<?php
require_once "../db.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>About Us - <?php echo $Web->web_name(); ?></title>
    <link rel="stylesheet" href="<?php echo $Web->get_assets("css/swiper.css"); ?>" />
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/visitor/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl mb-0 pb-0">
                        <!--  -->
                        <div class="card mx-auto card-flush mb-4">

                            <div class="card-body p-lg-17">

                                <div class="text-center mb-15">
                                    <h1 class="fs-2hx text-dark mb-5">Disclaimer</h1>
                                </div>
                                <div class="fs-5 fw-bold text-gray-600">
                                    <h3 class="text-center">Welcome To <?php echo $Web->web_name(); ?>!</h3>

                                    <p>All the information on this website - https://jamsrworld.com/ - is published in good faith and for general information purpose only. <?php echo $Web->web_name(); ?> does not make any warranties about the completeness, reliability and accuracy of this information. Any action you take upon the information you find on this website (<?php echo $Web->web_name(); ?>), is strictly at your own risk. <?php echo $Web->web_name(); ?> will not be liable for any losses and/or damages in connection with the use of our website.</p>

                                    <p>From our website, you can visit other websites by following hyperlinks to such external sites. While we strive to provide only quality links to useful and ethical websites, we have no control over the content and nature of these sites. These links to other websites do not imply a recommendation for all the content found on these sites. Site owners and content may change without notice and may occur before we have the opportunity to remove a link which may have gone 'bad'.</p>

                                    <p>Please be also aware that when you leave our website, other sites may have different privacy policies and terms which are beyond our control. Please be sure to check the Privacy Policies of these sites as well as their "Terms of Service" before engaging in any business or uploading any information.</p>

                                    <h2>Consent</h2>

                                    <p>By using our website, you hereby consent to our disclaimer and agree to its terms.</p>

                                    <h2>Update</h2>

                                    <p>Should we update, amend or make any changes to this document, those changes will be prominently posted here.</p>

                                    <p>If you require any more information or have any questions about our site's disclaimer, please feel free to contact us by email at puamith6@gmail.com</p>

                                </div>
                            </div>
                        </div>
                        <!--  -->
                    </div>
                </div>
                <?php include $Web->include("partials/visitor/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
</body>

</html>