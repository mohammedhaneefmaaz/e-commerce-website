<?php
require_once "../db.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>About Us - <?php echo $Web->web_name(); ?></title>
    <link rel="stylesheet" href="<?php echo $Web->get_assets("css/swiper.css"); ?>" />
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/visitor/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl mb-0 pb-0">
                        <!--  -->
                        <div class="card mx-auto card-flush mb-4">

                            <div class="card-body p-lg-17">

                                <div class="text-center mb-15">
                                    <h1 class="fs-2hx text-dark mb-5">Contact Us</h1>
                                    <h3 class="text-center">Welcome To <?php echo $Web->web_name(); ?>!</h3>
    
                                    <div class="fs-5 text-muted fw-bold">If you have any query regarding products, site or any other issue, please feel free to contact us at following: </div>
                                </div>

                                <div class="row g-5 mb-5">

                                    <a target="_blank" href="https://api.whatsapp.com/send?phone=+916382020120" class="col-sm-6 ps-lg-10">
                                        <div class="text-center bg-light card-rounded d-flex flex-column justify-content-center p-10 h-100">
                                            <i style="color:#25D366;" class="fab fs-3x fa-whatsapp"></i>
                                            <h1 class="text-dark fw-bolder my-5">Whatsapp</h1>
                                            <div class="text-primary fs-3 fw-bold">+91 6382020120</div>
                                        </div>
                                    </a>

                                    <a data-clipboard="true" data-clipboard-success="Email has been copied" data-clipboard-text="princeraj9137@gmail.com" class="cursor-pointer col-sm-6 ps-lg-10">
                                        <div class="text-center bg-light card-rounded d-flex flex-column justify-content-center p-10 h-100">
                                            <i class="fas text-primary fs-3x fa-envelope"></i>
                                            <h1 class="text-dark fw-bolder my-5">Email</h1>
                                            <div class="text-primary fs-3 fw-bold">mohammedhaneefmaaz@gmail.com</div>
                                        </div>
                                    </a>



                                 <!---   <a target="_blank" href="https://www.youtube.com/c/JamsrWorld" class="col-sm-6 ps-lg-10">
                                        <div class="text-center bg-light card-rounded d-flex flex-column justify-content-center p-10 h-100">
                                            <i style="color:#FF0000;" class="fab fs-3x fa-youtube"></i>
                                            <h1 class="text-dark fw-bolder my-5">Youtube</h1>
                                            <div class="text-primary fs-3 fw-bold">Jamsr world</div>
                                        </div>
                                    </a>

                                </div>


                            </div>
                        </div>
                        <!  -->
                    </div>
                </div>
                <?php include $Web->include("partials/visitor/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
</body>

</html>