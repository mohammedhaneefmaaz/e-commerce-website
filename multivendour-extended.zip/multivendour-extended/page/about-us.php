<?php
require_once "../db.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>About Us - <?php echo $Web->web_name(); ?></title>
    <link rel="stylesheet" href="<?php echo $Web->get_assets("css/swiper.css"); ?>" />
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/visitor/header.php"); ?>
                <div class="d-flex content flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl mb-0 pb-0">
                        <!--  -->
                        <div class="card mx-auto card-flush mb-4">

                            <div class="card-body p-lg-17">

                                <div class="text-center mb-15">
                                    <h1 class="fs-2hx text-dark mb-5">About Us</h1>
                                </div>
                                <div class="fs-5 fw-bold text-gray-600">
                                    <h3 class="text-center">Welcome To <?php echo $Web->web_name(); ?>!</h3>
                                    <p><span id="W_Name2"><?php echo $Web->web_name(); ?></span> is a Professional <span id="W_Type1">Web Development</span> Platform. Here we will provide you only interesting content, which you will like very much. We're dedicated to providing you the best of <span id="W_Type2">Web Development</span>, with a focus on dependability and <span id="W_Spec">Web Development</span>. We're working to turn our passion for <span id="W_Type3">Web Development</span> into a booming <a href="https://www.blogearns.com" rel="do-follow" style="color:inherit; text-decoration: none;">online website</a>. We hope you enjoy our <span id="W_Type4">Web Development</span> as much as we enjoy offering them to you.</p>
                                    <p>I will keep posting more important posts on my Website for all of you. Please give your support and love.</p>
                                    <p style="font-weight: bold; text-align: center;">Thanks For Visiting Our Site</p>
                                </div>


                            </div>
                        </div>
                        <!--  -->
                    </div>
                </div>
                <?php include $Web->include("partials/visitor/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
</body>

</html>