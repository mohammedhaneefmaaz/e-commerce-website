<?php
require_once "../db.php";
$Login->check_user_login();

use Ecommerce\Checkout;
use Ecommerce\PaymentMethod;

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Checkout Products - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/visitor/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div class="post d-flex flex-column-fluid" id="lx_post">
                        <div id="lx_content_container" class="container-xxl">

                            <?php if (Checkout::has_products($LogUser->user_id)) {
                            ?>
                                <div class="d-flex flex-column flex-lg-row gap-2">
                                    <div class="flex-grow-1">

                                        <div class="mb-2 card">
                                            <div class="card-header collapsible cursor-pointer rotate" data-bs-toggle="collapse" data-bs-target="#kt_docs_card_collapsible" aria-expanded="true">
                                                <div class="card-title">
                                                    <h2>Delivery Address</h2>
                                                </div>
                                                <div class="card-toolbar rotate-180">
                                                    <span class="svg-icon svg-icon-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <rect opacity="0.5" x="11" y="18" width="13" height="2" rx="1" transform="rotate(-90 11 18)" fill="black"></rect>
                                                            <path d="M11.4343 15.4343L7.25 11.25C6.83579 10.8358 6.16421 10.8358 5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75L11.2929 18.2929C11.6834 18.6834 12.3166 18.6834 12.7071 18.2929L18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25C17.8358 10.8358 17.1642 10.8358 16.75 11.25L12.5657 15.4343C12.2533 15.7467 11.7467 15.7467 11.4343 15.4343Z" fill="black"></path>
                                                        </svg>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="collapse show" id="kt_docs_card_collapsible">
                                                <div id="addressRow" class="card-body">
                                                    <?php echo Checkout::addresses($LogUser->user_id); ?>
                                                    <a class="btn btn-primary px-6 align-self-center text-nowrap" data-bs-toggle="modal" data-bs-target="#addAddress">Add New Address</a>
                                                </div>
                                            </div>

                                        </div>

                                        <div class="card">
                                            <div class="card-header">
                                                <div class="card-title">
                                                    <h2>Product Summary <span class="text-muted small">(<span id="products_count"><?php echo Checkout::products_count($LogUser->user_id); ?></span> items)</span></h2>
                                                </div>
                                            </div>
                                            <div id="checkout_products" class="card-body p-0">
                                                <?php echo Checkout::products($LogUser->user_id); ?>
                                            </div>
                                        </div>


                                    </div>

                                    <div class="w-lg-400px min-w-lg-400px w-100">

                                        <div class="card mb-2 card-flush br-4">
                                            <div class="card-header">
                                                <div class="card-title">
                                                    <h2>Price details</h2>
                                                </div>
                                            </div>
                                            <div id="price_details_card" class="card-body fs-5 pt-0">
                                                <?php echo Checkout::price_details_card($LogUser->user_id); ?>
                                            </div>
                                        </div>

                                        <div class="card card-flush">
                                            <div class="card-header">
                                                <div class="card-title">
                                                    <h2>Payment Method</h2>
                                                </div>
                                            </div>
                                            <div class="card-body pt-0">
                                                <div data-lx-buttons="true">

                                                    <?php
                                                    if (PaymentMethod::isPaytmActive()) {
                                                    ?>
                                                        <label class="btn btn-outline btn-outline-secondary bg-white d-flex flex-stack text-start p-6 mb-5 active">
                                                            <div class="d-flex align-items-center me-2">
                                                                <div class="form-check form-check-custom form-check-solid form-check-primary me-6">
                                                                    <input class="form-check-input" type="radio" name="payment_method" value="Paytm" autocomplete="off">
                                                                </div>
                                                                <div class="flex-grow-1">
                                                                    <div class="fw-bold  text-primary-alt">
                                                                        Paytm
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </label>
                                                    <?php
                                                    }

                                                    if (PaymentMethod::isRazorpayActive()) {
                                                    ?>
                                                        <label class="btn btn-outline btn-outline-secondary bg-white d-flex flex-stack text-start p-6 mb-5 active">
                                                            <div class="d-flex align-items-center me-2">
                                                                <div class="form-check form-check-custom form-check-solid form-check-primary me-6">
                                                                    <input class="form-check-input" type="radio" name="payment_method" value="Razorpay" autocomplete="off">
                                                                </div>
                                                                <div class="flex-grow-1">
                                                                    <div class="fw-bold  text-primary-alt">
                                                                        Razor Pay
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </label>
                                                    <?php  }

                                                    if (Checkout::is_cod_available($LogUser->user_id)) {
                                                    ?>
                                                        <label class="btn btn-outline btn-outline-secondary bg-white d-flex flex-stack text-start p-6 mb-5 active">
                                                            <div class="d-flex align-items-center me-2">
                                                                <div class="form-check form-check-custom form-check-solid form-check-primary me-6">
                                                                    <input class="form-check-input" type="radio" name="payment_method" value="CashOnDelivery" autocomplete="off">
                                                                </div>
                                                                <div class="flex-grow-1">
                                                                    <div class="fw-bold  text-primary-alt">
                                                                        Cash on delivery
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </label>
                                                    <?php  } else if (PaymentMethod::is_COD_Active()) {
                                                    ?>
                                                        <label class="btn btn-outline btn-outline-secondary opacity-75 bg-white d-flex flex-stack text-start p-6 mb-5 active">
                                                            <div class="d-flex align-items-center me-2">
                                                                <div class="form-check form-check-custom form-check-solid form-check-primary me-6">
                                                                    <input class="form-check-input" type="radio" disabled autocomplete="off">
                                                                </div>
                                                                <div class="flex-grow-1">
                                                                    <div class="fw-bold  text-primary-alt">
                                                                        Cash on delivery
                                                                        <div class="fs-8 text-danger">Not available for this order</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </label>
                                                    <?php
                                                    }


                                                    ?>
                                                    <div id="errorWrapper"></div>
                                                    <button id="checkout" class="mt-4 btn w-100 btn-active-text-white btn-outline btn-outline-primary ">Proceed Checkout</button>

                                                </div>
                                            </div>
                                        </div>
                                        <!--  -->
                                    </div>
                                </div>
                            <?php
                            } else {
                            ?>
                                <div class="min-h-100 justify-align-center pb-8 card">
                                    <img class="mh-200px img-fluid" src="<?php echo $Web->get_assets("images/web/empty-cart.svg"); ?>" alt="">
                                    <h2>No products in Checkout</h2>
                                    <a href="<?php echo $Web->base_url(); ?>" class="mt-8 min-w-200px w-100 w-md-auto btn btn-primary">Shop Now</a>
                                </div>
                            <?php
                            } ?>
                        </div>
                    </div>
                </div>

                <?php include $Web->include("partials/visitor/footer.php"); ?>


            </div>
        </div>
    </div>

    <div class="modal fade" id="editAddress" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered mw-650px">
            <div class="modal-content">
            </div>
        </div>
    </div>

    <div class="modal fade" id="addAddress" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered mw-650px">
            <div class="modal-content">
                <form novalidate class="form">
                    <div class="modal-header">
                        <h2>Add New Address</h2>
                        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body py-10 px-lg-17">
                        <div class="scroll-y px-7" id="address_scroll" data-lx-scroll="true" data-lx-scroll-activate="{default: false, lg: true}" data-lx-scroll-max-height="auto" data-lx-scroll-wrappers="#address_scroll" data-lx-scroll-offset="300px">

                            <div class="d-flex flex-column mb-5 fv-row">
                                <label class="required fs-5 fw-bold mb-2">Full Name</label>
                                <input data-max="40" required class="form-control form-control-solid" placeholder="" name="full_name" />
                                <div class="invalid-feedback">Full Name is required</div>
                            </div>
                            <div class="d-flex flex-column mb-5 fv-row">
                                <label class="required fs-5 fw-bold mb-2">Mobile Number </label>
                                <input required class="form-control form-control-solid" placeholder="" name="mobile_number" />
                                <div class="invalid-feedback">Mobile Number is required</div>
                            </div>
                            <div class="d-flex flex-column mb-5 fv-row">
                                <label class="required fs-5 fw-bold mb-2"> Town/City </label>
                                <input data-max="100" required class="form-control form-control-solid" placeholder="" name="city" />
                                <div class="invalid-feedback">Town/City is required</div>
                            </div>
                            <div class="d-flex flex-column mb-5 fv-row">
                                <label class="required fs-5 fw-bold mb-2">Area, Colony, Street, Sector, Village </label>
                                <input data-max="100" required class="form-control form-control-solid" placeholder="" name="area" />
                                <div class="invalid-feedback">Area is required</div>
                            </div>
                            <div class="d-flex flex-column mb-5 fv-row">
                                <label class="fs-5 fw-bold mb-2"> Flat, House no., Building, Company, Apartment </label>
                                <input data-max="100" class="form-control form-control-solid" placeholder="" name="flat" />
                            </div>
                            <div class="d-flex flex-column mb-5 fv-row">
                                <label class="required fs-5 fw-bold mb-2"> Landmark</label>
                                <input data-max="100" required class="form-control form-control-solid" placeholder="" name="landmark" />
                                <div class="invalid-feedback">Landmark is required</div>
                            </div>
                            <div class="row g-9 mb-5">
                                <div class="col-md-6 fv-row">
                                    <label class="required fs-5 fw-bold mb-2">State / Province</label>
                                    <input data-max="30" required class="form-control form-control-solid" placeholder="" name="state" />
                                    <div class="invalid-feedback">State is required</div>
                                </div>
                                <div class="col-md-6 fv-row">
                                    <label class="required fs-5 fw-bold mb-2">Post Code</label>
                                    <input  maxlength="6" required class="form-control form-control-solid" placeholder="" name="postcode" />
                                    <div class="invalid-feedback">Post Code is required</div>
                                </div>
                            </div>
                            <div class="fv-row">
                                <div class="d-flex">
                                    <label class="fs-5 fw-bold"> Address Type</label>
                                    <div class="ms-4">
                                        <div class="form-check form-check-custom form-check-solid">
                                            <input required class="form-check-input me-1" name="address_type" type="radio" value="office" id="office">
                                            <label class="form-check-label" for="office">
                                                <div class="fw-bold text-gray-800">Office(Delivery between 10 AM - 5 PM)</div>
                                            </label>
                                        </div>
                                        <div class="mt-4 flex-wrap form-check form-check-custom form-check-solid">
                                            <input required class="form-check-input me-1" name="address_type" type="radio" value="home" id="home">
                                            <label class="form-check-label" for="home">
                                                <div class="fw-bold text-gray-800">Home(All day delivery)</div>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="invalid-feedback">Address Type is required</div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer flex-center">
                        <button data-bs-dismiss="modal" type="button" class="btn btn-light me-3">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include $Web->include("partials/scripts.php"); ?>
    <script>
        Cart.checkout("<?php echo Address::primary_id($LogUser->user_id); ?>");
    </script>
</body>


</html>