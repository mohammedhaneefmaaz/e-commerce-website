<?php

require_once "../db.php";
?>

<html class="js" style="--pulse-color: #fffc0230;" lang="zxx">

<head>
    <title><?php echo $Web->web_name(); ?> - 404 Page Not Found</title>
    <?php include $Web->include("partials/meta.php"); ?>
    <link rel="stylesheet" href="<?php echo $Web->base_url(); ?>/404/vendor.bundle.css">
    <link rel="stylesheet" href="<?php echo $Web->base_url(); ?>/404/style-dark.css">
</head>

<body class="nk-body body-wider bg-light no-touch nk-nio-theme page-loaded firefox" cz-shortcut-listen="true">
    <div class="nk-wrap ov-h has-ovm">
        <div class="container">
            <main class="nk-pages nk-pages-centered px-0 text-center">
                <header class="pt-5"><a href="<?php echo $Web->base_url(); ?>" class="d-inline-block logo-lg"><img src="<?php echo $Web->logo(); ?>" alt="logo"></a></header>
                <div class="my-auto py-5">
                    <div class="row justify-content-center">
                        <div class="col-xl-6 col-md-7 col-sm-9">
                            <div class="position-relative">
                                <div class="piller-one"><img src="<?php echo $Web->base_url(); ?>/404/piler-a.png" alt="graphic"></div>
                                <div class="piller-two"><img src="<?php echo $Web->base_url(); ?>/404/piler-b.png" alt="graphic"></div>
                                <h2 class="title-xxl-grad">404</h2>
                                <h5 class="pb-2">Opps! Why you’re here?</h5>
                                <p class="">We are very sorry for inconvenience. It looks like you’re try to access a page that either has been deleted or never existed.</p><a href="<?php echo $Web->base_url(); ?>" class="btn btn-grad btn-md btn-round">Back to home</a>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        <div class="nk-ovm shape-z4"></div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
</body>

</html>