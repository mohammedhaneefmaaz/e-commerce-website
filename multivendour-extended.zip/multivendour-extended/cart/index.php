<?php
require_once "../db.php";
$Login->check_user_login();

use Ecommerce\Cart;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Cart - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/visitor/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div class="post d-flex flex-column-fluid" id="lx_post">
                        <div id="lx_content_container" class="container-xxl">

                            <div class="d-flex flex-column flex-lg-row">
                                <div class="flex-grow-1">
                                    <div class="card mb-2 card-flush">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>Cart <span class="text-muted small">(<span id="cart_count"><?php echo Cart::cart_products_count($LogUser->user_id); ?></span> items)</span></h2>
                                            </div>
                                        </div>
                                        <div id="cart_products" class="card-body p-0">
                                            <?php echo Cart::cart_products($LogUser->user_id); ?>
                                        </div>
                                        <div id="emptyCartContainer" class="<?php if (Cart::cart_products_count($LogUser->user_id) != 0) {
                                                                                echo "d-none";
                                                                            } ?> align-center p-4 flex-column">
                                            <img class="mh-200px img-fluid" src="<?php echo $Web->get_assets("images/web/empty-cart.svg"); ?>" alt="">
                                            <h2>Your Cart is Empty</h2>
                                            <a href="" class="mt-8 min-w-200px w-100 w-md-auto btn btn-primary">Shop Now</a>
                                        </div>
                                    </div>


                                </div>
                                <div class="w-lg-400px min-w-lg-400px ms-0 ms-lg-2 w-100">

                                    <div class="card mb-2 card-flush br-4">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>Price details</h2>
                                            </div>
                                        </div>
                                        <div id="price_details_card" class="card-body fs-5 pt-0">
                                            <?php echo Cart::cart_price_details_card($LogUser->user_id); ?>
                                        </div>
                                    </div>

                                    <!--  -->
                                </div>
                            </div>

                            <div id="savedContainer" class="<?php if (Cart::saved_products_count($LogUser->user_id) == 0) echo "d-none "; ?> d-flex flex-column flex-lg-row gap-2">
                                <div class="flex-grow-1 gap-2">
                                    <div class="card">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>Saved For Later <span class="text-muted small">(<span id="saved_count"><?php echo Cart::saved_products_count($LogUser->user_id); ?></span> items)</span></h2>
                                            </div>
                                        </div>
                                        <div id="saved_card" class="card-body p-0">
                                            <?php echo Cart::saved_products($LogUser->user_id); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="w-lg-400px w-100">
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <?php include $Web->include("partials/visitor/footer.php"); ?>


            </div>
        </div>
    </div>

    <div class="modal fade" id="modal" tabindex="-1" style="display: none;" aria-hidden="true">
        <div class="modal-dialog mw-650px">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="fw-bolder">Few items are unavailable for checkout</h2>
                    <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                        <span class="svg-icon svg-icon-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                            </svg>
                        </span>
                    </div>
                </div>
                <div class="modal-body scroll-y">

                </div>
                <div class="modal-footer">
                    <div class="justify-right">
                        <a data-bs-dismiss="modal" class="btn btn-light me-3">Cancel</a>
                        <button type="submit" id="continue" class="btn btn-primary">Yes, Continue</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Few items are unavailable for checkout -->

    <?php include $Web->include("partials/scripts.php"); ?>
    <script>
        LXUtil.onDOMContentLoaded((function() {
            Cart.init();
        }));
    </script>
</body>


</html>