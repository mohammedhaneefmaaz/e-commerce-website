<?php

use Ecommerce\Layout;

require_once "../db.php";

if (!isset($_GET["page_id"], $_GET["id"])) Errors::response_404();
$page_id = $Web->sanitize_text($_GET["page_id"]);
$layout_id = $Web->sanitize_text($_GET["id"]);
if (!Layout::is_layout_id($layout_id)) Errors::response_404();
$Layout = new Layout($layout_id);

if ($Layout->page_id() !== $page_id) Errors::response_404();

use Ecommerce\Home;

$Home = new Home();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Ecommerce - <?php echo $Web->web_name(); ?></title>
    <link rel="stylesheet" href="<?php echo $Web->get_assets("css/swiper.css"); ?>" />
    <?php include $Web->include("partials/meta.php"); ?>
    <style>
        .slider1 img,
        .row img {
            width: 100%;
        }
    </style>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/visitor/header.php"); ?>
                <div class="d-flex flex-column content flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl d-flex flex-column gap-2 gap-lg-4">
                        <?php echo $Home->components($layout_id); ?>
                    </div>
                    <?php include $Web->include("partials/visitor/footer.php"); ?>
                </div>
            </div>
            <?php include $Web->include("partials/scripts.php"); ?>
            <!-- Swiper JS -->
            <script src="<?php echo $Web->get_assets("js/swiper.js"); ?>"></script>
            <script>
                Ecommerce.Home();
            </script>

</body>

</html>