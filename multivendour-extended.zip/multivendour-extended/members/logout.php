<?php
require_once("../db.php");
$Login->check_user_login();
$url = $_GET["redirect_url"] ?? $Web->base_url();
$session_id = $Web->sanitize_text($_COOKIE['_usession_id']);

$stmt = $db->prepare("UPDATE $Web->login_session_tbl SET status = 'expired' WHERE session_id = ? ");
$query = $stmt->execute([$session_id]);

if ($query) {
    setcookie('_usession_id', '', time() - (86400 * 30), '/');
    $Web->locate_to($url);
} else {
    Errors::response("Error in logout");
}
