<!DOCTYPE html>
<html lang="en">

<head>
    <title>Register - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body">
    <div class="d-flex flex-column flex-root">
        <div class="d-flex flex-column flex-column-fluid bgi-position-y-bottom position-x-center bgi-no-repeat bgi-size-contain bgi-attachment-fixed" style="background-repeat:inherit;background-image: url(<?php echo $Web->get_assets('images/web/login-bg.jpg'); ?>)">
            <div class="d-flex flex-center flex-column flex-column-fluid p-10 pb-lg-20">
                <a href="<?php echo $Web->base_url(); ?>" class="mb-12">
                    <img alt="Logo" src="<?php echo $Web->logo(); ?>" class="h-40px" />
                </a>

                <div class="w-lg-500px bg-body rounded shadow-sm p-10 p-lg-15 mx-auto">

                    <form class="form w-100 needs-validation" novalidate="novalidate" id="userRegisterForm">
                        <div class="mb-10 text-center">
                            <h1 class="text-dark mb-3">Create your account on <?php echo $Web->web_name(); ?></h1>
                        </div>
                        <div class="row mb-10">
                            <div class="fv-row col-lg-6">
                                <label class="form-label fw-bold text-dark fs-6">First Name</label>
                                <input required maxlength="20" value="<?php echo  $registerDetails['first_name']; ?>" class="form-control form-control-lg" type="text" placeholder="" name="first_name" />
                                <div class="invalid-feedback">First Name is required</div>
                            </div>
                            <div class="fv-row col-lg-6">
                                <label class="form-label fw-bold text-dark fs-6">Last Name</label>
                                <input required maxlength="20" value="<?php echo  $registerDetails['last_name']; ?>" class="form-control form-control-lg" type="text" placeholder="" name="last_name" />
                                <div class="invalid-feedback">Last Name is required</div>
                            </div>
                        </div>
                        <div class="fv-row mb-10">
                            <label class="form-label fw-bold text-dark fs-6">Email</label>
                            <input value="<?php echo  $registerDetails['user_email']; ?>" readonly class="form-control form-control-lg" type="email" placeholder="" name="email" />
                        </div>


                        <!--begin::Alert-->
                        <div class="alert alert-dismissible bg-light-primary border border-primary border-dashed border-2 d-flex flex-column flex-sm-row p-5 mb-10">
                            <span class="svg-icon svg-icon-2hx svg-icon-primary me-4 mb-5 mb-sm-0">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black"></rect>
                                    <rect x="11" y="14" width="7" height="2" rx="1" transform="rotate(-90 11 14)" fill="black"></rect>
                                    <rect x="11" y="17" width="2" height="2" rx="1" transform="rotate(-90 11 17)" fill="black"></rect>
                                </svg></span>
                            <div class="d-flex flex-column pe-0 pe-sm-10">
                                <span>Enter Password and Confirm Password for login with email also.</span>
                            </div>
                            <button type="button" class="position-absolute position-sm-relative m-2 m-sm-0 top-0 end-0 btn btn-icon ms-sm-auto" data-bs-dismiss="alert">
                                <i class="bi bi-x fs-1 text-primary"></i>
                            </button>
                        </div>
                        <!--end::Alert-->



                        <div class="mb-10 fv-row">
                            <label class="form-label fw-bold text-dark fs-6">Password</label>
                            <div class="position-relative">
                                <input class="form-control no-bg password-input form-control-lg" type="password" name="password" />
                                <div class="show password-toggle">
                                    <svg class="show" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="-10 -10 47 38" style="stroke:#0c0c0d">
                                        <g style="stroke-width:2;fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round" transform="translate(1 1)">
                                            <path d="m0 8c0-2 5.5-8 11-8s11 6 11 8-5.5 8-11 8-11-6-11-8z" />
                                            <path d="m11 12c2.2091 0 4-1.7909 4-4 0-2.20914-1.7909-4-4-4-2.20914 0-4 1.79086-4 4 0 2.2091 1.79086 4 4 4z" />
                                            <path d="m13 7c.5523 0 1-.44772 1-1s-.4477-1-1-1-1 .44772-1 1 .4477 1 1 1z" fill="#000" fill-rule="nonzero" />
                                        </g>
                                    </svg>
                                    <svg class="hide" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="-10 -7 47 38" style="stroke:#0c0c0d">
                                        <g style="stroke-width:2;fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round" transform="translate(1 1)">
                                            <path d="m4.14 15.76c-2.44-1.76-4.14-4.13-4.14-5.22 0-1.91 5.27-7.66 10.54-7.66 1.8042928.06356301 3.559947.60164173 5.09 1.56m3.53 2.85c.954643.86366544 1.6242352 1.9970896 1.92 3.25 0 1.92-5.27 7.67-10.54 7.67-.82748303-.0073597-1.64946832-.1353738-2.44-.38" />
                                            <path d="m11.35 14.29c1.3567546-.2923172 2.4501897-1.2939955 2.86-2.62m-1.56-4.33c-1.5090443-.9785585-3.49511641-.77861361-4.77882585.48110127-1.28370945 1.25971488-1.52108848 3.24166123-.57117415 4.76889873" />
                                            <path d="m13.08 7.9c-.1699924-.15256531-.3916348-.2347875-.62-.23-.5522847 0-1 .44771525-1 1 .0046671.23144917.0894903.45410992.24.63" />
                                            <path d="m21.08 0-21.08 21.08" />
                                        </g>
                                    </svg>
                                </div>
                            </div>
                        </div>

                        <div class="fv-row mb-10">
                            <label class="form-label fw-bold text-dark fs-6">Confirm Password</label>
                            <div class="position-relative">
                                <input class="form-control no-bg password-input form-control-lg" type="password" name="confirm_password" />
                                <div class="show password-toggle">
                                    <svg class="show" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="-10 -10 47 38" style="stroke:#0c0c0d">
                                        <g style="stroke-width:2;fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round" transform="translate(1 1)">
                                            <path d="m0 8c0-2 5.5-8 11-8s11 6 11 8-5.5 8-11 8-11-6-11-8z" />
                                            <path d="m11 12c2.2091 0 4-1.7909 4-4 0-2.20914-1.7909-4-4-4-2.20914 0-4 1.79086-4 4 0 2.2091 1.79086 4 4 4z" />
                                            <path d="m13 7c.5523 0 1-.44772 1-1s-.4477-1-1-1-1 .44772-1 1 .4477 1 1 1z" fill="#000" fill-rule="nonzero" />
                                        </g>
                                    </svg>
                                    <svg class="hide" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="-10 -7 47 38" style="stroke:#0c0c0d">
                                        <g style="stroke-width:2;fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round" transform="translate(1 1)">
                                            <path d="m4.14 15.76c-2.44-1.76-4.14-4.13-4.14-5.22 0-1.91 5.27-7.66 10.54-7.66 1.8042928.06356301 3.559947.60164173 5.09 1.56m3.53 2.85c.954643.86366544 1.6242352 1.9970896 1.92 3.25 0 1.92-5.27 7.67-10.54 7.67-.82748303-.0073597-1.64946832-.1353738-2.44-.38" />
                                            <path d="m11.35 14.29c1.3567546-.2923172 2.4501897-1.2939955 2.86-2.62m-1.56-4.33c-1.5090443-.9785585-3.49511641-.77861361-4.77882585.48110127-1.28370945 1.25971488-1.52108848 3.24166123-.57117415 4.76889873" />
                                            <path d="m13.08 7.9c-.1699924-.15256531-.3916348-.2347875-.62-.23-.5522847 0-1 .44771525-1 1 .0046671.23144917.0894903.45410992.24.63" />
                                            <path d="m21.08 0-21.08 21.08" />
                                        </g>
                                    </svg>
                                </div>
                            </div>
                        </div>
                        <div class="fv-row mb-10">
                            <label class="form-check form-check-custom form-check-inline">
                                <input id="toc" required class="form-check-input" type="checkbox" name="toc" value="1" />
                                <span class="form-check-label fw-bold text-gray-700 fs-6">
                                    I Agree <a class="ms-1 link-primary">Terms and conditions</a></span>
                            </label>
                            <div class="invalid-feedback">You must have to agree with terms & conditions</div>
                        </div>
                        <div class="text-center">
                            <button type="submit" id="submit" class="btn btn-lg w-100 btn-primary">Register</button>
                        </div>

                    </form>
                </div>



            </div>

        </div>
    </div>


    <?php include $Web->include("partials/scripts.php"); ?>

    <script>
        LXUtil.onDOMContentLoaded((function() {
            Login.userGoogleRegister();
        }));
    </script>

</body>

</html>