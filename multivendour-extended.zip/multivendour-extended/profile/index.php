<?php
require_once "../db.php";
$Login->check_user_login();
$active_profile_tab = "settings";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Settings - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
    <style>
        .form-edit-disabled #profileContainer *:not(img){
            display: none !important;
        }
    </style>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/visitor/header.php"); ?>


                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div class="post d-flex flex-column-fluid" id="lx_post">
                        <div id="lx_content_container" class="container-xxl">

                            <div class="card mb-2 mb-lg-4">
                                <div class="card-header">
                                    <div class="card-title m-0">
                                        <h3 class="fw-bolder m-0">Profile Details</h3>
                                    </div>
                                    <div class="card-toolbar">
                                        <a type="edit" data-form="profile_details_form" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                            <span class="svg-icon svg-icon-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="black"></path>
                                                    <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="black"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <form novalidate id="profile_details_form" class="form">
                                    <div class="card-body border-top p-9">
                                        <div class="row mb-6">
                                            <label class="col-lg-4 col-form-label fw-bold fs-6">Avatar</label>
                                            <div class="col-lg-8">
                                                <div id="profileContainer" class="image-input <?php if ($LogUser->avatar_id() == '0') echo "image-input-empty"; ?> image-input-circle">
                                                    <div class="profile-progress"></div>
                                                    <img class="image-input-wrapper w-125px h-125px" src="<?php echo $LogUser->avatar(); ?> " />
                                                    <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-lx-image-input-action="change" data-bs-toggle="tooltip" title="Change avatar">
                                                        <i class="bi bi-pencil-fill fs-7"></i>
                                                        <input type="file" name="avatar" accept=".png, .jpg, .jpeg,.webp" />
                                                        <input type="hidden" value="<?php echo $LogUser->avatar_id(); ?>" name="avatar_image_id" />
                                                    </label>
                                                    <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-lx-image-input-action="remove" data-bs-toggle="tooltip" title="Remove avatar">
                                                        <i class="bi bi-x fs-2"></i>
                                                    </span>
                                                </div>
                                                <div class="form-text">Allowed file types: png, jpg, jpeg,webp.</div>
                                            </div>
                                        </div>
                                        <div class="row mb-6">
                                            <label class="col-lg-4 col-form-label required fw-bold fs-6">Full Name</label>
                                            <div class="col-lg-8">
                                                <div class="row">
                                                    <div class="col-lg-6 fv-row">
                                                        <input required type="text" name="first_name" class="form-control form-control-lg mb-3 mb-lg-0" placeholder="First name" value="<?php echo $LogUser->first_name(); ?>">
                                                        <div class="invalid-feedback">First Name is required</div>
                                                    </div>
                                                    <div class="col-lg-6 fv-row">
                                                        <input required type="text" name="last_name" class="form-control form-control-lg" placeholder="Last name" value="<?php echo $LogUser->last_name(); ?>" />
                                                        <div class="invalid-feedback">Last Name is required</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row mb-6">
                                            <label class="col-lg-4 col-form-label fw-bold fs-6">
                                                <span class="required">Contact Number</span>
                                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="Contact number must be active"></i>
                                            </label>
                                            <div class="col-lg-8 fv-row">
                                                <input required type="tel" name="contact_number" class="form-control form-control-lg" placeholder="Contact number" value="<?php echo $LogUser->contact_number(); ?>" />
                                                <div class="invalid-feedback">Contact Number is required</div>
                                            </div>
                                        </div>
                                        <div class="row mb-6">
                                            <label class="col-lg-4 col-form-label fw-bold fs-6">
                                                <span class="required">Contact Email</span>
                                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="Contact Email must be active"></i>
                                            </label>
                                            <div class="col-lg-8 fv-row">
                                                <input required type="tel" name="contact_email" class="form-control form-control-lg" placeholder="Contact Email" value="<?php echo $LogUser->contact_email(); ?>" />
                                                <div class="invalid-feedback">Contact Email is required</div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="card-footer d-flex justify-content-end px-9 py-0">
                                        <button type="cancel" class="btn my-4 d1-none me-4 btn-secondary">Cancel</button>
                                        <button type="submit" class="btn my-4 d1-none btn-primary" id="submit">Save Changes</button>
                                    </div>
                                </form>
                            </div>


                            <div class="card mb-2 mb-lg-4">
                                <div class="card-header">
                                    <div class="card-title">
                                        <h3>Billing Address</h3>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div id="addressRow" class="row gx-9 gy-6">
                                        <?php echo Address::all_cards($LogUser->user_id); ?>
                                        <div class="col-lg-6">
                                            <div data-bs-toggle="modal" data-bs-target="#addAddress" class="cursor-pointer h-100 d-flex bg-light-success border-2 rounded border-success border border-dashed flex-stack h-xl-100 mb-10 p-6 justify-align-center">
                                                <div class="text-success justify-align-center fw-bolder"><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <rect opacity="0.5" x="11" y="18" width="12" height="2" rx="1" transform="rotate(-90 11 18)" fill="black"></rect>
                                                            <rect x="6" y="11" width="12" height="2" rx="1" fill="black"></rect>
                                                        </svg></span>Add an address</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card mb-2 mb-lg-4">
                                <div class="card-header " role="button" data-bs-toggle="collapse" data-bs-target="#lx_account_signin_method">
                                    <div class="card-title m-0">
                                        <h3 class="fw-bolder m-0">Sign-in Method</h3>
                                    </div>
                                </div>
                                <div id="lx_account_settings_signin_method" class="collapse show">
                                    <div class="card-body border-top p-9">
                                        <div class="d-flex flex-wrap align-items-center">
                                            <div id="lx_signin_email">
                                                <div class="fs-6 fw-bolder mb-1">Email Address</div>
                                                <div class="fw-bold text-gray-600"><?php echo $LogUser->email() ?></div>
                                            </div>

                                        </div>
                                        <div class="separator separator-dashed my-6"></div>
                                        <div class="d-flex flex-wrap align-items-center mb-10">
                                            <div class="" id="signin_password">
                                                <div class="fs-6 fw-bolder mb-1">Password</div>
                                                <div class="fw-bold text-gray-600">************</div>
                                            </div>

                                            <?php if ($LogUser->email_login() == "on") { ?>

                                                <div id="signin_password_edit" class="flex-row-fluid d-none">
                                                    <form id="changePasswordForm" class="form" novalidate="novalidate">
                                                        <div class="row">
                                                            <div class="col-lg-4 fv-row mb-6">
                                                                <label for="currentpassword" class="form-label fs-6 fw-bolder mb-3">Current Password</label>
                                                                <input required type="password" class="form-control form-control-lg" name="current_password" id="currentpassword" />
                                                                <div class="invalid-feedback">Current Password is required</div>
                                                            </div>
                                                            <div class="col-lg-4 fv-row mb-6">
                                                                <label for="newpassword" class="form-label fs-6 fw-bolder mb-3">New Password</label>
                                                                <input required type="password" class="form-control form-control-lg" name="new_password" id="newpassword" />
                                                                <div class="invalid-feedback">New Password is required</div>
                                                            </div>
                                                            <div class="col-lg-4 fv-row mb-6">
                                                                <label for="confirmpassword" class="form-label fs-6 fw-bolder mb-3">Confirm New Password</label>
                                                                <input required type="password" class="form-control form-control-lg" name="confirm_password" id="confirmpassword" />
                                                                <div class="invalid-feedback">Confirm New Password is required</div>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex">
                                                            <button type="submit" class="btn btn-primary me-2 px-6">Update Password</button>
                                                            <button id="password_cancel" type="button" class="btn btn-color-gray-400 btn-active-light-primary px-6">Cancel</button>
                                                        </div>
                                                    </form>
                                                </div>
                                                <div id="login_change_password" class="ms-auto">
                                                    <button class="btn btn-light btn-active-light-primary">Change Password</button>
                                                </div>

                                            <?php } else { ?>


                                                <div id="add_password_edit" class="flex-row-fluid d-none">
                                                    <form id="add_password_form" class="form" novalidate="novalidate">
                                                        <div class="row mb-1">
                                                            <div class="col-lg-6">
                                                                <div class="fv-row mb-0">
                                                                    <label for="password" class="form-label fs-6 fw-bolder mb-3">Password</label>
                                                                    <input required type="password" class="form-control form-control-lg" name="password" id="password" />
                                                                    <div class="invalid-feedback">Password is required</div>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <div class="fv-row mb-0">
                                                                    <label for="confirmpassword" class="form-label fs-6 fw-bolder mb-3">Confirm Password</label>
                                                                    <input required type="password" class="form-control form-control-lg" name="confirm_password" id="confirmpassword" />
                                                                    <div class="invalid-feedback">Confirm Password is required</div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="mt-4 d-flex">
                                                            <button id="password_submit" type="submit" class="btn btn-primary me-2 px-6">Add Password</button>
                                                            <button id="add_password_cancel" type="button" class="btn btn-color-gray-400 btn-active-light-primary px-6">Cancel</button>
                                                        </div>
                                                    </form>
                                                </div>

                                                <div id="add_password_button" class="ms-auto">
                                                    <button class="btn btn-light btn-active-light-primary">Add Password</button>
                                                </div>

                                            <?php } ?>
                                        </div>

                                        <?php if ($LogUser->email_login() == "on") { ?>
                                            <div class="notice d-flex bg-light-primary rounded border-primary border border-dashed p-6">
                                                <span class="svg-icon svg-icon-2tx svg-icon-primary me-4">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path opacity="0.3" d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z" fill="black" />
                                                        <path d="M10.5606 11.3042L9.57283 10.3018C9.28174 10.0065 8.80522 10.0065 8.51412 10.3018C8.22897 10.5912 8.22897 11.0559 8.51412 11.3452L10.4182 13.2773C10.8099 13.6747 11.451 13.6747 11.8427 13.2773L15.4859 9.58051C15.771 9.29117 15.771 8.82648 15.4859 8.53714C15.1948 8.24176 14.7183 8.24176 14.4272 8.53714L11.7002 11.3042C11.3869 11.6221 10.874 11.6221 10.5606 11.3042Z" fill="black" />
                                                    </svg>
                                                </span>

                                                <div class="d-flex flex-stack flex-grow-1 flex-wrap flex-md-nowrap">
                                                    <div class="mb-3 mb-md-0 fw-bold">
                                                        <h4 class="text-gray-900 fw-bolder">Secure Your Account</h4>
                                                        <div class="fs-6 text-gray-700 pe-7">Two-factor authentication adds an extra layer of security to your account. To log in, in addition you'll need to provide a 6 digit code</div>
                                                    </div>
                                                    <button type="submit" id="enableVerification" class="btn btn-primary px-6 align-self-center text-nowrap">
                                                        <span class="indicator-label"><?php echo ($LogUser->login_verification() == "on") ? "Disable" : "Enable";  ?></span>
                                                        <span class="indicator-progress">Please wait...
                                                            <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                                    </button>
                                                </div>
                                            </div>
                                        <?php } ?>


                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">
                                        <h3>Login Sessions</h3>
                                    </div>
                                    <div class="card-toolbar">
                                        <button type="button" class="btn btn-sm btn-flex btn-light-primary" id="log_out_all_sessions">
                                            <span class="svg-icon svg-icon-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <rect opacity="0.3" x="4" y="11" width="12" height="2" rx="1" fill="black"></rect>
                                                    <path d="M5.86875 11.6927L7.62435 10.2297C8.09457 9.83785 8.12683 9.12683 7.69401 8.69401C7.3043 8.3043 6.67836 8.28591 6.26643 8.65206L3.34084 11.2526C2.89332 11.6504 2.89332 12.3496 3.34084 12.7474L6.26643 15.3479C6.67836 15.7141 7.3043 15.6957 7.69401 15.306C8.12683 14.8732 8.09458 14.1621 7.62435 13.7703L5.86875 12.3073C5.67684 12.1474 5.67684 11.8526 5.86875 11.6927Z" fill="black"></path>
                                                    <path d="M8 5V6C8 6.55228 8.44772 7 9 7C9.55228 7 10 6.55228 10 6C10 5.44772 10.4477 5 11 5H18C18.5523 5 19 5.44772 19 6V18C19 18.5523 18.5523 19 18 19H11C10.4477 19 10 18.5523 10 18C10 17.4477 9.55228 17 9 17C8.44772 17 8 17.4477 8 18V19C8 20.1046 8.89543 21 10 21H19C20.1046 21 21 20.1046 21 19V5C21 3.89543 20.1046 3 19 3H10C8.89543 3 8 3.89543 8 5Z" fill="#C4C4C4"></path>
                                                </svg>
                                            </span>
                                            Log out all sessions</button>
                                    </div>
                                </div>
                                <div class="card-body">
                                        <table id="loginSessionTbl" class="table align-middle table-row-dashed gy-5">
                                            <thead class="border-bottom border-gray-200 fs-7 fw-bolder">
                                                <tr class="text-muted text-uppercase gs-0">
                                                    <th class="min-w-100px">S. NO.</th>
                                                    <th class="min-w-150px">Location</th>
                                                    <th class="min-w-100px">IP Address</th>
                                                    <th class="min-w-200px">Device</th>
                                                    <th class="min-w-150px">Time</th>
                                                    <th class="min-w-50px">Status</th>
                                                    <th class="min-w-100px">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody class="fs-6 fw-bold text-gray-600">

                                            </tbody>
                                        </table>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>

                <div class="modal fade" id="authentication_modal" tabindex="-1" style="display: none;" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered mw-550px">
                        <div class="modal-content">
                            <div class="modal-header flex-stack">
                                <h2>Choose An Authentication Method</h2>
                                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                                    <span class="svg-icon svg-icon-1">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
                                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
                                        </svg>
                                    </span>
                                </div>
                            </div>

                            <div class="modal-body scroll-y pt-10 pb-15 px-lg-17">
                                <div class="">
                                    <form class="form w-100 mb-10 form-with-otp" novalidate="novalidate" id="enableTwoStepVerificationForm">
                                        <div class="text-center mb-10">
                                            <img alt="Logo" class="mh-125px" src="<?php echo $Web->get_assets("/images/web/smartphone.svg"); ?>">
                                        </div>
                                        <div class="text-center mb-10">
                                            <h1 class="text-dark mb-3">Two Step Verification</h1>
                                        </div>

                                        <div class="overflow-auto pb-5">
                                            <div class="notice d-flex bg-light-success rounded border-success border border-dashed flex-shrink-0 p-6">
                                                <span class="justify-align-center svg-icon svg-icon-2tx svg-icon-success me-4">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path d="M13 5.91517C15.8 6.41517 18 8.81519 18 11.8152C18 12.5152 17.9 13.2152 17.6 13.9152L20.1 15.3152C20.6 15.6152 21.4 15.4152 21.6 14.8152C21.9 13.9152 22.1 12.9152 22.1 11.8152C22.1 7.01519 18.8 3.11521 14.3 2.01521C13.7 1.91521 13.1 2.31521 13.1 3.01521V5.91517H13Z" fill="black"></path>
                                                        <path opacity="0.3" d="M19.1 17.0152C19.7 17.3152 19.8 18.1152 19.3 18.5152C17.5 20.5152 14.9 21.7152 12 21.7152C9.1 21.7152 6.50001 20.5152 4.70001 18.5152C4.30001 18.0152 4.39999 17.3152 4.89999 17.0152L7.39999 15.6152C8.49999 16.9152 10.2 17.8152 12 17.8152C13.8 17.8152 15.5 17.0152 16.6 15.6152L19.1 17.0152ZM6.39999 13.9151C6.19999 13.2151 6 12.5152 6 11.8152C6 8.81517 8.2 6.41515 11 5.91515V3.01519C11 2.41519 10.4 1.91519 9.79999 2.01519C5.29999 3.01519 2 7.01517 2 11.8152C2 12.8152 2.2 13.8152 2.5 14.8152C2.7 15.4152 3.4 15.7152 4 15.3152L6.39999 13.9151Z" fill="black"></path>
                                                    </svg>
                                                </span>
                                                <div class="text-center w-100">
                                                    <h4 class="text-gray-900 fw-bolder">Enter the verification code sent to</h4>
                                                    <a id="email_sent_to" class="fs-6 text-success pe-7"></a>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="mb-10 px-md-10">
                                            <div class="fw-bolder text-start text-dark fs-6 mb-3">Type the 6 digit otp code</div>
                                            <div class="otp-form-group justify-align-center gap-2 gap-md-4">
                                                <input maxlength="1" autocomplete="off" required name="1" type="text" class="form-control no-bg h-50px w-50px fs-2 text-center" data-mask="number">
                                                <input maxlength="1" autocomplete="off" required name="2" type="text" class="form-control no-bg  h-50px w-50px fs-2 text-center " data-mask="number">
                                                <input maxlength="1" autocomplete="off" required name="3" type="text" class="form-control no-bg  h-50px w-50px fs-2 text-center " data-mask="number">
                                                <input maxlength="1" autocomplete="off" required name="4" type="text" class="form-control no-bg  h-50px w-50px fs-2 text-center " data-mask="number">
                                                <input maxlength="1" autocomplete="off" required name="5" type="text" class="form-control no-bg  h-50px w-50px fs-2 text-center " data-mask="number">
                                                <input maxlength="1" autocomplete="off" required name="6" type="text" class="form-control no-bg  h-50px w-50px fs-2 text-center " data-mask="number">
                                            </div>
                                        </div>
                                        <div class="d-flex flex-center">
                                            <button type="submit" class="w-100 btn btn-lg btn-primary fw-bolder">Submit </button>
                                        </div>
                                        <div></div>
                                    </form>
                                    <div class="text-center fw-bold fs-5">
                                        <span class="text-muted me-1">Didn’t get the code ?</span>
                                        <a id="resendOtp" class="link-primary cursor-pointer fw-bolder fs-5 me-1">Resend</a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>


                <div class="modal fade" id="editAddress" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered mw-650px">
                        <div class="modal-content">
                            <form class="form">
                                <div class="modal-header">
                                    <h2>Edit Address</h2>
                                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                                        <span class="svg-icon svg-icon-1">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                            </svg>
                                        </span>
                                    </div>
                                </div>
                                <div class="modal-body py-10 px-lg-17">
                                    <div class="scroll-y me-n7 pe-7" id="address_scroll" data-lx-scroll="true" data-lx-scroll-activate="{default: false, lg: true}" data-lx-scroll-max-height="auto" data-lx-scroll-wrappers="#address_scroll" data-lx-scroll-offset="300px">

                                    </div>
                                </div>
                                <div class="modal-footer flex-center">
                                    <button data-bs-dismiss="modal" type="button" class="btn btn-light me-3">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="addAddress" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered mw-650px">
                        <div class="modal-content">
                            <form novalidate class="form">
                                <div class="modal-header">
                                    <h2>Add New Address</h2>
                                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                                        <span class="svg-icon svg-icon-1">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                            </svg>
                                        </span>
                                    </div>
                                </div>
                                <div class="modal-body py-10 px-lg-17">
                                    <div class="scroll-y px-7" id="address_scroll" data-lx-scroll="true" data-lx-scroll-activate="{default: false, lg: true}" data-lx-scroll-max-height="auto" data-lx-scroll-wrappers="#address_scroll" data-lx-scroll-offset="300px">

                                        <div class="d-flex flex-column mb-5 fv-row">
                                            <label class="required fs-5 fw-bold mb-2">Full Name</label>
                                            <input data-max="40" required class="form-control form-control-solid" placeholder="" name="full_name" />
                                            <div class="invalid-feedback">Full Name is required</div>
                                        </div>
                                        <div class="d-flex flex-column mb-5 fv-row">
                                            <label class="required fs-5 fw-bold mb-2">Mobile Number </label>
                                            <input required class="form-control form-control-solid" placeholder="" name="mobile_number" />
                                            <div class="invalid-feedback">Mobile Number is required</div>
                                        </div>
                                        <div class="d-flex flex-column mb-5 fv-row">
                                            <label class="required fs-5 fw-bold mb-2"> Town/City </label>
                                            <input data-max="100" required class="form-control form-control-solid" placeholder="" name="city" />
                                            <div class="invalid-feedback">Town/City is required</div>
                                        </div>
                                        <div class="d-flex flex-column mb-5 fv-row">
                                            <label class="required fs-5 fw-bold mb-2">Area, Colony, Street, Sector, Village </label>
                                            <input data-max="100" required class="form-control form-control-solid" placeholder="" name="area" />
                                            <div class="invalid-feedback">Area is required</div>
                                        </div>
                                        <div class="d-flex flex-column mb-5 fv-row">
                                            <label class="fs-5 fw-bold mb-2"> Flat, House no., Building, Company, Apartment </label>
                                            <input data-max="100" class="form-control form-control-solid" placeholder="" name="flat" />
                                        </div>
                                        <div class="d-flex flex-column mb-5 fv-row">
                                            <label class="required fs-5 fw-bold mb-2"> Landmark</label>
                                            <input data-max="100" required class="form-control form-control-solid" placeholder="" name="landmark" />
                                            <div class="invalid-feedback">Landmark is required</div>
                                        </div>
                                        <div class="row g-9 mb-5">
                                            <div class="col-md-6 fv-row">
                                                <label class="required fs-5 fw-bold mb-2">State / Province</label>
                                                <input data-max="30" required class="form-control form-control-solid" placeholder="" name="state" />
                                                <div class="invalid-feedback">State is required</div>
                                            </div>
                                            <div class="col-md-6 fv-row">
                                                <label class="required fs-5 fw-bold mb-2">Post Code</label>
                                                <input maxlength="6" required class="form-control form-control-solid" placeholder="" name="postcode" />
                                                <div class="invalid-feedback">Post Code is required</div>
                                            </div>
                                        </div>
                                        <div class="fv-row">
                                            <div class="d-flex">
                                                <label class="fs-5 fw-bold"> Address Type</label>
                                                <div class="ms-4">
                                                    <div class="form-check form-check-custom form-check-solid">
                                                        <input required class="form-check-input me-1" name="address_type" type="radio" value="office" id="office">
                                                        <label class="form-check-label" for="office">
                                                            <div class="fw-bold text-gray-800">Office(Delivery between 10 AM - 5 PM)</div>
                                                        </label>
                                                    </div>
                                                    <div class="mt-4 flex-wrap form-check form-check-custom form-check-solid">
                                                        <input required class="form-check-input me-1" name="address_type" type="radio" value="home" id="home">
                                                        <label class="form-check-label" for="home">
                                                            <div class="fw-bold text-gray-800">Home(All day delivery)</div>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="invalid-feedback">Address Type is required</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer flex-center">
                                    <button data-bs-dismiss="modal" type="button" class="btn btn-light me-3">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <?php include $Web->include("partials/visitor/footer.php"); ?>


            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/datatables.bundle.js"); ?>"></script>
    <script>
        LXUtil.onDOMContentLoaded(() => {
            MyProfile.Setting()
            userLoginSessionTbl();
            MyProfile.Billing()
        });
    </script>
</body>


</html>