<?php
require_once "../db.php";

use Ecommerce\Product;

if (!isset($_GET["pid"], $_GET["vid"], $_GET["sid"])) Errors::response_404();
$product_id = $_GET["pid"];
$variation_id = $_GET["vid"];
$svariation_id = $_GET["sid"];
if (!Product::is_product_id($product_id)) Errors::response_404();
$Product = new Product($product_id);
if (!$Product->is_variation_id($variation_id)) Errors::response_404();
if (!$Product->is_svariation_id($variation_id, $svariation_id)) Errors::response_404();
$Product->updateViews($variation_id, $svariation_id);

$page = $_GET['page'] ?? 1;
$page = preg_replace('/[^0-9]/', '', $page);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Ratings & Reviews | <?php echo $Product->product_name($variation_id, $svariation_id); ?> - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/visitor/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <?php if ($Product->can_view()) { ?>
                            <div class="d-flex flex-lg-row flex-column">
                                <div class="min-w-md-400px mw-md-400px w-100 me-0 me-lg-4">
                                    <a class="d-flex card flex-md-column flex-row" href="<?php echo $Product->url($variation_id, $svariation_id); ?>">
                                        <img class="w-100px w-md-100 img-fluid" src="<?php echo $Product->image($variation_id, $svariation_id); ?>" alt="image">
                                        <div class="card-body p-4">
                                            <div class="fs-5 text-primary-alt wrap-text-1 fw-bold"><?php echo $Product->product_name($variation_id, $svariation_id); ?></div>
                                            <div class="text-primary">Jamscart</div>
                                            <div class="d-flex align-items-baseline mb-1 fw-bolder">
                                                <span class="fs-2"><?php echo $Product->formatCurrency($Product->price($variation_id, $svariation_id)); ?></span>
                                                <span class="text-gray-600 text-decoration-line-through ms-2 fs-4"><?php echo $Product->formatCurrency($Product->mrp($variation_id, $svariation_id)); ?></span>
                                                <span class="text-success ms-2"><?php echo $Product->discount($Product->mrp($variation_id, $svariation_id), $Product->price($variation_id, $svariation_id)); ?>% off</span>
                                            </div>
                                        </div>
                                    </a>

                                    <div class="card card-flush my-3">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>Customer Reviews</h2>
                                            </div>
                                            <div class="card-toolbar">
                                                <span class="text-original"><?php echo $Product->avg_rating(); ?> out of 5</span>
                                            </div>
                                        </div>
                                        <div class="card-body pt-0">

                                            <div class="align-center mb-3">
                                                <div class="rating">
                                                    <div class="rating-label me-1 checked">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 checked">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 checked">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 checked">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 checked">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <div class="h-5px mx-3 bg-light">
                                                        <div role="progressbar" style="width: <?php echo $Product->avg_rating_per(5); ?>%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" class="bg-warning rounded h-5px"></div>
                                                    </div>
                                                </div>
                                                <div class="mw-60px"><?php echo $Product->avg_rating_per(5); ?>%</div>
                                            </div>
                                            <div class="align-center mb-3">
                                                <div class="rating">
                                                    <div class="rating-label me-1 checked">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 checked">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 checked">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 checked">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 fs-4">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <div class="h-5px mx-3 bg-light">
                                                        <div role="progressbar" style="width: <?php echo $Product->avg_rating_per(4); ?>%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" class="bg-warning rounded h-5px"></div>
                                                    </div>
                                                </div>
                                                <div class="mw-60px"><?php echo $Product->avg_rating_per(4); ?>%</div>
                                            </div>
                                            <div class="align-center mb-3">
                                                <div class="rating">
                                                    <div class="rating-label me-1 checked">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 checked">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 checked">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 fs-4">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 fs-4">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <div class="h-5px mx-3 bg-light">
                                                        <div role="progressbar" style="width: <?php echo $Product->avg_rating_per(3); ?>%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" class="bg-warning rounded h-5px"></div>
                                                    </div>
                                                </div>
                                                <div class="mw-60px"><?php echo $Product->avg_rating_per(3); ?>%</div>
                                            </div>
                                            <div class="align-center mb-3">
                                                <div class="rating">
                                                    <div class="rating-label me-1 checked">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 checked">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 fs-4">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 fs-4">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 fs-4">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <div class="h-5px mx-3 bg-light">
                                                        <div role="progressbar" style="width: <?php echo $Product->avg_rating_per(2); ?>%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" class="bg-warning rounded h-5px"></div>
                                                    </div>
                                                </div>
                                                <div class="mw-60px"><?php echo $Product->avg_rating_per(2); ?>%</div>
                                            </div>
                                            <div class="align-center mb-3">
                                                <div class="rating">
                                                    <div class="rating-label me-1 checked">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 fs-4">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 fs-4">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 fs-4">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                    <div class="rating-label me-1 fs-4">
                                                        <i class="bi bi-star fs-4"></i>
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <div class="h-5px mx-3 bg-light">
                                                        <div role="progressbar" style="width: <?php echo $Product->avg_rating_per(1); ?>%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" class="bg-warning rounded h-5px"></div>
                                                    </div>
                                                </div>
                                                <div class="mw-60px"><?php echo $Product->avg_rating_per(1); ?>%</div>
                                            </div>



                                        </div>
                                    </div>

                                </div>
                                <div class="flex-grow-1">
                                    <div class="card card-flush">
                                        <div class="card-header">
                                            <div class="card-title text-muted ">
                                                <h2 class="text-dark me-2">Reviews </h2> (<span id="reviews_count" class="text-muted"><?php echo $Product->reviews_count(); ?></span>)
                                            </div>
                                            <div class="card-toolbar">
                                                <button id="askQuestion" data-bs-toggle="modal" data-bs-target="#addReviewModal" type="button" class="btn btn-flex btn-light-info">
                                                    Add review
                                                </button>
                                            </div>
                                        </div>
                                        <div class="card-body p-0">

                                            <?php if ($Product->reviews_images_cnt() > 1) {
                                            ?>
                                                <div id="reviewsImages" class="border-bottom border-top px-6 py-2 ">
                                                    <div class="mt-1 mb-2 fw-bolder">User Images <span class="text-gray-600">(<?php echo $Product->reviews_images_cnt(); ?>)</span></div>
                                                    <div class="gallery-container">
                                                        <?php echo $Product->reviews_images(); ?>
                                                    </div>
                                                </div>
                                            <?php
                                            } ?>


                                            <div id="reviews_container">

                                                <div style="padding: 40px;" class="<?php if ($Product->reviews_count() > 0) {
                                                                                        echo "d1-none";
                                                                                    } ?>  px-4 no-content-box no-review-box fs-4 text-gray-600">
                                                    <span class="svg-icon svg-icon-muted svg-icon-2hx">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                                            <path fill="" d="M4,2A2,2 0 0,0 2,4V16A2,2 0 0,0 4,18H8V21A1,1 0 0,0 9,22H9.5V22C9.75,22 10,21.9 10.2,21.71L13.9,18H20A2,2 0 0,0 22,16V4C22,2.89 21.1,2 20,2H4M4,4H20V16H13.08L10,19.08V16H4V4M12.19,5.5C11.3,5.5 10.59,5.68 10.05,6.04C9.5,6.4 9.22,7 9.27,7.69C0.21,7.69 6.57,7.69 11.24,7.69C11.24,7.41 11.34,7.2 11.5,7.06C11.7,6.92 11.92,6.85 12.19,6.85C12.5,6.85 12.77,6.93 12.95,7.11C13.13,7.28 13.22,7.5 13.22,7.8C13.22,8.08 13.14,8.33 13,8.54C12.83,8.76 12.62,8.94 12.36,9.08C11.84,9.4 11.5,9.68 11.29,9.92C11.1,10.16 11,10.5 11,11H13C13,10.72 13.05,10.5 13.14,10.32C13.23,10.15 13.4,10 13.66,9.85C14.12,9.64 14.5,9.36 14.79,9C15.08,8.63 15.23,8.24 15.23,7.8C15.23,7.1 14.96,6.54 14.42,6.12C13.88,5.71 13.13,5.5 12.19,5.5M11,12V14H13V12H11Z"></path>
                                                        </svg>
                                                    </span>
                                                    Be the first to review the product
                                                </div>
                                                <?php echo $Product->reviews($variation_id, $svariation_id, $page)->content; ?>
                                                <?php echo $Product->reviews($variation_id, $svariation_id, $page)->pagination; ?>
                                            </div>



                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php
                        } else {
                            include "partials/unavailable.php";
                        }
                        ?>

                    </div>
                </div>

                <?php include $Web->include("partials/visitor/footer.php"); ?>
            </div>
        </div>
    </div>


    <?php include $Web->include("partials/scripts.php"); ?>

    <?php if ($Product->can_view()) { ?>
        <!--  -->
        <div class="modal fade" id="previewReviewModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered  mw-1000px">
            </div>
        </div>
        <div data-id="<?php echo $product_id; ?>" id="modalAAA"></div>
        <div id="ratingLightIC" class="d-dnone"></div>
        <script src="<?php echo $Web->get_assets("js/swiper.js"); ?>"></script>
        <script src="<?php echo $Web->get_assets("js/ecommerce-product-preview.js"); ?>"></script>
        <script>
            Products.Preview.review("<?php echo $product_id; ?>");
        </script>

    <?php
    }
    ?>


</body>


</html>