<?php
require_once "../db.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title><?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
    <link rel="stylesheet" href="<?php echo $Web->get_assets("css/jquery-ui.css"); ?>">
    <link rel="stylesheet" href="<?php echo $Web->get_assets("css/swiper.css"); ?>">
    <style>
        .card-header {
            min-height: 46px !important;
        }

        .drop-inactive svg {
            transform: rotate(180deg);
        }

        .selected {
            background: #e7f0ee !important;
        }
    </style>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/visitor/header.php"); ?>

                <div style="background-color: #fff;box-shadow: 0 10px 30px 0 rgba(82, 63, 105, .05);margin-top: 2px;" class="bg-white d-lg-none fs-4 d-flex">
                    <div data-bs-toggle="modal" data-bs-target="#sort_by_modal" id="toggle_sort_by" class="w-50 cursor-pointer p-4 border-end">
                        <span class="svg-icon svg-icon-muted svg-icon-1">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 448 512">
                                <path fill="none" d="M176 352h-48V48a16 16 0 0 0-16-16H80a16 16 0 0 0-16 16v304H16c-14.19 0-21.36 17.24-11.29 27.31l80 96a16 16 0 0 0 22.62 0l80-96C197.35 369.26 190.22 352 176 352zm240-64H288a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h56l-61.26 70.45A32 32 0 0 0 272 446.37V464a16 16 0 0 0 16 16h128a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16h-56l61.26-70.45A32 32 0 0 0 432 321.63V304a16 16 0 0 0-16-16zm31.06-85.38l-59.27-160A16 16 0 0 0 372.72 32h-41.44a16 16 0 0 0-15.07 10.62l-59.27 160A16 16 0 0 0 272 224h24.83a16 16 0 0 0 15.23-11.08l4.42-12.92h71l4.41 12.92A16 16 0 0 0 407.16 224H432a16 16 0 0 0 15.06-21.38zM335.61 144L352 96l16.39 48z" />
                            </svg>
                        </span>
                        <span>Sort by</span>
                    </div>
                    <div data-bs-toggle="modal" data-bs-target="#filter_modal" id="toggle_filter" class="cursor-pointer w-50 p-4">
                        <span class="svg-icon svg-icon-muted svg-icon-1">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 512 512">
                                <path fill="none" d="M240 96h64a16 16 0 0 0 16-16V48a16 16 0 0 0-16-16h-64a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16zm0 128h128a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16H240a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16zm256 192H240a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h256a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm-256-64h192a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16H240a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16zm-64 0h-48V48a16 16 0 0 0-16-16H80a16 16 0 0 0-16 16v304H16c-14.19 0-21.37 17.24-11.29 27.31l80 96a16 16 0 0 0 22.62 0l80-96C197.35 369.26 190.22 352 176 352z" />
                            </svg>
                        </span>
                        <span>Filters</span>
                    </div>
                </div>

                <div class="p-0 pt-lg-2 d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class=" container-xxl">


                        <div id="filterRow" class="preloader-instance-lg position-relative h-100 d-flex flex-column flex-lg-row">

                            <div id="filterPreloader" class="d-none absolute-preloader p-2 p-lg-4 lg-preloader bg-white z-index-3">
                                <div class="justify-align-center flex-column gap-10">
                                    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true">
                                    </span>
                                    <div class="fs-2x">Searching Products...</div>
                                </div>
                            </div>


                            <div id="filterLeftColumn" class="flex-column d-none d-lg-flex min-w-lg-300px w-100 w-lg-300px mb-1">
                                <div class="card fs-6 text-gray-700 fw-bold card-flush ">
                                    <div class="card-header border-bottom ">
                                        <div class="card-title">
                                            <h2>Filters</h2>
                                        </div>
                                    </div>
                                    <div id="filters_container" style="user-select: none;" class="card-body p-0">
                                        <div id="filters" data-lx-swapper="true" data-lx-swapper-mode="append" data-lx-swapper-parent="{default: '#m_filter_container', lg: '#filters_container'}"></div>

                                    </div>
                                </div>
                            </div>

                            <div id="filterRightColumn" class="flex-lg-row-fluid ms-lg-1">
                                <div class="card br-0">
                                    <div id="sortInfoRow" class="p-4 pb-0 d-none d-lg-block fw-bold ">
                                        <div class="fs-5 fw-bolder search-info"> </div>
                                        <div class="align-center">
                                            <div class="fs-5 fw-bolder">Sort by</div>
                                            <div id="sort_by_container">

                                                <ul data-lx-swapper="true" data-lx-swapper-mode="append" data-lx-swapper-parent="{
                                    default: '#m_sort_by_container', lg: '#sort_by_container' }" class="nav filter-sort-by p-2 nav-tabs border-0 nav-line-tabs nav-line-tabs-2x fs-6">

                                                    <li class="nav-item">
                                                        <div data-sort="relevance" class="form-check form-check-custom form-check-solid form-check-sm">
                                                            <label class="ms-auto flex-grow-1 form-check-label" for="sort_relavance">
                                                                <a type="button" class="nav-link w-max-content text-primary-alt p-0 ms-0 me-3 active">
                                                                    Relavance </a>
                                                            </label>
                                                            <input class="form-check-input d-lg-none" checked name="sort" autocomplete="off" type="radio" value="" id="sort_relavance" />
                                                        </div>
                                                    </li>

                                                    <li class="nav-item">
                                                        <div data-sort="popularity" class="form-check form-check-custom form-check-solid form-check-sm">
                                                            <label class="ms-auto flex-grow-1 form-check-label" for="sort_popularity">
                                                                <a type="button" class="nav-link w-max-content text-primary-alt p-0 ms-0 me-3">
                                                                    Popularity </a>
                                                            </label>
                                                            <input class="form-check-input d-lg-none" name="sort" autocomplete="off" type="radio" value="" id="sort_popularity" />
                                                        </div>

                                                    </li>
                                                    <li class="nav-item">

                                                        <div data-sort="price_asc" class="form-check form-check-custom form-check-solid form-check-sm">
                                                            <label class="ms-auto flex-grow-1 form-check-label" for="sort_price_asc">
                                                                <a type="button" class="nav-link w-max-content text-primary-alt p-0 ms-0 me-3">
                                                                    Price: Low to High </a>
                                                            </label>
                                                            <input class="form-check-input d-lg-none" name="sort" autocomplete="off" type="radio" value="" id="sort_price_asc" />
                                                        </div>

                                                    </li>
                                                    <li class="nav-item">
                                                        <div data-sort="price_desc" class="form-check form-check-custom form-check-solid form-check-sm">
                                                            <label class="ms-auto flex-grow-1 form-check-label" for="sort_price_desc">
                                                                <a type="button" class="nav-link w-max-content text-primary-alt p-0 ms-0 me-3">
                                                                    Price: High to Low </a>
                                                            </label>
                                                            <input class="form-check-input d-lg-none" name="sort" autocomplete="off" type="radio" value="" id="sort_price_desc" />
                                                        </div>

                                                    </li>
                                                    <li class="nav-item">

                                                        <div data-sort="newest" class="form-check form-check-custom form-check-solid form-check-sm">
                                                            <label class="ms-auto flex-grow-1 form-check-label" for="sort_new">
                                                                <a type="button" class="nav-link w-max-content text-primary-alt p-0 ms-0 me-3">
                                                                    Newest First </a>
                                                            </label>
                                                            <input class="form-check-input d-lg-none" name="sort" autocomplete="off" type="radio" value="" id="sort_new" />
                                                        </div>

                                                    </li>
                                                </ul>


                                            </div>
                                        </div>
                                    </div>
                                    <div id="productsContainer" class="row g-1">

                                    </div>
                                    <div id="pagination">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php include $Web->include("partials/visitor/footer.php"); ?>
            </div>
        </div>
    </div>


    <div class="modal fade" tabindex="-1" id="sort_by_modal">
        <div class="modal-dialog mw-100  modal-dialog-bottom">
            <div class="modal-content">
                <div class="modal-header px-4 py-3">
                    <h5 class="modal-title fs-2x">Sort By</h5>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2" data-bs-dismiss="modal" aria-label="Close">
                        <span class="svg-icon svg-icon-2x">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
                            </svg>
                        </span>
                    </div>
                </div>

                <div id="m_sort_by_container" class="p-0 scroll-y modal-body">

                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" tabindex="-1" id="filter_modal">
        <div class="modal-dialog mw-100 modal-dialog-bottom">
            <div class="modal-content">
                <div class="modal-header px-4 py-3">
                    <h5 class="modal-title fs-2x">Filter</h5>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2" data-bs-dismiss="modal" aria-label="Close">
                        <span class="svg-icon svg-icon-2x">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
                            </svg>
                        </span>
                    </div>
                </div>

                <div id="m_filter_container" class="p-0 scroll-y modal-body">

                </div>
                <div class="modal-footer justify-content-start py-0 px-2">
                    <div class="fs-7 d-flex flex-column">
                        <div id="searchResultCnt" class="fs-7 text-dark"></div>
                        <div class="fs-7">products found</div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/swiper.js"); ?>"></script>
    <script src="<?php echo $Web->get_assets("js/jquery-ui.js"); ?>"></script>
    <script>
        searchProducts.init();
    </script>


</body>


</html>