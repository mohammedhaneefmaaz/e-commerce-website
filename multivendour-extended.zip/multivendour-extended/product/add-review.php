<?php
require_once "../db.php";
$Login->check_user_login();

use Ecommerce\Product;
use Ecommerce\Review;

if (!isset($_GET["pid"], $_GET["vid"], $_GET["sid"])) Errors::response_404();
$product_id = $_GET["pid"];
$variation_id = $_GET["vid"];
$svariation_id = $_GET["sid"];
if (!Product::is_product_id($product_id)) Errors::response_404();
$Product = new Product($product_id);
if (!$Product->is_variation_id($variation_id)) Errors::response_404();
if (!$Product->is_svariation_id($variation_id, $svariation_id)) Errors::response_404();

$event = "create";
$review_id = 0;

if ($Product->has_user_reviewed($LogUser->user_id)) {
    $review_id = $Product->user_reviewed_id($LogUser->user_id);
    $event = "update";
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>Ratings & Reviews | <?php echo $Product->product_name($variation_id, $svariation_id); ?> - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/visitor/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <?php if ($Product->can_view()) {

                            if (!$Product->has_user_purchased_product($LogUser->user_id)) { ?>
                                <div class="alert bg-light-danger align-center p-5 mb-5">
                                    <span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black" />
                                            <rect x="7" y="15.3137" width="12" height="2" rx="1" transform="rotate(-45 7 15.3137)" fill="black" />
                                            <rect x="8.41422" y="7" width="12" height="2" rx="1" transform="rotate(45 8.41422 7)" fill="black" />
                                        </svg>
                                    </span>
                                    <div class="ms-4 d-flex flex-column pe-0 pe-sm-10">
                                        <h4 class="fw-bold">Haven't purchased this product?</h4>
                                        <span>Sorry! You are not allowed to review this product since you haven't purchased it.</span>
                                    </div>
                                </div>
                            <?php } ?>

                            <div class="d-flex flex-lg-row flex-column">
                                <div class="min-w-md-400px mw-md-400px w-100 me-0 me-lg-4">
                                    <a class="d-flex card mb-2 flex-md-column flex-row" href="<?php echo $Product->url($variation_id, $svariation_id); ?>">
                                        <img class="w-100px w-md-100 img-fluid" src="<?php echo $Product->image($variation_id, $svariation_id); ?>" alt="image">
                                        <div class="card-body p-4">
                                            <div class="fs-5 text-primary-alt wrap-text-1 fw-bold"><?php echo $Product->product_name($variation_id, $svariation_id); ?></div>
                                            <div class="text-primary">Jamscart</div>
                                            <div class="d-flex align-items-baseline mb-1 fw-bolder">
                                                <span class="fs-2"><?php echo $Product->formatCurrency($Product->price($variation_id, $svariation_id)); ?></span>
                                                <span class="text-gray-600 text-decoration-line-through ms-2 fs-4"><?php echo $Product->formatCurrency($Product->mrp($variation_id, $svariation_id)); ?></span>
                                                <span class="text-success ms-2"><?php echo $Product->discount($Product->mrp($variation_id, $svariation_id), $Product->price($variation_id, $svariation_id)); ?>% off</span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="flex-grow-1">

                                    <div class="card mb-4">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>Rating & Review</h2>
                                            </div>
                                        </div>
                                        <div class="card-body">


                                            <!--end::Alert-->
                                            <form class="form w-100" novalidate="novalidate" id="review_form">
                                                <?php if ($Product->has_user_reviewed($LogUser->user_id)) {
                                                    $Review = new Review($product_id, $review_id);
                                                ?>
                                                    <div class="fv-row mb-4">
                                                        <label class="form-label fs-6 fw-bolder">Rating</label>
                                                        <div class="mb-2 rating"><?php echo $Review->review_star("fs-2x"); ?></div>
                                                        <input required autocomplete="off" name="rating" type="hidden" value="<?php echo $Review->rating(); ?>">
                                                        <div class="invalid-feedback">Rating is required</div>
                                                    </div>
                                                    <div class="fv-row">
                                                        <label class="form-label fs-6 fw-bolder">Review</label>
                                                        <textarea required maxlength="3000" rows="7" class="form-control" name="review"><?php echo $Review->review(); ?></textarea>
                                                        <div class="invalid-feedback">Review is required</div>
                                                    </div>
                                                    <div class="fv-row my-4">
                                                        <label class="form-label fs-6 fw-bolder">Add Images</label>
                                                        <div id="imgsWrapper" class="d-flex">
                                                            <?php echo $Review->edit_images_form(); ?>
                                                        </div>
                                                    </div>
                                                <?php
                                                } else {
                                                ?>
                                                    <div class="fv-row mb-7">
                                                        <label class="form-label fs-6 fw-bolder">Rating</label>
                                                        <div class="mb-2 rating">
                                                            <div class="cursor-pointer rating-label">
                                                                <i class="bi bi-star me-1 fs-2x"></i>
                                                            </div>
                                                            <div class="cursor-pointer rating-label">
                                                                <i class="bi bi-star me-1 fs-2x"></i>
                                                            </div>
                                                            <div class="cursor-pointer rating-label">
                                                                <i class="bi bi-star me-1 fs-2x"></i>
                                                            </div>
                                                            <div class="cursor-pointer rating-label">
                                                                <i class="bi bi-star me-1 fs-2x"></i>
                                                            </div>
                                                            <div class="cursor-pointer rating-label">
                                                                <i class="bi bi-star me-1 fs-2x"></i>
                                                            </div>
                                                        </div>
                                                        <input required autocomplete="off" name="rating" type="hidden" value="">
                                                        <div class="invalid-feedback">Rating is required</div>
                                                    </div>
                                                    <div class="fv-row mb-7">
                                                        <label class="form-label fs-6 fw-bolder">Review</label>
                                                        <textarea required maxlength="3000" rows="7" class="form-control form-control" name="review"></textarea>
                                                        <div class="invalid-feedback">Review is required</div>
                                                    </div>
                                                    <div class="fv-row mb-7">
                                                        <label class="form-label fs-6 fw-bolder">Add Images</label>
                                                        <div id="imgsWrapper" class="d-flex">

                                                            <div class="w-50px h-50px me-3 opacity-100-hover review-img-upload" id="uploadImg">
                                                                <span>+</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php
                                                } ?>

                                                <div class="separator separator-dashed my-4"></div>
                                                <div class="justify-right">
                                                    <button <?php if (!$Product->has_user_purchased_product($LogUser->user_id)) {
                                                                echo "disabled";
                                                            } ?> autocomplete="off" type="submit" id="btn_submit" class="ms-4 btn btn-lg btn-primary">Submit Review</button>
                                                </div>
                                            </form>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        <?php
                        }else{
                            include "partials/unavailable.php";
                        }
                        ?>

                    </div>
                </div>
                <?php include $Web->include("partials/visitor/footer.php"); ?>
            </div>
        </div>
    </div>

    <?php include $Web->include("partials/scripts.php"); ?>

    <?php if ($Product->can_view()) {
    ?>
        <script>
            Products.Preview.addReview({
                product_id: '<?php echo $product_id; ?>',
                variation_id: '<?php echo $variation_id; ?>',
                svariation_id: '<?php echo $svariation_id; ?>',
                event: '<?php echo $event; ?>',
                review_id: '<?php echo $review_id; ?>',
                images: '<?php echo isset($Review) ? json_encode($Review->images()) : ""; ?>'
            });
        </script>
    <?php
    }
    ?>

</body>


</html>