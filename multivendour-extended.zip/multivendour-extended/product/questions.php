<?php
require_once "../db.php";

use Ecommerce\Product;

if (!isset($_GET["pid"], $_GET["vid"], $_GET["sid"])) Errors::response_404();
$product_id = $_GET["pid"];
$variation_id = $_GET["vid"];
$svariation_id = $_GET["sid"];
if (!Product::is_product_id($product_id)) Errors::response_404();
$Product = new Product($product_id);
if (!$Product->is_variation_id($variation_id)) Errors::response_404();
if (!$Product->is_svariation_id($variation_id, $svariation_id)) Errors::response_404();
$Product->updateViews($variation_id, $svariation_id);

$page = $_GET['page'] ?? 1;
$page = preg_replace('/[^0-9]/', '', $page);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Questions & Answers | <?php echo $Product->product_name($variation_id, $svariation_id); ?> - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/visitor/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <?php if ($Product->can_view()) { ?>
                            <div class="d-flex flex-lg-row flex-column">
                                <div class="mw-md-400px min-w-md-400px w-100 me-0 mb-4 me-lg-4">
                                    <a class="d-flex card flex-md-column flex-row" href="<?php echo $Product->url($variation_id, $svariation_id); ?>">
                                        <img class="w-100px w-md-100 img-fluid" src="<?php echo $Product->image($variation_id, $svariation_id); ?>" alt="image">
                                        <div class="card-body p-4">
                                            <div class="fs-5 text-primary-alt wrap-text-1 fw-bold"><?php echo $Product->product_name($variation_id, $svariation_id); ?></div>
                                            <div class="text-primary">Jamscart</div>
                                            <div class="d-flex align-items-baseline mb-1 fw-bolder">
                                                <span class="fs-2"><?php echo $Product->formatCurrency($Product->price($variation_id, $svariation_id)); ?></span>
                                                <span class="text-gray-600 text-decoration-line-through ms-2 fs-4"><?php echo $Product->formatCurrency($Product->mrp($variation_id, $svariation_id)); ?></span>
                                                <span class="text-success ms-2"><?php echo $Product->discount($Product->mrp($variation_id, $svariation_id), $Product->price($variation_id, $svariation_id)); ?>% off</span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="flex-grow-1">
                                    <div class="card card-flush mb-3">
                                        <div class="card-header">
                                            <div class="text-muted card-title">
                                                <h2 class="text-dark me-2">Questions & Answers</h2> (<span id="qa_cnt"><?php echo $Product->questions_count(); ?></span>)
                                            </div>
                                        </div>
                                        <div id="questionsWrapper" class="card-body p-0">
                                            <?php echo $Product->all_questions($variation_id, $svariation_id, $page)->content; ?>
                                            <?php echo $Product->all_questions($variation_id, $svariation_id, $page)->pagination; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php
                        } else {
                            include "partials/unavailable.php";
                        }
                        ?>

                    </div>
                </div>
                <?php include $Web->include("partials/visitor/footer.php"); ?>
            </div>
        </div>
    </div>

    <?php include $Web->include("partials/scripts.php"); ?>

    <?php if ($Product->can_view()) { ?>
        <!--  -->
        <div class="modal fade" id="askQuestionModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Ask a question</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y">
                        <form id="ask_ques">
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Question</label>
                                <textarea required rows="5" type="text" class="form-control" name="question" value=""></textarea>
                                <div class="invalid-feedback">Question is required</div>
                            </div>

                            <div class="justify-right">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--  -->
        <div class="modal fade" id="editQuestionModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Edit question</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y">

                    </div>
                </div>
            </div>
        </div>
        <!--  -->
        <div class="modal fade" id="addAnsModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Add an answer</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y">

                    </div>
                </div>
            </div>
        </div>
        <!--  -->
        <div class="modal fade" id="viewAnsModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">All Answers</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y"></div>
                </div>
            </div>
        </div>
        <!--  -->
        <script>
            Products.Preview.q_a("<?php echo $product_id; ?>");
        </script>
    <?php
    }
    ?>

</body>


</html>