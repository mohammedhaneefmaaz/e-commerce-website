<?php
require_once "../db.php";
if (!isset($_GET["pid"], $_GET["vid"], $_GET["sid"])) Errors::response_404();
$product_id = $_GET["pid"];
$variation_id = $_GET["vid"];
$svariation_id = $_GET["sid"];

use Ecommerce\Product;
use Ecommerce\Category;

if (!Product::is_product_id($product_id)) Errors::response_404();
$Product = new Product($product_id);
if (!$Product->is_variation_id($variation_id)) Errors::response_404();
if (!$Product->is_svariation_id($variation_id, $svariation_id)) Errors::response_404();


$arguments = array(
    "product_id" => $product_id,
    "variation_id" => $variation_id,
    "svariation_id" => $svariation_id,
    "status" =>  $Product->status_text($variation_id, $svariation_id)->type == "success" ? "active" : "inactive"
);
$arguments = json_encode($arguments);

$Product->updateViews($variation_id, $svariation_id);

if (isset($_GET["src"]) && !empty($_GET["src"])) {
    $src = $_GET["src"];
    $Product->update_search_relevance($variation_id, $src);
}

$Category = new Category($Product->category_id());

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title><?php echo $Product->product_name($variation_id, $svariation_id); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
    <link rel="stylesheet" href="<?php echo $Web->get_assets("css/ecommerce-product-preview.css"); ?>">
    <link rel="stylesheet" href="<?php echo $Web->get_assets("css/swiper.css"); ?>">
    <style>
        .card:not(.rounded) {
            border-radius: 0px !important;
            border: 1px solid #eef5f9;
            margin: 0 !important;
            padding: 0 !important;

        }

        .MagicZoom>img,
        .mz-figure>img {
            width: auto;
            height: auto;
            max-height: 100%;
        }
    </style>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/visitor/header.php"); ?>

                <div class="d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">
                        <?php if ($Product->can_view()) {
                            include "partials/content.php";
                            include "partials/extra-content.php";
                            include "partials/modals.php";
                        } else {
                            include "partials/unavailable.php";
                        }
                        ?>
                    </div>
                </div>


                <div id="ratingLightIC" class="d-dnone"></div>

                <?php include $Web->include("partials/visitor/footer.php"); ?>
            </div>
        </div>


    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <?php if ($Product->can_view()) {
    ?>
        <script src="<?php echo $Web->get_assets("js/swiper.js"); ?>"></script>
        <script src="<?php echo $Web->get_assets("js/ecommerce-product-preview.js"); ?>"></script>
        <script>
            Products.Preview.init(<?php echo $arguments; ?>);
        </script>
    <?php
    }
    ?>



</body>


</html>