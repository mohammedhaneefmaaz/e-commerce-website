<div class="h-100 px-6 bg-white justify-align-center text-center flex-column ">
    <video class="mw-100" loading="lazy" muted="muted" src="<?php echo $Web->get_assets("videos/recycle-bin-5096906-4263422.mp4"); ?>" type="video/mp4" autoplay="autoplay" loop="loop"></video>
    <h1 class="fs-3x">Product removed</h1>
    <p>This product has been removed from <?php echo $Web->web_name(); ?> and is no longer available. </p>
</div>