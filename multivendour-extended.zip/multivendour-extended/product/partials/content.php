 <?php

    use Ecommerce\Cart;

    ?>

 <div class="d-none d-lg-block"><?php echo $Category->breadcrumb($Product->product_name($variation_id, $svariation_id)); ?></div>

 <div class="d-flex flex-column flex-lg-row">
     <div class="mw-lg-700px min-w-lg-500px">
         <div class=" card mb-3">
             <div class="card-bod p-2 pb-md-2 pb-0">

                 <div class="wishlist" id="addToWishlist">
                     <?php if ($Login->is_user_loggedin()) {
                            echo Cart::is_product_in_wishlist($product_id, $variation_id, $svariation_id, $LogUser->user_id) ? '<i class="fas fa-heart text-danger"></i>' : '<i class="fal fa-heart text-dark"></i>';
                        } else {
                            echo '<i class="fal fa-heart text-dark"></i>';
                        } ?>
                 </div>

                 <div class="d-flex h-md-450px flex-column-reverse flex-md-row">
                     <div class="w-100 w-md-80px mx-md-2">
                         <div data-options="orientation:vertical;height:450px;width:80px;arrows: outside;loop:false;" class="MagicScroll">
                             <?php echo $Product->sm_zoom_images($variation_id, $svariation_id); ?>
                         </div>
                     </div>

                     <div class="justify-align-center h-md-450px h-auto flex-grow-1">
                         <div class="MagicZoom h-100 justify-align-center w-100" id="product_slider" data-options="history: false;rightClick:true;selectorTrigger:hover;variableZoom: true;expandZoomMode: magnifier;cssClass: dark-bg;cssClass: mz-square;" href="<?php echo $Product->image($variation_id, $svariation_id); ?>">
                             <img src="<?php echo $Product->image($variation_id, $svariation_id); ?>" />
                         </div>
                     </div>
                 </div>
             </div>
         </div>

         <div id="default_reviews_analysis_container"></div>
         <!--  -->
         <div data-lx-swapper="true" data-lx-swapper-mode="append" data-lx-swapper-parent="{
                                        default: '#m_reviews_analysis_container', lg: '#default_reviews_analysis_container'}" class="card card-flush mb-3">
             <div class="card-header">
                 <div class="card-title">
                     <h2>Customer Reviews</h2>
                 </div>
                 <div class="card-toolbar">
                     <span class="text-original"><?php echo $Product->avg_rating(); ?> out of 5</span>
                 </div>
             </div>
             <div class="card-body pt-0">

                 <div class="align-center mb-3">
                     <div class="rating">
                         <div class="rating-label me-1 checked">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 checked">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 checked">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 checked">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 checked">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                     </div>
                     <div class="flex-grow-1">
                         <div class="h-5px mx-3 bg-light">
                             <div role="progressbar" style="width: <?php echo $Product->avg_rating_per(5); ?>%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" class="bg-warning rounded h-5px"></div>
                         </div>
                     </div>
                     <div class="mw-60px"><?php echo $Product->avg_rating_per(5); ?>%</div>
                 </div>
                 <div class="align-center mb-3">
                     <div class="rating">
                         <div class="rating-label me-1 checked">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 checked">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 checked">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 checked">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 fs-4">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                     </div>
                     <div class="flex-grow-1">
                         <div class="h-5px mx-3 bg-light">
                             <div role="progressbar" style="width: <?php echo $Product->avg_rating_per(4); ?>%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" class="bg-warning rounded h-5px"></div>
                         </div>
                     </div>
                     <div class="mw-60px"><?php echo $Product->avg_rating_per(4); ?>%</div>
                 </div>
                 <div class="align-center mb-3">
                     <div class="rating">
                         <div class="rating-label me-1 checked">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 checked">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 checked">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 fs-4">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 fs-4">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                     </div>
                     <div class="flex-grow-1">
                         <div class="h-5px mx-3 bg-light">
                             <div role="progressbar" style="width: <?php echo $Product->avg_rating_per(3); ?>%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" class="bg-warning rounded h-5px"></div>
                         </div>
                     </div>
                     <div class="mw-60px"><?php echo $Product->avg_rating_per(3); ?>%</div>
                 </div>
                 <div class="align-center mb-3">
                     <div class="rating">
                         <div class="rating-label me-1 checked">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 checked">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 fs-4">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 fs-4">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 fs-4">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                     </div>
                     <div class="flex-grow-1">
                         <div class="h-5px mx-3 bg-light">
                             <div role="progressbar" style="width: <?php echo $Product->avg_rating_per(2); ?>%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" class="bg-warning rounded h-5px"></div>
                         </div>
                     </div>
                     <div class="mw-60px"><?php echo $Product->avg_rating_per(2); ?>%</div>
                 </div>
                 <div class="align-center mb-3">
                     <div class="rating">
                         <div class="rating-label me-1 checked">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 fs-4">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 fs-4">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 fs-4">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                         <div class="rating-label me-1 fs-4">
                             <i class="bi bi-star fs-4"></i>
                         </div>
                     </div>
                     <div class="flex-grow-1">
                         <div class="h-5px mx-3 bg-light">
                             <div role="progressbar" style="width: <?php echo $Product->avg_rating_per(1); ?>%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" class="bg-warning rounded h-5px"></div>
                         </div>
                     </div>
                     <div class="mw-60px"><?php echo $Product->avg_rating_per(1); ?>%</div>
                 </div>
             </div>
         </div>

     </div>
     <div class="flex-grow-1">

         <div class="card word-break mb-3 br-4">
             <div class="card-body">

                 <div class="fw-bolder mb-2 fs-3"><?php echo $Product->product_name($variation_id, $svariation_id); ?></div>

                 <div class="d-flex align-items-baseline mb-1 fw-bolder">
                     <span class="fs-3"><?php echo $Product->price_text($variation_id, $svariation_id); ?></span>
                     <span class="text-gray-600 text-decoration-line-through ms-2 fs-4"><?php echo $Product->mrp_text($variation_id, $svariation_id); ?></span>
                     <span class="text-success ms-2"><?php echo $Product->discount($Product->mrp($variation_id, $svariation_id), $Product->price($variation_id, $svariation_id)); ?>% off</span>
                 </div>

                 <?php
                    $status_text = $Product->status_text($variation_id, $svariation_id);
                    switch ($status_text->code) {

                        case "danger":
                    ?>
                         <div class="fs-7 text-<?php echo $status_text->code; ?>">This product is currently unavailable</div>
                     <?php
                            break;
                        case "warning":
                        ?>
                         <div class="fs-7 text-<?php echo $status_text->code; ?>"><?php echo $status_text->text; ?></div>
                 <?php
                            break;
                    }
                    ?>

                 <div class="d-flex mb-4 d-flex align-items-center  ">
                     <div class="jstars" data-value="<?php echo $Product->avg_rating(); ?>" data-color="#ffbc34" data-empty-color="#b5b5c3" data-size="25px"></div>
                     <span class="ms-2 text-gray-400"><?php echo $Product->rating_count(); ?> ratings and <?php echo $Product->reviews_count(); ?> reviews</span>
                 </div>

                 <?php

                    if (!empty($Product->variations_card($variation_id, $svariation_id))) {
                    ?> <div>
                         <?php echo $Product->variations_card($variation_id, $svariation_id); ?>
                     </div>
                 <?php
                    }

                    if (!empty($Product->svariations_card($variation_id, $svariation_id))) {
                    ?> <div>
                         <?php echo $Product->svariations_card($variation_id, $svariation_id); ?>
                     </div>
                 <?php
                    }
                    ?>

                 <div class="mb-4">
                     <?php if ($Product->return_policy($variation_id, $svariation_id) !== "no") { ?>
                         <div class="align-center"><span class="fw-bolder"> Returns & Exchanges:</span>
                             <div class="ms-2 text-gray-400 fw-bold"><?php echo $Product->return_policy_days($variation_id, $svariation_id); ?> days return policy</div> <i data-bs-toggle="modal" data-bs-target="#return_policy_modal" class="fas fa-exclamation-circle ms-2 fs-7"></i>
                         </div>
                     <?php } else {
                        ?>
                         <div class="align-center">
                             <span class="svg-icon svg-icon-muted svg-icon-2hx">
                                 <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                     <path d="M17.4 7H4C3.4 7 3 7.4 3 8C3 8.6 3.4 9 4 9H17.4V7ZM6.60001 15H20C20.6 15 21 15.4 21 16C21 16.6 20.6 17 20 17H6.60001V15Z" fill="currentColor" />
                                     <path opacity="0.3" d="M17.4 3V13L21.7 8.70001C22.1 8.30001 22.1 7.69999 21.7 7.29999L17.4 3ZM6.6 11V21L2.3 16.7C1.9 16.3 1.9 15.7 2.3 15.3L6.6 11Z" fill="currentColor" />
                                 </svg>
                             </span>
                             <div class="ms-2">No Returns Applicable</div> <i data-bs-toggle="modal" data-bs-target="#return_policy_modal" class="fas fa-exclamation-circle ms-2 fs-7"></i>
                         </div>
                     <?php
                        } ?>
                 </div>

                 <div class="mb-3">
                     <div class="d-flex mb-1">
                         <span class="fw-bolder">Seller: </span>
                         <a href="#!" class="fw-bolder ms-2"><?php echo $Product->seller()->store_name(); ?></a>
                     </div>
                 </div>

                 <?php if ($Product->is_cod_available($variation_id, $svariation_id)) {
                    ?> <div class="fs-7 mb-3 text-success">
                         <span class="svg-icon svg-icon-success svg-icon-2x">
                             <svg style="fill:#36bea6;" height="512" viewBox="0 0 64 64" width="512" xmlns="http://www.w3.org/2000/svg">
                                 <g>
                                     <path d="m2 55h60v2h-60z" />
                                     <path d="m20 11h12v2h-12z" />
                                     <path d="m16 7h12v2h-12z" />
                                     <path d="m12 7h2v2h-2z" />
                                     <path d="m55 28a1 1 0 0 0 -1-1h-3v8h4z" />
                                     <path d="m24.9 49h17.1v-6h-38v6h2.1a4.988 4.988 0 0 1 9.4-1.14 4.988 4.988 0 0 1 9.4 1.14z" />
                                     <path d="m20 47a3 3 0 1 0 3 3 3.009 3.009 0 0 0 -3-3zm1 4h-2v-2h2z" />
                                     <path d="m53 47a3 3 0 1 0 3 3 3.009 3.009 0 0 0 -3-3zm1 4h-2v-2h2z" />
                                     <path d="m58 42h2v2h-2z" />
                                     <path d="m60 39.58-4.5-2.57a.01.01 0 0 0 -.01-.01h-5.49a1 1 0 0 1 -1-1v-9h-5v22h4.1a5 5 0 0 1 9.8 0h2.1v-3h-3a1 1 0 0 1 -1-1v-4a1 1 0 0 1 1-1h3zm-6 1.42h-4v-2h4z" />
                                     <path d="m11 47a3 3 0 1 0 3 3 3.009 3.009 0 0 0 -3-3zm1 4h-2v-2h2z" />
                                     <path d="m42 17h-38v24h38zm-29 15h1a1 1 0 0 0 1-1h2a3.009 3.009 0 0 1 -3 3h-1a3.009 3.009 0 0 1 -3-3v-4a3.009 3.009 0 0 1 3-3h1a3.009 3.009 0 0 1 3 3h-2a1 1 0 0 0 -1-1h-1a1 1 0 0 0 -1 1v4a1 1 0 0 0 1 1zm13-1a3.009 3.009 0 0 1 -3 3h-1a3.009 3.009 0 0 1 -3-3v-4a3.009 3.009 0 0 1 3-3h1a3.009 3.009 0 0 1 3 3zm9 0a3.009 3.009 0 0 1 -3 3h-3a1 1 0 0 1 -1-1v-8a1 1 0 0 1 1-1h3a3.009 3.009 0 0 1 3 3z" />
                                     <path d="m32 26h-2v6h2a1 1 0 0 0 1-1v-4a1 1 0 0 0 -1-1z" />
                                     <rect height="6" rx="1" width="3" x="21" y="26" />
                                 </g>
                             </svg>
                         </span>
                         Cash on delivery is available
                     </div>
                 <?php
                    }
                    if ($status_text->type === "success") {
                    ?>
                     <div id="buyWrapper" class="d-flex flex-column flex-lg-row">
                         <div class="position-relative d-none d-lg-block align-center mb-4 w-md-200px" data-min="<?php echo $Product->minimum_order($variation_id, $svariation_id); ?>" data-max="<?php echo $Product->maximum_order($variation_id, $svariation_id); ?>" id="change_quantity">
                             <button type="button" class="btn btn-icon btn-active-color-gray-700 position-absolute translate-middle-y top-50 start-0" data-lx-dialer-control="decrease">
                                 <span class="svg-icon svg-icon-1">
                                     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                         <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5" fill="currentColor"></rect>
                                         <rect x="6.0104" y="10.9247" width="12" height="2" rx="1" fill="currentColor"></rect>
                                     </svg>
                                 </span>
                             </button>
                             <input autocomplete="off" type="text" class="form-control form-control-solid border-0 ps-12" data-lx-dialer-control="input" />
                             <button type="button" class="btn btn-icon btn-active-color-gray-700 position-absolute translate-middle-y top-50 end-0" data-lx-dialer-control="increase">
                                 <span class="svg-icon svg-icon-1">
                                     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                         <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5" fill="currentColor"></rect>
                                         <rect x="10.8891" y="17.8033" width="12" height="2" rx="1" transform="rotate(-90 10.8891 17.8033)" fill="currentColor"></rect>
                                         <rect x="6.01041" y="10.9247" width="12" height="2" rx="1" fill="currentColor"></rect>
                                     </svg>
                                 </span>
                             </button>
                         </div>
                         <div class="flex-grow-1 ms-0 ms-md-2 d-md-flex">

                             <?php if ($Login->is_user_loggedin()) {
                                    $add_class =  Cart::is_product_in_cart($product_id, $variation_id, $svariation_id, $LogUser->user_id) ? 'd1-none' : '';
                                    $view_class =  Cart::is_product_in_cart($product_id, $variation_id, $svariation_id, $LogUser->user_id) ? '' : 'd1-none';
                                } else {
                                    $add_class = "";
                                    $view_class = "d1-none";
                                } ?>

                             <button id="addToCart" class="<?php echo $add_class; ?> btn w-md-50 w-100 btn-lg btn-outline btn-outline-warning btn-rounded btn-active-light-warning mb-4">Add to cart</button>
                             <a href="<?php echo $Web->base_url(); ?>/cart/" id="viewCart" class="<?php echo $view_class; ?> btn text-warning w-md-50 w-100 btn-lg btn-outline btn-outline-warning btn-rounded btn-active-light-warning mb-4">View cart</a>
                             <button id="buyNow" class="btn ms-0 ms-md-2 w-md-50 w-100 btn-lg btn-outline  btn-rounded btn-outline-primary btn-active-light-primary mb-4">Buy Now</button>
                         </div>
                     </div>
                 <?php } ?>

                 <!-- <div class="d-flex">
                     <button class="btn-active-color-primary btn-text-muted btn">
                         <i class="fa-heart fs-3 fal"></i>
                         <span>Wishlist</span>
                     </button>
                     <button class="btn-active-color-primary btn-text-muted btn">
                         <i class="fonticon-share fs-2"></i>
                         <span>Share</span>
                     </button>
                 </div> -->

             </div>


         </div>
         <!--  -->


         <!--  -->
         <?php if (!empty($Product->highlights_card($variation_id, $svariation_id))) {
            ?>
             <div class="card word-break card-flush mb-3 br-4">
                 <div class="card-header collapsible cursor-pointer rotate" data-bs-toggle="collapse" data-bs-target="#highlights">
                     <div class="card-title">
                         <h2>Highlights</h2>
                     </div>
                     <div class="card-toolbar rotate-180">
                         <span class="svg-icon svg-icon-1">
                             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                 <rect opacity="0.5" x="11" y="18" width="13" height="2" rx="1" transform="rotate(-90 11 18)" fill="black"></rect>
                                 <path d="M11.4343 15.4343L7.25 11.25C6.83579 10.8358 6.16421 10.8358 5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75L11.2929 18.2929C11.6834 18.6834 12.3166 18.6834 12.7071 18.2929L18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25C17.8358 10.8358 17.1642 10.8358 16.75 11.25L12.5657 15.4343C12.2533 15.7467 11.7467 15.7467 11.4343 15.4343Z" fill="black"></path>
                             </svg>
                         </span>
                     </div>
                 </div>
                 <div class="collapse show" id="highlights">
                     <div class="card-body fs-14px fw-bolder pt-0">
                         <?php echo $Product->highlights_card($variation_id, $svariation_id); ?>
                     </div>
                 </div>
             </div>
         <?php
            } ?>
         <!--  -->


         <!--  -->

         <?php if (!empty($Product->description($variation_id, $svariation_id))) {
            ?>
             <div class="card card-flush mb-3 br-4">
                 <div class="card-header collapsible cursor-pointer rotate collapsed" data-bs-toggle="collapse" data-bs-target="#description">
                     <div class="card-title">
                         <h2>Discription</h2>
                     </div>
                     <div class="card-toolbar rotate-180">
                         <span class="svg-icon svg-icon-1">
                             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                 <rect opacity="0.5" x="11" y="18" width="13" height="2" rx="1" transform="rotate(-90 11 18)" fill="black"></rect>
                                 <path d="M11.4343 15.4343L7.25 11.25C6.83579 10.8358 6.16421 10.8358 5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75L11.2929 18.2929C11.6834 18.6834 12.3166 18.6834 12.7071 18.2929L18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25C17.8358 10.8358 17.1642 10.8358 16.75 11.25L12.5657 15.4343C12.2533 15.7467 11.7467 15.7467 11.4343 15.4343Z" fill="black"></path>
                             </svg>
                         </span>
                     </div>
                 </div>
                 <div class="collapse" id="description">
                     <div class="card-body fw-bolder pt-0">
                         <div class="pre-wrap fs-5 fw-bold text-gray-600" style="word-break: break-all;"><?php echo $Product->description($variation_id, $svariation_id); ?></div>
                     </div>
                 </div>
             </div>
         <?php
            } ?>
         <!--  -->


         <!--  -->
         <div class="card card-flush mb-3 br-4">
             <div class="card-header collapsible cursor-pointer rotate" data-bs-toggle="collapse" data-bs-target="#details">
                 <div class="card-title">
                     <h2>Product Details</h2>
                 </div>
                 <div class="card-toolbar rotate-180">
                     <span class="svg-icon svg-icon-1">
                         <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                             <rect opacity="0.5" x="11" y="18" width="13" height="2" rx="1" transform="rotate(-90 11 18)" fill="black"></rect>
                             <path d="M11.4343 15.4343L7.25 11.25C6.83579 10.8358 6.16421 10.8358 5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75L11.2929 18.2929C11.6834 18.6834 12.3166 18.6834 12.7071 18.2929L18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25C17.8358 10.8358 17.1642 10.8358 16.75 11.25L12.5657 15.4343C12.2533 15.7467 11.7467 15.7467 11.4343 15.4343Z" fill="black"></path>
                         </svg>
                     </span>
                 </div>
             </div>
             <div class="collapse show" id="details">
                 <div class="card-body fs-14px fw-bold pt-0">
                     <?php echo $Product->details_card($variation_id, $svariation_id); ?>
                 </div>
             </div>
         </div>
         <!--  -->
         <div class="card mb-3">
             <div class="card-body">
                 <div class="d-flex align-items-md-center flex-column flex-lg-row">
                     <div class="flex-grow-1 fs-3 fw-bolder">Didn't get the right answer you are looking for?</div>
                     <button id="askQuestion" data-bs-toggle="modal" data-bs-target="#askQuestionModal" type="button" class="btn mt-4 mt-md-0 btn-light-primary">
                         Ask Your Question
                     </button>
                 </div>
             </div>
         </div>
         <!--  -->
         <div class="card card-flush mb-3">
             <div class="card-header">
                 <div class="text-muted card-title">
                     <h2 class="text-dark me-2">Questions & Answers</h2> (<span id="qa_cnt"><?php echo $Product->questions_count(); ?></span>)
                 </div>
             </div>
             <div id="questionsWrapper" class="card-body p-0">

                 <div class="no-question-box <?php if ($Product->questions_count() > 0) {
                                                    echo "d1-none";
                                                } ?> ">
                     <div class="no-content-box px-4 fs-4 text-gray-600"><span class="svg-icon svg-icon-muted svg-icon-2hx">
                             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                 <path fill="" d="M4,2A2,2 0 0,0 2,4V16A2,2 0 0,0 4,18H8V21A1,1 0 0,0 9,22H9.5V22C9.75,22 10,21.9 10.2,21.71L13.9,18H20A2,2 0 0,0 22,16V4C22,2.89 21.1,2 20,2H4M4,4H20V16H13.08L10,19.08V16H4V4M12.19,5.5C11.3,5.5 10.59,5.68 10.05,6.04C9.5,6.4 9.22,7 9.27,7.69C0.21,7.69 6.57,7.69 11.24,7.69C11.24,7.41 11.34,7.2 11.5,7.06C11.7,6.92 11.92,6.85 12.19,6.85C12.5,6.85 12.77,6.93 12.95,7.11C13.13,7.28 13.22,7.5 13.22,7.8C13.22,8.08 13.14,8.33 13,8.54C12.83,8.76 12.62,8.94 12.36,9.08C11.84,9.4 11.5,9.68 11.29,9.92C11.1,10.16 11,10.5 11,11H13C13,10.72 13.05,10.5 13.14,10.32C13.23,10.15 13.4,10 13.66,9.85C14.12,9.64 14.5,9.36 14.79,9C15.08,8.63 15.23,8.24 15.23,7.8C15.23,7.1 14.96,6.54 14.42,6.12C13.88,5.71 13.13,5.5 12.19,5.5M11,12V14H13V12H11Z"></path>
                             </svg>
                         </span> Be the first to ask the question
                     </div>
                 </div>

                 <?php echo $Product->all_questions($variation_id, $svariation_id)->content; ?>
             </div>
         </div>
         <!--  -->
         <div id="m_reviews_analysis_container"></div>
         <div class="card card-flush">
             <div data-id="<?php echo $product_id; ?>" id="modalAAA"></div>

             <div class="card-header">
                 <div class="card-title text-muted ">
                     <h2 class="text-dark me-2">Reviews </h2> (<span id="reviews_count" class="text-muted"><?php echo $Product->reviews_count(); ?></span>)
                 </div>
             </div>
             <div class="card-body p-0">

                 <?php if ($Product->reviews_images_cnt() > 1) {
                    ?>
                     <div id="reviewsImages" class="border-bottom border-top px-6 py-2 ">
                         <div class="mt-1 mb-2 fw-bolder">User Images <span class="text-gray-600">(<?php echo $Product->reviews_images_cnt(); ?>)</span></div>
                         <div class="gallery-container">
                             <?php echo $Product->reviews_images(); ?>
                         </div>
                     </div>
                 <?php
                    } ?>


                 <div id="reviews_container">
                     <div style="padding: 40px;" class="<?php if ($Product->reviews_count() > 0) {
                                                            echo "d1-none";
                                                        } ?>  px-4 no-content-box no-review-box fs-4 text-gray-600">
                         <span class="svg-icon svg-icon-muted svg-icon-2hx">
                             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                 <path d="M11.1359 4.48359C11.5216 3.82132 12.4784 3.82132 12.8641 4.48359L15.011 8.16962C15.1523 8.41222 15.3891 8.58425 15.6635 8.64367L19.8326 9.54646C20.5816 9.70867 20.8773 10.6186 20.3666 11.1901L17.5244 14.371C17.3374 14.5803 17.2469 14.8587 17.2752 15.138L17.7049 19.382C17.7821 20.1445 17.0081 20.7069 16.3067 20.3978L12.4032 18.6777C12.1463 18.5645 11.8537 18.5645 11.5968 18.6777L7.69326 20.3978C6.99192 20.7069 6.21789 20.1445 6.2951 19.382L6.7248 15.138C6.75308 14.8587 6.66264 14.5803 6.47558 14.371L3.63339 11.1901C3.12273 10.6186 3.41838 9.70867 4.16744 9.54646L8.3365 8.64367C8.61089 8.58425 8.84767 8.41222 8.98897 8.16962L11.1359 4.48359Z" fill="black" />
                             </svg>
                         </span>
                         Be the first to review the product
                     </div>
                     <?php echo $Product->reviews($variation_id, $svariation_id)->content; ?>
                 </div>

             </div>
         </div>
         <!--  -->
         <div class="mb-2"></div>
     </div>
 </div>