 <?php if (!empty($Product->similarProducts())) {
    ?> <div class="card rounded">
         <div class="card-header">
             <div class="card-title">
                 <h2>Similar Products</h2>
             </div>
         </div>
         <div class="card-body p-2 p-md-6">
             <div class="swiper swiper-container">
                 <div class="swiper-wrapper">
                     <?php echo $Product->similarProducts(); ?>
                 </div>
                 <div class="swiper-button-next"></div>
                 <div class="swiper-button-prev"></div>
                 <div class="swiper-pagination"></div>
             </div>
         </div>
     </div>
 <?php
    }
    ?>