<!--  -->
<div class="modal fade" id="previewReviewModal" tabindex="-1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered mw-700px mw-xl-800px mw-xxl-1000px">
    </div>
</div>

<div class="modal fade" id="askQuestionModal" tabindex="-1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered mw-650px">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="fw-bolder">Ask a question</h2>
                <div data-bs-dismiss="modal" class="btn btn-icon btn-active-light-primary btn-sm btn-active-icon-primary">
                    <span class="svg-icon svg-icon-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                        </svg>
                    </span>
                </div>
            </div>
            <div class="modal-body scroll-y">

                <?php if ($Login->is_user_loggedin() &&  ($Product->user_questions_count($LogUser->user_id) >= 5)) { ?>

                    <div class="alert bg-light-danger align-center p-5 mb-10">
                        <span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black" />
                                <rect x="7" y="15.3137" width="12" height="2" rx="1" transform="rotate(-45 7 15.3137)" fill="black" />
                                <rect x="8.41422" y="7" width="12" height="2" rx="1" transform="rotate(45 8.41422 7)" fill="black" />
                            </svg>
                        </span>
                        <div class="ms-4 d-flex flex-column pe-0 pe-sm-10">
                            <h4 class="fw-bold">Maximum limit reached?</h4>
                            <span>Sorry you are allowed to ask maximum 5 questions.</span>
                        </div>
                    </div>
                <?php } ?>

                <form novalidate id="ask_ques">
                    <div class="fv-row mb-7">
                        <label class="required fs-6 fw-bold form-label mb-2">Question</label>
                        <textarea maxlength="500" required rows="5" type="text" class="form-control" name="question" value=""></textarea>
                        <div class="invalid-feedback">Question is required</div>
                    </div>

                    <div class="justify-right">
                        <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                        <button autocomplete="off" type="submit" <?php if ($Login->is_user_loggedin() && ($Product->user_questions_count($LogUser->user_id) >= 5)) {
                                                                        echo "disabled";
                                                                    } ?> id="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!--  -->
<div class="modal fade" id="editQuestionModal" tabindex="-1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered mw-650px">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="fw-bolder">Edit question</h2>
                <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-light-primary btn-active-icon-primary">
                    <span class="svg-icon svg-icon-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                        </svg>
                    </span>
                </div>
            </div>
            <div class="modal-body scroll-y">

            </div>
        </div>
    </div>
</div>
<!--  -->
<div class="modal fade" id="addAnsModal" tabindex="-1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered mw-650px">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="fw-bolder">Add an answer</h2>
                <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-light-primary btn-active-icon-primary">
                    <span class="svg-icon svg-icon-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                        </svg>
                    </span>
                </div>
            </div>
            <div class="modal-body scroll-y">

            </div>
        </div>
    </div>
</div>
<!--  -->
<div class="modal fade" id="viewAnsModal" tabindex="-1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered mw-650px">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="fw-bolder">All Answers</h2>
                <div data-bs-dismiss="modal" class="btn btn-icon btn-active-light-primary btn-sm btn-active-icon-primary">
                    <span class="svg-icon svg-icon-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                        </svg>
                    </span>
                </div>
            </div>
            <div class="modal-body scroll-y"></div>
        </div>
    </div>
</div>
<!--  -->
<div class="modal fade" id="return_policy_modal" tabindex="-1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered mw-600px">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="fw-bolder">Returns & Exchanges</h2>
                <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-light-primary btn-active-icon-primary">
                    <span class="svg-icon svg-icon-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                        </svg>
                    </span>
                </div>
            </div>
            <div class="modal-body scroll-y">

                <?php if ($Product->return_policy($variation_id, $svariation_id) !== "no") { ?>
                    <div class="text-dark fs-5 "><b><?php echo $Product->return_policy_days($variation_id, $svariation_id); ?> days return policy</b></div>
                    <div> <?php echo $Product->return_policy_tc($variation_id, $svariation_id); ?></div>
                <?php } else {
                ?>
                    <div class="text-dark fs-5 "><b>Not returnable </b></div>

                    <div class="text-muted mb-4"> This item is non-returnable due to the nature of the product. </div>

                    <div class="d-flex mb-4">
                        <div class="col bg-light mw-100px">
                            <svg width="100px" height="100px" version="1.1" viewBox="0 0 752 752" xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path d="m288.67 502.78c0-2.5117-0.99609-4.918-2.7734-6.6953-1.7773-1.7773-4.1836-2.7734-6.6953-2.7734h-59.91c-5.2305 0-9.4727 4.2383-9.4727 9.4688 0 5.2344 4.2422 9.4727 9.4727 9.4727h59.91c2.5117 0 4.918-0.99609 6.6953-2.7734 1.7773-1.7773 2.7734-4.1836 2.7734-6.6992z" />
                                    <path d="m219.29 520.49c-5.2305 0-9.4727 4.2383-9.4727 9.4688 0 5.2344 4.2422 9.4727 9.4727 9.4727h37.414c5.2305 0 9.4727-4.2383 9.4727-9.4727 0-5.2305-4.2422-9.4688-9.4727-9.4688z" />
                                    <path d="m279.15 539.43c3.832 0 7.2852-2.3086 8.7539-5.8477 1.4648-3.5391 0.65234-7.6133-2.0547-10.32-2.707-2.7109-6.7812-3.5195-10.32-2.0547-3.543 1.4688-5.8477 4.9219-5.8477 8.75 0 2.5156 0.99609 4.9219 2.7734 6.6992 1.7773 1.7773 4.1836 2.7734 6.6953 2.7734z" />
                                    <path d="m494.4 162.89c-25.121 0-49.215 9.9766-66.977 27.742-17.762 17.762-27.742 41.852-27.742 66.973 0 25.121 9.9805 49.211 27.742 66.977 17.762 17.762 41.855 27.742 66.977 27.742 25.117 0 49.211-9.9805 66.973-27.742 17.762-17.766 27.742-41.855 27.742-66.977 0-25.121-9.9805-49.211-27.742-66.973-17.762-17.766-41.855-27.742-66.973-27.742zm0 170.49c-20.098 0-39.371-7.9844-53.582-22.191-14.211-14.211-22.191-33.484-22.191-53.582 0-20.094 7.9805-39.367 22.191-53.578 14.211-14.211 33.484-22.195 53.582-22.195 20.094 0 39.367 7.9844 53.578 22.195 14.211 14.211 22.191 33.484 22.191 53.578 0 20.098-7.9805 39.371-22.191 53.582-14.211 14.207-33.484 22.191-53.578 22.191z" />
                                    <path d="m541.75 347.59c-5.2305 0-9.4727 4.2422-9.4727 9.4727v179.96l-28.414 22.73v-193.22c0-5.2344-4.2383-9.4727-9.4688-9.4727-5.2344 0-9.4727 4.2383-9.4727 9.4727v100.78l-63.461-19.844c-3.082-0.95703-6.4336-0.27734-8.9023 1.8008-2.4648 2.0625-3.7148 5.2383-3.3164 8.4297l2.8906 23.348-47.359-14.633v-0.003906c-4.9336-1.3555-10.055 1.4492-11.566 6.3359-1.5078 4.8906 1.1367 10.098 5.9766 11.758l61.566 18.941c0.84375 0.26172 1.7227 0.40625 2.6055 0.42578 2.2344 0.003906 4.3984-0.78516 6.1094-2.2266 2.4805-2.0547 3.75-5.2305 3.3633-8.4297l-2.8906-23.254 54.984 17.195v83.016h-303.09v-303.09h40.68l-21.312 68.195h0.003906c-0.95703 3.082-0.27734 6.4336 1.8008 8.9023 2.0625 2.4648 5.2383 3.7148 8.4297 3.3164l23.348-2.8906-14.633 47.359h-0.003907c-1.5391 4.9961 1.2578 10.293 6.2539 11.84 0.89453 0.33984 1.8359 0.54688 2.793 0.61719 4.1523-0.003907 7.8203-2.7109 9.0469-6.6797l18.941-61.566c0.98047-3.082 0.32031-6.4531-1.75-8.9375-2.0742-2.4844-5.2695-3.7383-8.4805-3.3281l-23.254 2.8906 18.66-59.719h44.09v125.31c0.023438 3.375 1.8359 6.4844 4.7617 8.1602 2.9258 1.6797 6.5273 1.6719 9.4492-0.015625l32.723-19.559 32.582 19.559c2.9297 1.6953 6.543 1.6953 9.4727 0 2.957-1.707 4.7656-4.8711 4.7344-8.2852v-125.17h3.7891c5.2305 0 9.4727-4.2422 9.4727-9.4727s-4.2422-9.4727-9.4727-9.4727h-191.89l22.922-28.414h179.96c5.2305 0 9.4727-4.2383 9.4727-9.4688 0-5.2344-4.2422-9.4727-9.4727-9.4727h-184.7c-2.875 0-5.5938 1.3086-7.3906 3.5508l-37.887 47.359c-0.011718 0.09375-0.011718 0.1875 0 0.28125-0.21484 0.28516-0.40625 0.58594-0.56641 0.90234l-0.42578 0.75781c-0.13281 0.27344-0.24219 0.55859-0.33203 0.85156l-0.28516 0.89844v0.85547c-0.023437 0.32812-0.023437 0.66016 0 0.99219l-0.47266 0.37891v322.04c0 2.5117 0.99609 4.9219 2.7734 6.6992 1.7773 1.7734 4.1836 2.7734 6.6992 2.7734h322.04c0.94922-0.011719 1.8906-0.17188 2.793-0.47266h0.47266c0.88672-0.33203 1.7148-0.79688 2.4648-1.375l47.359-37.887h-0.003906c2.3828-1.8086 3.7695-4.6328 3.7422-7.625v-184.7c0-2.5117-1-4.9219-2.7734-6.6992-1.7773-1.7734-4.1875-2.7734-6.6992-2.7734zm-180.39-80.508v108.59l-23.254-13.875c-2.9297-1.6914-6.5391-1.6914-9.4688 0l-23.109 13.828-0.003906-108.54z" />
                                    <path d="m494.4 200.78c-5.9688 0-16.242 4.7344-16.242 10.844l5.3945 64.93c0 5.9883 4.8555 10.844 10.848 10.844 5.9883 0 10.844-4.8555 10.844-10.844l5.3984-64.93c0-6.1094-10.277-10.844-16.242-10.844z" />
                                    <path d="m504.86 303.97c0 5.7812-4.6875 10.469-10.465 10.469-5.7812 0-10.469-4.6875-10.469-10.469 0-5.7773 4.6875-10.465 10.469-10.465 5.7773 0 10.465 4.6875 10.465 10.465" />
                                </g>
                            </svg>
                        </div>
                        <div class="ps-4 col-lg-10">
                            For damaged, defective, wrong or expired item you can request for a refund or replacement within 7 days of delivery.
                        </div>
                    </div>

                    <div class="d-flex mb-4">
                        <div class="col bg-light mw-100px">
                            <svg width="100px" height="100px" version="1.1" viewBox="0 0 752 752" xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path d="m561.74 294.32c-2.2969-1.4336-5.1641-1.5938-7.625-0.43359l-62.973 30.285v-50.512c0-4.3633-3.5312-7.8945-7.8945-7.8945l-288.79 0.003906c-4.3633 0-7.8945 3.5312-7.8945 7.8945v204.68c0 4.3633 3.5312 7.8945 7.8945 7.8945h288.79c4.3633 0 7.8945-3.5312 7.8945-7.8945v-50.504l62.973 30.285c1.0898 0.51562 2.2578 0.77734 3.4219 0.77734 1.4648 0 2.9219-0.41016 4.1992-1.2109 2.3008-1.4492 3.6953-3.9688 3.6953-6.6836v-150c0-2.7148-1.3945-5.2344-3.6914-6.6836zm-86.383 176.13h-273v-188.89h273zm74.289-31.996-58.504-28.133v-68.625l58.504-28.137z" />
                                    <path d="m376.84 340.17-54.926 54.926-21.043-21.043c-3.082-3.082-8.0781-3.082-11.16 0-3.082 3.082-3.082 8.0781 0 11.16l26.625 26.625c1.543 1.543 3.5625 2.3125 5.582 2.3125s4.0391-0.76953 5.582-2.3125l60.508-60.508c3.082-3.082 3.082-8.0781 0-11.16-3.0898-3.0859-8.082-3.0859-11.168 0z" />
                                </g>
                            </svg>
                        </div>
                        <div class="ps-4 col-lg-10">
                            You will need to share the unboxing video of the item and its defects through Your Orders for a refund or replacement.
                        </div>
                    </div>
                <?php
                } ?>
            </div>
        </div>
    </div>
</div>
<!--  -->