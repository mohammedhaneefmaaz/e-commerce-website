<?php
require_once "../db.php";
$Login->check_user_login();
use Ecommerce\Cart;

$page = $_GET['page'] ?? 1;
$page = preg_replace('/[^0-9]/', '', $page);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Wishlist - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/visitor/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div class="post d-flex flex-column-fluid" id="lx_post">
                        <div id="lx_content_container" class="container-xxl">

                            <div class="card mw-900px mx-auto card-flush">
                                <div class="card-header">
                                    <div class="card-title">
                                        <h2>Wishlist <span class="text-muted small">(<span id="fav_count"><?php echo Cart::wishlist_products_count($LogUser->user_id); ?></span> items)</span></h2>
                                    </div>
                                </div>
                                <div id="cart_products" class="card-body p-0">
                                    <?php echo Cart::wishlist_products($LogUser->user_id, $page)->content; ?>
                                    <?php echo Cart::wishlist_products($LogUser->user_id, $page)->pagination; ?>
                                </div>
                                <div id="emptyWishlistContainer" class="<?php if (Cart::wishlist_products_count($LogUser->user_id) != 0) {
                                                                            echo "d-none";
                                                                        } ?> align-center p-4 flex-column">
                                    <img class="mh-200px img-fluid" src="<?php echo $Web->get_assets("images/web/empty-wishlist.svg"); ?>" alt="">
                                    <h2>Your Wishlist is Empty</h2>
                                    <a href="<?php echo $Web->base_url(); ?>" class="mt-8 min-w-200px w-100 w-md-auto btn btn-primary">Shop Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php include $Web->include("partials/visitor/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script>
        Cart.wishlist();
    </script>
</body>


</html>