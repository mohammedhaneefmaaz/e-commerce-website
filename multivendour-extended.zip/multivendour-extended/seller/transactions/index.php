<?php
require_once "../../db.php";
$Login->check_seller_login();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Transactions - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/seller/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">


                        <div class="row">

                            <div class="col-lg-3 col-md-6">
                                <div class="rect-card mb-4 card border-bottom border-2 border-dark">
                                    <div class="card-body ">
                                        <div class="align-justify-between">
                                            <div>
                                                <h2 class="fs-2x"><?php echo $Web->formatCurrency($LogSeller->net_income()); ?></h2>
                                                <h6 class="text-dark fw-bolder">Net Income</h6>
                                            </div>
                                            <span class="svg-icon svg-icon-dark">
                                                <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path opacity="0.3" d="M3.20001 5.91897L16.9 3.01895C17.4 2.91895 18 3.219 18.1 3.819L19.2 9.01895L3.20001 5.91897Z" fill="black" />
                                                    <path opacity="0.3" d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21C21.6 10.9189 22 11.3189 22 11.9189V15.9189C22 16.5189 21.6 16.9189 21 16.9189H16C14.3 16.9189 13 15.6189 13 13.9189ZM16 12.4189C15.2 12.4189 14.5 13.1189 14.5 13.9189C14.5 14.7189 15.2 15.4189 16 15.4189C16.8 15.4189 17.5 14.7189 17.5 13.9189C17.5 13.1189 16.8 12.4189 16 12.4189Z" fill="black" />
                                                    <path d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21V7.91895C21 6.81895 20.1 5.91895 19 5.91895H3C2.4 5.91895 2 6.31895 2 6.91895V20.9189C2 21.5189 2.4 21.9189 3 21.9189H19C20.1 21.9189 21 21.0189 21 19.9189V16.9189H16C14.3 16.9189 13 15.6189 13 13.9189Z" fill="black" />
                                                </svg>
                                            </span>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-6">
                                <div class="rect-card mb-4 card border-bottom border-2 border-success">
                                    <div class="card-body ">
                                        <div class="align-justify-between">
                                            <div>
                                                <h2 class="fs-2x"><?php echo $Web->formatCurrency($LogSeller->wallet()); ?></h2>
                                                <h6 class="text-success fw-bolder">Wallet</h6>
                                            </div>
                                            <span class="svg-icon svg-icon-success">
                                                <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path opacity="0.3" d="M3.20001 5.91897L16.9 3.01895C17.4 2.91895 18 3.219 18.1 3.819L19.2 9.01895L3.20001 5.91897Z" fill="black" />
                                                    <path opacity="0.3" d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21C21.6 10.9189 22 11.3189 22 11.9189V15.9189C22 16.5189 21.6 16.9189 21 16.9189H16C14.3 16.9189 13 15.6189 13 13.9189ZM16 12.4189C15.2 12.4189 14.5 13.1189 14.5 13.9189C14.5 14.7189 15.2 15.4189 16 15.4189C16.8 15.4189 17.5 14.7189 17.5 13.9189C17.5 13.1189 16.8 12.4189 16 12.4189Z" fill="black" />
                                                    <path d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21V7.91895C21 6.81895 20.1 5.91895 19 5.91895H3C2.4 5.91895 2 6.31895 2 6.91895V20.9189C2 21.5189 2.4 21.9189 3 21.9189H19C20.1 21.9189 21 21.0189 21 19.9189V16.9189H16C14.3 16.9189 13 15.6189 13 13.9189Z" fill="black" />
                                                </svg>
                                            </span>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-6">
                                <div class="rect-card mb-4 card border-bottom border-2 border-warning">
                                    <div class="card-body ">
                                        <div class="align-justify-between">
                                            <div>
                                                <h2 class="fs-2x"><?php echo $Web->formatCurrency($LogSeller->pending_credits()); ?></h2>
                                                <h6 class="text-warning fw-bolder">Pending Credit</h6>
                                            </div>
                                            <span class="svg-icon svg-icon-warning">
                                                <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path opacity="0.3" d="M20 18H4C3.4 18 3 17.6 3 17V7C3 6.4 3.4 6 4 6H20C20.6 6 21 6.4 21 7V17C21 17.6 20.6 18 20 18ZM12 8C10.3 8 9 9.8 9 12C9 14.2 10.3 16 12 16C13.7 16 15 14.2 15 12C15 9.8 13.7 8 12 8Z" fill="black" />
                                                    <path d="M18 6H20C20.6 6 21 6.4 21 7V9C19.3 9 18 7.7 18 6ZM6 6H4C3.4 6 3 6.4 3 7V9C4.7 9 6 7.7 6 6ZM21 17V15C19.3 15 18 16.3 18 18H20C20.6 18 21 17.6 21 17ZM3 15V17C3 17.6 3.4 18 4 18H6C6 16.3 4.7 15 3 15Z" fill="black" />
                                                </svg>
                                            </span>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-6">
                                <div class="rect-card mb-4 card border-bottom border-2 border-info">
                                    <div class="card-body ">
                                        <div class="align-justify-between">
                                            <div>
                                                <h2 class="fs-2x"><?php echo $Web->formatCurrency($LogSeller->pending_clearance()); ?></h2>
                                                <h6 class="text-info fw-bolder">Pending Clearance</h6>
                                            </div>
                                            <span class="svg-icon svg-icon-info">
                                                <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path opacity="0.3" d="M20 18H4C3.4 18 3 17.6 3 17V7C3 6.4 3.4 6 4 6H20C20.6 6 21 6.4 21 7V17C21 17.6 20.6 18 20 18ZM12 8C10.3 8 9 9.8 9 12C9 14.2 10.3 16 12 16C13.7 16 15 14.2 15 12C15 9.8 13.7 8 12 8Z" fill="black" />
                                                    <path d="M18 6H20C20.6 6 21 6.4 21 7V9C19.3 9 18 7.7 18 6ZM6 6H4C3.4 6 3 6.4 3 7V9C4.7 9 6 7.7 6 6ZM21 17V15C19.3 15 18 16.3 18 18H20C20.6 18 21 17.6 21 17ZM3 15V17C3 17.6 3.4 18 4 18H6C6 16.3 4.7 15 3 15Z" fill="black" />
                                                </svg>
                                            </span>
                                        </div>

                                    </div>
                                </div>
                            </div>


                            <div class="col-lg-3 col-md-6">
                                <div class="rect-card mb-4 card border-bottom border-2 border-warning">
                                    <div class="card-body ">
                                        <div class="align-justify-between">
                                            <div>
                                                <h2 class="fs-2x"><?php echo $Web->formatCurrency($LogSeller->pending_withdrawal()); ?></h2>
                                                <h6 class="text-warning fw-bolder">Pending Withdrawal</h6>
                                            </div>
                                            <span class="svg-icon svg-icon-warning">
                                                <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path opacity="0.3" d="M20 18H4C3.4 18 3 17.6 3 17V7C3 6.4 3.4 6 4 6H20C20.6 6 21 6.4 21 7V17C21 17.6 20.6 18 20 18ZM12 8C10.3 8 9 9.8 9 12C9 14.2 10.3 16 12 16C13.7 16 15 14.2 15 12C15 9.8 13.7 8 12 8Z" fill="black" />
                                                    <path d="M18 6H20C20.6 6 21 6.4 21 7V9C19.3 9 18 7.7 18 6ZM6 6H4C3.4 6 3 6.4 3 7V9C4.7 9 6 7.7 6 6ZM21 17V15C19.3 15 18 16.3 18 18H20C20.6 18 21 17.6 21 17ZM3 15V17C3 17.6 3.4 18 4 18H6C6 16.3 4.7 15 3 15Z" fill="black" />
                                                </svg>
                                            </span>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="rect-card mb-4 card border-bottom border-2 border-primary">
                                    <div class="card-body ">
                                        <div class="align-justify-between">
                                            <div>
                                                <h2 class="fs-2x"><?php echo $Web->formatCurrency($LogSeller->total_withdrawal()); ?></h2>
                                                <h6 class="text-primary fw-bolder">Total Withdrawal</h6>
                                            </div>
                                            <span class="svg-icon svg-icon-primary">
                                                <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path opacity="0.3" d="M20 18H4C3.4 18 3 17.6 3 17V7C3 6.4 3.4 6 4 6H20C20.6 6 21 6.4 21 7V17C21 17.6 20.6 18 20 18ZM12 8C10.3 8 9 9.8 9 12C9 14.2 10.3 16 12 16C13.7 16 15 14.2 15 12C15 9.8 13.7 8 12 8Z" fill="black" />
                                                    <path d="M18 6H20C20.6 6 21 6.4 21 7V9C19.3 9 18 7.7 18 6ZM6 6H4C3.4 6 3 6.4 3 7V9C4.7 9 6 7.7 6 6ZM21 17V15C19.3 15 18 16.3 18 18H20C20.6 18 21 17.6 21 17ZM3 15V17C3 17.6 3.4 18 4 18H6C6 16.3 4.7 15 3 15Z" fill="black" />
                                                </svg>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="card card-flush">

                            <div class="card-header">
                                <div class="card-title">
                                    <h2>Transactions</h2>
                                </div>
                            </div>
                            <div class="card-body pt-0">
                                <table class="table align-middle table-row-dashed fs-6 gy-5" id="data_table">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                            <th class="min-w-50px">#</th>
                                            <th class="min-w-100px">Transaction Id</th>
                                            <th class="min-w-150px">Amount</th>
                                            <th class="min-w-150px">Txn Charge</th>
                                            <th class="min-w-150px">Net Amount</th>
                                            <th class="min-w-50px">Description</th>
                                            <th class="min-w-150px">Date</th>
                                            <th class="min-w-150px">Last Updated</th>
                                            <th class="min-w-50px">Payment Status</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-bold text-gray-600">

                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>

                <?php include $Web->include("partials/seller/footer.php"); ?>
            </div>
        </div>
    </div>

    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/datatables.bundle.js"); ?>"></script>
    <script>
        setActiveNavItem(location.pathname);
        Seller.Transactions();
    </script>

</body>


</html>