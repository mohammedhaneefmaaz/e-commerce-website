<?php
include "../../db.php";
$Login->check_seller_login();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>My Profile - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--jw-toolbar-height:55px;--jw-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/seller/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <div class="d-flex flex-column flex-lg-row">
                            <div class="flex-column flex-lg-row-auto w-100 w-lg-350px">
                                <div class="card mb-5">
                                    <div class="card-body pt-15">
                                        <a data-bs-toggle="modal" data-bs-target="#storeModal" class="btn position-absolute mt-4 me-4 end-0 top-0 btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                            <span class="svg-icon svg-icon-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="black"></path>
                                                    <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="black"></path>
                                                </svg>
                                            </span>
                                        </a>
                                        <div class="d-flex flex-center flex-column mb-5">
                                            <div class="symbol symbol-150px symbol-circle mb-7">
                                                <img id="store_logo" data-user-avatar="" src="<?php echo $LogSeller->store_logo(); ?>" alt="image" />
                                            </div>
                                            <div id="store_name" class="fs-3 text-gray-800 fw-bolder mb-1"><?php echo $Web->is_empty($LogSeller->store_name()) ? "Store Name" : $LogSeller->store_name(); ?></div>
                                            <div id="store_description" class="fs-5 pre-wrap  fw-bold text-muted mb-6"><?php echo $Web->is_empty($LogSeller->store_description()) ? "Store Description" : $LogSeller->store_description(); ?></div>
                                        </div>
                                        <div class="separator separator-dashed my-3"></div>
                                        <div class="pb-5 fs-6">
                                            <div class="fw-bolder mt-5">User ID</div>
                                            <div class="text-gray-600">ID- <?php echo $LogSeller->user_id; ?></div>

                                            <div class="fw-bolder mt-5">Email</div>
                                            <div class="text-gray-600">
                                                <a class="text-gray-600 text-hover-primary"><?php echo $LogSeller->email(); ?></a>
                                            </div>

                                            <div class="fw-bolder mt-5">Member Since</div>
                                            <div class="text-gray-600"><?php echo $LogSeller->registration_date(); ?></div>

                                            <div class="fw-bolder mt-5">Seller Since</div>
                                            <div class="text-gray-600"><?php echo $LogSeller->registration_date(); ?></div>

                                            <div class="fw-bolder mt-5">Account verification:</div>
                                            <div class="fw-bolder status-label text-success"><?php echo $LogSeller->status_label(); ?></div>

                                            <?php if ($LogSeller->status() === "rejected") { ?>
                                                <div class="fw-bolder mt-5">Rejected reason:</div>
                                                <div class="fw-bold fs-7 pre-wrap text-danger"><?php echo $LogSeller->rejected_reason(); ?></div>
                                            <?php } ?>

                                            <?php if ($LogSeller->status() === "blocked") { ?>
                                                <div class="fw-bolder mt-5">Blocked reason:</div>
                                                <div class="fw-bold fs-7 pre-wrap text-danger"><?php echo $LogSeller->rejected_reason(); ?></div>
                                            <?php } ?>

                                            <?php if ($LogSeller->status() !== "pending" && $LogSeller->status() !== "verified") { ?>
                                                <button id="verifyAccount" class="mt-4 btn w-100 btn-light-primary">Verify Account</button>
                                            <?php } ?>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="flex-lg-row-fluid ms-lg-6">

                                <div class="card mb-lg-6 mb-4">
                                    <div class="card-header border-0">
                                        <div class="card-title">
                                            <h2> Contact Details </h2>
                                        </div>
                                        <div class="card-toolbar">
                                            <a type="edit" data-form="contact_details_form" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                                <span class="svg-icon svg-icon-3">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="black"></path>
                                                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="black"></path>
                                                    </svg>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0 pb-5">
                                        <form novalidate class="form" id="contact_details_form">
                                            <div class="row">
                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> Name </label>
                                                    <input required type="text" class="form-control form-control-solid" placeholder="" name="contact_name" value="<?php echo $LogSeller->contact_details()->contact_name ?? ""; ?>" />
                                                    <div class="invalid-feedback">Name is required</div>
                                                </div>

                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> Mobile Number </label>
                                                    <input required type="text" class="form-control form-control-solid" placeholder="" name="mobile_number" value="<?php echo $LogSeller->contact_details()->mobile_number ?? ""; ?>" />
                                                    <div class="invalid-feedback"> Mobile Number is required</div>
                                                </div>

                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> Contact Email</label>
                                                    <input required type="text" class="form-control form-control-solid" placeholder="" name="contact_email" value="<?php echo $LogSeller->contact_details()->contact_email ?? ""; ?>" />
                                                    <div class="invalid-feedback">Contact Email is required</div>
                                                </div>

                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> Preferred Language </label>
                                                    <input required type="text" class="form-control form-control-solid" placeholder="" name="preferred_language" value="<?php echo $LogSeller->contact_details()->preferred_language ?? ""; ?>" />
                                                    <div class="invalid-feedback">Preferred Language is required</div>
                                                </div>

                                            </div>
                                            <div class="d-flex mt-4 justify-content-end">
                                                <button type="cancel" class="btn d1-none me-4 btn-secondary">Cancel</button>
                                                <button type="submit" class="btn d1-none btn-primary">Update Contact</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <!--  -->
                                <div class="card mb-lg-6 mb-4">
                                    <div class="card-header border-0">
                                        <div class="card-title">
                                            <h2> Pickup Address </h2>
                                        </div>
                                        <div class="card-toolbar">
                                            <a type="edit" data-form="pickup_address_form" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                                <span class="svg-icon svg-icon-3">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="black"></path>
                                                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="black"></path>
                                                    </svg>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0 pb-5">
                                        <form novalidate class="form" id="pickup_address_form">
                                            <div class="row">
                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> Country </label>
                                                    <input required type="text" class="form-control form-control-solid" placeholder="" name="pickup_country" value="<?php echo $LogSeller->pickup_address()->pickup_country ?? ""; ?>" />
                                                    <div class="invalid-feedback">Country is required</div>
                                                </div>

                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> State </label>
                                                    <input required type="text" class="form-control form-control-solid" placeholder="" name="pickup_state" value="<?php echo $LogSeller->pickup_address()->pickup_state ?? ""; ?>" />
                                                    <div class="invalid-feedback">State is required</div>
                                                </div>

                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> City </label>
                                                    <input required type="text" class="form-control form-control-solid" placeholder="" name="pickup_city" value="<?php echo $LogSeller->pickup_address()->pickup_city ?? ""; ?>" />
                                                    <div class="invalid-feedback">City is required</div>
                                                </div>

                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> Address</label>
                                                    <input required type="text" class="form-control form-control-solid" placeholder="" name="pickup_address" value="<?php echo $LogSeller->pickup_address()->pickup_address ?? ""; ?>" />
                                                    <div class="invalid-feedback">Address is required</div>
                                                </div>

                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> PIN code</label>
                                                    <input required type="text" class="form-control form-control-solid" placeholder="" name="pin_code" value="<?php echo $LogSeller->pickup_address()->pin_code ?? ""; ?>" />
                                                    <div class="invalid-feedback">PIN code is required</div>
                                                </div>

                                            </div>
                                            <div class="d-flex mt-4 justify-content-end">
                                                <button type="cancel" class="btn d1-none me-4 btn-secondary">Cancel</button>
                                                <button type="submit" class="btn d1-none btn-primary">Update Address</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <!--  -->



                            </div>
                        </div>

                    </div>
                </div>
                <?php include $Web->include("partials/seller/footer.php"); ?>
            </div>
        </div>
    </div>

    <div class="modal fade" id="storeModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered mw-650px">
            <div class="modal-content">
                <form class="form needs-validation" novalidate default-validation>
                    <div class="modal-header">
                        <h2>Update store Details</h2>
                        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body py-10 px-lg-17">

                        <div class="justify-align-center flex-column">
                            <div id="profileContainer" class="image-input <?php if (empty($LogSeller->store_logo_id())) echo "image-input-empty"; ?> image-input-circle">
                                <div class="profile-progress"></div>
                                <img class="image-input-wrapper w-125px h-125px" src="<?php echo $LogSeller->store_logo(); ?>">
                                <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-lx-image-input-action="change" data-bs-toggle="tooltip" title="" data-bs-original-title="Change store logo">
                                    <i class="bi bi-pencil-fill fs-7"></i>
                                    <input type="file" name="logo" accept=".png, .jpg, .jpeg">
                                    <input type="hidden" value="<?php echo $LogSeller->store_logo_id(); ?>" name="logo_image_id">
                                </label>
                                <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-lx-image-input-action="remove" data-bs-toggle="tooltip" title="" data-bs-original-title="Remove logo">
                                    <i class="bi bi-x fs-2"></i>
                                </span>
                            </div>
                            <div class="form-text">Allowed file types: png, jpg, jpeg, webp</div>
                        </div>

                        <div class="d-flex flex-column mb-5 fv-row">
                            <label class="required fs-5 fw-bold mb-2">Store Name</label>
                            <input class="form-control form-control-solid" value="<?php echo $LogSeller->store_name(); ?>" required placeholder="" name="store_name">
                            <div class="invalid-feedback">Store Name is required</div>
                        </div>

                        <div class="d-flex flex-column mb-5 fv-row">
                            <label class="required fs-5 fw-bold mb-2">Description Your Store</label>
                            <textarea class="form-control form-control-solid" required placeholder="" name="store_description"><?php echo $LogSeller->store_description(); ?></textarea>
                            <div class="invalid-feedback">Description is required </div>
                        </div>

                    </div>
                    <div class="modal-footer flex-center">
                        <button data-bs-dismiss="modal" type="button" class="btn btn-light me-3">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/datatables.bundle.js"); ?>"></script>
    <script>
        LXUtil.onDOMContentLoaded((function() {
            Seller.MyProfile.init();
        }));
    </script>
</body>


</html>