<form id="listingForm" default-validation="" class="<?php if (isset($_GET["validate"])) {
                                                        echo "was-validated";
                                                    } ?> requires-validation" novalidate>
    <div class="row g-2 g-lg-4 ">
        <div class="col-lg-5">
            <div data-portion="image" class="card mb-2 mb-lg-4 ">
                <div class="card-body">
                    <div class="d-flex">
                        <div id="miniImgUpload" style="scrollbar-width: none;" class="h-450px scroll-y min-w-80px w-80px mx-2">

                            <!-- 1 -->
                            <div data-index="1" class="active required required-absolute position-relative cursor-pointer border-bottom border-warning border-2 w-80px justify-align-center mb-2 bg-light hover h-100px">

                                <div class="bottom-inherit image-upload-progress top-0">
                                    <div class="progress-bar h-3px"></div>
                                </div>
                                <span class="svg-icon svg-icon-muted svg-icon-2x">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black"></path>
                                        <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black"></path>
                                    </svg>
                                </span>
                            </div>
                            <!-- 2 -->
                            <div data-index="2" class="position-relative required required-absolute  cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">

                                <div class="bottom-inherit image-upload-progress top-0">
                                    <div class="progress-bar h-3px"></div>
                                </div>
                                <span class="svg-icon svg-icon-muted svg-icon-2x">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black"></path>
                                        <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black"></path>
                                    </svg>
                                </span>
                            </div>
                            <!-- 3 -->
                            <div data-index="3" class="position-relative required required-absolute cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">

                                <div class="bottom-inherit image-upload-progress top-0">
                                    <div class="progress-bar h-3px"></div>
                                </div>
                                <span class="svg-icon svg-icon-muted svg-icon-2x">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black"></path>
                                        <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black"></path>
                                    </svg>
                                </span>
                            </div>
                            <!-- 4 -->
                            <div data-index="4" class="position-relative cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">

                                <div class="bottom-inherit image-upload-progress top-0">
                                    <div class="progress-bar h-3px"></div>
                                </div>
                                <span class="svg-icon svg-icon-muted svg-icon-2x">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black"></path>
                                        <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black"></path>
                                    </svg>
                                </span>
                            </div>
                            <!-- 5 -->
                            <div data-index="5" class="position-relative cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">

                                <div class="bottom-inherit image-upload-progress top-0">
                                    <div class="progress-bar h-3px"></div>
                                </div>
                                <span class="svg-icon svg-icon-muted svg-icon-2x">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black"></path>
                                        <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black"></path>
                                    </svg>
                                </span>
                            </div>
                            <!-- 6 -->
                            <div data-index="6" class="position-relative cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">

                                <div class="bottom-inherit image-upload-progress top-0">
                                    <div class="progress-bar h-3px"></div>
                                </div>
                                <span class="svg-icon svg-icon-muted svg-icon-2x">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black"></path>
                                        <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black"></path>
                                    </svg>
                                </span>
                            </div>
                            <!-- 7 -->
                            <div data-index="7" class="position-relative cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">

                                <div class="bottom-inherit image-upload-progress top-0">
                                    <div class="progress-bar h-3px"></div>
                                </div>
                                <span class="svg-icon svg-icon-muted svg-icon-2x">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black"></path>
                                        <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black"></path>
                                    </svg>
                                </span>
                            </div>


                            <!-- 8 -->
                            <div data-type="video" data-index="8" class="position-relative cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">

                                <div class="bottom-inherit image-upload-progress top-0">
                                    <div class="progress-bar h-3px"></div>
                                </div>
                                <span class="svg-icon svg-icon-muted svg-icon-2x">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" style="fill:#a1a5b7;">
                                        <path d="M336.2 64H47.8C21.4 64 0 85.4 0 111.8v288.4C0 426.6 21.4 448 47.8 448h288.4c26.4 0 47.8-21.4 47.8-47.8V111.8c0-26.4-21.4-47.8-47.8-47.8zm189.4 37.7L416 177.3v157.4l109.6 75.5c21.2 14.6 50.4-.3 50.4-25.8V127.5c0-25.4-29.1-40.4-50.4-25.8z" />
                                    </svg>
                                </span>
                            </div>
                        </div>

                        <div id="mainImgUpload" class="h-450px position-relative bg-light justify-align-center flex-grow-1 me-2">
                            <button type="button" class="ecommerce-upload-btn btn-alt btn-alt-primary"><i class="fas text-white fa-upload me-2 "></i><span>Upload Image</span></button>
                            <img class="img-fluid mh-100" src=" <?php echo $Web->get_assets("images/web/blank-image.svg"); ?>" alt="" srcset="">
                        </div>

                    </div>

                </div>
            </div>

        </div>

        <div class="col-lg-7">

            <div data-portion="information" class="card card-flush py-2 mb-2 mb-lg-4">
                <div class="card-header">
                    <div class="card-title">
                        <h2>Product Information</h2>
                        <?php if (!$Listing->category()->has_variation()) {
                        ?>
                            <div id="statusWrapper" class="ms-4">
                                <?php echo $Listing->svariation_status_labels($variation_id, $svariation_id); ?>
                            </div>
                        <?php
                        } ?>
                    </div>
                    <div class="card-toolbar">
                        <?php if (!$Listing->category()->has_variation()) echo $Listing->toolbar($variation_id, $svariation_id); ?>
                    </div>
                </div>
                <div class="card-body pt-0">
                    <div class="row">
                        <div class="fv-row mb-7">
                            <label class="required fs-6 fw-bold form-label mb-2">Product Name</label>
                            <input required="" maxlength="200" name="product_name" value="<?php echo $Listing->product_name($variation_id, $svariation_id); ?>" type="text" class="form-control form-control-solid">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mb-7 fv-row">
                            <label class="required fs-6 fw-bold form-label mb-2"> Minimum Order </label>
                            <input maxlength="10" data-mask="integer" required="" name="minimum_order" value="<?php echo $Listing->minimum_order($variation_id, $svariation_id) ?? 1; ?>" type="text" class="form-control form-control-solid">
                        </div>
                        <div class="col-lg-6 mb-7 fv-row">
                            <label class="required fs-6 fw-bold form-label mb-2"> Maximum Order </label>
                            <input maxlength="10" data-mask="integer" required="" name="maximum_order" value="<?php echo $Listing->maximum_order($variation_id, $svariation_id) ?? 10; ?>" type="text" class="form-control form-control-solid">
                        </div>
                        <div class="col-lg-6 mb-7 fv-row">
                            <label class="required fs-6 fw-bold form-label mb-2"> Selling Price </label>
                            <input maxlength="10" data-mask="integer" name="product_price" required type="text" class="form-control form-control-solid" value="<?php echo $Listing->price($variation_id, $svariation_id); ?>">
                        </div>
                        <div class="col-lg-6 mb-7 fv-row">
                            <label class="required fs-6 fw-bold form-label mb-2"> Product Mrp </label>
                            <input maxlength="10" data-mask="integer" name="product_mrp" required type="text" class="form-control form-control-solid" value="<?php echo $Listing->mrp($variation_id, $svariation_id); ?>">
                        </div>
                        <div class="col-lg-6 mb-7 fv-row">
                            <label class="required fs-6 fw-bold form-label mb-2"> Stock </label>
                            <input maxlength="10" data-mask="integer" name="stock" required type="text" class="form-control form-control-solid" value="<?php echo $Listing->stock($variation_id, $svariation_id); ?>">
                        </div>
                        <div class="col-lg-6 mb-7 fv-row">
                            <label class="required fs-6 fw-bold form-label mb-2"> Low Stock Warning</label>
                            <input maxlength="10" data-mask="integer" name="low_stock_warning" required type="text" class="form-control form-control-solid" value="<?php echo $Listing->low_stock_warning($variation_id, $svariation_id) ?? 10; ?>">
                        </div>
                        <div class="col-lg-6 mb-7 fv-row">
                            <label class="required fs-6 fw-bold form-label mb-2"> Sku Id </label>
                            <input name="sku_id" required type="text" class="form-control form-control-solid" value="<?php echo $Listing->sku_id($variation_id, $svariation_id); ?>">
                        </div>
                        <div class="col-lg-6 mb-7 fv-row">
                            <label class="required fs-6 fw-bold form-label mb-2"> Return Policy </label>
                            <select id="return_policy" autocomplete="off" name="return_policy" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" value="<?php echo $Listing->return_policy($variation_id, $svariation_id); ?>" type="text" class="form-select form-select-solid">
                                <option value=""></option>
                                <option value="no">No</option>
                                <option value="replacement">Replacement</option>
                                <option value="return">Return</option>
                            </select>
                        </div>
                        <div id="return_policy_days" class="col-lg-6 mb-7 fv-row">
                            <label class="required fs-6 fw-bold form-label mb-2"> Return Policy </label>
                            <div class="input-group input-group-solid">
                                <input maxlength="10" data-mask="integer" name="return_policy_days" value="<?php echo $Listing->return_policy_days($variation_id, $svariation_id); ?>" type="text" class="form-control form-control-solid">
                                <span class="input-group-text">Days</span>
                            </div>
                        </div>
                        <div id="return_policy_tc" class="fv-row mb-7">
                            <label class="required fs-6 fw-bold form-label mb-2"> Return Policy T&C </label>
                            <textarea maxlength="5000" rows="10" name="return_policy_tc" type="text" class="form-control form-control-solid"><?php echo $Listing->return_policy_tc($variation_id, $svariation_id); ?></textarea>
                        </div>

                        <div class="col-lg-6 mb-7 fv-row">
                            <label class="required fs-6 fw-bold form-label mb-2"> Cash On Delivery</label>
                            <select name="cod_status" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" value="<?php echo $Listing->cod_status($variation_id, $svariation_id); ?>" type="text" class="form-select form-select-solid">
                                <option value=""></option>
                                <option value="no">No</option>
                                <option value="yes">Yes</option>
                            </select>
                        </div>

                        <div class="col-lg-6 mb-7 fv-row">
                            <label class="required fs-6 fw-bold form-label mb-2"> Status</label>
                            <select name="product_status" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" value="<?php echo $Listing->status($variation_id, $svariation_id); ?>" type="text" class="form-select form-select-solid">
                                <option value=""></option>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <div data-portion="details" class="card card-flush py-2 mb-2 mb-lg-4">
                <div class="card-header">
                    <div class="card-title">
                        <h2>Product Details</h2>
                    </div>
                </div>
                <div class="card-body pt-0">
                    <?php echo $Listing->product_details_form($variation_id, $svariation_id); ?>
                </div>
            </div>

            <div data-portion="tags" class="card card-flush py-2 mb-2 mb-lg-4">
                <div class="card-header">
                    <div class="card-title">
                        <h2>Product Tags</h2>
                    </div>
                </div>
                <div class="card-body pt-0">
                    <div class="d-flex align-justify-between ">
                    <label class="text-muted fs-7 form-label">Enter tags that describe your product (optional) </label>
                    <div class="d-flex mb-2" >
                            <button title="Copy Tags" data-bs-toggle="tooltip" id="copyTag" type="button" class="btn d-none btn-icon btn-sm btn-outline-light">
                                <span class="svg-icon svg-icon-2 ionic text-dark">
                                <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 512 512"><title>Copy</title><rect x="128" y="128" width="336" height="336" rx="57" ry="57" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32" style="color: #000;"></rect><path d="M383.5 128l.5-24a56.16 56.16 0 00-56-56H112a64.19 64.19 0 00-64 64v216a56.16 56.16 0 0056 56h24" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" fill="none" style="color: #000;"></path></svg>
                                </span>
                            </button>
                            <button title="Remove All Tags" data-bs-toggle="tooltip"  id="removeAllTag" type="button" class="btn d-none btn-icon btn-sm btn-outline-light">
                                <span class="ionic text-dark svg-icon svg-icon-danger svg-icon-2">
                                    <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 512 512"><title>Close</title><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M368 368L144 144M368 144L144 368"/></svg>
                                </span>
                            </button>
                        </div>
                    </div>
                    <div class="position-relative form-group">
                        <input autocomplete="off" value='<?php echo $Listing->tags($variation_id, $svariation_id); ?>' placeholder="Type Something" maxlength="500" class="form-control" name="tags" id="tags">
                    </div>
                </div>
            </div>

            <div data-portion="description" class="card card-flush py-2 mb-2 mb-lg-4">
                <div class="card-header">
                    <div class="card-title">
                        <h2>Description</h2>
                    </div>
                </div>
                <div class="card-body pt-0">
                    <label class="text-muted fs-7 form-label">Describe your product (optional) </label>
                    <textarea maxlength="5000" class="form-control form-control-solid" name="description" id="" cols="30" rows="10"><?php echo $Listing->description($variation_id, $svariation_id); ?></textarea>
                </div>
            </div>

            <div data-portion="highlights" class="card card-flush py-2 mb-2 mb-lg-4">
                <div class="card-header">
                    <div class="card-title">
                        <h2>Highlights</h2>
                    </div>
                </div>
                <div class="card-body pt-0">
                    <label class="text-muted fs-7 form-label">Add highlights points in your product(optional)</label>
                    <div id="repeater">
                        <div class="form-group">
                            <div data-repeater-list="repeater" class="d-flex flex-column gap-3">
                                <div data-repeater-item="" class="form-group align-center gap-5">
                                    <input name="highlights[]" type="text" class="form-control form-control-solid flex-grow-1 ">
                                    <button type="button" data-repeater-delete="" class="btn btn-sm btn-icon btn-light-danger">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                                <?php echo $Listing->create_highlights($variation_id, $svariation_id); ?>
                            </div>
                        </div>
                        <div class="form-group mt-5">
                            <button type="button" data-repeater-create="" class="btn btn-sm btn-light-primary">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <?php if ($Listing->can_update_variation()) {
    ?>
        <div class="form-group justify-right">
            <button type="submit" class="btn-alt btn-lg btn-alt-orange ">Save</button>
        </div>
    <?php
    } ?>
</form>