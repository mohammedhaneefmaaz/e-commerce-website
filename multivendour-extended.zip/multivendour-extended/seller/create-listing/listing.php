<?php

require_once "../../db.php";
$Login->check_seller_login();

use Ecommerce\Listing;
use Ecommerce\Category;

if (!isset($_GET["lid"], $_GET["vid"], $_GET["sid"])) Errors::response_404();
$listing_id = $_GET["lid"];
$variation_id = $_GET["vid"];
$svariation_id = $_GET["sid"];
if (!Listing::is_listing_id($listing_id)) Errors::response_404();
$Listing = new Listing($listing_id);
if (!$Listing->is_variation_id($variation_id)) Errors::response_404();
if (!$Listing->is_svariation_id($variation_id, $svariation_id)) Errors::response_404();

$qc_id = $_GET["qc"] ?? "";
$active_tab = $_GET["src"] ?? "details";

$data = new stdClass;
$data->listing_id = $listing_id;
$data->svariation_id = $svariation_id;
$data->variation_id = $variation_id;
$data->parent_type = $Listing->category()->has_variation() ? $Listing->variation_input("type") : "";
$data->child_type = $Listing->category()->has_svariation() ? $Listing->svariation_input($variation_id,"type") : "";

if ($Listing->has_qc_rejected($variation_id, $svariation_id, $qc_id)->status == true) {
    $data->error_portions =  $Listing->has_qc_rejected($variation_id, $svariation_id, $qc_id)->error_portions;
}

if (!$Web->is_empty($variation_id)) {
    $data->images = $Listing->images($variation_id, $svariation_id);
}

$data = json_encode($data);
$Category = new Category($Listing->category_id());


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Create Listing - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/seller/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <?php echo $Category->breadcrumb($Listing->product_name($variation_id, $svariation_id), false);
                        if (!$LogSeller->is_verified()) { ?>
                            <div class="alert alert-danger d-flex align-items-center p-5 mb-2 mb-lg-4">
                                <span class="svg-icon svg-icon-2hx svg-icon-danger me-4">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z" fill="currentColor"></path>
                                        <path d="M10.5606 11.3042L9.57283 10.3018C9.28174 10.0065 8.80522 10.0065 8.51412 10.3018C8.22897 10.5912 8.22897 11.0559 8.51412 11.3452L10.4182 13.2773C10.8099 13.6747 11.451 13.6747 11.8427 13.2773L15.4859 9.58051C15.771 9.29117 15.771 8.82648 15.4859 8.53714C15.1948 8.24176 14.7183 8.24176 14.4272 8.53714L11.7002 11.3042C11.3869 11.6221 10.874 11.6221 10.5606 11.3042Z" fill="currentColor"></path>
                                    </svg>
                                </span>
                                <div class="d-flex flex-column">
                                    <h4 class="mb-1 text-danger">Listing isn't available for unverified seller</h4>
                                    <span>Please verify your account.</span>
                                </div>
                            </div>
                        <?php
                        }
                        if ($Category->is_archived()) { ?>
                            <div class="alert alert-danger d-flex align-items-center p-5 mb-2 mb-lg-4">
                                <span class="svg-icon svg-icon-2hx svg-icon-danger me-4">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M12 10.6L14.8 7.8C15.2 7.4 15.8 7.4 16.2 7.8C16.6 8.2 16.6 8.80002 16.2 9.20002L13.4 12L12 10.6ZM10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 8.99999 16.4 9.19999 16.2L12 13.4L10.6 12Z" fill="black" />
                                        <path d="M22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2C17.5 2 22 6.5 22 12ZM13.4 12L16.2 9.20001C16.6 8.80001 16.6 8.19999 16.2 7.79999C15.8 7.39999 15.2 7.39999 14.8 7.79999L12 10.6L9.2 7.79999C8.8 7.39999 8.2 7.39999 7.8 7.79999C7.4 8.19999 7.4 8.80001 7.8 9.20001L10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 9 16.4 9.2 16.2L12 13.4L14.8 16.2C15 16.4 15.3 16.5 15.5 16.5C15.7 16.5 16 16.4 16.2 16.2C16.6 15.8 16.6 15.2 16.2 14.8L13.4 12Z" fill="black" />
                                    </svg>
                                </span>
                                <div class="d-flex flex-column">
                                    <h4 class="mb-1 text-danger">Your selected category '<?php echo $Category->category(); ?>' is no more available now</h4>
                                    <span>Since the category has been closed you can't add new variations to this listing, but you can update details.</span>
                                </div>
                            </div>
                        <?php
                        }

                        if ($Category->is_rejected()) { ?>
                            <div class="alert alert-danger d-flex align-items-center p-5 mb-2 mb-lg-4">
                                <span class="svg-icon svg-icon-2hx svg-icon-danger me-4">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M12 10.6L14.8 7.8C15.2 7.4 15.8 7.4 16.2 7.8C16.6 8.2 16.6 8.80002 16.2 9.20002L13.4 12L12 10.6ZM10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 8.99999 16.4 9.19999 16.2L12 13.4L10.6 12Z" fill="black" />
                                        <path d="M22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2C17.5 2 22 6.5 22 12ZM13.4 12L16.2 9.20001C16.6 8.80001 16.6 8.19999 16.2 7.79999C15.8 7.39999 15.2 7.39999 14.8 7.79999L12 10.6L9.2 7.79999C8.8 7.39999 8.2 7.39999 7.8 7.79999C7.4 8.19999 7.4 8.80001 7.8 9.20001L10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 9 16.4 9.2 16.2L12 13.4L14.8 16.2C15 16.4 15.3 16.5 15.5 16.5C15.7 16.5 16 16.4 16.2 16.2C16.6 15.8 16.6 15.2 16.2 14.8L13.4 12Z" fill="black" />
                                    </svg>
                                </span>
                                <div class="d-flex flex-column">
                                    <h4 class="mb-1 text-danger">Your selected category '<?php echo $Category->category(); ?>' has been removed</h4>
                                    <span>This listing is no more available on <?php echo $Web->web_name(); ?></span>
                                </div>
                            </div>
                        <?php
                        }
                        ?>

                        <?php if ($Listing->category()->has_variation()) {
                        ?>
                            <div class="mb-2 mb-lg-4  card card-flush">
                                <div class="card-header">
                                    <div class="card-title">
                                        <h2><?php echo $Listing->variation_header_text(); ?></h2>
                                       <?php if (!$Listing->category()->has_svariation()) { ?>  
                                         <div id="statusWrapper" class="ms-4">
                                            <?php echo $Listing->svariation_status_labels($variation_id, $svariation_id); ?>
                                        </div>
                                        <?php } ?>
                                    </div>
                                    <div class="card-toolbar">
                                        <?php echo $Listing->toolbar($variation_id, $svariation_id); ?>
                                    </div>
                                </div>
                                <div class="card-body pt-0">
                                    <div class="flex-wrap gap-4 align-center">
                                        <?php echo $Listing->variations_card($variation_id);

                                        if ($Listing->can_add_variation()) {
                                        ?> <div>
                                                <div data-role="primary" data-trigger="createVariation" class="active position-relative cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">
                                                    <div class="bottom-inherit image-upload-progress top-0">
                                                        <div class="progress-bar h-3px"></div>
                                                    </div>
                                                    <span class="svg-icon svg-icon-muted svg-icon-4x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <rect opacity="0.5" x="11" y="18" width="12" height="2" rx="1" transform="rotate(-90 11 18)" fill="currentColor" />
                                                            <rect x="6" y="11" width="12" height="2" rx="1" fill="currentColor" />
                                                        </svg></span>
                                                </div>
                                            </div>
                                        <?php
                                        }
                                        ?>

                                    </div>
                                </div>
                            </div>
                        <?php
                        }
                        ?>
                        <?php if ($Listing->category()->has_svariation()) {
                        ?>
                            <div class="mb-2 mb-lg-4  card card-flush">
                                <div class="card-header">
                                    <div class="card-title">
                                        <h2><?php echo $Listing->svariation_header_text(); ?></h2>
                                        <div id="statusWrapper" class="ms-4">
                                            <?php echo $Listing->svariation_status_labels($variation_id, $svariation_id); ?>
                                        </div>
                                    </div>
                                    <div class="card-toolbar">
                                        <?php echo $Listing->child_toolbar($variation_id, $svariation_id); ?>
                                    </div>
                                </div>
                                <div class="card-body pt-0">
                                    <div class="flex-wrap gap-4 align-center">
                                        <?php echo $Listing->svariations_card($variation_id, $svariation_id);
                                        if ($Listing->can_add_variation()) {
                                        ?>
                                            <div>
                                                <div data-role="secondary" data-trigger="createVariation" class="active position-relative cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">
                                                    <div class="bottom-inherit image-upload-progress top-0">
                                                        <div class="progress-bar h-3px"></div>
                                                    </div>
                                                    <span class="svg-icon svg-icon-muted svg-icon-4x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <rect opacity="0.5" x="11" y="18" width="12" height="2" rx="1" transform="rotate(-90 11 18)" fill="currentColor" />
                                                            <rect x="6" y="11" width="12" height="2" rx="1" fill="currentColor" />
                                                        </svg></span>
                                                </div>
                                            </div>
                                        <?php
                                        }
                                        ?>

                                    </div>
                                </div>
                            </div>
                        <?php  } ?>

                        <?php
                        if ($Listing->has_qc_rejected($variation_id, $svariation_id, $qc_id)->status == true) {
                        ?>
                            <div class="alert alert-dismissible bg-light-danger d-flex flex-column flex-sm-row w-100 p-5 mb-2 mb-lg-4">
                                <span class="svg-icon me-4 svg-icon-danger svg-icon-2hx">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M12 10.6L14.8 7.8C15.2 7.4 15.8 7.4 16.2 7.8C16.6 8.2 16.6 8.80002 16.2 9.20002L13.4 12L12 10.6ZM10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 8.99999 16.4 9.19999 16.2L12 13.4L10.6 12Z" fill="black" />
                                        <path d="M22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2C17.5 2 22 6.5 22 12ZM13.4 12L16.2 9.20001C16.6 8.80001 16.6 8.19999 16.2 7.79999C15.8 7.39999 15.2 7.39999 14.8 7.79999L12 10.6L9.2 7.79999C8.8 7.39999 8.2 7.39999 7.8 7.79999C7.4 8.19999 7.4 8.80001 7.8 9.20001L10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 9 16.4 9.2 16.2L12 13.4L14.8 16.2C15 16.4 15.3 16.5 15.5 16.5C15.7 16.5 16 16.4 16.2 16.2C16.6 15.8 16.6 15.2 16.2 14.8L13.4 12Z" fill="black" />
                                    </svg>
                                </span>
                                <div class="d-flex flex-column pe-0 pe-sm-10">
                                    <h4 class="fw-bold">Listing was rejected from qc</h4>
                                    <div class="pre-wrap"><?php echo $Listing->has_qc_rejected($variation_id, $svariation_id, $qc_id)->reject_reason ?></div>
                                </div>
                                <button type="button" class="position-absolute position-sm-relative m-2 m-sm-0 top-0 end-0 btn btn-icon ms-sm-auto" data-bs-dismiss="alert">
                                    <span class="svg-icon svg-icon-1 svg-icon-danger">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
                                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
                                        </svg>
                                    </span>
                                </button>
                            </div>
                        <?php
                        }
                        ?>


                        <?php if ((isset($_GET["validate"])) && !empty($Listing->validation_errors($variation_id, $svariation_id)->errors)) {
                        ?>
                            <div class="mb-2 mb-lg-4  card card-flush">
                                <div class="card-header">
                                    <div class="card-title">
                                        <h2>Please solve the following errors :- </h2>
                                    </div>
                                    <div class="card-toolbar">
                                        <span data-parent-remove="true" data-parent-eq="2" class="svg-icon cursor-pointer hover svg-icon-muted svg-icon-2hx">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
                                            </svg>
                                        </span>
                                    </div>
                                </div>
                                <div class="card-body row pt-0">
                                    <?php echo $Listing->validation_errors($variation_id, $svariation_id)->errors; ?>
                                </div>
                            </div>

                        <?php
                        }

                        if ($Listing->is_svariation_live($variation_id, $svariation_id)) {
                        ?>
                            <div class="card p-2 mb-2 mb-lg-4">
                                <ul class="nav nav-tabs nav-pills flex-row border-0 me-5 mb-3 mb-md-0 fs-6">
                                    <li class="nav-item me-2">
                                        <a href="<?php echo $Listing->vurl($variation_id, $svariation_id); ?>" class="nav-link btn btn-flex btn-active-light-success <?php if ($active_tab == "details") {
                                                                                                                                                                            echo "active";
                                                                                                                                                                        } ?> ">
                                            <span class="svg-icon svg-icon-2 svg-icon-primary me-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="black" />
                                                    <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="black" />
                                                </svg>
                                            </span>
                                            <span class="d-flex flex-column align-items-start">
                                                <span class="fs-4 fw-bolder">Details</span>
                                            </span>
                                        </a>
                                    </li>
                                    <li class="nav-item me-2">
                                        <a href="<?php echo $Listing->analytics_url($variation_id, $svariation_id); ?>" class="nav-link btn btn-flex btn-active-light-info <?php if ($active_tab == "analytics") {
                                                                                                                                                                                echo "active";
                                                                                                                                                                            } ?> ">
                                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <rect x="8" y="9" width="3" height="10" rx="1.5" fill="black" />
                                                    <rect opacity="0.5" x="13" y="5" width="3" height="14" rx="1.5" fill="black" />
                                                    <rect x="18" y="11" width="3" height="8" rx="1.5" fill="black" />
                                                    <rect x="3" y="13" width="3" height="6" rx="1.5" fill="black" />
                                                </svg>
                                            </span>
                                            <span class="d-flex flex-column align-items-start">
                                                <span class="fs-4 fw-bolder">Analytics</span>
                                            </span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        <?php
                            switch ($active_tab) {
                                case "analytics":
                                    include "partials/analytics.php";
                                    break;
                                default:
                                    include "partials/details.php";
                                    break;
                            }
                        } else {
                            include "partials/details.php";
                        }
                        ?>
                    </div>
                </div>
                <?php include $Web->include("partials/seller/footer.php"); ?>
            </div>
        </div>
    </div>

    <div class="modal fade" id="createVariationModal" tabindex="-1" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered mw-650px">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="fw-bolder">Add a variation</h2>
                    <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                        <span class="svg-icon svg-icon-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                            </svg>
                        </span>
                    </div>
                </div>
                <div class="modal-body scroll-y">
                    <form class="needs-validation" default-validation="" novalidate="">

                    </form>
                </div>
            </div>
        </div>
    </div>

    <!--  -->
    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/tagify.js"); ?>"></script>
    <script src="<?php echo $Web->get_assets("js/formrepeater.js"); ?>"></script>

    <script>
        <?php
        switch ($active_tab) {
            case "analytics":
        ?> CreateListing.analytics('<?php echo json_encode(array(
                                        "listing_id" => $listing_id,
                                        "variation_id" => $variation_id,
                                        "svariation_id" => $svariation_id,
                                    )); ?>');
            <?php
                break;
            default:
            ?> CreateListing.create('<?php echo $data; ?>');
        <?php
                break;
        }
        ?>
        setActiveNavItem();
    </script>

</body>


</html>