<?php
require_once "../../db.php";
$Login->check_seller_login();

use Ecommerce\Withdraw;

if (!isset($_GET["id"])) Errors::response_404();
$withdraw_id = $_GET["id"];
if (!Withdraw::is_withdraw_id($withdraw_id)) Errors::response_404();
$Withdraw = new Withdraw($withdraw_id);
if ($Withdraw->seller()->user_id !== $LogSeller->user_id) Errors::response_404();


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title> Withdraw #<?php echo $withdraw_id; ?> - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/seller/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div class="post d-flex flex-column-fluid" id="lx_post">
                        <div id="lx_content_container" class="container-xxl">

                            <?php

                            switch ($Withdraw->status()) {
                                case "pending":
                            ?>
                                    <div class="alert alert-warning d-flex align-items-center p-5 mb-5">
                                        <span class="svg-icon svg-icon-2hx svg-icon-warning me-4">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black"></rect>
                                                <rect x="11" y="14" width="7" height="2" rx="1" transform="rotate(-90 11 14)" fill="black"></rect>
                                                <rect x="11" y="17" width="2" height="2" rx="1" transform="rotate(-90 11 17)" fill="black"></rect>
                                            </svg>
                                        </span>
                                        <div class="d-flex flex-column">
                                            <h4 class="mb-1 text-warning">Withdraw Pending</h4>
                                            <span>You have requested for withdrawal on <?php echo $Withdraw->date_requested(); ?>.</span>
                                        </div>
                                    </div>
                                <?php
                                    break;
                                case "success":
                                ?>
                                    <div class="alert alert-success d-flex align-items-center p-5 mb-5">
                                        <span class="svg-icon svg-icon-2hx svg-icon-success me-4">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <path opacity="0.3" d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z" fill="black"></path>
                                                <path d="M10.5606 11.3042L9.57283 10.3018C9.28174 10.0065 8.80522 10.0065 8.51412 10.3018C8.22897 10.5912 8.22897 11.0559 8.51412 11.3452L10.4182 13.2773C10.8099 13.6747 11.451 13.6747 11.8427 13.2773L15.4859 9.58051C15.771 9.29117 15.771 8.82648 15.4859 8.53714C15.1948 8.24176 14.7183 8.24176 14.4272 8.53714L11.7002 11.3042C11.3869 11.6221 10.874 11.6221 10.5606 11.3042Z" fill="black"></path>
                                            </svg>
                                        </span>
                                        <div class="d-flex flex-column">
                                            <h4 class="mb-1 text-success">Withdraw Successfull</h4>
                                            <span>Withdraw has been successfull on <?php echo $Withdraw->date_processed(); ?>.</span>
                                        </div>
                                    </div>
                                <?php
                                    break;
                                case "rejected":
                                ?>
                                    <div class="alert alert-danger d-flex align-items-center p-5 mb-5">
                                        <span class="svg-icon svg-icon-2hx svg-icon-danger me-4">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black" />
                                                <rect x="7" y="15.3137" width="12" height="2" rx="1" transform="rotate(-45 7 15.3137)" fill="black" />
                                                <rect x="8.41422" y="7" width="12" height="2" rx="1" transform="rotate(45 8.41422 7)" fill="black" />
                                            </svg>
                                        </span>
                                        <div class="d-flex flex-column">
                                            <h4 class="mb-1 text-danger">Withdraw Rejected</h4>
                                            <span><?php echo $Withdraw->rejected_reason(); ?></span>
                                        </div>
                                    </div>
                            <?php
                                    break;
                            } ?>

                            <div class="row form-disabled">
                                <div class="col-lg-6">
                                    <div class="card mb-4">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <?php echo $Withdraw->gateway()->card_heading; ?>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <?php echo $Withdraw->labels(); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="card">
                                        <div class="card-header">
                                            <div class="card-title">
                                                Withdraw
                                            </div>
                                        </div>
                                        <div class="card-body">

                                            <div class="mb-5 fv-row">
                                                <label class="fs-6 fw-bold mb-2 required"> Amount </label>
                                                <div class="input-group mb-5">
                                                    <span class="input-group-text" id="basic-addon1"><?php echo $Web->currency(); ?></span>
                                                    <input required type="text" class="form-control flex-grow-1 " name="amount" value="<?php echo $Withdraw->gross_amount(); ?>">
                                                </div>
                                            </div>

                                            <div class="mb-5 fv-row">
                                                <label class="fs-6 fw-bold mb-2 required"> Withdraw Charge </label>
                                                <div class="input-group mb-5">
                                                    <span class="input-group-text" id="basic-addon1"><?php echo $Web->currency(); ?></span>
                                                    <input required type="text" class="form-control flex-grow-1 " name="withdraw_charge" value="<?php echo $Withdraw->charge(); ?>">
                                                </div>
                                            </div>

                                            <div class="mb-5 fv-row">
                                                <label class="fs-6 fw-bold mb-2 required"> Final Amount </label>
                                                <div class="input-group mb-5">
                                                    <span class="input-group-text" id="basic-addon1"><?php echo $Web->currency(); ?></span>
                                                    <input required type="text" class="form-control flex-grow-1 " name="final_amount" value="<?php echo $Withdraw->net_amount(); ?>">
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php include $Web->include("partials/seller/footer.php"); ?>


            </div>
        </div>


    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script>
        setActiveNavItem(getCurrentDirPath() + "history");
    </script>


</body>


</html>