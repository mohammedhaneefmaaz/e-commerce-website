<?php
require_once "../../db.php";
$Login->check_seller_login();

use Ecommerce\WithdrawGateway;

if (!isset($_GET["id"])) Errors::response_404();
$gateway_id = $_GET["id"];
if (!WithdrawGateway::is_gateway_id($gateway_id)) Errors::response_404();
$WithdrawGateway = new WithdrawGateway($gateway_id);
if ($WithdrawGateway->status() !== "active") Errors::response_404();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Withdraw - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/seller/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div class="post d-flex flex-column-fluid" id="lx_post">
                        <div id="lx_content_container" class="container-xxl">

                            <div class="mx-auto mw-600px mb-6">
                                <form id="add_withdraw_details"  novalidate action="">
                                    <div class="card">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <?php echo $WithdrawGateway->card_heading(); ?>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <?php echo $WithdrawGateway->form($LogSeller->user_id); ?>
                                        </div>
                                    </div>
                                    <div class="justify-right mt-6">
                                        <a href="./" class="btn btn-secondary">Cancel</a>
                                        <button type="submit" class="ms-4 btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
                       



                    </div>
                </div>
            </div>

            <?php include $Web->include("partials/seller/footer.php"); ?>


        </div>
    </div>


    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script>
        Withdraw.createMethod();
    </script>


</body>


</html>