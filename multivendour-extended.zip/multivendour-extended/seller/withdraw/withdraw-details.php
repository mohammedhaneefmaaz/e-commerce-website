<?php
require_once "../../db.php";
$Login->check_seller_login();

use Ecommerce\WithdrawGateway;

if (!isset($_GET["id"])) Errors::response_404();
$gateway_id = $_GET["id"];
if (!WithdrawGateway::is_gateway_id($gateway_id)) Errors::response_404();
$WithdrawGateway = new WithdrawGateway($gateway_id);
if ($WithdrawGateway->status() !== "active") Errors::response_404();
if (!$WithdrawGateway->has_seller_withdraw_gateway($LogSeller->user_id)) $Web->locate_to($Web->seller_url() . '/withdraw/add-details?id=' . $gateway_id);

$db_labels = $WithdrawGateway->labels();
$labels = $WithdrawGateway->user_added_labels($LogSeller->user_id);

if (array_keys($labels) !=  array_column($db_labels, "id")) $Web->locate_to($Web->seller_url() . '/withdraw/add-details?id=' . $gateway_id);

$props = json_encode(array(
    "charge" => $WithdrawGateway->charge(),
    "charge_type" => $WithdrawGateway->charge_type()
));

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Withdraw - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/seller/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div class="post d-flex flex-column-fluid" id="lx_post">
                        <div id="lx_content_container" class="container-xxl">

                            <form id="withdraw" class="needs-validation" default-validation novalidate action="">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="card">
                                            <div class="card-header">
                                                <div class="card-title">
                                                    <?php echo $WithdrawGateway->card_heading(); ?>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <?php echo $WithdrawGateway->false_form($LogSeller->user_id); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="card">
                                            <div class="card-header">
                                                <div class="card-title">
                                                    Withdraw
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <div class="mb-5 fv-row">
                                                    <label class="fs-6 fw-bold mb-2 required"> Available Balance </label>
                                                    <div class="input-group mb-5">
                                                        <span class="input-group-text" id="basic-addon1"><?php echo $Web->currency(); ?></span>
                                                        <input autocomplete="off" required readonly type="text" class="form-control flex-grow-1 " name="available_balance" value="<?php echo $LogSeller->wallet(); ?>">
                                                    </div>
                                                </div>

                                                <div class="mb-5 fv-row">
                                                    <label class="fs-6 fw-bold mb-2 required"> Amount </label>
                                                    <div class="input-group mb-5">
                                                        <span class="input-group-text" id="basic-addon1"><?php echo $Web->currency(); ?></span>
                                                        <input autocomplete="off" placeholder="Enter the amount to withdraw" required type="text" class="form-control flex-grow-1 " name="amount" value="">
                                                    </div>
                                                    <div class="invalid-feedback">Amount is required</div>
                                                </div>

                                                <div class="mb-5 fv-row">
                                                    <label class="fs-6 fw-bold mb-2 required"> Withdraw Charge (<?php echo $WithdrawGateway->chargeText(); ?>) </label>
                                                    <div class="input-group mb-5">
                                                        <span class="input-group-text" id="basic-addon1"><?php echo $Web->currency(); ?></span>
                                                        <input autocomplete="off" readonly autocomplete="off" name="withdraw_charge" type="text" class="form-control" required></input>
                                                    </div>
                                                </div>

                                                <div class="mb-5 fv-row">
                                                    <label class="fs-6 fw-bold mb-2 required"> Final Amount </label>
                                                    <div class="input-group mb-5">
                                                        <span class="input-group-text" id="basic-addon1"><?php echo $Web->currency(); ?></span>
                                                        <input autocomplete="off" readonly required type="text" class="form-control flex-grow-1 " name="final_amount" value="">
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="justify-right mt-4">
                                    <a href="./" class="btn btn-secondary">Cancel</a>
                                    <button type="submit" class="ms-4 btn btn-primary">Withdraw</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php include $Web->include("partials/seller/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>

    <script>
        Withdraw.fillDetails(<?php echo $props; ?>);
    </script>
</body>


</html>