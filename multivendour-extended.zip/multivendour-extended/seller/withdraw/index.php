<?php
require_once "../../db.php";
$Login->check_seller_login();

use Ecommerce\WithdrawGateway;


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Withdraw - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/seller/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div class="post d-flex flex-column-fluid" id="lx_post">
                        <div id="lx_content_container" class="container-xxl">
                            <?php echo $LogSeller->withdraw_gateway_lists(); ?>
                        </div>
                    </div>
                </div>
                <?php include $Web->include("partials/seller/footer.php"); ?>
            </div>
        </div>


    </div>
    <?php include $Web->include("partials/scripts.php"); ?>

    <script>
        setActiveNavItem(location.pathname);

        Withdraw.lists();
    </script>


</body>


</html>