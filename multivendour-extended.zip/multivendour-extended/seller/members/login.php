<?php
require_once "../../db.php";
$Login->uncheck_seller_login();

$googleLogin = new googleLogin("login", "seller");
if (isset($_GET["code"])) {
    $out = $googleLogin->verifyLogin($_GET["code"]);

    if ($out->message === "Login Successfull") {
        $Web->locate_to($out->url);
    } else if (!empty($out->url)) {
        $Web->locate_to($out->url);
    }
    $googleLoginError =  $out->message;
}


if (isset($_GET["err"])) {
    $err_id = $_GET["err"];

    $stmt = $db->prepare("SELECT * FROM $Web->check_google_signup_tbl WHERE google_id = ? AND type = 'login' ");
    $stmt->execute([$err_id]);
    if ($stmt->rowCount()) {
        $row = $stmt->fetch();
        $details = $row->details;
        $details = unserialize($details);
        $googleLoginErrorEmail = $details["user_email"];
        $googleLoginError = $details["error"];
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
    <link rel="stylesheet" href="<?php echo $Web->get_assets("css/swiper.css"); ?>" />
</head>

<body id="lx_body">
    <div class="d-flex flex-column flex-root">
        <div class="d-flex flex-column flex-column-fluid bgi-position-y-bottom position-x-center bgi-no-repeat bgi-size-contain bgi-attachment-fixed" style="background-repeat:inherit;background-image: url(<?php echo $Web->get_assets('images/web/login-bg.jpg'); ?>)">
            <div class="d-flex flex-center flex-column flex-column-fluid ">
                <div style="max-width: 1032px;" class="login-card mw-lg-1000px mw-500px w-100 card mx-auto">

                    <div class="row">
                        <div style="background: #fafbfc;" class="slider-card d-none d-lg-block p-0 col-lg-6">
                            <section class="h-100 swiper">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide" style="background-image:url(<?php echo $Web->get_assets("images/ecommerce/seller/login_1.jpg"); ?>);"></div>
                                    <div class="swiper-slide" style="background-image:url(<?php echo $Web->get_assets("images/ecommerce/seller/login_2.jpg"); ?>);"></div>
                                    <div class="swiper-slide" style="background-image:url(<?php echo $Web->get_assets("images/ecommerce/seller/login_3.jpg"); ?>);"></div>
                                </div>
                                <div class="swiper-pagination"></div>
                            </section>
                        </div>
                        <div id="loginCard" class="p-16 mw-500px col-lg-6">
                            <div class="<?php echo $googleLoginError ?? "d-none"; ?> notice mb-4 d-flex bg-light-danger rounded border-danger border border-2 border-dashed flex-shrink-0 p-6">
                                <span class="justify-align-center svg-icon svg-icon-2tx svg-icon-danger me-4">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black"></rect>
                                        <rect x="11" y="14" width="7" height="2" rx="1" transform="rotate(-90 11 14)" fill="black"></rect>
                                        <rect x="11" y="17" width="2" height="2" rx="1" transform="rotate(-90 11 17)" fill="black"></rect>
                                    </svg>
                                </span>
                                <div class="text-center w-100">
                                    <h4 class="text-gray-900 fw-bolder"><?php echo $googleLoginError ?? ''; ?> </h4>
                                    <a class="fs-6 text-danger pe-7"><?php echo $googleLoginErrorEmail ?? ''; ?></a>
                                </div>
                            </div>

                            <form class="form w-100" novalidate="novalidate" id="loginForm">

                                <div class="justify-align-center flex-column">

                                    <a href="<?php echo $Web->seller_url(); ?>" class="mb-6">
                                        <img alt="Logo" src="<?php echo $Web->seller_logo(); ?>" class="h-40px" />
                                    </a>
                                    <h1 class="text-dark fs-2x mb-8">Get Started with <?php echo $Web->web_name(); ?></h1>

                                    <a false-url href="<?php echo $googleLogin->getUrl(); ?>" type="button" class="btn btn-light-primary btn-active fw-bolder w-100 ">
                                        <img alt="Logo" src="<?php echo $Web->get_assets('images/web/google-icon.svg'); ?>" class="h-20px me-3" />Login with Google</a>

                                    <div class="d-flex w-100 align-items-center my-8">
                                        <div class="border-bottom border-gray-300 mw-50 w-100"></div>
                                        <span class="fw-bold text-gray-400 fs-7 mx-2">OR</span>
                                        <div class="border-bottom border-gray-300 mw-50 w-100"></div>
                                    </div>
                                </div>

                                <div class="fv-row mb-10">
                                    <label class="form-label fs-6 fw-bolder text-dark">Email</label>
                                    <input required value="<?php echo $Web->testingEmail; ?>" class="form-control form-control-lg" type="email" name="email" />
                                    <div class="invalid-feedback">Email is required</div>
                                </div>
                                <div class="fv-row mb-10">
                                    <div class="d-flex flex-stack mb-2">
                                        <label class="form-label fw-bolder text-dark fs-6 mb-0">Password</label>
                                        <a href="<?php echo $Web->seller_url(); ?>/forgot-password" class="link-primary fs-6 fw-bolder">Forgot Password ?</a>
                                    </div>
                                    <div class="position-relative">
                                        <input value="<?php echo $Web->testingEmailPassword; ?>" required class="form-control no-bg password-input form-control-lg" type="password" name="password" />
                                        <div class="show password-toggle">
                                            <svg class="show" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="-10 -10 47 38" style="stroke:#0c0c0d">
                                                <g style="stroke-width:2;fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round" transform="translate(1 1)">
                                                    <path d="m0 8c0-2 5.5-8 11-8s11 6 11 8-5.5 8-11 8-11-6-11-8z" />
                                                    <path d="m11 12c2.2091 0 4-1.7909 4-4 0-2.20914-1.7909-4-4-4-2.20914 0-4 1.79086-4 4 0 2.2091 1.79086 4 4 4z" />
                                                    <path d="m13 7c.5523 0 1-.44772 1-1s-.4477-1-1-1-1 .44772-1 1 .4477 1 1 1z" fill="#000" fill-rule="nonzero" />
                                                </g>
                                            </svg>
                                            <svg class="hide" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="-10 -7 47 38" style="stroke:#0c0c0d">
                                                <g style="stroke-width:2;fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round" transform="translate(1 1)">
                                                    <path d="m4.14 15.76c-2.44-1.76-4.14-4.13-4.14-5.22 0-1.91 5.27-7.66 10.54-7.66 1.8042928.06356301 3.559947.60164173 5.09 1.56m3.53 2.85c.954643.86366544 1.6242352 1.9970896 1.92 3.25 0 1.92-5.27 7.67-10.54 7.67-.82748303-.0073597-1.64946832-.1353738-2.44-.38" />
                                                    <path d="m11.35 14.29c1.3567546-.2923172 2.4501897-1.2939955 2.86-2.62m-1.56-4.33c-1.5090443-.9785585-3.49511641-.77861361-4.77882585.48110127-1.28370945 1.25971488-1.52108848 3.24166123-.57117415 4.76889873" />
                                                    <path d="m13.08 7.9c-.1699924-.15256531-.3916348-.2347875-.62-.23-.5522847 0-1 .44771525-1 1 .0046671.23144917.0894903.45410992.24.63" />
                                                    <path d="m21.08 0-21.08 21.08" />
                                                </g>
                                            </svg>
                                        </div>
                                    </div>
                                    <div class="invalid-feedback">Password is required</div>
                                </div>
                                <div class="fv-row mb-10">
                                    <label class="form-check form-check-custom form-check-inline">
                                        <input checked class="form-check-input" type="checkbox" id="keeplogged" />
                                        <span class="form-check-label fw-bold text-gray-700 fs-6">
                                            <a class="ms-1 link-primary">Remember Me</a></span>
                                    </label>
                                </div>
                                <button type="submit" id="submit" class="btn btn-lg btn-primary w-100 mb-5">Login</button>
                                <div class="text-center">
                                    <div class="fw-bold fs-6">Don't have an account?
                                        <a href="<?php echo $Web->seller_url(); ?>/register" class="link-primary fw-bolder">Create an Account</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>

    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/swiper.js"); ?>"></script>
    <script>
        LXUtil.onDOMContentLoaded((function() {
            Login.userLogin({
                role: "seller"
            });
        }));
    </script>
</body>

</html>