
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Register - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body">
    <div class="d-flex flex-column flex-root">
        <div class="d-flex flex-column flex-column-fluid bgi-position-y-bottom position-x-center bgi-no-repeat bgi-size-contain bgi-attachment-fixed" style="background-image: url(<?php echo $Web->get_assets('images/web/background.png'); ?>)">
            <div class="d-flex flex-center flex-column flex-column-fluid p-10 pb-lg-20">
                <a href="<?php echo $Web->seller_url(); ?>" class="mb-12">
                    <img alt="Logo" src="<?php echo $Web->seller_logo(); ?>" class="h-40px" />
                </a>

                <div class="w-lg-500px mw-500px bg-body rounded shadow-sm p-10 p-lg-15 mx-auto">
                    <form class="step-3 form w-100" novalidate="novalidate" id="userRegisterForm">
                        <div class="mb-10 text-center">
                            <h1 class="text-dark mb-3">Create your account on <?php echo $Web->web_name(); ?></h1>
                        </div>
                        <div class="row fv-row mb-7">
                            <div class="col-xl-6">
                                <label class="form-label fw-bolder text-dark fs-6">First Name</label>
                                <input value="<?php echo  $registerDetails['first_name']; ?>" class="form-control form-control-lg" type="text" placeholder="" name="first_name" />
                            </div>
                            <div class="col-xl-6">
                                <label class="form-label fw-bolder text-dark fs-6">Last Name</label>
                                <input value="<?php echo  $registerDetails['last_name']; ?>" class="form-control form-control-lg" type="text" placeholder="" name="last_name" />
                            </div>
                        </div>
                        <div class="fv-row mb-7">
                            <label class="form-label fw-bolder text-dark fs-6">Email</label>
                            <input value="<?php echo  $registerDetails['user_email']; ?>" readonly class="form-control form-control-lg" type="email" placeholder="" name="email" />
                        </div>


                        <!--begin::Alert-->
                        <div class="alert alert-dismissible bg-light-primary border border-primary border-dashed border-2 d-flex flex-column flex-sm-row p-5 mb-10">
                            <span class="svg-icon svg-icon-2hx svg-icon-primary me-4 mb-5 mb-sm-0">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black"></rect>
                                    <rect x="11" y="14" width="7" height="2" rx="1" transform="rotate(-90 11 14)" fill="black"></rect>
                                    <rect x="11" y="17" width="2" height="2" rx="1" transform="rotate(-90 11 17)" fill="black"></rect>
                                </svg></span>
                            <div class="d-flex flex-column pe-0 pe-sm-10">
                                <span>Enter Password and Confirm Password for login with email also.</span>
                            </div>
                            <button type="button" class="position-absolute position-sm-relative m-2 m-sm-0 top-0 end-0 btn btn-icon ms-sm-auto" data-bs-dismiss="alert">
                                <i class="bi bi-x fs-1 text-primary"></i>
                            </button>
                        </div>
                        <!--end::Alert-->



                        <div class="mb-10 fv-row">
                            <label class="form-label fw-bolder text-dark fs-6">Password</label>
                            <input class="form-control form-control-lg" type="password" placeholder="" name="password" />
                        </div>

                        <div class="fv-row mb-5">
                            <label class="form-label fw-bolder text-dark fs-6">Confirm Password</label>
                            <input class="form-control form-control-lg" type="password" placeholder="" name="confirm_password" />
                        </div>

                        <div class="fv-row mb-10">
                            <label class="form-check form-check-custom form-check-solid form-check-inline">
                                <input class="form-check-input" type="checkbox" name="toc" value="1" />
                                <span class="form-check-label fw-bold text-gray-700 fs-6">I Agree
                                    <a href="#" class="ms-1 link-primary">Terms and conditions</a>.</span>
                            </label>
                        </div>
                        <div class="text-center">
                            <button type="submit" id="submit" class="btn btn-lg w-100 btn-primary">
                                <span class="indicator-label">Submit</span>
                                <span class="indicator-progress">Please wait...
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>

                    </form>
                </div>



            </div>

        </div>
    </div>


    <?php include $Web->include("partials/scripts.php"); ?>

    <script>
        LXUtil.onDOMContentLoaded((function() {
            Login.userGoogleRegister("seller");
        }));
    </script>

</body>

</html>