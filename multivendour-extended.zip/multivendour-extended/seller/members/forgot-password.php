<?php
require_once "../../db.php";
$Login->uncheck_seller_login();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Forgot Password - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body">

    <div class="d-flex flex-column flex-root">
        <div class="d-flex flex-column flex-column-fluid bgi-position-y-bottom position-x-center bgi-no-repeat bgi-size-contain bgi-attachment-fixed" style="background-repeat:inherit;background-image: url(<?php echo $Web->get_assets('images/web/login-bg.jpg'); ?>)">
            <div class="d-flex flex-center flex-column flex-column-fluid p-lg-2">
                <div class="login-card mw-550px py-16 px-10 px-lg-18 w-100 card mx-auto">

                    <form class="w-100" novalidate="novalidate" id="forForm" class="needs-validation">
                        <div class="justify-align-center flex-column">
                            <a href="<?php echo $Web->seller_url(); ?>" class="mb-6">
                                <img alt="Logo" src="<?php echo $Web->seller_logo(); ?>" class="h-40px" />
                            </a>
                        </div>
                        <div class="text-center mb-10">
                            <h1 class="text-dark mb-3">Forgot Password</h1>
                            <div class="text-gray-700 fw-bold fs-4">Enter the email to reset your password.</div>
                        </div>
                        <div class="fv-row mb-10">
                            <label class="form-label fs-6 fw-bold text-dark">Email</label>
                            <input required class="form-control form-control-lg" type="email" name="email" />
                            <div class="invalid-feedback">Email is required</div>
                        </div>

                        <button type="submit" id="submit" class="btn btn-lg btn-primary w-100 mb-5">Continue</button>

                        <div class="fw-bold text-center fs-6">Remembered Password?
                            <a href="<?php echo $Web->seller_url(); ?>/login" class="link-primary fw-bold">Login here</a>
                        </div>
                    </form>

                    <form class="w-100 d-none" novalidate="novalidate" id="otpForm" class="needs-validation">
                        <div class="justify-align-center flex-column">
                            <a href="<?php echo $Web->seller_url(); ?>" class="mb-6">
                                <img alt="Logo" src="<?php echo $Web->seller_logo(); ?>" class="h-40px" />
                            </a>
                        </div>

                        <div class="text-center mb-10">
                            <img alt="Logo" class="mh-125px" src="<?php echo $Web->get_assets("images/web/smartphone.svg"); ?>">
                        </div>
                        <div class="text-center mb-10">
                            <h1 class="text-dark mb-3">Verify otp</h1>
                        </div>

                        <div class="overflow-auto pb-5">
                            <div class="notice d-flex bg-light-success rounded border-success border border-2 border-dashed flex-shrink-0 p-6">
                                <span class="justify-align-center svg-icon svg-icon-2tx svg-icon-success me-4">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path d="M13 5.91517C15.8 6.41517 18 8.81519 18 11.8152C18 12.5152 17.9 13.2152 17.6 13.9152L20.1 15.3152C20.6 15.6152 21.4 15.4152 21.6 14.8152C21.9 13.9152 22.1 12.9152 22.1 11.8152C22.1 7.01519 18.8 3.11521 14.3 2.01521C13.7 1.91521 13.1 2.31521 13.1 3.01521V5.91517H13Z" fill="black"></path>
                                        <path opacity="0.3" d="M19.1 17.0152C19.7 17.3152 19.8 18.1152 19.3 18.5152C17.5 20.5152 14.9 21.7152 12 21.7152C9.1 21.7152 6.50001 20.5152 4.70001 18.5152C4.30001 18.0152 4.39999 17.3152 4.89999 17.0152L7.39999 15.6152C8.49999 16.9152 10.2 17.8152 12 17.8152C13.8 17.8152 15.5 17.0152 16.6 15.6152L19.1 17.0152ZM6.39999 13.9151C6.19999 13.2151 6 12.5152 6 11.8152C6 8.81517 8.2 6.41515 11 5.91515V3.01519C11 2.41519 10.4 1.91519 9.79999 2.01519C5.29999 3.01519 2 7.01517 2 11.8152C2 12.8152 2.2 13.8152 2.5 14.8152C2.7 15.4152 3.4 15.7152 4 15.3152L6.39999 13.9151Z" fill="black"></path>
                                    </svg>
                                </span>
                                <div class="text-center w-100">
                                    <h4 class="text-gray-900 fw-bolder">Enter the verification code sent to</h4>
                                    <a id="email_sent_to" class="fs-6 text-success pe-7"></a>
                                </div>
                            </div>
                        </div>

                        <div class="mb-8 px-md-10">
                            <div class="fw-bolder text-start text-dark fs-6 mb-3">Type the 6 digit otp code</div>
                            <div class="otp-form-group justify-align-center gap-2 gap-md-4">
                                <input maxlength="1" autocomplete="off" required name="1" type="text" class="form-control no-bg h-50px w-50px fs-2 text-center" data-mask="number">
                                <input maxlength="1" autocomplete="off" required name="2" type="text" class="form-control no-bg h-50px w-50px fs-2 text-center" data-mask="number">
                                <input maxlength="1" autocomplete="off" required name="3" type="text" class="form-control no-bg h-50px w-50px fs-2 text-center" data-mask="number">
                                <input maxlength="1" autocomplete="off" required name="4" type="text" class="form-control no-bg h-50px w-50px fs-2 text-center" data-mask="number">
                                <input maxlength="1" autocomplete="off" required name="5" type="text" class="form-control no-bg h-50px w-50px fs-2 text-center" data-mask="number">
                                <input maxlength="1" autocomplete="off" required name="6" type="text" class="form-control no-bg h-50px w-50px fs-2 text-center" data-mask="number">
                            </div>
                        </div>


                        <button type="submit" id="submit" class="btn btn-lg btn-primary w-100 mb-5">Continue</button>

                        <div class="text-center fw-bold fs-5">
                            <span class="text-muted me-1">Didn’t get the code ?</span>
                            <a id="resendOtp" class="link-primary cursor-pointer fw-bolder fs-5 me-1">Resend</a>
                        </div>

                    </form>

                    <form class="w-100 d-none" novalidate="novalidate" id="resForm" class="needs-validation">
                        <div class="justify-align-center flex-column">
                            <a href="<?php echo $Web->seller_url(); ?>" class="mb-6">
                                <img alt="Logo" src="<?php echo $Web->seller_logo(); ?>" class="h-40px" />
                            </a>
                        </div>

                        <div class="text-center mb-10">
                            <h1 class="text-dark mb-3">Reset Password</h1>
                            <div class="text-gray-700 fw-bold fs-4">Set a new password to reset your password.</div>
                        </div>

                        <div class="fv-row mb-10">
                            <label class="form-label fs-6 fw-bold text-dark">Email</label>
                            <input required readonly class="form-control form-control-lg" type="email" id="email" />
                        </div>

                        <div class="mb-10 fv-row">
                            <label class="form-label fw-bold text-dark fs-6">New Password</label>
                            <div class="position-relative">
                                <input required class="form-control no-bg password-input form-control-lg" type="password" placeholder="" name="password" />
                                <div class="show password-toggle">
                                    <svg class="show" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="-10 -10 47 38" style="stroke:#0c0c0d">
                                        <g style="stroke-width:2;fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round" transform="translate(1 1)">
                                            <path d="m0 8c0-2 5.5-8 11-8s11 6 11 8-5.5 8-11 8-11-6-11-8z" />
                                            <path d="m11 12c2.2091 0 4-1.7909 4-4 0-2.20914-1.7909-4-4-4-2.20914 0-4 1.79086-4 4 0 2.2091 1.79086 4 4 4z" />
                                            <path d="m13 7c.5523 0 1-.44772 1-1s-.4477-1-1-1-1 .44772-1 1 .4477 1 1 1z" fill="#000" fill-rule="nonzero" />
                                        </g>
                                    </svg>
                                    <svg class="hide" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="-10 -7 47 38" style="stroke:#0c0c0d">
                                        <g style="stroke-width:2;fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round" transform="translate(1 1)">
                                            <path d="m4.14 15.76c-2.44-1.76-4.14-4.13-4.14-5.22 0-1.91 5.27-7.66 10.54-7.66 1.8042928.06356301 3.559947.60164173 5.09 1.56m3.53 2.85c.954643.86366544 1.6242352 1.9970896 1.92 3.25 0 1.92-5.27 7.67-10.54 7.67-.82748303-.0073597-1.64946832-.1353738-2.44-.38" />
                                            <path d="m11.35 14.29c1.3567546-.2923172 2.4501897-1.2939955 2.86-2.62m-1.56-4.33c-1.5090443-.9785585-3.49511641-.77861361-4.77882585.48110127-1.28370945 1.25971488-1.52108848 3.24166123-.57117415 4.76889873" />
                                            <path d="m13.08 7.9c-.1699924-.15256531-.3916348-.2347875-.62-.23-.5522847 0-1 .44771525-1 1 .0046671.23144917.0894903.45410992.24.63" />
                                            <path d="m21.08 0-21.08 21.08" />
                                        </g>
                                    </svg>
                                </div>
                            </div>
                            <div class="invalid-feedback">Password is required</div>
                        </div>

                        <div class="fv-row mb-5">
                            <label class="form-label fw-bold text-dark fs-6">Confirm New Password</label>
                            <div class="position-relative">
                                <input required class="form-control no-bg password-input form-control-lg" type="password" placeholder="" name="confirm_password" />
                                <div class="show password-toggle">
                                    <svg class="show" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="-10 -10 47 38" style="stroke:#0c0c0d">
                                        <g style="stroke-width:2;fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round" transform="translate(1 1)">
                                            <path d="m0 8c0-2 5.5-8 11-8s11 6 11 8-5.5 8-11 8-11-6-11-8z" />
                                            <path d="m11 12c2.2091 0 4-1.7909 4-4 0-2.20914-1.7909-4-4-4-2.20914 0-4 1.79086-4 4 0 2.2091 1.79086 4 4 4z" />
                                            <path d="m13 7c.5523 0 1-.44772 1-1s-.4477-1-1-1-1 .44772-1 1 .4477 1 1 1z" fill="#000" fill-rule="nonzero" />
                                        </g>
                                    </svg>
                                    <svg class="hide" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="-10 -7 47 38" style="stroke:#0c0c0d">
                                        <g style="stroke-width:2;fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round" transform="translate(1 1)">
                                            <path d="m4.14 15.76c-2.44-1.76-4.14-4.13-4.14-5.22 0-1.91 5.27-7.66 10.54-7.66 1.8042928.06356301 3.559947.60164173 5.09 1.56m3.53 2.85c.954643.86366544 1.6242352 1.9970896 1.92 3.25 0 1.92-5.27 7.67-10.54 7.67-.82748303-.0073597-1.64946832-.1353738-2.44-.38" />
                                            <path d="m11.35 14.29c1.3567546-.2923172 2.4501897-1.2939955 2.86-2.62m-1.56-4.33c-1.5090443-.9785585-3.49511641-.77861361-4.77882585.48110127-1.28370945 1.25971488-1.52108848 3.24166123-.57117415 4.76889873" />
                                            <path d="m13.08 7.9c-.1699924-.15256531-.3916348-.2347875-.62-.23-.5522847 0-1 .44771525-1 1 .0046671.23144917.0894903.45410992.24.63" />
                                            <path d="m21.08 0-21.08 21.08" />
                                        </g>
                                    </svg>
                                </div>
                            </div>
                            <div class="invalid-feedback">Password is required</div>
                        </div>

                        <button type="submit" id="submit" class="btn btn-lg btn-primary w-100 mb-5">Reset Password</button>

                    </form>

                </div>
            </div>
        </div>
    </div>

    <?php include $Web->include("partials/scripts.php"); ?>

    <script>
        LXUtil.onDOMContentLoaded(() => {
            Login.userForgotPassword("seller");
        });
    </script>

</body>

</html>