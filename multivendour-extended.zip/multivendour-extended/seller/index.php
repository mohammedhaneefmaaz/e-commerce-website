<?php
require_once "../db.php";
$Login->uncheck_seller_login();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title><?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>

    <style>
        .title.style-3 {
            background-image: url(<?php echo $Web->get_assets("images/ecommerce/seller/wave.png"); ?>);
            background-position: center bottom;
            background-repeat: no-repeat;
            padding-bottom: 25px;
        }

        .mb-40 {
            margin-bottom: 40px !important;
        }

        h1 {
            font-size: 48px;
        }

        p {
            font-size: 1rem;
            font-weight: 400;
            line-height: 24px;
            margin-bottom: 5px;
            color: #7E7E7E;
        }

        .font-xl {
            font-size: 19px;
        }

        .featured-card {
            padding: 50px 30px;
            border-radius: 15px;
            border: 1px solid #ececec;
            background: #fff;
        }

        .featured-card h4 {
            margin-bottom: 30px;
        }

        h4 {
            font-size: 24px;
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        .font-heading,
        .display-1,
        .display-2,
        .heading-sm-1 {
            font-family: "Quicksand", sans-serif;
            color: #253D4E;
            font-weight: 700;
            line-height: 1.2;
        }

        .single-content h3 {
            font-size: 36px;
            line-height: 48px;
            margin-bottom: 28px;
        }

        .single-content p {
            color: #253D4E;
            font-size: 17px;
        }

        .single-content p {
            margin-bottom: 1.2em;
            font-weight: 400;
        }

        .mb-30 {
            margin-bottom: 30px !important;
        }

        .mt-30 {
            margin-top: 30px !important;
        }

        .mb-50 {
            margin-bottom: 50px !important;
        }

        .py-50 {
            padding-top: 50px !important;
            padding-bottom: 50px !important;
        }

        .mb-80 {
            margin-bottom: 80px !important;
        }

        #lx_header_nav,#lx_header_menu{
            visibility: hidden !important;
        }
    </style>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/seller/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div class="post d-flex flex-column-fluid" id="lx_post">
                        <div id="lx_content_container" class="container-xxl">

                            <div class="card py-50">
                                <div class="row">
                                    <div class="col-lg-8 mx-auto text-center">
                                        <h1 class="title heading-1 style-3 mb-40">Start an online retail business with <span class="text-primary"><?php echo $Web->web_name(); ?></span> today</h1>
                                        <p class="font-xl mb-80">Sell your products and accept all type of payments from buying customers. <?php echo $Web->web_name(); ?> gives you everything you need to run a successful online store.</p>
                                    </div>
                                    <div class="col-xl-10 col-lg-12 m-auto">
                                        <section class="text-center mb-50">
                                            <div class="row">
                                                <div class="col-lg-4 col-md-6 mb-24">
                                                    <div class="featured-card">
                                                        <img src="<?php echo $Web->get_assets("images/ecommerce/seller/icon-1.svg"); ?>" alt="">
                                                        <h4>Best Prices &amp; Offers</h4>
                                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form</p>
                                                        <a href="#">Read more</a>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 col-md-6 mb-24">
                                                    <div class="featured-card">
                                                        <img src="<?php echo $Web->get_assets("images/ecommerce/seller/icon-2.svg"); ?>" alt="">
                                                        <h4>Wide Assortment</h4>
                                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form</p>
                                                        <a href="#">Read more</a>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 col-md-6 mb-24">
                                                    <div class="featured-card">
                                                        <img src="<?php echo $Web->get_assets("images/ecommerce/seller/icon-3.svg"); ?>" alt="">
                                                        <h4>Free Delivery</h4>
                                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form</p>
                                                        <a href="#">Read more</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                    <div class="col-xl-8 col-lg-12 mx-auto">
                                        <div class="single-content">
                                            <h3>1. Account Registering</h3>
                                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla modi dolores neque omnis ipsa? Quia, nam voluptas! Aut, magnam molestias:</p>
                                            <ul class="mb-30">
                                                <li>Name (required)</li>
                                                <li>Age (required)</li>
                                                <li>Date of birth (required)</li>
                                                <li>Passport/ ID no. (required)</li>
                                                <li>Current career (required)</li>
                                                <li>Mobile phone numbers (required)</li>
                                                <li>Email address (required)</li>
                                                <li>Hobbies &amp; interests (optional)</li>
                                                <li>Social profiles (optional)</li>
                                            </ul>
                                            <h3>2. Choose a package</h3>
                                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit officia necessitatibus repellat placeat aut enim recusandae assumenda adipisci quisquam, deserunt iure veritatis cupiditate modi aspernatur accusantium, mollitia doloribus. Velit, iste.</p>
                                            <h3>3. Add your products</h3>
                                            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Libero ut autem sed! Assumenda, nostrum non doloribus tenetur, pariatur veritatis harum natus ipsam maiores dolorem repudiandae laboriosam, cupiditate odio earum eum?</p>
                                            <h3>4. Start selling</h3>
                                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam nesciunt nam aut magnam libero aspernatur eaque praesentium? Tempore labore quis neque? Magni.</p>
                                            <h3>5. Accepted Credit Cards</h3>
                                            <ul>
                                                <li>Visa</li>
                                                <li>Mastercards</li>
                                                <li>American Express</li>
                                                <li>Discover</li>
                                            </ul>
                                            <span>*Taxes are calculated by your local bank and location.</span>
                                            <h3 class="mt-30">6. Get money</h3>
                                            <ul>
                                                <li>Updated content on a regular basis</li>
                                                <li>Secure &amp; hassle-free payment</li>
                                                <li>1-click checkout</li>
                                                <li>Easy access &amp; smart user dashboard</li>
                                            </ul>
                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <?php include $Web->include("partials/seller/footer.php"); ?>


            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>

</body>


</html>