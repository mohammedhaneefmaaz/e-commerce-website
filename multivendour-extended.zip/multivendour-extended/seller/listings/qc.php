<?php
require_once "../../db.php";
$Login->check_seller_login();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>QC - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/seller/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <div class="card card-flush">
                            <ul class="nav px-6 py-2 nav-tabs nav-line-tabs nav-line-tabs-2x fs-6">
                                <li class="nav-item">
                                    <a class="nav-link active" href="<?php echo $Web->seller_url() . '/listings/'; ?>qc">In QC</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo $Web->seller_url() . '/listings/'; ?>draft">Draft Listings</a>
                                </li>
                            </ul>

                            <div class="card-header">
                                <div class="card-title">
                                    <h2>Listings in QC</h2>
                                </div>
                                <div class="card-toolbar">
                                    <div class="d-flex align-items-center fw-bolder">
                                        <div class="text-muted fs-7 me-2">Status</div>
                                        <select autocomplete="off" id="qc_status" class="form-select form-select-transparent text-dark fs-7 lh-1 fw-bolder py-0 ps-3 w-auto select2-hidden-accessible" data-control="select2" data-hide-search="true" data-dropdown-css-class="w-150px" data-placeholder="Select an option">
                                            <option value="all">All</option>
                                            <option value="pending">QC in Pending</option>
                                            <option value="rejected">QC Rejected</option>
                                            <option value="approved">QC Approved</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body pt-0">
                                <table class="table align-middle table-row-dashed fs-6 gy-5" id="data_table">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                            <th class="min-w-50px">#</th>
                                            <th class="min-w-200px mw-300px">Product Details</th>
                                            <th class="min-w-50px">Requested Date</th>
                                            <th class="min-w-50px">Response Date</th>
                                            <th class="min-w-150px">Status</th>
                                            <th class="min-w-50px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-bold text-gray-600">

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <?php include $Web->include("partials/seller/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/datatables.bundle.js"); ?>" "></script>

<script>  setActiveNavItem(location.pathname);
Seller.myListings().qc();
</script>

</body>


</html>