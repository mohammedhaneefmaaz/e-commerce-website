<?php
require_once "../../db.php";
$Login->check_seller_login();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>New Orders - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/seller/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <div class="card card-flush">
                            <ul class="nav px-6 py-2 nav-tabs nav-line-tabs nav-line-tabs-2x fs-6">
                                <li class="nav-item">
                                    <a class="nav-link active" href="<?php echo $Web->seller_url() . '/orders/'; ?>">New Orders</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo $Web->seller_url() . '/orders/'; ?>rtd">Pending RTD</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo $Web->seller_url() . '/orders/'; ?>handover">Pending Handover</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo $Web->seller_url() . '/orders/'; ?>scheduled-pickups">Scheduled Pickups</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo $Web->seller_url() . '/orders/'; ?>shipped">Shipped Orders</a>
                                </li>
                                <li class="nav-item ms-auto">
                                    <a class="nav-link" href="<?php echo $Web->seller_url() . '/orders/'; ?>cancelled">Cancelled Orders</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo $Web->seller_url() . '/orders/'; ?>rejected">Rejected Orders</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo $Web->seller_url() . '/orders/'; ?>completed">Completed Orders</a>
                                </li>
                            </ul>

                            <div class="card-header">
                                <div class="card-title">
                                    <h2>New Orders</h2>
                                </div>
                                <div class="card-toolbar">
                                    <div class="me-2"> With Selected:-</div>
                                    <div class="d-flex w-100 w-md-auto flex-wrap gap-2 mt-4 mt-md-0">
                                        <button disabled id="cancel" class="w-100 w-md-auto btn btn-danger">Reject Order</button>
                                        <button disabled id="accept" class="btn w-100 w-md-auto btn-warning">Generate Label</button>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body pt-0">
                                <table class="table align-middle table-row-dashed fs-6 gy-5" id="data_table">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                            <th class="min-w-50px">#</th>
                                            <th>
                                                <div class="form-check form-check-sm form-check-custom form-check-solid">
                                                    <input autocomplete="off" class="form-check-input" type="checkbox" data-check-selector="true">
                                                </div>
                                            </th>
                                            <th class="min-w-100px">Order Id</th>
                                            <th class="min-w-150px">Product Details</th>
                                            <th class="min-w-150px">Buyer Name</th>
                                            <th class="min-w-50px">Quantity</th>
                                            <th class="min-w-100px">Amount</th>
                                            <th class="min-w-150px">Order Date</th>
                                            <th class="min-w-50px">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-bold text-gray-600">

                                    </tbody>
                                </table>
                            </div>
                        </div>



                    </div>
                </div>

                <?php include $Web->include("partials/seller/footer.php"); ?>
            </div>
        </div>
    </div>

    <div class="modal fade" id="cancelOrderModal" tabindex="-1" style="display: none;" aria-hidden="true">
        <div class="modal-dialog mw-650px">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="fw-bolder">Reject Order</h2>
                    <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                        <span class="svg-icon svg-icon-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                            </svg>
                        </span>
                    </div>
                </div>
                <div class="modal-body scroll-y">
                    <form default-validation="true" novalidate="" class="">
                        <div id="orders_id"></div>
                        <div class="fv-row mb-7">
                            <label class="required form-label mb-2"> Reason For Rejection</label>
                            <textarea maxlength="3000" rows="5" type="text" class="form-control form-control-solid" required name="reason"></textarea>
                            <div class="invalid-feedback">Reason For Rejection is required</div>
                        </div>

                        <div class="justify-right">
                            <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                            <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/datatables.bundle.js"); ?>"></script>
    <script>
        setActiveNavItem();
        Seller.Orders.active();
    </script>

</body>


</html>