<?php
require_once "../../db.php";
$Login->check_seller_login();


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Add Ticket - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <div class="wrapper d-flex flex-column flex-row-fluid">
                <?php include $Web->include("partials/seller/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid">
                    <div id="lx_content_container" class="container-xxl">

                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">
                                    <h3>Add Ticket</h3>
                                </div>
                            </div>
                            <div class="card-body">
                                <form id="addTicketForm" novalidate class="form">
                                <input type="hidden" name="case" value="add_ticket">
                                    <div class="d-flex flex-column mb-5 fv-row">
                                        <label class="required fs-5 fw-bold mb-2">Subject</label>
                                        <input required class="form-control form-control-solid" placeholder="" name="subject" />
                                        <div class="invalid-feedback">Subject is required</div>
                                    </div>
                                    <div class="d-flex flex-column mb-5 fv-row">
                                        <label class="required fs-5 fw-bold mb-2">Message </label>
                                        <textarea required rows="8" class="form-control form-control-solid" placeholder="" name="message"></textarea>
                                        <div class="invalid-feedback">Message is required</div>
                                    </div>
                                    <div class="d-flex flex-column mb-5 fv-row">
                                        <label class="fs-5 fw-bold mb-2">Add Files <small class="text-muted">(optional)</small></label>
                                        <div class="d-flex gap-4">
                                            <div id="uploadImg" class="active position-relative cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-80px">
                                                <span class="svg-icon svg-icon-muted svg-icon-4x">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM16 13.5L12.5 13V10C12.5 9.4 12.6 9.5 12 9.5C11.4 9.5 11.5 9.4 11.5 10L11 13L8 13.5C7.4 13.5 7 13.4 7 14C7 14.6 7.4 14.5 8 14.5H11V18C11 18.6 11.4 19 12 19C12.6 19 12.5 18.6 12.5 18V14.5L16 14C16.6 14 17 14.6 17 14C17 13.4 16.6 13.5 16 13.5Z" fill="black" />
                                                        <rect x="11" y="19" width="10" height="2" rx="1" transform="rotate(-90 11 19)" fill="black" />
                                                        <rect x="7" y="13" width="10" height="2" rx="1" fill="black" />
                                                        <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black" />
                                                    </svg>
                                                </span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="justify-right">
                                        <a href="./" type="button" class="btn btn-lg btn-light me-3">Cancel</a>
                                        <button type="submit" class="btn btn-lg btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
                <?php include $Web->include("partials/seller/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script>
        Seller.Support.addTicket();
    </script>
</body>

</html>