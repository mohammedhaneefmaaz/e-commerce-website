<?php
require_once "../../db.php";
$Login->check_seller_login();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Support - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <div class="wrapper d-flex flex-column flex-row-fluid">
                <?php include $Web->include("partials/seller/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid">
                    <div id="lx_content_container" class="container-xxl">

                        <div class="card">
                            <div class="card-header">
                                <div class="card-title flex-column">
                                    <h3>Support</h3>
                                    <div class="text-muted fs-7"> List of ticket opened by you </div>
                                </div>
                                <div class="card-toolbar">
                                    <a href="add-ticket" type="button" class="btn btn-sm btn-flex btn-light-primary" id="log_out_all_sessions">
                                        <span class="svg-icon svg-icon-3">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <rect opacity="0.5" x="11.364" y="20.364" width="16" height="2" rx="1" transform="rotate(-90 11.364 20.364)" fill="black" />
                                                <rect x="4.36396" y="11.364" width="16" height="2" rx="1" fill="black" />
                                            </svg>
                                        </span>Add a ticket</a>
                                </div>
                            </div>
                            <div class="card-body">
                                <table id="dataTbl" class="table align-middle table-row-dashed fs-6 gy-5">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                            <th>#</th>
                                            <th class="min-w-150px">Subject</th>
                                            <th class="min-w-50px">Status</th>
                                            <th class="min-w-200px mw-250px">Date Created</th>
                                            <th>View</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-bold text-gray-600">

                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>
                <?php include $Web->include("partials/seller/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/datatables.bundle.js"); ?>"></script>

    <script>
        LXUtil.onDOMContentLoaded((function() {
            Seller.Support.init();
        }));
    </script>
</body>

</html>