<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

function exception_error_handler($severity, $message, $file, $line)
{
    if (!(error_reporting() & $severity)) {
        // This error code is not included in error_reporting
        return;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
}
set_error_handler("exception_error_handler");

$DOCUMENT_ROOT = $_SERVER["DOCUMENT_ROOT"];
$DOCUMENT_SUB_ROOT = str_replace(realpath($_SERVER["DOCUMENT_ROOT"]), "", realpath(__DIR__));
$DOCUMENT_SUB_ROOT = str_replace("\\", "/", $DOCUMENT_SUB_ROOT);
$DOCUMENT_ROOT = $DOCUMENT_ROOT . $DOCUMENT_SUB_ROOT;
define('ROOT', $DOCUMENT_ROOT);
define('BASE', basename(__DIR__));

$HTTP_ROOT = (!empty($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/' . BASE;


class DB
{
    // db_host_name
public $host = "localhost";
    // db_user_name
public $userName = "root";
    // db_password
public $password = "";
    // db_name
public $dbName = "acart_testing";

    public function connect()
    {
        try {
            $db = "mysql:host=$this->host;dbname=$this->dbName;";
            $conn =  new PDO($db, $this->userName, $this->password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
            $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
            return $conn;
        } catch (PDOException $e) {
            return false;
        }
    }
}

class Basics
{
    public static $base_url;
    public static $absolute_base_url;
    public static $seller_url;
    public static $seller_absolute_url;
    public static $admin_url;
    public static $currency = "₹";
    public static $web_name = "Jamscart";
    public static $ajax_error = "Something went wrong";
    public static $currency_position = "prefix";
    public static $timezone = "Asia/Kolkata";
    public static $primary_color = "0,158,246";
    public static $last_updated = "238957948"; // Change to clear cache
    public static $testingEmail = "princeraj9137@gmail.com";
    public static $testingEmailPassword = "admin";
}


Basics::$base_url = $DOCUMENT_SUB_ROOT;
Basics::$seller_url = $DOCUMENT_SUB_ROOT . "/seller";
Basics::$absolute_base_url = $HTTP_ROOT;
Basics::$seller_absolute_url = $HTTP_ROOT . "/seller";
Basics::$admin_url = $DOCUMENT_SUB_ROOT . "/admin";

$conn = new DB();
$db = $conn->connect();

if (!$db && empty($installPage)) {
    $install_url = $DOCUMENT_SUB_ROOT . "/install/";
    header("location:$install_url");
    exit();
}

require_once "assets/php/functions.php";

if ($db && isset($installPage) && $installPage == "1") {
    Errors::response_404();
}

if ($db) {
    date_default_timezone_set($Web->timezone());
}

// #008080


