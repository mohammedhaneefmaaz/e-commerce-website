<?php
require_once "db.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Search - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <div class="wrapper d-flex flex-column flex-row-fluid">
                <?php include $Web->include("partials/visitor/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid">
                </div>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script>
        $(".search-container").removeClass("d-none");
        $("#searchProducts").find("input").trigger("focus");
    </script>
</body>
</html>