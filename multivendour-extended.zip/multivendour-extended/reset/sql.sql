-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 10, 2022 at 01:44 AM
-- Server version: 10.3.35-MariaDB-log-cll-lve
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `magirtzm_jcart2`
--

-- --------------------------------------------------------

--
-- Table structure for table `check_google_signup`
--

CREATE TABLE `check_google_signup` (
  `serial_id` bigint(255) NOT NULL,
  `google_id` varchar(100) NOT NULL,
  `google_email` varchar(255) NOT NULL,
  `type` enum('login','register') NOT NULL,
  `details` text NOT NULL,
  `status` enum('1','2') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `check_google_signup`
--

INSERT INTO `check_google_signup` (`serial_id`, `google_id`, `google_email`, `type`, `details`, `status`) VALUES
(1, '31751691660069086', 'jaicky79003@gmail.com', 'register', 'a:4:{s:10:\"first_name\";s:6:\"Jaicky\";s:9:\"last_name\";s:5:\"Kumar\";s:10:\"user_email\";s:21:\"jaicky79003@gmail.com\";s:5:\"event\";s:1:\"2\";}', '2'),
(2, '99955371660069107', 'jaickykumar7903@gmail.com', 'login', 'a:2:{s:10:\"user_email\";s:25:\"jaickykumar7903@gmail.com\";s:5:\"error\";s:22:\"Account does not exist\";}', '1'),
(3, '15609431660069115', 'jaickykumar7903@gmail.com', 'login', 'a:2:{s:10:\"user_email\";s:25:\"jaickykumar7903@gmail.com\";s:5:\"error\";s:22:\"Account does not exist\";}', '1');

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_answer_rating`
--

CREATE TABLE `ecommerce_answer_rating` (
  `id` bigint(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `question_id` bigint(255) NOT NULL,
  `answer_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `action` enum('like','dislike') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_category`
--

CREATE TABLE `ecommerce_category` (
  `category_id` bigint(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `parent_id` bigint(255) NOT NULL,
  `level` bigint(255) NOT NULL,
  `has_details` enum('no','yes') NOT NULL DEFAULT 'no',
  `images` text DEFAULT NULL,
  `variations` text DEFAULT NULL,
  `status` enum('draft','active','archived','rejected') NOT NULL DEFAULT 'draft',
  `data` longtext DEFAULT NULL,
  `has_content` enum('no','yes') NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecommerce_category`
--

INSERT INTO `ecommerce_category` (`category_id`, `category`, `parent_id`, `level`, `has_details`, `images`, `variations`, `status`, `data`, `has_content`) VALUES
(1, 'Clothing &amp; Accessories', 0, 0, 'no', NULL, NULL, 'active', NULL, 'no'),
(2, 'Topwear', 1, 1, 'no', NULL, NULL, 'active', NULL, 'no'),
(3, 'T-Shirts', 2, 2, 'yes', '[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\"]', '{\"1660064532742\":{\"name\":\"Colour\",\"custom_select_id\":\"\",\"type\":\"image\",\"detail_id\":\"2\",\"select_id\":\"\",\"role\":\"parent\",\"selectOptions\":[]},\"1660064547315\":{\"name\":\"Size\",\"custom_select_id\":\"\",\"type\":\"select\",\"detail_id\":\"\",\"select_id\":\"5\",\"role\":\"child\",\"selectOptions\":[]}}', 'active', '{\"images\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\"],\"variations\":{\"1660064532742\":{\"name\":\"Colour\",\"custom_select_id\":\"\",\"type\":\"image\",\"detail_id\":\"2\",\"select_id\":\"\",\"role\":\"parent\",\"selectOptions\":[]},\"1660064547315\":{\"name\":\"Size\",\"custom_select_id\":\"\",\"type\":\"select\",\"detail_id\":\"\",\"select_id\":\"5\",\"role\":\"child\",\"selectOptions\":[]}},\"details\":{\"1\":{\"custom_select_id\":\"\",\"mandatory\":\"yes\",\"option_text\":\"Size\",\"option_type\":\"select\",\"select_id\":\"5\",\"filter\":\"yes\",\"selectOptions\":[]},\"2\":{\"custom_select_id\":\"\",\"mandatory\":\"yes\",\"option_text\":\"Colour\",\"option_type\":\"select\",\"select_id\":\"2\",\"filter\":\"yes\",\"selectOptions\":[]},\"3\":{\"custom_select_id\":\"\",\"mandatory\":\"yes\",\"option_text\":\"Ideal for\",\"option_type\":\"select\",\"select_id\":\"1\",\"filter\":\"yes\",\"selectOptions\":[]},\"4\":{\"custom_select_id\":\"\",\"mandatory\":\"yes\",\"option_text\":\"Neck Style\",\"option_type\":\"select\",\"select_id\":\"10\",\"filter\":\"no\",\"selectOptions\":[]},\"5\":{\"custom_select_id\":\"\",\"mandatory\":\"yes\",\"option_text\":\"Style Name\",\"option_type\":\"select\",\"select_id\":\"4\",\"filter\":\"yes\",\"selectOptions\":[]},\"6\":{\"custom_select_id\":\"\",\"mandatory\":\"yes\",\"option_text\":\"Sleeve Type\",\"option_type\":\"select\",\"select_id\":\"7\",\"filter\":\"no\",\"selectOptions\":[]},\"7\":{\"custom_select_id\":\"\",\"mandatory\":\"yes\",\"option_text\":\"Material Type\",\"option_type\":\"select\",\"select_id\":\"6\",\"filter\":\"no\",\"selectOptions\":[]},\"8\":{\"custom_select_id\":\"\",\"mandatory\":\"yes\",\"option_text\":\"Product Care Instructions\",\"option_type\":\"select\",\"select_id\":\"3\",\"filter\":\"no\",\"selectOptions\":[]},\"9\":{\"custom_select_id\":\"\",\"mandatory\":\"yes\",\"option_text\":\"Country Of Origin\",\"option_type\":\"select\",\"select_id\":\"12\",\"filter\":\"no\",\"selectOptions\":[]},\"10\":{\"custom_select_id\":\"\",\"mandatory\":\"yes\",\"option_text\":\"Pattern\",\"option_type\":\"select\",\"select_id\":\"8\",\"filter\":\"no\",\"selectOptions\":[]}},\"deldetails\":[],\"maxImages\":8,\"currentImages\":8}', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_category_details`
--

CREATE TABLE `ecommerce_category_details` (
  `detail_id` bigint(255) NOT NULL,
  `category_id` bigint(255) NOT NULL,
  `mandatory` varchar(255) NOT NULL,
  `option_text` varchar(255) NOT NULL,
  `option_type` varchar(255) NOT NULL,
  `select_id` varchar(255) NOT NULL,
  `filter` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecommerce_category_details`
--

INSERT INTO `ecommerce_category_details` (`detail_id`, `category_id`, `mandatory`, `option_text`, `option_type`, `select_id`, `filter`) VALUES
(1, 3, 'yes', 'Size', 'select', '5', 'yes'),
(2, 3, 'yes', 'Colour', 'select', '2', 'yes'),
(3, 3, 'yes', 'Ideal for', 'select', '1', 'yes'),
(4, 3, 'yes', 'Neck Style', 'select', '10', 'no'),
(5, 3, 'yes', 'Style Name', 'select', '4', 'yes'),
(6, 3, 'yes', 'Sleeve Type', 'select', '7', 'no'),
(7, 3, 'yes', 'Material Type', 'select', '6', 'no'),
(8, 3, 'yes', 'Product Care Instructions', 'select', '3', 'no'),
(9, 3, 'yes', 'Country Of Origin', 'select', '12', 'no'),
(10, 3, 'yes', 'Pattern', 'select', '8', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_courier`
--

CREATE TABLE `ecommerce_courier` (
  `courier_id` bigint(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `url` varchar(1000) NOT NULL,
  `status` enum('active','deleted') NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_listing`
--

CREATE TABLE `ecommerce_listing` (
  `listing_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `category_id` bigint(255) NOT NULL,
  `category_variation` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecommerce_listing`
--

INSERT INTO `ecommerce_listing` (`listing_id`, `user_id`, `category_id`, `category_variation`) VALUES
(1, '1006090', 3, NULL),
(2, '1006090', 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_listing_variations`
--

CREATE TABLE `ecommerce_listing_variations` (
  `id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `listing_id` varchar(255) NOT NULL,
  `variation_id` varchar(255) NOT NULL,
  `svariation_id` varchar(255) NOT NULL,
  `variation_value` varchar(255) DEFAULT NULL,
  `svariation_value` varchar(255) DEFAULT NULL,
  `variation_data` text DEFAULT NULL,
  `svariation_data` text DEFAULT NULL,
  `details` text DEFAULT NULL,
  `images` text DEFAULT NULL,
  `price` bigint(255) DEFAULT NULL,
  `mrp` bigint(255) DEFAULT NULL,
  `stock` bigint(255) DEFAULT NULL,
  `low_stock_warning` int(21) DEFAULT NULL,
  `sku_id` varchar(21) DEFAULT NULL,
  `product_name` varchar(1000) DEFAULT NULL,
  `minimum_order` int(251) DEFAULT NULL,
  `maximum_order` int(251) DEFAULT NULL,
  `cod_status` enum('no','yes') DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT NULL,
  `return_policy` enum('no','replacement','return') DEFAULT NULL,
  `return_policy_days` varchar(100) DEFAULT NULL,
  `return_policy_tc` varchar(5000) DEFAULT NULL,
  `highlights` text DEFAULT NULL,
  `description` varchar(5000) DEFAULT NULL,
  `date_created` varchar(43) NOT NULL,
  `last_modified` varchar(43) NOT NULL,
  `is_draft` enum('no','yes') NOT NULL DEFAULT 'yes',
  `tags` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecommerce_listing_variations`
--

INSERT INTO `ecommerce_listing_variations` (`id`, `user_id`, `listing_id`, `variation_id`, `svariation_id`, `variation_value`, `svariation_value`, `variation_data`, `svariation_data`, `details`, `images`, `price`, `mrp`, `stock`, `low_stock_warning`, `sku_id`, `product_name`, `minimum_order`, `maximum_order`, `cod_status`, `status`, `return_policy`, `return_policy_days`, `return_policy_tc`, `highlights`, `description`, `date_created`, `last_modified`, `is_draft`, `tags`) VALUES
(1, '1006090', '1', '9719859216662f29d8e2d2af', '6772391462162f29d8e2d408', 'Grey', 'M', '{\"type\":\"image\",\"id\":\"63\"}', '{\"type\":\"select\"}', '{\"1\":\"M\",\"2\":\"Grey\",\"3\":\"Men\",\"4\":\"Polo\",\"5\":\"Polo\",\"6\":\"HalfSleeve\",\"7\":\"Cotton\",\"8\":\"Hand-wash\",\"9\":\"India\"}', '{\"1\":{\"id\":\"65\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/8967209166006727216600672727992ba42-2c50-45b8-9852-d6ae2ea00418.jpg\",\"type\":\"image\"},\"2\":{\"id\":\"66\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/3984251166006727516600672750394cf49-1f25-4a4e-931a-4618210d4f79.jpg\",\"type\":\"image\"},\"3\":{\"id\":\"67\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/83454911660067278166006727824692e76-ed46-407b-b3b3-4b9ef4089c71.jpg\",\"type\":\"image\"},\"4\":{\"id\":\"68\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/264483216600672831660067283160e056e-dd42-4a52-b680-2ab509c8745b.jpg\",\"type\":\"image\"},\"5\":{\"id\":\"69\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/989298116600672901660067290c79d31e2-91bb-400f-a9f8-543a6c7f4d4a.jpg\",\"type\":\"image\"},\"6\":{\"id\":\"70\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/226907616600672941660067294343e0486-8af3-4177-bf05-46711bb51a80.jpg\",\"type\":\"image\"},\"7\":{\"id\":\"\",\"src\":null,\"type\":\"image\"},\"8\":{\"id\":\"\",\"src\":null,\"type\":\"video\"}}', 499, 999, 12, 10, 'grey', 'Grey melange and navy half sleeve polo T-shirt', 1, 10, 'yes', 'active', 'no', '0', NULL, '[\"half sleeve polo T-shirt\",\"Grey melange and navy half sleeve polo T-shirt\"]', '', '1660067214', '1660067214', 'no', '[{\"value\":\"half sleeve polo T-shirt\"},{\"value\":\"men tshirt\"}]'),
(2, '1006090', '1', '9719859216662f29d8e2d2af', '1278207494262f29f5d764a4', 'Grey', 'L', '{\"type\":\"image\",\"id\":\"63\"}', '{\"type\":\"select\"}', '{\"1\":\"L\",\"2\":\"Grey\",\"3\":\"Men\",\"4\":\"Polo\",\"5\":\"Polo\",\"6\":\"HalfSleeve\",\"7\":\"Cotton\",\"8\":\"Hand-wash\",\"9\":\"India\"}', '{\"1\":{\"id\":\"65\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/8967209166006727216600672727992ba42-2c50-45b8-9852-d6ae2ea00418.jpg\",\"type\":\"image\"},\"2\":{\"id\":\"66\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/3984251166006727516600672750394cf49-1f25-4a4e-931a-4618210d4f79.jpg\",\"type\":\"image\"},\"3\":{\"id\":\"67\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/83454911660067278166006727824692e76-ed46-407b-b3b3-4b9ef4089c71.jpg\",\"type\":\"image\"},\"4\":{\"id\":\"68\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/264483216600672831660067283160e056e-dd42-4a52-b680-2ab509c8745b.jpg\",\"type\":\"image\"},\"5\":{\"id\":\"69\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/989298116600672901660067290c79d31e2-91bb-400f-a9f8-543a6c7f4d4a.jpg\",\"type\":\"image\"},\"6\":{\"id\":\"70\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/226907616600672941660067294343e0486-8af3-4177-bf05-46711bb51a80.jpg\",\"type\":\"image\"},\"7\":{\"id\":\"\",\"src\":null,\"type\":\"image\"},\"8\":{\"id\":\"\",\"src\":null,\"type\":\"video\"}}', 499, 999, 12, 10, 'large', 'Grey melange and navy half sleeve polo T-shirt', 1, 10, 'yes', 'active', 'no', '0', NULL, '[\"half sleeve polo T-shirt\",\"Grey melange and navy half sleeve polo T-shirt\"]', '', '1660067677', '1660067677', 'no', '[{\"value\":\"half sleeve polo T-shirt\"},{\"value\":\"men tshirt\"}]'),
(3, '1006090', '2', '1561202040862f29fa6bc132', '8936677608962f29fa6bc270', 'Black', 'M', '{\"type\":\"image\",\"id\":\"71\"}', '{\"type\":\"select\"}', '{\"1\":\"M\",\"2\":\"Black\",\"3\":\"Women\",\"4\":\"Polo\",\"5\":\"Polo\",\"6\":\"HalfSleeve\",\"7\":\"Cotton\",\"8\":\"Hand-wash\",\"9\":\"India\"}', '{\"1\":{\"id\":\"72\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/460086116600677881660067788afa73247-4159-45fb-ac0b-6f9f793f7c0f.jpg\",\"type\":\"image\"},\"2\":{\"id\":\"73\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/6035672166006779216600677920d9833e5-6804-4b7d-956c-88ce8da32e53.jpg\",\"type\":\"image\"},\"3\":{\"id\":\"74\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/23548371660067794166006779415925a57-da92-4b2a-8f70-c6d278d171bc.jpg\",\"type\":\"image\"},\"4\":{\"id\":\"75\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/635816916600677971660067797705293a3-a46d-4ca8-bea8-22f8aa642821.jpg\",\"type\":\"image\"},\"5\":{\"id\":\"\",\"src\":null,\"type\":\"image\"},\"6\":{\"id\":\"\",\"src\":null,\"type\":\"image\"},\"7\":{\"id\":\"\",\"src\":null,\"type\":\"image\"},\"8\":{\"id\":\"\",\"src\":null,\"type\":\"video\"}}', 599, 999, 12, 10, 'print', 'Black assorted prints polo T-shirt', 1, 10, 'yes', 'active', 'replacement', '10', '10days', '[\"Black assorted prints polo T-shirt\"]', '', '1660067750', '1660067750', 'no', '[{\"value\":\"tshirt for girls\"},{\"value\":\"girls tshirt\"},{\"value\":\"Black assorted prints polo T-shirt\"}]'),
(4, '1006090', '2', '5318347839362f2a079ed68f', '8381390899062f2a079edb21', 'Black', 'M', '{\"type\":\"image\",\"id\":\"76\"}', '{\"type\":\"select\"}', '{\"1\":\"M\",\"2\":\"Black\",\"3\":\"Women\",\"4\":\"Polo\",\"5\":\"Polo\",\"6\":\"HalfSleeve\",\"7\":\"Cotton\",\"8\":\"Hand-wash\",\"9\":\"India\"}', '{\"1\":{\"id\":\"77\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/3810333166006797216600679724cf90222-67e2-448d-b50e-8abb448c8db1.jpg\",\"type\":\"image\"},\"2\":{\"id\":\"78\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/252312516600679741660067974130ee9a4-13a8-4417-9bc2-6cb663b64bc0.jpg\",\"type\":\"image\"},\"3\":{\"id\":\"79\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/4750747166006797716600679778f2e8fb1-d22c-49da-8c2e-a323c0222786.jpg\",\"type\":\"image\"},\"4\":{\"id\":\"80\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/585885016600679811660067981b60bfbd4-c0c3-454e-a14d-1c7f5458edbe.jpg\",\"type\":\"image\"},\"5\":{\"id\":\"81\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/759781816600679881660067988d6f00b88-a667-4cc7-b6c5-d6ef2f8c8680.jpg\",\"type\":\"image\"},\"6\":{\"id\":\"82\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/287310116600679931660067993a8219abd-2f5c-4d19-9341-ba51fbeb8b3a.jpg\",\"type\":\"image\"},\"7\":{\"id\":\"\",\"src\":null,\"type\":\"image\"},\"8\":{\"id\":\"\",\"src\":null,\"type\":\"video\"}}', 599, 999, 12, 10, 'red', 'Hibiscus assorted prints polo T-shirt', 1, 10, 'yes', 'active', 'replacement', '10', '10days', '[\"Hibiscus assorted prints polo T-shirt\"]', '', '1660067961', '1660067961', 'no', '[{\"value\":\"tshirt for girls\"},{\"value\":\"girls tshirt\"},{\"value\":\"Black assorted prints polo T-shirt\"},{\"value\":\"red tshirt\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_orders`
--

CREATE TABLE `ecommerce_orders` (
  `order_id` bigint(255) NOT NULL,
  `buyer_id` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `variation_id` varchar(255) NOT NULL,
  `svariation_id` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(65,2) NOT NULL,
  `total_price` decimal(65,2) NOT NULL,
  `shipping_charge` decimal(65,2) NOT NULL DEFAULT 0.00,
  `service_charge` decimal(65,2) NOT NULL DEFAULT 0.00,
  `grand_total` decimal(61,2) NOT NULL,
  `ordered_date` varchar(255) NOT NULL,
  `return_policy` text NOT NULL,
  `address` text NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `status` enum('PENDING','FAILED','SUCCESS','LABELLED','CANCELLED','RTD','SHIPPED','REJECTED','DELIVERED','REPLACEMENT','RETURNED','PICKUP_SCHEDULED') NOT NULL,
  `cancelled_on` varchar(255) DEFAULT NULL,
  `cancelled_reason` varchar(3000) DEFAULT NULL,
  `labelled_on` varchar(255) DEFAULT NULL,
  `rtd_on` varchar(255) DEFAULT NULL,
  `shipped_on` varchar(255) DEFAULT NULL,
  `delivered_on` varchar(255) DEFAULT NULL,
  `shipped_details` text DEFAULT NULL,
  `rejected_on` varchar(21) DEFAULT NULL,
  `rejected_reason` varchar(3000) DEFAULT NULL,
  `refund_status` enum('none','pending','completed') NOT NULL DEFAULT 'none',
  `refund_inited_on` varchar(255) DEFAULT NULL,
  `refund_comment` varchar(3000) DEFAULT NULL,
  `refund_date` varchar(255) DEFAULT NULL,
  `pickup_scheduled_on` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_order_transactions`
--

CREATE TABLE `ecommerce_order_transactions` (
  `id` bigint(255) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `razorpay_id` varchar(255) DEFAULT NULL,
  `buyer_id` varchar(255) NOT NULL,
  `orders` text NOT NULL,
  `payable_amount` bigint(255) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `status` varchar(100) NOT NULL,
  `transaction_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_products`
--

CREATE TABLE `ecommerce_products` (
  `product_id` bigint(255) NOT NULL,
  `listing_id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `category_id` bigint(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecommerce_products`
--

INSERT INTO `ecommerce_products` (`product_id`, `listing_id`, `user_id`, `category_id`) VALUES
(1, '1', '1006090', 3),
(2, '2', '1006090', 3);

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_product_answers_tbl`
--

CREATE TABLE `ecommerce_product_answers_tbl` (
  `answer_id` bigint(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `question_id` bigint(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `answer` varchar(1000) NOT NULL,
  `answered_by` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_product_questions_tbl`
--

CREATE TABLE `ecommerce_product_questions_tbl` (
  `question_id` bigint(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `question` varchar(100) NOT NULL,
  `date_asked` varchar(255) NOT NULL,
  `asker_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_product_views`
--

CREATE TABLE `ecommerce_product_views` (
  `view_id` bigint(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `variation_id` varchar(255) NOT NULL,
  `svariation_id` varchar(255) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `views` bigint(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `last_viewed` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecommerce_product_views`
--

INSERT INTO `ecommerce_product_views` (`view_id`, `product_id`, `variation_id`, `svariation_id`, `ip_address`, `views`, `date`, `last_viewed`) VALUES
(1, '1', '9719859216662f29d8e2d2af', '6772391462162f29d8e2d408', '103.199.200.76', 1, '1659983400', '1660067730'),
(2, '2', '1561202040862f29fa6bc132', '8936677608962f29fa6bc270', '103.199.200.76', 1, '1659983400', '1660068201'),
(3, '2', '5318347839362f2a079ed68f', '8381390899062f2a079edb21', '103.199.200.76', 1, '1660069800', '1660107163'),
(4, '1', '9719859216662f29d8e2d2af', '6772391462162f29d8e2d408', '103.199.200.76', 1, '1660069800', '1660110166');

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_qc`
--

CREATE TABLE `ecommerce_qc` (
  `qc_id` bigint(255) NOT NULL,
  `qvariation_id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `listing_id` varchar(255) NOT NULL,
  `variation_id` varchar(255) NOT NULL,
  `svariation_id` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL,
  `reject_reason` varchar(1000) DEFAULT NULL,
  `error_portions` text DEFAULT NULL,
  `date_requested` varchar(255) NOT NULL,
  `date_processed` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecommerce_qc`
--

INSERT INTO `ecommerce_qc` (`qc_id`, `qvariation_id`, `user_id`, `listing_id`, `variation_id`, `svariation_id`, `status`, `reject_reason`, `error_portions`, `date_requested`, `date_processed`) VALUES
(1, '83631296117', '1006090', '1', '9719859216662f29d8e2d2af', '6772391462162f29d8e2d408', 'approved', NULL, NULL, '1660067551', '1660067559'),
(2, '22534387277', '1006090', '1', '9719859216662f29d8e2d2af', '1278207494262f29f5d764a4', 'approved', NULL, NULL, '1660067698', '1660067706'),
(3, '87294225023', '1006090', '2', '5318347839362f2a079ed68f', '8381390899062f2a079edb21', 'approved', NULL, NULL, '1660068052', '1660068111'),
(4, '93860848997', '1006090', '2', '1561202040862f29fa6bc132', '8936677608962f29fa6bc270', 'approved', NULL, NULL, '1660068118', '1660068127');

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_replacement_orders`
--

CREATE TABLE `ecommerce_replacement_orders` (
  `replacement_id` bigint(255) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `requested_date` varchar(211) NOT NULL,
  `replacement_reason` varchar(3000) NOT NULL,
  `status` enum('initiated','accepted','rejected','cancelled','pickup_scheduled','completed') NOT NULL DEFAULT 'initiated',
  `processed_comment` varchar(3000) DEFAULT NULL,
  `accepted_on` varchar(211) DEFAULT NULL,
  `rejected_on` varchar(211) DEFAULT NULL,
  `completed_date` varchar(211) DEFAULT NULL,
  `pickup_scheduled_date` varchar(211) DEFAULT NULL,
  `pickup_scheduled_comment` varchar(3000) DEFAULT NULL,
  `cancelled_on` varchar(255) DEFAULT NULL,
  `new_order_id` varchar(255) DEFAULT NULL,
  `images` text NOT NULL,
  `refund_reason` varchar(3000) DEFAULT NULL,
  `return_shipping_charge` decimal(65,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_return_orders`
--

CREATE TABLE `ecommerce_return_orders` (
  `return_id` bigint(255) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `requested_date` varchar(211) NOT NULL,
  `return_reason` varchar(3000) NOT NULL,
  `status` enum('initiated','accepted','rejected','cancelled','pickup_scheduled','completed') NOT NULL DEFAULT 'initiated',
  `processed_comment` varchar(3000) DEFAULT NULL,
  `accepted_on` varchar(211) DEFAULT NULL,
  `rejected_on` varchar(211) DEFAULT NULL,
  `completed_date` varchar(211) DEFAULT NULL,
  `pickup_scheduled_date` varchar(211) DEFAULT NULL,
  `pickup_scheduled_comment` varchar(3000) DEFAULT NULL,
  `cancelled_on` varchar(255) DEFAULT NULL,
  `images` text NOT NULL,
  `return_shipping_charge` decimal(65,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_reviews_rating`
--

CREATE TABLE `ecommerce_reviews_rating` (
  `rating_id` bigint(255) NOT NULL,
  `review_id` bigint(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `action` enum('like','dislike') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_reviews_tbl`
--

CREATE TABLE `ecommerce_reviews_tbl` (
  `review_id` bigint(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `reviewed_by` varchar(255) NOT NULL,
  `rating` int(5) NOT NULL,
  `review` varchar(3000) NOT NULL,
  `images` varchar(200) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_search_relavance`
--

CREATE TABLE `ecommerce_search_relavance` (
  `relevance_id` bigint(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `variation_id` varchar(255) NOT NULL,
  `search_keyword` varchar(1000) NOT NULL,
  `views` bigint(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_select`
--

CREATE TABLE `ecommerce_select` (
  `select_id` bigint(255) NOT NULL,
  `select_heading` varchar(255) DEFAULT NULL,
  `options` longtext NOT NULL,
  `date_created` varchar(255) DEFAULT NULL,
  `last_modified` varchar(255) DEFAULT NULL,
  `is_temp` enum('no','yes') NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecommerce_select`
--

INSERT INTO `ecommerce_select` (`select_id`, `select_heading`, `options`, `date_created`, `last_modified`, `is_temp`) VALUES
(1, 'Gender', '[\"Women\",\"Men\",\"Girls\",\"Boys\",\"BabyGirl\",\"BabyBoy\",\"Men & Women\",\"Boys & Girls\",\"BabyBoy & BabyGirls\"]', '1660064033', '1660064033', 'no'),
(2, 'Colour', '[\"Brown\",\"Black\",\"Orange\",\"Beige\",\"Grey\",\"Maroon\",\"Gold\",\"Blue\",\"Assorted\",\"CharcoalGrey\",\"Multicolored\",\"Red\",\"Silver\",\"Off-White\",\"White\",\"Khaki\",\"Pink\",\"Purple\",\"Yellow\",\"Green\",\"Metallic\",\"DarkBlue\",\"DarkBrown\",\"DarkGreen\",\"LightBlue\",\"LightBrown\",\"LightGreen\",\"Nude\",\"Bronze\",\"Multicolor\",\"Turquoise\",\"Clear\"]', '1660064033', '1660064033', 'no'),
(3, 'Product Care Instructions', '[\"Hand-wash\",\"Machine-wash\",\"Dry Clean Only\",\"First Time Dry-Clean followed by hand wash\",\"First Time Dry-Clean followed by machine wash\",\"Hand Wash Only\"]', '1660064033', '1660064033', 'no'),
(4, 'Style Name', '[\"Regular\",\"A-Line\",\"Batwing\",\"Blouse\",\"ButtonUp\",\"Crop\",\"Boxy\",\"Cape\",\"ColdShoulder\",\"CutOut\",\"Empire\",\"Henley\",\"Hooded\",\"Jerseys\",\"Kaftan\",\"Layered\",\"Nursing\",\"Peasant\",\"Peplum\",\"Poncho\",\"Ruffles\",\"Tie-Ups\",\"Tunic\",\"Tuxedo\",\"Wrap\",\"Longline\",\"Polo\",\"Dress\",\"Cropped\",\"T-Shirt\",\"Camisole\",\"Business Casual\",\"Bodysuit\",\"Casual\",\"Puff Sleeve\",\"Tank\"]', '1660064033', '1660064033', 'no'),
(5, 'Size', '[ \"S\", \"XS\", \"2XS\", \"3XS\", \"4XS\", \"5XS\", \"M\", \"L\", \"XL\", \"2XL\", \"3XL\", \"4XL\", \"5XL\", \"Free Size\", \"Newborn\", \"0\", \"2\", \"4\", \"6\", \"8\", \"10\", \"12\", \"14\", \"16\", \"18\", \"20\", \"22\", \"24\", \"25\", \"26\", \"27\", \"28\", \"29\", \"30\", \"31\", \"32\", \"33\", \"34\", \"35\", \"36\", \"37\", \"38\", \"39\", \"40\", \"42\", \"44\", \"46\", \"48\", \"50\", \"52\", \"54\", \"56\", \"58\", \"0-3 Months\", \"3-6 Months\", \"6-12 Months\", \"12-18 Months\", \"18-24 Months\", \"2-3 Years\", \"3-4 Years\", \"4-5 Years\", \"5-6 Years\", \"6-7 Years\", \"7-8 Years\", \"8-9 Years\", \"9-10 Years\", \"10-11 Years\", \"11-12 Years\", \"12-13 Years\", \"13-14 Years\", \"14-15 Years\", \"15-16 Years\", \"16-17 Years\", \"17-18 Years\", \"24W x 30L\", \"24W x 32L\", \"25W x 30L\", \"25W x 32L\", \"26W x 30L\", \"26W x 32L\", \"27W x 30L\", \"27W x 32L\", \"28W x 30L\", \"28W x 32L\", \"28W x 34L\", \"29W x 30L\", \"29W x 32L\", \"29W x 34L\", \"30W x 30L\", \"30W x 32L\", \"30W x 34L\", \"31W x 30L\", \"31W x 32L\", \"31W x 34L\", \"32W x 30L\", \"32W x 32L\", \"32W x 34L\", \"33W x 30L\", \"33W x 32L\", \"33W x 34L\", \"34W x 30L\", \"34W x 32L\", \"34W x 34L\", \"35W x 30L\", \"35W x 32L\", \"35W x 34L\", \"36W x 30L\", \"36W x 32L\", \"36W x 34L\", \"38W x 30L\", \"38W x 32L\", \"38W x 34L\", \"40W x 30L\", \"40W x 32L\", \"40W x 34L\", \"42W x 30L\", \"42W x 32L\", \"42W x 34L\", \"44W x 30L\", \"44W x 32L\", \"44W x 34L\", \"46W x 30L\", \"46W x 32L\", \"46W x 34L\", \"48W x 30L\", \"48W x 32L\", \"48W x 34L\" ]', '1660064033', '1660064033', 'no'),
(6, 'Material Type', '[\"Acrylic\",\"AcrylicBlend\",\"Cashmere\",\"CashmereBlend\",\"Corduroy\",\"Cotton\",\"Cottonblend\",\"Denim\",\"FauxFur\",\"Fleece\",\"Jacquard\",\"Leather\",\"Linen\",\"LinenBlend\",\"Modal\",\"ModalBlend\",\"Nylon\",\"NylonBlend\",\"Polyester\",\"PolyesterBlend\",\"Polyurethane(PU)\",\"Rayon\",\"RayonBlend\",\"Satin\",\"Satinblend\",\"Seude\",\"Silk\",\"SilkBlend\",\"Velvet\",\"Velvetblend\",\"ViscoseBlend\",\"Wool\",\"Woolblend\",\"Faux Leather\",\"Spandex\",\"Polycotton\",\"Neoprene\",\"Suede\",\"Rubber\"]', '1660064033', '1660064033', 'no'),
(7, 'Sleeve Type', '[\"Sleeveless\",\"HalfSleeve\",\"Fullsleeve\",\"3/4thsleeve\",\"CapSleeve\",\"Lantern Sleeve\",\"Batwing Sleeve\",\"Cuff Sleeve\",\"Long Sleeve\",\"Cape Sleeve\",\"Raglan Sleeve\",\"Ruffle Sleeve\",\"3/4 Sleeve\",\"Short Sleeve\",\"Puff Sleeve\",\"Bell Sleeve\"]', '1660064033', '1660064033', 'no'),
(8, 'Pattern', '[\"Embellished\",\"Animal Print\",\"Cartoon\",\"Abstract Print\",\"All Over Print\",\"Checkered\",\"Aztec Print\",\"Camouflage\",\"Striped\",\"Ombre\",\"Dobby Print\",\"Block Print\",\"Textured\",\"Graphic Print\",\"Geometric Print\",\"Tribal\",\"Embroidered\",\"Floral\",\"Tie-Dye\",\"Polka Dot\",\"Paisley\",\"Solid\",\"Plaid\",\"Color Block\",\"Botanic Print\",\"Starred\",\"Self-Design\",\"Ethnic motifs\",\"Printed\",\"Character Print\",\"Conversational\",\"Varsity\",\"Assorted\",\"Faded\",\"Logo\"]', '1660064033', '1660064033', 'no'),
(9, 'Fitting Type', '[\"Regular Fit\",\"Slim Fit\",\"Loose Fit\",\"Tailored Fit\",\"Western\",\"Overall\",\"Compression\",\"Fitted\",\"Regular\",\"Relaxed\",\"Stretch\",\"Slim\",\"Classic\",\"Loose\",\"Skinny\"]', '1660064033', '1660064033', 'no'),
(10, 'Neck Style', '[\"Polo\",\"RoundNeck\",\"V-Neck\",\"Henley\",\"ScoopNeck\",\"ButtonFront\",\"CrewNeck\",\"TurtleNeck\",\"Collared\",\"BoatNeck\",\"Hood\",\"AsymmetricNeck\",\"Cowl\",\"Halter\",\"OffShoulder\",\"OneShoulder\",\"SquareNeck\",\"Strapless\",\"SweetheartNeck\",\"Half-Zip\"]', '1660064033', '1660064033', 'no'),
(11, 'Collar Style', '[\"Classic Collar\",\"Cutaway Collar\",\"Mandarin Collar\",\"Button Down Collar\",\"Round Collar\",\"Collarless\",\"Banded Collar\",\"Club Collar\",\"Spread Collar\",\"Wingtip Collar\",\"Spread\",\"Tab\",\"Club\",\"Cutaway\",\"Hidden Button Down\",\"Wingtip\",\"Band\",\"Straight Point\",\"Button Down\",\"Camp\"]', '1660064033', '1660064033', 'no'),
(12, 'Country Of Origin', '[\"India\",\"China\",\"United States\",\"Afghanistan\",\"Aland Islands\",\"Albania\",\"Algeria\",\"American Samoa\",\"Andorra\",\"Angola\",\"Anguilla\",\"Antarctica\",\"Antigua And Barbuda\",\"Argentina\",\"Armenia\",\"Aruba\",\"Australia\",\"Austria\",\"Azerbaijan\",\"Bahamas\",\"Bahrain\",\"Bangladesh\",\"Barbados\",\"Belarus\",\"Belgium\",\"Belize\",\"Benin\",\"Bermuda\",\"Bhutan\",\"Bolivia\",\"Bosnia and Herzegovina\",\"Botswana\",\"Bouvet Island\",\"Brazil\",\"British Indian Ocean Territory\",\"British Virgin Islands\",\"Brunei\",\"Bulgaria\",\"Burkina Faso\",\"Burma (Myanmar)\",\"Burundi\",\"Cambodia\",\"Cameroon\",\"Canada\",\"Cape Verde\",\"Cayman Islands\",\"Central African Republic\",\"Chad\",\"Chile\",\"Christmas Island\",\"Cocos (Keeling) Islands\",\"Colombia\",\"Comoros\",\"Cook Islands\",\"Costa Rica\",\"Croatia\",\"Cuba\",\"Cyprus\",\"Czech Republic\",\"Democratic Republic of the Congo\",\"Denmark\",\"Djibouti\",\"Dominica\",\"Dominican Republic\",\"Ecuador\",\"Egypt\",\"El Salvador\",\"Equatorial Guinea\",\"Eritrea\",\"Estonia\",\"Ethiopia\",\"Falkland Islands\",\"Faroe Islands\",\"Fiji\",\"Finland\",\"France\",\"French Guiana\",\"French Polynesia\",\"French Southern Territories\",\"Great Britain\",\"Gabon\",\"Gambia\",\"Georgia\",\"Germany\",\"Ghana\",\"Gibraltar\",\"Greece\",\"Greenland\",\"Grenada\",\"Guadeloupe\",\"Guam\",\"Guatemala\",\"Guernsey\",\"Guinea\",\"Guinea-Bissau\",\"Guyana\",\"Haiti\",\"Heard and McDonald Islands\",\"Holy See (Vatican City)\",\"Honduras\",\"Hong Kong\",\"Hungary\",\"Iceland\",\"Indonesia\",\"Iran\",\"Iraq\",\"Ireland\",\"Isle of Man\",\"Israel\",\"Italy\",\"Ivory Coast\",\"Jamaica\",\"Japan\",\"Jersey\",\"Jordan\",\"Kazakhstan\",\"Kenya\",\"Kiribati\",\"Kuwait\",\"Kyrgyzstan\",\"Laos\",\"Latvia\",\"Lebanon\",\"Lesotho\",\"Liberia\",\"Libya\",\"Liechtenstein\",\"Lithuania\",\"Luxembourg\",\"Macau\",\"North Macedonia\",\"Madagascar\",\"Malawi\",\"Malaysia\",\"Maldives\",\"Mali\",\"Malta\",\"Marshall Islands\",\"Martinique\",\"Mauritania\",\"Mauritius\",\"Mayotte\",\"Mexico\",\"Micronesia\",\"Moldova\",\"Monaco\",\"Mongolia\",\"Montserrat\",\"Morocco\",\"Mozambique\",\"Namibia\",\"Nauru\",\"Nepal\",\"Netherlands\",\"New Caledonia\",\"New Zealand\",\"Nicaragua\",\"Niger\",\"Nigeria\",\"Niue\",\"Norfolk Island\",\"North Korea\",\"Northern Mariana Islands\",\"Norway\",\"Oman\",\"Pakistan\",\"Palau\",\"Palestinian Territory\",\"Panama\",\"Papua New Guinea\",\"Paraguay\",\"Peru\",\"Philippines\",\"Pitcairn Islands\",\"Poland\",\"Portugal\",\"Puerto Rico\",\"Qatar\",\"Republic of the Congo\",\"Reunion\",\"Romania\",\"Russia\",\"Rwanda\",\"S. Georgia and S. Sandwich Isls.\",\"Saint Helena\",\"Saint Kitts And Nevis\",\"Saint Lucia\",\"Saint Pierre and Miquelon\",\"Saint Vincent And The Grenadines\",\"Saint-Martin\",\"Samoa\",\"San Marino\",\"Sao Tome And Principe\",\"Saudi Arabia\",\"Senegal\",\"Serbia\",\"Seychelles\",\"Sierra Leone\",\"Singapore\",\"Slovakia\",\"Slovenia\",\"Solomon Islands\",\"Somalia\",\"South Africa\",\"South Korea\",\"Spain\",\"Sri Lanka\",\"Sudan\",\"Suriname\",\"Svalbard\",\"Swaziland\",\"Sweden\",\"Switzerland\",\"Syria\",\"Taiwan\",\"Tajikistan\",\"Tanzania\",\"Thailand\",\"Timor-Leste\",\"Togo\",\"Tokelau\",\"Tonga\",\"Trinidad And Tobago\",\"Tunisia\",\"Turkey\",\"Turkmenistan\",\"Turks And Caicos Islands\",\"Tuvalu\",\"Uganda\",\"Ukraine\",\"United Arab Emirates\",\"Uruguay\",\"US Minor Outlying Islands\",\"US Virgin Islands\",\"Uzbekistan\",\"Vanuatu\",\"Venezuela\",\"Vietnam\",\"Wallis and Futuna\",\"Western Sahara\",\"Yemen\",\"Zambia\",\"Zimbabwe\",\"Unknown\",\"United Kingdom\"]', '1660064033', '1660064033', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_sellers_withdraw`
--

CREATE TABLE `ecommerce_sellers_withdraw` (
  `withdraw_id` bigint(255) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `gateway` text NOT NULL,
  `gross_amount` float(65,2) NOT NULL,
  `charge` float(65,2) NOT NULL,
  `net_amount` float(65,2) NOT NULL,
  `date_requested` varchar(255) NOT NULL,
  `date_processed` varchar(255) DEFAULT NULL,
  `db_labels` text NOT NULL,
  `user_labels` text NOT NULL,
  `status` enum('pending','rejected','success') NOT NULL,
  `rejected_reason` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_seller_verification`
--

CREATE TABLE `ecommerce_seller_verification` (
  `verification_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `status` enum('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  `rejected_reason` varchar(1000) DEFAULT NULL,
  `requested_on` varchar(255) NOT NULL,
  `action_date` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecommerce_seller_verification`
--

INSERT INTO `ecommerce_seller_verification` (`verification_id`, `user_id`, `status`, `rejected_reason`, `requested_on`, `action_date`) VALUES
(1, '1006090', 'verified', NULL, '1660067190', '1660067200');

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_service_charges`
--

CREATE TABLE `ecommerce_service_charges` (
  `service_id` bigint(255) NOT NULL,
  `service_name` varchar(255) NOT NULL,
  `service_charge` bigint(255) NOT NULL,
  `charge_type` enum('fixed','percentage') NOT NULL,
  `created_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecommerce_service_charges`
--

INSERT INTO `ecommerce_service_charges` (`service_id`, `service_name`, `service_charge`, `charge_type`, `created_date`) VALUES
(1, 'Admin Charge', 10, 'percentage', '1660064808'),
(2, 'Service charge', 20, 'fixed', '1660064819');

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_users_withdraw_gateways`
--

CREATE TABLE `ecommerce_users_withdraw_gateways` (
  `primary_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `gateway_id` varchar(255) NOT NULL,
  `labels` text NOT NULL,
  `date_created` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_user_cart`
--

CREATE TABLE `ecommerce_user_cart` (
  `cart_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `variation_id` varchar(255) NOT NULL,
  `svariation_id` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `role` enum('cart','saved','wishlist','checkout') NOT NULL,
  `last_updated` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_user_search_history`
--

CREATE TABLE `ecommerce_user_search_history` (
  `search_id` bigint(255) NOT NULL,
  `search_text` varchar(1000) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `last_updated` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecommerce_user_search_history`
--

INSERT INTO `ecommerce_user_search_history` (`search_id`, `search_text`, `user_id`, `last_updated`) VALUES
(1, 'Shirt', '1006090', '1660066172'),
(2, 'Shirt', NULL, '1660066153'),
(3, 'Shirt', NULL, '1660066162'),
(4, 'Shirt', NULL, '1660066162'),
(5, 'Shirt', NULL, '1660066163'),
(6, 'Shirt', NULL, '1660066163'),
(7, 'Shirt', NULL, '1660066163'),
(8, 'Shirt', NULL, '1660066163'),
(9, 'Shirt', NULL, '1660066164'),
(10, 'Shirt', NULL, '1660066164'),
(11, 'Shirt', NULL, '1660066172'),
(12, 'Shirt', NULL, '1660067571'),
(13, 'Shirt', NULL, '1660067575'),
(14, 'Shirt', NULL, '1660110161');

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_variations`
--

CREATE TABLE `ecommerce_variations` (
  `id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `variation_id` varchar(255) NOT NULL,
  `svariation_id` varchar(255) NOT NULL,
  `variation_value` varchar(255) DEFAULT NULL,
  `svariation_value` varchar(255) DEFAULT NULL,
  `variation_data` text DEFAULT NULL,
  `svariation_data` text DEFAULT NULL,
  `details` text DEFAULT NULL,
  `images` text DEFAULT NULL,
  `price` bigint(255) DEFAULT NULL,
  `mrp` bigint(255) DEFAULT NULL,
  `stock` bigint(255) DEFAULT NULL,
  `low_stock_warning` int(21) DEFAULT NULL,
  `sku_id` varchar(21) DEFAULT NULL,
  `product_name` varchar(200) DEFAULT NULL,
  `minimum_order` int(251) DEFAULT NULL,
  `maximum_order` int(251) DEFAULT NULL,
  `cod_status` enum('no','yes') NOT NULL,
  `status` enum('active','inactive','archived','blocked','rejected') DEFAULT NULL,
  `return_policy` enum('no','replacement','return') DEFAULT NULL,
  `return_policy_days` varchar(100) DEFAULT NULL,
  `return_policy_tc` varchar(5000) DEFAULT NULL,
  `highlights` text DEFAULT NULL,
  `description` varchar(5000) DEFAULT NULL,
  `date_created` varchar(43) NOT NULL,
  `last_modified` varchar(43) NOT NULL,
  `tags` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecommerce_variations`
--

INSERT INTO `ecommerce_variations` (`id`, `user_id`, `product_id`, `variation_id`, `svariation_id`, `variation_value`, `svariation_value`, `variation_data`, `svariation_data`, `details`, `images`, `price`, `mrp`, `stock`, `low_stock_warning`, `sku_id`, `product_name`, `minimum_order`, `maximum_order`, `cod_status`, `status`, `return_policy`, `return_policy_days`, `return_policy_tc`, `highlights`, `description`, `date_created`, `last_modified`, `tags`) VALUES
(1, '1006090', '1', '9719859216662f29d8e2d2af', '6772391462162f29d8e2d408', 'Grey', 'M', '{\"type\":\"image\",\"id\":\"63\"}', '{\"type\":\"select\"}', '{\"1\":\"M\",\"2\":\"Grey\",\"3\":\"Men\",\"4\":\"Polo\",\"5\":\"Polo\",\"6\":\"HalfSleeve\",\"7\":\"Cotton\",\"8\":\"Hand-wash\",\"9\":\"India\"}', '{\"1\":{\"id\":\"65\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/8967209166006727216600672727992ba42-2c50-45b8-9852-d6ae2ea00418.jpg\",\"type\":\"image\"},\"2\":{\"id\":\"66\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/3984251166006727516600672750394cf49-1f25-4a4e-931a-4618210d4f79.jpg\",\"type\":\"image\"},\"3\":{\"id\":\"67\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/83454911660067278166006727824692e76-ed46-407b-b3b3-4b9ef4089c71.jpg\",\"type\":\"image\"},\"4\":{\"id\":\"68\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/264483216600672831660067283160e056e-dd42-4a52-b680-2ab509c8745b.jpg\",\"type\":\"image\"},\"5\":{\"id\":\"69\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/989298116600672901660067290c79d31e2-91bb-400f-a9f8-543a6c7f4d4a.jpg\",\"type\":\"image\"},\"6\":{\"id\":\"70\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/226907616600672941660067294343e0486-8af3-4177-bf05-46711bb51a80.jpg\",\"type\":\"image\"},\"7\":{\"id\":\"\",\"src\":null,\"type\":\"image\"},\"8\":{\"id\":\"\",\"src\":null,\"type\":\"video\"}}', 499, 999, 12, 10, 'grey', 'Grey melange and navy half sleeve polo T-shirt', 1, 10, 'yes', 'active', 'no', '0', NULL, '[\"half sleeve polo T-shirt\",\"Grey melange and navy half sleeve polo T-shirt\"]', '', '1660067559', '1660067559', '[{\"value\":\"half sleeve polo T-shirt\"},{\"value\":\"men tshirt\"}]'),
(2, '1006090', '1', '9719859216662f29d8e2d2af', '1278207494262f29f5d764a4', 'Grey', 'L', '{\"type\":\"image\",\"id\":\"63\"}', '{\"type\":\"select\"}', '{\"1\":\"L\",\"2\":\"Grey\",\"3\":\"Men\",\"4\":\"Polo\",\"5\":\"Polo\",\"6\":\"HalfSleeve\",\"7\":\"Cotton\",\"8\":\"Hand-wash\",\"9\":\"India\"}', '{\"1\":{\"id\":\"65\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/8967209166006727216600672727992ba42-2c50-45b8-9852-d6ae2ea00418.jpg\",\"type\":\"image\"},\"2\":{\"id\":\"66\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/3984251166006727516600672750394cf49-1f25-4a4e-931a-4618210d4f79.jpg\",\"type\":\"image\"},\"3\":{\"id\":\"67\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/83454911660067278166006727824692e76-ed46-407b-b3b3-4b9ef4089c71.jpg\",\"type\":\"image\"},\"4\":{\"id\":\"68\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/264483216600672831660067283160e056e-dd42-4a52-b680-2ab509c8745b.jpg\",\"type\":\"image\"},\"5\":{\"id\":\"69\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/989298116600672901660067290c79d31e2-91bb-400f-a9f8-543a6c7f4d4a.jpg\",\"type\":\"image\"},\"6\":{\"id\":\"70\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/226907616600672941660067294343e0486-8af3-4177-bf05-46711bb51a80.jpg\",\"type\":\"image\"},\"7\":{\"id\":\"\",\"src\":null,\"type\":\"image\"},\"8\":{\"id\":\"\",\"src\":null,\"type\":\"video\"}}', 499, 999, 12, 10, 'large', 'Grey melange and navy half sleeve polo T-shirt', 1, 10, 'yes', 'active', 'no', '0', NULL, '[\"half sleeve polo T-shirt\",\"Grey melange and navy half sleeve polo T-shirt\"]', '', '1660067706', '1660067706', '[{\"value\":\"half sleeve polo T-shirt\"},{\"value\":\"men tshirt\"}]'),
(3, '1006090', '2', '5318347839362f2a079ed68f', '8381390899062f2a079edb21', 'Black', 'M', '{\"type\":\"image\",\"id\":\"76\"}', '{\"type\":\"select\"}', '{\"1\":\"M\",\"2\":\"Black\",\"3\":\"Women\",\"4\":\"Polo\",\"5\":\"Polo\",\"6\":\"HalfSleeve\",\"7\":\"Cotton\",\"8\":\"Hand-wash\",\"9\":\"India\"}', '{\"1\":{\"id\":\"77\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/3810333166006797216600679724cf90222-67e2-448d-b50e-8abb448c8db1.jpg\",\"type\":\"image\"},\"2\":{\"id\":\"78\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/252312516600679741660067974130ee9a4-13a8-4417-9bc2-6cb663b64bc0.jpg\",\"type\":\"image\"},\"3\":{\"id\":\"79\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/4750747166006797716600679778f2e8fb1-d22c-49da-8c2e-a323c0222786.jpg\",\"type\":\"image\"},\"4\":{\"id\":\"80\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/585885016600679811660067981b60bfbd4-c0c3-454e-a14d-1c7f5458edbe.jpg\",\"type\":\"image\"},\"5\":{\"id\":\"81\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/759781816600679881660067988d6f00b88-a667-4cc7-b6c5-d6ef2f8c8680.jpg\",\"type\":\"image\"},\"6\":{\"id\":\"82\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/287310116600679931660067993a8219abd-2f5c-4d19-9341-ba51fbeb8b3a.jpg\",\"type\":\"image\"},\"7\":{\"id\":\"\",\"src\":null,\"type\":\"image\"},\"8\":{\"id\":\"\",\"src\":null,\"type\":\"video\"}}', 599, 999, 12, 10, 'red', 'Hibiscus assorted prints polo T-shirt', 1, 10, 'yes', 'active', 'replacement', '10', '10days', '[\"Hibiscus assorted prints polo T-shirt\"]', '', '1660068111', '1660068111', '[{\"value\":\"tshirt for girls\"},{\"value\":\"girls tshirt\"},{\"value\":\"Black assorted prints polo T-shirt\"},{\"value\":\"red tshirt\"}]'),
(4, '1006090', '2', '1561202040862f29fa6bc132', '8936677608962f29fa6bc270', 'Black', 'M', '{\"type\":\"image\",\"id\":\"71\"}', '{\"type\":\"select\"}', '{\"1\":\"M\",\"2\":\"Black\",\"3\":\"Women\",\"4\":\"Polo\",\"5\":\"Polo\",\"6\":\"HalfSleeve\",\"7\":\"Cotton\",\"8\":\"Hand-wash\",\"9\":\"India\"}', '{\"1\":{\"id\":\"72\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/460086116600677881660067788afa73247-4159-45fb-ac0b-6f9f793f7c0f.jpg\",\"type\":\"image\"},\"2\":{\"id\":\"73\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/6035672166006779216600677920d9833e5-6804-4b7d-956c-88ce8da32e53.jpg\",\"type\":\"image\"},\"3\":{\"id\":\"74\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/23548371660067794166006779415925a57-da92-4b2a-8f70-c6d278d171bc.jpg\",\"type\":\"image\"},\"4\":{\"id\":\"75\",\"src\":\"\\/demo\\/jcart\\/assets\\/files\\/635816916600677971660067797705293a3-a46d-4ca8-bea8-22f8aa642821.jpg\",\"type\":\"image\"},\"5\":{\"id\":\"\",\"src\":null,\"type\":\"image\"},\"6\":{\"id\":\"\",\"src\":null,\"type\":\"image\"},\"7\":{\"id\":\"\",\"src\":null,\"type\":\"image\"},\"8\":{\"id\":\"\",\"src\":null,\"type\":\"video\"}}', 599, 999, 12, 10, 'print', 'Black assorted prints polo T-shirt', 1, 10, 'yes', 'active', 'replacement', '10', '10days', '[\"Black assorted prints polo T-shirt\"]', '', '1660068127', '1660068127', '[{\"value\":\"tshirt for girls\"},{\"value\":\"girls tshirt\"},{\"value\":\"Black assorted prints polo T-shirt\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_withdraw_gateways`
--

CREATE TABLE `ecommerce_withdraw_gateways` (
  `gateway_id` bigint(255) NOT NULL,
  `gateway_name` varchar(255) NOT NULL,
  `logo_id` varchar(255) NOT NULL,
  `processing_time` varchar(255) NOT NULL,
  `charge` int(255) NOT NULL,
  `charge_type` enum('fixed','percentage') NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `card_heading` varchar(255) NOT NULL,
  `labels` text NOT NULL,
  `date_created` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `file_id` bigint(255) NOT NULL,
  `file_src` text NOT NULL,
  `file_name` varchar(5000) NOT NULL,
  `type` enum('file','url','web') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`file_id`, `file_src`, `file_name`, `type`) VALUES
(1, '64941801660064412166006441200baa002-c357-4ad3-85be-224320b9626d.jpg', 'brick-red-t-shirt-mv03-6.jpg', 'file'),
(2, '1517080166006442416600644242a68e179-c349-445a-8b1a-e4896fc9f55c.jpg', 'deep-atlantis-sport-polo-t-shirt-3911-5.jpg', 'file'),
(3, '570552716600644301660064430e221da17-245a-47ef-ac86-3b14712b3b7b.jpg', 'worldly-red-and-white-half-sleeve-polo-t-shirt-us93-4.jpg', 'file'),
(4, '150692716600644451660064445843182b1-47e5-434f-b2ae-94cbd69ca754.jpg', 'grey-melange-and-navy-half-sleeve-polo-t-shirt-us93-2.jpg', 'file'),
(5, '5145224166006445816600644586a186036-11c7-45a8-86dd-76a909a108af.jpg', 'black-round-neck-t-shirt-1515-6.jpg', 'file'),
(6, '3308854166006446616600644666d832d6c-ab91-40ff-94f8-d6698f7af31d.jpg', 'red-wood-round-neck-t-shirt-1515-18.jpg', 'file'),
(7, '776056816600644781660064478b8a244fd-ceed-4595-991b-d9ba6291db68.jpg', 'indigo-crush-polo-shirt-ul10-5.jpg', 'file'),
(8, '416016816600644851660064485ceb05ce6-0aec-4957-85cb-9aecc170e811.jpg', 'hibiscus-assorted-prints-polo-t-shirt-ul34-11.jpg', 'file'),
(9, '633322016600649991660064999e1cb5d09-fe7e-42e9-acb1-73716067a117.webp', '0e6a4c91ad4e8809.webp', 'file'),
(10, '23436951660065011166006501193ae700d-a7a5-461a-bfc8-c95ad41a73f2.webp', 'a025208e7b4e3a70.webp', 'file'),
(11, '574315916600650301660065030f99547f8-d4e6-4321-aa6a-70b81e0535b3.webp', '39fb591b5f955843.webp', 'file'),
(12, '4899780166006504516600650450d26d2ad-377c-490a-bc4a-de037b8e2b10.webp', '4611f9e35b662282.webp', 'file'),
(13, '92705061660065056166006505662aa1093-ede3-42af-9c34-0350b0e17f27.webp', '74eb5a8430d3dc06.webp', 'file'),
(14, '23295491660065074166006507474d92ae8-27ec-4027-b389-64f51489feac.jpg', '216-min.jpg', 'file'),
(15, '39086931660065099166006509955853c1d-f123-4057-b741-d1703dfd0f86.jpg', 'slider_(12)_copy1.jpg', 'file'),
(16, '569141116600651141660065114fbab105c-6f0f-46b3-a905-d6826bc3ce94.jpg', '52-min.jpg', 'file'),
(17, '267213916600651381660065138958b0edc-e16f-42cc-8404-06b9426a5e05.jpg', '10-min.jpg', 'file'),
(18, '132700916600652511660065251feac991b-9c3e-497d-843d-176c4a1711a5.webp', '-original-imagf2yzeffezg4g.webp', 'file'),
(19, '92949991660065274166006527407e6a116-0c95-4c8b-b382-0edb693b2437.webp', '-original-imagf2yzeffezg4g.webp', 'file'),
(20, '7831543166006529916600652990e8ac9d0-67a7-4497-9e38-80786dd59237.webp', 'brother-dcp-b7500d-original-imafuvbyfgt5p9fr.webp', 'file'),
(21, '67066841660065307166006530769db5325-a99f-4732-b24b-ea4cab7382ba.webp', '2311-throwball-ratna-s-original-imag5edrnfrfzhzt.webp', 'file'),
(22, '8434378166006531416600653143b9fef55-af4c-48d3-a087-9fcc871890a3.webp', '1-drift-warrior-3x3-stickerless-speedcube-highspeed-magic-cube-original-imagc3gpnk4hsagz.webp', 'file'),
(23, '884333616600653241660065324848ec1c5-405d-469f-9b7e-c053e7c153d5.webp', 'kitchen-cook-set-for-kids-in-briefcase-style-ar-kids-toys-original-imafgufsdtgmvhrg.webp', 'file'),
(24, '526681016600653341660065334174ee6d0-094b-4c75-a404-7bad025f8d09.webp', 'yes-standard-edition-ps5-gran-turismo-7-standard-ed-full-game-original-imag9yd5uzdbqp5c.webp', 'file'),
(25, '5233466166006534216600653424c7320cb-c6ad-4be9-915a-f49c32670f72.webp', 'zeb-transformer-m-zebronics-original-imafxrugfftphbkk.webp', 'file'),
(26, '782061916600653481660065348e9caed73-2a4f-468e-ba63-4b3385802f7c.webp', 'carbon-steel-low-back-royal-ergonomic-desk-mesh-chair-in-brown-original-imafvzvprhk3xqdc.webp', 'file'),
(27, '7538137166006540516600654054472ef5e-4cdc-440b-843c-af3a35f8827d.webp', '2bba4baa853eaf59.webp', 'file'),
(28, '974125316600654141660065414170953c4-d611-42e6-adbd-77c5f6e9080e.webp', '079e5ea4ea71fc3d.webp', 'file'),
(29, '229788416600654221660065422b056b3ff-8713-46b1-8406-fcdebe9f3a2f.webp', 'dd13cfc4d9cdb10c.webp', 'file'),
(30, '5249184166006543316600654338cf2b4b3-540f-414d-9af0-fcf64c0cd83b.webp', '0264bbda7be8bf00.webp', 'file'),
(31, '2477560166006543916600654397cac2916-aa39-439e-9fa2-ec716c8ea222.webp', 'd4e597011a8a38ee.webp', 'file'),
(32, '48804191660065449166006544982c02b59-7194-42fe-a697-c832897bba6f.webp', '654721a35114ce04.webp', 'file'),
(33, '839970416600654601660065460cef7ad85-b54b-4774-9fc6-a0f61bd24b63.webp', '368eda7fd16a1b4d.webp', 'file'),
(34, '3674642166006546716600654675bcdb871-7995-49ba-81d3-f510735c72f7.webp', '9f94ed47f44d9d0e.webp', 'file'),
(35, '6839620166006550416600655046624bf4a-0494-4881-9b4f-8bf2a6951440.webp', '0cbdf75060e1a919.webp', 'file'),
(36, '4532037166006552716600655270e0a6d46-b31d-4498-9a6a-13927dcc6d96.webp', '5560d29a3109eebe.webp', 'file'),
(37, '50702381660065560166006556083cba08a-70d0-4e2a-8a13-85486b1932cc.webp', '98cc8f5bd6768c30.webp', 'file'),
(38, '760651516600656021660065602c7655197-efb0-4cc5-b643-66a688ec4960.webp', '247231c4cf9f2003.webp', 'file'),
(39, '34281741660065615166006561534c94fce-2e61-4fbb-8270-a912dac0f8e8.webp', '247231c4cf9f2003.webp', 'file'),
(40, '600257116600656201660065620a9ed1a5f-7f7e-4288-9bf7-2251464fc21e.webp', 'bb72d6c9df0c3c82.webp', 'file'),
(41, '588275216600656491660065649f9229dca-7495-4557-bf66-5fb133de3fd8.webp', 'bc440e23d55bd111.webp', 'file'),
(42, '139347116600656601660065660dd552262-c04f-49e9-ba97-64df399b5462.webp', '270cdf47bcc0e89d.webp', 'file'),
(43, '637286216600656801660065680d48ad7d8-12fe-416c-a9cd-c49df975471a.webp', 'c575255f0c11b324.webp', 'file'),
(44, '636424716600657051660065705c4319fa4-3adb-46b5-9001-8e8617f80598.webp', '1064d8830bdc0181.webp', 'file'),
(45, '496645416600657651660065765648a2593-a54f-4124-b8ac-2191a0f54784.webp', '653c63ca35ff867e.webp', 'file'),
(46, '598005016600657721660065772753c19b1-5a4c-4de7-8d6a-6d6bc0955ff4.webp', '0f4a4a43371eb2c3.webp', 'file'),
(47, '4838593166006577916600657798f1c7ae2-e1bc-443a-b9b5-567504d8c7cf.webp', 'dfaba2b9dd53f064.webp', 'file'),
(48, '858023016600657871660065787d72dcbaa-0e57-440d-b18a-c9db169f6a75.webp', 'fb7916dcb940e5e1.webp', 'file'),
(49, '4204731166006579616600657963149c76a-ca1a-4791-a133-499e951a9cee.webp', '8a6f494950ee1a27.webp', 'file'),
(50, '621316416600658041660065804eddb9c9c-9209-4711-b5e9-d4452b7706d8.webp', '371351db95e1f1c9.webp', 'file'),
(51, '17471931660065811166006581113dd89ad-4397-4035-9caf-8bbd336ca3cd.webp', '3a371d8a5dacb40f.webp', 'file'),
(52, '501177516600662511660066251ee209cb5-a518-4fcb-b638-dfca1f3cbec9.jpg', '662423516598869981659886998adb42ec9-771d-4cd5-8230-629a3c9e188d.jpg', 'file'),
(53, '30934831660066268166006626899064e82-6415-4e3b-8a44-c1f1d62253b9.jpg', '4822318165988706916598870695f2edaa2-f849-4220-a70c-920be4b36a86.jpg', 'file'),
(54, '393247016600663531660066353dce4c1eb-cb07-4932-a739-2f6df4b61e20.jpeg', 'laptop6-min-min.jpeg', 'file'),
(55, '64774541660066364166006636466be676d-6c1c-4615-a573-f5534eac3060.jpg', '71WAfzYNAFL__SL1500_.jpg', 'file'),
(56, '813569216600663861660066386ba9e08ec-b065-4dee-b90c-1c6b96c03cce.jpg', 'aa-min_1.jpg', 'file'),
(57, '65536951660066420166006642032edb409-2a9f-45c9-8ac3-f123cc663f0d.jpg', 'phn4-min.jpg', 'file'),
(58, '9204622166006646516600664657697685e-7746-4076-8f7b-d744d5cfbf3d.jpg', 'images_jfif.jpg', 'file'),
(59, '6107574166006651816600665184b414c04-2a5e-4b3c-9631-97e6617c43f2.jpg', '01_Samsung_Galaxy_S21_Ultra_5G.jpg', 'file'),
(60, '144300316600665791660066579cd180fee-2ea3-4238-839e-57da7dd95d0c.jpg', 'Webp_net-resizeimage5-min.jpg', 'file'),
(61, '4254729166006677616600667765360034a-0ca5-4a2f-99d1-c17af9c7e60c.jpg', 'il_794xN_1340783932_doku.jpg', 'file'),
(62, '941476616600671481660067148448fee82-6c3b-4c94-9497-1eaa57fec640.jpg', '006.jpg', 'file'),
(63, '4791467166006724716600672473a67663b-9b33-41c0-b762-e03d332ff80d.jpg', 'grey-melange-and-navy-half-sleeve-polo-t-shirt-us93-6.jpg', 'file'),
(64, '7509251166006726116600672612f395f4d-1378-427b-ad9b-c631507219c2.jpg', 'grey-melange-and-navy-half-sleeve-polo-t-shirt-us93-1.jpg', 'file'),
(65, '8967209166006727216600672727992ba42-2c50-45b8-9852-d6ae2ea00418.jpg', 'grey-melange-and-navy-half-sleeve-polo-t-shirt-us93-6.jpg', 'file'),
(66, '3984251166006727516600672750394cf49-1f25-4a4e-931a-4618210d4f79.jpg', 'grey-melange-and-navy-half-sleeve-polo-t-shirt-us93-5.jpg', 'file'),
(67, '83454911660067278166006727824692e76-ed46-407b-b3b3-4b9ef4089c71.jpg', 'grey-melange-and-navy-half-sleeve-polo-t-shirt-us93-4.jpg', 'file'),
(68, '264483216600672831660067283160e056e-dd42-4a52-b680-2ab509c8745b.jpg', 'grey-melange-and-navy-half-sleeve-polo-t-shirt-us93-3.jpg', 'file'),
(69, '989298116600672901660067290c79d31e2-91bb-400f-a9f8-543a6c7f4d4a.jpg', 'grey-melange-and-navy-half-sleeve-polo-t-shirt-us93-2.jpg', 'file'),
(70, '226907616600672941660067294343e0486-8af3-4177-bf05-46711bb51a80.jpg', 'grey-melange-and-navy-half-sleeve-polo-t-shirt-us93-1.jpg', 'file'),
(71, '987100016600677741660067774cd6c0f8c-6e57-4615-9872-a3299e8053d2.jpg', 'black-assorted-prints-polo-t-shirt-ul34-6.jpg', 'file'),
(72, '460086116600677881660067788afa73247-4159-45fb-ac0b-6f9f793f7c0f.jpg', 'black-assorted-prints-polo-t-shirt-ul34-6.jpg', 'file'),
(73, '6035672166006779216600677920d9833e5-6804-4b7d-956c-88ce8da32e53.jpg', 'black-assorted-prints-polo-t-shirt-ul34-5.jpg', 'file'),
(74, '23548371660067794166006779415925a57-da92-4b2a-8f70-c6d278d171bc.jpg', 'black-assorted-prints-polo-t-shirt-ul34-4.jpg', 'file'),
(75, '635816916600677971660067797705293a3-a46d-4ca8-bea8-22f8aa642821.jpg', 'black-assorted-prints-polo-t-shirt-ul34-2.jpg', 'file'),
(76, '411901016600679591660067959a97d2626-d4cb-45c6-a578-4157320e7567.jpg', 'hibiscus-assorted-prints-polo-t-shirt-ul34-14.jpg', 'file'),
(77, '3810333166006797216600679724cf90222-67e2-448d-b50e-8abb448c8db1.jpg', 'hibiscus-assorted-prints-polo-t-shirt-ul34-14.jpg', 'file'),
(78, '252312516600679741660067974130ee9a4-13a8-4417-9bc2-6cb663b64bc0.jpg', 'hibiscus-assorted-prints-polo-t-shirt-ul34-13.jpg', 'file'),
(79, '4750747166006797716600679778f2e8fb1-d22c-49da-8c2e-a323c0222786.jpg', 'hibiscus-assorted-prints-polo-t-shirt-ul34-12.jpg', 'file'),
(80, '585885016600679811660067981b60bfbd4-c0c3-454e-a14d-1c7f5458edbe.jpg', 'hibiscus-assorted-prints-polo-t-shirt-ul34-11.jpg', 'file'),
(81, '759781816600679881660067988d6f00b88-a667-4cc7-b6c5-d6ef2f8c8680.jpg', 'hibiscus-assorted-prints-polo-t-shirt-ul34-10.jpg', 'file'),
(82, '287310116600679931660067993a8219abd-2f5c-4d19-9341-ba51fbeb8b3a.jpg', 'hibiscus-assorted-prints-polo-t-shirt-ul34-9.jpg', 'file');

-- --------------------------------------------------------

--
-- Table structure for table `layouts`
--

CREATE TABLE `layouts` (
  `layout_id` bigint(255) NOT NULL,
  `page_id` varchar(100) NOT NULL,
  `components` longtext NOT NULL,
  `created_date` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `layouts`
--

INSERT INTO `layouts` (`layout_id`, `page_id`, `components`, `created_date`, `status`) VALUES
(1, 'HOME', '[\"2\",\"7\",\"6\",\"10\",\"4\",\"9\",\"8\",\"1\",\"5\",\"3\"]', NULL, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `login_session`
--

CREATE TABLE `login_session` (
  `id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `valid_till` varchar(255) NOT NULL,
  `user_ip` varchar(255) NOT NULL,
  `user_browser` varchar(255) NOT NULL,
  `user_os` varchar(255) NOT NULL,
  `user_device` varchar(255) NOT NULL,
  `user_location` varchar(255) NOT NULL,
  `status` enum('active','expired') NOT NULL DEFAULT 'active',
  `role` enum('visitor','seller','admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login_session`
--

INSERT INTO `login_session` (`id`, `user_id`, `session_id`, `date`, `valid_till`, `user_ip`, `user_browser`, `user_os`, `user_device`, `user_location`, `status`, `role`) VALUES
(1, '1006090', '0d09924f0ccb4316bd35e62678cf8cd0', '1660064036', '1662656036', '103.199.200.76', 'Firefox', 'Windows 8', 'Computer', 'Dhanbad, Jharkhand, India', 'expired', 'admin'),
(2, '1006090', '99ded59259654277b45bd877f9aa15c8', '1660064080', '1662656080', '103.199.200.76', 'Firefox', 'Mac OS X', 'Computer', 'Dhanbad, Jharkhand, India', 'expired', 'admin'),
(3, '1006090', '89ed0091a214470ba79a0f1d6b3e5c68', '1660066080', '1662658080', '106.206.197.47', 'Handheld Browser', 'Android', 'Mobile', 'Patna, Bihar, India', 'expired', 'visitor'),
(4, '1006090', 'b5ded59ef14146f996d7b12774caae25', '1660067125', '1662659125', '103.199.200.76', 'Firefox', 'Mac OS X', 'Computer', 'Dhanbad, Jharkhand, India', 'expired', 'seller'),
(5, '1006090', 'bc59555dfca743fa85477a56571dee7d', '1660068317', '1662660317', '103.199.200.76', 'Firefox', 'Mac OS X', 'Computer', 'Dhanbad, Jharkhand, India', 'active', 'visitor'),
(6, '1006090', '88184c3a376240c5bda0976bd291f7b5', '1660068375', '1662660375', '103.199.200.76', 'Firefox', 'Mac OS X', 'Computer', 'Dhanbad, Jharkhand, India', 'active', 'seller'),
(7, '1006090', 'd882eea4877645d8a7fc8d7808792e10', '1660068515', '1662660515', '103.199.200.76', 'Firefox', 'Windows 8', 'Computer', 'Dhanbad, Jharkhand, India', 'active', 'admin'),
(8, '1006091', '9f2fcb5fd3f644b3a8f335f81c2b0512', '1660069123', '1662661123', '106.206.205.47', 'Handheld Browser', 'Android', 'Mobile', 'Patna, Bihar, India', 'active', 'seller');

-- --------------------------------------------------------

--
-- Table structure for table `otps`
--

CREATE TABLE `otps` (
  `otp_id` bigint(255) NOT NULL,
  `otp` bigint(255) NOT NULL,
  `otp_sender` varchar(255) NOT NULL,
  `valid_till` varchar(255) NOT NULL,
  `status` enum('valid','invalid') NOT NULL DEFAULT 'valid',
  `purpose` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `method_id` int(255) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `last_modified` varchar(255) NOT NULL,
  `status` enum('enabled','disabled') NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`method_id`, `uid`, `name`, `last_modified`, `status`, `details`) VALUES
(1, 'Razorpay', 'Razorpay', '', 'disabled', '{\"keyId\":\"\",\"keySecret\":\"\"}'),
(2, 'Paytm', 'Paytm', '1660064113', 'enabled', '{\"merchantKey\":\"&xMexbD%DUYhqGhX\",\"merchantMid\":\"WgbocG04046901552998\",\"environment\":\"TEST\"}'),
(3, 'CashOnDelivery', 'Cash On Delivery', '1660064102', 'enabled', '[]');

-- --------------------------------------------------------

--
-- Table structure for table `seller_users`
--

CREATE TABLE `seller_users` (
  `seller_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `bank_details` text DEFAULT NULL,
  `contact_details` text DEFAULT NULL,
  `pickup_address` text DEFAULT NULL,
  `store_logo_id` bigint(255) DEFAULT 0,
  `store_name` varchar(200) DEFAULT NULL,
  `store_description` varchar(5000) DEFAULT NULL,
  `status` enum('unverified','pending','verified','rejected','blocked') NOT NULL DEFAULT 'unverified',
  `status_reason` varchar(1000) DEFAULT NULL,
  `seller_since` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seller_users`
--

INSERT INTO `seller_users` (`seller_id`, `user_id`, `bank_details`, `contact_details`, `pickup_address`, `store_logo_id`, `store_name`, `store_description`, `status`, `status_reason`, `seller_since`) VALUES
(1, '1006090', NULL, '{\"contact_name\":\"JamsrWorld\",\"mobile_number\":\"9771701893\",\"contact_email\":\"princeraj9137@gmail.com\",\"preferred_language\":\"Hindi,English\"}', '{\"pickup_country\":\"India\",\"pickup_state\":\"Bihar\",\"pickup_city\":\"Bihar\",\"pickup_address\":\"Bihar\",\"pin_code\":\"Bihar\"}', 62, 'Jcart', 'Jcart', 'verified', NULL, '1660067125'),
(2, '1006091', NULL, NULL, NULL, 0, NULL, NULL, 'unverified', NULL, '1660069123');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `setting_id` bigint(255) NOT NULL,
  `mail_encryption` enum('ssl','tls') DEFAULT NULL,
  `mail_host` varchar(255) DEFAULT NULL,
  `mail_username` varchar(255) DEFAULT NULL,
  `mail_port` int(255) DEFAULT NULL,
  `mail_password` varchar(255) DEFAULT NULL,
  `web_logos` text DEFAULT NULL,
  `web_name` varchar(255) DEFAULT NULL,
  `currency` varchar(12) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `currency_position` enum('prefix','suffix') DEFAULT NULL,
  `primary_color` varchar(255) DEFAULT NULL,
  `timezone` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`setting_id`, `mail_encryption`, `mail_host`, `mail_username`, `mail_port`, `mail_password`, `web_logos`, `web_name`, `currency`, `date`, `currency_position`, `primary_color`, `timezone`) VALUES
(1, 'ssl', 'smtp.hostinger.com', 'support@fasinw.com', 465, 'Fasinw.com@958267', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sliders_banners`
--

CREATE TABLE `sliders_banners` (
  `component_id` bigint(255) NOT NULL,
  `heading` varchar(100) NOT NULL,
  `data` longtext NOT NULL,
  `card_index` int(9) NOT NULL,
  `type` enum('slider','banner','product_slider','category','manual_slider') NOT NULL,
  `columns` int(2) DEFAULT NULL,
  `tab_columns` int(2) DEFAULT NULL,
  `mobile_columns` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sliders_banners`
--

INSERT INTO `sliders_banners` (`component_id`, `heading`, `data`, `card_index`, `type`, `columns`, `tab_columns`, `mobile_columns`) VALUES
(1, 'Banner1', '[{\"image_id\":\"45\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"46\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"47\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"48\",\"url\":\"\",\"status\":\"active\"}]', 1, 'banner', 4, 2, 1),
(2, 'Slider1', '[{\"image_id\":\"9\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"10\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"11\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"12\",\"url\":\"\",\"status\":\"active\"}]', 2, 'slider', NULL, NULL, NULL),
(3, 'Slider2', '[{\"image_id\":\"14\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"15\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"16\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"17\",\"url\":\"\",\"status\":\"active\"}]', 3, 'slider', NULL, NULL, NULL),
(4, 'On Earbuds | Up to 60% off', '[{\"image_id\":\"19\",\"url\":\"\",\"text1\":\"Gamin TWS\",\"text2\":\"From \\u20b9899\",\"text3\":\"Shop Now\",\"status\":\"active\"},{\"image_id\":\"20\",\"url\":\"\",\"text1\":\"Laser Printers\",\"text2\":\"From \\u20b96999\",\"text3\":\"Canon, HP &amp; More\",\"status\":\"active\"},{\"image_id\":\"21\",\"url\":\"\",\"text1\":\"Top Sport\",\"text2\":\"From \\u20b979\",\"text3\":\"Basket Ball, Sacket &amp; More\",\"status\":\"active\"},{\"image_id\":\"22\",\"url\":\"\",\"text1\":\"Puzzle\",\"text2\":\"From \\u20b9 59\",\"text3\":\"Puzzle &amp; Cube Toys\",\"status\":\"active\"},{\"image_id\":\"23\",\"url\":\"\",\"text1\":\"Role Play Toys\",\"text2\":\"Min 30% Off\",\"text3\":\"Puppet, Doctor Set &amp; More\",\"status\":\"active\"},{\"image_id\":\"24\",\"url\":\"\",\"text1\":\"Physcial Games\",\"text2\":\"From \\u20b9666\",\"text3\":\"Shop Now\",\"status\":\"active\"},{\"image_id\":\"25\",\"url\":\"\",\"text1\":\"Gaming Mouse\",\"text2\":\"From \\u20b9249\",\"text3\":\"Shop Now\",\"status\":\"active\"},{\"image_id\":\"26\",\"url\":\"\",\"text1\":\"Office Study Chairs\",\"text2\":\"From \\u20b91,890\",\"text3\":\"Best For Work from Home\",\"status\":\"active\"}]', 4, 'manual_slider', 6, 4, 2),
(5, 'Manual Slider2', '[{\"image_id\":\"27\",\"url\":\"\",\"text1\":\"\",\"text2\":\"\",\"text3\":\"\",\"status\":\"active\"},{\"image_id\":\"28\",\"url\":\"\",\"text1\":\"\",\"text2\":\"\",\"text3\":\"\",\"status\":\"active\"},{\"image_id\":\"29\",\"url\":\"\",\"text1\":\"\",\"text2\":\"\",\"text3\":\"\",\"status\":\"active\"},{\"image_id\":\"30\",\"url\":\"\",\"text1\":\"\",\"text2\":\"\",\"text3\":\"\",\"status\":\"active\"},{\"image_id\":\"31\",\"url\":\"\",\"text1\":\"\",\"text2\":\"\",\"text3\":\"\",\"status\":\"active\"},{\"image_id\":\"32\",\"url\":\"\",\"text1\":\"\",\"text2\":\"\",\"text3\":\"\",\"status\":\"active\"},{\"image_id\":\"33\",\"url\":\"\",\"text1\":\"\",\"text2\":\"\",\"text3\":\"\",\"status\":\"active\"},{\"image_id\":\"34\",\"url\":\"\",\"text1\":\"\",\"text2\":\"\",\"text3\":\"\",\"status\":\"active\"}]', 5, 'manual_slider', 5, 4, 2),
(6, 'Smart Phones &amp; Basic Mobiles', '[{\"image_id\":\"35\",\"category_name\":\"Mobiles\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"36\",\"category_name\":\"Fashion\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"37\",\"category_name\":\"Electronics\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"38\",\"category_name\":\"Beauty\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"40\",\"category_name\":\"Home\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"41\",\"category_name\":\"Appliances\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"42\",\"category_name\":\"Furniture\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"43\",\"category_name\":\"Travel\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"44\",\"category_name\":\"Grocery\",\"url\":\"\",\"status\":\"active\"}]', 6, 'category', 7, 6, 4),
(7, 'Trending Products', '[{\"image_id\":\"54\",\"category_name\":\"Laptops\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"55\",\"category_name\":\"Earphone\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"56\",\"category_name\":\"Mens clothing\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"57\",\"category_name\":\"One plus\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"58\",\"category_name\":\"Bed rooms acceseries\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"61\",\"category_name\":\"Custom\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"60\",\"category_name\":\"Mobiles\",\"url\":\"\",\"status\":\"active\"}]', 7, 'category', 6, 6, 4),
(8, 'Banner3', '[{\"image_id\":\"49\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"50\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"51\",\"url\":\"\",\"status\":\"active\"}]', 8, 'banner', 3, 3, 1),
(9, 'Slider3', '[{\"image_id\":\"52\",\"url\":\"\",\"status\":\"active\"},{\"image_id\":\"53\",\"url\":\"\",\"status\":\"active\"}]', 9, 'slider', NULL, NULL, NULL),
(10, 'Featured Products', '{\"heading\":\"Featured Products\",\"category\":\"all\",\"sort_by\":\"sells\",\"total_columns\":\"12\",\"status\":\"active\"}', 10, 'product_slider', NULL, NULL, NULL),
(11, 'Slider4', '[]', 11, 'slider', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `support_tickets`
--

CREATE TABLE `support_tickets` (
  `ticket_id` bigint(255) NOT NULL,
  `creator` varchar(255) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  `last_reply_on` varchar(255) DEFAULT NULL,
  `status` enum('pending','active','closed') NOT NULL,
  `closed_on` varchar(222) DEFAULT NULL,
  `closed_by` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `support_ticket_messages`
--

CREATE TABLE `support_ticket_messages` (
  `message_id` bigint(255) NOT NULL,
  `ticket_id` varchar(255) NOT NULL,
  `replier` varchar(255) NOT NULL,
  `message` varchar(3000) NOT NULL,
  `date` varchar(255) NOT NULL,
  `files` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transaction_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `amount` decimal(25,2) NOT NULL,
  `txn_charge` decimal(65,2) NOT NULL,
  `charge_details` text DEFAULT NULL,
  `net_amount` decimal(65,2) NOT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `details` text NOT NULL,
  `status` enum('credit','debit','pending','failed','clearing') NOT NULL,
  `date` varchar(255) NOT NULL,
  `last_updated` varchar(255) NOT NULL,
  `type` enum('withdraw','order','other') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `serial_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `avatar_id` bigint(255) DEFAULT NULL,
  `status` enum('active','blocked') NOT NULL,
  `email_login` enum('on','off') NOT NULL DEFAULT 'on',
  `google_login` enum('on','off') NOT NULL DEFAULT 'off',
  `login_verification` enum('off','on') NOT NULL DEFAULT 'off',
  `registration_date` varchar(255) NOT NULL,
  `contact_number` bigint(255) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `user_role` enum('user','admin') NOT NULL DEFAULT 'user',
  `is_seller` enum('no','yes') NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`serial_id`, `user_id`, `user_email`, `first_name`, `last_name`, `password`, `avatar_id`, `status`, `email_login`, `google_login`, `login_verification`, `registration_date`, `contact_number`, `contact_email`, `user_role`, `is_seller`) VALUES
(1, '1006090', 'princeraj9137@gmail.com', 'Jamsr', 'World', '$2y$10$ZYxnp/siLE5.tMxlLhccTOv86LO59Zk3PVBmNYzotIjpSK4BDoEDe', 62, 'active', 'on', 'off', 'off', '1660064033', NULL, NULL, 'admin', 'yes'),
(2, '1006091', 'jaicky79003@gmail.com', 'Jaicky', 'Kumar', '$2y$10$zvedotZPZWJBUWXnHuZGAeyv7dA3b9tikpoRnGfEjEZ1N19jJCb8m', NULL, 'active', 'on', 'on', 'off', '1660069098', NULL, NULL, 'user', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `user_billing_addresses`
--

CREATE TABLE `user_billing_addresses` (
  `address_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `full_name` varchar(40) NOT NULL,
  `mobile_number` varchar(10) NOT NULL,
  `city` varchar(100) NOT NULL,
  `area` varchar(100) NOT NULL,
  `flat` varchar(100) NOT NULL,
  `landmark` varchar(100) NOT NULL,
  `state` varchar(30) NOT NULL,
  `postcode` bigint(6) NOT NULL,
  `address_type` enum('home','office') NOT NULL,
  `is_default` enum('yes','no') NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `check_google_signup`
--
ALTER TABLE `check_google_signup`
  ADD PRIMARY KEY (`serial_id`);

--
-- Indexes for table `ecommerce_answer_rating`
--
ALTER TABLE `ecommerce_answer_rating`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ecommerce_category`
--
ALTER TABLE `ecommerce_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `ecommerce_category_details`
--
ALTER TABLE `ecommerce_category_details`
  ADD PRIMARY KEY (`detail_id`);

--
-- Indexes for table `ecommerce_courier`
--
ALTER TABLE `ecommerce_courier`
  ADD PRIMARY KEY (`courier_id`);

--
-- Indexes for table `ecommerce_listing`
--
ALTER TABLE `ecommerce_listing`
  ADD PRIMARY KEY (`listing_id`);

--
-- Indexes for table `ecommerce_listing_variations`
--
ALTER TABLE `ecommerce_listing_variations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `svariation_id` (`svariation_id`);

--
-- Indexes for table `ecommerce_orders`
--
ALTER TABLE `ecommerce_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `ecommerce_order_transactions`
--
ALTER TABLE `ecommerce_order_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_id` (`transaction_id`),
  ADD UNIQUE KEY `razorpay_id` (`razorpay_id`);

--
-- Indexes for table `ecommerce_products`
--
ALTER TABLE `ecommerce_products`
  ADD PRIMARY KEY (`product_id`),
  ADD UNIQUE KEY `listing_id` (`listing_id`);

--
-- Indexes for table `ecommerce_product_answers_tbl`
--
ALTER TABLE `ecommerce_product_answers_tbl`
  ADD PRIMARY KEY (`answer_id`),
  ADD UNIQUE KEY `question_id` (`question_id`,`answered_by`);

--
-- Indexes for table `ecommerce_product_questions_tbl`
--
ALTER TABLE `ecommerce_product_questions_tbl`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `ecommerce_product_views`
--
ALTER TABLE `ecommerce_product_views`
  ADD PRIMARY KEY (`view_id`);

--
-- Indexes for table `ecommerce_qc`
--
ALTER TABLE `ecommerce_qc`
  ADD PRIMARY KEY (`qc_id`);

--
-- Indexes for table `ecommerce_replacement_orders`
--
ALTER TABLE `ecommerce_replacement_orders`
  ADD PRIMARY KEY (`replacement_id`),
  ADD UNIQUE KEY `order_id` (`order_id`),
  ADD UNIQUE KEY `new_order_id` (`new_order_id`);

--
-- Indexes for table `ecommerce_return_orders`
--
ALTER TABLE `ecommerce_return_orders`
  ADD PRIMARY KEY (`return_id`),
  ADD UNIQUE KEY `order_id` (`order_id`);

--
-- Indexes for table `ecommerce_reviews_rating`
--
ALTER TABLE `ecommerce_reviews_rating`
  ADD PRIMARY KEY (`rating_id`),
  ADD UNIQUE KEY `review_id` (`review_id`,`user_id`);

--
-- Indexes for table `ecommerce_reviews_tbl`
--
ALTER TABLE `ecommerce_reviews_tbl`
  ADD PRIMARY KEY (`review_id`),
  ADD UNIQUE KEY `review_id` (`review_id`,`reviewed_by`);

--
-- Indexes for table `ecommerce_search_relavance`
--
ALTER TABLE `ecommerce_search_relavance`
  ADD PRIMARY KEY (`relevance_id`);

--
-- Indexes for table `ecommerce_select`
--
ALTER TABLE `ecommerce_select`
  ADD PRIMARY KEY (`select_id`),
  ADD UNIQUE KEY `select_id` (`select_heading`);

--
-- Indexes for table `ecommerce_sellers_withdraw`
--
ALTER TABLE `ecommerce_sellers_withdraw`
  ADD PRIMARY KEY (`withdraw_id`);

--
-- Indexes for table `ecommerce_seller_verification`
--
ALTER TABLE `ecommerce_seller_verification`
  ADD PRIMARY KEY (`verification_id`);

--
-- Indexes for table `ecommerce_service_charges`
--
ALTER TABLE `ecommerce_service_charges`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `ecommerce_users_withdraw_gateways`
--
ALTER TABLE `ecommerce_users_withdraw_gateways`
  ADD PRIMARY KEY (`primary_id`);

--
-- Indexes for table `ecommerce_user_cart`
--
ALTER TABLE `ecommerce_user_cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `ecommerce_user_search_history`
--
ALTER TABLE `ecommerce_user_search_history`
  ADD PRIMARY KEY (`search_id`);

--
-- Indexes for table `ecommerce_variations`
--
ALTER TABLE `ecommerce_variations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ecommerce_withdraw_gateways`
--
ALTER TABLE `ecommerce_withdraw_gateways`
  ADD PRIMARY KEY (`gateway_id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`file_id`);

--
-- Indexes for table `layouts`
--
ALTER TABLE `layouts`
  ADD PRIMARY KEY (`layout_id`),
  ADD UNIQUE KEY `page` (`page_id`);

--
-- Indexes for table `login_session`
--
ALTER TABLE `login_session`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `otps`
--
ALTER TABLE `otps`
  ADD PRIMARY KEY (`otp_id`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`method_id`);

--
-- Indexes for table `seller_users`
--
ALTER TABLE `seller_users`
  ADD PRIMARY KEY (`seller_id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`setting_id`);

--
-- Indexes for table `sliders_banners`
--
ALTER TABLE `sliders_banners`
  ADD PRIMARY KEY (`component_id`),
  ADD UNIQUE KEY `card_index` (`card_index`);

--
-- Indexes for table `support_tickets`
--
ALTER TABLE `support_tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `support_ticket_messages`
--
ALTER TABLE `support_ticket_messages`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`serial_id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`user_email`);

--
-- Indexes for table `user_billing_addresses`
--
ALTER TABLE `user_billing_addresses`
  ADD PRIMARY KEY (`address_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `check_google_signup`
--
ALTER TABLE `check_google_signup`
  MODIFY `serial_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ecommerce_answer_rating`
--
ALTER TABLE `ecommerce_answer_rating`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_category`
--
ALTER TABLE `ecommerce_category`
  MODIFY `category_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ecommerce_category_details`
--
ALTER TABLE `ecommerce_category_details`
  MODIFY `detail_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `ecommerce_courier`
--
ALTER TABLE `ecommerce_courier`
  MODIFY `courier_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_listing`
--
ALTER TABLE `ecommerce_listing`
  MODIFY `listing_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ecommerce_listing_variations`
--
ALTER TABLE `ecommerce_listing_variations`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ecommerce_orders`
--
ALTER TABLE `ecommerce_orders`
  MODIFY `order_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_order_transactions`
--
ALTER TABLE `ecommerce_order_transactions`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_products`
--
ALTER TABLE `ecommerce_products`
  MODIFY `product_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ecommerce_product_answers_tbl`
--
ALTER TABLE `ecommerce_product_answers_tbl`
  MODIFY `answer_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_product_questions_tbl`
--
ALTER TABLE `ecommerce_product_questions_tbl`
  MODIFY `question_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_product_views`
--
ALTER TABLE `ecommerce_product_views`
  MODIFY `view_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ecommerce_qc`
--
ALTER TABLE `ecommerce_qc`
  MODIFY `qc_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ecommerce_replacement_orders`
--
ALTER TABLE `ecommerce_replacement_orders`
  MODIFY `replacement_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_return_orders`
--
ALTER TABLE `ecommerce_return_orders`
  MODIFY `return_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_reviews_rating`
--
ALTER TABLE `ecommerce_reviews_rating`
  MODIFY `rating_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_reviews_tbl`
--
ALTER TABLE `ecommerce_reviews_tbl`
  MODIFY `review_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_search_relavance`
--
ALTER TABLE `ecommerce_search_relavance`
  MODIFY `relevance_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_select`
--
ALTER TABLE `ecommerce_select`
  MODIFY `select_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `ecommerce_sellers_withdraw`
--
ALTER TABLE `ecommerce_sellers_withdraw`
  MODIFY `withdraw_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_seller_verification`
--
ALTER TABLE `ecommerce_seller_verification`
  MODIFY `verification_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ecommerce_service_charges`
--
ALTER TABLE `ecommerce_service_charges`
  MODIFY `service_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ecommerce_users_withdraw_gateways`
--
ALTER TABLE `ecommerce_users_withdraw_gateways`
  MODIFY `primary_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_user_cart`
--
ALTER TABLE `ecommerce_user_cart`
  MODIFY `cart_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_user_search_history`
--
ALTER TABLE `ecommerce_user_search_history`
  MODIFY `search_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `ecommerce_variations`
--
ALTER TABLE `ecommerce_variations`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ecommerce_withdraw_gateways`
--
ALTER TABLE `ecommerce_withdraw_gateways`
  MODIFY `gateway_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `file_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `layouts`
--
ALTER TABLE `layouts`
  MODIFY `layout_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `login_session`
--
ALTER TABLE `login_session`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `otps`
--
ALTER TABLE `otps`
  MODIFY `otp_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `method_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `seller_users`
--
ALTER TABLE `seller_users`
  MODIFY `seller_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `setting_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sliders_banners`
--
ALTER TABLE `sliders_banners`
  MODIFY `component_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `support_tickets`
--
ALTER TABLE `support_tickets`
  MODIFY `ticket_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `support_ticket_messages`
--
ALTER TABLE `support_ticket_messages`
  MODIFY `message_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `serial_id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_billing_addresses`
--
ALTER TABLE `user_billing_addresses`
  MODIFY `address_id` bigint(255) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
