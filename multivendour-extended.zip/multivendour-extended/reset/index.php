<?php


require_once "../db.php";

$db->query('SET foreign_key_checks = 0');
if ($result = $db->query("SHOW TABLES")) {
    while ($row = $result->fetch()) {
        $db->query('DROP TABLE IF EXISTS ' . $row->Tables_in_acart_few);
    }
}

$db->query('SET foreign_key_checks = 1');

$tempLine = '';
// Read in the full file
$lines = file("sql.sql");
// Loop through each line
foreach ($lines as $line) {

    // Skip it if it's a comment
    if (substr($line, 0, 2) == '--' || $line == '')
        continue;

    // Add this line to the current segment
    $tempLine .= $line;
    // If its semicolon at the end, so that is the end of one query
    if (substr(trim($line), -1, 1) == ';') {
        // Perform the query
        $query = $db->query($tempLine);
        // Reset temp variable to empty
        $tempLine = '';
    }
}

$base_url = $Web->base_url();
header("location:$base_url");
