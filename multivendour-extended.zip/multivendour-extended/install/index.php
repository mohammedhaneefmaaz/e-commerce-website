<?php
$installPage = "1";
require_once "../db.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo Basics::$web_name; ?> </title>
    <link rel="stylesheet" href="install.css">
</head>

<body>
    <div class="wrapper">
        <div class="center align-center">
            <h1 class="title font-bold"><?php echo Basics::$web_name; ?> </h1>
            <p class="version">Version 2.5</p>
            <a href="install" class="clrSecondary button">Install</a>
        </div>
    </div>
</body>
</html>