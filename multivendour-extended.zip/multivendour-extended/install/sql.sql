-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 14, 2022 at 12:21 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `acart_few`
--

-- --------------------------------------------------------

--
-- Table structure for table `check_google_signup`
--

CREATE TABLE `check_google_signup` (
  `serial_id` bigint(255) NOT NULL,
  `google_id` varchar(100) NOT NULL,
  `google_email` varchar(255) NOT NULL,
  `type` enum('login','register') NOT NULL,
  `details` text NOT NULL,
  `status` enum('1','2') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_answer_rating`
--

CREATE TABLE `ecommerce_answer_rating` (
  `id` bigint(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `question_id` bigint(255) NOT NULL,
  `answer_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `action` enum('like','dislike') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_category`
--

CREATE TABLE `ecommerce_category` (
  `category_id` bigint(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `parent_id` bigint(255) NOT NULL,
  `level` bigint(255) NOT NULL,
  `has_details` enum('no','yes') NOT NULL DEFAULT 'no',
  `images` text DEFAULT NULL,
  `variations` text DEFAULT NULL,
  `status` enum('draft','active','archived','rejected') NOT NULL DEFAULT 'draft',
  `data` longtext DEFAULT NULL,
  `has_content` enum('no','yes') NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_category_details`
--

CREATE TABLE `ecommerce_category_details` (
  `detail_id` bigint(255) NOT NULL,
  `category_id` bigint(255) NOT NULL,
  `mandatory` varchar(255) NOT NULL,
  `option_text` varchar(255) NOT NULL,
  `option_type` varchar(255) NOT NULL,
  `select_id` varchar(255) NOT NULL,
  `filter` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_courier`
--

CREATE TABLE `ecommerce_courier` (
  `courier_id` bigint(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `url` varchar(1000) NOT NULL,
  `status` enum('active','deleted') NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_listing`
--

CREATE TABLE `ecommerce_listing` (
  `listing_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `category_id` bigint(255) NOT NULL,
  `category_variation` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_listing_variations`
--

CREATE TABLE `ecommerce_listing_variations` (
  `id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `listing_id` varchar(255) NOT NULL,
  `variation_id` varchar(255) NOT NULL,
  `svariation_id` varchar(255) NOT NULL,
  `variation_value` varchar(255) DEFAULT NULL,
  `svariation_value` varchar(255) DEFAULT NULL,
  `variation_data` text DEFAULT NULL,
  `svariation_data` text DEFAULT NULL,
  `details` text DEFAULT NULL,
  `images` text DEFAULT NULL,
  `price` bigint(255) DEFAULT NULL,
  `mrp` bigint(255) DEFAULT NULL,
  `stock` bigint(255) DEFAULT NULL,
  `low_stock_warning` int(21) DEFAULT NULL,
  `sku_id` varchar(21) DEFAULT NULL,
  `product_name` varchar(1000) DEFAULT NULL,
  `minimum_order` int(251) DEFAULT NULL,
  `maximum_order` int(251) DEFAULT NULL,
  `cod_status` enum('no','yes') DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT NULL,
  `return_policy` enum('no','replacement','return') DEFAULT NULL,
  `return_policy_days` varchar(100) DEFAULT NULL,
  `return_policy_tc` varchar(5000) DEFAULT NULL,
  `highlights` text DEFAULT NULL,
  `description` varchar(5000) DEFAULT NULL,
  `date_created` varchar(43) NOT NULL,
  `last_modified` varchar(43) NOT NULL,
  `is_draft` enum('no','yes') NOT NULL DEFAULT 'yes',
  `tags` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_orders`
--

CREATE TABLE `ecommerce_orders` (
  `order_id` bigint(255) NOT NULL,
  `buyer_id` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `variation_id` varchar(255) NOT NULL,
  `svariation_id` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(65,2) NOT NULL,
  `total_price` decimal(65,2) NOT NULL,
  `shipping_charge` decimal(65,2) NOT NULL DEFAULT 0.00,
  `service_charge` decimal(65,2) NOT NULL DEFAULT 0.00,
  `grand_total` decimal(61,2) NOT NULL,
  `ordered_date` varchar(255) NOT NULL,
  `return_policy` text NOT NULL,
  `address` text NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `status` enum('PENDING','FAILED','SUCCESS','LABELLED','CANCELLED','RTD','SHIPPED','REJECTED','DELIVERED','REPLACEMENT','RETURNED','PICKUP_SCHEDULED') NOT NULL,
  `cancelled_on` varchar(255) DEFAULT NULL,
  `cancelled_reason` varchar(3000) DEFAULT NULL,
  `labelled_on` varchar(255) DEFAULT NULL,
  `rtd_on` varchar(255) DEFAULT NULL,
  `shipped_on` varchar(255) DEFAULT NULL,
  `delivered_on` varchar(255) DEFAULT NULL,
  `shipped_details` text DEFAULT NULL,
  `rejected_on` varchar(21) DEFAULT NULL,
  `rejected_reason` varchar(3000) DEFAULT NULL,
  `refund_status` enum('none','pending','completed') NOT NULL DEFAULT 'none',
  `refund_inited_on` varchar(255) DEFAULT NULL,
  `refund_comment` varchar(3000) DEFAULT NULL,
  `refund_date` varchar(255) DEFAULT NULL,
  `pickup_scheduled_on` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_order_transactions`
--

CREATE TABLE `ecommerce_order_transactions` (
  `id` bigint(255) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `razorpay_id` varchar(255) DEFAULT NULL,
  `buyer_id` varchar(255) NOT NULL,
  `orders` text NOT NULL,
  `payable_amount` bigint(255) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `status` varchar(100) NOT NULL,
  `transaction_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_products`
--

CREATE TABLE `ecommerce_products` (
  `product_id` bigint(255) NOT NULL,
  `listing_id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `category_id` bigint(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_product_answers_tbl`
--

CREATE TABLE `ecommerce_product_answers_tbl` (
  `answer_id` bigint(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `question_id` bigint(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `answer` varchar(1000) NOT NULL,
  `answered_by` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_product_questions_tbl`
--

CREATE TABLE `ecommerce_product_questions_tbl` (
  `question_id` bigint(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `question` varchar(100) NOT NULL,
  `date_asked` varchar(255) NOT NULL,
  `asker_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_product_views`
--

CREATE TABLE `ecommerce_product_views` (
  `view_id` bigint(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `variation_id` varchar(255) NOT NULL,
  `svariation_id` varchar(255) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `views` bigint(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `last_viewed` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_qc`
--

CREATE TABLE `ecommerce_qc` (
  `qc_id` bigint(255) NOT NULL,
  `qvariation_id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `listing_id` varchar(255) NOT NULL,
  `variation_id` varchar(255) NOT NULL,
  `svariation_id` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL,
  `reject_reason` varchar(1000) DEFAULT NULL,
  `error_portions` text DEFAULT NULL,
  `date_requested` varchar(255) NOT NULL,
  `date_processed` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_replacement_orders`
--

CREATE TABLE `ecommerce_replacement_orders` (
  `replacement_id` bigint(255) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `requested_date` varchar(211) NOT NULL,
  `replacement_reason` varchar(3000) NOT NULL,
  `status` enum('initiated','accepted','rejected','cancelled','pickup_scheduled','completed') NOT NULL DEFAULT 'initiated',
  `processed_comment` varchar(3000) DEFAULT NULL,
  `accepted_on` varchar(211) DEFAULT NULL,
  `rejected_on` varchar(211) DEFAULT NULL,
  `completed_date` varchar(211) DEFAULT NULL,
  `pickup_scheduled_date` varchar(211) DEFAULT NULL,
  `pickup_scheduled_comment` varchar(3000) DEFAULT NULL,
  `cancelled_on` varchar(255) DEFAULT NULL,
  `new_order_id` varchar(255) DEFAULT NULL,
  `images` text NOT NULL,
  `refund_reason` varchar(3000) DEFAULT NULL,
  `return_shipping_charge` decimal(65,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_return_orders`
--

CREATE TABLE `ecommerce_return_orders` (
  `return_id` bigint(255) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `requested_date` varchar(211) NOT NULL,
  `return_reason` varchar(3000) NOT NULL,
  `status` enum('initiated','accepted','rejected','cancelled','pickup_scheduled','completed') NOT NULL DEFAULT 'initiated',
  `processed_comment` varchar(3000) DEFAULT NULL,
  `accepted_on` varchar(211) DEFAULT NULL,
  `rejected_on` varchar(211) DEFAULT NULL,
  `completed_date` varchar(211) DEFAULT NULL,
  `pickup_scheduled_date` varchar(211) DEFAULT NULL,
  `pickup_scheduled_comment` varchar(3000) DEFAULT NULL,
  `cancelled_on` varchar(255) DEFAULT NULL,
  `images` text NOT NULL,
  `return_shipping_charge` decimal(65,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_reviews_rating`
--

CREATE TABLE `ecommerce_reviews_rating` (
  `rating_id` bigint(255) NOT NULL,
  `review_id` bigint(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `action` enum('like','dislike') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_reviews_tbl`
--

CREATE TABLE `ecommerce_reviews_tbl` (
  `review_id` bigint(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `reviewed_by` varchar(255) NOT NULL,
  `rating` int(5) NOT NULL,
  `review` varchar(3000) NOT NULL,
  `images` varchar(200) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_search_relavance`
--

CREATE TABLE `ecommerce_search_relavance` (
  `relevance_id` bigint(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `variation_id` varchar(255) NOT NULL,
  `search_keyword` varchar(1000) NOT NULL,
  `views` bigint(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_select`
--

CREATE TABLE `ecommerce_select` (
  `select_id` bigint(255) NOT NULL,
  `select_heading` varchar(255) DEFAULT NULL,
  `options` longtext NOT NULL,
  `date_created` varchar(255) DEFAULT NULL,
  `last_modified` varchar(255) DEFAULT NULL,
  `is_temp` enum('no','yes') NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_sellers_withdraw`
--

CREATE TABLE `ecommerce_sellers_withdraw` (
  `withdraw_id` bigint(255) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `gateway` text NOT NULL,
  `gross_amount` float(65,2) NOT NULL,
  `charge` float(65,2) NOT NULL,
  `net_amount` float(65,2) NOT NULL,
  `date_requested` varchar(255) NOT NULL,
  `date_processed` varchar(255) DEFAULT NULL,
  `db_labels` text NOT NULL,
  `user_labels` text NOT NULL,
  `status` enum('pending','rejected','success') NOT NULL,
  `rejected_reason` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_seller_verification`
--

CREATE TABLE `ecommerce_seller_verification` (
  `verification_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `status` enum('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  `rejected_reason` varchar(1000) DEFAULT NULL,
  `requested_on` varchar(255) NOT NULL,
  `action_date` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_service_charges`
--

CREATE TABLE `ecommerce_service_charges` (
  `service_id` bigint(255) NOT NULL,
  `service_name` varchar(255) NOT NULL,
  `service_charge` bigint(255) NOT NULL,
  `charge_type` enum('fixed','percentage') NOT NULL,
  `created_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_users_withdraw_gateways`
--

CREATE TABLE `ecommerce_users_withdraw_gateways` (
  `primary_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `gateway_id` varchar(255) NOT NULL,
  `labels` text NOT NULL,
  `date_created` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_user_cart`
--

CREATE TABLE `ecommerce_user_cart` (
  `cart_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `variation_id` varchar(255) NOT NULL,
  `svariation_id` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `role` enum('cart','saved','wishlist','checkout') NOT NULL,
  `last_updated` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_user_search_history`
--

CREATE TABLE `ecommerce_user_search_history` (
  `search_id` bigint(255) NOT NULL,
  `search_text` varchar(1000) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `last_updated` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_variations`
--

CREATE TABLE `ecommerce_variations` (
  `id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `variation_id` varchar(255) NOT NULL,
  `svariation_id` varchar(255) NOT NULL,
  `variation_value` varchar(255) DEFAULT NULL,
  `svariation_value` varchar(255) DEFAULT NULL,
  `variation_data` text DEFAULT NULL,
  `svariation_data` text DEFAULT NULL,
  `details` text DEFAULT NULL,
  `images` text DEFAULT NULL,
  `price` bigint(255) DEFAULT NULL,
  `mrp` bigint(255) DEFAULT NULL,
  `stock` bigint(255) DEFAULT NULL,
  `low_stock_warning` int(21) DEFAULT NULL,
  `sku_id` varchar(21) DEFAULT NULL,
  `product_name` varchar(200) DEFAULT NULL,
  `minimum_order` int(251) DEFAULT NULL,
  `maximum_order` int(251) DEFAULT NULL,
  `cod_status` enum('no','yes') NOT NULL,
  `status` enum('active','inactive','archived','blocked','rejected') DEFAULT NULL,
  `return_policy` enum('no','replacement','return') DEFAULT NULL,
  `return_policy_days` varchar(100) DEFAULT NULL,
  `return_policy_tc` varchar(5000) DEFAULT NULL,
  `highlights` text DEFAULT NULL,
  `description` varchar(5000) DEFAULT NULL,
  `date_created` varchar(43) NOT NULL,
  `last_modified` varchar(43) NOT NULL,
  `tags` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_withdraw_gateways`
--

CREATE TABLE `ecommerce_withdraw_gateways` (
  `gateway_id` bigint(255) NOT NULL,
  `gateway_name` varchar(255) NOT NULL,
  `logo_id` varchar(255) NOT NULL,
  `processing_time` varchar(255) NOT NULL,
  `charge` int(255) NOT NULL,
  `charge_type` enum('fixed','percentage') NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `card_heading` varchar(255) NOT NULL,
  `labels` text NOT NULL,
  `date_created` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `file_id` bigint(255) NOT NULL,
  `file_src` text NOT NULL,
  `file_name` varchar(5000) NOT NULL,
  `type` enum('file','url','web') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `layouts`
--

CREATE TABLE `layouts` (
  `layout_id` bigint(255) NOT NULL,
  `page_id` varchar(100) NOT NULL,
  `components` longtext NOT NULL,
  `created_date` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `login_session`
--

CREATE TABLE `login_session` (
  `id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `valid_till` varchar(255) NOT NULL,
  `user_ip` varchar(255) NOT NULL,
  `user_browser` varchar(255) NOT NULL,
  `user_os` varchar(255) NOT NULL,
  `user_device` varchar(255) NOT NULL,
  `user_location` varchar(255) NOT NULL,
  `status` enum('active','expired') NOT NULL DEFAULT 'active',
  `role` enum('visitor','seller','admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `otps`
--

CREATE TABLE `otps` (
  `otp_id` bigint(255) NOT NULL,
  `otp` bigint(255) NOT NULL,
  `otp_sender` varchar(255) NOT NULL,
  `valid_till` varchar(255) NOT NULL,
  `status` enum('valid','invalid') NOT NULL DEFAULT 'valid',
  `purpose` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `method_id` int(255) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `last_modified` varchar(255) NOT NULL,
  `status` enum('enabled','disabled') NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `seller_users`
--

CREATE TABLE `seller_users` (
  `seller_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `bank_details` text DEFAULT NULL,
  `contact_details` text DEFAULT NULL,
  `pickup_address` text DEFAULT NULL,
  `store_logo_id` bigint(255) DEFAULT 0,
  `store_name` varchar(200) DEFAULT NULL,
  `store_description` varchar(5000) DEFAULT NULL,
  `status` enum('unverified','pending','verified','rejected','blocked') NOT NULL DEFAULT 'unverified',
  `status_reason` varchar(1000) DEFAULT NULL,
  `seller_since` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `setting_id` bigint(255) NOT NULL,
  `mail_encryption` enum('ssl','tls') DEFAULT NULL,
  `mail_host` varchar(255) DEFAULT NULL,
  `mail_username` varchar(255) DEFAULT NULL,
  `mail_port` int(255) DEFAULT NULL,
  `mail_password` varchar(255) DEFAULT NULL,
  `web_logos` text DEFAULT NULL,
  `web_name` varchar(255) DEFAULT NULL,
  `currency` varchar(12) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `currency_position` enum('prefix','suffix') DEFAULT NULL,
  `primary_color` varchar(255) DEFAULT NULL,
  `timezone` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sliders_banners`
--

CREATE TABLE `sliders_banners` (
  `component_id` bigint(255) NOT NULL,
  `heading` varchar(100) NOT NULL,
  `data` longtext NOT NULL,
  `card_index` int(9) NOT NULL,
  `type` enum('slider','banner','product_slider','category','manual_slider') NOT NULL,
  `columns` int(2) DEFAULT NULL,
  `tab_columns` int(2) DEFAULT NULL,
  `mobile_columns` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `support_tickets`
--

CREATE TABLE `support_tickets` (
  `ticket_id` bigint(255) NOT NULL,
  `creator` varchar(255) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  `last_reply_on` varchar(255) DEFAULT NULL,
  `status` enum('pending','active','closed') NOT NULL,
  `closed_on` varchar(222) DEFAULT NULL,
  `closed_by` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `support_ticket_messages`
--

CREATE TABLE `support_ticket_messages` (
  `message_id` bigint(255) NOT NULL,
  `ticket_id` varchar(255) NOT NULL,
  `replier` varchar(255) NOT NULL,
  `message` varchar(3000) NOT NULL,
  `date` varchar(255) NOT NULL,
  `files` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transaction_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `amount` decimal(25,2) NOT NULL,
  `txn_charge` decimal(65,2) NOT NULL,
  `charge_details` text DEFAULT NULL,
  `net_amount` decimal(65,2) NOT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `details` text NOT NULL,
  `status` enum('credit','debit','pending','failed','clearing') NOT NULL,
  `date` varchar(255) NOT NULL,
  `last_updated` varchar(255) NOT NULL,
  `type` enum('withdraw','order','other') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `serial_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `avatar_id` bigint(255) DEFAULT NULL,
  `status` enum('active','blocked') NOT NULL,
  `email_login` enum('on','off') NOT NULL DEFAULT 'on',
  `google_login` enum('on','off') NOT NULL DEFAULT 'off',
  `login_verification` enum('off','on') NOT NULL DEFAULT 'off',
  `registration_date` varchar(255) NOT NULL,
  `contact_number` bigint(255) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `user_role` enum('user','admin') NOT NULL DEFAULT 'user',
  `is_seller` enum('no','yes') NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_billing_addresses`
--

CREATE TABLE `user_billing_addresses` (
  `address_id` bigint(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `full_name` varchar(40) NOT NULL,
  `mobile_number` varchar(10) NOT NULL,
  `city` varchar(100) NOT NULL,
  `area` varchar(100) NOT NULL,
  `flat` varchar(100) NOT NULL,
  `landmark` varchar(100) NOT NULL,
  `state` varchar(30) NOT NULL,
  `postcode` bigint(6) NOT NULL,
  `address_type` enum('home','office') NOT NULL,
  `is_default` enum('yes','no') NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `check_google_signup`
--
ALTER TABLE `check_google_signup`
  ADD PRIMARY KEY (`serial_id`);

--
-- Indexes for table `ecommerce_answer_rating`
--
ALTER TABLE `ecommerce_answer_rating`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ecommerce_category`
--
ALTER TABLE `ecommerce_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `ecommerce_category_details`
--
ALTER TABLE `ecommerce_category_details`
  ADD PRIMARY KEY (`detail_id`);

--
-- Indexes for table `ecommerce_courier`
--
ALTER TABLE `ecommerce_courier`
  ADD PRIMARY KEY (`courier_id`);

--
-- Indexes for table `ecommerce_listing`
--
ALTER TABLE `ecommerce_listing`
  ADD PRIMARY KEY (`listing_id`);

--
-- Indexes for table `ecommerce_listing_variations`
--
ALTER TABLE `ecommerce_listing_variations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `svariation_id` (`svariation_id`);

--
-- Indexes for table `ecommerce_orders`
--
ALTER TABLE `ecommerce_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `ecommerce_order_transactions`
--
ALTER TABLE `ecommerce_order_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_id` (`transaction_id`),
  ADD UNIQUE KEY `razorpay_id` (`razorpay_id`);

--
-- Indexes for table `ecommerce_products`
--
ALTER TABLE `ecommerce_products`
  ADD PRIMARY KEY (`product_id`),
  ADD UNIQUE KEY `listing_id` (`listing_id`);

--
-- Indexes for table `ecommerce_product_answers_tbl`
--
ALTER TABLE `ecommerce_product_answers_tbl`
  ADD PRIMARY KEY (`answer_id`),
  ADD UNIQUE KEY `question_id` (`question_id`,`answered_by`);

--
-- Indexes for table `ecommerce_product_questions_tbl`
--
ALTER TABLE `ecommerce_product_questions_tbl`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `ecommerce_product_views`
--
ALTER TABLE `ecommerce_product_views`
  ADD PRIMARY KEY (`view_id`);

--
-- Indexes for table `ecommerce_qc`
--
ALTER TABLE `ecommerce_qc`
  ADD PRIMARY KEY (`qc_id`);

--
-- Indexes for table `ecommerce_replacement_orders`
--
ALTER TABLE `ecommerce_replacement_orders`
  ADD PRIMARY KEY (`replacement_id`),
  ADD UNIQUE KEY `order_id` (`order_id`),
  ADD UNIQUE KEY `new_order_id` (`new_order_id`);

--
-- Indexes for table `ecommerce_return_orders`
--
ALTER TABLE `ecommerce_return_orders`
  ADD PRIMARY KEY (`return_id`),
  ADD UNIQUE KEY `order_id` (`order_id`);

--
-- Indexes for table `ecommerce_reviews_rating`
--
ALTER TABLE `ecommerce_reviews_rating`
  ADD PRIMARY KEY (`rating_id`),
  ADD UNIQUE KEY `review_id` (`review_id`,`user_id`);

--
-- Indexes for table `ecommerce_reviews_tbl`
--
ALTER TABLE `ecommerce_reviews_tbl`
  ADD PRIMARY KEY (`review_id`),
  ADD UNIQUE KEY `review_id` (`review_id`,`reviewed_by`);

--
-- Indexes for table `ecommerce_search_relavance`
--
ALTER TABLE `ecommerce_search_relavance`
  ADD PRIMARY KEY (`relevance_id`);

--
-- Indexes for table `ecommerce_select`
--
ALTER TABLE `ecommerce_select`
  ADD PRIMARY KEY (`select_id`),
  ADD UNIQUE KEY `select_id` (`select_heading`);

--
-- Indexes for table `ecommerce_sellers_withdraw`
--
ALTER TABLE `ecommerce_sellers_withdraw`
  ADD PRIMARY KEY (`withdraw_id`);

--
-- Indexes for table `ecommerce_seller_verification`
--
ALTER TABLE `ecommerce_seller_verification`
  ADD PRIMARY KEY (`verification_id`);

--
-- Indexes for table `ecommerce_service_charges`
--
ALTER TABLE `ecommerce_service_charges`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `ecommerce_users_withdraw_gateways`
--
ALTER TABLE `ecommerce_users_withdraw_gateways`
  ADD PRIMARY KEY (`primary_id`);

--
-- Indexes for table `ecommerce_user_cart`
--
ALTER TABLE `ecommerce_user_cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `ecommerce_user_search_history`
--
ALTER TABLE `ecommerce_user_search_history`
  ADD PRIMARY KEY (`search_id`);

--
-- Indexes for table `ecommerce_variations`
--
ALTER TABLE `ecommerce_variations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ecommerce_withdraw_gateways`
--
ALTER TABLE `ecommerce_withdraw_gateways`
  ADD PRIMARY KEY (`gateway_id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`file_id`);

--
-- Indexes for table `layouts`
--
ALTER TABLE `layouts`
  ADD PRIMARY KEY (`layout_id`),
  ADD UNIQUE KEY `page` (`page_id`);

--
-- Indexes for table `login_session`
--
ALTER TABLE `login_session`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `otps`
--
ALTER TABLE `otps`
  ADD PRIMARY KEY (`otp_id`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`method_id`);

--
-- Indexes for table `seller_users`
--
ALTER TABLE `seller_users`
  ADD PRIMARY KEY (`seller_id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`setting_id`);

--
-- Indexes for table `sliders_banners`
--
ALTER TABLE `sliders_banners`
  ADD PRIMARY KEY (`component_id`),
  ADD UNIQUE KEY `card_index` (`card_index`);

--
-- Indexes for table `support_tickets`
--
ALTER TABLE `support_tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `support_ticket_messages`
--
ALTER TABLE `support_ticket_messages`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`serial_id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`user_email`);

--
-- Indexes for table `user_billing_addresses`
--
ALTER TABLE `user_billing_addresses`
  ADD PRIMARY KEY (`address_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `check_google_signup`
--
ALTER TABLE `check_google_signup`
  MODIFY `serial_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_answer_rating`
--
ALTER TABLE `ecommerce_answer_rating`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_category`
--
ALTER TABLE `ecommerce_category`
  MODIFY `category_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_category_details`
--
ALTER TABLE `ecommerce_category_details`
  MODIFY `detail_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_courier`
--
ALTER TABLE `ecommerce_courier`
  MODIFY `courier_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_listing`
--
ALTER TABLE `ecommerce_listing`
  MODIFY `listing_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_listing_variations`
--
ALTER TABLE `ecommerce_listing_variations`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_orders`
--
ALTER TABLE `ecommerce_orders`
  MODIFY `order_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_order_transactions`
--
ALTER TABLE `ecommerce_order_transactions`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_products`
--
ALTER TABLE `ecommerce_products`
  MODIFY `product_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_product_answers_tbl`
--
ALTER TABLE `ecommerce_product_answers_tbl`
  MODIFY `answer_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_product_questions_tbl`
--
ALTER TABLE `ecommerce_product_questions_tbl`
  MODIFY `question_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_product_views`
--
ALTER TABLE `ecommerce_product_views`
  MODIFY `view_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_qc`
--
ALTER TABLE `ecommerce_qc`
  MODIFY `qc_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_replacement_orders`
--
ALTER TABLE `ecommerce_replacement_orders`
  MODIFY `replacement_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_return_orders`
--
ALTER TABLE `ecommerce_return_orders`
  MODIFY `return_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_reviews_rating`
--
ALTER TABLE `ecommerce_reviews_rating`
  MODIFY `rating_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_reviews_tbl`
--
ALTER TABLE `ecommerce_reviews_tbl`
  MODIFY `review_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_search_relavance`
--
ALTER TABLE `ecommerce_search_relavance`
  MODIFY `relevance_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_select`
--
ALTER TABLE `ecommerce_select`
  MODIFY `select_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_sellers_withdraw`
--
ALTER TABLE `ecommerce_sellers_withdraw`
  MODIFY `withdraw_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_seller_verification`
--
ALTER TABLE `ecommerce_seller_verification`
  MODIFY `verification_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_service_charges`
--
ALTER TABLE `ecommerce_service_charges`
  MODIFY `service_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_users_withdraw_gateways`
--
ALTER TABLE `ecommerce_users_withdraw_gateways`
  MODIFY `primary_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_user_cart`
--
ALTER TABLE `ecommerce_user_cart`
  MODIFY `cart_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_user_search_history`
--
ALTER TABLE `ecommerce_user_search_history`
  MODIFY `search_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_variations`
--
ALTER TABLE `ecommerce_variations`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_withdraw_gateways`
--
ALTER TABLE `ecommerce_withdraw_gateways`
  MODIFY `gateway_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `file_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `layouts`
--
ALTER TABLE `layouts`
  MODIFY `layout_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login_session`
--
ALTER TABLE `login_session`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `otps`
--
ALTER TABLE `otps`
  MODIFY `otp_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `method_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `seller_users`
--
ALTER TABLE `seller_users`
  MODIFY `seller_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `setting_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sliders_banners`
--
ALTER TABLE `sliders_banners`
  MODIFY `component_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `support_tickets`
--
ALTER TABLE `support_tickets`
  MODIFY `ticket_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `support_ticket_messages`
--
ALTER TABLE `support_ticket_messages`
  MODIFY `message_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `serial_id` bigint(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_billing_addresses`
--
ALTER TABLE `user_billing_addresses`
  MODIFY `address_id` bigint(255) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
