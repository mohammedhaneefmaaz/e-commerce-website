<?php
$installPage = "1";
require_once "../db.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="install.css">
    <link rel="stylesheet" href="../assets/css/global.css">
    <title>Install-<?php echo Basics::$web_name; ?> </title>
</head>

<body>
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
            <div class="container-fluid">
                <div class="row wizard-setup">
                    <div class="col-md-12 min-w-350px min-w-md-400px col-lg-6 col-xl-4">
                        <div class="card">
                            <div class="card-header py-2 flex-column">
                                <h1 class="text-center"><?php echo Basics::$web_name; ?> </h1>
                                <h5 class="text-center">Welcome to the Installer</h5>
                            </div>
                            <div class="card-body">
                                <div class="f1" method="post">
                                    <div class="f1-steps">
                                        <div class="f1-progress">
                                            <div class="f1-progress-line" data-now-value="16.66" data-number-of-steps="3"></div>
                                        </div>
                                        <div class="f1-step active">
                                            <div class="f1-step-icon"><i class="fa fa-code"></i></div>
                                            <p>Start</p>
                                        </div>
                                        <div class="f1-step">
                                            <div class="f1-step-icon"><i class="fa fa-database"></i></div>
                                            <p>Database</p>
                                        </div>
                                        <div class="f1-step">
                                            <div class="f1-step-icon">
                                                <i class="fa fa-user"></i>
                                            </div>
                                            <p>Admin</p>
                                        </div>
                                    </div>

                                    <!--  -->
                                    <fieldset style="display: block;">
                                        <form default-validation="true" class="needs-validation" novalidate method="post">
                                            <input value="license_code" name="action" type="hidden">
                                            <div class="mb-4">
                                                <label for="f1-first-name">License Code</label>
                                                <input placeholder="License Code" name="license_code" required class="form-control">
                                                <div class="invalid-feedback">Please provide a valid License Code</div>
                                            </div>
                                            <div class="justify-right">
                                                <button type="submit" class="button clrPrimary">Next</button>
                                            </div>
                                        </form>
                                        <div class="f1-buttons">
                                            <button class="d-none btn clrPrimary btn-next" type="button">Next</button>
                                        </div>
                                    </fieldset>
                                    <!--  -->

                                    <!--  -->
                                    <fieldset>

                                        <form  default-validation="true" class="needs-validation" novalidate method="post">
                                            <input value="database" name="action" type="hidden">
                                            <div class="form-group mb-7">
                                                <label for="host">Host</label>
                                                <input id="host" type="text" class="form-control form-input" name="db_host" placeholder="Host" value="localhost" required="">
                                                <div class="invalid-feedback">Please provide a valid Host</div>
                                            </div>
                                            <div class="form-group mb-7">
                                                <label for="database_name">Database Name</label>
                                                <input id="database_name" type="text" class="form-control form-input" name="db_name" placeholder="Database Name" value="" required="">
                                                <div class="invalid-feedback">Please provide a valid Database Name</div>

                                            </div>
                                            <div class="form-group mb-7">
                                                <label for="user_name">Database Username</label>
                                                <input id="user_name" type="text" class="form-control form-input" name="db_user" placeholder="Database Username" value="root" required="">
                                                <div class="invalid-feedback">Please provide a valid Database Username</div>

                                            </div>
                                            <div class="form-group mb-7">
                                                <label for="password">Database Password</label>
                                                <input id="password" type="password" class="form-control form-input" name="db_password" placeholder="Database Password" value="">
                                                <div class="invalid-feedback">Please provide a valid Database Password</div>
                                            </div>
                                            <div class="justify-right mt-4">
                                                <button type="submit" class="ms-3 button clrSecondary">Next</button>
                                            </div>
                                        </form>
                                        <div class="f1-buttons">
                                            <button class="d-none btn btn-primary btn-next" type="submit">Next</button>
                                        </div>
                                    </fieldset>
                                    <!--  -->

                                    <!--  -->
                                    <fieldset>
                                        <form  default-validation="true" class="needs-validation" novalidate method="post">
                                            <input value="admin_data" name="action" type="hidden">
                                            <div class="form-group  mb-7">
                                                <label for="firstName">First name</label>
                                                <input type="text" class="form-control form-input" name="first_name" placeholder="First Name" value="" required="">
                                                <div class="invalid-feedback">Please provide a valid First name</div>
                                            </div>
                                            <div class="form-group  mb-7">
                                                <label for="LastName">Last Name</label>
                                                <input type="text" class="form-control form-input" name="last_name" placeholder="Last Name" value="" required="">
                                                <div class="invalid-feedback">Please provide a valid Last name</div>
                                            </div>
                                            <div class="form-group  mb-7">
                                                <label for="database_name">Email</label>
                                                <input id="database_name" type="email" class="form-control form-input" name="email" placeholder="Email" value="" required="">
                                                <div class="invalid-feedback">Please provide a valid Email</div>

                                            </div>
                                            <div class="form-group  mb-7">
                                                <label for="user_name">Password</label>
                                                <input required id="user_name" type="password" class="form-control form-input" name="password" placeholder="Password" value="">
                                                <div class="invalid-feedback">Please provide a valid Password</div>

                                            </div>
                                            <div class="form-group  mb-7">
                                                <label for="password">Confirm Password</label>
                                                <input required id="password" type="password" class="form-control form-input" name="confirm_password" placeholder="Confirm Password" value="">
                                                <div class="invalid-feedback">Please provide a valid Confirm Password</div>
                                            </div>

                                            <div class="f1-buttons">
                                                <button class="button clrSecondary btn-submit" type="submit">Submit</button>
                                            </div>
                                        </form>
                                    </fieldset>
                                    <!--  -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

<script src="../assets/js/global.js"></script>
<script src="../assets/js/proceed.js"></script>
<script src="../assets/js/scripts.js"></script>
<script src="install.js"></script>
<script>
    Install();
</script>

</html>