<?php


use Ecommerce\PaymentMethod;

error_reporting(E_ALL);
ini_set("display_errors", 1);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    exit();
}


if (!isset($_POST["action"])) {
    return_exit("Invalid request");
}

$action = $_POST["action"];

if ($action !== "admin_data") {
    function is_isset()
    {
        $requests =  func_get_args();
        $output = true;
        foreach ($requests as $request) {
            if (!isset($_POST[$request])) {
                $output = false;
            }
        }
        return $output;
    }

    function return_exit($text)
    {
        echo $text;
        exit();
    }
}

switch ($action) {
    case "license_code":
        if (!is_isset("license_code")) {
            return_exit("Invalid request");
        }
        $license_code = $_POST["license_code"];
        if ($license_code !== "J0K75E200") {
            return_exit("Invalid License Code");
        }
        $output = new stdClass;
        $output->message = "License Code Matched";
        echo json_encode($output);
        break;

    case "database":
        if (!is_isset("db_host", "db_name", "db_password", "db_user")) {
            return_exit("Invalid request");
        }

        $db_host = $_POST["db_host"];
        $db_password = $_POST["db_password"];
        $db_user = $_POST["db_user"];
        $db_name = $_POST["db_name"];

        if (!mysqli_connect($db_host, $db_user, $db_password)) {
            return_exit("Provide a valid database credentials" . mysqli_connect_error());
        }

        $conn = mysqli_connect($db_host, $db_user, $db_password);

        $sql = "CREATE DATABASE IF NOT EXISTS $db_name";
        if (!mysqli_query($conn, $sql)) {
            return_exit(mysqli_error($conn));
        }

        $conn = mysqli_connect($db_host, $db_user, $db_password, $db_name);
        $tempLine = '';
        // Read in the full file
        $lines = file("sql.sql");
        // Loop through each line
        foreach ($lines as $line) {

            // Skip it if it's a comment
            if (substr($line, 0, 2) == '--' || $line == '')
                continue;

            // Add this line to the current segment
            $tempLine .= $line;
            // If its semicolon at the end, so that is the end of one query
            if (substr(trim($line), -1, 1) == ';') {
                // Perform the query
                $query = mysqli_query($conn, $tempLine);
                if (!$query) {
                    mysqli_query($conn, "DROP DATABASE $db_name");
                    return_exit("Error in " . $tempLine . ":" . mysqli_error($conn));
                }
                // Reset temp variable to empty
                $tempLine = '';
            }
        }

        $txt_file = file_get_contents("../db.php");
        $rows = explode("\n", $txt_file);
        foreach ($rows as $row => &$data) {
            if (strstr($data, 'db_host_name') !== FALSE) {
                $rows[$row + 1] = 'public $host = "' . $db_host . '";';
            }
            if (strstr($data, 'db_user_name') !== FALSE) {
                $rows[$row + 1] = 'public $userName = "' . $db_user . '";';
            }
            if (strstr($data, 'db_password') !== FALSE) {
                $rows[$row + 1] = 'public $password = "' . $db_password . '";';
            }
            if (strstr($data, 'db_name') !== FALSE) {
                $rows[$row + 1] = 'public $dbName = "' . $db_name . '";';
            }
            $data = $data . "\n";
        }

        file_put_contents('../db.php', $rows);
        $output = new stdClass;
        $output->message = "Database created successfully";
        echo json_encode($output);

        break;

    case "admin_data":

        require_once "../db.php";

        if (!$db) Errors::response("Invalid Installation");

        if (!$Web->is_isset("first_name", "last_name", "email", "password", "confirm_password")) {
            Errors::response("Invalid request");
        }

        $first_name = $Web->sanitize_text($_POST["first_name"]);
        $last_name = $Web->sanitize_text($_POST["last_name"]);
        $email = $Web->sanitize_text($_POST["email"]);
        $password = $Web->sanitize_text($_POST["password"]);
        $confirm_password = $Web->sanitize_text($_POST["confirm_password"]);
        $user_id = 1006090;

        $Web->validate_post_input($email, "email", "Email", true);
        $Web->validate_post_input($first_name, "alpha_numeric", "Firstname", true);
        $Web->validate_post_input($last_name, "alpha_numeric", "Lastname", true);
        $Web->validate_post_input($password, "", "Password", true);
        $Web->validate_post_input($confirm_password, "", "Confirm Password", true);

        if (User::is_user_id($user_id)) Errors::response("Already Installed");

        if ($password !== $confirm_password) {
            Errors::response("Passwords are not matching");
        }

        $password = password_hash($password, PASSWORD_BCRYPT);
        $current_time = $Web->current_time();

        try {

            $db->beginTransaction();

            // Creating Admin
            $stmt = $db->prepare("INSERT INTO $Web->users_tbl (`user_id`, `user_email`, `first_name`, `last_name`, `password`, `status`,`email_login`, `registration_date`,`user_role`)
            VALUES (?,?,?,?,?,?,?,?,?) ");
            $stmt->execute([$user_id, $email, $first_name, $last_name, $password, 'active', 'on', $current_time, 'admin']);


            // Inserting Library Start

            $library = [

                "Gender" => '["Women","Men","Girls","Boys","BabyGirl","BabyBoy","Men & Women","Boys & Girls","BabyBoy & BabyGirls"]',

                "Colour" => '["Brown","Black","Orange","Beige","Grey","Maroon","Gold","Blue","Assorted","CharcoalGrey","Multicolored","Red","Silver","Off-White","White","Khaki","Pink","Purple","Yellow","Green","Metallic","DarkBlue","DarkBrown","DarkGreen","LightBlue","LightBrown","LightGreen","Nude","Bronze","Multicolor","Turquoise","Clear"]',

                "Product Care Instructions" => '["Hand-wash","Machine-wash","Dry Clean Only","First Time Dry-Clean followed by hand wash","First Time Dry-Clean followed by machine wash","Hand Wash Only"]',

                "Style Name" => '["Regular","A-Line","Batwing","Blouse","ButtonUp","Crop","Boxy","Cape","ColdShoulder","CutOut","Empire","Henley","Hooded","Jerseys","Kaftan","Layered","Nursing","Peasant","Peplum","Poncho","Ruffles","Tie-Ups","Tunic","Tuxedo","Wrap","Longline","Polo","Dress","Cropped","T-Shirt","Camisole","Business Casual","Bodysuit","Casual","Puff Sleeve","Tank"]',

                "Size" => '[ "S", "XS", "2XS", "3XS", "4XS", "5XS", "M", "L", "XL", "2XL", "3XL", "4XL", "5XL", "Free Size", "Newborn", "0", "2", "4", "6", "8", "10", "12", "14", "16", "18", "20", "22", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "42", "44", "46", "48", "50", "52", "54", "56", "58", "0-3 Months", "3-6 Months", "6-12 Months", "12-18 Months", "18-24 Months", "2-3 Years", "3-4 Years", "4-5 Years", "5-6 Years", "6-7 Years", "7-8 Years", "8-9 Years", "9-10 Years", "10-11 Years", "11-12 Years", "12-13 Years", "13-14 Years", "14-15 Years", "15-16 Years", "16-17 Years", "17-18 Years", "24W x 30L", "24W x 32L", "25W x 30L", "25W x 32L", "26W x 30L", "26W x 32L", "27W x 30L", "27W x 32L", "28W x 30L", "28W x 32L", "28W x 34L", "29W x 30L", "29W x 32L", "29W x 34L", "30W x 30L", "30W x 32L", "30W x 34L", "31W x 30L", "31W x 32L", "31W x 34L", "32W x 30L", "32W x 32L", "32W x 34L", "33W x 30L", "33W x 32L", "33W x 34L", "34W x 30L", "34W x 32L", "34W x 34L", "35W x 30L", "35W x 32L", "35W x 34L", "36W x 30L", "36W x 32L", "36W x 34L", "38W x 30L", "38W x 32L", "38W x 34L", "40W x 30L", "40W x 32L", "40W x 34L", "42W x 30L", "42W x 32L", "42W x 34L", "44W x 30L", "44W x 32L", "44W x 34L", "46W x 30L", "46W x 32L", "46W x 34L", "48W x 30L", "48W x 32L", "48W x 34L" ]',

                "Material Type" => '["Acrylic","AcrylicBlend","Cashmere","CashmereBlend","Corduroy","Cotton","Cottonblend","Denim","FauxFur","Fleece","Jacquard","Leather","Linen","LinenBlend","Modal","ModalBlend","Nylon","NylonBlend","Polyester","PolyesterBlend","Polyurethane(PU)","Rayon","RayonBlend","Satin","Satinblend","Seude","Silk","SilkBlend","Velvet","Velvetblend","ViscoseBlend","Wool","Woolblend","Faux Leather","Spandex","Polycotton","Neoprene","Suede","Rubber"]',

                "Sleeve Type" => '["Sleeveless","HalfSleeve","Fullsleeve","3/4thsleeve","CapSleeve","Lantern Sleeve","Batwing Sleeve","Cuff Sleeve","Long Sleeve","Cape Sleeve","Raglan Sleeve","Ruffle Sleeve","3/4 Sleeve","Short Sleeve","Puff Sleeve","Bell Sleeve"]',

                "Pattern" => '["Embellished","Animal Print","Cartoon","Abstract Print","All Over Print","Checkered","Aztec Print","Camouflage","Striped","Ombre","Dobby Print","Block Print","Textured","Graphic Print","Geometric Print","Tribal","Embroidered","Floral","Tie-Dye","Polka Dot","Paisley","Solid","Plaid","Color Block","Botanic Print","Starred","Self-Design","Ethnic motifs","Printed","Character Print","Conversational","Varsity","Assorted","Faded","Logo"]',

                "Fitting Type" => '["Regular Fit","Slim Fit","Loose Fit","Tailored Fit","Western","Overall","Compression","Fitted","Regular","Relaxed","Stretch","Slim","Classic","Loose","Skinny"]',

                "Neck Style" => '["Polo","RoundNeck","V-Neck","Henley","ScoopNeck","ButtonFront","CrewNeck","TurtleNeck","Collared","BoatNeck","Hood","AsymmetricNeck","Cowl","Halter","OffShoulder","OneShoulder","SquareNeck","Strapless","SweetheartNeck","Half-Zip"]',

                "Collar Style" => '["Classic Collar","Cutaway Collar","Mandarin Collar","Button Down Collar","Round Collar","Collarless","Banded Collar","Club Collar","Spread Collar","Wingtip Collar","Spread","Tab","Club","Cutaway","Hidden Button Down","Wingtip","Band","Straight Point","Button Down","Camp"]',

                "Country Of Origin" => '["India","China","United States","Afghanistan","Aland Islands","Albania","Algeria","American Samoa","Andorra","Angola","Anguilla","Antarctica","Antigua And Barbuda","Argentina","Armenia","Aruba","Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bermuda","Bhutan","Bolivia","Bosnia and Herzegovina","Botswana","Bouvet Island","Brazil","British Indian Ocean Territory","British Virgin Islands","Brunei","Bulgaria","Burkina Faso","Burma (Myanmar)","Burundi","Cambodia","Cameroon","Canada","Cape Verde","Cayman Islands","Central African Republic","Chad","Chile","Christmas Island","Cocos (Keeling) Islands","Colombia","Comoros","Cook Islands","Costa Rica","Croatia","Cuba","Cyprus","Czech Republic","Democratic Republic of the Congo","Denmark","Djibouti","Dominica","Dominican Republic","Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia","Ethiopia","Falkland Islands","Faroe Islands","Fiji","Finland","France","French Guiana","French Polynesia","French Southern Territories","Great Britain","Gabon","Gambia","Georgia","Germany","Ghana","Gibraltar","Greece","Greenland","Grenada","Guadeloupe","Guam","Guatemala","Guernsey","Guinea","Guinea-Bissau","Guyana","Haiti","Heard and McDonald Islands","Holy See (Vatican City)","Honduras","Hong Kong","Hungary","Iceland","Indonesia","Iran","Iraq","Ireland","Isle of Man","Israel","Italy","Ivory Coast","Jamaica","Japan","Jersey","Jordan","Kazakhstan","Kenya","Kiribati","Kuwait","Kyrgyzstan","Laos","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania","Luxembourg","Macau","North Macedonia","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Martinique","Mauritania","Mauritius","Mayotte","Mexico","Micronesia","Moldova","Monaco","Mongolia","Montserrat","Morocco","Mozambique","Namibia","Nauru","Nepal","Netherlands","New Caledonia","New Zealand","Nicaragua","Niger","Nigeria","Niue","Norfolk Island","North Korea","Northern Mariana Islands","Norway","Oman","Pakistan","Palau","Palestinian Territory","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Pitcairn Islands","Poland","Portugal","Puerto Rico","Qatar","Republic of the Congo","Reunion","Romania","Russia","Rwanda","S. Georgia and S. Sandwich Isls.","Saint Helena","Saint Kitts And Nevis","Saint Lucia","Saint Pierre and Miquelon","Saint Vincent And The Grenadines","Saint-Martin","Samoa","San Marino","Sao Tome And Principe","Saudi Arabia","Senegal","Serbia","Seychelles","Sierra Leone","Singapore","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa","South Korea","Spain","Sri Lanka","Sudan","Suriname","Svalbard","Swaziland","Sweden","Switzerland","Syria","Taiwan","Tajikistan","Tanzania","Thailand","Timor-Leste","Togo","Tokelau","Tonga","Trinidad And Tobago","Tunisia","Turkey","Turkmenistan","Turks And Caicos Islands","Tuvalu","Uganda","Ukraine","United Arab Emirates","Uruguay","US Minor Outlying Islands","US Virgin Islands","Uzbekistan","Vanuatu","Venezuela","Vietnam","Wallis and Futuna","Western Sahara","Yemen","Zambia","Zimbabwe","Unknown","United Kingdom"]'
            ];

            foreach ($library as $key => $value) {
                $stmt = $db->prepare("INSERT INTO $Web->ecommerce_select_tbl (`select_heading`, `options`, `date_created`, `last_modified`, `is_temp`) VALUES (?,?,?,?,?) ");
                $stmt->execute([$key, $value, $Web->current_time(), $Web->current_time(), 'no']);
            }

            // Inserting Library End


            PaymentMethod::insertPaymentMethod();
            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            Errors::response("Error in registration" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Account created successfully";
        $output->url =  $Web->admin_url() . '/login';
        echo json_encode($output);
        break;
}
