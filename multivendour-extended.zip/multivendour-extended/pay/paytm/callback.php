<?php
require_once "../../db.php";

$Login->check_user_login();

header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");


use Ecommerce\Order;
use Ecommerce\OrderTransaction;
use Ecommerce\PaymentMethod;


$PaymentMethod = "Paytm";

$PAYTM_data = PaymentMethod::getMethodDetails($PaymentMethod);
if ($PAYTM_data->status !== "enabled") Errors::response_404();


require_once("./lib/config_paytm.php");
require_once("./lib/encdec_paytm.php");

$paytmChecksum = "";
$paramList = array();
$isValidChecksum = "FALSE";
$paramList = $_POST;
$paytmChecksum = isset($_POST["CHECKSUMHASH"]) ? $_POST["CHECKSUMHASH"] : "";
$isValidChecksum = verifychecksum_e($paramList, PAYTM_MERCHANT_KEY, $paytmChecksum);

try {
    $db->beginTransaction();

    if ($isValidChecksum === "TRUE") {
        $transaction_id = $_POST['ORDERID'];
        $transaction_amount = $_POST['TXNAMOUNT'];
        $transaction_date = !empty($_POST['TXNDATE']) ? strtotime($_POST['TXNDATE']) : $Web->current_time();
        $transaction_amount = (int) $transaction_amount;
        if (!OrderTransaction::is_transaction_id($transaction_id)) $card = OrderTransaction::checksumMismatchCard();
        else {
            $OrderTransaction = new OrderTransaction($transaction_id);
            $productAmount = $OrderTransaction->payable_amount();
            $productAmount = (int) $productAmount;
            $orders = $OrderTransaction->orders();

            if ($productAmount !== $transaction_amount) $card = $OrderTransaction->checksumMismatchCard();
            else if ($OrderTransaction->buyer() !== $LogUser->user_id) $card = $OrderTransaction->checksumMismatchCard();
            else if ($OrderTransaction->payment_method() !== $PaymentMethod) $card = $OrderTransaction->checksumMismatchCard();
            else if ($_POST["STATUS"] === "TXN_SUCCESS") {
                if ($OrderTransaction->status() == "PENDING") {


                    foreach ($orders as $order_id) {
                        $Order = new Order($order_id);

                        $Product = $Order->product();
                        $product_id = $Order->product_id();
                        $variation_id = $Order->variation_id();
                        $svariation_id = $Order->svariation_id();
                        $quantity = $Order->quantity();

                        $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET STATUS = 'SUCCESS', ordered_date = ? WHERE order_id = ? AND buyer_id = ? AND payment_method = ?");
                        $stmt->execute([$transaction_date, $order_id, $LogUser->user_id, $PaymentMethod]);


                        $stmt = $db->prepare("UPDATE $Web->ecommerce_variations_tbl SET stock = stock - ? WHERE product_id =? AND variation_id = ? AND svariation_id = ? ");
                        $stmt->execute([$quantity, $product_id, $variation_id, $svariation_id]);

                        $listing_id = $Product->listing_id();

                        $stmt = $db->prepare("UPDATE $Web->ecommerce_listing_variations_tbl SET stock = stock - ? WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? ");
                        $stmt->execute([$quantity, $listing_id, $variation_id, $svariation_id]);
                    }
                }
                $card = $OrderTransaction->paymentSuccessCard();
            } else {

                if ($OrderTransaction->status() == "PENDING") {
                    $orders = $OrderTransaction->orders();
                    foreach ($orders as $order_id) {
                        $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET STATUS = 'FAILED',ordered_date = ?  WHERE order_id = ? AND buyer_id = ?  AND payment_method = ?   ");
                        $stmt->execute([$transaction_date, $order_id, $LogUser->user_id, $PaymentMethod]);
                    }
                }
                $err = $_GET["errorMessage"] ?? false;
                $card = $OrderTransaction->PaymentFailedCard($err);
            }
        }
    } else {
        $card = OrderTransaction::checksumMismatchCard();
    }
    $db->commit();
} catch (\Exception $e) {
    $db->rollBack();
    exit("Error in checkout");
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>Paytm - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/visitor/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">
                        <?php echo $card; ?>
                    </div>
                </div>
                <?php include $Web->include("partials/visitor/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
</body>

</html>