<?php
header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");
include "../../db.php";
$Login->check_user_login();

use Ecommerce\PaymentMethod;
use Ecommerce\OrderTransaction;

$PaymentMethod = "Paytm";

$PAYTM_data = PaymentMethod::getMethodDetails($PaymentMethod);
if ($PAYTM_data->status !== "enabled") Errors::response_404();


if (!isset($_GET["i"])) Errors::response_404();
$transaction_id = $_GET["i"];
$transaction_id = $Web->sanitize_text($transaction_id);

if (!OrderTransaction::is_transaction_id($transaction_id)) Errors::response_404();
$OrderTransaction = new OrderTransaction($transaction_id);

if ($OrderTransaction->buyer() !== $LogUser->user_id) Errors::response_404();
if ($OrderTransaction->status() !== "PENDING") Errors::response_404();
if ($OrderTransaction->payment_method() !== $PaymentMethod) Errors::response_404();

require_once("./lib/config_paytm.php");
require_once("./lib/encdec_paytm.php");

$checkSum = "";
$paramList = array();

$ORDER_ID = $transaction_id;
$CUST_ID = rand(10000000, 99999999);
$INDUSTRY_TYPE_ID = 'Retail';
$CHANNEL_ID = 'WEB';
$TXN_AMOUNT = $OrderTransaction->payable_amount();

// Create an array having all required parameters for creating checksum.
$paramList["MID"] = PAYTM_MERCHANT_MID;
$paramList["ORDER_ID"] = $ORDER_ID;
$paramList["CUST_ID"] = $CUST_ID;
$paramList["INDUSTRY_TYPE_ID"] = $INDUSTRY_TYPE_ID;
$paramList["CHANNEL_ID"] = $CHANNEL_ID;
$paramList["TXN_AMOUNT"] = $TXN_AMOUNT;
$paramList["WEBSITE"] = PAYTM_MERCHANT_WEBSITE;
$paramList["CALLBACK_URL"] = $Web->absolute_url() . '/pay/paytm/callback';
$checkSum = getChecksumFromArray($paramList, PAYTM_MERCHANT_KEY);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>Paytm - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/visitor/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <div class="mw-400px  p-10 m-auto card">
                            <div class="card-body">
                                <div class="py-4 text-center">
                                    <div class="spinner-grow" style="width: 3rem; height: 3rem;" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <h2 class="text-uppercase text-muted">Processing Order</h2>
                                </div>

                            </div>

                        </div>

                        <ul class="d-none">
                            <form method="POST" action="<?php echo PAYTM_TXN_URL ?>" name="f1">
                                <?php
                                foreach ($paramList as $name => $value) {
                                    echo '<input style="display:none;" readonly type="hidden" name="' . $name . '" value="' . $value . '">';
                                }
                                ?>
                                <input type="hidden" name="CHECKSUMHASH" value="<?php echo $checkSum ?>">
                                <script type="text/javascript">
                                    document.f1.submit();
                                </script>
                            </form>
                        </ul>

                    </div>
                </div>
                <?php include $Web->include("partials/visitor/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
</body>

</html>