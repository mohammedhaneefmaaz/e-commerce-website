<?php
session_start();

require_once "../../db.php";
$Login->check_user_login();


require('razorpay-php/Razorpay.php');

use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;


use Ecommerce\Order;
use Ecommerce\OrderTransaction;
use Ecommerce\PaymentMethod;

$PaymentMethod = "Razorpay";

$RAZORPAY_data = PaymentMethod::getMethodDetails($PaymentMethod);
if ($RAZORPAY_data->status !== "enabled") Errors::response_404();

$keyId = $RAZORPAY_data->details->keyId;
$keySecret = $RAZORPAY_data->details->keySecret;

try {
    $db->beginTransaction();

    if (empty($_POST['razorpay_payment_id']) === false) {
        $api = new Api($keyId, $keySecret);

        $razorpay_payment_id  = $_POST["razorpay_payment_id"];
        $razorpay_order_id  = $_SESSION["razorpay_order_id"];
        if (!OrderTransaction::is_razorpay_order_id($razorpay_order_id))  $card = OrderTransaction::checksumMismatchCard();
        else {
            $transaction_id = OrderTransaction::transaction_id_by_razorpay($razorpay_order_id);

            $OrderTransaction = new OrderTransaction($transaction_id);
            $status = $OrderTransaction->status();
            $transaction_date = $Web->current_time();
            if ($OrderTransaction->payment_method() !== $PaymentMethod) $card = $OrderTransaction->checksumMismatchCard();
            else {
                try {
                    $attributes = array(
                        'razorpay_order_id' => $_SESSION['razorpay_order_id'],
                        'razorpay_payment_id' => $_POST['razorpay_payment_id'],
                        'razorpay_signature' => $_POST['razorpay_signature']
                    );

                    $api->utility->verifyPaymentSignature($attributes);

                    if ($status === "PENDING") {

                        $orders = $OrderTransaction->orders();
                        foreach ($orders as $order_id) {
                            $Order = new Order($order_id);

                            $Product = $Order->product();
                            $product_id = $Order->product_id();
                            $variation_id = $Order->variation_id();
                            $svariation_id = $Order->svariation_id();
                            $quantity = $Order->quantity();


                            $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET STATUS = 'SUCCESS', ordered_date = ? WHERE order_id = ? AND buyer_id = ? AND payment_method = ?");
                            $stmt->execute([$transaction_date, $order_id, $LogUser->user_id, $PaymentMethod]);


                            $stmt = $db->prepare("UPDATE $Web->ecommerce_variations_tbl SET stock = stock - ? WHERE product_id =? AND variation_id = ? AND svariation_id = ? ");
                            $stmt->execute([$quantity, $product_id, $variation_id, $svariation_id]);

                            $listing_id = $Product->listing_id();

                            $stmt = $db->prepare("UPDATE $Web->ecommerce_listing_variations_tbl SET stock = stock - ? WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? ");
                            $stmt->execute([$quantity, $listing_id, $variation_id, $svariation_id]);
                        }
                    }

                    $card = $OrderTransaction->PaymentSuccessCard();
                } catch (SignatureVerificationError $e) {

                    if ($status == "PENDING") {
                        $orders = $OrderTransaction->orders();
                        foreach ($orders as $order_id) {
                            $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET STATUS = 'FAILED',ordered_date = ?  WHERE order_id = ? AND buyer_id = ?  AND payment_method = ?   ");
                            $stmt->execute([$transaction_date, $order_id, $LogUser->user_id, $PaymentMethod]);
                        }
                    }
                    $err = $e->getMessage();
                    $card = $OrderTransaction->PaymentFailedCard($err);
                }
            }
        }
    }
    $db->commit();
} catch (\Exception $e) {
    $db->rollBack();
    exit("Error in checkout".$e->getLine());
}




?>



<!DOCTYPE html>
<html lang="en">

<head>
    <title>Paytm - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/visitor/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">
                        <?php echo $card; ?>
                    </div>
                </div>
                <?php include $Web->include("partials/visitor/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
</body>

</html>