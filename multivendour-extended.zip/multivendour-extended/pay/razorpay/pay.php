<?php
session_start();

require_once "../../db.php";
require('razorpay-php/Razorpay.php');

$Login->check_user_login();

use Razorpay\Api\Api;
use Ecommerce\OrderTransaction;
use Ecommerce\PaymentMethod;


$PaymentMethod = "Razorpay";

$RAZORPAY_data = PaymentMethod::getMethodDetails($PaymentMethod);
if ($RAZORPAY_data->status !== "enabled") Errors::response_404();


$keyId = $RAZORPAY_data->details->keyId;
$keySecret = $RAZORPAY_data->details->keySecret;

$api = new Api($keyId, $keySecret);

if (!isset($_GET["i"])) Errors::response_404();
$transaction_id = $_GET["i"];
$transaction_id = $Web->sanitize_text($transaction_id);

if (!OrderTransaction::is_transaction_id($transaction_id)) Errors::response_404();
$OrderTransaction = new OrderTransaction($transaction_id);
$payable_amount = $OrderTransaction->payable_amount();

if ($OrderTransaction->buyer() !== $LogUser->user_id) Errors::response_404();
if ($OrderTransaction->status() !== "PENDING") Errors::response_404();
if ($OrderTransaction->payment_method() !== $PaymentMethod) Errors::response_404();

$orderData = [
    'receipt'         => 'rcptid_11',
    'amount'          => $payable_amount * 100,
    'currency'        => 'INR',
    'payment_capture' => 1
];

$razorpayOrder = $api->order->create($orderData);
$razorpayOrderId = $razorpayOrder['id'];
$_SESSION['razorpay_order_id'] = $razorpayOrderId;

$stmt = $db->prepare("UPDATE $Web->ecommerce_order_transactions_tbl SET razorpay_id = ? WHERE transaction_id = ? ");
$query = $stmt->execute([$razorpayOrderId, $transaction_id]);
if (!$query) {
    Errors::response("Error in checkout");
}

$data = new stdClass;
$data->key = $keyId;
$data->order_id = $razorpayOrderId;
$data->name = "Ecommerce";
$data->theme = ["color" => "#F37254"];

$json = json_encode($data);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pay Razorpay - <?php echo $Web->web_name(); ?></title>
</head>

<body>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <form name='razorpayform' action="verify" method="POST">
        <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id">
        <input type="hidden" name="razorpay_signature" id="razorpay_signature">
    </form>

    <script>
        var options = <?php echo $json ?>;
        options.handler = function(response) {
            document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
            document.getElementById('razorpay_signature').value = response.razorpay_signature;
            document.razorpayform.submit();
        };
        options.theme.image_padding = false;
        options.modal = {
            ondismiss: function() {
                console.log("This code runs when the popup is closed");
            },
            escape: false,
            backdropclose: false
        };
        options.prefill = {
            "name": "<?php echo $OrderTransaction->full_name(); ?>",
            "contact": "+91<?php echo $OrderTransaction->phone(); ?>",
            "email": "<?php echo $LogUser->email(); ?>"
        };
        var rzp = new Razorpay(options);

        rzp.open();
    </script>
</body>

</html>