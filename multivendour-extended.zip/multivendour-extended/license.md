Copyright (c) 2022,[JamsrWorld](https://jamsrworld.com/)

<-- Extended License -->

You are permitted to use and distribute the copies of this license if needed.
There are no limitations on the uses of this copy.

Permission is hereby granted, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.