<!-- Order Track Started -->
<div id="default_track_container">
    <div data-lx-swapper="true" data-lx-swapper-mode="append" data-lx-swapper-parent="{
      default: '#m_track_container', lg: '#default_track_container' }" class="card card-flush overflow-hidden">
        <div class="card-header">
            <div class="card-title">
                <h2>Events</h2>
            </div>
        </div>
        <div data-track-init="true" class="card-body pt-0">
            <!-- Track Started -->
            <div class="<?php if (!empty($Order->cancelled_on()) || !empty($Order->rejected_on())) {
                            echo "order-cancelled";
                        } ?> d-flex flex-md-row flex-column ">
                <div data-track-stop="ordered" class="timeline-step <?php if ($Order->status() == "SUCCESS" || $Order->status() == "LABELLED") echo "active "; ?> done">
                    <div class="timeline-stop"></div>
                    <div class="timeline-info">
                        <div class="timeline-info-status">Ordered On</div>
                        <div class="timeline-info-date"> <?php echo $Order->order_date(); ?></div>
                    </div>
                </div>
                <div class="timeline-track <?php if (!empty($Order->rtd_on())) {
                                                echo "done";
                                            } ?>">
                    <div class="timeline-track-path"></div>
                </div>
                <div data-track-stop="packed" class="timeline-step  <?php if ($Order->status() == "RTD" || $Order->status() == "PICKUP_SCHEDULED") echo "active ";
                                                                    if (!empty($Order->rtd_on())) {
                                                                        echo "done";
                                                                    } ?>">
                    <div class="timeline-stop"></div>
                    <div class="timeline-info">
                        <div class="timeline-info-status">Packed On</div>
                        <div class="timeline-info-date"> <?php echo $Order->rtd_on(); ?></div>
                    </div>
                </div>
                <div class="timeline-track  <?php if (!empty($Order->shipped_on())) {
                                                echo "done";
                                            } ?>">
                    <div class="timeline-track-path"></div>
                </div>
                <div data-track-stop="shipped" class="timeline-step  <?php if ($Order->status() == "SHIPPED") echo "active ";
                                                                        if (!empty($Order->shipped_on())) {
                                                                            echo "done";
                                                                        } ?>">
                    <div class="timeline-stop"></div>
                    <div class="timeline-info">
                        <div class="timeline-info-status">Shipped On</div>
                        <div class="timeline-info-date"><?php echo $Order->shipped_on(); ?></div>
                    </div>
                </div>
                <div class="timeline-track  <?php if (!empty($Order->delivered_on())) {
                                                echo "done";
                                            } ?>">
                    <div class="timeline-track-path"></div>
                </div>
                <div data-track-stop="delivered" class="timeline-step  <?php if (!empty($Order->delivered_on())) echo "active ";
                                                                        if (!empty($Order->delivered_on())) {
                                                                            echo "done";
                                                                        } ?>">
                    <div class="timeline-stop"></div>
                    <div class="timeline-info">
                        <div class="timeline-info-status">Delivered On</div>
                        <div class="timeline-info-date"><?php echo $Order->delivered_on(); ?></div>
                    </div>
                </div>
                <?php if ($Order->status_step() == 2) { ?>
                    <div class="timeline-track track-cancelled done">
                        <div class="timeline-track-path"></div>
                    </div>
                    <div data-track-stop="cancelled" class="timeline-step track-cancelled active done">
                        <div class="timeline-stop"></div>
                        <div class="timeline-info">
                            <div class="timeline-info-status">Cancelled On</div>
                            <div class="timeline-info-date"><?php echo $Order->cancelled_on(); ?></div>
                        </div>
                    </div>
                <?php  } ?>
                <?php if ($Order->status_step() == 3) { ?>
                    <div class="timeline-track track-cancelled done">
                        <div class="timeline-track-path"></div>
                    </div>
                    <div data-track-stop="rejected" class="timeline-step track-cancelled active done">
                        <div class="timeline-stop"></div>
                        <div class="timeline-info">
                            <div class="timeline-info-status">Rejected On</div>
                            <div class="timeline-info-date"><?php echo $Order->rejected_on(); ?></div>
                        </div>
                    </div>
                <?php  } ?>
            </div>
            <!-- Track End -->
            <!-- Notice Start -->
            <div class="mt-14">
                <div data-track="ordered" class="mt-4">
                    <div class="alert alert-warning d-flex align-items-center p-5">
                        <span class="svg-icon svg-icon-2hx svg-icon-warning me-4">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z" fill="black"></path>
                                <path d="M10.5606 11.3042L9.57283 10.3018C9.28174 10.0065 8.80522 10.0065 8.51412 10.3018C8.22897 10.5912 8.22897 11.0559 8.51412 11.3452L10.4182 13.2773C10.8099 13.6747 11.451 13.6747 11.8427 13.2773L15.4859 9.58051C15.771 9.29117 15.771 8.82648 15.4859 8.53714C15.1948 8.24176 14.7183 8.24176 14.4272 8.53714L11.7002 11.3042C11.3869 11.6221 10.874 11.6221 10.5606 11.3042Z" fill="black"></path>
                            </svg>
                        </span>
                        <div class="d-flex flex-column">
                            <h4 class="mb-1 text-warning">Order Placed</h4>
                            <div>Your order has been placed at <span class="text-gray-700"><?php echo $Order->order_date(); ?></span></div>
                        </div>
                    </div>
                </div>
                <?php if (!empty($Order->rtd_on())) { ?>
                    <div data-track="packed" class="mt-4">
                        <div class="alert alert-info d-flex align-items-center p-5">
                            <span class="svg-icon svg-icon-2hx svg-icon-info me-4">
                                <svg class="w-50px h-50px" viewBox="0 0 70 70" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0)">
                                        <path d="M15.9117 48.4248C15.3395 47.9455 14.4872 48.0209 14.008 48.593L10.629 52.6273L9.40776 51.5926C8.8383 51.1102 7.98573 51.1807 7.50317 51.7502C7.02073 52.3196 7.09127 53.1724 7.66073 53.6548L9.91884 55.5679C10.1638 55.7755 10.4737 55.8882 10.7924 55.8882C10.8307 55.8882 10.8691 55.8865 10.9076 55.8832C11.266 55.8525 11.5975 55.6803 11.8284 55.4045L16.0802 50.3284C16.5591 49.7563 16.4837 48.9041 15.9117 48.4248Z" fill="#3BB77E"></path>
                                        <path d="M44.0001 22V26C44.0001 26.5 42.0001 28 41.5001 28H32.5001C31.6667 27.8333 30.0001 27.8 30.0001 29V32.5L28.0001 33C27.5001 33.3333 26.5001 34.1 26.5001 34.5C26.5001 35 26.0001 36 26.5001 36.5C27.0001 37 28 37.5 28.5 38C29 38.5 30.0001 38 30.0001 38.5V40.5C30.0001 40.9 30.3334 42 30.5 42.5C30.8333 42.8333 31.6 43.5 32 43.5C32.4 43.5 33.1667 43.8333 33.5 44V45.5C33.5 45.9 34.1667 47 34.5 47.5C35 47.8333 36.2 48.5 37 48.5C38 48.5 46.5 49.5 48 49.5C49.2 49.5 53.1667 48.8333 55 48.5L58.5 46L63.5 45H66.5L68.5 44V41.5L69 31L68 29H64.5C64.1 29 62.3333 27.6667 61.5 27C60.8333 26.5 59.5 25.4 59.5 25C59.5 24.6 56.5 23.1667 55 22.5L53 22H48H45.5H44.0001Z" fill="#FDC040"></path>
                                        <path d="M26 8V20L30.0001 18.5L31.5 17.5L36.5 20L38 18.5L37.5 9L36 8H31H26Z" fill="none"></path>
                                        <path d="M44.0001 22C44.0001 23.1667 44.0001 25.6 44.0001 26M44.0001 22V26M44.0001 22H45.5M44.0001 26C44.0001 26.5 42.0001 28 41.5001 28M41.5001 28C41.1001 28 35.3334 28 32.5001 28M41.5001 28H32.5001M32.5001 28C31.6667 27.8333 30.0001 27.8 30.0001 29M30.0001 29C30.0001 30.2 30.0001 31.8333 30.0001 32.5M30.0001 29V32.5M30.0001 32.5L28.0001 33C27.5001 33.3333 26.5001 34.1 26.5001 34.5C26.5001 35 26.0001 36 26.5001 36.5C27.0001 37 28 37.5 28.5 38C29 38.5 30.0001 38 30.0001 38.5M30.0001 38.5C30.0001 39 30.0001 40 30.0001 40.5M30.0001 38.5V40.5M30.0001 40.5C30.0001 40.9 30.3334 42 30.5 42.5C30.8333 42.8333 31.6 43.5 32 43.5C32.4 43.5 33.1667 43.8333 33.5 44M33.5 44C33.5 44.3333 33.5 45.1 33.5 45.5M33.5 44V45.5M33.5 45.5C33.5 45.9 34.1667 47 34.5 47.5C35 47.8333 36.2 48.5 37 48.5C38 48.5 46.5 49.5 48 49.5C49.2 49.5 53.1667 48.8333 55 48.5L58.5 46L63.5 45H66.5L68.5 44V41.5L69 31L68 29M68 29C67 29 64.9 29 64.5 29M68 29H64.5M64.5 29C64.1 29 62.3333 27.6667 61.5 27C60.8333 26.5 59.5 25.4 59.5 25C59.5 24.6 56.5 23.1667 55 22.5L53 22H48H45.5M45.5 22H43.5M26 8C26 8.4 26 16.1667 26 20M26 8H31H36L37.5 9L38 18.5L36.5 20L31.5 17.5L30.0001 18.5L26 20M26 8V20" stroke="black" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M67.1381 27.5825H65.1959C63.5692 27.5073 62.2609 26.1218 60.7473 24.5185C59.7358 23.4473 58.6528 22.3003 57.3482 21.4502V9.89827C57.3482 7.86354 55.6928 6.20813 53.6582 6.20813H9.58066C7.54593 6.20813 5.89066 7.86354 5.89066 9.89827V19.2723C5.89066 20.0187 6.49566 20.6237 7.24201 20.6237C7.98836 20.6237 8.59336 20.0187 8.59336 19.2723V9.89827C8.59336 9.36313 9.04552 8.91083 9.58066 8.91083H24.5346V20.8672C24.5346 21.3584 24.8012 21.811 25.2308 22.0492C25.4348 22.1623 25.6605 22.2185 25.8858 22.2185C26.1348 22.2185 26.3834 22.1498 26.6021 22.0131L31.6211 18.8762L36.6363 22.013C37.053 22.2734 37.578 22.2875 38.0078 22.0493C38.4377 21.8112 38.7043 21.3587 38.7043 20.8673V8.91083H53.6584C54.1935 8.91083 54.6457 9.363 54.6457 9.89827V20.3045C54.2061 20.2125 53.7446 20.1572 53.2566 20.1485C53.2486 20.1484 53.2408 20.1484 53.2328 20.1484H49.8093H47.1503H45.6188C45.6117 20.1484 45.6049 20.1484 45.5978 20.1485C43.9688 20.1738 43.1317 20.9123 42.7163 21.5273C42.0716 22.4819 42.0119 23.7748 42.5476 25.1662C42.6723 25.4911 42.8243 25.7984 42.9995 26.0872H32.7523C30.5507 26.0872 28.7594 27.8784 28.7594 30.08C28.7594 30.5327 28.8351 30.9681 28.9742 31.3741H28.6155C26.4139 31.3741 24.6227 33.1653 24.6227 35.3671C24.6227 37.5688 26.4139 39.36 28.6155 39.36H28.9732C28.8347 39.7649 28.7593 40.1989 28.7593 40.6503C28.7593 42.7831 30.4369 44.531 32.5405 44.6415C32.4007 45.048 32.3247 45.4838 32.3247 45.9373C32.3247 48.1391 34.1159 49.9303 36.3176 49.9303H53.06C53.6366 49.9303 54.1615 49.8598 54.6453 49.7389V53.9733C54.6453 54.5106 54.1931 54.9644 53.658 54.9644H22.3566C22.6217 54.0203 22.7666 53.0264 22.7666 51.9987C22.7666 45.9452 17.8419 41.0203 11.7885 41.0203C10.6773 41.0203 9.60458 41.1876 8.59295 41.4961V31.4219C8.59295 30.6756 7.98795 30.0706 7.2416 30.0706C6.49525 30.0706 5.89025 30.6756 5.89025 31.4219V42.7467C2.83931 44.6991 0.810791 48.1154 0.810791 51.9988C0.810791 58.0545 5.73552 62.9811 11.7889 62.9811C15.7704 62.9811 19.2632 60.8494 21.1881 57.6672H53.6584C55.693 57.6672 57.3484 56.0102 57.3484 53.9734V48.4095C57.6467 48.1962 57.932 47.9775 58.2086 47.7642C59.402 46.8446 60.4326 46.0504 62.0736 46.0504H67.1382C68.7162 46.0504 70.0001 44.7683 70.0001 43.1923V30.4445C70 28.8662 68.7162 27.5825 67.1381 27.5825ZM36.0016 18.4281L32.338 16.1366C31.8997 15.8627 31.3436 15.8626 30.9051 16.1365L27.2373 18.4289V8.91083H36.0016V18.4281ZM11.7889 60.2784C7.22579 60.2784 3.51349 56.5642 3.51349 51.9988C3.51349 47.4356 7.22579 43.7231 11.7889 43.7231C16.352 43.7231 20.0643 47.4356 20.0643 51.9988C20.0643 56.5642 16.352 60.2784 11.7889 60.2784ZM67.2973 43.1923C67.2973 43.2752 67.223 43.3477 67.1381 43.3477H62.0735C59.5117 43.3477 57.943 44.5567 56.5588 45.6234C55.3957 46.5198 54.477 47.2277 53.0601 47.2277H36.3178C35.6065 47.2277 35.0277 46.6489 35.0277 45.9375C35.0277 45.226 35.6065 44.6472 36.3178 44.6472H40.8035C41.5499 44.6472 42.1549 44.0422 42.1549 43.2958C42.1549 42.5495 41.5499 41.9445 40.8035 41.9445H32.7524C32.0409 41.9445 31.4623 41.3641 31.4623 40.6504C31.4623 39.9389 32.0411 39.3602 32.7524 39.3602H40.8035C41.5499 39.3602 42.1549 38.7552 42.1549 38.0088C42.1549 37.2625 41.5499 36.6575 40.8035 36.6575H28.6157C27.9043 36.6575 27.3255 36.0787 27.3255 35.3672C27.3255 34.6557 27.9043 34.0769 28.6157 34.0769H40.8035C41.5499 34.0769 42.1549 33.4719 42.1549 32.7256C42.1549 31.9792 41.5499 31.3742 40.8035 31.3742H32.7524C32.0409 31.3742 31.4623 30.7937 31.4623 30.0802C31.4623 29.3687 32.0411 28.79 32.7524 28.79H47.8309H50.7638H52.723C53.4693 28.79 54.0743 28.185 54.0743 27.4387C54.0743 26.6923 53.4693 26.0873 52.723 26.0873H50.7638H47.8309C46.5949 26.0873 45.5115 25.3456 45.0704 24.1966C44.8134 23.5288 44.8834 23.148 44.9563 23.0399C45.0296 22.9315 45.2935 22.8576 45.6303 22.8512H49.8093H53.2204C55.4992 22.8968 57.094 24.586 58.7824 26.3741C60.5486 28.2448 62.3749 30.1791 65.1159 30.2842C65.1331 30.2849 65.1504 30.2852 65.1677 30.2852H67.1384C67.2246 30.2852 67.2976 30.3581 67.2976 30.4443V43.1923H67.2973Z" fill="#3BB77E"></path>
                                        <path d="M7.24198 26.7004C7.98833 26.7004 8.59333 26.0916 8.59333 25.3452C8.59333 24.5989 7.98833 23.9939 7.24198 23.9939C6.49563 23.9939 5.89062 24.5989 5.89062 25.3452V25.353C5.89062 26.0992 6.49563 26.7004 7.24198 26.7004Z" fill="none"></path>
                                    </g>
                                    <defs>
                                        <clipPath id="clip0">
                                            <rect width="69.1892" height="69.1892" fill="white" transform="translate(0.810791)"></rect>
                                        </clipPath>
                                    </defs>
                                </svg>
                            </span>
                            <div class="d-flex flex-column">
                                <h4 class="mb-1 text-info">Ready to dispatch</h4>
                                <div>Your order has been packed at <span class="text-gray-700"><?php echo $Order->rtd_on(); ?></span></div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <?php if (!empty($Order->shipped_on())) { ?>
                    <div data-track="shipped" class="mt-4">
                        <div class="alert alert-primary d-flex align-items-center p-5">
                            <span class="svg-icon svg-icon-2hx svg-icon-primary me-4">
                                <svg class="w-175px h-175px" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M20 8H16C15.4 8 15 8.4 15 9V16H10V17C10 17.6 10.4 18 11 18H16C16 16.9 16.9 16 18 16C19.1 16 20 16.9 20 18H21C21.6 18 22 17.6 22 17V13L20 8Z" fill="black"></path>
                                    <path opacity="0.3" d="M20 18C20 19.1 19.1 20 18 20C16.9 20 16 19.1 16 18C16 16.9 16.9 16 18 16C19.1 16 20 16.9 20 18ZM15 4C15 3.4 14.6 3 14 3H3C2.4 3 2 3.4 2 4V13C2 13.6 2.4 14 3 14H15V4ZM6 16C4.9 16 4 16.9 4 18C4 19.1 4.9 20 6 20C7.1 20 8 19.1 8 18C8 16.9 7.1 16 6 16Z" fill="black"></path>
                                </svg>
                            </span>
                            <div class="d-flex flex-column">
                                <h4 class="mb-1 text-primary">Order Shipped</h4>
                                <div> Your order has been dispatched from the seller warehouse at <span class="text-gray-700"><?php echo $Order->shipped_on(); ?></span></div>
                                <div class="my-2"> Your tracking ID is <b> <?php echo $Order->shipping()->tracking_id; ?> </b> </div>
                                <div class="mb-2"> You can check it on <a class="link" target="_blank" href="<?php echo $Order->shipping()->courier_service_url; ?>"><?php echo $Order->shipping()->courier_service; ?></a></div>
                                <div class="pre-wrap"> <?php echo $Order->shipping()->comment; ?> </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <?php if (!empty($Order->delivered_on())) { ?>
                    <div data-track="delivered" class="mt-4">
                        <div class="alert alert-success d-flex align-items-center p-5">
                            <span class="svg-icon svg-icon-2hx svg-icon-success me-4">
                                <svg class="w-50px h-50px" viewBox="0 0 70 70" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0)">
                                        <path d="M15.9117 48.4248C15.3395 47.9455 14.4872 48.0209 14.008 48.593L10.629 52.6273L9.40776 51.5926C8.8383 51.1102 7.98573 51.1807 7.50317 51.7502C7.02073 52.3196 7.09127 53.1724 7.66073 53.6548L9.91884 55.5679C10.1638 55.7755 10.4737 55.8882 10.7924 55.8882C10.8307 55.8882 10.8691 55.8865 10.9076 55.8832C11.266 55.8525 11.5975 55.6803 11.8284 55.4045L16.0802 50.3284C16.5591 49.7563 16.4837 48.9041 15.9117 48.4248Z" fill="#3BB77E"></path>
                                        <path d="M44.0001 22V26C44.0001 26.5 42.0001 28 41.5001 28H32.5001C31.6667 27.8333 30.0001 27.8 30.0001 29V32.5L28.0001 33C27.5001 33.3333 26.5001 34.1 26.5001 34.5C26.5001 35 26.0001 36 26.5001 36.5C27.0001 37 28 37.5 28.5 38C29 38.5 30.0001 38 30.0001 38.5V40.5C30.0001 40.9 30.3334 42 30.5 42.5C30.8333 42.8333 31.6 43.5 32 43.5C32.4 43.5 33.1667 43.8333 33.5 44V45.5C33.5 45.9 34.1667 47 34.5 47.5C35 47.8333 36.2 48.5 37 48.5C38 48.5 46.5 49.5 48 49.5C49.2 49.5 53.1667 48.8333 55 48.5L58.5 46L63.5 45H66.5L68.5 44V41.5L69 31L68 29H64.5C64.1 29 62.3333 27.6667 61.5 27C60.8333 26.5 59.5 25.4 59.5 25C59.5 24.6 56.5 23.1667 55 22.5L53 22H48H45.5H44.0001Z" fill="#FDC040"></path>
                                        <path d="M26 8V20L30.0001 18.5L31.5 17.5L36.5 20L38 18.5L37.5 9L36 8H31H26Z" fill="#FDC040"></path>
                                        <path d="M44.0001 22C44.0001 23.1667 44.0001 25.6 44.0001 26M44.0001 22V26M44.0001 22H45.5M44.0001 26C44.0001 26.5 42.0001 28 41.5001 28M41.5001 28C41.1001 28 35.3334 28 32.5001 28M41.5001 28H32.5001M32.5001 28C31.6667 27.8333 30.0001 27.8 30.0001 29M30.0001 29C30.0001 30.2 30.0001 31.8333 30.0001 32.5M30.0001 29V32.5M30.0001 32.5L28.0001 33C27.5001 33.3333 26.5001 34.1 26.5001 34.5C26.5001 35 26.0001 36 26.5001 36.5C27.0001 37 28 37.5 28.5 38C29 38.5 30.0001 38 30.0001 38.5M30.0001 38.5C30.0001 39 30.0001 40 30.0001 40.5M30.0001 38.5V40.5M30.0001 40.5C30.0001 40.9 30.3334 42 30.5 42.5C30.8333 42.8333 31.6 43.5 32 43.5C32.4 43.5 33.1667 43.8333 33.5 44M33.5 44C33.5 44.3333 33.5 45.1 33.5 45.5M33.5 44V45.5M33.5 45.5C33.5 45.9 34.1667 47 34.5 47.5C35 47.8333 36.2 48.5 37 48.5C38 48.5 46.5 49.5 48 49.5C49.2 49.5 53.1667 48.8333 55 48.5L58.5 46L63.5 45H66.5L68.5 44V41.5L69 31L68 29M68 29C67 29 64.9 29 64.5 29M68 29H64.5M64.5 29C64.1 29 62.3333 27.6667 61.5 27C60.8333 26.5 59.5 25.4 59.5 25C59.5 24.6 56.5 23.1667 55 22.5L53 22H48H45.5M45.5 22H43.5M26 8C26 8.4 26 16.1667 26 20M26 8H31H36L37.5 9L38 18.5L36.5 20L31.5 17.5L30.0001 18.5L26 20M26 8V20" stroke="black" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M67.1381 27.5825H65.1959C63.5692 27.5073 62.2609 26.1218 60.7473 24.5185C59.7358 23.4473 58.6528 22.3003 57.3482 21.4502V9.89827C57.3482 7.86354 55.6928 6.20813 53.6582 6.20813H9.58066C7.54593 6.20813 5.89066 7.86354 5.89066 9.89827V19.2723C5.89066 20.0187 6.49566 20.6237 7.24201 20.6237C7.98836 20.6237 8.59336 20.0187 8.59336 19.2723V9.89827C8.59336 9.36313 9.04552 8.91083 9.58066 8.91083H24.5346V20.8672C24.5346 21.3584 24.8012 21.811 25.2308 22.0492C25.4348 22.1623 25.6605 22.2185 25.8858 22.2185C26.1348 22.2185 26.3834 22.1498 26.6021 22.0131L31.6211 18.8762L36.6363 22.013C37.053 22.2734 37.578 22.2875 38.0078 22.0493C38.4377 21.8112 38.7043 21.3587 38.7043 20.8673V8.91083H53.6584C54.1935 8.91083 54.6457 9.363 54.6457 9.89827V20.3045C54.2061 20.2125 53.7446 20.1572 53.2566 20.1485C53.2486 20.1484 53.2408 20.1484 53.2328 20.1484H49.8093H47.1503H45.6188C45.6117 20.1484 45.6049 20.1484 45.5978 20.1485C43.9688 20.1738 43.1317 20.9123 42.7163 21.5273C42.0716 22.4819 42.0119 23.7748 42.5476 25.1662C42.6723 25.4911 42.8243 25.7984 42.9995 26.0872H32.7523C30.5507 26.0872 28.7594 27.8784 28.7594 30.08C28.7594 30.5327 28.8351 30.9681 28.9742 31.3741H28.6155C26.4139 31.3741 24.6227 33.1653 24.6227 35.3671C24.6227 37.5688 26.4139 39.36 28.6155 39.36H28.9732C28.8347 39.7649 28.7593 40.1989 28.7593 40.6503C28.7593 42.7831 30.4369 44.531 32.5405 44.6415C32.4007 45.048 32.3247 45.4838 32.3247 45.9373C32.3247 48.1391 34.1159 49.9303 36.3176 49.9303H53.06C53.6366 49.9303 54.1615 49.8598 54.6453 49.7389V53.9733C54.6453 54.5106 54.1931 54.9644 53.658 54.9644H22.3566C22.6217 54.0203 22.7666 53.0264 22.7666 51.9987C22.7666 45.9452 17.8419 41.0203 11.7885 41.0203C10.6773 41.0203 9.60458 41.1876 8.59295 41.4961V31.4219C8.59295 30.6756 7.98795 30.0706 7.2416 30.0706C6.49525 30.0706 5.89025 30.6756 5.89025 31.4219V42.7467C2.83931 44.6991 0.810791 48.1154 0.810791 51.9988C0.810791 58.0545 5.73552 62.9811 11.7889 62.9811C15.7704 62.9811 19.2632 60.8494 21.1881 57.6672H53.6584C55.693 57.6672 57.3484 56.0102 57.3484 53.9734V48.4095C57.6467 48.1962 57.932 47.9775 58.2086 47.7642C59.402 46.8446 60.4326 46.0504 62.0736 46.0504H67.1382C68.7162 46.0504 70.0001 44.7683 70.0001 43.1923V30.4445C70 28.8662 68.7162 27.5825 67.1381 27.5825ZM36.0016 18.4281L32.338 16.1366C31.8997 15.8627 31.3436 15.8626 30.9051 16.1365L27.2373 18.4289V8.91083H36.0016V18.4281ZM11.7889 60.2784C7.22579 60.2784 3.51349 56.5642 3.51349 51.9988C3.51349 47.4356 7.22579 43.7231 11.7889 43.7231C16.352 43.7231 20.0643 47.4356 20.0643 51.9988C20.0643 56.5642 16.352 60.2784 11.7889 60.2784ZM67.2973 43.1923C67.2973 43.2752 67.223 43.3477 67.1381 43.3477H62.0735C59.5117 43.3477 57.943 44.5567 56.5588 45.6234C55.3957 46.5198 54.477 47.2277 53.0601 47.2277H36.3178C35.6065 47.2277 35.0277 46.6489 35.0277 45.9375C35.0277 45.226 35.6065 44.6472 36.3178 44.6472H40.8035C41.5499 44.6472 42.1549 44.0422 42.1549 43.2958C42.1549 42.5495 41.5499 41.9445 40.8035 41.9445H32.7524C32.0409 41.9445 31.4623 41.3641 31.4623 40.6504C31.4623 39.9389 32.0411 39.3602 32.7524 39.3602H40.8035C41.5499 39.3602 42.1549 38.7552 42.1549 38.0088C42.1549 37.2625 41.5499 36.6575 40.8035 36.6575H28.6157C27.9043 36.6575 27.3255 36.0787 27.3255 35.3672C27.3255 34.6557 27.9043 34.0769 28.6157 34.0769H40.8035C41.5499 34.0769 42.1549 33.4719 42.1549 32.7256C42.1549 31.9792 41.5499 31.3742 40.8035 31.3742H32.7524C32.0409 31.3742 31.4623 30.7937 31.4623 30.0802C31.4623 29.3687 32.0411 28.79 32.7524 28.79H47.8309H50.7638H52.723C53.4693 28.79 54.0743 28.185 54.0743 27.4387C54.0743 26.6923 53.4693 26.0873 52.723 26.0873H50.7638H47.8309C46.5949 26.0873 45.5115 25.3456 45.0704 24.1966C44.8134 23.5288 44.8834 23.148 44.9563 23.0399C45.0296 22.9315 45.2935 22.8576 45.6303 22.8512H49.8093H53.2204C55.4992 22.8968 57.094 24.586 58.7824 26.3741C60.5486 28.2448 62.3749 30.1791 65.1159 30.2842C65.1331 30.2849 65.1504 30.2852 65.1677 30.2852H67.1384C67.2246 30.2852 67.2976 30.3581 67.2976 30.4443V43.1923H67.2973Z" fill="#3BB77E"></path>
                                        <path d="M7.24198 26.7004C7.98833 26.7004 8.59333 26.0916 8.59333 25.3452C8.59333 24.5989 7.98833 23.9939 7.24198 23.9939C6.49563 23.9939 5.89062 24.5989 5.89062 25.3452V25.353C5.89062 26.0992 6.49563 26.7004 7.24198 26.7004Z" fill="#3BB77E"></path>
                                    </g>
                                    <defs>
                                        <clipPath id="clip0">
                                            <rect width="69.1892" height="69.1892" fill="white" transform="translate(0.810791)"></rect>
                                        </clipPath>
                                    </defs>
                                </svg>
                            </span>
                            <div class="d-flex flex-column">
                                <h4 class="mb-1 text-success">Order Delivered</h4>
                                <div> Your order has been delivered at <span class="text-gray-700"><?php echo $Order->delivered_on(); ?></span></div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <?php if ($Order->status_step() == 2) { ?>
                    <div data-track="cancelled" class='mt-4'>
                        <div class="alert alert-danger d-flex align-items-center p-5">
                            <span class="svg-icon svg-icon-2hx svg-icon-danger me-4">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M12 10.6L14.8 7.8C15.2 7.4 15.8 7.4 16.2 7.8C16.6 8.2 16.6 8.80002 16.2 9.20002L13.4 12L12 10.6ZM10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 8.99999 16.4 9.19999 16.2L12 13.4L10.6 12Z" fill="black" />
                                    <path d="M22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2C17.5 2 22 6.5 22 12ZM13.4 12L16.2 9.20001C16.6 8.80001 16.6 8.19999 16.2 7.79999C15.8 7.39999 15.2 7.39999 14.8 7.79999L12 10.6L9.2 7.79999C8.8 7.39999 8.2 7.39999 7.8 7.79999C7.4 8.19999 7.4 8.80001 7.8 9.20001L10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 9 16.4 9.2 16.2L12 13.4L14.8 16.2C15 16.4 15.3 16.5 15.5 16.5C15.7 16.5 16 16.4 16.2 16.2C16.6 15.8 16.6 15.2 16.2 14.8L13.4 12Z" fill="black" />
                                </svg>
                            </span>
                            <div class="d-flex flex-column">
                                <h4 class="mb-1 text-danger">Order Cancelled</h4>
                                <span> Order has been cancelled by you at <span class="text-gray-700"><?php echo $Order->cancelled_on(); ?></span></span>
                                <div class="d-lg-flex my-2 fs-6">
                                    <div class="fw-bolder no-wrap"> Cancelled Reason:- </div>
                                    <span class="pre-wrap overflow-true"> <?php echo $Order->cancelled_reason(); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <?php if ($Order->status_step() == 3) { ?>
                    <div data-track="rejected" class='mt-4'>
                        <div class="alert alert-danger d-flex align-items-center p-5">
                            <span class="svg-icon svg-icon-2hx svg-icon-danger me-4">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M12 10.6L14.8 7.8C15.2 7.4 15.8 7.4 16.2 7.8C16.6 8.2 16.6 8.80002 16.2 9.20002L13.4 12L12 10.6ZM10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 8.99999 16.4 9.19999 16.2L12 13.4L10.6 12Z" fill="black" />
                                    <path d="M22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2C17.5 2 22 6.5 22 12ZM13.4 12L16.2 9.20001C16.6 8.80001 16.6 8.19999 16.2 7.79999C15.8 7.39999 15.2 7.39999 14.8 7.79999L12 10.6L9.2 7.79999C8.8 7.39999 8.2 7.39999 7.8 7.79999C7.4 8.19999 7.4 8.80001 7.8 9.20001L10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 9 16.4 9.2 16.2L12 13.4L14.8 16.2C15 16.4 15.3 16.5 15.5 16.5C15.7 16.5 16 16.4 16.2 16.2C16.6 15.8 16.6 15.2 16.2 14.8L13.4 12Z" fill="black" />
                                </svg>
                            </span>
                            <div class="d-flex flex-column">
                                <h4 class="mb-1 text-danger">Order Rejected</h4>
                                <span> Order has been rejected by seller at <span class="text-gray-700"><?php echo $Order->rejected_on(); ?></span></span>
                                <div class="d-lg-flex my-2 fs-6">
                                    <div class="fw-bolder no-wrap"> Rejected Reason:- </div>
                                    <span class="pre-wrap overflow-true"> <?php echo $Order->rejected_reason(); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <!-- Notice End -->
        </div>
    </div>
</div>
<!-- Order Track End -->


<?php
if ($Order->has_returned_requested()) { ?>
    <div class="card card-flush">
        <div class="card-header">
            <div class="card-title">
                <h2>Return Order</h2>
            </div>
            <div class="card-toolbar">
                <div data-bs-target="#returnGuide" data-bs-toggle="modal" class="btn text-danger p-0 fs-7 fw-bolder"> Return Guideline?</div>
            </div>
        </div>
        <div data-track-init="true" class="card-body pt-0 min-h-100px ">
            <div class="d-flex <?php if ($Return->status_code() == '0' || $Return->status_code() == '2') {
                                    echo "order-cancelled";
                                } ?> flex-md-row flex-column ">
         <div data-track-stop=" return_initiated" class="timeline-step <?php echo $Return->track_class(1); ?>">
                <div class="timeline-stop"></div>
                <div class="timeline-info">
                    <div class="timeline-info-status">Return Initiated</div>
                    <div class="timeline-info-date"><?php echo $Return->requested_date(); ?></div>
                </div>
            </div>
            <!--  -->
            <?php if (!empty($Return->accepted_on()) || empty($Return->rejected_on())) { ?>
                <!--  -->
                <div class="timeline-track done">
                    <div class="timeline-track-path"></div>
                </div>
                <div data-track-stop="return_accepted" class="timeline-step <?php echo $Return->track_class(3); ?> ">
                    <div class="timeline-stop"></div>
                    <div class="timeline-info">
                        <div class="timeline-info-status">Return Accepted</div>
                        <div class="timeline-info-date"><?php echo $Return->accepted_on(); ?></div>
                    </div>
                </div>
                <!--  -->
            <?php }
            if ($Return->status_code() == '0') {
            ?>
                <!--  -->
                <div class="timeline-track done">
                    <div class="timeline-track-path bg-danger"></div>
                </div>
                <div data-track-stop="return_cancelled" class="timeline-step done active ">
                    <div class="timeline-stop bg-danger"></div>
                    <div class="timeline-info">
                        <div class="timeline-info-status">Return Cancelled</div>
                        <div class="timeline-info-date"><?php echo $Return->cancelled_date(); ?></div>
                    </div>
                </div>
                <!--  -->
            <?php
            } else { ?>
                <div class="timeline-track <?php echo $Return->track_class(4); ?>">
                    <div class="timeline-track-path"></div>
                </div>
                <div data-track-stop="picked_up" class="timeline-step <?php echo $Return->track_class(4); ?>">
                    <div class="timeline-stop"></div>
                    <div class="timeline-info">
                        <div class="timeline-info-status">Pickup Scheduled</div>
                        <div class="timeline-info-date"><?php echo $Return->pickup_scheduled_date(); ?></div>
                    </div>
                </div>
                <!--  -->
                <div class="timeline-track <?php echo $Return->track_class(5); ?>">
                    <div class="timeline-track-path"></div>
                </div>
                <div data-track-stop="refunded" class="timeline-step <?php echo $Return->track_class(5); ?> ">
                    <div class="timeline-stop"></div>
                    <div class="timeline-info">
                        <div class="timeline-info-status">Return Completed</div>
                        <div class="timeline-info-date"><?php echo $Return->completed_date(); ?></div>
                    </div>
                </div>
                <!--  -->
            <?php
            }


            if ($Return->status_code() == "2") { ?>
                <div class="timeline-track done">
                    <div class="timeline-track-path bg-danger "></div>
                </div>
                <div data-track-stop="return_rejected" class="timeline-step  <?php echo $Return->track_class(2); ?>">
                    <div class="timeline-stop bg-danger"></div>
                    <div class="timeline-info">
                        <div class="timeline-info-status">Return rejected</div>
                        <div class="timeline-info-date"><?php echo $Return->rejected_on(); ?></div>
                    </div>
                </div>
            <?php
            }

            ?>
        </div>
        <!--  -->
        <div class="mt-14"></div>
        <div data-track="return_initiated" class='mt-4'>
            <div class="alert alert-warning d-flex align-items-center p-5">
                <span class="svg-icon svg-icon-2hx svg-icon-warning me-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black" />
                        <path d="M10.4343 12.4343L8.75 10.75C8.33579 10.3358 7.66421 10.3358 7.25 10.75C6.83579 11.1642 6.83579 11.8358 7.25 12.25L10.2929 15.2929C10.6834 15.6834 11.3166 15.6834 11.7071 15.2929L17.25 9.75C17.6642 9.33579 17.6642 8.66421 17.25 8.25C16.8358 7.83579 16.1642 7.83579 15.75 8.25L11.5657 12.4343C11.2533 12.7467 10.7467 12.7467 10.4343 12.4343Z" fill="black" />
                    </svg>
                </span>
                <div class="d-flex flex-column">
                    <h4 class="mb-1 text-warning">Order Return Requested</h4>
                    <span> You requested return for the order at <span class="text-gray-700"><?php echo $Return->requested_date(); ?></span></span>
                    <div class="d-lg-flex my-2 fs-6">
                        <div class="fw-bolder no-wrap"> Return Reason:- </div>
                        <span class="pre-wrap overflow-true"> <?php echo $Return->return_reason(); ?></span>
                    </div>
                    <div><?php echo $Return->attachments(); ?></div>
                </div>
            </div>
        </div>
        <?php
        if ($Return->status_code() == 0) { ?>
            <div data-track="return_cancelled" class='mt-4'>
                <div class="alert alert-danger d-flex align-items-center p-5">
                    <span class="svg-icon svg-icon-2hx svg-icon-danger me-4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path opacity="0.3" d="M12 10.6L14.8 7.8C15.2 7.4 15.8 7.4 16.2 7.8C16.6 8.2 16.6 8.80002 16.2 9.20002L13.4 12L12 10.6ZM10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 8.99999 16.4 9.19999 16.2L12 13.4L10.6 12Z" fill="black" />
                            <path d="M22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2C17.5 2 22 6.5 22 12ZM13.4 12L16.2 9.20001C16.6 8.80001 16.6 8.19999 16.2 7.79999C15.8 7.39999 15.2 7.39999 14.8 7.79999L12 10.6L9.2 7.79999C8.8 7.39999 8.2 7.39999 7.8 7.79999C7.4 8.19999 7.4 8.80001 7.8 9.20001L10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 9 16.4 9.2 16.2L12 13.4L14.8 16.2C15 16.4 15.3 16.5 15.5 16.5C15.7 16.5 16 16.4 16.2 16.2C16.6 15.8 16.6 15.2 16.2 14.8L13.4 12Z" fill="black" />
                        </svg>
                    </span>
                    <div class="d-flex flex-column">
                        <h4 class="mb-1 text-danger">Return Cancelled</h4>
                        <span> You requested cancellation for your return at <span class="text-gray-700"><?php echo $Return->cancelled_date(); ?></span></span>
                    </div>
                </div>
            </div>
        <?php }
        if ($Return->status_code() == 2) { ?>
            <div data-track="return_rejected" class='mt-4'>
                <div class="alert alert-danger d-flex align-items-center p-5">
                    <span class="svg-icon svg-icon-2hx svg-icon-danger me-4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path opacity="0.3" d="M12 10.6L14.8 7.8C15.2 7.4 15.8 7.4 16.2 7.8C16.6 8.2 16.6 8.80002 16.2 9.20002L13.4 12L12 10.6ZM10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 8.99999 16.4 9.19999 16.2L12 13.4L10.6 12Z" fill="black" />
                            <path d="M22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2C17.5 2 22 6.5 22 12ZM13.4 12L16.2 9.20001C16.6 8.80001 16.6 8.19999 16.2 7.79999C15.8 7.39999 15.2 7.39999 14.8 7.79999L12 10.6L9.2 7.79999C8.8 7.39999 8.2 7.39999 7.8 7.79999C7.4 8.19999 7.4 8.80001 7.8 9.20001L10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 9 16.4 9.2 16.2L12 13.4L14.8 16.2C15 16.4 15.3 16.5 15.5 16.5C15.7 16.5 16 16.4 16.2 16.2C16.6 15.8 16.6 15.2 16.2 14.8L13.4 12Z" fill="black" />
                        </svg>
                    </span>
                    <div class="d-flex flex-column">
                        <h4 class="mb-1 text-danger">Return Rejected</h4>
                        <span> Return request has been rejected by the seller at <span class="text-gray-700"><?php echo $Return->rejected_on(); ?></span></span>
                        <div class="d-flex my-2 fs-6">
                            <div class="fw-bolder no-wrap"> Reject Reason:- </div>
                            <span class="pre-wrap overflow-true"> <?php echo $Return->processed_comment(); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        <?php }
        if ($Return->has_accepted()) { ?>
            <div data-track="return_accepted" class='mt-4'>
                <div class="alert alert-success d-flex align-items-center p-5">
                    <span class="svg-icon svg-icon-2hx svg-icon-success me-4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black" />
                            <path d="M10.4343 12.4343L8.75 10.75C8.33579 10.3358 7.66421 10.3358 7.25 10.75C6.83579 11.1642 6.83579 11.8358 7.25 12.25L10.2929 15.2929C10.6834 15.6834 11.3166 15.6834 11.7071 15.2929L17.25 9.75C17.6642 9.33579 17.6642 8.66421 17.25 8.25C16.8358 7.83579 16.1642 7.83579 15.75 8.25L11.5657 12.4343C11.2533 12.7467 10.7467 12.7467 10.4343 12.4343Z" fill="black" />
                        </svg>
                    </span>
                    <div class="d-flex flex-column">
                        <h4 class="mb-1 text-success">Return Accepted</h4>
                        <span> Return has been accepted by the seller at <span class="text-gray-700"><?php echo $Return->accepted_on(); ?></span></span>
                        <div class="d-flex mt-2 fs-6">
                            <div class="fw-bolder no-wrap"> </div>
                            <span class="pre-wrap overflow-true"><?php echo $Return->processed_comment(); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        <?php }
        if ($Return->status_code() >= 3) {
        ?>
            <div data-track="picked_up" class='mt-4'>
                <div class="alert alert-primary d-flex align-items-center p-5">
                    <span class="svg-icon svg-icon-2hx svg-icon-primary me-4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black" />
                            <path d="M10.4343 12.4343L8.75 10.75C8.33579 10.3358 7.66421 10.3358 7.25 10.75C6.83579 11.1642 6.83579 11.8358 7.25 12.25L10.2929 15.2929C10.6834 15.6834 11.3166 15.6834 11.7071 15.2929L17.25 9.75C17.6642 9.33579 17.6642 8.66421 17.25 8.25C16.8358 7.83579 16.1642 7.83579 15.75 8.25L11.5657 12.4343C11.2533 12.7467 10.7467 12.7467 10.4343 12.4343Z" fill="black" />
                        </svg>
                    </span>
                    <div class="d-flex flex-column">
                        <h4 class="mb-1 text-primary">Pickup Scheduled</h4>
                        <span> Pickup has been scheduled by the seller to return the product at <span class="text-gray-700"><?php echo $Return->pickup_scheduled_date(); ?></span></span>
                        <div class="d-flex mt-2 fs-6">
                            <div class="fw-bolder no-wrap"> </div>
                            <span class="pre-wrap overflow-true"><?php echo $Return->pickup_scheduled_comment(); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        <?php }
        if ($Return->status_code() == 5) {
        ?>
            <div data-track="refunded" class='mt-4'>
                <div class="alert alert-success d-flex align-items-center p-5">
                    <span class="svg-icon svg-icon-2hx svg-icon-success me-4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black" />
                            <path d="M10.4343 12.4343L8.75 10.75C8.33579 10.3358 7.66421 10.3358 7.25 10.75C6.83579 11.1642 6.83579 11.8358 7.25 12.25L10.2929 15.2929C10.6834 15.6834 11.3166 15.6834 11.7071 15.2929L17.25 9.75C17.6642 9.33579 17.6642 8.66421 17.25 8.25C16.8358 7.83579 16.1642 7.83579 15.75 8.25L11.5657 12.4343C11.2533 12.7467 10.7467 12.7467 10.4343 12.4343Z" fill="black" />
                        </svg>
                    </span>
                    <div class="d-flex flex-column">
                        <h4 class="mb-1 text-success">Return Completed</h4>
                        <span> Your return has been completed at <span class="text-gray-700"><?php echo $Return->completed_date(); ?></span></span>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
    </div>
<?php
}
if ($Order->has_replacement_requested()) { ?>
    <div class="card card-flush">
        <div class="card-header">
            <div class="card-title">
                <h2>Replacement Order</h2>
            </div>
            <div class="card-toolbar">
                <div data-bs-target="#returnGuide" data-bs-toggle="modal" class="btn text-danger p-0 fs-7 fw-bolder"> Return Guideline?</div>
            </div>
        </div>
        <div data-track-init="true" class="card-body pt-0 min-h-100px">
            <div class="d-flex <?php if ($Replacement->status_code() == '0' || $Replacement->status_code() == '2') {
                                    echo "order-cancelled";
                                } ?> flex-md-row flex-column ">
                <div data-track-stop="replacement_initiated" class="timeline-step <?php echo $Replacement->track_class(1); ?>">
                    <div class="timeline-stop"></div>
                    <div class="timeline-info">
                        <div class="timeline-info-status">Replacement Initiated</div>
                        <div class="timeline-info-date"><?php echo $Replacement->requested_date(); ?></div>
                    </div>
                </div>
                <!--  -->
                <?php if (!empty($Replacement->accepted_on()) || empty($Replacement->rejected_on())) { ?>
                    <!--  -->
                    <div class="timeline-track done">
                        <div class="timeline-track-path"></div>
                    </div>
                    <div data-track-stop="replacement_accepted" class="timeline-step <?php echo $Replacement->track_class(3); ?> ">
                        <div class="timeline-stop"></div>
                        <div class="timeline-info">
                            <div class="timeline-info-status">Replacement Accepted </div>
                            <div class="timeline-info-date"><?php echo $Replacement->accepted_on(); ?></div>
                        </div>
                    </div>
                    <!--  -->
                <?php }
                if ($Replacement->status_code() == '0') {
                ?>
                    <div class="timeline-track done">
                        <div class="timeline-track-path bg-danger"></div>
                    </div>
                    <div data-track-stop="replacement_cancelled" class="timeline-step done active ">
                        <div class="timeline-stop bg-danger"></div>
                        <div class="timeline-info">
                            <div class="timeline-info-status">Replacement Cancelled</div>
                            <div class="timeline-info-date"><?php echo $Replacement->cancelled_date(); ?></div>
                        </div>
                    </div>
                    <!--  -->
                <?php
                } else { ?>
                    <div class="timeline-track <?php echo $Replacement->track_class(4); ?>">
                        <div class="timeline-track-path"></div>
                    </div>
                    <div data-track-stop="picked_up" class="timeline-step <?php echo $Replacement->track_class(4); ?>">
                        <div class="timeline-stop"></div>
                        <div class="timeline-info">
                            <div class="timeline-info-status">Pickup Scheduled</div>
                            <div class="timeline-info-date"><?php echo $Replacement->pickup_scheduled_date(); ?></div>
                        </div>
                    </div>
                    <!--  -->
                    <div class="timeline-track <?php echo $Replacement->track_class(5); ?>">
                        <div class="timeline-track-path"></div>
                    </div>
                    <div data-track-stop="replacement_completed" class="timeline-step <?php echo $Replacement->track_class(5); ?> ">
                        <div class="timeline-stop"></div>
                        <div class="timeline-info">
                            <div class="timeline-info-status">Replacement Completed</div>
                            <div class="timeline-info-date"><?php echo $Replacement->completed_date(); ?></div>
                        </div>
                    </div>
                    <!--  -->
                <?php
                }


                if ($Replacement->status_code() == "2") { ?>
                    <div class="timeline-track done">
                        <div class="timeline-track-path bg-danger "></div>
                    </div>
                    <div data-track-stop="replacement_rejected" class="timeline-step  <?php echo $Replacement->track_class(2); ?>">
                        <div class="timeline-stop bg-danger"></div>
                        <div class="timeline-info">
                            <div class="timeline-info-status">Replacement rejected</div>
                            <div class="timeline-info-date"><?php echo $Replacement->rejected_on(); ?></div>
                        </div>
                    </div>
                <?php
                }

                ?>
            </div>
            <!--  -->
            <div class="mt-14">
                <div data-track="replacement_initiated" class='mt-4'>
                    <div class="alert alert-warning d-flex align-items-center p-5">
                        <span class="svg-icon svg-icon-2hx svg-icon-warning me-4">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black" />
                                <path d="M10.4343 12.4343L8.75 10.75C8.33579 10.3358 7.66421 10.3358 7.25 10.75C6.83579 11.1642 6.83579 11.8358 7.25 12.25L10.2929 15.2929C10.6834 15.6834 11.3166 15.6834 11.7071 15.2929L17.25 9.75C17.6642 9.33579 17.6642 8.66421 17.25 8.25C16.8358 7.83579 16.1642 7.83579 15.75 8.25L11.5657 12.4343C11.2533 12.7467 10.7467 12.7467 10.4343 12.4343Z" fill="black" />
                            </svg>
                        </span>
                        <div class="d-flex flex-column">
                            <h4 class="mb-1 text-warning">Order Replacement Requested</h4>
                            <span> You requested return for the order at <span class="text-gray-700"><?php echo $Replacement->requested_date(); ?></span></span>
                            <div class="d-lg-flex my-2 fs-6">
                                <div class="fw-bolder no-wrap"> Replacement Reason:- </div>
                                <span class="pre-wrap overflow-true"> <?php echo $Replacement->replacement_reason(); ?></span>
                            </div>
                            <div><?php echo $Replacement->attachments(); ?></div>
                        </div>
                    </div>
                </div>
                <?php
                if ($Replacement->status_code() == 0) { ?>
                    <div data-track="replacement_cancelled" class='mt-4'>
                        <div class="alert alert-danger d-flex align-items-center p-5">
                            <span class="svg-icon svg-icon-2hx svg-icon-danger me-4">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M12 10.6L14.8 7.8C15.2 7.4 15.8 7.4 16.2 7.8C16.6 8.2 16.6 8.80002 16.2 9.20002L13.4 12L12 10.6ZM10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 8.99999 16.4 9.19999 16.2L12 13.4L10.6 12Z" fill="black" />
                                    <path d="M22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2C17.5 2 22 6.5 22 12ZM13.4 12L16.2 9.20001C16.6 8.80001 16.6 8.19999 16.2 7.79999C15.8 7.39999 15.2 7.39999 14.8 7.79999L12 10.6L9.2 7.79999C8.8 7.39999 8.2 7.39999 7.8 7.79999C7.4 8.19999 7.4 8.80001 7.8 9.20001L10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 9 16.4 9.2 16.2L12 13.4L14.8 16.2C15 16.4 15.3 16.5 15.5 16.5C15.7 16.5 16 16.4 16.2 16.2C16.6 15.8 16.6 15.2 16.2 14.8L13.4 12Z" fill="black" />
                                </svg>
                            </span>
                            <div class="d-flex flex-column">
                                <h4 class="mb-1 text-danger">Replacement Cancelled</h4>
                                <span> You requested cancellation for your replacement at <span class="text-gray-700"><?php echo $Replacement->cancelled_date(); ?></span></span>
                            </div>
                        </div>
                    </div>
                <?php }
                if ($Replacement->status_code() == 2) { ?>
                    <div data-track="replacement_rejected" class='mt-4'>
                        <div class="alert alert-danger d-flex align-items-center p-5">
                            <span class="svg-icon svg-icon-2hx svg-icon-danger me-4">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M12 10.6L14.8 7.8C15.2 7.4 15.8 7.4 16.2 7.8C16.6 8.2 16.6 8.80002 16.2 9.20002L13.4 12L12 10.6ZM10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 8.99999 16.4 9.19999 16.2L12 13.4L10.6 12Z" fill="black" />
                                    <path d="M22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2C17.5 2 22 6.5 22 12ZM13.4 12L16.2 9.20001C16.6 8.80001 16.6 8.19999 16.2 7.79999C15.8 7.39999 15.2 7.39999 14.8 7.79999L12 10.6L9.2 7.79999C8.8 7.39999 8.2 7.39999 7.8 7.79999C7.4 8.19999 7.4 8.80001 7.8 9.20001L10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 9 16.4 9.2 16.2L12 13.4L14.8 16.2C15 16.4 15.3 16.5 15.5 16.5C15.7 16.5 16 16.4 16.2 16.2C16.6 15.8 16.6 15.2 16.2 14.8L13.4 12Z" fill="black" />
                                </svg>
                            </span>
                            <div class="d-flex flex-column">
                                <h4 class="mb-1 text-danger">Replacement Rejected</h4>
                                <span> Replacement request has been rejected by the seller at <span class="text-gray-700"><?php echo $Replacement->rejected_on(); ?></span></span>
                                <div class="d-flex my-2 fs-6">
                                    <div class="fw-bolder no-wrap"> Reject Reason:- </div>
                                    <span class="pre-wrap overflow-true"> <?php echo $Replacement->processed_comment(); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }
                if (!empty($Replacement->accepted_on())) { ?>
                    <div data-track="replacement_accepted" class='mt-4'>
                        <div class="alert alert-success d-flex align-items-center p-5">
                            <span class="svg-icon svg-icon-2hx svg-icon-success me-4">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black" />
                                    <path d="M10.4343 12.4343L8.75 10.75C8.33579 10.3358 7.66421 10.3358 7.25 10.75C6.83579 11.1642 6.83579 11.8358 7.25 12.25L10.2929 15.2929C10.6834 15.6834 11.3166 15.6834 11.7071 15.2929L17.25 9.75C17.6642 9.33579 17.6642 8.66421 17.25 8.25C16.8358 7.83579 16.1642 7.83579 15.75 8.25L11.5657 12.4343C11.2533 12.7467 10.7467 12.7467 10.4343 12.4343Z" fill="black" />
                                </svg>
                            </span>
                            <div class="d-flex flex-column">
                                <h4 class="mb-1 text-success">Replacement Accepted</h4>
                                <span> Replacement has been accepted by the seller at <span class="text-gray-700"><?php echo $Replacement->accepted_on(); ?></span></span>
                                <div class="d-flex mt-2 fs-6">
                                    <div class="fw-bolder no-wrap"> </div>
                                    <span class="pre-wrap overflow-true"><?php echo $Replacement->processed_comment(); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }
                if (!empty($Replacement->pickup_scheduled_date())) {
                ?>
                    <div data-track="picked_up" class='mt-4'>
                        <div class="alert alert-primary d-flex align-items-center p-5">
                            <span class="svg-icon svg-icon-2hx svg-icon-primary me-4">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black" />
                                    <path d="M10.4343 12.4343L8.75 10.75C8.33579 10.3358 7.66421 10.3358 7.25 10.75C6.83579 11.1642 6.83579 11.8358 7.25 12.25L10.2929 15.2929C10.6834 15.6834 11.3166 15.6834 11.7071 15.2929L17.25 9.75C17.6642 9.33579 17.6642 8.66421 17.25 8.25C16.8358 7.83579 16.1642 7.83579 15.75 8.25L11.5657 12.4343C11.2533 12.7467 10.7467 12.7467 10.4343 12.4343Z" fill="black" />
                                </svg>
                            </span>
                            <div class="d-flex flex-column">
                                <h4 class="mb-1 text-primary">Pickup Scheduled</h4>
                                <span> Pickup has been scheduled by the seller to return the product at <span class="text-gray-700"><?php echo $Replacement->pickup_scheduled_date(); ?></span></span>
                                <div class="d-flex mt-2 fs-6">
                                    <div class="fw-bolder no-wrap"> </div>
                                    <span class="pre-wrap overflow-true"><?php echo $Replacement->pickup_scheduled_comment(); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }
                if ($Replacement->status_code() == 5) {
                ?>
                    <div data-track="replacement_completed" class='mt-4'>
                        <div class="alert alert-success d-flex align-items-center p-5">
                            <span class="svg-icon svg-icon-2hx svg-icon-success me-4">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black" />
                                    <path d="M10.4343 12.4343L8.75 10.75C8.33579 10.3358 7.66421 10.3358 7.25 10.75C6.83579 11.1642 6.83579 11.8358 7.25 12.25L10.2929 15.2929C10.6834 15.6834 11.3166 15.6834 11.7071 15.2929L17.25 9.75C17.6642 9.33579 17.6642 8.66421 17.25 8.25C16.8358 7.83579 16.1642 7.83579 15.75 8.25L11.5657 12.4343C11.2533 12.7467 10.7467 12.7467 10.4343 12.4343Z" fill="black" />
                                </svg>
                            </span>
                            <div class="d-flex flex-column">
                                <h4 class="mb-1 text-success">Replacement Completed</h4>
                                <span> Your replacement has been completed at <span class="text-gray-700"><?php echo $Replacement->completed_date(); ?></span></span>
                                <?php if (!empty($Replacement->refund_reason())) {
                                ?> <span class="text-danger">We are sorry we can't provide you a replacement due to unavailability so we are providing a refund.</span>
                                <?php
                                } else {
                                ?> <span> Replacement Order Id is <a href="<?php echo $Replacement->newUserOrder()->url(); ?>">#<?php echo $Replacement->newOrder()->order_id; ?></a></span>
                                <?php
                                } ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
<?php
}
?>