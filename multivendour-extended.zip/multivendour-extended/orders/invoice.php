<?php
include "../db.php";
$Login->check_user_login();

use Ecommerce\Order;
use Ecommerce\Product;
use Mpdf\Mpdf;
require_once  $Web->include('pdf/vendor/autoload.php');


if(!isset($_GET["id"])) Errors::response_404();
$order_id = $_GET["id"];
if (!Order::is_order_id($order_id))  Errors::response_404();
$Order = new Order($order_id);
if ($Order->buyer()->user_id !== $LogUser->user_id) Errors::response_404();
if(!$Order->can_review())  Errors::response_404();


$mpdf = new Mpdf([
    'tempDir' => $Web->include('/pdf/vendor/mpdf/mpdf/tmp/'),
    'default_font' => 'frutiger'
]);



// Product Details
$Product = new Product($Order->product_id());

$product_name = $Product->product_name($Order->variation_id(),$Order->svariation_id());
$quantity = $Order->quantity();
$product_price = $Order->total_price();
$total_price = $Order->total_price();
$product_seller = $Product->seller()->store_name();
$address = $Order->address_card();
$shipped_from_address = $Order->seller_address_card();
//
$html =  '<html>
<title>Order Invoice </title>
<body>
    <div style="width: 100%">
        <h2 style="text-align:center;" >Tax Invoice</h2>
        <div style="text-align:left;">
            <b>Sold By:</b> ' . $product_seller . '<br>
            <b>Shipped from:</b> ' . $shipped_from_address . '
        </div>
    </div>
    <hr style="color:#000;">
    <div style="width: 100%">
        <div style="float: left; width: 50%">
            <b>Order Id:</b> #' . $order_id . '<br />
            <b>Date:</b> ' . $Order->order_date() . '
        </div>
        <div style="text-align:right;">
            <b>Ship To:</b> ' . $address . '
        </div>
    </div>
    <hr style="color:#000;">
    <div >
        <table style="width:100%;">
            <tr style="font-weight: bold;">
                <td style="width:40%" >Item Description</td>
                <td style="text-align:right;width:20%">Quantity</td>
                <td style="text-align:right;width:20%">Price</td>
                <td style="text-align:right;width:20%">Total</td>
            </tr>
            
            <tr>
            <td><hr style="width:100%;color:#000;"></td>
            <td><hr style="width:100%;color:#000;"></td>
            <td><hr style="width:100%;color:#000;"></td>
            <td><hr style="width:100%;color:#000;"></td>
            </tr>
            <tr>
                <td style=""><span>' . $product_name . '</span></td>
                <td style="text-align:right; ">' . $quantity . '</td>
                <td style="text-align:right; ">' . $product_price . '</td>
                <td style="text-align:right; ">' . $total_price . '</td>
            </tr>
        </table>
    </div>
      <hr style="color:#000;">
      <div style="text-align:right;">
        <p>' . $product_seller . '</p>
        <img style="width:100px;" src="' . $Web->base_url() . '/assets/images/web/logo.png" >
      <p>Authorized Signatory</p>

      </div>
</body>
</html>';

$mpdf->AddPage();
$mpdf->WriteHTML($html);


$date = $Web->current_time();
$date = str_replace(" ", "-", $date);
$date = str_replace(":", "-", $date);
$uniq_id = $Web->unique_id();
$filename = $uniq_id . $date . ".pdf";
$mpdf->Output($filename, 'D');
