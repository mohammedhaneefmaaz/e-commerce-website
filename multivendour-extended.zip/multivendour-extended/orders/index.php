<?php
require_once "../db.php";
$Login->check_user_login();

use Ecommerce\Order;

$page = $_GET['page'] ?? 1;
$page = preg_replace('/[^0-9]/', '', $page);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Orders - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body class="header-fixed header-tablet-and-mobile-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <div class="wrapper d-flex flex-column flex-row-fluid">
                <?php include $Web->include("partials/visitor/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid">
                    <div id="lx_content_container" class="container-xxl">

                        <div class="card mw-1000px m-auto">
                            <div class="card-header">
                                <div class="card-title">
                                    <h2>Orders</h2>
                                </div>
                            </div>
                            <div>
                                <div class="<?php if (Order::user_orders_count($LogUser->user_id) != 0) {
                                                echo "d-none";
                                            } ?> align-center p-4 flex-column">
                                    <img class="mh-200px img-fluid" src="<?php echo $Web->get_assets("images/web/empty-orders.svg"); ?>" alt="">
                                    <h2>No Items Purchased</h2>
                                    <a href="<?php echo $Web->base_url(); ?>" class="mt-8 min-w-200px w-100 w-md-auto btn btn-primary">Shop Now</a>
                                </div>

                                <?php echo Order::user_orders($LogUser->user_id, $page)->content; ?>
                                <?php echo Order::user_orders($LogUser->user_id, $page)->pagination; ?>

                            </div>
                        </div>

                    </div>
                </div>
                <?php include $Web->include("partials/visitor/footer.php"); ?>
            </div>
        </div>
    </div>


    <?php include $Web->include("partials/scripts.php"); ?>
    <script>

    </script>
</body>


</html>