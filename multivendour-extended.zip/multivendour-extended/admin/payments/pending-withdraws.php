<?php
require_once "../../db.php";
$Login->check_admin_login();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pending Withdraws - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/admin/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">


                        <div class="card card-flush">
                            <div class="card-header">
                                <div class="card-title">
                                    <h2>Pending Withdraws</h2>
                                </div>
                            </div>
                            <div class="card-body pt-0">
                                <table class="table align-middle table-row-dashed fs-6 gy-5" id="data_table">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                            <th class="min-w-50px">#</th>
                                            <th class="min-w-100px">Transaction Id</th>
                                            <th class="min-w-100px">Seller</th>
                                            <th class="min-w-100px">Gateway</th>
                                            <th class="min-w-100px">Amount</th>
                                            <th class="min-w-50px">Charges</th>
                                            <th class="min-w-150px">Net Amount</th>
                                            <th class="min-w-150px">Requested Date</th>
                                            <th class="min-w-50px">Status</th>
                                            <th class="min-w-50px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-bold text-gray-600"></tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/datatables.bundle.js"); ?>"></script>
    <script>
        setActiveNavItem(location.pathname)
        Admin.Withdraw.dataTbl("asc", "pending");
    </script>

</body>


</html>