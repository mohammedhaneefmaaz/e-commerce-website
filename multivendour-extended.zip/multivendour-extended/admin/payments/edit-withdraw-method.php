<?php


require_once "../../db.php";
$Login->check_admin_login();

use Ecommerce\WithdrawGateway;

if (!isset($_GET["id"])) Errors::response_404();
$gateway_id = $_GET["id"];
if (!WithdrawGateway::is_gateway_id($gateway_id)) Errors::response_404();

$WithdrawGateway = new WithdrawGateway($gateway_id);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Edit Withdraw Method - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/admin/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <form id="createWithdrawMethod" default-validation="" class="needs-validation" novalidate>
                            <input type="hidden" value="<?php echo $gateway_id; ?>" name="gateway_id">
                            <input type="hidden" value="update" name="event">

                            <div class="d-flex flex-column flex-xl-row">
                                <div class="flex-column flex-lg-row-auto w-100 w-xl-350px">
                                    <div class="card mb-5">
                                        <div class="card-body">

                                            <div class="fw-bolder mt-5"> Payment Gateway Image </div>
                                            <div class="justify-align-center flex-column">
                                                <div id="profileContainer" class="image-input <?php if ($WithdrawGateway->logo_id() == '0') {
                                                                                                    echo "image-input-empty";
                                                                                                } ?> image-input-circle">
                                                    <div class="profile-progress"></div>
                                                    <img class="image-input-wrapper w-125px h-125px" src="<?php echo $WithdrawGateway->logo(); ?>">
                                                    <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-lx-image-input-action="change" data-bs-toggle="tooltip" title="" data-bs-original-title="Change store logo">
                                                        <i class="bi bi-pencil-fill fs-7"></i>
                                                        <input type="file" name="logo" accept=".png, .jpg, .jpeg">
                                                        <input type="hidden" value="<?php echo $WithdrawGateway->logo_id(); ?>" name="logo_image_id">
                                                    </label>
                                                    <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-lx-image-input-action="remove" data-bs-toggle="tooltip" title="" data-bs-original-title="Remove logo">
                                                        <i class="bi bi-x fs-2"></i>
                                                    </span>
                                                </div>
                                                <div class="form-text">Allowed file types: png, jpg, jpeg.</div>
                                            </div>

                                            <div class="separator separator-dashed my-3"></div>
                                            <div class="fv-row col-lg-12 mb-7">
                                                <label class="fs-6 fw-bold mb-2 required"> Payment Gateway Name </label>
                                                <input required type="text" class="form-control form-control-solid" placeholder="" name="gateway_name" value="<?php echo $WithdrawGateway->name(); ?>">
                                                <div class="invalid-feedback">Payment Gateway Name</div>
                                            </div>
                                            <div class="fv-row col-lg-12 mb-7">
                                                <label class="fs-6 fw-bold mb-2 required"> Processing Time </label>
                                                <input required type="text" class="form-control form-control-solid" placeholder="" name="processing_time" value="<?php echo $WithdrawGateway->processing_time(); ?>">
                                                <div class="invalid-feedback">Processing Time is required</div>
                                            </div>
                                            <div class="fv-row col-lg-12 mb-7">
                                                <label class="fs-6 fw-bold mb-2 required"> Charge </label>
                                                <input required type="text" class="form-control form-control-solid" placeholder="" name="charge" value="<?php echo $WithdrawGateway->charge(); ?>">
                                                <div class="invalid-feedback">Charge is required</div>
                                            </div>
                                            <div class="fv-row col-lg-12 mb-7">
                                                <label class="fs-6 fw-bold mb-2 required"> Charge Type </label>
                                                <select value="<?php echo $WithdrawGateway->charge_type(); ?>" required class=" form-select form-select-solid" name="charge_type" data-control="select2" data-placeholder="Select an option" data-hide-search="true" tabindex="-1" aria-hidden="true">
                                                    <option></option>
                                                    <option value="fixed">Fixed</option>
                                                    <option value="percentage">Percentage</option>
                                                </select>
                                                <div class="invalid-feedback">Charge Type is required</div>
                                            </div>
                                            <div class="fv-row col-lg-12 mb-7">
                                                <label class="fs-6 fw-bold mb-2 required"> Status </label>
                                                <select value="<?php echo $WithdrawGateway->status(); ?>" required class="form-select form-select-solid" name="status" data-control="select2" data-placeholder="Select an option" data-hide-search="true" tabindex="-1" aria-hidden="true">
                                                    <option></option>
                                                    <option value="active">Active</option>
                                                    <option value="inactive">Inactive</option>
                                                </select>
                                                <div class="invalid-feedback">Status is required</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="flex-xl-row-fluid ms-xl-6">
                                    <div class="card card-flush mb-xl-6 mb-4">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>Payment requirements</h2>
                                            </div>
                                        </div>
                                        <div class="card-body pt-0">

                                            <div class="fv-row col-lg-12 mb-5">
                                                <label class="fs-6 fw-bold mb-2 required"> Card Heading </label>
                                                <input required type="text" class="form-control form-control-solid" placeholder="Card Heading" name="card_heading" value="<?php echo $WithdrawGateway->card_heading(); ?>">
                                                <div class="invalid-feedback">Card Heading is required</div>
                                            </div>

                                            <div id="repeater">

                                                <div class="form-group">
                                                    <div data-repeater-list="repeater" class="d-flex flex-column gap-3">
                                                        <div data-repeater-item="" class="form-group d-flex align-items-end mb-5">
                                                            <div class="flex-grow-1 fv-row">
                                                                <label class="fs-6 fw-bold mb-2 required"> Add Label </label>
                                                                <input type="text" class="form-control form-control-solid flex-grow-1 " placeholder="Add Label" name="labels" value="">
                                                            </div>
                                                            <button type="button" data-repeater-delete="" class="ms-4 btn btn-sm btn-icon btn-light-danger">
                                                                <i class="fas fa-times"></i>
                                                            </button>
                                                        </div>
                                                        <?php echo $WithdrawGateway->labels_preview(); ?>
                                                    </div>
                                                </div>
                                                <div class="form-group mt-5">
                                                    <button type="button" data-repeater-create-image="" class="btn btn-sm btn-light-primary">
                                                        <span class="svg-icon svg-icon-primary svg-icon-1">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black" />
                                                                <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black" />
                                                            </svg>
                                                        </span>
                                                    </button>
                                                    <button type="button" data-repeater-create="" class="btn btn-sm btn-light-primary">
                                                        <i class="fas fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="justify-between">
                                <button type="button" id="delete_gateway" class="btn btn-danger">Delete</button>
                                <div class="d-flex">
                                    <a class="btn go-back btn-secondary me-4">Cancel</a>
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </div>

                        </form>

                    </div>
                </div>
                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/formrepeater.js"); ?>"></script>
    <script>
        setActiveNavItem(getCurrentDirPath() + "withdraw-methods")
        Admin.Withdraw.addNewMethod(<?php echo $WithdrawGateway->labels_count(); ?>);
    </script>

</body>


</html>