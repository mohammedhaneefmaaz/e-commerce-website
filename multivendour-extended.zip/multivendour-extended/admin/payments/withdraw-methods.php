<?php
require_once "../../db.php";
$Login->check_admin_login();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Withdraw Methods - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/admin/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">


                        <div class="card card-flush">
                            <div class="card-header">
                                <div class="card-title">
                                    <h2>Seller Withdrawl Methods</h2>
                                </div>
                                <div class="card-toolbar">
                                    <a href="<?php echo $Web->admin_url(); ?>/payments/create-withdraw-method" type="button" class="btn btn-sm btn-flex btn-light-primary">
                                        <span class="svg-icon svg-icon-3">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5" fill="black"></rect>
                                                <rect x="10.8891" y="17.8033" width="12" height="2" rx="1" transform="rotate(-90 10.8891 17.8033)" fill="black"></rect>
                                                <rect x="6.01041" y="10.9247" width="12" height="2" rx="1" fill="black"></rect>
                                            </svg>
                                        </span>
                                        Add a new
                                    </a>
                                </div>
                            </div>
                            <div class="card-body pt-0">
                                <table class="table align-middle table-row-dashed fs-6 gy-5" id="data_table">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                            <th class="min-w-50px">#</th>
                                            <th class="min-w-200px mw-300px">Gateway</th>
                                            <th class="min-w-100px">Processing Time</th>
                                            <th class="min-w-100px">Date Created</th>
                                            <th class="min-w-50px">Status</th>
                                            <th class="min-w-50px">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-bold text-gray-600"></tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/datatables.bundle.js"); ?>"></script>
    <script>
        setActiveNavItem(location.pathname)
        Admin.Withdraw.withdrawMethods();
    </script>

</body>


</html>