<?php

require_once "../../db.php";
$Login->check_admin_login();

use Ecommerce\SellerVerification;

if (!isset($_GET["verification_id"])) Errors::response_404();
$verification_id = $_GET["verification_id"];
if (!SellerVerification::is_verification_id($verification_id)) Errors::response_404();

$Verification = new SellerVerification($verification_id);
$Seller = $Verification->seller();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>View Seller - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/admin/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <?php
                        if ($Verification->status() == "rejected") {
                        ?>
                            <div class="alert bg-danger d-flex flex-column flex-sm-row w-100 p-5 mb-4">
                                <span class="svg-icon me-4 svg-icon-white svg-icon-2hx">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M12 10.6L14.8 7.8C15.2 7.4 15.8 7.4 16.2 7.8C16.6 8.2 16.6 8.80002 16.2 9.20002L13.4 12L12 10.6ZM10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 8.99999 16.4 9.19999 16.2L12 13.4L10.6 12Z" fill="black" />
                                        <path d="M22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2C17.5 2 22 6.5 22 12ZM13.4 12L16.2 9.20001C16.6 8.80001 16.6 8.19999 16.2 7.79999C15.8 7.39999 15.2 7.39999 14.8 7.79999L12 10.6L9.2 7.79999C8.8 7.39999 8.2 7.39999 7.8 7.79999C7.4 8.19999 7.4 8.80001 7.8 9.20001L10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 9 16.4 9.2 16.2L12 13.4L14.8 16.2C15 16.4 15.3 16.5 15.5 16.5C15.7 16.5 16 16.4 16.2 16.2C16.6 15.8 16.6 15.2 16.2 14.8L13.4 12Z" fill="black" />
                                    </svg>
                                </span>
                                <div class="d-flex text-white flex-column pe-0 pe-sm-10">
                                    <h4 class="text-white fw-bold">Rejected Reason</h4>
                                    <div class="pre-wrap"><?php echo $Verification->rejected_reason() ?></div>
                                </div>
                            </div>
                        <?php
                        }
                        ?>


                        <div class="d-flex flex-column flex-lg-row">
                            <div class="flex-column flex-lg-row-auto w-100 w-lg-350px">
                                <div class="card mb-5">
                                    <div class="card-body pt-15">
                                        <div class="d-flex flex-center flex-column mb-5">
                                            <div class="symbol symbol-150px symbol-circle mb-7">
                                                <img id="store_logo" data-user-avatar="" src="<?php echo $Seller->store_logo(); ?>" alt="image" />
                                            </div>
                                            <div id="store_name" class="fs-3 text-gray-800 fw-bolder mb-1"><?php echo $Web->is_empty($Seller->store_name()) ? "Shop Name" : $Seller->store_name(); ?></div>
                                            <div id="store_description" class="fs-5 pre-wrap  fw-bold text-muted mb-6"><?php echo $Web->is_empty($Seller->store_description()) ? "Shop Description" : $Seller->store_description(); ?></div>
                                        </div>
                                        <div class="separator separator-dashed my-3"></div>
                                        <div class="pb-5 fs-6">
                                            <div class="fw-bolder mt-5">User ID</div>
                                            <div class="text-gray-600">ID- <?php echo $Seller->user_id; ?></div>

                                            <div class="fw-bolder mt-5">Email</div>
                                            <div class="text-gray-600">
                                                <a class="text-gray-600 text-hover-primary"><?php echo $Seller->email(); ?></a>
                                            </div>

                                            <div class="fw-bolder mt-5">Member Since</div>
                                            <div class="text-gray-600"><?php echo $Seller->registration_date(); ?></div>

                                            <div class="fw-bolder mt-5">Seller Since</div>
                                            <div class="text-gray-600"><?php echo $Seller->seller_since(); ?></div>

                                            <div class="fw-bolder mt-5">Account verification:</div>
                                            <div class="fw-bolder status-label text-success"><?php echo $Seller->status_label(); ?></div>

                                            <?php if ($Seller->status() === "rejected") { ?>
                                                <div class="fw-bolder mt-5">Rejected reason:</div>
                                                <div class="fw-bold fs-7 pre-wrap text-danger"><?php echo $Seller->rejected_reason(); ?></div>
                                            <?php } ?>



                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="flex-lg-row-fluid ms-lg-6">

                                <div class="card mb-lg-6 mb-4">
                                    <div class="card-header border-0">
                                        <div class="card-title">
                                            <h2> Contact Details </h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0 pb-5">
                                        <form class="form form-disabled" id="contact_details_form">
                                            <div class="row">
                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> Name </label>
                                                    <input type="text" class="form-control form-control-solid" placeholder="" name="contact_name" value="<?php echo $Seller->contact_details()->contact_name ?? ""; ?>" />
                                                </div>

                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> Mobile Number </label>
                                                    <input type="text" class="form-control form-control-solid" placeholder="" name="mobile_number" value="<?php echo $Seller->contact_details()->mobile_number ?? ""; ?>" />
                                                </div>

                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> Contact Email</label>
                                                    <input type="text" class="form-control form-control-solid" placeholder="" name="contact_email" value="<?php echo $Seller->contact_details()->contact_email ?? ""; ?>" />
                                                </div>

                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> Preferred Language </label>
                                                    <input type="text" class="form-control form-control-solid" placeholder="" name="preferred_language" value="<?php echo $Seller->contact_details()->preferred_language ?? ""; ?>" />
                                                </div>

                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <!--  -->
                                <div class="card mb-lg-6 mb-4">
                                    <div class="card-header border-0">
                                        <div class="card-title">
                                            <h2> Pickup Address </h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0 pb-5">
                                        <form class="form form-disabled" id="pickup_address_form">
                                            <div class="row">
                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> Country </label>
                                                    <input type="text" class="form-control form-control-solid" placeholder="" name="pickup_country" value="<?php echo $Seller->pickup_address()->pickup_country ?? ""; ?>" />
                                                </div>

                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> State </label>
                                                    <input type="text" class="form-control form-control-solid" placeholder="" name="pickup_state" value="<?php echo $Seller->pickup_address()->pickup_state ?? ""; ?>" />
                                                </div>

                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> City </label>
                                                    <input type="text" class="form-control form-control-solid" placeholder="" name="pickup_city" value="<?php echo $Seller->pickup_address()->pickup_city ?? ""; ?>" />
                                                </div>

                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> Address</label>
                                                    <input type="text" class="form-control form-control-solid" placeholder="" name="pickup_address" value="<?php echo $Seller->pickup_address()->pickup_address ?? ""; ?>" />
                                                </div>

                                                <div class="fv-row col-lg-6 mb-7">
                                                    <label class="fs-6 fw-bold mb-2 required"> PIN code</label>
                                                    <input type="text" class="form-control form-control-solid" placeholder="" name="pin_code" value="<?php echo $Seller->pickup_address()->pin_code ?? ""; ?>" />
                                                </div>

                                            </div>
                                        </form>
                                    </div>
                                </div>


                            </div>
                        </div>

                        <?php if ($Verification->status() == "pending") {
                        ?> <div class="mb-6 justify-right">
                                <button data-bs-toggle="modal" data-bs-target="#rejectVerificationModal" id="rejectVerification" class="btn btn-danger">Reject</button>
                                <button id="approveVerification" class="btn ms-4 btn-success">Approve</button>
                            </div>
                        <?php
                        } ?>


                    </div>
                </div>
                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>
    </div>

    <div class="modal fade" id="rejectVerificationModal" tabindex="-1" style="display: none;" aria-hidden="true">
        <div class="modal-dialog mw-650px">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="fw-bolder">Reject Verification</h2>
                    <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                        <span class="svg-icon svg-icon-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                            </svg>
                        </span>
                    </div>
                </div>
                <div class="modal-body scroll-y">
                    <form default-validation novalidate class="no-validate">
                        <div class="fv-row mb-7">
                            <label class="required fs-6 fw-bold form-label mb-2">Reject Reason</label>
                            <textarea required rows="5" type="text" class="form-control" name="reject_reason"></textarea>
                            <div class="invalid-feedback">Reject Reason is required</div>
                        </div>

                        <div class="justify-right">
                            <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                            <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--  -->

    <?php include $Web->include("partials/scripts.php"); ?>

    <script>
        setActiveNavItem(getCurrentDirPath() + "view-verification");
        Admin.viewSellerVerification("<?php echo $verification_id; ?>");
    </script>


</body>


</html>