<?php

require_once "../db.php";

$Login->uncheck_admin_login();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body">

    <div class="d-flex flex-column flex-root">
        <div class="d-flex flex-column flex-column-fluid bgi-position-y-bottom position-x-center bgi-no-repeat bgi-size-contain bgi-attachment-fixed" style="background-image: url(<?php echo $Web->get_assets('images/web/background.png'); ?>)">
            <div class="d-flex flex-center flex-column flex-column-fluid p-10 pb-lg-20">

                <div class="w-lg-500px bg-body rounded shadow-sm  mx-auto login-card ">

                    <div class="border-bottom py-4 text-center">
                        <a href="<?php echo $Web->admin_url(); ?>" class="mb-12">
                            <img alt="Logo" src="<?php echo $Web->admin_logo(); ?>" class="h-40px" />
                        </a>
                    </div>

                    <div class="p-10 p-lg-15">
                        <form class="form w-100" novalidate="novalidate" id="loginForm" action="#">
                            <div class="text-center mb-10">
                                <h1 class="text-dark mb-3">Login to <?php echo $Web->web_name(); ?></h1>
                            </div>
                            <div class="fv-row mb-10">
                                <label class="form-label fs-6 fw-bolder text-dark">Email</label>
                                <input value="<?php echo $Web->testingEmail; ?>" class="form-control form-control-lg" type="email" name="email" />
                            </div>
                            <div class="fv-row mb-10">
                                <label class="form-label fw-bolder text-dark fs-6">Password</label>
                                <div class="position-relative">
                                    <input required class="form-control no-bg form-control-lg password-input" value="<?php echo $Web->testingEmailPassword; ?>" type="password" name="password" autocomplete="off" />
                                    <div class="show password-toggle">
                                        <svg class="show" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="-10 -10 47 38" style="stroke:#0c0c0d">
                                            <g style="stroke-width:2;fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round" transform="translate(1 1)">
                                                <path d="m0 8c0-2 5.5-8 11-8s11 6 11 8-5.5 8-11 8-11-6-11-8z" />
                                                <path d="m11 12c2.2091 0 4-1.7909 4-4 0-2.20914-1.7909-4-4-4-2.20914 0-4 1.79086-4 4 0 2.2091 1.79086 4 4 4z" />
                                                <path d="m13 7c.5523 0 1-.44772 1-1s-.4477-1-1-1-1 .44772-1 1 .4477 1 1 1z" fill="#000" fill-rule="nonzero" />
                                            </g>
                                        </svg>
                                        <svg class="hide" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="-10 -7 47 38" style="stroke:#0c0c0d">
                                            <g style="stroke-width:2;fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round" transform="translate(1 1)">
                                                <path d="m4.14 15.76c-2.44-1.76-4.14-4.13-4.14-5.22 0-1.91 5.27-7.66 10.54-7.66 1.8042928.06356301 3.559947.60164173 5.09 1.56m3.53 2.85c.954643.86366544 1.6242352 1.9970896 1.92 3.25 0 1.92-5.27 7.67-10.54 7.67-.82748303-.0073597-1.64946832-.1353738-2.44-.38" />
                                                <path d="m11.35 14.29c1.3567546-.2923172 2.4501897-1.2939955 2.86-2.62m-1.56-4.33c-1.5090443-.9785585-3.49511641-.77861361-4.77882585.48110127-1.28370945 1.25971488-1.52108848 3.24166123-.57117415 4.76889873" />
                                                <path d="m13.08 7.9c-.1699924-.15256531-.3916348-.2347875-.62-.23-.5522847 0-1 .44771525-1 1 .0046671.23144917.0894903.45410992.24.63" />
                                                <path d="m21.08 0-21.08 21.08" />
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                            <div class="fv-row mb-10">
                                <label class="form-check form-check-custom form-check-solid form-check-inline">
                                    <input checked class="form-check-input" type="checkbox" id="keeplogged" />
                                    <span class="form-check-label fw-bold text-gray-700 fs-6">
                                        <a class="ms-1 link-primary">Remember Me</a></span>
                                </label>
                            </div>
                            <div class="text-center">
                                <button type="submit" id="submit" class="btn btn-lg btn-primary w-100 mb-5">
                                    <span class="indicator-label">Continue</span>
                                    <span class="indicator-progress">Please wait...
                                        <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                </button>

                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <?php include $Web->include("partials/scripts.php"); ?>

    <script>
        LXUtil.onDOMContentLoaded((function() {
            Login.adminLogin();
        }));
    </script>

</body>

</html>