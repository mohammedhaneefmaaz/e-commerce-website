<?php

require_once "../../db.php";
$Login->check_admin_login();

use Ecommerce\QC;
use Ecommerce\Category;

if (!isset($_GET["qid"], $_GET["id"])) Errors::response_404();
$qc_id = $_GET["id"];
$qvariation_id = $_GET["qid"];

if (!QC::is_qc_id($qc_id)) Errors::response_404();
$QC = new QC($qc_id);
$Listing = $QC->listing();
$variation_id = $QC->variation_id();
$svariation_id = $QC->svariation_id();
$Category = new Category($Listing->category_id());

if (!$QC->is_qc_qvariation_id($qvariation_id)) Errors::response_404();

if (!$Listing->is_svariation_id($variation_id, $svariation_id)) Errors::response_404();
$data = $Listing->images($variation_id, $svariation_id);
$data = json_encode($data);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>View QC - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/admin/header.php"); ?>

                <div class="content form-disabled d-flex flex-column flex-column-fluid" id="lx_content">
                    <div class="post d-flex flex-column-fluid" id="lx_post">
                        <div id="lx_content_container" class="container-xxl">

                            <?php echo $Category->breadcrumb($Listing->product_name($variation_id, $svariation_id)); ?>

                            <div class="justify-right mb-2 mb-lg-4 ">
                                <?php
                                if ($QC->status() == "pending") {
                                ?>
                                    <button data-bs-toggle="modal" data-bs-target="#rejectQcModal" class="btn btn-danger btn-hover-scale">Reject Qc</button>
                                    <button id="approveQC" class="ms-4 btn btn-light-primary btn-hover-scale btn-success">Approve QC</button>
                                <?php } ?>
                            </div>

                            <?php
                            if ($Listing->category()->has_variation()) {
                            ?>
                                <div class=" mb-2 mb-lg-4 card card-flush">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2><?php echo $Listing->variation_header_text(); ?></h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div class="d-flex">
                                            <?php echo $QC->variations_card($qvariation_id, $variation_id); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php
                            } ?>

                            <?php
                            if ($Listing->category()->has_svariation()) {
                            ?>
                                <div class=" mb-2 mb-lg-4 card card-flush">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2><?php echo $Listing->svariation_header_text(); ?></h2>
                                            <div class="ms-4"><?php echo $QC->status_label(); ?></div>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div class="d-flex">
                                            <?php echo $QC->svariations_card($qvariation_id, $qc_id); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php
                            } ?>

                            <?php
                            if ($QC->status() == "rejected") {
                            ?>
                                <div class="alert alert-danger d-flex align-items-center p-5 mb-2 mb-lg-4">
                                    <span class="svg-icon me-4 svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path opacity="0.3" d="M12 10.6L14.8 7.8C15.2 7.4 15.8 7.4 16.2 7.8C16.6 8.2 16.6 8.80002 16.2 9.20002L13.4 12L12 10.6ZM10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 8.99999 16.4 9.19999 16.2L12 13.4L10.6 12Z" fill="black" />
                                            <path d="M22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2C17.5 2 22 6.5 22 12ZM13.4 12L16.2 9.20001C16.6 8.80001 16.6 8.19999 16.2 7.79999C15.8 7.39999 15.2 7.39999 14.8 7.79999L12 10.6L9.2 7.79999C8.8 7.39999 8.2 7.39999 7.8 7.79999C7.4 8.19999 7.4 8.80001 7.8 9.20001L10.6 12L7.8 14.8C7.4 15.2 7.4 15.8 7.8 16.2C8 16.4 8.3 16.5 8.5 16.5C8.7 16.5 9 16.4 9.2 16.2L12 13.4L14.8 16.2C15 16.4 15.3 16.5 15.5 16.5C15.7 16.5 16 16.4 16.2 16.2C16.6 15.8 16.6 15.2 16.2 14.8L13.4 12Z" fill="black" />
                                        </svg></span>
                                    <div class="d-flex flex-column">
                                        <h4 class="mb-1 text-danger">Rejected Reason</h4>
                                        <div class="pre-wrap"><?php echo $QC->reject_reason(); ?></div>
                                    </div>
                                </div>

                            <?php
                            }
                            ?>


                            <div class="row">
                                <div class="col-lg-5">

                                    <div class="card mb-2 mb-lg-4 ">
                                        <div class="card-body">
                                            <div class="d-flex">

                                                <div id="miniImgUpload" style="scrollbar-width: none;" class="h-450px scroll-y min-w-80px w-80px mx-2">

                                                    <!-- 1 -->
                                                    <div data-index="1" class="active required required-absolute position-relative cursor-pointer border-bottom border-warning border-2 w-80px justify-align-center mb-2 bg-light hover h-100px">

                                                        <div class="bottom-inherit image-upload-progress top-0">
                                                            <div class="progress-bar h-3px"></div>
                                                        </div>
                                                        <span class="svg-icon svg-icon-muted svg-icon-2x">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black"></path>
                                                                <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black"></path>
                                                            </svg>
                                                        </span>
                                                    </div>
                                                    <!-- 2 -->
                                                    <div data-index="2" class="position-relative required required-absolute  cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">

                                                        <div class="bottom-inherit image-upload-progress top-0">
                                                            <div class="progress-bar h-3px"></div>
                                                        </div>
                                                        <span class="svg-icon svg-icon-muted svg-icon-2x">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black"></path>
                                                                <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black"></path>
                                                            </svg>
                                                        </span>
                                                    </div>
                                                    <!-- 3 -->
                                                    <div data-index="3" class="position-relative required required-absolute cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">

                                                        <div class="bottom-inherit image-upload-progress top-0">
                                                            <div class="progress-bar h-3px"></div>
                                                        </div>
                                                        <span class="svg-icon svg-icon-muted svg-icon-2x">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black"></path>
                                                                <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black"></path>
                                                            </svg>
                                                        </span>
                                                    </div>
                                                    <!-- 4 -->
                                                    <div data-index="4" class="position-relative cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">

                                                        <div class="bottom-inherit image-upload-progress top-0">
                                                            <div class="progress-bar h-3px"></div>
                                                        </div>
                                                        <span class="svg-icon svg-icon-muted svg-icon-2x">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black"></path>
                                                                <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black"></path>
                                                            </svg>
                                                        </span>
                                                    </div>
                                                    <!-- 5 -->
                                                    <div data-index="5" class="position-relative cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">

                                                        <div class="bottom-inherit image-upload-progress top-0">
                                                            <div class="progress-bar h-3px"></div>
                                                        </div>
                                                        <span class="svg-icon svg-icon-muted svg-icon-2x">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black"></path>
                                                                <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black"></path>
                                                            </svg>
                                                        </span>
                                                    </div>
                                                    <!-- 6 -->
                                                    <div data-index="6" class="position-relative cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">

                                                        <div class="bottom-inherit image-upload-progress top-0">
                                                            <div class="progress-bar h-3px"></div>
                                                        </div>
                                                        <span class="svg-icon svg-icon-muted svg-icon-2x">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black"></path>
                                                                <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black"></path>
                                                            </svg>
                                                        </span>
                                                    </div>
                                                    <!-- 7 -->
                                                    <div data-index="7" class="position-relative cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">

                                                        <div class="bottom-inherit image-upload-progress top-0">
                                                            <div class="progress-bar h-3px"></div>
                                                        </div>
                                                        <span class="svg-icon svg-icon-muted svg-icon-2x">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black"></path>
                                                                <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black"></path>
                                                            </svg>
                                                        </span>
                                                    </div>


                                                    <!-- 8 -->
                                                    <div data-type="video" data-index="8" class="position-relative cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">

                                                        <div class="bottom-inherit image-upload-progress top-0">
                                                            <div class="progress-bar h-3px"></div>
                                                        </div>
                                                        <span class="svg-icon svg-icon-muted svg-icon-2x">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" style="fill:#a1a5b7;">
                                                                <path d="M336.2 64H47.8C21.4 64 0 85.4 0 111.8v288.4C0 426.6 21.4 448 47.8 448h288.4c26.4 0 47.8-21.4 47.8-47.8V111.8c0-26.4-21.4-47.8-47.8-47.8zm189.4 37.7L416 177.3v157.4l109.6 75.5c21.2 14.6 50.4-.3 50.4-25.8V127.5c0-25.4-29.1-40.4-50.4-25.8z" />
                                                            </svg>
                                                        </span>
                                                    </div>
                                                </div>

                                                <div id="mainImgUpload" class="h-450px position-relative bg-light justify-align-center flex-grow-1 me-2">
                                                    <img class="img-fluid mh-100" src=" <?php echo $Web->get_assets("images/web/blank-image.svg"); ?>" alt="" srcset="">
                                                </div>

                                            </div>

                                        </div>
                                    </div>

                                </div>

                                <div class="col-lg-7">

                                    <div class="card card-flush py-2 mb-2 mb-lg-4">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>Product Information</h2>
                                            </div>
                                        </div>
                                        <div class="card-body pt-0">
                                            <div class="row">
                                                <div class="fv-row mb-7">
                                                    <label class="required fs-6 fw-bold form-label mb-2">Product Name</label>
                                                    <input required="" maxlength="200" name="product_name" value="<?php echo $Listing->product_name($variation_id, $svariation_id); ?>" type="text" class="form-control form-control-solid">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-6 mb-7">
                                                    <label class="required fs-6 fw-bold form-label mb-2"> Minimum Order </label>
                                                    <input data-mask="integer" required="" name="minimum_order" value="<?php echo $Listing->minimum_order($variation_id, $svariation_id); ?>" type="text" class="form-control form-control-solid">
                                                </div>
                                                <div class="col-lg-6 mb-7">
                                                    <label class="required fs-6 fw-bold form-label mb-2"> Maximum Order </label>
                                                    <input data-mask="integer" required="" name="maximum_order" value="<?php echo $Listing->maximum_order($variation_id, $svariation_id); ?>" type="text" class="form-control form-control-solid">
                                                </div>
                                                <div class="col-lg-6 mb-7">
                                                    <label class="required fs-6 fw-bold form-label mb-2"> Product Mrp </label>
                                                    <input data-mask="integer" name="product_mrp" required type="text" class="form-control form-control-solid" value="<?php echo $Listing->mrp($variation_id, $svariation_id); ?>">
                                                </div>
                                                <div class="col-lg-6 mb-7">
                                                    <label class="required fs-6 fw-bold form-label mb-2"> Product Price </label>
                                                    <input data-mask="integer" name="product_price" required type="text" class="form-control form-control-solid" value="<?php echo $Listing->price($variation_id, $svariation_id); ?>">
                                                </div>
                                                <div class="col-lg-6 mb-7">
                                                    <label class="required fs-6 fw-bold form-label mb-2"> Stock </label>
                                                    <input data-mask="integer" name="stock" required type="text" class="form-control form-control-solid" value="<?php echo $Listing->stock($variation_id, $svariation_id); ?>">
                                                </div>
                                                <div class="col-lg-6 mb-7">
                                                    <label class="required fs-6 fw-bold form-label mb-2"> Low Stock Warning</label>
                                                    <input data-mask="integer" name="low_stock_warning" required type="text" class="form-control form-control-solid" value="<?php echo $Listing->stock($variation_id, $svariation_id); ?>">
                                                </div>
                                                <div class="col-lg-6 mb-7">
                                                    <label class="required fs-6 fw-bold form-label mb-2"> Sku Id </label>
                                                    <input name="sku_id" required type="text" class="form-control form-control-solid" value="<?php echo $Listing->sku_id($variation_id, $svariation_id); ?>">
                                                </div>
                                                <div class="col-lg-6 mb-7">
                                                    <label class="required fs-6 fw-bold form-label mb-2"> Return Policy </label>
                                                    <select id="return_policy" name="return_policy" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" value="<?php echo $Listing->return_policy($variation_id, $svariation_id); ?>" type="text" class="form-select form-select-solid">
                                                        <option value=""></option>
                                                        <option value="no">No</option>
                                                        <option value="replacement">Replacement</option>
                                                        <option value="return">Return</option>
                                                    </select>
                                                </div>
                                                <div id="return_policy_days" class="col-lg-6 mb-7">
                                                    <label class="required fs-6 fw-bold form-label mb-2"> Return Policy </label>
                                                    <div class="input-group input-group-solid">
                                                        <input data-mask="integer" name="return_policy_days" value="<?php echo $Listing->return_policy_days($variation_id, $svariation_id); ?>" type="text" class="form-control form-control-solid">
                                                        <span class="input-group-text">Days</span>
                                                    </div>
                                                </div>
                                                <div id="return_policy_tc" class="fv-row mb-7">
                                                    <label class="required fs-6 fw-bold form-label mb-2"> Return Policy T&C </label>
                                                    <textarea name="return_policy_tc" type="text" class="form-control form-control-solid"><?php echo $Listing->return_policy_tc($variation_id, $svariation_id); ?></textarea>
                                                </div>

                                                <div class="col-lg-6 mb-7">
                                                    <label class="required fs-6 fw-bold form-label mb-2"> Cash On Delivery</label>
                                                    <select name="cod_status" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" value="<?php echo $Listing->cod_status($variation_id, $svariation_id); ?>" type="text" class="form-select form-select-solid">
                                                        <option value=""></option>
                                                        <option value="no">No</option>
                                                        <option value="yes">Yes</option>
                                                    </select>
                                                </div>
                                                <div class="col-lg-6 mb-7">
                                                    <label class="required fs-6 fw-bold form-label mb-2"> Status</label>
                                                    <select name="product_status" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" value="<?php echo $Listing->status($variation_id, $svariation_id); ?>" type="text" class="form-select form-select-solid">
                                                        <option value=""></option>
                                                        <option value="active">Active</option>
                                                        <option value="inactive">Inactive</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="card card-flush py-2 mb-2 mb-lg-4">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>Product Details</h2>
                                            </div>
                                        </div>
                                        <div class="card-body pt-0">
                                            <?php echo $Listing->product_details_form($variation_id, $svariation_id); ?>
                                        </div>
                                    </div>

                                    <div data-portion="description" class="card card-flush py-2 mb-2 mb-lg-4">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>Product Tags</h2>
                                            </div>
                                        </div>
                                        <div class="card-body pt-0">
                                            <div class="d-flex align-justify-between ">
                                                <label class="text-muted fs-7 form-label">Enter tags that describe your product (optional) </label>
                                                <div class="d-flex mb-2">
                                                    <button title="Copy Tags" data-bs-toggle="tooltip" id="copyTag" type="button" class="btn d-none btn-icon btn-sm btn-outline-light">
                                                        <span class="svg-icon svg-icon-2 ionic text-dark">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                                <title>Copy</title>
                                                                <rect x="128" y="128" width="336" height="336" rx="57" ry="57" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32" style="color: #000;"></rect>
                                                                <path d="M383.5 128l.5-24a56.16 56.16 0 00-56-56H112a64.19 64.19 0 00-64 64v216a56.16 56.16 0 0056 56h24" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" fill="none" style="color: #000;"></path>
                                                            </svg>
                                                        </span>
                                                    </button>
                                                    <button title="Remove All Tags" data-bs-toggle="tooltip" id="removeAllTag" type="button" class="btn d-none btn-icon btn-sm btn-outline-light">
                                                        <span class="ionic text-dark svg-icon svg-icon-danger svg-icon-2">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                                <title>Close</title>
                                                                <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M368 368L144 144M368 144L144 368" />
                                                            </svg>
                                                        </span>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="position-relative form-group">
                                                <input readonly autocomplete="off" value='<?php echo $Listing->tags($variation_id, $svariation_id); ?>' placeholder="Type Something" maxlength="500" class="form-control" name="tags" id="tags">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="card card-flush py-2 mb-2 mb-lg-4">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>Description</h2>
                                            </div>
                                        </div>
                                        <div class="card-body pt-0">
                                            <label class="text-muted fs-7 form-label">Describe your product (optional) </label>
                                            <textarea maxlength="3000" class="form-control form-control-solid" name="description" id="" cols="30" rows="10"><?php echo $Listing->description($variation_id, $svariation_id); ?></textarea>
                                        </div>
                                    </div>
                                    
                                    <?php if(!empty($QC->create_highlights($variation_id, $svariation_id)))
                                    {
                                        ?>      <div class="card card-flush py-2 mb-2 mb-lg-4">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>Highlights</h2>
                                            </div>
                                        </div>
                                        <div class="card-body pt-0">
                                            <?php echo $QC->create_highlights($variation_id, $svariation_id); ?>
                                        </div>
                                    </div>
                                        <?php
                                    }
                                    ?>
                              


                                </div>
                            </div>



                        </div>
                    </div>
                </div>

                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>
    </div>

    <div class="modal fade" id="rejectQcModal" tabindex="-1" style="display: none;" aria-hidden="true">
        <div class="modal-dialog mw-650px">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="fw-bolder">Reject Qc</h2>
                    <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                        <span class="svg-icon svg-icon-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                            </svg>
                        </span>
                    </div>
                </div>
                <div class="modal-body scroll-y">
                    <form default-validation="" class="needs-validation" novalidate>

                        <div class="fv-row mb-2 mb-lg-4 ">
                            <label class="required fs-6 fw-bold form-label mb-2">Please specify which portions has incorrect details</label>
                            <div class="border-top-dashed border-top">
                                <label class="align-center error-item p-4 cursor-pointer border-bottom-dashed border-bottom">
                                    <div class="form-check form-check-sm form-check-custom form-check-solid">
                                        <input autocomplete="off" class="form-check-input" type="checkbox" value="image">
                                    </div>
                                    <a class="text-gray-800 ms-4 text-hover-primary">Product Image</a>
                                </label>

                                <label class="align-center error-item  p-4 cursor-pointer border-bottom-dashed border-bottom">
                                    <div class="form-check form-check-sm form-check-custom form-check-solid">
                                        <input autocomplete="off" class="form-check-input" type="checkbox" value="information">
                                    </div>
                                    <a class="text-gray-800 ms-4  text-hover-primary">Product Information</a>
                                </label>

                                <label class="align-center error-item  p-4 cursor-pointer border-bottom-dashed border-bottom">
                                    <div class="form-check form-check-sm form-check-custom form-check-solid">
                                        <input autocomplete="off" class="form-check-input" type="checkbox" value="details">
                                    </div>
                                    <a class="text-gray-800  ms-4 text-hover-primary">Product Details</a>
                                </label>

                                <label class="align-center error-item  p-4 cursor-pointer border-bottom-dashed border-bottom">
                                    <div class="form-check form-check-sm form-check-custom form-check-solid">
                                        <input autocomplete="off" class="form-check-input" type="checkbox" value="tags">
                                    </div>
                                    <a class="text-gray-800  ms-4 text-hover-primary">Product Tags</a>
                                </label>

                                <label class="align-center error-item  p-4 cursor-pointer border-bottom-dashed border-bottom">
                                    <div class="form-check form-check-sm form-check-custom form-check-solid">
                                        <input autocomplete="off" class="form-check-input" type="checkbox" value="description">
                                    </div>
                                    <a class="text-gray-800  ms-4 text-hover-primary">Product Description</a>
                                </label>

                                <label class="align-center error-item  p-4 cursor-pointer border-bottom-dashed border-bottom">
                                    <div class="form-check form-check-sm form-check-custom form-check-solid">
                                        <input autocomplete="off" class="form-check-input" type="checkbox" value="highlights">
                                    </div>
                                    <a class="text-gray-800  ms-4 text-hover-primary">Product Highlights</a>
                                </label>
                            </div>
                            <input name="errorInput" autocomplete="off" class="d-none" type="text" value="" required>
                            <div class="invalid-feedback">You must choose a detail</div>
                        </div>


                        <div class="fv-row mb-7">
                            <label class="required fs-6 fw-bold form-label mb-2">Reject Reason</label>
                            <textarea required rows="5" type="text" class="form-control" name="reject_reason" value=""></textarea>
                            <div class="invalid-feedback">Reject Reason is required</div>
                        </div>

                        <div class="justify-right">
                            <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                            <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--  -->

    <!--  -->
    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/tagify.js"); ?>"></script>

    <script>
        setActiveNavItem(getCurrentDirPath() + "view");
        Admin.QC.view('<?php echo $data; ?>');
    </script>
</body>


</html>