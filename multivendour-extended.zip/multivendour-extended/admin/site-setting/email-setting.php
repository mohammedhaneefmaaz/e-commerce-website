<?php
require_once "../../db.php";
$Login->check_admin_login();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Email Setting - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/admin/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <div class="row">

                            <div class="col-lg-6">
                                <div class="card mb-4 card-flush">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h4>Email Settings</h4>
                                        </div>
                                        <div class="card-toolbar">
                                            <a type="edit" data-form="emailForm" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                                <span class="svg-icon svg-icon-3">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="black"></path>
                                                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="black"></path>
                                                    </svg>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <form id="emailForm" action="" novalidate="novalidate">
                                            <div class="fv-row mb-10 ">
                                                <label class="form-label">Encryption</label>
                                                <select required value="<?php echo $Web->email_setting(false)->mail_encryption ?? ""; ?>" class="form-select form-select-solid" name="mail_encryption" data-control="select2" data-hide-search="true" data-placeholder="Select" id="">
                                                    <option value=""></option>
                                                    <option value="ssl">SSL</option>
                                                    <option value="tls">TLS</option>
                                                </select>
                                                <div class="invalid-feedback">Encryption is required</div>
                                            </div>
                                            <div class="fv-row mb-10 ">
                                                <label class="form-label"> Mail Host </label>
                                                <input required value="<?php echo $Web->email_setting(false)->mail_host ?? ""; ?>" type="text" class="form-control mb-2" name="mail_host" placeholder="Mail Host">
                                                <div class="invalid-feedback">Mail Host is required</div>
                                            </div>
                                            <div class="fv-row mb-10 ">
                                                <label class="form-label"> Mail Port </label>
                                                <input required value="<?php echo $Web->email_setting(false)->mail_port ?? ""; ?>" type="text" class="form-control mb-2" name="mail_port" placeholder=" Mail Port ">
                                                <div class="invalid-feedback">Mail Port is required</div>
                                            </div>
                                            <div class="fv-row mb-10 ">
                                                <label class="form-label"> Mail Username </label>
                                                <input required value="<?php echo $Web->email_setting(false)->mail_username ?? ""; ?>" type="text" class="form-control mb-2" name="mail_username" placeholder=" Mail Username ">
                                                <div class="invalid-feedback">Mail Username is required</div>
                                            </div>
                                            <div class="fv-row mb-10 ">
                                                <label class="form-label"> Mail Password </label>
                                                <div class="position-relative">
                                                    <input placeholder=" Mail Password " required class="form-control no-bg form-control-lg password-input" value="<?php echo $Web->email_setting(false)->mail_password ?? ""; ?>" type="password" name="mail_password" autocomplete="off" />
                                                    <div class="show password-toggle">
                                                        <svg class="show" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="-10 -10 47 38" style="stroke:#0c0c0d">
                                                            <g style="stroke-width:2;fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round" transform="translate(1 1)">
                                                                <path d="m0 8c0-2 5.5-8 11-8s11 6 11 8-5.5 8-11 8-11-6-11-8z" />
                                                                <path d="m11 12c2.2091 0 4-1.7909 4-4 0-2.20914-1.7909-4-4-4-2.20914 0-4 1.79086-4 4 0 2.2091 1.79086 4 4 4z" />
                                                                <path d="m13 7c.5523 0 1-.44772 1-1s-.4477-1-1-1-1 .44772-1 1 .4477 1 1 1z" fill="#000" fill-rule="nonzero" />
                                                            </g>
                                                        </svg>
                                                        <svg class="hide" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="-10 -7 47 38" style="stroke:#0c0c0d">
                                                            <g style="stroke-width:2;fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round" transform="translate(1 1)">
                                                                <path d="m4.14 15.76c-2.44-1.76-4.14-4.13-4.14-5.22 0-1.91 5.27-7.66 10.54-7.66 1.8042928.06356301 3.559947.60164173 5.09 1.56m3.53 2.85c.954643.86366544 1.6242352 1.9970896 1.92 3.25 0 1.92-5.27 7.67-10.54 7.67-.82748303-.0073597-1.64946832-.1353738-2.44-.38" />
                                                                <path d="m11.35 14.29c1.3567546-.2923172 2.4501897-1.2939955 2.86-2.62m-1.56-4.33c-1.5090443-.9785585-3.49511641-.77861361-4.77882585.48110127-1.28370945 1.25971488-1.52108848 3.24166123-.57117415 4.76889873" />
                                                                <path d="m13.08 7.9c-.1699924-.15256531-.3916348-.2347875-.62-.23-.5522847 0-1 .44771525-1 1 .0046671.23144917.0894903.45410992.24.63" />
                                                                <path d="m21.08 0-21.08 21.08" />
                                                            </g>
                                                        </svg>
                                                    </div>
                                                </div>

                                                <div class="invalid-feedback">Mail Password is required</div>
                                            </div>
                                            <div class="justify-right">
                                                <button type="cancel" class="d1-none btn btn-secondary">Cancel</button>
                                                <button type="submit" id="submit" class="d1-none ms-4 btn btn-light-primary">Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="card mb-4 card-flush">
                                    <div class="card-header">
                                        <div class="card-title flex-column">
                                            <h4>Send Test Email</h4>
                                            <div class="fs-7 mt-2 text-danger">You can send a test mail to check if your mail server is working.</div>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <form id="testEmailForm" action="" novalidate="novalidate">

                                            <div class="fv-row mb-10 ">
                                                <label class="form-label"> Email Address </label>
                                                <input required type="text" class="form-control mb-2" name="test_email" placeholder="Email Address">
                                                <div class="invalid-feedback">Email Address is required</div>
                                            </div>
                                            <div class="justify-right">
                                                <button type="submit" id="submit" class="btn btn-light-primary">Send</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script>
        setActiveNavItem(location.pathname);
        Admin.Setting.emailSetting();
    </script>
</body>


</html>