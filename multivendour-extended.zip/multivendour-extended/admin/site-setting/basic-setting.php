<?php
require_once "../../db.php";
$Login->check_admin_login();


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Basic Setting - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/admin/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <div class="row">

                            <div class="col-lg-6 mx-auto">
                                <div class="card mb-4 card-flush">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h4>Basic Settings</h4>
                                        </div>
                                        <div class="card-toolbar">

                                            <button type="edit" id="reset" class="btn btn-danger btn-sm me-4">
                                                <div class="text-white">Reset</div>
                                            </button>

                                            <a type="edit" data-form="basicForm" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                                <span class="svg-icon svg-icon-3">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="black"></path>
                                                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="black"></path>
                                                    </svg>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">

                                        <form id="basicForm" action="" novalidate="novalidate">

                                            <div class="fv-row mb-10 ">
                                                <label class="form-label"> Web Name </label>
                                                <input required value="<?php echo $Web->web_name(); ?>" type="text" class="form-control mb-2" name="web_name" placeholder="Web Name ">
                                            <div class="invalid-feedback">Web Name is required</div>
                                            </div>

                                            <div class="fv-row mb-10 ">
                                                <label class="form-label"> Currency </label>
                                                <input required value="<?php echo $Web->currency(); ?>" type="text" class="form-control mb-2" name="currency" placeholder="Currency">
                                            <div class="invalid-feedback">Currency is required</div>
                                            </div>

                                            <div class="fv-row mb-10 ">
                                                <label class="form-label">Currency Position</label>
                                                <select required value="<?php echo $Web->currency_position(); ?>" class="form-select form-select-solid" name="currency_position" data-control="select2" data-hide-search="true" data-placeholder="Select">
                                                    <option value=""></option>
                                                    <option value="prefix">Prefix</option>
                                                    <option value="suffix">Suffix</option>
                                                </select>
                                            <div class="invalid-feedback">Currency Position is required</div>
                                            </div>

                                            <div class="fv-row mb-10 ">
                                                <label class="form-label">Time Zone</label>
                                                <select required value="<?php echo $Web->timezone(); ?>" class="form-select form-select-solid" name="timezone" data-control="select2" data-placeholder="Select">
                                                    <option value=""></option>
                                                    <?php
                                                    $timezone = Setting::timezone_list();
                                                    foreach ($timezone as $value => $option) {
                                                        echo "<option value='$value'>$option</option>";
                                                    }
                                                    ?>
                                                </select>
                                            <div class="invalid-feedback">Time Zone is required</div>
                                            </div>

                                            <div class="fv-row mb-10 ">
                                                <label class="form-label"> Primary Colour </label>
                                                <input required value="<?php echo $Web->rgb_to_hex($Web->primary_color()); ?>" type="color" class="min-h-40px form-control mb-2" name="primary_color" placeholder=" Mail Username ">
                                            <div class="invalid-feedback">Primary Colour is required</div>
                                            </div>

                                            <div class="justify-right">
                                                <button type="cancel" class="d1-none btn btn-secondary">Cancel</button>
                                                <button type="submit" id="submit" class="d1-none ms-4 btn btn-light-primary">Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script>
        setActiveNavItem(location.pathname);
        Admin.Setting.basicSetting();
    </script>
</body>


</html>