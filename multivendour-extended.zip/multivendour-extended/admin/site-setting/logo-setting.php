<?php
require_once "../../db.php";
$Login->check_admin_login();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Logo Setting - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/admin/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <div class="row">

                            <div class="col-lg-6">
                                <div class="card card-flush py-2 mb-4">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2>User Panel Logo</h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div data-input-parent="logoUpload" class="cursor-pointer image-input image-upload-card mb-4">
                                            <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-lx-image-input-action="change" data-bs-toggle="tooltip" title="" data-bs-original-title="Change Logo">
                                                <i class="bi bi-pencil-fill fs-7"></i>
                                                <input data-type="logo" data-panel="user" data-input="changeLogo" type="file" name="avatar" accept=".png, .jpg, .jpeg">
                                            </label>
                                            <div class="image-upload-progress">
                                                <div class="progress-bar"></div>
                                            </div>

                                            <img class="img-fluid" src="<?php echo $Web->logo(); ?>" alt="logo" srcset="">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="card card-flush py-2 mb-4">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2>User Panel Favicon</h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div data-input-parent="logoUpload" class="cursor-pointer image-input image-upload-card mb-4">
                                            <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-lx-image-input-action="change" data-bs-toggle="tooltip" title="" data-bs-original-title="Change Favicon">
                                                <i class="bi bi-pencil-fill fs-7"></i>
                                                <input data-type="favicon" data-panel="user" data-input="changeLogo" type="file" name="avatar" accept=".png, .jpg, .jpeg">
                                            </label>
                                            <div class="image-upload-progress">
                                                <div class="progress-bar"></div>
                                            </div>

                                            <img class="img-fluid" src="<?php echo $Web->favicon(); ?>" alt="favicon" srcset="">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="card card-flush py-2 mb-4">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2>Seller Panel Logo</h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div data-input-parent="logoUpload" class="cursor-pointer image-input image-upload-card mb-4">
                                            <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-lx-image-input-action="change" data-bs-toggle="tooltip" title="" data-bs-original-title="Change Logo">
                                                <i class="bi bi-pencil-fill fs-7"></i>
                                                <input data-type="logo" data-panel="seller" data-input="changeLogo" type="file" name="avatar" accept=".png, .jpg, .jpeg">
                                            </label>
                                            <div class="image-upload-progress">
                                                <div class="progress-bar"></div>
                                            </div>

                                            <img class="img-fluid" src="<?php echo $Web->seller_logo(); ?>" alt="logo" srcset="">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="card card-flush py-2 mb-4">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2>Seller Panel Favicon</h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div data-input-parent="logoUpload" class="cursor-pointer image-input image-upload-card mb-4">
                                            <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-lx-image-input-action="change" data-bs-toggle="tooltip" title="" data-bs-original-title="Change Favicon">
                                                <i class="bi bi-pencil-fill fs-7"></i>
                                                <input data-type="favicon" data-panel="seller" data-input="changeLogo" type="file" name="avatar" accept=".png, .jpg, .jpeg">
                                            </label>
                                            <div class="image-upload-progress">
                                                <div class="progress-bar"></div>
                                            </div>

                                            <img class="img-fluid" src="<?php echo $Web->seller_favicon(); ?>" alt="favicon" srcset="">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="card card-flush py-2 mb-4">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2>Admin Panel Logo</h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div data-input-parent="logoUpload" class="cursor-pointer image-input image-upload-card mb-4">
                                            <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-lx-image-input-action="change" data-bs-toggle="tooltip" title="" data-bs-original-title="Change Logo">
                                                <i class="bi bi-pencil-fill fs-7"></i>
                                                <input data-type="logo" data-panel="admin" data-input="changeLogo" type="file" name="avatar" accept=".png, .jpg, .jpeg">
                                            </label>
                                            <div class="image-upload-progress">
                                                <div class="progress-bar"></div>
                                            </div>

                                            <img class="img-fluid" src="<?php echo $Web->admin_logo(); ?>" alt="logo" srcset="">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="card card-flush py-2 mb-4">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2>Admin Panel Favicon</h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div data-input-parent="logoUpload" class="cursor-pointer image-input image-upload-card mb-4">
                                            <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-lx-image-input-action="change" data-bs-toggle="tooltip" title="" data-bs-original-title="Change Favicon">
                                                <i class="bi bi-pencil-fill fs-7"></i>
                                                <input data-type="favicon" data-panel="admin" data-input="changeLogo" type="file" name="avatar" accept=".png, .jpg, .jpeg">
                                            </label>
                                            <div class="image-upload-progress">
                                                <div class="progress-bar"></div>
                                            </div>

                                            <img class="img-fluid" src="<?php echo $Web->admin_favicon(); ?>" alt="favicon" srcset="">
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script>
        setActiveNavItem(location.pathname);

        Admin.Setting.LogoSetting();
    </script>
</body>


</html>