     <div class="card mb-lg-6 mb-4">
         <div class="card-header border-0">
             <div class="card-title">
                 <h2> Contact Details </h2>
             </div>
         </div>
         <div class="card-body pt-0 pb-5">

             <form class="form form-disabled" id="contact_details_form">
                 <div class="row">
                     <div class="fv-row col-lg-6 mb-7">
                         <label class="fs-6 fw-bold mb-2 required"> Name </label>
                         <input type="text" class="form-control form-control-solid" placeholder="" name="contact_name" value="<?php echo $Seller->contact_details()->contact_name ?? ""; ?>" />
                     </div>

                     <div class="fv-row col-lg-6 mb-7">
                         <label class="fs-6 fw-bold mb-2 required"> Mobile Number </label>
                         <input type="text" class="form-control form-control-solid" placeholder="" name="mobile_number" value="<?php echo $Seller->contact_details()->mobile_number ?? ""; ?>" />
                     </div>

                     <div class="fv-row col-lg-6 mb-7">
                         <label class="fs-6 fw-bold mb-2 required"> Contact Email</label>
                         <input type="text" class="form-control form-control-solid" placeholder="" name="contact_email" value="<?php echo $Seller->contact_details()->contact_email ?? ""; ?>" />
                     </div>

                     <div class="fv-row col-lg-6 mb-7">
                         <label class="fs-6 fw-bold mb-2 required"> Preferred Language </label>
                         <input type="text" class="form-control form-control-solid" placeholder="" name="preferred_language" value="<?php echo $Seller->contact_details()->preferred_language ?? ""; ?>" />
                     </div>

                 </div>
                 <div class="d-flex mt-4 justify-content-end">
                     <button type="cancel" class="btn d1-none me-4 btn-secondary">Cancel</button>
                     <button type="submit" class="btn d1-none btn-primary">Update Contact</button>
                 </div>
             </form>
         </div>
     </div>
     <!--  -->
     <div class="card mb-lg-6 mb-4">
         <div class="card-header border-0">
             <div class="card-title">
                 <h2> Pickup Address </h2>
             </div>
         </div>
         <div class="card-body pt-0 pb-5">
             <form class="form form-disabled" id="pickup_address_form">
                 <div class="row">
                     <div class="fv-row col-lg-6 mb-7">
                         <label class="fs-6 fw-bold mb-2 required"> Country </label>
                         <input type="text" class="form-control form-control-solid" placeholder="" name="pickup_country" value="<?php echo $Seller->pickup_address()->pickup_country ?? ""; ?>" />
                     </div>

                     <div class="fv-row col-lg-6 mb-7">
                         <label class="fs-6 fw-bold mb-2 required"> State </label>
                         <input type="text" class="form-control form-control-solid" placeholder="" name="pickup_state" value="<?php echo $Seller->pickup_address()->pickup_state ?? ""; ?>" />
                     </div>

                     <div class="fv-row col-lg-6 mb-7">
                         <label class="fs-6 fw-bold mb-2 required"> City </label>
                         <input type="text" class="form-control form-control-solid" placeholder="" name="pickup_city" value="<?php echo $Seller->pickup_address()->pickup_city ?? ""; ?>" />
                     </div>

                     <div class="fv-row col-lg-6 mb-7">
                         <label class="fs-6 fw-bold mb-2 required"> Address</label>
                         <input type="text" class="form-control form-control-solid" placeholder="" name="pickup_address" value="<?php echo $Seller->pickup_address()->pickup_address ?? ""; ?>" />
                     </div>

                     <div class="fv-row col-lg-6 mb-7">
                         <label class="fs-6 fw-bold mb-2 required"> PIN code</label>
                         <input type="text" class="form-control form-control-solid" placeholder="" name="pin_code" value="<?php echo $Seller->pickup_address()->pin_code ?? ""; ?>" />
                     </div>

                 </div>
                 <div class="d-flex mt-4 justify-content-end">
                     <button type="cancel" class="btn d1-none me-4 btn-secondary">Cancel</button>
                     <button type="submit" class="btn d1-none btn-primary">Update Address</button>
                 </div>
             </form>
         </div>
     </div>