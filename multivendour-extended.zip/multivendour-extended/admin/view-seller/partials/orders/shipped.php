 <div class="card card-flush">
     <ul class="nav px-6 py-2 nav-tabs nav-line-tabs nav-line-tabs-2x fs-6">
         <li class="nav-item">
             <a class="nav-link" href="<?php echo $Web->admin_url() . '/view-seller/?id=' . $user_id; ?>&tab=orders">New Orders</a>
         </li>
         <li class="nav-item">
             <a class="nav-link" href="<?php echo $Web->admin_url() . '/view-seller/?id=' . $user_id; ?>&tab=orders&status=rtd">Pending RTD</a>
         </li>
         <li class="nav-item">
             <a class="nav-link" href="<?php echo $Web->admin_url() . '/view-seller/?id=' . $user_id; ?>&tab=orders&status=handover">Pending Handover</a>
         </li>
         <li class="nav-item">
             <a class="nav-link active" href="<?php echo $Web->admin_url() . '/view-seller/?id=' . $user_id; ?>&tab=orders&status=shipped">Shipped Orders</a>
         </li>
         <li class="nav-item  ms-auto">
             <a class="nav-link " href="<?php echo $Web->admin_url() . '/view-seller/?id=' . $user_id; ?>&tab=orders&status=cancelled">Cancelled Orders</a>
         </li>
         <li class="nav-item">
             <a class="nav-link" href="<?php echo $Web->admin_url() . '/view-seller/?id=' . $user_id; ?>&tab=orders&status=rejected">Rejected Orders</a>
         </li>
         <li class="nav-item">
             <a class="nav-link" href="<?php echo $Web->admin_url() . '/view-seller/?id=' . $user_id; ?>&tab=orders&status=completed">Completed Orders</a>
         </li>
     </ul>
     <div class="card-header">
         <div class="card-title">
             <h2>Shipped Orders</h2>
         </div>
     </div>
     <div class="card-body pt-0">
         <table class="table align-middle table-row-dashed fs-6 gy-5" id="data_table">
             <thead>
                 <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                     <th class="min-w-50px">#</th>
                     <th class="min-w-100px">Order Id</th>
                     <th class="min-w-150px">Product Details</th>
                     <th class="min-w-100px">Buyer Name</th>
                     <th class="min-w-50px">Quantity</th>
                     <th class="min-w-100px">Amount</th>
                     <th class="min-w-150px">Order Date</th>
                     <th class="min-w-150px">Shipped Date</th>
                     <th class="min-w-50px">Actions</th>
                 </tr>
             </thead>
             <tbody class="fw-bold text-gray-600">

             </tbody>
         </table>
     </div>
 </div>