          <div class="mb-lg-6 mb-4 card card-flush">

              <div class="card-header">
                  <div class="card-title">
                      <h2>Transactions</h2>
                  </div>
              </div>
              <div class="card-body pt-0">
                  <table class="table align-middle table-row-dashed fs-6 gy-5" id="data_table">
                      <thead>
                          <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                              <th class="min-w-50px">#</th>
                              <th class="min-w-100px">Transaction Id</th>
                              <th class="min-w-150px">Amount</th>
                              <th class="min-w-150px">Txn Charge</th>
                              <th class="min-w-150px">Net Amount</th>
                              <th class="min-w-50px">Description</th>
                              <th class="min-w-150px">Date</th>
                              <th class="min-w-50px">Status</th>
                          </tr>
                      </thead>
                      <tbody class="fw-bold text-gray-600">

                      </tbody>
                  </table>
              </div>
          </div>