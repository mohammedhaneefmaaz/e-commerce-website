<?php

$status = $_GET["status"] ?? "active";

switch ($status) {
    case "rtd":
        require_once "orders/rtd.php";
        break;
    case "handover":
        require_once "orders/handover.php";
        break;
    case "shipped":
        require_once "orders/shipped.php";
        break;
    case "cancelled":
        require_once "orders/cancelled.php";
        break;
    case "rejected":
        require_once "orders/rejected.php";
        break;
    case "completed":
        require_once "orders/completed.php";
        break;
    default:
        require_once "orders/index.php";
        break;
}
