<?php

switch($listingStatus)
{
    case "active":
        require_once "active_listings.php";
        break;
    case "inactive":
        require_once "inactive_listings.php";
        break;
    case "blocked":
        require_once "blocked_listings.php";
        break;
    case "archived":
        require_once "archived_listings.php";
        break;
}


?>