<?php

require_once "../../db.php";
$Login->check_admin_login();


use Ecommerce\Seller;

if (!isset($_GET["id"])) Errors::response_404();
$user_id = $_GET["id"];
if (!Seller::is_user_seller($user_id)) Errors::response_404();
$Seller = new Seller($user_id);
$tab = $_GET["tab"] ?? "overview";

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>All Sellers - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/admin/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <div class="d-flex flex-column flex-lg-row">
                            <div class="flex-column flex-lg-row-auto w-100 w-lg-350px">
                                <div class="card mb-5">
                                    <div class="card-body pt-15">
                                        <div class="d-flex flex-center flex-column mb-5">
                                            <div class="symbol symbol-150px symbol-circle mb-7">
                                                <img id="store_logo" data-user-avatar="" src="<?php echo $Seller->store_logo(); ?>" alt="image" />
                                            </div>
                                            <div id="store_name" class="fs-3 text-gray-800 fw-bolder mb-1"><?php echo $Web->is_empty($Seller->store_name()) ? "store Name" : $Seller->store_name(); ?></div>
                                            <div id="store_description" class="fs-5 pre-wrap  fw-bold text-muted mb-6"><?php echo $Web->is_empty($Seller->store_description()) ? "store Description" : $Seller->store_description(); ?></div>
                                        </div>
                                        <div class="separator separator-dashed my-3"></div>
                                        <div class="pb-5 fs-6">
                                            <div class="fw-bolder mt-5">User ID</div>
                                            <div class="text-gray-600">ID- <?php echo $Seller->user_id; ?></div>

                                            <div class="fw-bolder mt-5">Email</div>
                                            <div class="text-gray-600">
                                                <a class="text-gray-600 text-hover-primary"><?php echo $Seller->email(); ?></a>
                                            </div>

                                            <div class="fw-bolder mt-5">Member Since</div>
                                            <div class="text-gray-600"><?php echo $Seller->registration_date(); ?></div>

                                            <div class="fw-bolder mt-5">Seller Since</div>
                                            <div class="text-gray-600"><?php echo $Seller->seller_since(); ?></div>

                                            <div class="fw-bolder mt-5">Account Status:</div>
                                            <div id="account_status" class="fw-bolder status-label text-success"><?php echo $Seller->status_label(); ?></div>

                                            <?php if ($Seller->status() === "rejected") { ?>
                                                <div class="fw-bolder mt-5">Rejected reason:</div>
                                                <div class="fw-bold fs-7 pre-wrap text-danger"><?php echo $Seller->rejected_reason(); ?></div>
                                            <?php } ?>

                                            <?php if ($Seller->status() === "verified") { ?>
                                                <div id="changeStatusWrapper">
                                                    <div class="fw-bolder mt-5">Change Status:</div>
                                                    <div class="fw-bolder status-label text-success">
                                                        <select id="changeStatus" autocomplete="off" class="form-select form-select-solid" data-placeholder="Select" data-control="select2" data-hide-search="true">
                                                            <option value=""></option>
                                                            <option value="reject">Reject</option>
                                                            <option value="block">Block</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            <?php } ?>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="flex-lg-row-fluid ms-lg-6">

                                <div class="row mt-4 rect-card-no-shadow">
                                    <div class="col-lg-6 col-xl-4">
                                        <div class="rect-card mb-4 card border-bottom border-2 border-primary">
                                            <div class="card-body ">
                                                <div class="align-justify-between">
                                                    <div>
                                                        <h2 class="fs-2x"><?php echo $Seller->orders_data()->new_orders; ?></h2>
                                                        <h6 class="text-success fw-bolder">New Orders</h6>
                                                    </div>
                                                    <span class="svg-icon">
                                                        <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <path opacity="0.3" d="M21.25 18.525L13.05 21.825C12.35 22.125 11.65 22.125 10.95 21.825L2.75 18.525C1.75 18.125 1.75 16.725 2.75 16.325L4.04999 15.825L10.25 18.325C10.85 18.525 11.45 18.625 12.05 18.625C12.65 18.625 13.25 18.525 13.85 18.325L20.05 15.825L21.35 16.325C22.35 16.725 22.35 18.125 21.25 18.525ZM13.05 16.425L21.25 13.125C22.25 12.725 22.25 11.325 21.25 10.925L13.05 7.62502C12.35 7.32502 11.65 7.32502 10.95 7.62502L2.75 10.925C1.75 11.325 1.75 12.725 2.75 13.125L10.95 16.425C11.65 16.725 12.45 16.725 13.05 16.425Z" fill="black"></path>
                                                            <path d="M11.05 11.025L2.84998 7.725C1.84998 7.325 1.84998 5.925 2.84998 5.525L11.05 2.225C11.75 1.925 12.45 1.925 13.15 2.225L21.35 5.525C22.35 5.925 22.35 7.325 21.35 7.725L13.05 11.025C12.45 11.325 11.65 11.325 11.05 11.025Z" fill="black"></path>
                                                        </svg>
                                                    </span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-xl-4">
                                        <div class="rect-card mb-4 card border-bottom border-2 border-primary">
                                            <div class="card-body ">
                                                <div class="align-justify-between">
                                                    <div>
                                                        <h2 class="fs-2x"><?php echo $Seller->orders_data()->pending_rtd; ?></h2>
                                                        <h6 class="text-success fw-bolder">Pending RTD</h6>
                                                    </div>
                                                    <span class="svg-icon">
                                                        <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <path opacity="0.3" d="M21.25 18.525L13.05 21.825C12.35 22.125 11.65 22.125 10.95 21.825L2.75 18.525C1.75 18.125 1.75 16.725 2.75 16.325L4.04999 15.825L10.25 18.325C10.85 18.525 11.45 18.625 12.05 18.625C12.65 18.625 13.25 18.525 13.85 18.325L20.05 15.825L21.35 16.325C22.35 16.725 22.35 18.125 21.25 18.525ZM13.05 16.425L21.25 13.125C22.25 12.725 22.25 11.325 21.25 10.925L13.05 7.62502C12.35 7.32502 11.65 7.32502 10.95 7.62502L2.75 10.925C1.75 11.325 1.75 12.725 2.75 13.125L10.95 16.425C11.65 16.725 12.45 16.725 13.05 16.425Z" fill="black"></path>
                                                            <path d="M11.05 11.025L2.84998 7.725C1.84998 7.325 1.84998 5.925 2.84998 5.525L11.05 2.225C11.75 1.925 12.45 1.925 13.15 2.225L21.35 5.525C22.35 5.925 22.35 7.325 21.35 7.725L13.05 11.025C12.45 11.325 11.65 11.325 11.05 11.025Z" fill="black"></path>
                                                        </svg>
                                                    </span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-xl-4">
                                        <div class="rect-card mb-4 card border-bottom border-2 border-primary">
                                            <div class="card-body ">
                                                <div class="align-justify-between">
                                                    <div>
                                                        <h2 class="fs-2x"><?php echo $Seller->orders_data()->pending_handover; ?></h2>
                                                        <h6 class="text-success fw-bolder">Pending Handover</h6>
                                                    </div>
                                                    <span class="svg-icon">
                                                        <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <path opacity="0.3" d="M21.25 18.525L13.05 21.825C12.35 22.125 11.65 22.125 10.95 21.825L2.75 18.525C1.75 18.125 1.75 16.725 2.75 16.325L4.04999 15.825L10.25 18.325C10.85 18.525 11.45 18.625 12.05 18.625C12.65 18.625 13.25 18.525 13.85 18.325L20.05 15.825L21.35 16.325C22.35 16.725 22.35 18.125 21.25 18.525ZM13.05 16.425L21.25 13.125C22.25 12.725 22.25 11.325 21.25 10.925L13.05 7.62502C12.35 7.32502 11.65 7.32502 10.95 7.62502L2.75 10.925C1.75 11.325 1.75 12.725 2.75 13.125L10.95 16.425C11.65 16.725 12.45 16.725 13.05 16.425Z" fill="black"></path>
                                                            <path d="M11.05 11.025L2.84998 7.725C1.84998 7.325 1.84998 5.925 2.84998 5.525L11.05 2.225C11.75 1.925 12.45 1.925 13.15 2.225L21.35 5.525C22.35 5.925 22.35 7.325 21.35 7.725L13.05 11.025C12.45 11.325 11.65 11.325 11.05 11.025Z" fill="black"></path>
                                                        </svg>
                                                    </span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-xl-4">
                                        <div class="rect-card mb-4 card border-bottom border-2 border-primary">
                                            <div class="card-body ">
                                                <div class="align-justify-between">
                                                    <div>
                                                        <h2 class="fs-2x"><?php echo $Seller->orders_data()->shipped_orders; ?></h2>
                                                        <h6 class="text-success fw-bolder">Shipped Orders</h6>
                                                    </div>
                                                    <span class="svg-icon">
                                                        <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <path opacity="0.3" d="M21.25 18.525L13.05 21.825C12.35 22.125 11.65 22.125 10.95 21.825L2.75 18.525C1.75 18.125 1.75 16.725 2.75 16.325L4.04999 15.825L10.25 18.325C10.85 18.525 11.45 18.625 12.05 18.625C12.65 18.625 13.25 18.525 13.85 18.325L20.05 15.825L21.35 16.325C22.35 16.725 22.35 18.125 21.25 18.525ZM13.05 16.425L21.25 13.125C22.25 12.725 22.25 11.325 21.25 10.925L13.05 7.62502C12.35 7.32502 11.65 7.32502 10.95 7.62502L2.75 10.925C1.75 11.325 1.75 12.725 2.75 13.125L10.95 16.425C11.65 16.725 12.45 16.725 13.05 16.425Z" fill="black"></path>
                                                            <path d="M11.05 11.025L2.84998 7.725C1.84998 7.325 1.84998 5.925 2.84998 5.525L11.05 2.225C11.75 1.925 12.45 1.925 13.15 2.225L21.35 5.525C22.35 5.925 22.35 7.325 21.35 7.725L13.05 11.025C12.45 11.325 11.65 11.325 11.05 11.025Z" fill="black"></path>
                                                        </svg>
                                                    </span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-xl-4">
                                        <div class="rect-card mb-4 card border-bottom border-2 border-primary">
                                            <div class="card-body ">
                                                <div class="align-justify-between">
                                                    <div>
                                                        <h2 class="fs-2x"><?php echo $Seller->orders_data()->completed_orders; ?></h2>
                                                        <h6 class="text-success fw-bolder">Completed Orders</h6>
                                                    </div>
                                                    <span class="svg-icon">
                                                        <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <path opacity="0.3" d="M21.25 18.525L13.05 21.825C12.35 22.125 11.65 22.125 10.95 21.825L2.75 18.525C1.75 18.125 1.75 16.725 2.75 16.325L4.04999 15.825L10.25 18.325C10.85 18.525 11.45 18.625 12.05 18.625C12.65 18.625 13.25 18.525 13.85 18.325L20.05 15.825L21.35 16.325C22.35 16.725 22.35 18.125 21.25 18.525ZM13.05 16.425L21.25 13.125C22.25 12.725 22.25 11.325 21.25 10.925L13.05 7.62502C12.35 7.32502 11.65 7.32502 10.95 7.62502L2.75 10.925C1.75 11.325 1.75 12.725 2.75 13.125L10.95 16.425C11.65 16.725 12.45 16.725 13.05 16.425Z" fill="black"></path>
                                                            <path d="M11.05 11.025L2.84998 7.725C1.84998 7.325 1.84998 5.925 2.84998 5.525L11.05 2.225C11.75 1.925 12.45 1.925 13.15 2.225L21.35 5.525C22.35 5.925 22.35 7.325 21.35 7.725L13.05 11.025C12.45 11.325 11.65 11.325 11.05 11.025Z" fill="black"></path>
                                                        </svg>
                                                    </span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-xl-4">
                                        <div class="rect-card mb-4 card border-bottom border-2 border-primary">
                                            <div class="card-body ">
                                                <div class="align-justify-between">
                                                    <div>
                                                        <h2 class="fs-2x"><?php echo $Seller->orders_data()->cancelled_orders; ?></h2>
                                                        <h6 class="text-success fw-bolder">Cancelled Orders</h6>
                                                    </div>
                                                    <span class="svg-icon">
                                                        <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <path opacity="0.3" d="M21.25 18.525L13.05 21.825C12.35 22.125 11.65 22.125 10.95 21.825L2.75 18.525C1.75 18.125 1.75 16.725 2.75 16.325L4.04999 15.825L10.25 18.325C10.85 18.525 11.45 18.625 12.05 18.625C12.65 18.625 13.25 18.525 13.85 18.325L20.05 15.825L21.35 16.325C22.35 16.725 22.35 18.125 21.25 18.525ZM13.05 16.425L21.25 13.125C22.25 12.725 22.25 11.325 21.25 10.925L13.05 7.62502C12.35 7.32502 11.65 7.32502 10.95 7.62502L2.75 10.925C1.75 11.325 1.75 12.725 2.75 13.125L10.95 16.425C11.65 16.725 12.45 16.725 13.05 16.425Z" fill="black"></path>
                                                            <path d="M11.05 11.025L2.84998 7.725C1.84998 7.325 1.84998 5.925 2.84998 5.525L11.05 2.225C11.75 1.925 12.45 1.925 13.15 2.225L21.35 5.525C22.35 5.925 22.35 7.325 21.35 7.725L13.05 11.025C12.45 11.325 11.65 11.325 11.05 11.025Z" fill="black"></path>
                                                        </svg>
                                                    </span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-xl-4">
                                        <div class="rect-card mb-4 card border-bottom border-2 border-primary">
                                            <div class="card-body ">
                                                <div class="align-justify-between">
                                                    <div>
                                                        <h2 class="fs-2x"><?php echo $Web->formatCurrency($Seller->net_income()); ?></h2>
                                                        <h6 class="text-success fw-bolder">Total Earnings</h6>
                                                    </div>
                                                    <span class="svg-icon">
                                                        <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <path opacity="0.3" d="M21.25 18.525L13.05 21.825C12.35 22.125 11.65 22.125 10.95 21.825L2.75 18.525C1.75 18.125 1.75 16.725 2.75 16.325L4.04999 15.825L10.25 18.325C10.85 18.525 11.45 18.625 12.05 18.625C12.65 18.625 13.25 18.525 13.85 18.325L20.05 15.825L21.35 16.325C22.35 16.725 22.35 18.125 21.25 18.525ZM13.05 16.425L21.25 13.125C22.25 12.725 22.25 11.325 21.25 10.925L13.05 7.62502C12.35 7.32502 11.65 7.32502 10.95 7.62502L2.75 10.925C1.75 11.325 1.75 12.725 2.75 13.125L10.95 16.425C11.65 16.725 12.45 16.725 13.05 16.425Z" fill="black"></path>
                                                            <path d="M11.05 11.025L2.84998 7.725C1.84998 7.325 1.84998 5.925 2.84998 5.525L11.05 2.225C11.75 1.925 12.45 1.925 13.15 2.225L21.35 5.525C22.35 5.925 22.35 7.325 21.35 7.725L13.05 11.025C12.45 11.325 11.65 11.325 11.05 11.025Z" fill="black"></path>
                                                        </svg>
                                                    </span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>


                                    <div class="col-lg-6 col-xl-4">
                                        <div class="rect-card mb-4 card border-bottom border-2 border-primary">
                                            <div class="card-body ">
                                                <div class="align-justify-between">
                                                    <div>
                                                        <h2 class="fs-2x"><?php echo $Seller->listings_data()->active_listings; ?></h2>
                                                        <h6 class="text-success fw-bolder">Active Listings</h6>
                                                    </div>
                                                    <span class="svg-icon">
                                                        <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <path opacity="0.3" d="M21.25 18.525L13.05 21.825C12.35 22.125 11.65 22.125 10.95 21.825L2.75 18.525C1.75 18.125 1.75 16.725 2.75 16.325L4.04999 15.825L10.25 18.325C10.85 18.525 11.45 18.625 12.05 18.625C12.65 18.625 13.25 18.525 13.85 18.325L20.05 15.825L21.35 16.325C22.35 16.725 22.35 18.125 21.25 18.525ZM13.05 16.425L21.25 13.125C22.25 12.725 22.25 11.325 21.25 10.925L13.05 7.62502C12.35 7.32502 11.65 7.32502 10.95 7.62502L2.75 10.925C1.75 11.325 1.75 12.725 2.75 13.125L10.95 16.425C11.65 16.725 12.45 16.725 13.05 16.425Z" fill="black"></path>
                                                            <path d="M11.05 11.025L2.84998 7.725C1.84998 7.325 1.84998 5.925 2.84998 5.525L11.05 2.225C11.75 1.925 12.45 1.925 13.15 2.225L21.35 5.525C22.35 5.925 22.35 7.325 21.35 7.725L13.05 11.025C12.45 11.325 11.65 11.325 11.05 11.025Z" fill="black"></path>
                                                        </svg>
                                                    </span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>


                                </div>

                            </div>
                        </div>



                        <ul class="nav px-6 py-2 nav-tabs nav-line-tabs nav-line-tabs-2x fs-6">
                            <li class="nav-item">
                                <a class="nav-link <?php if ($tab === "overview") {
                                                        echo "active";
                                                    } ?>" href="<?php echo $Web->admin_url() . '/view-seller/?id=' . $user_id; ?>">Overview</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php if ($tab === "listings") {
                                                        echo "active";
                                                    } ?>" href="<?php echo $Web->admin_url() . '/view-seller/?id=' . $user_id; ?>&tab=listings">Listings</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link  <?php if ($tab === "orders") {
                                                        echo "active";
                                                    } ?>" href="<?php echo $Web->admin_url() . '/view-seller/?id=' . $user_id; ?>&tab=orders">Orders</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link  <?php if ($tab === "transactions") {
                                                        echo "active";
                                                    } ?>" href="<?php echo $Web->admin_url() . '/view-seller/?id=' . $user_id; ?>&tab=transactions">Transactions</a>
                            </li>
                        </ul>

                        <?php
                        switch ($tab) {
                            case "listings":
                                $listingStatus = $_GET["status"] ?? "active";
                                require_once "partials/listings.php";
                                break;
                            case "orders":
                                $orderStatus = $_GET["status"] ?? "success";
                                require_once "partials/orders.php";
                                break;
                            case "transactions":
                                require_once "partials/transactions.php";
                                break;
                            default:
                                require_once "partials/main.php";
                                break;
                        }
                        ?>

                    </div>
                </div>
                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>
    </div>



    <div class="modal fade" id="statusModal" tabindex="-1" style="display: none;" aria-hidden="true">
        <div class="modal-dialog mw-650px">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 id="heading" class="fw-bolder"></h2>
                    <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                        <span class="svg-icon svg-icon-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                            </svg>
                        </span>
                    </div>
                </div>
                <div class="modal-body scroll-y">
                    <form default-validation novalidate class="no-validate">
                        <div class="fv-row mb-7">
                            <label class="required fs-6 fw-bold form-label mb-2">Describe Reason</label>
                            <textarea required rows="5" type="text" class="form-control" name="reason"></textarea>
                            <div class="invalid-feedback">Reason is required</div>
                        </div>

                        <div class="justify-right">
                            <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                            <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--  -->

    <?php include $Web->include("partials/scripts.php"); ?>

    <script>
        Admin.viewSeller.init();
    </script>

    <?php
    switch ($tab) {
        case "listings":
    ?><script src="<?php echo $Web->get_assets("js/datatables.bundle.js"); ?>"></script>
            <script>
                Admin.viewSeller.listings("<?php echo $listingStatus; ?>");
            </script>
        <?php
            break;
        case "orders":
        ?>
            <script src="<?php echo $Web->get_assets("js/datatables.bundle.js"); ?>"></script>
            <script>
                Admin.viewSeller.orders("<?php echo $orderStatus; ?>");
            </script>
        <?php
            break;
        case "transactions":
        ?><script src="<?php echo $Web->get_assets("js/datatables.bundle.js"); ?>"></script>
            <script>
                Admin.viewSeller.transactions();
            </script>
    <?php
            break;
    }
    ?>
    <script>
        setActiveNavItem("<?php echo $Web->admin_url(); ?>/sellers/list");
    </script>

</body>


</html>