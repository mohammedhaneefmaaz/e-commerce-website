<?php
require_once "../../db.php";
$Login->check_admin_login();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Support - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/admin/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <div class="card">
                            <div class="card-header">
                                <div class="card-title flex-column">
                                    <h3>Support</h3>
                                    <div class="text-muted fs-7"> List of ticket opened by customers </div>
                                </div>
                            </div>
                            <div class="card-body">
                                    <table id="loginSessionTbl" class="table align-middle table-row-dashed gy-5">
                                        <thead class="border-bottom border-gray-200 fs-7 fw-bolder">
                                            <tr class="text-muted text-uppercase gs-0">
                                                <th>#</th>
                                                <th class="min-w-150px">Customer</th>
                                                <th class="min-w-150px">Subject</th>
                                                <th class="min-w-50px">Status</th>
                                                <th class="min-w-200px mw-250px">Date Created</th>
                                                <th>View</th>
                                            </tr>
                                        </thead>
                                        <tbody class="fs-6 fw-bold text-gray-600">

                                        </tbody>
                                    </table>
                            </div>
                        </div>
                    </div>
                </div>
                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/datatables.bundle.js"); ?>"></script>

    <script>
        LXUtil.onDOMContentLoaded((function() {
            setActiveNavItem();
            Admin.Support.init();
        }));
    </script>
</body>

</html>