<?php

use Ecommerce\Layout;

require_once "../../db.php";
$Login->check_admin_login();

$data = "";
$page_id = "HOME";


if (!Layout::is_page_id($page_id)) {
    Layout::create_new_layout("HOME");
}

$id = Layout::get_id_by_page("HOME");
$Layout = new Layout($id);
$components_layout = $Layout->components_layout();


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Home Page Layout- <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/admin/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">


                        <div id="pageComponents" class="d-flex flex-column gap-2 gap-lg-4">
                            <?php echo $components_layout; ?>
                        </div>

                        <div data-bs-toggle="modal" data-bs-target="#chooseComponentModal" class="mt-4 bg-white cursor-pointer border border-dashed border-2 border-warning justify-align-center p-6">
                            <div class="text-warning justify-align-center fw-bolder">
                                <span class="svg-icon svg-icon-warning svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="11" y="18" width="12" height="2" rx="1" transform="rotate(-90 11 18)" fill="black"></rect>
                                        <rect x="6" y="11" width="12" height="2" rx="1" fill="black"></rect>
                                    </svg>
                                </span>
                                Add A Component
                            </div>
                        </div>

                    </div>
                </div>
                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>

        <!-- Modals -->

        <div class="modal fade" id="chooseComponentModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered mw-400px">

                <div class="card pointer-auto w-100 min-h-400px rounded-4">
                    <div class="modal-header">
                        <h2>Choose Component</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-active-light-primary btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div id="content">
                        <div data-choose="slider" class="p-4 hover cursor-pointer category-list border-bottom align-justify-between">
                            <div class="fs-4 d-flex fw-bold">Slider</div>
                            <span class="svg-icon svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z" fill="black"></path>
                                </svg>
                            </span>
                        </div>
                        <div data-choose="manual_slider" class="p-4 hover cursor-pointer category-list border-bottom align-justify-between">
                            <div class="fs-4 d-flex fw-bold">Manual Slider</div>
                            <span class="svg-icon svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z" fill="black"></path>
                                </svg>
                            </span>
                        </div>
                        <div data-choose="banner" class="p-4 hover cursor-pointer category-list border-bottom align-justify-between">
                            <div class="fs-4 d-flex fw-bold">Banner</div>
                            <span class="svg-icon svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z" fill="black"></path>
                                </svg>
                            </span>
                        </div>
                        <div data-choose="product_slider" class="p-4 hover cursor-pointer category-list border-bottom align-justify-between">
                            <div class="fs-4 d-flex fw-bold">Product Slider</div>
                            <span class="svg-icon svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z" fill="black"></path>
                                </svg>
                            </span>
                        </div>
                        <div data-choose="category" class="p-4 hover cursor-pointer category-list border-bottom align-justify-between">
                            <div class="fs-4 d-flex fw-bold">Category</div>
                            <span class="svg-icon svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z" fill="black"></path>
                                </svg>
                            </span>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- Modals -->
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/jquery-ui.js"); ?>"></script>
    <script>
        setActiveNavItem(location.pathname);
        Admin.Layouts.create("<?php echo $id; ?>");
    </script>
</body>


</html>