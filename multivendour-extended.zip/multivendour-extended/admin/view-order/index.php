<?php
require_once "../../db.php";
$Login->check_admin_login();

use Ecommerce\_Order;
use Ecommerce\Courier;

if (!isset($_GET["id"])) Errors::response_404();
$order_id = $_GET["id"];
if (!_Order::is_order_id($order_id)) Errors::response_404();
$Order = new _Order($order_id);

if ($Order->has_returned_requested()) {
    $Return = $Order->return_order();
    $return_id = $Return->return_id;
}

if ($Order->has_replacement_requested()) {
    $Replacement = $Order->replacement_order();
    $replacement_id = $Replacement->replacement_id;
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Order #<?php echo $order_id; ?> - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-1" id="lx_wrapper">

                <?php include $Web->include("partials/admin/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <?php
                        if (isset($Return)) {
                        ?>
                            <div class="mb-4 justify-right">
                                <?php
                                if ($Return->status_code() == "1") {
                                ?>
                                    <button data-bs-toggle="modal" data-bs-target="#rejectModal" class="btn btn-danger me-4">Reject</button>
                                    <button data-bs-toggle="modal" data-bs-target="#acceptModal" class="btn btn-success me-4">Accept</button>
                                <?php }
                                if ($Return->status_code() == "3") {
                                ?>
                                    <button data-bs-toggle="modal" data-bs-target="#rejectModal" class="btn btn-danger me-4">Reject</button>
                                    <button data-bs-toggle="modal" data-bs-target="#scheduleModal" class="btn btn-warning me-4">Schedule Pickup</button>
                                <?php }
                                if ($Return->status_code() == "4") {
                                ?>
                                    <button data-bs-toggle="modal" data-bs-target="#rejectModal" class="btn btn-danger me-4">Reject</button>
                                    <button id="markCompleted" class="btn btn-warning me-4">Mark as completed</button>
                                <?php }
                                ?>
                            </div>
                        <?php
                        } else if (isset($Replacement)) {
                        ?>
                            <div class="mb-4 justify-right">
                                <?php
                                if ($Replacement->status_code() == "1") {
                                ?>
                                    <button data-bs-toggle="modal" data-bs-target="#rejectModal" class="btn btn-danger me-4">Reject</button>
                                    <button data-bs-toggle="modal" data-bs-target="#acceptModal" class="btn btn-success me-4">Accept</button>
                                <?php }
                                if ($Replacement->status_code() == "3") {
                                ?>
                                    <button data-bs-toggle="modal" data-bs-target="#rejectModal" class="btn btn-danger me-4">Reject</button>
                                    <button data-bs-toggle="modal" data-bs-target="#scheduleModal" class="btn btn-warning me-4">Schedule Pickup</button>
                                <?php }
                                if ($Replacement->status_code() == "4") {
                                ?>
                                    <button data-bs-toggle="modal" data-bs-target="#rejectModal" class="btn btn-danger me-4">Reject</button>
                                    <button data-bs-toggle="modal" data-bs-target="#refundReplacementModal" class="btn btn-primary me-4">Refund</button>
                                    <button id="markCompleted" class="btn btn-warning me-4">Mark as completed</button>
                                <?php }
                                ?>
                            </div>
                        <?php
                        }
                        ?>

                        <div class="justify-right">
                            <?php
                            if ($Order->refund_status() == "pending") {
                            ?>
                                <button data-bs-toggle="modal" data-bs-target="#refundModal" class="btn btn-success mb-4 me-4">Refund</button>
                            <?php }
                            if ($Order->status_step() == 6) { ?>
                                <button data-bs-toggle="modal" data-bs-target="#addTrackingModal" class="btn mb-4 btn-warning">Schedule Pickup</button>
                            <?php }
                            if ($Order->status_step() == 7) { ?>
                                <button id="markDelivered" class="btn mb-4 btn-warning">Mark as Delivered</button>
                            <?php }
                            if ($Order->status_step() == 11) { ?>
                                <button id="markAsShipped" class="btn mb-4 btn-warning">Mark as Shipped</button>
                            <?php }
                            if (($Order->status_step() > 3 && $Order->status_step() < 8) || $Order->status_step() == 11) {
                            ?>
                                <button data-bs-toggle="modal" data-bs-target="#rejectOrderModal" class="btn ms-4 mb-4 btn-danger">Reject Order</button>
                            <?php
                            }
                            ?>
                        </div>
                        <?php


                        if ($Order->is_replacement_order()) {
                        ?>
                            <div class="alert alert-success d-flex align-items-center mb-2 mb-lg-4 p-5">
                                <div class="d-flex flex-column">
                                    <h4 class="mb-1 text-success">This is a replacement order </h4>
                                    <span> Previous Order is <a href="<?php echo (new _Order($Order->original_order_id()))->admin_view_url(); ?>"> #<?php echo $Order->original_order_id(); ?> </a></span>
                                </div>
                            </div>
                        <?php
                        }

                        if ($Order->has_refunded()) {
                        ?>
                            <div class="alert mb-4 alert-success d-flex align-items-center p-5 mb-0">
                                <span class="svg-icon svg-icon-2hx svg-icon-success me-4">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z" fill="black"></path>
                                        <path d="M10.5606 11.3042L9.57283 10.3018C9.28174 10.0065 8.80522 10.0065 8.51412 10.3018C8.22897 10.5912 8.22897 11.0559 8.51412 11.3452L10.4182 13.2773C10.8099 13.6747 11.451 13.6747 11.8427 13.2773L15.4859 9.58051C15.771 9.29117 15.771 8.82648 15.4859 8.53714C15.1948 8.24176 14.7183 8.24176 14.4272 8.53714L11.7002 11.3042C11.3869 11.6221 10.874 11.6221 10.5606 11.3042Z" fill="black"></path>
                                    </svg>
                                </span>
                                <div class="d-flex flex-column">
                                    <h4 class="mb-1 text-success">Refund Completed on <?php echo $Order->refund_date(); ?></h4>
                                    <span><?php echo $Order->refund_comment(); ?></span>
                                </div>
                            </div>
                        <?php
                        }
                        if (isset($Replacement)) {
                        ?>

                            <div class="card card-flush mb-6">
                                <div class="card-header">
                                    <div class="card-title">
                                        <h2>Replacement #<?php echo $replacement_id; ?></h2>
                                    </div>
                                </div>
                                <div class="card-body pt-0">
                                    <div class="d-flex mb-4">
                                        <div class="fs-5 fw-bold">Buyer Response:</div>
                                        <div class="pre-wrap ms-4 text-gray-600 fs-5 "><?php echo $Replacement->replacement_reason(); ?></div>
                                    </div>
                                    <div class="d-flex">
                                        <div class="fs-5 fw-bold"> Attachments:</div>
                                        <div class="pre-wrap ms-4 text-gray-600 fs-5 "><?php echo $Replacement->attachments(); ?></div>
                                    </div>
                                </div>
                            </div>


                            <?php
                            if ($Replacement->status() === "completed") { ?>
                                <div class="alert alert-success d-flex align-items-center mb-2 mb-lg-4 p-5 mt-2">
                                    <span class="svg-icon svg-icon-2hx svg-icon-success me-4">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path opacity="0.3" d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z" fill="black"></path>
                                            <path d="M10.5606 11.3042L9.57283 10.3018C9.28174 10.0065 8.80522 10.0065 8.51412 10.3018C8.22897 10.5912 8.22897 11.0559 8.51412 11.3452L10.4182 13.2773C10.8099 13.6747 11.451 13.6747 11.8427 13.2773L15.4859 9.58051C15.771 9.29117 15.771 8.82648 15.4859 8.53714C15.1948 8.24176 14.7183 8.24176 14.4272 8.53714L11.7002 11.3042C11.3869 11.6221 10.874 11.6221 10.5606 11.3042Z" fill="black"></path>
                                        </svg>
                                    </span>
                                    <div class="d-flex flex-column">
                                        <h4 class="mb-1 text-success">This replacement has been completed on <?php echo $Replacement->completed_date(); ?></h4>
                                        <?php if (!empty($Replacement->refund_reason())) {
                                        ?>
                                            <span class="text-danger">We are sorry we can't provide you a replacement due to unavailability so we are providing a refund.</span>
                                            <div>Admin Comment: <span class="text-info pre"> <?php echo $Replacement->refund_reason(); ?></span></div>
                                        <?php
                                        } else {
                                        ?> <span> Replacement Order Id is <a href="<?php echo $Replacement->newOrder()->admin_view_url(); ?>">#<?php echo $Replacement->newOrder()->order_id; ?></a></span>
                                        <?php
                                        } ?>
                                    </div>
                                </div>
                            <?php
                            }
                        }
                        if (isset($Return)) {
                            ?>
                            <div class="card card-flush mb-6">
                                <div class="card-header">
                                    <div class="card-title">
                                        <h2>Return #<?php echo $return_id; ?></h2>
                                    </div>
                                </div>
                                <div class="card-body pt-0">
                                    <div class="d-flex mb-4">
                                        <div class="fs-5 fw-bold">Buyer Response:</div>
                                        <div class="pre-wrap ms-4 text-gray-600 fs-5 "><?php echo $Return->return_reason(); ?></div>
                                    </div>
                                    <div class="d-flex">
                                        <div class="fs-5 fw-bold"> Attachments:</div>
                                        <div class="pre-wrap ms-4 text-gray-600 fs-5 "><?php echo $Return->attachments(); ?></div>
                                    </div>
                                </div>
                            </div>
                        <?php
                        }
                        ?>

                        <div class="d-flex flex-column gap-7">

                            <div class="d-flex flex-column flex-xl-row gap-7">
                                <div class="card card-flush py-4 flex-1">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2>Order Details (#<?php echo $order_id; ?>)</h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div class="table-responsive">
                                            <table class="table border-light align-middle table-row-bordered mb-0 fs-6 gy-5 ">
                                                <tbody class="fw-bold text-gray-600">
                                                    <tr>
                                                        <td class="text-muted">
                                                            <div class="d-flex align-items-center">
                                                                <span class="svg-icon svg-icon-2 me-2">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                                                                        <path opacity="0.3" d="M19 3.40002C18.4 3.40002 18 3.80002 18 4.40002V8.40002H14V4.40002C14 3.80002 13.6 3.40002 13 3.40002C12.4 3.40002 12 3.80002 12 4.40002V8.40002H8V4.40002C8 3.80002 7.6 3.40002 7 3.40002C6.4 3.40002 6 3.80002 6 4.40002V8.40002H2V4.40002C2 3.80002 1.6 3.40002 1 3.40002C0.4 3.40002 0 3.80002 0 4.40002V19.4C0 20 0.4 20.4 1 20.4H19C19.6 20.4 20 20 20 19.4V4.40002C20 3.80002 19.6 3.40002 19 3.40002ZM18 10.4V13.4H14V10.4H18ZM12 10.4V13.4H8V10.4H12ZM12 15.4V18.4H8V15.4H12ZM6 10.4V13.4H2V10.4H6ZM2 15.4H6V18.4H2V15.4ZM14 18.4V15.4H18V18.4H14Z" fill="black"></path>
                                                                        <path d="M19 0.400024H1C0.4 0.400024 0 0.800024 0 1.40002V4.40002C0 5.00002 0.4 5.40002 1 5.40002H19C19.6 5.40002 20 5.00002 20 4.40002V1.40002C20 0.800024 19.6 0.400024 19 0.400024Z" fill="black"></path>
                                                                    </svg>
                                                                </span>
                                                                Date Ordered
                                                            </div>
                                                        </td>
                                                        <td class="fw-bolder text-end"><?php echo $Order->order_date(); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted">
                                                            <div class="d-flex align-items-center">
                                                                <span class="svg-icon svg-icon-2 me-2">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                        <path opacity="0.3" d="M3.20001 5.91897L16.9 3.01895C17.4 2.91895 18 3.219 18.1 3.819L19.2 9.01895L3.20001 5.91897Z" fill="black"></path>
                                                                        <path opacity="0.3" d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21C21.6 10.9189 22 11.3189 22 11.9189V15.9189C22 16.5189 21.6 16.9189 21 16.9189H16C14.3 16.9189 13 15.6189 13 13.9189ZM16 12.4189C15.2 12.4189 14.5 13.1189 14.5 13.9189C14.5 14.7189 15.2 15.4189 16 15.4189C16.8 15.4189 17.5 14.7189 17.5 13.9189C17.5 13.1189 16.8 12.4189 16 12.4189Z" fill="black"></path>
                                                                        <path d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21V7.91895C21 6.81895 20.1 5.91895 19 5.91895H3C2.4 5.91895 2 6.31895 2 6.91895V20.9189C2 21.5189 2.4 21.9189 3 21.9189H19C20.1 21.9189 21 21.0189 21 19.9189V16.9189H16C14.3 16.9189 13 15.6189 13 13.9189Z" fill="black"></path>
                                                                    </svg>
                                                                </span>
                                                                Payment Method
                                                            </div>
                                                        </td>
                                                        <td class="fw-bolder text-end">
                                                            <?php echo $Order->payment_method(); ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted">
                                                            <div class="d-flex align-items-center">
                                                                <span class="svg-icon svg-icon-2 me-2">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                        <path opacity="0.3" d="M5 8.04999L11.8 11.95V19.85L5 15.85V8.04999Z" fill="black"></path>
                                                                        <path d="M20.1 6.65L12.3 2.15C12 1.95 11.6 1.95 11.3 2.15L3.5 6.65C3.2 6.85 3 7.15 3 7.45V16.45C3 16.75 3.2 17.15 3.5 17.25L11.3 21.75C11.5 21.85 11.6 21.85 11.8 21.85C12 21.85 12.1 21.85 12.3 21.75L20.1 17.25C20.4 17.05 20.6 16.75 20.6 16.45V7.45C20.6 7.15 20.4 6.75 20.1 6.65ZM5 15.85V7.95L11.8 4.05L18.6 7.95L11.8 11.95V19.85L5 15.85Z" fill="black"></path>
                                                                    </svg>
                                                                </span>
                                                                Order Status
                                                            </div>
                                                        </td>
                                                        <td class="fw-bolder text-end"><?php echo $Order->status_label(); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted">
                                                            <div class="d-flex align-items-center">
                                                                <span class="svg-icon svg-icon-2 me-2">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                        <path opacity="0.3" d="M3.20001 5.91897L16.9 3.01895C17.4 2.91895 18 3.219 18.1 3.819L19.2 9.01895L3.20001 5.91897Z" fill="black"></path>
                                                                        <path opacity="0.3" d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21C21.6 10.9189 22 11.3189 22 11.9189V15.9189C22 16.5189 21.6 16.9189 21 16.9189H16C14.3 16.9189 13 15.6189 13 13.9189ZM16 12.4189C15.2 12.4189 14.5 13.1189 14.5 13.9189C14.5 14.7189 15.2 15.4189 16 15.4189C16.8 15.4189 17.5 14.7189 17.5 13.9189C17.5 13.1189 16.8 12.4189 16 12.4189Z" fill="black"></path>
                                                                        <path d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21V7.91895C21 6.81895 20.1 5.91895 19 5.91895H3C2.4 5.91895 2 6.31895 2 6.91895V20.9189C2 21.5189 2.4 21.9189 3 21.9189H19C20.1 21.9189 21 21.0189 21 19.9189V16.9189H16C14.3 16.9189 13 15.6189 13 13.9189Z" fill="black"></path>
                                                                    </svg>
                                                                </span>
                                                                Payment:
                                                            </div>
                                                        </td>
                                                        <td class="fw-bolder text-end"><?php echo $Order->payment_status_label(); ?></td>
                                                    </tr>
                                                    <?php if (isset($Return)) {
                                                    ?>
                                                        <tr>
                                                            <td class="text-muted">
                                                                <div class="d-flex align-items-center">
                                                                    <span class="svg-icon svg-icon-2 me-2">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                            <path opacity="0.3" d="M5 8.04999L11.8 11.95V19.85L5 15.85V8.04999Z" fill="black"></path>
                                                                            <path d="M20.1 6.65L12.3 2.15C12 1.95 11.6 1.95 11.3 2.15L3.5 6.65C3.2 6.85 3 7.15 3 7.45V16.45C3 16.75 3.2 17.15 3.5 17.25L11.3 21.75C11.5 21.85 11.6 21.85 11.8 21.85C12 21.85 12.1 21.85 12.3 21.75L20.1 17.25C20.4 17.05 20.6 16.75 20.6 16.45V7.45C20.6 7.15 20.4 6.75 20.1 6.65ZM5 15.85V7.95L11.8 4.05L18.6 7.95L11.8 11.95V19.85L5 15.85Z" fill="black"></path>
                                                                        </svg>
                                                                    </span>
                                                                    Return Status
                                                                </div>
                                                            </td>
                                                            <td class="fw-bolder text-end"><?php echo $Return->status_label(); ?></td>
                                                        </tr>
                                                    <?php
                                                    }
                                                    if (isset($Replacement)) {
                                                    ?>
                                                        <td class="text-muted">
                                                            <div class="d-flex align-items-center">
                                                                <span class="svg-icon svg-icon-2 me-2">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                        <path opacity="0.3" d="M5 8.04999L11.8 11.95V19.85L5 15.85V8.04999Z" fill="black"></path>
                                                                        <path d="M20.1 6.65L12.3 2.15C12 1.95 11.6 1.95 11.3 2.15L3.5 6.65C3.2 6.85 3 7.15 3 7.45V16.45C3 16.75 3.2 17.15 3.5 17.25L11.3 21.75C11.5 21.85 11.6 21.85 11.8 21.85C12 21.85 12.1 21.85 12.3 21.75L20.1 17.25C20.4 17.05 20.6 16.75 20.6 16.45V7.45C20.6 7.15 20.4 6.75 20.1 6.65ZM5 15.85V7.95L11.8 4.05L18.6 7.95L11.8 11.95V19.85L5 15.85Z" fill="black"></path>
                                                                    </svg>
                                                                </span>
                                                                Replacement Status
                                                            </div>
                                                        </td>
                                                        <td class="fw-bolder text-end"><?php echo $Replacement->status_label(); ?></td>
                                                        </tr>
                                                    <?php
                                                    } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                                <div class="card card-flush pb-4 flex-1">
                                    <div class="position-absolute top-0 end-0 opacity-10 pe-none text-end">
                                        <svg class="w-175px h-175px" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M20 8H16C15.4 8 15 8.4 15 9V16H10V17C10 17.6 10.4 18 11 18H16C16 16.9 16.9 16 18 16C19.1 16 20 16.9 20 18H21C21.6 18 22 17.6 22 17V13L20 8Z" fill="black" />
                                            <path opacity="0.3" d="M20 18C20 19.1 19.1 20 18 20C16.9 20 16 19.1 16 18C16 16.9 16.9 16 18 16C19.1 16 20 16.9 20 18ZM15 4C15 3.4 14.6 3 14 3H3C2.4 3 2 3.4 2 4V13C2 13.6 2.4 14 3 14H15V4ZM6 16C4.9 16 4 16.9 4 18C4 19.1 4.9 20 6 20C7.1 20 8 19.1 8 18C8 16.9 7.1 16 6 16Z" fill="black" />
                                        </svg>
                                    </div>
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2>Pickup Address</h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <?php echo $Order->pickup_address(); ?>
                                    </div>
                                </div>

                            </div>

                            <div class="d-flex flex-column gap-7">
                                <div class="d-flex flex-column flex-xl-row gap-7">
                                    <div class="flex-1">

                                        <div class="card card-flush py-4 min-w-xl-500px flex-1">
                                            <div class="position-absolute top-0 end-0 opacity-10 pe-none text-end">

                                                <svg class="w-175px h-175px" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M20 8H16C15.4 8 15 8.4 15 9V16H10V17C10 17.6 10.4 18 11 18H16C16 16.9 16.9 16 18 16C19.1 16 20 16.9 20 18H21C21.6 18 22 17.6 22 17V13L20 8Z" fill="black" />
                                                    <path opacity="0.3" d="M20 18C20 19.1 19.1 20 18 20C16.9 20 16 19.1 16 18C16 16.9 16.9 16 18 16C19.1 16 20 16.9 20 18ZM15 4C15 3.4 14.6 3 14 3H3C2.4 3 2 3.4 2 4V13C2 13.6 2.4 14 3 14H15V4ZM6 16C4.9 16 4 16.9 4 18C4 19.1 4.9 20 6 20C7.1 20 8 19.1 8 18C8 16.9 7.1 16 6 16Z" fill="black" />
                                                </svg>
                                            </div>
                                            <div class="card-header">
                                                <div class="card-title">
                                                    <h2>Shipping Address</h2>
                                                </div>
                                            </div>
                                            <div class="card-body pt-0">
                                                <?php echo $Order->address_card(); ?>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="flex-1">
                                        <div class="card card-flush py-4">
                                            <div class="card-header">
                                                <div class="card-title">
                                                    <h2>Shipping Details</h2>
                                                </div>
                                            </div>
                                            <div class="card-body pt-0">
                                                <?php if (!empty($Order->shipping())) { ?>
                                                    <div class="table-responsive">
                                                        <table class="table border-light align-middle table-row-bordered mb-0 fs-6 gy-5 min-w-300px">
                                                            <tbody class="fw-bold text-gray-600">
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="d-flex space-nowrap  align-items-center">
                                                                            <span class="svg-icon svg-icon-2 me-2">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                                    <path opacity="0.3" d="M22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2C17.5 2 22 6.5 22 12ZM12 7C10.3 7 9 8.3 9 10C9 11.7 10.3 13 12 13C13.7 13 15 11.7 15 10C15 8.3 13.7 7 12 7Z" fill="black"></path>
                                                                                    <path d="M12 22C14.6 22 17 21 18.7 19.4C17.9 16.9 15.2 15 12 15C8.8 15 6.09999 16.9 5.29999 19.4C6.99999 21 9.4 22 12 22Z" fill="black"></path>
                                                                                </svg>
                                                                            </span>
                                                                            Tracking ID
                                                                        </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a><?php echo $Order->shipping()->tracking_id; ?></a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="d-flex space-nowrap  align-items-center">
                                                                            <span class="svg-icon svg-icon-2 me-2">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                                    <path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19Z" fill="black"></path>
                                                                                    <path d="M21 5H2.99999C2.69999 5 2.49999 5.10005 2.29999 5.30005L11.2 13.3C11.7 13.7 12.4 13.7 12.8 13.3L21.7 5.30005C21.5 5.10005 21.3 5 21 5Z" fill="black"></path>
                                                                                </svg>
                                                                            </span>
                                                                            Courier Service
                                                                        </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a target="_blank" class="text-primary" href="<?php echo $Order->shipping()->courier_service_url; ?>" class="text-gray-600 text-hover-primary"><?php echo $Order->shipping()->courier_service; ?></a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="d-flex">
                                                                            <span class="svg-icon svg-icon-2 me-2">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                                    <path d="M5 20H19V21C19 21.6 18.6 22 18 22H6C5.4 22 5 21.6 5 21V20ZM19 3C19 2.4 18.6 2 18 2H6C5.4 2 5 2.4 5 3V4H19V3Z" fill="black"></path>
                                                                                    <path opacity="0.3" d="M19 4H5V20H19V4Z" fill="black"></path>
                                                                                </svg>
                                                                            </span>
                                                                            Comment
                                                                        </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <div data-clamp="3" class="pre-wrap line-clamp line-clamp-3  overflow-true"><?php echo $Order->shipping()->comment; ?></div>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                <?php } else {
                                                    echo '<h1 class="text-muted">NA</h1>';
                                                } ?>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="flex-1">
                                    <div class="card card-flush py-4 overflow-hidden">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>Events</h2>
                                            </div>
                                        </div>
                                        <div class="card-body pt-0">
                                            <div class="table-responsive">
                                                <table class="table border-light  table-row-bordered align-middle mb-0 fs-6 gy-5 min-w-300px">
                                                    <tbody class="fw-bold text-gray-600">
                                                        <tr>
                                                            <td class="text-muted">
                                                                <div class="w-content d-flex align-items-center"> Order On: </div>
                                                            </td>
                                                            <td class="fw-bolder text-end">
                                                                <a> <?php echo $Order->order_date(); ?> </a>
                                                            </td>
                                                        </tr>

                                                        <?php if (!empty($Order->labelled_on())) { ?>
                                                            <tr>
                                                                <td class="text-muted">
                                                                    <div class="w-content d-flex align-items-center"> Labelled On: </div>
                                                                </td>
                                                                <td class="fw-bolder text-end">
                                                                    <a> <?php echo $Order->labelled_on(); ?> </a>
                                                                </td>
                                                            </tr>
                                                        <?php } ?>

                                                        <?php if (!empty($Order->rtd_on())) { ?>
                                                            <tr>
                                                                <td class="text-muted">
                                                                    <div class="w-content d-flex align-items-center"> RTD On: </div>
                                                                </td>
                                                                <td class="fw-bolder text-end">
                                                                    <a> <?php echo $Order->rtd_on(); ?> </a>
                                                                </td>
                                                            </tr>
                                                        <?php } ?>
                                                        <?php if (!empty($Order->pickup_scheduled_on())) { ?>
                                                            <tr>
                                                                <td class="text-muted">
                                                                    <div class="w-content d-flex align-items-center"> Pickup Scheduled On: </div>
                                                                </td>
                                                                <td class="fw-bolder text-end">
                                                                    <a> <?php echo $Order->pickup_scheduled_on(); ?> </a>
                                                                </td>
                                                            </tr>
                                                        <?php } ?>

                                                        <?php if (!empty($Order->shipped_on())) { ?>
                                                            <tr>
                                                                <td class="text-muted">
                                                                    <div class="w-content d-flex align-items-center"> Shipped On: </div>
                                                                </td>
                                                                <td class="fw-bolder text-end">
                                                                    <a> <?php echo $Order->shipped_on(); ?> </a>
                                                                </td>
                                                            </tr>
                                                        <?php } ?>

                                                        <?php if (!empty($Order->delivered_on())) { ?>
                                                            <tr>
                                                                <td class="text-muted">
                                                                    <div class="w-content d-flex align-items-center"> Delivered On: </div>
                                                                </td>
                                                                <td class="fw-bolder text-end">
                                                                    <a> <?php echo $Order->delivered_on(); ?> </a>
                                                                </td>
                                                            </tr>
                                                        <?php } ?>

                                                        <?php if ($Order->status_step() == 2) { ?>
                                                            <tr>
                                                                <td class="text-muted">
                                                                    <div class="w-content d-flex align-items-center"> Cancelled On: </div>
                                                                </td>
                                                                <td class="fw-bolder text-end">
                                                                    <a> <?php echo $Order->cancelled_on(); ?> </a>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="text-muted">
                                                                    <div class="w-content d-flex align-items-center"> Cancelled Reason: </div>
                                                                </td>
                                                                <td class="fw-bolder text-end">
                                                                    <a data-clamp="3" class="overflow-true line-clamp line-clamp-3  pre-wrap"> <?php echo $Order->cancelled_reason(); ?> </a>
                                                                </td>
                                                            </tr>
                                                        <?php } ?>

                                                        <?php if ($Order->status_step() == 3) { ?>
                                                            <tr>
                                                                <td class="text-muted">
                                                                    <div class="w-content d-flex align-items-center"> Rejected On: </div>
                                                                </td>
                                                                <td class="fw-bolder text-end">
                                                                    <a> <?php echo $Order->rejected_on(); ?> </a>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="text-muted">
                                                                    <div class="w-content d-flex align-items-center"> Rejected Reason: </div>
                                                                </td>
                                                                <td class="fw-bolder text-end">
                                                                    <a data-clamp="3" class="overflow-true line-clamp line-clamp-3  pre-wrap"> <?php echo $Order->rejected_reason(); ?> </a>
                                                                </td>
                                                            </tr>
                                                        <?php }
                                                        if (isset($Return)) {
                                                        ?>
                                                            <tr>
                                                                <td class="text-muted">
                                                                    <div class="w-content d-flex align-items-center"> Return Requested On: </div>
                                                                </td>
                                                                <td class="fw-bolder text-end">
                                                                    <a> <?php echo $Return->requested_date(); ?> </a>
                                                                </td>
                                                            </tr>

                                                            <?php
                                                            if ($Return->accepted_on()) { ?>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center"> Return Accepted On: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a> <?php echo $Return->accepted_on(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center"> Accepted Comment: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a class="word-break"> <?php echo empty($Return->processed_comment()) ? "NA" : $Return->processed_comment(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                            <?php }
                                                            if ($Return->status_code() == '0') { ?>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center"> Return Cancelled On: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a> <?php echo $Return->cancelled_date(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                            <?php }
                                                            if ($Return->status_code() == "2") {
                                                            ?>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center"> Return Rejected On: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a> <?php echo $Return->rejected_on(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center">Return Rejected Reason: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a class="word-break"> <?php echo $Return->processed_comment(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                            <?php
                                                            }
                                                            if (!empty($Return->pickup_scheduled_date())) { ?>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center"> Pickup Scheduled On: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a> <?php echo $Return->pickup_scheduled_date(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center"> Pickup Schedule Comment: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a class="word-break"> <?php echo $Return->pickup_scheduled_comment(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                            <?php }
                                                            if ($Return->status_code() == "5") { ?>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center"> Return Completed On: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a> <?php echo $Return->completed_date(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                            <?php }
                                                        }
                                                        if (isset($Replacement)) {
                                                            ?>
                                                            <tr>
                                                                <td class="text-muted">
                                                                    <div class="w-content d-flex align-items-center"> Replacement Requested On: </div>
                                                                </td>
                                                                <td class="fw-bolder text-end">
                                                                    <a> <?php echo $Replacement->requested_date(); ?> </a>
                                                                </td>
                                                            </tr>

                                                            <?php
                                                            if (!empty($Replacement->accepted_on())) { ?>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center"> Replacement Accepted On: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a> <?php echo $Replacement->accepted_on(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center"> Accepted Comment: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a class="word-break"> <?php echo empty($Replacement->processed_comment()) ? "NA" : $Replacement->processed_comment(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                            <?php }
                                                            if ($Replacement->status_code() == '0') { ?>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center"> Replacement Cancelled On: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a> <?php echo $Replacement->cancelled_date(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                            <?php }
                                                            if (!empty($Replacement->pickup_scheduled_date())) { ?>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center"> Pickup Scheduled On: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a> <?php echo $Replacement->pickup_scheduled_date(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center"> Pickup Schedule Comment: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a class="word-break"> <?php echo $Replacement->pickup_scheduled_comment(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                            <?php }
                                                            if ($Replacement->status_code() == "2") { ?>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center"> Replacement Rejected On: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a> <?php echo $Replacement->rejected_on(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center">Replacement Rejected Reason: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a class="word-break"> <?php echo $Replacement->processed_comment(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                            <?php }
                                                            if ($Replacement->status_code() == "5") { ?>
                                                                <tr>
                                                                    <td class="text-muted">
                                                                        <div class="w-content d-flex align-items-center"> Replacement Completed On: </div>
                                                                    </td>
                                                                    <td class="fw-bolder text-end">
                                                                        <a> <?php echo $Replacement->completed_date(); ?> </a>
                                                                    </td>
                                                                </tr>
                                                        <?php }
                                                        }
                                                        ?>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="card card-flush py-4 flex-1 overflow-hidden">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2>Order #<?php echo $order_id; ?></h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div class="table-responsive">
                                            <table class="table border-light align-middle table-row-dashed fs-6 gy-5 mb-0">
                                                <thead>
                                                    <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                                        <th class="min-w-175px">Product</th>
                                                        <th class="min-w-100px text-end">SKU</th>
                                                        <th class="min-w-70px text-end">Qty</th>
                                                        <th class="min-w-100px text-end">Unit Price</th>
                                                        <th class="min-w-100px text-end">Total</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="fw-bold text-gray-600">
                                                    <tr>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <a target="_blank" class="tbl-product-img" href="<?php echo $Order->product()->url($Order->variation_id(), $Order->svariation_id()); ?>">
                                                                    <img src="<?php echo $Order->product()->image($Order->variation_id(), $Order->svariation_id()); ?>">
                                                                </a>
                                                                <div class="ms-5">
                                                                    <a target="_blank" href="<?php echo $Order->product()->url($Order->variation_id(), $Order->svariation_id()); ?>" class="fw-bolder text-gray-600 text-hover-primary"><?php echo $Order->product()->product_name($Order->variation_id(), $Order->svariation_id()); ?></a>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td class="text-end"><a><?php echo $Order->product()->sku_id($Order->variation_id(), $Order->svariation_id()); ?></a> </td>
                                                        <td class="text-end"><?php echo $Order->quantity(); ?></td>
                                                        <td class="text-end"><?php echo $Order->price_text(); ?></td>
                                                        <td class="text-end"><?php echo $Order->total_price_text(); ?></td>
                                                    </tr>
                                                    <?php echo $Order->tbl_charges_details(); ?>
                                                    <tr>
                                                        <td colspan="4" class="fs-3 text-dark text-end">Grand Total</td>
                                                        <td class="text-dark fs-3 fw-boldest text-end"><?php echo $Order->grand_total_text(); ?></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                                <?php if (isset($Replacement) && !empty($Replacement->refund_reason())) {
                                ?>
                                    <div class="card card-flush py-4 mb-6 flex-1 overflow-hidden">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>Replacement Order #<?php echo $Order->replacement_order_id(); ?></h2>
                                            </div>
                                        </div>
                                        <div class="card-body pt-0">
                                            <div class="table-responsive">
                                                <table class="table border-light align-middle table-row-dashed fs-6 gy-5 mb-0">
                                                    <thead>
                                                        <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                                            <th class="min-w-175px">Product</th>
                                                            <th class="min-w-100px text-end">SKU</th>
                                                            <th class="min-w-70px text-end">Qty</th>
                                                            <th class="min-w-100px text-end">Unit Price</th>
                                                            <th class="min-w-100px text-end">Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="fw-bold text-gray-600">
                                                        <tr>
                                                            <td>
                                                                <div class="d-flex align-items-center">
                                                                    <a target="_blank" class="tbl-product-img" href="<?php echo $Order->product()->url($Order->variation_id(), $Order->svariation_id()); ?>">
                                                                        <img src="<?php echo $Order->product()->image($Order->variation_id(), $Order->svariation_id()); ?>">
                                                                    </a>
                                                                    <div class="ms-5">
                                                                        <a target="_blank" href="<?php echo $Order->product()->url($Order->variation_id(), $Order->svariation_id()); ?>" class="fw-bolder text-gray-600 text-hover-primary"><?php echo $Order->product()->product_name($Order->variation_id(), $Order->svariation_id()); ?></a>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td class="text-end"><a><?php echo $Order->product()->sku_id($Order->variation_id(), $Order->svariation_id()); ?></a> </td>
                                                            <td class="text-end"><?php echo $Order->quantity(); ?></td>
                                                            <td class="text-end"><?php echo $Order->price_text(); ?></td>
                                                            <td class="text-end"><?php echo $Order->total_price_text(); ?></td>
                                                        </tr>

                                                        <?php echo $Replacement->tbl_charges_details(); ?>

                                                        <tr>
                                                            <td colspan="4" class="fs-3 text-dark text-end">Grand Total</td>
                                                            <td class="text-dark fs-3 fw-boldest text-end"> - <?php echo $Replacement->final_price_text(); ?></td>
                                                        </tr>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                <?php
                                } ?>

                                <?php if (isset($Return) && in_array($Return->status_code(), [4, 5])) {
                                ?>

                                    <div class="card card-flush py-4 flex-1 overflow-hidden">
                                        <div class="card-header">
                                            <div class="card-title">
                                                <h2>Return Order <a>#<?php echo $Order->return_order_id(); ?></a></h2>
                                            </div>
                                        </div>
                                        <div class="card-body pt-0">
                                            <div class="table-responsive">
                                                <table class="table border-light align-middle table-row-dashed fs-6 gy-5 mb-0">
                                                    <thead>
                                                        <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                                            <th class="min-w-175px">Product</th>
                                                            <th class="min-w-100px text-end">SKU</th>
                                                            <th class="min-w-70px text-end">Qty</th>
                                                            <th class="min-w-100px text-end">Unit Price</th>
                                                            <th class="min-w-100px text-end">Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="fw-bold text-gray-600">
                                                        <tr>
                                                            <td>
                                                                <div class="d-flex align-items-center">
                                                                    <a target="_blank" class="tbl-product-img" href="<?php echo $Order->product()->url($Order->variation_id(), $Order->svariation_id()); ?>">
                                                                        <img src="<?php echo $Order->product()->image($Order->variation_id(), $Order->svariation_id()); ?>">
                                                                    </a>
                                                                    <div class="ms-5">
                                                                        <a target="_blank" href="<?php echo $Order->product()->url($Order->variation_id(), $Order->svariation_id()); ?>" class="fw-bolder text-gray-600 text-hover-primary"><?php echo $Order->product()->product_name($Order->variation_id(), $Order->svariation_id()); ?></a>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td class="text-end"><a><?php echo $Order->product()->sku_id($Order->variation_id(), $Order->svariation_id()); ?></a> </td>
                                                            <td class="text-end"><?php echo $Order->quantity(); ?></td>
                                                            <td class="text-end"><?php echo $Order->price_text(); ?></td>
                                                            <td class="text-end"><?php echo $Order->total_price_text(); ?></td>
                                                        </tr>

                                                        <?php echo $Return->tbl_charges_details(); ?>

                                                        <tr>
                                                            <td colspan="4" class="fs-3 text-dark text-end">Grand Total</td>
                                                            <td class="text-dark fs-3 fw-boldest text-end"> - <?php echo $Return->final_price_text(); ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                <?php
                                } ?>

                            </div>

                        </div>


                    </div>
                </div>

                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>


        <div class="modal fade" id="addTrackingModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Add Tracking ID</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y">
                        <form novalidate="" class="">
                            <div class="fv-row mb-7">
                                <label class="required form-label mb-2"> Tracking ID </label>
                                <input maxlength="100" autocomplete="off" name="tracking_id" type="text" class="form-control form-control-solid" required></input>
                                <div class="invalid-feedback"> Tracking ID is required</div>
                            </div>
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2"> Courier Service</label>
                                <select name="courier_service" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" class="form-select form-select-solid">
                                    <option value=""></option>
                                    <?php echo Courier::list(); ?>
                                </select>
                                <div class="invalid-feedback"> Courier Service is required</div>
                            </div>
                            <div class="fv-row mb-7">
                                <label class="required form-label mb-2"> Courier Charge </label>
                                <div class="input-group mb-5">
                                    <span class="input-group-text"><?php echo $Web->currency(); ?></span>
                                    <input autocomplete="off" name="courier_charge" type="text" class="form-control form-control-solid" required></input>
                                </div>
                                <div class="invalid-feedback">Courier Charge is required</div>
                            </div>
                            <div class="fv-row mb-7">
                                <label class="required form-label mb-2">Comment</label>
                                <textarea maxlength="3000" rows="5" class="form-control form-control-solid" required name="courier_comment"></textarea>
                                <div class="invalid-feedback">Comment is required</div>
                            </div>

                            <div class="justify-right">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="refundModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Refund Order</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y">
                        <form novalidate="" class="">
                            <div id="orders_id"></div>
                            <div class="fv-row mb-7">
                                <label class="form-label required mb-2"> Comment</label>
                                <textarea required maxlength="3000" rows="5" type="text" class="form-control" placeholder="" name="comment"></textarea>
                                <div class="invalid-feedback">Comment is required</div>
                            </div>

                            <div class="justify-right">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="rejectOrderModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Reject Order</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y">
                        <form novalidate="" class="">
                            <div class="fv-row mb-7">
                                <label class="required form-label mb-2"> Reason For Rejection</label>
                                <textarea maxlength="3000" rows="5" type="text" class="form-control form-control-solid" required name="reason"></textarea>
                                <div class="invalid-feedback">Reason For Rejection is required</div>
                            </div>

                            <div class="justify-right">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <?php
        if (isset($Return)) {
        ?>

            <div class="modal fade" id="rejectModal" tabindex="-1" style="display: none;" aria-hidden="true">
                <div class="modal-dialog mw-650px">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="fw-bolder">Reject Return</h2>
                            <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                    </svg>
                                </span>
                            </div>
                        </div>
                        <div class="modal-body scroll-y">
                            <form novalidate="" class="">
                                <div id="orders_id"></div>
                                <div class="fv-row mb-7">
                                    <label class="required form-label mb-2"> Reason For Rejection</label>
                                    <textarea maxlength="3000" rows="5" type="text" class="form-control" required name="reason"></textarea>
                                </div>

                                <div class="justify-right">
                                    <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                    <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="acceptModal" tabindex="-1" style="display: none;" aria-hidden="true">
                <div class="modal-dialog mw-650px">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="fw-bolder">Accept Return</h2>
                            <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                    </svg>
                                </span>
                            </div>
                        </div>
                        <div class="modal-body scroll-y">
                            <form novalidate="" class="">
                                <div id="orders_id"></div>
                                <div class="fv-row mb-7">
                                    <label class="form-label mb-2"> Comment</label>
                                    <textarea maxlength="3000" rows="5" type="text" class="form-control" placeholder="optional" name="comment"></textarea>
                                </div>

                                <div class="justify-right">
                                    <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                    <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="scheduleModal" tabindex="-1" style="display: none;" aria-hidden="true">
                <div class="modal-dialog mw-650px">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="fw-bolder">Schedule Pickup</h2>
                            <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                    </svg>
                                </span>
                            </div>
                        </div>
                        <div class="modal-body scroll-y">
                            <form novalidate="" class="">

                                <div class="fv-row mb-7">
                                    <label class="required form-label mb-2"> Return Id</label>
                                    <input value="<?php echo $Order->return_order_id(); ?>" readonly rows="5" type="text" class="form-control" required name="return_id"></input>
                                </div>


                                <div class="fv-row mb-7">
                                    <label class="required form-label mb-2"> Return Shipping Charge</label>
                                    <div class="input-group mb-5">
                                        <span class="input-group-text" id="basic-addon1"><?php echo $Web->currency(); ?></span>
                                        <input data-mask="integer" autocomplete="off" name="return_shipping_charge" type="text" class="form-control" required></input>
                                    </div>
                                    <div class="invalid-feedback">Return Shipping Charge is required</div>
                                </div>

                                <div class="fv-row mb-7">
                                    <label class="required form-label mb-2"> Comment</label>
                                    <textarea maxlength="3000" rows="5" type="text" class="form-control" required name="comment"></textarea>
                                    <div class="invalid-feedback">Comment is required</div>
                                </div>

                                <div class="justify-right">
                                    <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                    <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        }
        if (isset($Replacement)) { ?>

            <div class="modal fade" id="refundReplacementModal" tabindex="-1" style="display: none;" aria-hidden="true">
                <div class="modal-dialog mw-650px">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="fw-bolder">Refund Replacement Order</h2>
                            <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                    </svg>
                                </span>
                            </div>
                        </div>
                        <div class="modal-body scroll-y">
                            <form novalidate="" class="">
                                <div id="orders_id"></div>
                                <div class="fv-row mb-7">
                                    <label class="form-label required mb-2"> Comment</label>
                                    <textarea required maxlength="3000" rows="5" type="text" class="form-control" placeholder="" name="comment"></textarea>
                                    <div class="invalid-feedback">Comment is required</div>
                                </div>

                                <div class="justify-right">
                                    <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                    <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="rejectModal" tabindex="-1" style="display: none;" aria-hidden="true">
                <div class="modal-dialog mw-650px">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="fw-bolder">Reject Replacement</h2>
                            <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                    </svg>
                                </span>
                            </div>
                        </div>
                        <div class="modal-body scroll-y">
                            <form novalidate="" class="">
                                <div id="orders_id"></div>
                                <div class="fv-row mb-7">
                                    <label class="required form-label mb-2"> Reason For Rejection</label>
                                    <textarea maxlength="3000" rows="5" type="text" class="form-control" required name="reason"></textarea>
                                    <div class="invalid-feedback">Reason is required</div>
                                </div>

                                <div class="justify-right">
                                    <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                    <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="acceptModal" tabindex="-1" style="display: none;" aria-hidden="true">
                <div class="modal-dialog mw-650px">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="fw-bolder">Accept Replacement</h2>
                            <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                    </svg>
                                </span>
                            </div>
                        </div>
                        <div class="modal-body scroll-y">
                            <form novalidate="" class="">
                                <div class="fv-row mb-7">
                                    <label class="form-label mb-2"> Comment</label>
                                    <textarea maxlength="3000" rows="5" type="text" class="form-control" placeholder="optional" name="comment"></textarea>
                                </div>

                                <div class="justify-right">
                                    <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                    <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="scheduleModal" tabindex="-1" style="display: none;" aria-hidden="true">
                <div class="modal-dialog mw-650px">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="fw-bolder">Schedule Pickup</h2>
                            <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                    </svg>
                                </span>
                            </div>
                        </div>
                        <div class="modal-body scroll-y">
                            <form novalidate="" class="">

                                <div class="fv-row mb-7">
                                    <label class="required form-label mb-2"> Replacement Id</label>
                                    <input readonly value="<?php echo $Order->replacement_order_id(); ?>" type="text" class="form-control" required name="replacement_id"></input>
                                </div>

                                <div class="fv-row mb-7">
                                    <label class="required form-label mb-2"> Return Shipping Charge</label>
                                    <div class="input-group mb-5">
                                        <span class="input-group-text" id="basic-addon1"><?php echo $Web->currency(); ?></span>
                                        <input data-mask="integer" autocomplete="off" name="return_shipping_charge" type="text" class="form-control" required></input>
                                    </div>
                                    <div class="invalid-feedback">Return Shipping Charge is required</div>
                                </div>

                                <div class="fv-row mb-7">
                                    <label class="required form-label mb-2"> Comment</label>
                                    <textarea maxlength="3000" rows="5" type="text" class="form-control" required name="comment"></textarea>
                                    <div class="invalid-feedback">Comment is required</div>
                                </div>

                                <div class="justify-right">
                                    <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                    <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        <?php }
        ?>


    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script>
        setActiveNavItem("<?php echo $Web->admin_url(); ?>/orders/handover");
        Admin.ViewOrder("<?php echo $order_id; ?>");
    </script>

    <?php
    if (isset($Replacement)) { ?>
        <script>
            Admin.ReplacementOrders().proceed("<?php echo $order_id; ?>");
        </script>
    <?php }
    if (isset($Return)) {
    ?>
        <script>
            Admin.ReturnOrders().proceed("<?php echo $order_id; ?>");
        </script>
    <?php
    } ?>

</body>


</html>