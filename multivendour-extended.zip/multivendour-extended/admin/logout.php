<?php
require_once("../db.php");
if (!$Login->is_admin_loggedin()) {
    $Web->locate_to($Web->admin_url());
}
$session_id = $Web->sanitize_text($_COOKIE['_asession_id']);
$stmt = $db->prepare("UPDATE $Web->login_session_tbl SET status = 'expired' WHERE session_id = ? ");
$query = $stmt->execute([$session_id]);
if ($query) {
    setcookie('_asession_id', '', time() - (86400 * 30), '/');
    $Web->locate_to($Web->admin_url());
} else {
    Errors::response("Error in logout");
}
