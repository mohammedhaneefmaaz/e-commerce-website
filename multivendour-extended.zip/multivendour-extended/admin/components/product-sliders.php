<?php

require_once "../../db.php";
$Login->check_admin_login();

use Ecommerce\HomePageSetting;
use Ecommerce\Component;

$HomePageSetting = new HomePageSetting();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Product Sliders - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/admin/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <div class="flex-row-fluid" id="lx_content">
                            <div class="card card-flush">
                                <div class="card-header align-items-center py-5 gap-2 gap-md-5">
                                    <div class="card-title">
                                        <h2>Product Sliders</h2>
                                    </div>
                                    <div class="card-toolbar">
                                        <a data-bs-toggle="modal" data-bs-target="#addSliderModal" class="btn btn-sm btn-flex btn-light-primary">
                                            <span class="svg-icon svg-icon-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5" fill="black"></rect>
                                                    <rect x="10.8891" y="17.8033" width="12" height="2" rx="1" transform="rotate(-90 10.8891 17.8033)" fill="black"></rect>
                                                    <rect x="6.01041" y="10.9247" width="12" height="2" rx="1" fill="black"></rect>
                                                </svg>
                                            </span>
                                            Add a new
                                        </a>

                                    </div>
                                </div>
                                <div class="card-body pt-0">
                                    <div class="table-responsive">
                                        <table class="table align-middle table-row-dashed fs-6 gy-5" id="jobs_table">
                                            <thead>
                                                <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                                    <th class="min-w-50px">#</th>
                                                    <th class="min-w-200px">Heading</th>
                                                    <th class="min-w-200px">Sory By</th>
                                                    <th class="min-w-150px">Status</th>
                                                    <th class="min-w-150px">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody id="sliderData" class="fw-bold text-gray-600">
                                                <?php echo Component::product_sliders_tbl(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>

        <!-- Modals -->

        <div class="modal fade" id="categoryModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered mw-400px">

                <div class="card pointer-auto w-100 min-h-400px rounded-4">
                    <div class="modal-header">
                        <h2>Choose Category</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-active-light-primary btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div id="content">
                        <?php echo Ecommerce\HomePageSetting::choose_categories(); ?>
                    </div>
                </div>

            </div>
        </div>

        <div class="modal fade" id="addSliderModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Add Product Slider</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-active-light-primary btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y">

                        <form id="sliderForm" novalidate class="need-validation">
                            <input type="hidden" name="event" value="create">

                            <div class="fv-row mb-7">
                                <label class="form-label required mb-2">Heading</label>
                                <input required type="text" class="form-control form-control-solid" name="heading">
                                <div class="invalid-feedback">Heading is required</div>
                            </div>

                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2"> Category</label>
                                <select name="category" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" type="text" class="form-select form-select-solid">
                                    <option></option>
                                    <option value="all">All</option>
                                    <option value="choose">Choose</option>
                                </select>
                                <div class="invalid-feedback">Category is required</div>
                            </div>


                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Sort By</label>
                                <select name="sort_by" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" type="text" class="form-select form-select-solid">
                                    <option></option>
                                    <option value="sells">Sells</option>
                                    <option value="latest">Latest</option>
                                    <option value="price_asc">Price: Low To High</option>
                                    <option value="price_desc">Price: High To Low</option>
                                    <option value="discount">Discount</option>
                                    <option value="rating">Rating</option>
                                    <option value="view">View</option>
                                    <option value="random">Random</option>
                                </select>
                                <div class="invalid-feedback">Status is required</div>
                            </div>

                            <div class="fv-row mb-7">
                                <label class="form-label required mb-2">Total Columns<i data-bs-toggle="tooltip" data-bs-original-title="Total number of cards to load in slider" class="fas text-muted fa-exclamation-circle ms-1 fs-7"></i></label>
                                <input data-mask="integer" required type="text" class="form-control form-control-solid" name="total_columns">
                                <div class="invalid-feedback">Total Columns is required</div>
                            </div>

                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2"> Status</label>
                                <select name="status" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" type="text" class="form-select form-select-solid">
                                    <option></option>
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                                <div class="invalid-feedback">Status is required</div>
                            </div>

                            <div class="justify-right">
                                <button type=submit class="btn btn-primary">Create
                                    <span class="svg-icon svg-icon-2">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black"></rect>
                                            <path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black"></path>
                                        </svg>
                                    </span>
                                </button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="updateSliderModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Update Product Slider</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-active-light-primary btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y">

                    </div>
                </div>
            </div>
        </div>

        <!--  -->
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script>
        setActiveNavItem(location.pathname);
        Admin.Setting.productSliders.init();
    </script>
</body>


</html>