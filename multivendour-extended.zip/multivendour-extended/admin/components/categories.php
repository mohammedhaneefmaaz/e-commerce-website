<?php

require_once "../../db.php";
$Login->check_admin_login();

use Ecommerce\HomePageSetting;
use Ecommerce\Component;

$HomePageSetting = new HomePageSetting();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Categories - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">
                <?php include $Web->include("partials/admin/header.php"); ?>
                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <div class="justify-right mb-2 mb-lg-4">
                            <button type="button" id="addCollection" class="btn btn-flex btn-light-orange">
                                <span class="svg-icon svg-icon-3">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5" fill="black"></rect>
                                        <rect x="10.8891" y="17.8033" width="12" height="2" rx="1" transform="rotate(-90 10.8891 17.8033)" fill="black"></rect>
                                        <rect x="6.01041" y="10.9247" width="12" height="2" rx="1" fill="black"></rect>
                                    </svg>
                                </span>
                                Add new collection
                            </button>
                        </div>

                        <div class="d-flex flex-column gap-2 gap-lg-4" id="collections">
                            <?php echo Component::categories_collections_tbl(); ?>
                        </div>

                    </div>
                </div>
                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>

        <!-- Modals -->

        <div class="modal fade" id="updateCollectionDetails" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Update Details</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-active-light-primary btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y">
                        <form novalidate="">
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Heading</label>
                                <input maxlength="100" required="" type="text" class="form-control" name="heading" value=""></input>
                                <div class="invalid-feedback">Heading is required</div>
                            </div>
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Columns</label>
                                <input data-mask="integer" maxlength="1" required="" type="text" class="form-control" name="columns" value=""></input>
                                <div class="invalid-feedback">Columns is required</div>
                            </div>
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Columns in Tab</label>
                                <input data-mask="integer" maxlength="1" required="" type="text" class="form-control" name="tab_columns" value=""></input>
                                <div class="invalid-feedback">Tab Columns is required</div>
                            </div>
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Columns in Mobile</label>
                                <input data-mask="integer" maxlength="1" required="" type="text" class="form-control" name="mobile_columns" value=""></input>
                                <div class="invalid-feedback">Mobile Columns is required</div>
                            </div>
                            <div class="justify-right">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button autocomplete="off" type="submit" id="submit" class="btn btn-primary">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="addCategoryModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Add a category</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-active-light-primary btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y">
                        <form novalidate class="need-validation">
                            <input type="hidden" name="event" value="create">
                            <div class="fv-row mb-7">
                                <label class="required form-label mb-2">Image</label>
                                <div id="uploadCard" class="position-relative border border-dashed border-primary border-2 cursor-pointer justify-align-center mb-2 bg-light min-h-200px">
                                    <div class="bottom-inherit image-upload-progress top-0">
                                        <div class="progress-bar h-3px"></div>
                                    </div>
                                    <div class="justify-align-center flex-column" id="innerContent">
                                        <span class="svg-icon svg-icon-muted svg-icon-5x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="black"></path>
                                                <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="black"></path>
                                            </svg>
                                        </span>
                                        <div class="text-gray-600">Upload Image</div>
                                    </div>
                                </div>
                                <input autocomplete="off" class="sr-only" required name="image_id" value="">
                                <div class="invalid-feedback">Please upload a image</div>
                            </div>
                            <div class="fv-row mb-7">
                                <label class="form-label mb-2">Category Name</label>
                                <input required autocomplete="off" type="text" class="form-control form-control-solid" name="category_name" value="">
                                <div class="invalid-feedback">Category Name is required</div>
                            </div>
                            <div class="fv-row mb-7">
                                <label class="form-label mb-2">Url</label>
                                <input autocomplete="off" type="text" class="form-control form-control-solid" name="url" value="">
                            </div>
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2"> Status</label>
                                <select autocomplete="off" name="status" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" value="" type="text" class="form-select form-select-solid">
                                    <option value=""></option>
                                    <option selected value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                                <div class="invalid-feedback">Status is required</div>
                            </div>
                            <div class="justify-right">
                                <button type=submit class="btn btn-primary">Create
                                    <span class="svg-icon svg-icon-2">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black"></rect>
                                            <path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black"></path>
                                        </svg>
                                    </span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="updateCategoryModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Update Category</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-active-light-primary btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y">

                    </div>
                </div>
            </div>
        </div>

        <!--  -->
    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script>
        setActiveNavItem(location.pathname);
        Admin.Setting.Category.init();
    </script>
</body>


</html>