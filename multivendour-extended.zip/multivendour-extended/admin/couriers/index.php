<?php
require_once "../../db.php";
$Login->check_admin_login();

use Ecommerce\Courier;


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Couriers - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/admin/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div class="post d-flex flex-column-fluid" id="lx_post">
                        <div id="lx_content_container" class="container-xxl">


                            <div class="flex-row-fluid" id="lx_content">
                                <div class="card card-flush">
                                    <div class="card-header align-items-center py-5 gap-2 gap-md-5">
                                        <div class="card-title">
                                            <h2>Couriers</h2>
                                        </div>
                                        <div class="card-toolbar">
                                            <a data-bs-toggle="modal" data-bs-target="#addCourier" class="btn btn-primary">Add Courier</a>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div class="table-responsive">
                                            <table class="table align-middle table-row-dashed fs-6 gy-5" id="jobs_table">
                                                <thead>
                                                    <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                                        <th class="min-w-50px">#</th>
                                                        <th class="min-w-200px">Courier Name</th>
                                                        <th class="min-w-150px">Courier Url</th>
                                                        <th class="min-w-150px">Date Created</th>
                                                        <th class="min-w-150px">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="data" class="fw-bold text-gray-600">
                                                    <?php echo Courier::tbl(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>

        <div class="modal fade" id="addCourier" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Add a courier</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y">
                        <form novalidate >
                            <div class="fv-row mb-7">
                                <label class="required form-label mb-2">Courier Name</label>
                                <input required maxlength="100" rows="5" type="text" class="form-control form-control-solid" name="name" value="">
                                <div class="invalid-feedback">Courier Name is required</div>
                            </div>

                            <div class="fv-row mb-7">
                                <label class="required form-label mb-2">Courier Url</label>
                                <input required maxlength="1000" rows="5" type="text" class="form-control form-control-solid" name="url" value="">
                                <div class="invalid-feedback">Courier Url is required</div>
                            </div>

                            <div class="justify-right">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="editCourier" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Edit courier</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y">

                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script>
        setActiveNavItem();
        Admin.Courier.init();
    </script>



</body>


</html>