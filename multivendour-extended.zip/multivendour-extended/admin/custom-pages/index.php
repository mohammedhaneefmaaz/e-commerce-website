<?php

use Ecommerce\Layout;

require_once "../../db.php";
$Login->check_admin_login();


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Custom Pages - <?php echo $Web->web_name(); ?> </title>
    <?php include $Web->include("partials/meta.php"); ?>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/admin/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div class="post d-flex flex-column-fluid" id="lx_post">
                        <div id="lx_content_container" class="container-xxl">


                            <div class="flex-row-fluid" id="lx_content">
                                <div class="card card-flush">
                                    <div class="card-header align-items-center py-5 gap-2 gap-md-5">
                                        <div class="card-title">
                                            <h2>Custom Pages</h2>
                                        </div>
                                        <div class="card-toolbar">
                                        <a data-bs-toggle="modal" data-bs-target="#createCustomPage" class="btn btn-flex btn-light-primary">
                                            <span class="svg-icon svg-icon-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5" fill="black"></rect>
                                                    <rect x="10.8891" y="17.8033" width="12" height="2" rx="1" transform="rotate(-90 10.8891 17.8033)" fill="black"></rect>
                                                    <rect x="6.01041" y="10.9247" width="12" height="2" rx="1" fill="black"></rect>
                                                </svg>
                                            </span>
                                            Add new page
                                        </a>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div class="table-responsive">
                                            <table class="table align-middle table-row-dashed fs-6 gy-5" id="jobs_table">
                                                <thead>
                                                    <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                                        <th class="min-w-50px">#</th>
                                                        <th class="min-w-200px">Name</th>
                                                        <th class="min-w-150px">Url</th>
                                                        <th class="min-w-150px">Status</th>
                                                        <th class="min-w-150px">Date Created</th>
                                                        <th class="min-w-150px">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="fw-bold text-gray-600">
                                                    <?php echo Layout::pages_tbl_except_home(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <?php include $Web->include("partials/admin/footer.php"); ?>
            </div>
        </div>

        <div class="modal fade" id="createCustomPage" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Create page</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y">
                        <form novalidate>
                            <div class="fv-row mb-7">
                                <label class="required form-label mb-2">Page Name</label>
                                <input required maxlength="100" type="text" class="form-control form-control-solid" name="name" value="">
                                <div class="invalid-feedback">Page Name is required</div>
                            </div>
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2"> Status</label>
                                <select autocomplete="off" name="status" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" value="" type="text" class="form-select form-select-solid">
                                    <option value=""></option>
                                    <option selected value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                                <div class="invalid-feedback">Status is required</div>
                            </div>
                            <div class="justify-right">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="updatePageModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Update Page</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y">
                    <form novalidate>
                            <div class="fv-row mb-7">
                                <label class="required form-label mb-2">Page Name</label>
                                <input required maxlength="100" type="text" class="form-control form-control-solid" name="name" value="">
                                <div class="invalid-feedback">Page Name is required</div>
                            </div>
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2"> Status</label>
                                <select autocomplete="off" name="status" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" value="" type="text" class="form-select form-select-solid">
                                    <option value=""></option>
                                    <option selected value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                                <div class="invalid-feedback">Status is required</div>
                            </div>
                            <div class="justify-right">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script>
        setActiveNavItem();
        Admin.CustomPages.init();
    </script>



</body>


</html>