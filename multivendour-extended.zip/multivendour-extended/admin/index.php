<?php

require_once "../db.php";
$Web->locate_to($Web->admin_url().'/dashboard/');
?>