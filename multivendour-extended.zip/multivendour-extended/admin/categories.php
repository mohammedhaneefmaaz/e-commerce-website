<?php
require_once "../db.php";
$Login->check_admin_login();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Ecommerce Categories - <?php echo $Web->web_name(); ?></title>
    <?php include $Web->include("partials/meta.php"); ?> <script>
        // window.onbeforeunload = function(e) {
        //     return "Are you sure you want to leave this page?  You will lose any unsaved data.";
        // };
    </script>
</head>

<body id="lx_body" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed" style="--lx-toolbar-height:55px;--lx-toolbar-height-tablet-and-mobile:55px">
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">
            <?php include $Web->include("partials/admin/aside.php"); ?>
            <div class="wrapper d-flex flex-column flex-row-fluid" id="lx_wrapper">

                <?php include $Web->include("partials/admin/header.php"); ?>

                <div class="content d-flex flex-column flex-column-fluid" id="lx_content">
                    <div id="lx_content_container" class="container-xxl">

                        <div class="card card-flush">
                            <div class="card-header">
                                <div class="card-title">
                                    <h2>Categories</h2>
                                </div>
                                <div class="card-toolbar">
                                    <button id="apply_changes" class="btn btn-success">Apply Changes</button>
                                </div>
                            </div>
                            <div class="card-body pt-0">
                                <div class="category-group">
                                    <?php echo Ecommerce\Category::all_lists(); ?>
                                </div>
                            </div>
                        </div>

                        <div id="updateDataWrapper">

                        </div>

                    </div>
                </div>

                <?php include $Web->include("partials/admin/footer.php"); ?>


            </div>
        </div>

        <div class="modal fade" id="variationModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Create Variation</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                        <form class="needs-validation" default-validation novalidate id="add_detail">
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Variation Name</label>
                                <input required type="text" class="form-control form-control-solid" name="name" value="">
                                <input type="hidden" class="form-control form-control-solid" name="custom_select_id" value="">
                                <div class="invalid-feedback">Variation Name is required</div>
                            </div>

                            <div class="fv-row mb-7">
                                <label class="required fs-6 form-label mb-2">Variation Type</label>
                                <select required class="form-select form-select-solid" name="type" data-control="select2" data-placeholder="Select an option" data-hide-search="true">
                                    <option></option>
                                    <option value="input">Input (custom text) </option>
                                    <option value="select">Select (dropdown) </option>
                                    <option value="image">Image (choose image) </option>
                                </select>
                                <div class="invalid-feedback">Variation Type is required</div>
                            </div>

                            <div id="detailIdWrapper" class="fv-row d1-none mb-7">
                                <label class="fs-6 fw-bold form-label mb-2">Detail Id
                                    <i data-bs-toggle="tooltip" data-bs-original-title="To use image value first create it value in product details below" class="fas fa-exclamation-circle ms-2 fs-7"></i>
                                </label>
                                <select class="form-select form-select-solid" name="detail_id" data-control="select2" data-placeholder="Select an option">
                                    <option></option>
                                </select>
                            </div>

                            <div id="selectIdWrapper" class="d1-none">
                                <div class="fv-row mb-7">
                                    <label class="required fs-6 fw-bold form-label mb-2">Select (dropdown) value</label>
                                    <select id="selectLibrary" class="form-select form-select-solid" name="select_id" data-control="select2" data-placeholder="Select an option to copy value">
                                        <option></option>
                                    </select>
                                </div>
                                <div id="customSelectWrapper"></div>
                                <div id="selectPreview"></div>
                            </div>

                            <div class="fv-row mb-7">
                                <label class="required fs-6 form-label mb-2">Role Type</label>
                                <select required class="form-select form-select-solid" name="role" data-control="select2" data-placeholder="Select an option " data-hide-search="true">
                                    <option></option>
                                    <option value="parent">Parent</option>
                                    <option value="child">Child</option>
                                </select>
                                <div class="invalid-feedback">Role Type is required</div>
                            </div>

                            <div class="text-center">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="editVariationModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Edit Variation</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">

                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="addDetailsModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Add detail</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                        <form class="needs-validation" default-validation novalidate id="add_detail">
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Mandatory</label> <input type="hidden" class="form-control form-control-solid" name="custom_select_id" value="">
                                <select value="yes" required class="form-select form-select-solid" name="mandatory" data-control="select2" data-placeholder="Select an option" data-hide-search="true" tabindex="-1" aria-hidden="true">
                                    <option></option>
                                    <option value="yes">Yes</option>
                                    <option value="no">No</option>
                                </select>
                                <div class="invalid-feedback">This field is required</div>
                            </div>

                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Label</label>
                                <input required type="text" class="form-control form-control-solid" name="option_text" value="" placeholder="color, pack of, size, pattern">
                                <div class="invalid-feedback">Label is required</div>
                            </div>

                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Label Type</label>
                                <select required class="form-select form-select-solid" name="option_type" data-control="select2" data-placeholder="Select an option" data-hide-search="true" tabindex="-1" aria-hidden="true">
                                    <option></option>
                                    <option value="input">Input</option>
                                    <option value="select">Select</option>
                                </select>
                                <div class="invalid-feedback">Label Type is required</div>
                            </div>


                            <div id="selectIdWrapper" class="d1-none">
                                <div class="fv-row mb-7">
                                    <label class="required fs-6 fw-bold form-label mb-2">Select (dropdown) value</label>
                                    <select id="detailSelectLibrary" class="form-select form-select-solid" name="select_id" data-control="select2" data-placeholder="Select an option to copy value">
                                        <option></option>
                                    </select>
                                </div>
                                <div id="customSelectWrapper"></div>
                                <div id="selectPreview"></div>
                            </div>

                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Filter<i data-bs-toggle="tooltip" data-bs-original-title="Filter option during product search" class="fas fa-exclamation-circle ms-2 fs-7"></i></label>
                                <select value="no" required class="form-select form-select-solid" name="filter" data-control="select2" data-placeholder="Select an option" data-hide-search="true" tabindex="-1" aria-hidden="true">
                                    <option></option>
                                    <option value="yes">Yes</option>
                                    <option value="no">No</option>
                                </select>
                                <div class="invalid-feedback">Filter is required</div>
                            </div>

                            <div class="text-center">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>
                            <div></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="editDetailsModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Edit detail</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">

                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="addSelectLibraryModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog mw-650px">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="fw-bolder">Create Custom Select</h2>
                        <div data-bs-dismiss="modal" class="btn btn-icon btn-sm btn-active-icon-primary">
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">



                    </div>
                </div>
            </div>
        </div>


    </div>
    <?php include $Web->include("partials/scripts.php"); ?>
    <script src="<?php echo $Web->get_assets("js/formrepeater.js"); ?>"></script>
    <script>
        LXUtil.onDOMContentLoaded((function() {
            setActiveNavItem(location.pathname);
            Admin.Category();
        }));
    </script>

</body>


</html>