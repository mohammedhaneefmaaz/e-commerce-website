
!function (e, t) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : (e = "undefined" != typeof globalThis ? globalThis : e || self).ApexCharts = t()
}(this, (function () {
    "use strict";

    function e(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var i = Object.getOwnPropertySymbols(e);
            t && (i = i.filter((function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable
            }))), n.push.apply(n, i)
        }
        return n
    }

    function t(t) {
        for (var n = 1; n < arguments.length; n++) {
            var i = null != arguments[n] ? arguments[n] : {};
            n % 2 ? e(Object(i), !0).forEach((function (e) {
                s(t, e, i[e])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i)) : e(Object(i)).forEach((function (e) {
                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(i, e))
            }))
        }
        return t
    }

    function n(e) {
        return (n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (e) {
            return typeof e
        } : function (e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function i(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function a(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
        }
    }

    function r(e, t, n) {
        return t && a(e.prototype, t), n && a(e, n), e
    }

    function s(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function o(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
        e.prototype = Object.create(t && t.prototype, {
            constructor: {
                value: e,
                writable: !0,
                configurable: !0
            }
        }), t && c(e, t)
    }

    function l(e) {
        return (l = Object.setPrototypeOf ? Object.getPrototypeOf : function (e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function c(e, t) {
        return (c = Object.setPrototypeOf || function (e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }

    function u(e, t) {
        if (t && ("object" == typeof t || "function" == typeof t)) return t;
        if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
        return function (e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        }(e)
    }

    function d(e) {
        var t = function () {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function () {}))), !0
            } catch (e) {
                return !1
            }
        }();
        return function () {
            var n, i = l(e);
            if (t) {
                var a = l(this).constructor;
                n = Reflect.construct(i, arguments, a)
            } else n = i.apply(this, arguments);
            return u(this, n)
        }
    }

    function h(e) {
        return function (e) {
            if (Array.isArray(e)) return f(e)
        }(e) || function (e) {
            if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
        }(e) || function (e, t) {
            if (e) {
                if ("string" == typeof e) return f(e, t);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? f(e, t) : void 0
            }
        }(e) || function () {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function f(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, i = new Array(t); n < t; n++) i[n] = e[n];
        return i
    }
    var p = function () {
            function e() {
                i(this, e)
            }
            return r(e, [{
                key: "shadeRGBColor",
                value: function (e, t) {
                    var n = t.split(","),
                        i = e < 0 ? 0 : 255,
                        a = e < 0 ? -1 * e : e,
                        r = parseInt(n[0].slice(4), 10),
                        s = parseInt(n[1], 10),
                        o = parseInt(n[2], 10);
                    return "rgb(" + (Math.round((i - r) * a) + r) + "," + (Math.round((i - s) * a) + s) + "," + (Math.round((i - o) * a) + o) + ")"
                }
            }, {
                key: "shadeHexColor",
                value: function (e, t) {
                    var n = parseInt(t.slice(1), 16),
                        i = e < 0 ? 0 : 255,
                        a = e < 0 ? -1 * e : e,
                        r = n >> 16,
                        s = n >> 8 & 255,
                        o = 255 & n;
                    return "#" + (16777216 + 65536 * (Math.round((i - r) * a) + r) + 256 * (Math.round((i - s) * a) + s) + (Math.round((i - o) * a) + o)).toString(16).slice(1)
                }
            }, {
                key: "shadeColor",
                value: function (t, n) {
                    return e.isColorHex(n) ? this.shadeHexColor(t, n) : this.shadeRGBColor(t, n)
                }
            }], [{
                key: "bind",
                value: function (e, t) {
                    return function () {
                        return e.apply(t, arguments)
                    }
                }
            }, {
                key: "isObject",
                value: function (e) {
                    return e && "object" === n(e) && !Array.isArray(e) && null != e
                }
            }, {
                key: "is",
                value: function (e, t) {
                    return Object.prototype.toString.call(t) === "[object " + e + "]"
                }
            }, {
                key: "listToArray",
                value: function (e) {
                    var t, n = [];
                    for (t = 0; t < e.length; t++) n[t] = e[t];
                    return n
                }
            }, {
                key: "extend",
                value: function (e, t) {
                    var n = this;
                    "function" != typeof Object.assign && (Object.assign = function (e) {
                        if (null == e) throw new TypeError("Cannot convert undefined or null to object");
                        for (var t = Object(e), n = 1; n < arguments.length; n++) {
                            var i = arguments[n];
                            if (null != i)
                                for (var a in i) i.hasOwnProperty(a) && (t[a] = i[a])
                        }
                        return t
                    });
                    var i = Object.assign({}, e);
                    return this.isObject(e) && this.isObject(t) && Object.keys(t).forEach((function (a) {
                        n.isObject(t[a]) && a in e ? i[a] = n.extend(e[a], t[a]) : Object.assign(i, s({}, a, t[a]))
                    })), i
                }
            }, {
                key: "extendArray",
                value: function (t, n) {
                    var i = [];
                    return t.map((function (t) {
                        i.push(e.extend(n, t))
                    })), i
                }
            }, {
                key: "monthMod",
                value: function (e) {
                    return e % 12
                }
            }, {
                key: "clone",
                value: function (t) {
                    if (e.is("Array", t)) {
                        for (var i = [], a = 0; a < t.length; a++) i[a] = this.clone(t[a]);
                        return i
                    }
                    if (e.is("Null", t)) return null;
                    if (e.is("Date", t)) return t;
                    if ("object" === n(t)) {
                        var r = {};
                        for (var s in t) t.hasOwnProperty(s) && (r[s] = this.clone(t[s]));
                        return r
                    }
                    return t
                }
            }, {
                key: "log10",
                value: function (e) {
                    return Math.log(e) / Math.LN10
                }
            }, {
                key: "roundToBase10",
                value: function (e) {
                    return Math.pow(10, Math.floor(Math.log10(e)))
                }
            }, {
                key: "roundToBase",
                value: function (e, t) {
                    return Math.pow(t, Math.floor(Math.log(e) / Math.log(t)))
                }
            }, {
                key: "parseNumber",
                value: function (e) {
                    return null === e ? e : parseFloat(e)
                }
            }, {
                key: "randomId",
                value: function () {
                    return (Math.random() + 1).toString(36).substring(4)
                }
            }, {
                key: "noExponents",
                value: function (e) {
                    var t = String(e).split(/[eE]/);
                    if (1 === t.length) return t[0];
                    var n = "",
                        i = e < 0 ? "-" : "",
                        a = t[0].replace(".", ""),
                        r = Number(t[1]) + 1;
                    if (r < 0) {
                        for (n = i + "0."; r++;) n += "0";
                        return n + a.replace(/^-/, "")
                    }
                    for (r -= a.length; r--;) n += "0";
                    return a + n
                }
            }, {
                key: "getDimensions",
                value: function (e) {
                    var t = getComputedStyle(e, null),
                        n = e.clientHeight,
                        i = e.clientWidth;
                    return n -= parseFloat(t.paddingTop) + parseFloat(t.paddingBottom), [i -= parseFloat(t.paddingLeft) + parseFloat(t.paddingRight), n]
                }
            }, {
                key: "getBoundingClientRect",
                value: function (e) {
                    var t = e.getBoundingClientRect();
                    return {
                        top: t.top,
                        right: t.right,
                        bottom: t.bottom,
                        left: t.left,
                        width: e.clientWidth,
                        height: e.clientHeight,
                        x: t.left,
                        y: t.top
                    }
                }
            }, {
                key: "getLargestStringFromArr",
                value: function (e) {
                    return e.reduce((function (e, t) {
                        return Array.isArray(t) && (t = t.reduce((function (e, t) {
                            return e.length > t.length ? e : t
                        }))), e.length > t.length ? e : t
                    }), 0)
                }
            }, {
                key: "hexToRgba",
                value: function () {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "#999999",
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : .6;
                    "#" !== e.substring(0, 1) && (e = "#999999");
                    var n = e.replace("#", "");
                    n = n.match(new RegExp("(.{" + n.length / 3 + "})", "g"));
                    for (var i = 0; i < n.length; i++) n[i] = parseInt(1 === n[i].length ? n[i] + n[i] : n[i], 16);
                    return void 0 !== t && n.push(t), "rgba(" + n.join(",") + ")"
                }
            }, {
                key: "getOpacityFromRGBA",
                value: function (e) {
                    return parseFloat(e.replace(/^.*,(.+)\)/, "$1"))
                }
            }, {
                key: "rgb2hex",
                value: function (e) {
                    return (e = e.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?/i)) && 4 === e.length ? "#" + ("0" + parseInt(e[1], 10).toString(16)).slice(-2) + ("0" + parseInt(e[2], 10).toString(16)).slice(-2) + ("0" + parseInt(e[3], 10).toString(16)).slice(-2) : ""
                }
            }, {
                key: "isColorHex",
                value: function (e) {
                    return /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)|(^#[0-9A-F]{8}$)/i.test(e)
                }
            }, {
                key: "getPolygonPos",
                value: function (e, t) {
                    for (var n = [], i = 2 * Math.PI / t, a = 0; a < t; a++) {
                        var r = {};
                        r.x = e * Math.sin(a * i), r.y = -e * Math.cos(a * i), n.push(r)
                    }
                    return n
                }
            }, {
                key: "polarToCartesian",
                value: function (e, t, n, i) {
                    var a = (i - 90) * Math.PI / 180;
                    return {
                        x: e + n * Math.cos(a),
                        y: t + n * Math.sin(a)
                    }
                }
            }, {
                key: "escapeString",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "x",
                        n = e.toString().slice();
                    return n.replace(/[` ~!@#$%^&*()_|+\-=?;:'",.<>{}[\]\\/]/gi, t)
                }
            }, {
                key: "negToZero",
                value: function (e) {
                    return e < 0 ? 0 : e
                }
            }, {
                key: "moveIndexInArray",
                value: function (e, t, n) {
                    if (n >= e.length)
                        for (var i = n - e.length + 1; i--;) e.push(void 0);
                    return e.splice(n, 0, e.splice(t, 1)[0]), e
                }
            }, {
                key: "extractNumber",
                value: function (e) {
                    return parseFloat(e.replace(/[^\d.]*/g, ""))
                }
            }, {
                key: "findAncestor",
                value: function (e, t) {
                    for (;
                        (e = e.parentElement) && !e.classList.contains(t););
                    return e
                }
            }, {
                key: "setELstyles",
                value: function (e, t) {
                    for (var n in t) t.hasOwnProperty(n) && (e.style.key = t[n])
                }
            }, {
                key: "isNumber",
                value: function (e) {
                    return !isNaN(e) && parseFloat(Number(e)) === e && !isNaN(parseInt(e, 10))
                }
            }, {
                key: "isFloat",
                value: function (e) {
                    return Number(e) === e && e % 1 != 0
                }
            }, {
                key: "isSafari",
                value: function () {
                    return /^((?!chrome|android).)*safari/i.test(navigator.userAgent)
                }
            }, {
                key: "isFirefox",
                value: function () {
                    return navigator.userAgent.toLowerCase().indexOf("firefox") > -1
                }
            }, {
                key: "isIE11",
                value: function () {
                    if (-1 !== window.navigator.userAgent.indexOf("MSIE") || window.navigator.appVersion.indexOf("Trident/") > -1) return !0
                }
            }, {
                key: "isIE",
                value: function () {
                    var e = window.navigator.userAgent,
                        t = e.indexOf("MSIE ");
                    if (t > 0) return parseInt(e.substring(t + 5, e.indexOf(".", t)), 10);
                    if (e.indexOf("Trident/") > 0) {
                        var n = e.indexOf("rv:");
                        return parseInt(e.substring(n + 3, e.indexOf(".", n)), 10)
                    }
                    var i = e.indexOf("Edge/");
                    return i > 0 && parseInt(e.substring(i + 5, e.indexOf(".", i)), 10)
                }
            }]), e
        }(),
        m = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w, this.setEasingFunctions()
            }
            return r(e, [{
                key: "setEasingFunctions",
                value: function () {
                    var e;
                    if (!this.w.globals.easing) {
                        switch (this.w.config.chart.animations.easing) {
                            case "linear":
                                e = "-";
                                break;
                            case "easein":
                                e = "<";
                                break;
                            case "easeout":
                                e = ">";
                                break;
                            case "easeinout":
                            default:
                                e = "<>";
                                break;
                            case "swing":
                                e = function (e) {
                                    var t = 1.70158;
                                    return (e -= 1) * e * ((t + 1) * e + t) + 1
                                };
                                break;
                            case "bounce":
                                e = function (e) {
                                    return e < 1 / 2.75 ? 7.5625 * e * e : e < 2 / 2.75 ? 7.5625 * (e -= 1.5 / 2.75) * e + .75 : e < 2.5 / 2.75 ? 7.5625 * (e -= 2.25 / 2.75) * e + .9375 : 7.5625 * (e -= 2.625 / 2.75) * e + .984375
                                };
                                break;
                            case "elastic":
                                e = function (e) {
                                    return e === !!e ? e : Math.pow(2, -10 * e) * Math.sin((e - .075) * (2 * Math.PI) / .3) + 1
                                }
                        }
                        this.w.globals.easing = e
                    }
                }
            }, {
                key: "animateLine",
                value: function (e, t, n, i) {
                    e.attr(t).animate(i).attr(n)
                }
            }, {
                key: "animateMarker",
                value: function (e, t, n, i, a, r) {
                    t || (t = 0), e.attr({
                        r: t,
                        width: t,
                        height: t
                    }).animate(i, a).attr({
                        r: n,
                        width: n.width,
                        height: n.height
                    }).afterAll((function () {
                        r()
                    }))
                }
            }, {
                key: "animateCircle",
                value: function (e, t, n, i, a) {
                    e.attr({
                        r: t.r,
                        cx: t.cx,
                        cy: t.cy
                    }).animate(i, a).attr({
                        r: n.r,
                        cx: n.cx,
                        cy: n.cy
                    })
                }
            }, {
                key: "animateRect",
                value: function (e, t, n, i, a) {
                    e.attr(t).animate(i).attr(n).afterAll((function () {
                        return a()
                    }))
                }
            }, {
                key: "animatePathsGradually",
                value: function (e) {
                    var t = e.el,
                        n = e.realIndex,
                        i = e.j,
                        a = e.fill,
                        r = e.pathFrom,
                        s = e.pathTo,
                        o = e.speed,
                        l = e.delay,
                        c = this.w,
                        u = 0;
                    c.config.chart.animations.animateGradually.enabled && (u = c.config.chart.animations.animateGradually.delay), c.config.chart.animations.dynamicAnimation.enabled && c.globals.dataChanged && "bar" !== c.config.chart.type && (u = 0), this.morphSVG(t, n, i, "line" !== c.config.chart.type || c.globals.comboCharts ? a : "stroke", r, s, o, l * u)
                }
            }, {
                key: "showDelayedElements",
                value: function () {
                    this.w.globals.delayedElements.forEach((function (e) {
                        e.el.classList.remove("apexcharts-element-hidden")
                    }))
                }
            }, {
                key: "animationCompleted",
                value: function (e) {
                    var t = this.w;
                    t.globals.animationEnded || (t.globals.animationEnded = !0, this.showDelayedElements(), "function" == typeof t.config.chart.events.animationEnd && t.config.chart.events.animationEnd(this.ctx, {
                        el: e,
                        w: t
                    }))
                }
            }, {
                key: "morphSVG",
                value: function (e, t, n, i, a, r, s, o) {
                    var l = this,
                        c = this.w;
                    a || (a = e.attr("pathFrom")), r || (r = e.attr("pathTo"));
                    var u = function (e) {
                        return "radar" === c.config.chart.type && (s = 1), "M 0 ".concat(c.globals.gridHeight)
                    };
                    (!a || a.indexOf("undefined") > -1 || a.indexOf("NaN") > -1) && (a = u()), (!r || r.indexOf("undefined") > -1 || r.indexOf("NaN") > -1) && (r = u()), c.globals.shouldAnimate || (s = 1), e.plot(a).animate(1, c.globals.easing, o).plot(a).animate(s, c.globals.easing, o).plot(r).afterAll((function () {
                        p.isNumber(n) ? n === c.globals.series[c.globals.maxValsInArrayIndex].length - 2 && c.globals.shouldAnimate && l.animationCompleted(e) : "none" !== i && c.globals.shouldAnimate && (!c.globals.comboCharts && t === c.globals.series.length - 1 || c.globals.comboCharts) && l.animationCompleted(e), l.showDelayedElements()
                    }))
                }
            }]), e
        }(),
        g = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "getDefaultFilter",
                value: function (e, t) {
                    var n = this.w;
                    e.unfilter(!0), (new window.SVG.Filter).size("120%", "180%", "-5%", "-40%"), "none" !== n.config.states.normal.filter ? this.applyFilter(e, t, n.config.states.normal.filter.type, n.config.states.normal.filter.value) : n.config.chart.dropShadow.enabled && this.dropShadow(e, n.config.chart.dropShadow, t)
                }
            }, {
                key: "addNormalFilter",
                value: function (e, t) {
                    var n = this.w;
                    n.config.chart.dropShadow.enabled && !e.node.classList.contains("apexcharts-marker") && this.dropShadow(e, n.config.chart.dropShadow, t)
                }
            }, {
                key: "addLightenFilter",
                value: function (e, t, n) {
                    var i = this,
                        a = this.w,
                        r = n.intensity;
                    e.unfilter(!0), new window.SVG.Filter, e.filter((function (e) {
                        var n = a.config.chart.dropShadow;
                        (n.enabled ? i.addShadow(e, t, n) : e).componentTransfer({
                            rgb: {
                                type: "linear",
                                slope: 1.5,
                                intercept: r
                            }
                        })
                    })), e.filterer.node.setAttribute("filterUnits", "userSpaceOnUse"), this._scaleFilterSize(e.filterer.node)
                }
            }, {
                key: "addDarkenFilter",
                value: function (e, t, n) {
                    var i = this,
                        a = this.w,
                        r = n.intensity;
                    e.unfilter(!0), new window.SVG.Filter, e.filter((function (e) {
                        var n = a.config.chart.dropShadow;
                        (n.enabled ? i.addShadow(e, t, n) : e).componentTransfer({
                            rgb: {
                                type: "linear",
                                slope: r
                            }
                        })
                    })), e.filterer.node.setAttribute("filterUnits", "userSpaceOnUse"), this._scaleFilterSize(e.filterer.node)
                }
            }, {
                key: "applyFilter",
                value: function (e, t, n) {
                    var i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : .5;
                    switch (n) {
                        case "none":
                            this.addNormalFilter(e, t);
                            break;
                        case "lighten":
                            this.addLightenFilter(e, t, {
                                intensity: i
                            });
                            break;
                        case "darken":
                            this.addDarkenFilter(e, t, {
                                intensity: i
                            })
                    }
                }
            }, {
                key: "addShadow",
                value: function (e, t, n) {
                    var i = n.blur,
                        a = n.top,
                        r = n.left,
                        s = n.color,
                        o = n.opacity,
                        l = e.flood(Array.isArray(s) ? s[t] : s, o).composite(e.sourceAlpha, "in").offset(r, a).gaussianBlur(i).merge(e.source);
                    return e.blend(e.source, l)
                }
            }, {
                key: "dropShadow",
                value: function (e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                        i = t.top,
                        a = t.left,
                        r = t.blur,
                        s = t.color,
                        o = t.opacity,
                        l = t.noUserSpaceOnUse,
                        c = this.w;
                    return e.unfilter(!0), p.isIE() && "radialBar" === c.config.chart.type || (s = Array.isArray(s) ? s[n] : s, e.filter((function (e) {
                        var t;
                        t = p.isSafari() || p.isFirefox() || p.isIE() ? e.flood(s, o).composite(e.sourceAlpha, "in").offset(a, i).gaussianBlur(r) : e.flood(s, o).composite(e.sourceAlpha, "in").offset(a, i).gaussianBlur(r).merge(e.source), e.blend(e.source, t)
                    })), l || e.filterer.node.setAttribute("filterUnits", "userSpaceOnUse"), this._scaleFilterSize(e.filterer.node)), e
                }
            }, {
                key: "setSelectionFilter",
                value: function (e, t, n) {
                    var i = this.w;
                    if (void 0 !== i.globals.selectedDataPoints[t] && i.globals.selectedDataPoints[t].indexOf(n) > -1) {
                        e.node.setAttribute("selected", !0);
                        var a = i.config.states.active.filter;
                        "none" !== a && this.applyFilter(e, t, a.type, a.value)
                    }
                }
            }, {
                key: "_scaleFilterSize",
                value: function (e) {
                    ! function (t) {
                        for (var n in t) t.hasOwnProperty(n) && e.setAttribute(n, t[n])
                    }({
                        width: "200%",
                        height: "200%",
                        x: "-50%",
                        y: "-50%"
                    })
                }
            }]), e
        }(),
        v = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "drawLine",
                value: function (e, t, n, i) {
                    var a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "#a8a8a8",
                        r = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0,
                        s = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null,
                        o = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : "butt",
                        l = this.w,
                        c = l.globals.dom.Paper.line().attr({
                            x1: e,
                            y1: t,
                            x2: n,
                            y2: i,
                            stroke: a,
                            "stroke-dasharray": r,
                            "stroke-width": s,
                            "stroke-linecap": o
                        });
                    return c
                }
            }, {
                key: "drawRect",
                value: function () {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                        i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
                        a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0,
                        r = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : "#fefefe",
                        s = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 1,
                        o = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
                        l = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : null,
                        c = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : 0,
                        u = this.w,
                        d = u.globals.dom.Paper.rect();
                    return d.attr({
                        x: e,
                        y: t,
                        width: n > 0 ? n : 0,
                        height: i > 0 ? i : 0,
                        rx: a,
                        ry: a,
                        opacity: s,
                        "stroke-width": null !== o ? o : 0,
                        stroke: null !== l ? l : "none",
                        "stroke-dasharray": c
                    }), d.node.setAttribute("fill", r), d
                }
            }, {
                key: "drawPolygon",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "#e1e1e1",
                        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
                        i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "none",
                        a = this.w,
                        r = a.globals.dom.Paper.polygon(e).attr({
                            fill: i,
                            stroke: t,
                            "stroke-width": n
                        });
                    return r
                }
            }, {
                key: "drawCircle",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                        n = this.w;
                    e < 0 && (e = 0);
                    var i = n.globals.dom.Paper.circle(2 * e);
                    return null !== t && i.attr(t), i
                }
            }, {
                key: "drawPath",
                value: function (e) {
                    var t = e.d,
                        n = void 0 === t ? "" : t,
                        i = e.stroke,
                        a = void 0 === i ? "#a8a8a8" : i,
                        r = e.strokeWidth,
                        s = void 0 === r ? 1 : r,
                        o = e.fill,
                        l = e.fillOpacity,
                        c = void 0 === l ? 1 : l,
                        u = e.strokeOpacity,
                        d = void 0 === u ? 1 : u,
                        h = e.classes,
                        f = e.strokeLinecap,
                        p = void 0 === f ? null : f,
                        m = e.strokeDashArray,
                        g = void 0 === m ? 0 : m,
                        v = this.w;
                    return null === p && (p = v.config.stroke.lineCap), (n.indexOf("undefined") > -1 || n.indexOf("NaN") > -1) && (n = "M 0 ".concat(v.globals.gridHeight)), v.globals.dom.Paper.path(n).attr({
                        fill: o,
                        "fill-opacity": c,
                        stroke: a,
                        "stroke-opacity": d,
                        "stroke-linecap": p,
                        "stroke-width": s,
                        "stroke-dasharray": g,
                        class: h
                    })
                }
            }, {
                key: "group",
                value: function () {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                        t = this.w,
                        n = t.globals.dom.Paper.group();
                    return null !== e && n.attr(e), n
                }
            }, {
                key: "move",
                value: function (e, t) {
                    return ["M", e, t].join(" ")
                }
            }, {
                key: "line",
                value: function (e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
                        i = null;
                    return null === n ? i = ["L", e, t].join(" ") : "H" === n ? i = ["H", e].join(" ") : "V" === n && (i = ["V", t].join(" ")), i
                }
            }, {
                key: "curve",
                value: function (e, t, n, i, a, r) {
                    return ["C", e, t, n, i, a, r].join(" ")
                }
            }, {
                key: "quadraticCurve",
                value: function (e, t, n, i) {
                    return ["Q", e, t, n, i].join(" ")
                }
            }, {
                key: "arc",
                value: function (e, t, n, i, a, r, s) {
                    var o = arguments.length > 7 && void 0 !== arguments[7] && arguments[7],
                        l = "A";
                    o && (l = "a");
                    var c = [l, e, t, n, i, a, r, s].join(" ");
                    return c
                }
            }, {
                key: "renderPaths",
                value: function (e) {
                    var n, i = e.j,
                        a = e.realIndex,
                        r = e.pathFrom,
                        s = e.pathTo,
                        o = e.stroke,
                        l = e.strokeWidth,
                        c = e.strokeLinecap,
                        u = e.fill,
                        d = e.animationDelay,
                        h = e.initialSpeed,
                        f = e.dataChangeSpeed,
                        p = e.className,
                        v = e.shouldClipToGrid,
                        y = void 0 === v || v,
                        b = e.bindEventsOnPaths,
                        x = void 0 === b || b,
                        _ = e.drawShadow,
                        w = void 0 === _ || _,
                        k = this.w,
                        M = new g(this.ctx),
                        L = new m(this.ctx),
                        S = this.w.config.chart.animations.enabled,
                        A = S && this.w.config.chart.animations.dynamicAnimation.enabled,
                        T = !!(S && !k.globals.resized || A && k.globals.dataChanged && k.globals.shouldAnimate);
                    T ? n = r : (n = s, k.globals.animationEnded = !0);
                    var C, D = k.config.stroke.dashArray;
                    C = Array.isArray(D) ? D[a] : k.config.stroke.dashArray;
                    var E = this.drawPath({
                        d: n,
                        stroke: o,
                        strokeWidth: l,
                        fill: u,
                        fillOpacity: 1,
                        classes: p,
                        strokeLinecap: c,
                        strokeDashArray: C
                    });
                    if (E.attr("index", a), y && E.attr({
                            "clip-path": "url(#gridRectMask".concat(k.globals.cuid, ")")
                        }), "none" !== k.config.states.normal.filter.type) M.getDefaultFilter(E, a);
                    else if (k.config.chart.dropShadow.enabled && w && (!k.config.chart.dropShadow.enabledOnSeries || k.config.chart.dropShadow.enabledOnSeries && -1 !== k.config.chart.dropShadow.enabledOnSeries.indexOf(a))) {
                        var O = k.config.chart.dropShadow;
                        M.dropShadow(E, O, a)
                    }
                    x && (E.node.addEventListener("mouseenter", this.pathMouseEnter.bind(this, E)), E.node.addEventListener("mouseleave", this.pathMouseLeave.bind(this, E)), E.node.addEventListener("mousedown", this.pathMouseDown.bind(this, E))), E.attr({
                        pathTo: s,
                        pathFrom: r
                    });
                    var P = {
                        el: E,
                        j: i,
                        realIndex: a,
                        pathFrom: r,
                        pathTo: s,
                        fill: u,
                        strokeWidth: l,
                        delay: d
                    };
                    return !S || k.globals.resized || k.globals.dataChanged ? !k.globals.resized && k.globals.dataChanged || L.showDelayedElements() : L.animatePathsGradually(t(t({}, P), {}, {
                        speed: h
                    })), k.globals.dataChanged && A && T && L.animatePathsGradually(t(t({}, P), {}, {
                        speed: f
                    })), E
                }
            }, {
                key: "drawPattern",
                value: function (e, t, n) {
                    var i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "#a8a8a8",
                        a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0,
                        r = this.w,
                        s = r.globals.dom.Paper.pattern(t, n, (function (r) {
                            "horizontalLines" === e ? r.line(0, 0, n, 0).stroke({
                                color: i,
                                width: a + 1
                            }) : "verticalLines" === e ? r.line(0, 0, 0, t).stroke({
                                color: i,
                                width: a + 1
                            }) : "slantedLines" === e ? r.line(0, 0, t, n).stroke({
                                color: i,
                                width: a
                            }) : "squares" === e ? r.rect(t, n).fill("none").stroke({
                                color: i,
                                width: a
                            }) : "circles" === e && r.circle(t).fill("none").stroke({
                                color: i,
                                width: a
                            })
                        }));
                    return s
                }
            }, {
                key: "drawGradient",
                value: function (e, t, n, i, a) {
                    var r, s = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
                        o = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null,
                        l = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
                        c = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 0,
                        u = this.w;
                    t.length < 9 && 0 === t.indexOf("#") && (t = p.hexToRgba(t, i)), n.length < 9 && 0 === n.indexOf("#") && (n = p.hexToRgba(n, a));
                    var d = 0,
                        h = 1,
                        f = 1,
                        m = null;
                    null !== o && (d = void 0 !== o[0] ? o[0] / 100 : 0, h = void 0 !== o[1] ? o[1] / 100 : 1, f = void 0 !== o[2] ? o[2] / 100 : 1, m = void 0 !== o[3] ? o[3] / 100 : null);
                    var g = !("donut" !== u.config.chart.type && "pie" !== u.config.chart.type && "polarArea" !== u.config.chart.type && "bubble" !== u.config.chart.type);
                    if (r = null === l || 0 === l.length ? u.globals.dom.Paper.gradient(g ? "radial" : "linear", (function (e) {
                            e.at(d, t, i), e.at(h, n, a), e.at(f, n, a), null !== m && e.at(m, t, i)
                        })) : u.globals.dom.Paper.gradient(g ? "radial" : "linear", (function (e) {
                            (Array.isArray(l[c]) ? l[c] : l).forEach((function (t) {
                                e.at(t.offset / 100, t.color, t.opacity)
                            }))
                        })), g) {
                        var v = u.globals.gridWidth / 2,
                            y = u.globals.gridHeight / 2;
                        "bubble" !== u.config.chart.type ? r.attr({
                            gradientUnits: "userSpaceOnUse",
                            cx: v,
                            cy: y,
                            r: s
                        }) : r.attr({
                            cx: .5,
                            cy: .5,
                            r: .8,
                            fx: .2,
                            fy: .2
                        })
                    } else "vertical" === e ? r.from(0, 0).to(0, 1) : "diagonal" === e ? r.from(0, 0).to(1, 1) : "horizontal" === e ? r.from(0, 1).to(1, 1) : "diagonal2" === e && r.from(1, 0).to(0, 1);
                    return r
                }
            }, {
                key: "drawText",
                value: function (e) {
                    var t, n = e.x,
                        i = e.y,
                        a = e.text,
                        r = e.textAnchor,
                        s = e.fontSize,
                        o = e.fontFamily,
                        l = e.fontWeight,
                        c = e.foreColor,
                        u = e.opacity,
                        d = e.cssClass,
                        h = void 0 === d ? "" : d,
                        f = e.isPlainText,
                        p = void 0 === f || f,
                        m = this.w;
                    return void 0 === a && (a = ""), r || (r = "start"), c && c.length || (c = m.config.chart.foreColor), o = o || m.config.chart.fontFamily, l = l || "regular", (t = Array.isArray(a) ? m.globals.dom.Paper.text((function (e) {
                        for (var t = 0; t < a.length; t++) 0 === t ? e.tspan(a[t]) : e.tspan(a[t]).newLine()
                    })) : p ? m.globals.dom.Paper.plain(a) : m.globals.dom.Paper.text((function (e) {
                        return e.tspan(a)
                    }))).attr({
                        x: n,
                        y: i,
                        "text-anchor": r,
                        "dominant-baseline": "auto",
                        "font-size": s,
                        "font-family": o,
                        "font-weight": l,
                        fill: c,
                        class: "apexcharts-text " + h
                    }), t.node.style.fontFamily = o, t.node.style.opacity = u, t
                }
            }, {
                key: "drawMarker",
                value: function (e, t, n) {
                    e = e || 0;
                    var i = n.pSize || 0,
                        a = null;
                    if ("square" === n.shape || "rect" === n.shape) {
                        var r = void 0 === n.pRadius ? i / 2 : n.pRadius;
                        null !== t && i || (i = 0, r = 0);
                        var s = 1.2 * i + r,
                            o = this.drawRect(s, s, s, s, r);
                        o.attr({
                            x: e - s / 2,
                            y: t - s / 2,
                            cx: e,
                            cy: t,
                            class: n.class ? n.class : "",
                            fill: n.pointFillColor,
                            "fill-opacity": n.pointFillOpacity ? n.pointFillOpacity : 1,
                            stroke: n.pointStrokeColor,
                            "stroke-width": n.pointStrokeWidth ? n.pointStrokeWidth : 0,
                            "stroke-opacity": n.pointStrokeOpacity ? n.pointStrokeOpacity : 1
                        }), a = o
                    } else "circle" !== n.shape && n.shape || (p.isNumber(t) || (i = 0, t = 0), a = this.drawCircle(i, {
                        cx: e,
                        cy: t,
                        class: n.class ? n.class : "",
                        stroke: n.pointStrokeColor,
                        fill: n.pointFillColor,
                        "fill-opacity": n.pointFillOpacity ? n.pointFillOpacity : 1,
                        "stroke-width": n.pointStrokeWidth ? n.pointStrokeWidth : 0,
                        "stroke-opacity": n.pointStrokeOpacity ? n.pointStrokeOpacity : 1
                    }));
                    return a
                }
            }, {
                key: "pathMouseEnter",
                value: function (e, t) {
                    var n = this.w,
                        i = new g(this.ctx),
                        a = parseInt(e.node.getAttribute("index"), 10),
                        r = parseInt(e.node.getAttribute("j"), 10);
                    if ("function" == typeof n.config.chart.events.dataPointMouseEnter && n.config.chart.events.dataPointMouseEnter(t, this.ctx, {
                            seriesIndex: a,
                            dataPointIndex: r,
                            w: n
                        }), this.ctx.events.fireEvent("dataPointMouseEnter", [t, this.ctx, {
                            seriesIndex: a,
                            dataPointIndex: r,
                            w: n
                        }]), ("none" === n.config.states.active.filter.type || "true" !== e.node.getAttribute("selected")) && "none" !== n.config.states.hover.filter.type && !n.globals.isTouchDevice) {
                        var s = n.config.states.hover.filter;
                        i.applyFilter(e, a, s.type, s.value)
                    }
                }
            }, {
                key: "pathMouseLeave",
                value: function (e, t) {
                    var n = this.w,
                        i = new g(this.ctx),
                        a = parseInt(e.node.getAttribute("index"), 10),
                        r = parseInt(e.node.getAttribute("j"), 10);
                    "function" == typeof n.config.chart.events.dataPointMouseLeave && n.config.chart.events.dataPointMouseLeave(t, this.ctx, {
                        seriesIndex: a,
                        dataPointIndex: r,
                        w: n
                    }), this.ctx.events.fireEvent("dataPointMouseLeave", [t, this.ctx, {
                        seriesIndex: a,
                        dataPointIndex: r,
                        w: n
                    }]), "none" !== n.config.states.active.filter.type && "true" === e.node.getAttribute("selected") || "none" !== n.config.states.hover.filter.type && i.getDefaultFilter(e, a)
                }
            }, {
                key: "pathMouseDown",
                value: function (e, t) {
                    var n = this.w,
                        i = new g(this.ctx),
                        a = parseInt(e.node.getAttribute("index"), 10),
                        r = parseInt(e.node.getAttribute("j"), 10),
                        s = "false";
                    if ("true" === e.node.getAttribute("selected")) {
                        if (e.node.setAttribute("selected", "false"), n.globals.selectedDataPoints[a].indexOf(r) > -1) {
                            var o = n.globals.selectedDataPoints[a].indexOf(r);
                            n.globals.selectedDataPoints[a].splice(o, 1)
                        }
                    } else {
                        if (!n.config.states.active.allowMultipleDataPointsSelection && n.globals.selectedDataPoints.length > 0) {
                            n.globals.selectedDataPoints = [];
                            var l = n.globals.dom.Paper.select(".apexcharts-series path").members,
                                c = n.globals.dom.Paper.select(".apexcharts-series circle, .apexcharts-series rect").members,
                                u = function (e) {
                                    Array.prototype.forEach.call(e, (function (e) {
                                        e.node.setAttribute("selected", "false"), i.getDefaultFilter(e, a)
                                    }))
                                };
                            u(l), u(c)
                        }
                        e.node.setAttribute("selected", "true"), s = "true", void 0 === n.globals.selectedDataPoints[a] && (n.globals.selectedDataPoints[a] = []), n.globals.selectedDataPoints[a].push(r)
                    }
                    if ("true" === s) {
                        var d = n.config.states.active.filter;
                        "none" !== d && i.applyFilter(e, a, d.type, d.value)
                    } else "none" !== n.config.states.active.filter.type && i.getDefaultFilter(e, a);
                    "function" == typeof n.config.chart.events.dataPointSelection && n.config.chart.events.dataPointSelection(t, this.ctx, {
                        selectedDataPoints: n.globals.selectedDataPoints,
                        seriesIndex: a,
                        dataPointIndex: r,
                        w: n
                    }), t && this.ctx.events.fireEvent("dataPointSelection", [t, this.ctx, {
                        selectedDataPoints: n.globals.selectedDataPoints,
                        seriesIndex: a,
                        dataPointIndex: r,
                        w: n
                    }])
                }
            }, {
                key: "rotateAroundCenter",
                value: function (e) {
                    var t = {};
                    return e && "function" == typeof e.getBBox && (t = e.getBBox()), {
                        x: t.x + t.width / 2,
                        y: t.y + t.height / 2
                    }
                }
            }, {
                key: "getTextRects",
                value: function (e, t, n, i) {
                    var a = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
                        r = this.w,
                        s = this.drawText({
                            x: -200,
                            y: -200,
                            text: e,
                            textAnchor: "start",
                            fontSize: t,
                            fontFamily: n,
                            foreColor: "#fff",
                            opacity: 0
                        });
                    i && s.attr("transform", i), r.globals.dom.Paper.add(s);
                    var o = s.bbox();
                    return a || (o = s.node.getBoundingClientRect()), s.remove(), {
                        width: o.width,
                        height: o.height
                    }
                }
            }, {
                key: "placeTextWithEllipsis",
                value: function (e, t, n) {
                    if ("function" == typeof e.getComputedTextLength && (e.textContent = t, t.length > 0 && e.getComputedTextLength() >= n / 1.1)) {
                        for (var i = t.length - 3; i > 0; i -= 3)
                            if (e.getSubStringLength(0, i) <= n / 1.1) return void(e.textContent = t.substring(0, i) + "...");
                        e.textContent = "."
                    }
                }
            }], [{
                key: "setAttrs",
                value: function (e, t) {
                    for (var n in t) t.hasOwnProperty(n) && e.setAttribute(n, t[n])
                }
            }]), e
        }(),
        y = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.annoCtx = t
            }
            return r(e, [{
                key: "setOrientations",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                        n = this.w;
                    if ("vertical" === e.label.orientation) {
                        var i = null !== t ? t : 0,
                            a = n.globals.dom.baseEl.querySelector(".apexcharts-xaxis-annotations .apexcharts-xaxis-annotation-label[rel='".concat(i, "']"));
                        if (null !== a) {
                            var r = a.getBoundingClientRect();
                            a.setAttribute("x", parseFloat(a.getAttribute("x")) - r.height + 4), "top" === e.label.position ? a.setAttribute("y", parseFloat(a.getAttribute("y")) + r.width) : a.setAttribute("y", parseFloat(a.getAttribute("y")) - r.width);
                            var s = this.annoCtx.graphics.rotateAroundCenter(a),
                                o = s.x,
                                l = s.y;
                            a.setAttribute("transform", "rotate(-90 ".concat(o, " ").concat(l, ")"))
                        }
                    }
                }
            }, {
                key: "addBackgroundToAnno",
                value: function (e, t) {
                    var n = this.w;
                    if (!e || void 0 === t.label.text || void 0 !== t.label.text && !String(t.label.text).trim()) return null;
                    var i = n.globals.dom.baseEl.querySelector(".apexcharts-grid").getBoundingClientRect(),
                        a = e.getBoundingClientRect(),
                        r = t.label.style.padding.left,
                        s = t.label.style.padding.right,
                        o = t.label.style.padding.top,
                        l = t.label.style.padding.bottom;
                    "vertical" === t.label.orientation && (o = t.label.style.padding.left, l = t.label.style.padding.right, r = t.label.style.padding.top, s = t.label.style.padding.bottom);
                    var c = a.left - i.left - r,
                        u = a.top - i.top - o,
                        d = this.annoCtx.graphics.drawRect(c - n.globals.barPadForNumericAxis, u, a.width + r + s, a.height + o + l, t.label.borderRadius, t.label.style.background, 1, t.label.borderWidth, t.label.borderColor, 0);
                    return t.id && d.node.classList.add(p.escapeString(t.id)), d
                }
            }, {
                key: "annotationsBackground",
                value: function () {
                    var e = this,
                        t = this.w,
                        n = function (n, i, a) {
                            var r = t.globals.dom.baseEl.querySelector(".apexcharts-".concat(a, "-annotations .apexcharts-").concat(a, "-annotation-label[rel='").concat(i, "']"));
                            if (r) {
                                var s = r.parentNode,
                                    o = e.addBackgroundToAnno(r, n);
                                o && (s.insertBefore(o.node, r), n.label.mouseEnter && o.node.addEventListener("mouseenter", n.label.mouseEnter.bind(e, n)), n.label.mouseLeave && o.node.addEventListener("mouseleave", n.label.mouseLeave.bind(e, n)))
                            }
                        };
                    t.config.annotations.xaxis.map((function (e, t) {
                        n(e, t, "xaxis")
                    })), t.config.annotations.yaxis.map((function (e, t) {
                        n(e, t, "yaxis")
                    })), t.config.annotations.points.map((function (e, t) {
                        n(e, t, "point")
                    }))
                }
            }, {
                key: "getStringX",
                value: function (e) {
                    var t = this.w,
                        n = e;
                    t.config.xaxis.convertedCatToNumeric && t.globals.categoryLabels.length && (e = t.globals.categoryLabels.indexOf(e) + 1);
                    var i = t.globals.labels.indexOf(e),
                        a = t.globals.dom.baseEl.querySelector(".apexcharts-xaxis-texts-g text:nth-child(" + (i + 1) + ")");
                    return a && (n = parseFloat(a.getAttribute("x"))), n
                }
            }]), e
        }(),
        b = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.annoCtx = t, this.invertAxis = this.annoCtx.invertAxis
            }
            return r(e, [{
                key: "addXaxisAnnotation",
                value: function (e, t, n) {
                    var i = this.w,
                        a = this.invertAxis ? i.globals.minY : i.globals.minX,
                        r = this.invertAxis ? i.globals.maxY : i.globals.maxX,
                        s = this.invertAxis ? i.globals.yRange[0] : i.globals.xRange,
                        o = (e.x - a) / (s / i.globals.gridWidth);
                    this.annoCtx.inversedReversedAxis && (o = (r - e.x) / (s / i.globals.gridWidth));
                    var l = e.label.text;
                    "category" !== i.config.xaxis.type && !i.config.xaxis.convertedCatToNumeric || this.invertAxis || i.globals.dataFormatXNumeric || (o = this.annoCtx.helpers.getStringX(e.x));
                    var c = e.strokeDashArray;
                    if (p.isNumber(o)) {
                        if (null === e.x2 || void 0 === e.x2) {
                            var u = this.annoCtx.graphics.drawLine(o + e.offsetX, 0 + e.offsetY, o + e.offsetX, i.globals.gridHeight + e.offsetY, e.borderColor, c, e.borderWidth);
                            t.appendChild(u.node), e.id && u.node.classList.add(e.id)
                        } else {
                            var d = (e.x2 - a) / (s / i.globals.gridWidth);
                            if (this.annoCtx.inversedReversedAxis && (d = (r - e.x2) / (s / i.globals.gridWidth)), "category" !== i.config.xaxis.type && !i.config.xaxis.convertedCatToNumeric || this.invertAxis || i.globals.dataFormatXNumeric || (d = this.annoCtx.helpers.getStringX(e.x2)), d < o) {
                                var h = o;
                                o = d, d = h
                            }
                            var f = this.annoCtx.graphics.drawRect(o + e.offsetX, 0 + e.offsetY, d - o, i.globals.gridHeight + e.offsetY, 0, e.fillColor, e.opacity, 1, e.borderColor, c);
                            f.node.classList.add("apexcharts-annotation-rect"), f.attr("clip-path", "url(#gridRectMask".concat(i.globals.cuid, ")")), t.appendChild(f.node), e.id && f.node.classList.add(e.id)
                        }
                        var m = "top" === e.label.position ? 4 : i.globals.gridHeight,
                            g = this.annoCtx.graphics.getTextRects(l, parseFloat(e.label.style.fontSize)),
                            v = this.annoCtx.graphics.drawText({
                                x: o + e.label.offsetX,
                                y: m + e.label.offsetY - ("vertical" === e.label.orientation ? "top" === e.label.position ? g.width / 2 - 12 : -g.width / 2 : 0),
                                text: l,
                                textAnchor: e.label.textAnchor,
                                fontSize: e.label.style.fontSize,
                                fontFamily: e.label.style.fontFamily,
                                fontWeight: e.label.style.fontWeight,
                                foreColor: e.label.style.color,
                                cssClass: "apexcharts-xaxis-annotation-label ".concat(e.label.style.cssClass, " ").concat(e.id ? e.id : "")
                            });
                        v.attr({
                            rel: n
                        }), t.appendChild(v.node), this.annoCtx.helpers.setOrientations(e, n)
                    }
                }
            }, {
                key: "drawXAxisAnnotations",
                value: function () {
                    var e = this,
                        t = this.w,
                        n = this.annoCtx.graphics.group({
                            class: "apexcharts-xaxis-annotations"
                        });
                    return t.config.annotations.xaxis.map((function (t, i) {
                        e.addXaxisAnnotation(t, n.node, i)
                    })), n
                }
            }]), e
        }(),
        x = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "getStackedSeriesTotals",
                value: function () {
                    var e = this.w,
                        t = [];
                    if (0 === e.globals.series.length) return t;
                    for (var n = 0; n < e.globals.series[e.globals.maxValsInArrayIndex].length; n++) {
                        for (var i = 0, a = 0; a < e.globals.series.length; a++) void 0 !== e.globals.series[a][n] && (i += e.globals.series[a][n]);
                        t.push(i)
                    }
                    return e.globals.stackedSeriesTotals = t, t
                }
            }, {
                key: "getSeriesTotalByIndex",
                value: function () {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
                    return null === e ? this.w.config.series.reduce((function (e, t) {
                        return e + t
                    }), 0) : this.w.globals.series[e].reduce((function (e, t) {
                        return e + t
                    }), 0)
                }
            }, {
                key: "isSeriesNull",
                value: function () {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
                    return 0 === (null === e ? this.w.config.series.filter((function (e) {
                        return null !== e
                    })) : this.w.config.series[e].data.filter((function (e) {
                        return null !== e
                    }))).length
                }
            }, {
                key: "seriesHaveSameValues",
                value: function (e) {
                    return this.w.globals.series[e].every((function (e, t, n) {
                        return e === n[0]
                    }))
                }
            }, {
                key: "getCategoryLabels",
                value: function (e) {
                    var t = this.w,
                        n = e.slice();
                    return t.config.xaxis.convertedCatToNumeric && (n = e.map((function (e, n) {
                        return t.config.xaxis.labels.formatter(e - t.globals.minX + 1)
                    }))), n
                }
            }, {
                key: "getLargestSeries",
                value: function () {
                    var e = this.w;
                    e.globals.maxValsInArrayIndex = e.globals.series.map((function (e) {
                        return e.length
                    })).indexOf(Math.max.apply(Math, e.globals.series.map((function (e) {
                        return e.length
                    }))))
                }
            }, {
                key: "getLargestMarkerSize",
                value: function () {
                    var e = this.w,
                        t = 0;
                    return e.globals.markers.size.forEach((function (e) {
                        t = Math.max(t, e)
                    })), e.globals.markers.largestSize = t, t
                }
            }, {
                key: "getSeriesTotals",
                value: function () {
                    var e = this.w;
                    e.globals.seriesTotals = e.globals.series.map((function (e, t) {
                        var n = 0;
                        if (Array.isArray(e))
                            for (var i = 0; i < e.length; i++) n += e[i];
                        else n += e;
                        return n
                    }))
                }
            }, {
                key: "getSeriesTotalsXRange",
                value: function (e, t) {
                    var n = this.w;
                    return n.globals.series.map((function (i, a) {
                        for (var r = 0, s = 0; s < i.length; s++) n.globals.seriesX[a][s] > e && n.globals.seriesX[a][s] < t && (r += i[s]);
                        return r
                    }))
                }
            }, {
                key: "getPercentSeries",
                value: function () {
                    var e = this.w;
                    e.globals.seriesPercent = e.globals.series.map((function (t, n) {
                        var i = [];
                        if (Array.isArray(t))
                            for (var a = 0; a < t.length; a++) {
                                var r = e.globals.stackedSeriesTotals[a],
                                    s = 0;
                                r && (s = 100 * t[a] / r), i.push(s)
                            } else {
                                var o = 100 * t / e.globals.seriesTotals.reduce((function (e, t) {
                                    return e + t
                                }), 0);
                                i.push(o)
                            }
                        return i
                    }))
                }
            }, {
                key: "getCalculatedRatios",
                value: function () {
                    var e, t, n, i, a = this.w.globals,
                        r = [],
                        s = 0,
                        o = [],
                        l = .1,
                        c = 0;
                    if (a.yRange = [], a.isMultipleYAxis)
                        for (var u = 0; u < a.minYArr.length; u++) a.yRange.push(Math.abs(a.minYArr[u] - a.maxYArr[u])), o.push(0);
                    else a.yRange.push(Math.abs(a.minY - a.maxY));
                    a.xRange = Math.abs(a.maxX - a.minX), a.zRange = Math.abs(a.maxZ - a.minZ);
                    for (var d = 0; d < a.yRange.length; d++) r.push(a.yRange[d] / a.gridHeight);
                    if (t = a.xRange / a.gridWidth, n = Math.abs(a.initialMaxX - a.initialMinX) / a.gridWidth, e = a.yRange / a.gridWidth, i = a.xRange / a.gridHeight, (s = a.zRange / a.gridHeight * 16) || (s = 1), a.minY !== Number.MIN_VALUE && 0 !== Math.abs(a.minY) && (a.hasNegs = !0), a.isMultipleYAxis) {
                        o = [];
                        for (var h = 0; h < r.length; h++) o.push(-a.minYArr[h] / r[h])
                    } else o.push(-a.minY / r[0]), a.minY !== Number.MIN_VALUE && 0 !== Math.abs(a.minY) && (l = -a.minY / e, c = a.minX / t);
                    return {
                        yRatio: r,
                        invertedYRatio: e,
                        zRatio: s,
                        xRatio: t,
                        initialXRatio: n,
                        invertedXRatio: i,
                        baseLineInvertedY: l,
                        baseLineY: o,
                        baseLineX: c
                    }
                }
            }, {
                key: "getLogSeries",
                value: function (e) {
                    var t = this,
                        n = this.w;
                    return n.globals.seriesLog = e.map((function (e, i) {
                        return n.config.yaxis[i] && n.config.yaxis[i].logarithmic ? e.map((function (e) {
                            return null === e ? null : t.getLogVal(e, i)
                        })) : e
                    })), n.globals.invalidLogScale ? e : n.globals.seriesLog
                }
            }, {
                key: "getLogVal",
                value: function (e, t) {
                    var n = this.w,
                        i = (Math.log(e) - Math.log(n.globals.minYArr[t])) / (Math.log(n.globals.maxYArr[t]) - Math.log(n.globals.minYArr[t]));
                    return isNaN(i) ? e : i
                }
            }, {
                key: "getLogYRatios",
                value: function (e) {
                    var t = this,
                        n = this.w,
                        i = this.w.globals;
                    return i.yLogRatio = e.slice(), i.logYRange = i.yRange.map((function (e, a) {
                        if (n.config.yaxis[a] && t.w.config.yaxis[a].logarithmic) {
                            var r, s = -Number.MAX_VALUE,
                                o = Number.MIN_VALUE;
                            return i.seriesLog.forEach((function (e, t) {
                                e.forEach((function (e) {
                                    n.config.yaxis[t] && n.config.yaxis[t].logarithmic && (s = Math.max(e, s), o = Math.min(e, o))
                                }))
                            })), r = Math.pow(i.yRange[a], Math.abs(o - s) / i.yRange[a]), i.yLogRatio[a] = r / i.gridHeight, r
                        }
                    })), i.invalidLogScale ? e.slice() : i.yLogRatio
                }
            }], [{
                key: "checkComboSeries",
                value: function (e) {
                    var t = !1,
                        n = 0,
                        i = 0;
                    return e.length && void 0 !== e[0].type && e.forEach((function (e) {
                        "bar" !== e.type && "column" !== e.type && "candlestick" !== e.type && "boxPlot" !== e.type || n++, void 0 !== e.type && i++
                    })), i > 0 && (t = !0), {
                        comboBarCount: n,
                        comboCharts: t
                    }
                }
            }, {
                key: "extendArrayProps",
                value: function (e, t, n) {
                    return t.yaxis && (t = e.extendYAxis(t, n)), t.annotations && (t.annotations.yaxis && (t = e.extendYAxisAnnotations(t)), t.annotations.xaxis && (t = e.extendXAxisAnnotations(t)), t.annotations.points && (t = e.extendPointAnnotations(t))), t
                }
            }]), e
        }(),
        _ = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.annoCtx = t
            }
            return r(e, [{
                key: "addYaxisAnnotation",
                value: function (e, t, n) {
                    var i, a = this.w,
                        r = e.strokeDashArray,
                        s = this._getY1Y2("y1", e),
                        o = e.label.text;
                    if (null === e.y2 || void 0 === e.y2) {
                        var l = this.annoCtx.graphics.drawLine(0 + e.offsetX, s + e.offsetY, this._getYAxisAnnotationWidth(e), s + e.offsetY, e.borderColor, r, e.borderWidth);
                        t.appendChild(l.node), e.id && l.node.classList.add(e.id)
                    } else {
                        if ((i = this._getY1Y2("y2", e)) > s) {
                            var c = s;
                            s = i, i = c
                        }
                        var u = this.annoCtx.graphics.drawRect(0 + e.offsetX, i + e.offsetY, this._getYAxisAnnotationWidth(e), s - i, 0, e.fillColor, e.opacity, 1, e.borderColor, r);
                        u.node.classList.add("apexcharts-annotation-rect"), u.attr("clip-path", "url(#gridRectMask".concat(a.globals.cuid, ")")), t.appendChild(u.node), e.id && u.node.classList.add(e.id)
                    }
                    var d = "right" === e.label.position ? a.globals.gridWidth : 0,
                        h = this.annoCtx.graphics.drawText({
                            x: d + e.label.offsetX,
                            y: (null != i ? i : s) + e.label.offsetY - 3,
                            text: o,
                            textAnchor: e.label.textAnchor,
                            fontSize: e.label.style.fontSize,
                            fontFamily: e.label.style.fontFamily,
                            fontWeight: e.label.style.fontWeight,
                            foreColor: e.label.style.color,
                            cssClass: "apexcharts-yaxis-annotation-label ".concat(e.label.style.cssClass, " ").concat(e.id ? e.id : "")
                        });
                    h.attr({
                        rel: n
                    }), t.appendChild(h.node)
                }
            }, {
                key: "_getY1Y2",
                value: function (e, t) {
                    var n, i = "y1" === e ? t.y : t.y2,
                        a = this.w;
                    if (this.annoCtx.invertAxis) {
                        var r = a.globals.labels.indexOf(i);
                        a.config.xaxis.convertedCatToNumeric && (r = a.globals.categoryLabels.indexOf(i));
                        var s = a.globals.dom.baseEl.querySelector(".apexcharts-yaxis-texts-g text:nth-child(" + (r + 1) + ")");
                        s && (n = parseFloat(s.getAttribute("y")))
                    } else {
                        var o;
                        o = a.config.yaxis[t.yAxisIndex].logarithmic ? (i = new x(this.annoCtx.ctx).getLogVal(i, t.yAxisIndex)) / a.globals.yLogRatio[t.yAxisIndex] : (i - a.globals.minYArr[t.yAxisIndex]) / (a.globals.yRange[t.yAxisIndex] / a.globals.gridHeight), n = a.globals.gridHeight - o, a.config.yaxis[t.yAxisIndex] && a.config.yaxis[t.yAxisIndex].reversed && (n = o)
                    }
                    return n
                }
            }, {
                key: "_getYAxisAnnotationWidth",
                value: function (e) {
                    var t = this.w;
                    return t.globals.gridWidth, (e.width.indexOf("%") > -1 ? t.globals.gridWidth * parseInt(e.width, 10) / 100 : parseInt(e.width, 10)) + e.offsetX
                }
            }, {
                key: "drawYAxisAnnotations",
                value: function () {
                    var e = this,
                        t = this.w,
                        n = this.annoCtx.graphics.group({
                            class: "apexcharts-yaxis-annotations"
                        });
                    return t.config.annotations.yaxis.map((function (t, i) {
                        e.addYaxisAnnotation(t, n.node, i)
                    })), n
                }
            }]), e
        }(),
        w = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.annoCtx = t
            }
            return r(e, [{
                key: "addPointAnnotation",
                value: function (e, t, n) {
                    var i = this.w,
                        a = 0,
                        r = 0,
                        s = 0;
                    this.annoCtx.invertAxis && console.warn("Point annotation is not supported in horizontal bar charts.");
                    var o = parseFloat(e.y);
                    if ("string" == typeof e.x || "category" === i.config.xaxis.type || i.config.xaxis.convertedCatToNumeric) {
                        var l = i.globals.labels.indexOf(e.x);
                        i.config.xaxis.convertedCatToNumeric && (l = i.globals.categoryLabels.indexOf(e.x)), a = this.annoCtx.helpers.getStringX(e.x), null === e.y && (o = i.globals.series[e.seriesIndex][l])
                    } else a = (e.x - i.globals.minX) / (i.globals.xRange / i.globals.gridWidth);
                    for (var c, u = [], d = 0, h = 0; h <= e.seriesIndex; h++) {
                        var f = i.config.yaxis[h].seriesName;
                        if (f)
                            for (var m = h + 1; m <= e.seriesIndex; m++) i.config.yaxis[m].seriesName === f && -1 === u.indexOf(f) && (d++, u.push(f))
                    }
                    if (i.config.yaxis[e.yAxisIndex].logarithmic) c = (o = new x(this.annoCtx.ctx).getLogVal(o, e.yAxisIndex)) / i.globals.yLogRatio[e.yAxisIndex];
                    else {
                        var g = e.yAxisIndex + d;
                        c = (o - i.globals.minYArr[g]) / (i.globals.yRange[g] / i.globals.gridHeight)
                    }
                    if (r = i.globals.gridHeight - c - parseFloat(e.label.style.fontSize) - e.marker.size, s = i.globals.gridHeight - c, i.config.yaxis[e.yAxisIndex] && i.config.yaxis[e.yAxisIndex].reversed && (r = c + parseFloat(e.label.style.fontSize) + e.marker.size, s = c), p.isNumber(a)) {
                        var v = {
                                pSize: e.marker.size,
                                pointStrokeWidth: e.marker.strokeWidth,
                                pointFillColor: e.marker.fillColor,
                                pointStrokeColor: e.marker.strokeColor,
                                shape: e.marker.shape,
                                pRadius: e.marker.radius,
                                class: "apexcharts-point-annotation-marker ".concat(e.marker.cssClass, " ").concat(e.id ? e.id : "")
                            },
                            y = this.annoCtx.graphics.drawMarker(a + e.marker.offsetX, s + e.marker.offsetY, v);
                        t.appendChild(y.node);
                        var b = e.label.text ? e.label.text : "",
                            _ = this.annoCtx.graphics.drawText({
                                x: a + e.label.offsetX,
                                y: r + e.label.offsetY,
                                text: b,
                                textAnchor: e.label.textAnchor,
                                fontSize: e.label.style.fontSize,
                                fontFamily: e.label.style.fontFamily,
                                fontWeight: e.label.style.fontWeight,
                                foreColor: e.label.style.color,
                                cssClass: "apexcharts-point-annotation-label ".concat(e.label.style.cssClass, " ").concat(e.id ? e.id : "")
                            });
                        if (_.attr({
                                rel: n
                            }), t.appendChild(_.node), e.customSVG.SVG) {
                            var w = this.annoCtx.graphics.group({
                                class: "apexcharts-point-annotations-custom-svg " + e.customSVG.cssClass
                            });
                            w.attr({
                                transform: "translate(".concat(a + e.customSVG.offsetX, ", ").concat(r + e.customSVG.offsetY, ")")
                            }), w.node.innerHTML = e.customSVG.SVG, t.appendChild(w.node)
                        }
                        if (e.image.path) {
                            var k = e.image.width ? e.image.width : 20,
                                M = e.image.height ? e.image.height : 20;
                            y = this.annoCtx.addImage({
                                x: a + e.image.offsetX - k / 2,
                                y: r + e.image.offsetY - M / 2,
                                width: k,
                                height: M,
                                path: e.image.path,
                                appendTo: ".apexcharts-point-annotations"
                            })
                        }
                        e.mouseEnter && y.node.addEventListener("mouseenter", e.mouseEnter.bind(this, e)), e.mouseLeave && y.node.addEventListener("mouseleave", e.mouseLeave.bind(this, e))
                    }
                }
            }, {
                key: "drawPointAnnotations",
                value: function () {
                    var e = this,
                        t = this.w,
                        n = this.annoCtx.graphics.group({
                            class: "apexcharts-point-annotations"
                        });
                    return t.config.annotations.points.map((function (t, i) {
                        e.addPointAnnotation(t, n.node, i)
                    })), n
                }
            }]), e
        }(),
        k = {
            name: "en",
            options: {
                months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                toolbar: {
                    exportToSVG: "Download SVG",
                    exportToPNG: "Download PNG",
                    exportToCSV: "Download CSV",
                    menu: "Menu",
                    selection: "Selection",
                    selectionZoom: "Selection Zoom",
                    zoomIn: "Zoom In",
                    zoomOut: "Zoom Out",
                    pan: "Panning",
                    reset: "Reset Zoom"
                }
            }
        },
        M = function () {
            function e() {
                i(this, e), this.yAxis = {
                    show: !0,
                    showAlways: !1,
                    showForNullSeries: !0,
                    seriesName: void 0,
                    opposite: !1,
                    reversed: !1,
                    logarithmic: !1,
                    logBase: 10,
                    tickAmount: void 0,
                    forceNiceScale: !1,
                    max: void 0,
                    min: void 0,
                    floating: !1,
                    decimalsInFloat: void 0,
                    labels: {
                        show: !0,
                        minWidth: 0,
                        maxWidth: 160,
                        offsetX: 0,
                        offsetY: 0,
                        align: void 0,
                        rotate: 0,
                        padding: 20,
                        style: {
                            colors: [],
                            fontSize: "11px",
                            fontWeight: 400,
                            fontFamily: void 0,
                            cssClass: ""
                        },
                        formatter: void 0
                    },
                    axisBorder: {
                        show: !1,
                        color: "#e0e0e0",
                        width: 1,
                        offsetX: 0,
                        offsetY: 0
                    },
                    axisTicks: {
                        show: !1,
                        color: "#e0e0e0",
                        width: 6,
                        offsetX: 0,
                        offsetY: 0
                    },
                    title: {
                        text: void 0,
                        rotate: -90,
                        offsetY: 0,
                        offsetX: 0,
                        style: {
                            color: void 0,
                            fontSize: "11px",
                            fontWeight: 900,
                            fontFamily: void 0,
                            cssClass: ""
                        }
                    },
                    tooltip: {
                        enabled: !1,
                        offsetX: 0
                    },
                    crosshairs: {
                        show: !0,
                        position: "front",
                        stroke: {
                            color: "#b6b6b6",
                            width: 1,
                            dashArray: 0
                        }
                    }
                }, this.pointAnnotation = {
                    id: void 0,
                    x: 0,
                    y: null,
                    yAxisIndex: 0,
                    seriesIndex: 0,
                    mouseEnter: void 0,
                    mouseLeave: void 0,
                    marker: {
                        size: 4,
                        fillColor: "#fff",
                        strokeWidth: 2,
                        strokeColor: "#333",
                        shape: "circle",
                        offsetX: 0,
                        offsetY: 0,
                        radius: 2,
                        cssClass: ""
                    },
                    label: {
                        borderColor: "#c2c2c2",
                        borderWidth: 1,
                        borderRadius: 2,
                        text: void 0,
                        textAnchor: "middle",
                        offsetX: 0,
                        offsetY: 0,
                        mouseEnter: void 0,
                        mouseLeave: void 0,
                        style: {
                            background: "#fff",
                            color: void 0,
                            fontSize: "11px",
                            fontFamily: void 0,
                            fontWeight: 400,
                            cssClass: "",
                            padding: {
                                left: 5,
                                right: 5,
                                top: 2,
                                bottom: 2
                            }
                        }
                    },
                    customSVG: {
                        SVG: void 0,
                        cssClass: void 0,
                        offsetX: 0,
                        offsetY: 0
                    },
                    image: {
                        path: void 0,
                        width: 20,
                        height: 20,
                        offsetX: 0,
                        offsetY: 0
                    }
                }, this.yAxisAnnotation = {
                    id: void 0,
                    y: 0,
                    y2: null,
                    strokeDashArray: 1,
                    fillColor: "#c2c2c2",
                    borderColor: "#c2c2c2",
                    borderWidth: 1,
                    opacity: .3,
                    offsetX: 0,
                    offsetY: 0,
                    width: "100%",
                    yAxisIndex: 0,
                    label: {
                        borderColor: "#c2c2c2",
                        borderWidth: 1,
                        borderRadius: 2,
                        text: void 0,
                        textAnchor: "end",
                        position: "right",
                        offsetX: 0,
                        offsetY: -3,
                        mouseEnter: void 0,
                        mouseLeave: void 0,
                        style: {
                            background: "#fff",
                            color: void 0,
                            fontSize: "11px",
                            fontFamily: void 0,
                            fontWeight: 400,
                            cssClass: "",
                            padding: {
                                left: 5,
                                right: 5,
                                top: 2,
                                bottom: 2
                            }
                        }
                    }
                }, this.xAxisAnnotation = {
                    id: void 0,
                    x: 0,
                    x2: null,
                    strokeDashArray: 1,
                    fillColor: "#c2c2c2",
                    borderColor: "#c2c2c2",
                    borderWidth: 1,
                    opacity: .3,
                    offsetX: 0,
                    offsetY: 0,
                    label: {
                        borderColor: "#c2c2c2",
                        borderWidth: 1,
                        borderRadius: 2,
                        text: void 0,
                        textAnchor: "middle",
                        orientation: "vertical",
                        position: "top",
                        offsetX: 0,
                        offsetY: 0,
                        mouseEnter: void 0,
                        mouseLeave: void 0,
                        style: {
                            background: "#fff",
                            color: void 0,
                            fontSize: "11px",
                            fontFamily: void 0,
                            fontWeight: 400,
                            cssClass: "",
                            padding: {
                                left: 5,
                                right: 5,
                                top: 2,
                                bottom: 2
                            }
                        }
                    }
                }, this.text = {
                    x: 0,
                    y: 0,
                    text: "",
                    textAnchor: "start",
                    foreColor: void 0,
                    fontSize: "13px",
                    fontFamily: void 0,
                    fontWeight: 400,
                    appendTo: ".apexcharts-annotations",
                    backgroundColor: "transparent",
                    borderColor: "#c2c2c2",
                    borderRadius: 0,
                    borderWidth: 0,
                    paddingLeft: 4,
                    paddingRight: 4,
                    paddingTop: 2,
                    paddingBottom: 2
                }
            }
            return r(e, [{
                key: "init",
                value: function () {
                    return {
                        annotations: {
                            position: "front",
                            yaxis: [this.yAxisAnnotation],
                            xaxis: [this.xAxisAnnotation],
                            points: [this.pointAnnotation],
                            texts: [],
                            images: [],
                            shapes: []
                        },
                        chart: {
                            animations: {
                                enabled: !0,
                                easing: "easeinout",
                                speed: 800,
                                animateGradually: {
                                    delay: 150,
                                    enabled: !0
                                },
                                dynamicAnimation: {
                                    enabled: !0,
                                    speed: 350
                                }
                            },
                            background: "transparent",
                            locales: [k],
                            defaultLocale: "en",
                            dropShadow: {
                                enabled: !1,
                                enabledOnSeries: void 0,
                                top: 2,
                                left: 2,
                                blur: 4,
                                color: "#000",
                                opacity: .35
                            },
                            events: {
                                animationEnd: void 0,
                                beforeMount: void 0,
                                mounted: void 0,
                                updated: void 0,
                                click: void 0,
                                mouseMove: void 0,
                                mouseLeave: void 0,
                                legendClick: void 0,
                                markerClick: void 0,
                                selection: void 0,
                                dataPointSelection: void 0,
                                dataPointMouseEnter: void 0,
                                dataPointMouseLeave: void 0,
                                beforeZoom: void 0,
                                beforeResetZoom: void 0,
                                zoomed: void 0,
                                scrolled: void 0,
                                brushScrolled: void 0
                            },
                            foreColor: "#373d3f",
                            fontFamily: "Helvetica, Arial, sans-serif",
                            height: "auto",
                            parentHeightOffset: 15,
                            redrawOnParentResize: !0,
                            redrawOnWindowResize: !0,
                            id: void 0,
                            group: void 0,
                            offsetX: 0,
                            offsetY: 0,
                            selection: {
                                enabled: !1,
                                type: "x",
                                fill: {
                                    color: "#24292e",
                                    opacity: .1
                                },
                                stroke: {
                                    width: 1,
                                    color: "#24292e",
                                    opacity: .4,
                                    dashArray: 3
                                },
                                xaxis: {
                                    min: void 0,
                                    max: void 0
                                },
                                yaxis: {
                                    min: void 0,
                                    max: void 0
                                }
                            },
                            sparkline: {
                                enabled: !1
                            },
                            brush: {
                                enabled: !1,
                                autoScaleYaxis: !0,
                                target: void 0
                            },
                            stacked: !1,
                            stackType: "normal",
                            toolbar: {
                                show: !0,
                                offsetX: 0,
                                offsetY: 0,
                                tools: {
                                    download: !0,
                                    selection: !0,
                                    zoom: !0,
                                    zoomin: !0,
                                    zoomout: !0,
                                    pan: !0,
                                    reset: !0,
                                    customIcons: []
                                },
                                export: {
                                    csv: {
                                        filename: void 0,
                                        columnDelimiter: ",",
                                        headerCategory: "category",
                                        headerValue: "value",
                                        dateFormatter: function (e) {
                                            return new Date(e).toDateString()
                                        }
                                    },
                                    png: {
                                        filename: void 0
                                    },
                                    svg: {
                                        filename: void 0
                                    }
                                },
                                autoSelected: "zoom"
                            },
                            type: "line",
                            width: "100%",
                            zoom: {
                                enabled: !0,
                                type: "x",
                                autoScaleYaxis: !1,
                                zoomedArea: {
                                    fill: {
                                        color: "#90CAF9",
                                        opacity: .4
                                    },
                                    stroke: {
                                        color: "#0D47A1",
                                        opacity: .4,
                                        width: 1
                                    }
                                }
                            }
                        },
                        plotOptions: {
                            area: {
                                fillTo: "origin"
                            },
                            bar: {
                                horizontal: !1,
                                columnWidth: "70%",
                                barHeight: "70%",
                                distributed: !1,
                                borderRadius: 0,
                                rangeBarOverlap: !0,
                                rangeBarGroupRows: !1,
                                colors: {
                                    ranges: [],
                                    backgroundBarColors: [],
                                    backgroundBarOpacity: 1,
                                    backgroundBarRadius: 0
                                },
                                dataLabels: {
                                    position: "top",
                                    maxItems: 100,
                                    hideOverflowingLabels: !0,
                                    orientation: "horizontal"
                                }
                            },
                            bubble: {
                                minBubbleRadius: void 0,
                                maxBubbleRadius: void 0
                            },
                            candlestick: {
                                colors: {
                                    upward: "#00B746",
                                    downward: "#EF403C"
                                },
                                wick: {
                                    useFillColor: !0
                                }
                            },
                            boxPlot: {
                                colors: {
                                    upper: "#00E396",
                                    lower: "#008FFB"
                                }
                            },
                            heatmap: {
                                radius: 2,
                                enableShades: !0,
                                shadeIntensity: .5,
                                reverseNegativeShade: !1,
                                distributed: !1,
                                useFillColorAsStroke: !1,
                                colorScale: {
                                    inverse: !1,
                                    ranges: [],
                                    min: void 0,
                                    max: void 0
                                }
                            },
                            treemap: {
                                enableShades: !0,
                                shadeIntensity: .5,
                                distributed: !1,
                                reverseNegativeShade: !1,
                                useFillColorAsStroke: !1,
                                colorScale: {
                                    inverse: !1,
                                    ranges: [],
                                    min: void 0,
                                    max: void 0
                                }
                            },
                            radialBar: {
                                inverseOrder: !1,
                                startAngle: 0,
                                endAngle: 360,
                                offsetX: 0,
                                offsetY: 0,
                                hollow: {
                                    margin: 5,
                                    size: "50%",
                                    background: "transparent",
                                    image: void 0,
                                    imageWidth: 150,
                                    imageHeight: 150,
                                    imageOffsetX: 0,
                                    imageOffsetY: 0,
                                    imageClipped: !0,
                                    position: "front",
                                    dropShadow: {
                                        enabled: !1,
                                        top: 0,
                                        left: 0,
                                        blur: 3,
                                        color: "#000",
                                        opacity: .5
                                    }
                                },
                                track: {
                                    show: !0,
                                    startAngle: void 0,
                                    endAngle: void 0,
                                    background: "#f2f2f2",
                                    strokeWidth: "97%",
                                    opacity: 1,
                                    margin: 5,
                                    dropShadow: {
                                        enabled: !1,
                                        top: 0,
                                        left: 0,
                                        blur: 3,
                                        color: "#000",
                                        opacity: .5
                                    }
                                },
                                dataLabels: {
                                    show: !0,
                                    name: {
                                        show: !0,
                                        fontSize: "16px",
                                        fontFamily: void 0,
                                        fontWeight: 600,
                                        color: void 0,
                                        offsetY: 0,
                                        formatter: function (e) {
                                            return e
                                        }
                                    },
                                    value: {
                                        show: !0,
                                        fontSize: "14px",
                                        fontFamily: void 0,
                                        fontWeight: 400,
                                        color: void 0,
                                        offsetY: 16,
                                        formatter: function (e) {
                                            return e + "%"
                                        }
                                    },
                                    total: {
                                        show: !1,
                                        label: "Total",
                                        fontSize: "16px",
                                        fontWeight: 600,
                                        fontFamily: void 0,
                                        color: void 0,
                                        formatter: function (e) {
                                            return e.globals.seriesTotals.reduce((function (e, t) {
                                                return e + t
                                            }), 0) / e.globals.series.length + "%"
                                        }
                                    }
                                }
                            },
                            pie: {
                                customScale: 1,
                                offsetX: 0,
                                offsetY: 0,
                                startAngle: 0,
                                endAngle: 360,
                                expandOnClick: !0,
                                dataLabels: {
                                    offset: 0,
                                    minAngleToShowLabel: 10
                                },
                                donut: {
                                    size: "65%",
                                    background: "transparent",
                                    labels: {
                                        show: !1,
                                        name: {
                                            show: !0,
                                            fontSize: "16px",
                                            fontFamily: void 0,
                                            fontWeight: 600,
                                            color: void 0,
                                            offsetY: -10,
                                            formatter: function (e) {
                                                return e
                                            }
                                        },
                                        value: {
                                            show: !0,
                                            fontSize: "20px",
                                            fontFamily: void 0,
                                            fontWeight: 400,
                                            color: void 0,
                                            offsetY: 10,
                                            formatter: function (e) {
                                                return e
                                            }
                                        },
                                        total: {
                                            show: !1,
                                            showAlways: !1,
                                            label: "Total",
                                            fontSize: "16px",
                                            fontWeight: 400,
                                            fontFamily: void 0,
                                            color: void 0,
                                            formatter: function (e) {
                                                return e.globals.seriesTotals.reduce((function (e, t) {
                                                    return e + t
                                                }), 0)
                                            }
                                        }
                                    }
                                }
                            },
                            polarArea: {
                                rings: {
                                    strokeWidth: 1,
                                    strokeColor: "#e8e8e8"
                                },
                                spokes: {
                                    strokeWidth: 1,
                                    connectorColors: "#e8e8e8"
                                }
                            },
                            radar: {
                                size: void 0,
                                offsetX: 0,
                                offsetY: 0,
                                polygons: {
                                    strokeWidth: 1,
                                    strokeColors: "#e8e8e8",
                                    connectorColors: "#e8e8e8",
                                    fill: {
                                        colors: void 0
                                    }
                                }
                            }
                        },
                        colors: void 0,
                        dataLabels: {
                            enabled: !0,
                            enabledOnSeries: void 0,
                            formatter: function (e) {
                                return null !== e ? e : ""
                            },
                            textAnchor: "middle",
                            distributed: !1,
                            offsetX: 0,
                            offsetY: 0,
                            style: {
                                fontSize: "12px",
                                fontFamily: void 0,
                                fontWeight: 600,
                                colors: void 0
                            },
                            background: {
                                enabled: !0,
                                foreColor: "#fff",
                                borderRadius: 2,
                                padding: 4,
                                opacity: .9,
                                borderWidth: 1,
                                borderColor: "#fff",
                                dropShadow: {
                                    enabled: !1,
                                    top: 1,
                                    left: 1,
                                    blur: 1,
                                    color: "#000",
                                    opacity: .45
                                }
                            },
                            dropShadow: {
                                enabled: !1,
                                top: 1,
                                left: 1,
                                blur: 1,
                                color: "#000",
                                opacity: .45
                            }
                        },
                        fill: {
                            type: "solid",
                            colors: void 0,
                            opacity: .85,
                            gradient: {
                                shade: "dark",
                                type: "horizontal",
                                shadeIntensity: .5,
                                gradientToColors: void 0,
                                inverseColors: !0,
                                opacityFrom: 1,
                                opacityTo: 1,
                                stops: [0, 50, 100],
                                colorStops: []
                            },
                            image: {
                                src: [],
                                width: void 0,
                                height: void 0
                            },
                            pattern: {
                                style: "squares",
                                width: 6,
                                height: 6,
                                strokeWidth: 2
                            }
                        },
                        forecastDataPoints: {
                            count: 0,
                            fillOpacity: .5,
                            strokeWidth: void 0,
                            dashArray: 4
                        },
                        grid: {
                            show: !0,
                            borderColor: "#e0e0e0",
                            strokeDashArray: 0,
                            position: "back",
                            xaxis: {
                                lines: {
                                    show: !1
                                }
                            },
                            yaxis: {
                                lines: {
                                    show: !0
                                }
                            },
                            row: {
                                colors: void 0,
                                opacity: .5
                            },
                            column: {
                                colors: void 0,
                                opacity: .5
                            },
                            padding: {
                                top: 0,
                                right: 10,
                                bottom: 0,
                                left: 12
                            }
                        },
                        labels: [],
                        legend: {
                            show: !0,
                            showForSingleSeries: !1,
                            showForNullSeries: !0,
                            showForZeroSeries: !0,
                            floating: !1,
                            position: "bottom",
                            horizontalAlign: "center",
                            inverseOrder: !1,
                            fontSize: "12px",
                            fontFamily: void 0,
                            fontWeight: 400,
                            width: void 0,
                            height: void 0,
                            formatter: void 0,
                            tooltipHoverFormatter: void 0,
                            offsetX: -20,
                            offsetY: 4,
                            customLegendItems: [],
                            labels: {
                                colors: void 0,
                                useSeriesColors: !1
                            },
                            markers: {
                                width: 12,
                                height: 12,
                                strokeWidth: 0,
                                fillColors: void 0,
                                strokeColor: "#fff",
                                radius: 12,
                                customHTML: void 0,
                                offsetX: 0,
                                offsetY: 0,
                                onClick: void 0
                            },
                            itemMargin: {
                                horizontal: 5,
                                vertical: 2
                            },
                            onItemClick: {
                                toggleDataSeries: !0
                            },
                            onItemHover: {
                                highlightDataSeries: !0
                            }
                        },
                        markers: {
                            discrete: [],
                            size: 0,
                            colors: void 0,
                            strokeColors: "#fff",
                            strokeWidth: 2,
                            strokeOpacity: .9,
                            strokeDashArray: 0,
                            fillOpacity: 1,
                            shape: "circle",
                            width: 8,
                            height: 8,
                            radius: 2,
                            offsetX: 0,
                            offsetY: 0,
                            onClick: void 0,
                            onDblClick: void 0,
                            showNullDataPoints: !0,
                            hover: {
                                size: void 0,
                                sizeOffset: 3
                            }
                        },
                        noData: {
                            text: void 0,
                            align: "center",
                            verticalAlign: "middle",
                            offsetX: 0,
                            offsetY: 0,
                            style: {
                                color: void 0,
                                fontSize: "14px",
                                fontFamily: void 0
                            }
                        },
                        responsive: [],
                        series: void 0,
                        states: {
                            normal: {
                                filter: {
                                    type: "none",
                                    value: 0
                                }
                            },
                            hover: {
                                filter: {
                                    type: "lighten",
                                    value: .1
                                }
                            },
                            active: {
                                allowMultipleDataPointsSelection: !1,
                                filter: {
                                    type: "darken",
                                    value: .5
                                }
                            }
                        },
                        title: {
                            text: void 0,
                            align: "left",
                            margin: 5,
                            offsetX: 0,
                            offsetY: 0,
                            floating: !1,
                            style: {
                                fontSize: "14px",
                                fontWeight: 900,
                                fontFamily: void 0,
                                color: void 0
                            }
                        },
                        subtitle: {
                            text: void 0,
                            align: "left",
                            margin: 5,
                            offsetX: 0,
                            offsetY: 30,
                            floating: !1,
                            style: {
                                fontSize: "12px",
                                fontWeight: 400,
                                fontFamily: void 0,
                                color: void 0
                            }
                        },
                        stroke: {
                            show: !0,
                            curve: "smooth",
                            lineCap: "butt",
                            width: 2,
                            colors: void 0,
                            dashArray: 0
                        },
                        tooltip: {
                            enabled: !0,
                            enabledOnSeries: void 0,
                            shared: !0,
                            followCursor: !1,
                            intersect: !1,
                            inverseOrder: !1,
                            custom: void 0,
                            fillSeriesColor: !1,
                            theme: "light",
                            style: {
                                fontSize: "12px",
                                fontFamily: void 0
                            },
                            onDatasetHover: {
                                highlightDataSeries: !1
                            },
                            x: {
                                show: !0,
                                format: "dd MMM",
                                formatter: void 0
                            },
                            y: {
                                formatter: void 0,
                                title: {
                                    formatter: function (e) {
                                        return e ? e + ": " : ""
                                    }
                                }
                            },
                            z: {
                                formatter: void 0,
                                title: "Size: "
                            },
                            marker: {
                                show: !0,
                                fillColors: void 0
                            },
                            items: {
                                display: "flex"
                            },
                            fixed: {
                                enabled: !1,
                                position: "topRight",
                                offsetX: 0,
                                offsetY: 0
                            }
                        },
                        xaxis: {
                            type: "category",
                            categories: [],
                            convertedCatToNumeric: !1,
                            offsetX: 0,
                            offsetY: 0,
                            overwriteCategories: void 0,
                            labels: {
                                show: !0,
                                rotate: -45,
                                rotateAlways: !1,
                                hideOverlappingLabels: !0,
                                trim: !1,
                                minHeight: void 0,
                                maxHeight: 120,
                                showDuplicates: !0,
                                style: {
                                    colors: [],
                                    fontSize: "12px",
                                    fontWeight: 400,
                                    fontFamily: void 0,
                                    cssClass: ""
                                },
                                offsetX: 0,
                                offsetY: 0,
                                format: void 0,
                                formatter: void 0,
                                datetimeUTC: !0,
                                datetimeFormatter: {
                                    year: "yyyy",
                                    month: "MMM 'yy",
                                    day: "dd MMM",
                                    hour: "HH:mm",
                                    minute: "HH:mm:ss",
                                    second: "HH:mm:ss"
                                }
                            },
                            axisBorder: {
                                show: !0,
                                color: "#e0e0e0",
                                width: "100%",
                                height: 1,
                                offsetX: 0,
                                offsetY: 0
                            },
                            axisTicks: {
                                show: !0,
                                color: "#e0e0e0",
                                height: 6,
                                offsetX: 0,
                                offsetY: 0
                            },
                            tickAmount: void 0,
                            tickPlacement: "on",
                            min: void 0,
                            max: void 0,
                            range: void 0,
                            floating: !1,
                            decimalsInFloat: void 0,
                            position: "bottom",
                            title: {
                                text: void 0,
                                offsetX: 0,
                                offsetY: 0,
                                style: {
                                    color: void 0,
                                    fontSize: "12px",
                                    fontWeight: 900,
                                    fontFamily: void 0,
                                    cssClass: ""
                                }
                            },
                            crosshairs: {
                                show: !0,
                                width: 1,
                                position: "back",
                                opacity: .9,
                                stroke: {
                                    color: "#b6b6b6",
                                    width: 1,
                                    dashArray: 3
                                },
                                fill: {
                                    type: "solid",
                                    color: "#B1B9C4",
                                    gradient: {
                                        colorFrom: "#D8E3F0",
                                        colorTo: "#BED1E6",
                                        stops: [0, 100],
                                        opacityFrom: .4,
                                        opacityTo: .5
                                    }
                                },
                                dropShadow: {
                                    enabled: !1,
                                    left: 0,
                                    top: 0,
                                    blur: 1,
                                    opacity: .4
                                }
                            },
                            tooltip: {
                                enabled: !0,
                                offsetY: 0,
                                formatter: void 0,
                                style: {
                                    fontSize: "12px",
                                    fontFamily: void 0
                                }
                            }
                        },
                        yaxis: this.yAxis,
                        theme: {
                            mode: "light",
                            palette: "palette1",
                            monochrome: {
                                enabled: !1,
                                color: "#008FFB",
                                shadeTo: "light",
                                shadeIntensity: .65
                            }
                        }
                    }
                }
            }]), e
        }(),
        L = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w, this.graphics = new v(this.ctx), this.w.globals.isBarHorizontal && (this.invertAxis = !0), this.helpers = new y(this), this.xAxisAnnotations = new b(this), this.yAxisAnnotations = new _(this), this.pointsAnnotations = new w(this), this.w.globals.isBarHorizontal && this.w.config.yaxis[0].reversed && (this.inversedReversedAxis = !0), this.xDivision = this.w.globals.gridWidth / this.w.globals.dataPoints
            }
            return r(e, [{
                key: "drawAxesAnnotations",
                value: function () {
                    var e = this.w;
                    if (e.globals.axisCharts) {
                        for (var t = this.yAxisAnnotations.drawYAxisAnnotations(), n = this.xAxisAnnotations.drawXAxisAnnotations(), i = this.pointsAnnotations.drawPointAnnotations(), a = e.config.chart.animations.enabled, r = [t, n, i], s = [n.node, t.node, i.node], o = 0; o < 3; o++) e.globals.dom.elGraphical.add(r[o]), !a || e.globals.resized || e.globals.dataChanged || "scatter" !== e.config.chart.type && "bubble" !== e.config.chart.type && e.globals.dataPoints > 1 && s[o].classList.add("apexcharts-element-hidden"), e.globals.delayedElements.push({
                            el: s[o],
                            index: 0
                        });
                        this.helpers.annotationsBackground()
                    }
                }
            }, {
                key: "drawImageAnnos",
                value: function () {
                    var e = this;
                    this.w.config.annotations.images.map((function (t, n) {
                        e.addImage(t, n)
                    }))
                }
            }, {
                key: "drawTextAnnos",
                value: function () {
                    var e = this;
                    this.w.config.annotations.texts.map((function (t, n) {
                        e.addText(t, n)
                    }))
                }
            }, {
                key: "addXaxisAnnotation",
                value: function (e, t, n) {
                    this.xAxisAnnotations.addXaxisAnnotation(e, t, n)
                }
            }, {
                key: "addYaxisAnnotation",
                value: function (e, t, n) {
                    this.yAxisAnnotations.addYaxisAnnotation(e, t, n)
                }
            }, {
                key: "addPointAnnotation",
                value: function (e, t, n) {
                    this.pointsAnnotations.addPointAnnotation(e, t, n)
                }
            }, {
                key: "addText",
                value: function (e, t) {
                    var n = e.x,
                        i = e.y,
                        a = e.text,
                        r = e.textAnchor,
                        s = e.foreColor,
                        o = e.fontSize,
                        l = e.fontFamily,
                        c = e.fontWeight,
                        u = e.cssClass,
                        d = e.backgroundColor,
                        h = e.borderWidth,
                        f = e.strokeDashArray,
                        p = e.borderRadius,
                        m = e.borderColor,
                        g = e.appendTo,
                        v = void 0 === g ? ".apexcharts-annotations" : g,
                        y = e.paddingLeft,
                        b = void 0 === y ? 4 : y,
                        x = e.paddingRight,
                        _ = void 0 === x ? 4 : x,
                        w = e.paddingBottom,
                        k = void 0 === w ? 2 : w,
                        M = e.paddingTop,
                        L = void 0 === M ? 2 : M,
                        S = this.w,
                        A = this.graphics.drawText({
                            x: n,
                            y: i,
                            text: a,
                            textAnchor: r || "start",
                            fontSize: o || "12px",
                            fontWeight: c || "regular",
                            fontFamily: l || S.config.chart.fontFamily,
                            foreColor: s || S.config.chart.foreColor,
                            cssClass: u
                        }),
                        T = S.globals.dom.baseEl.querySelector(v);
                    T && T.appendChild(A.node);
                    var C = A.bbox();
                    if (a) {
                        var D = this.graphics.drawRect(C.x - b, C.y - L, C.width + b + _, C.height + k + L, p, d || "transparent", 1, h, m, f);
                        T.insertBefore(D.node, A.node)
                    }
                }
            }, {
                key: "addImage",
                value: function (e, t) {
                    var n = this.w,
                        i = e.path,
                        a = e.x,
                        r = void 0 === a ? 0 : a,
                        s = e.y,
                        o = void 0 === s ? 0 : s,
                        l = e.width,
                        c = void 0 === l ? 20 : l,
                        u = e.height,
                        d = void 0 === u ? 20 : u,
                        h = e.appendTo,
                        f = void 0 === h ? ".apexcharts-annotations" : h,
                        p = n.globals.dom.Paper.image(i);
                    p.size(c, d).move(r, o);
                    var m = n.globals.dom.baseEl.querySelector(f);
                    return m && m.appendChild(p.node), p
                }
            }, {
                key: "addXaxisAnnotationExternal",
                value: function (e, t, n) {
                    return this.addAnnotationExternal({
                        params: e,
                        pushToMemory: t,
                        context: n,
                        type: "xaxis",
                        contextMethod: n.addXaxisAnnotation
                    }), n
                }
            }, {
                key: "addYaxisAnnotationExternal",
                value: function (e, t, n) {
                    return this.addAnnotationExternal({
                        params: e,
                        pushToMemory: t,
                        context: n,
                        type: "yaxis",
                        contextMethod: n.addYaxisAnnotation
                    }), n
                }
            }, {
                key: "addPointAnnotationExternal",
                value: function (e, t, n) {
                    return void 0 === this.invertAxis && (this.invertAxis = n.w.globals.isBarHorizontal), this.addAnnotationExternal({
                        params: e,
                        pushToMemory: t,
                        context: n,
                        type: "point",
                        contextMethod: n.addPointAnnotation
                    }), n
                }
            }, {
                key: "addAnnotationExternal",
                value: function (e) {
                    var t = e.params,
                        n = e.pushToMemory,
                        i = e.context,
                        a = e.type,
                        r = e.contextMethod,
                        s = i,
                        o = s.w,
                        l = o.globals.dom.baseEl.querySelector(".apexcharts-".concat(a, "-annotations")),
                        c = l.childNodes.length + 1,
                        u = new M,
                        d = Object.assign({}, "xaxis" === a ? u.xAxisAnnotation : "yaxis" === a ? u.yAxisAnnotation : u.pointAnnotation),
                        h = p.extend(d, t);
                    switch (a) {
                        case "xaxis":
                            this.addXaxisAnnotation(h, l, c);
                            break;
                        case "yaxis":
                            this.addYaxisAnnotation(h, l, c);
                            break;
                        case "point":
                            this.addPointAnnotation(h, l, c)
                    }
                    var f = o.globals.dom.baseEl.querySelector(".apexcharts-".concat(a, "-annotations .apexcharts-").concat(a, "-annotation-label[rel='").concat(c, "']")),
                        m = this.helpers.addBackgroundToAnno(f, h);
                    return m && l.insertBefore(m.node, f), n && o.globals.memory.methodsToExec.push({
                        context: s,
                        id: h.id ? h.id : p.randomId(),
                        method: r,
                        label: "addAnnotation",
                        params: t
                    }), i
                }
            }, {
                key: "clearAnnotations",
                value: function (e) {
                    var t = e.w,
                        n = t.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxis-annotations, .apexcharts-xaxis-annotations, .apexcharts-point-annotations");
                    t.globals.memory.methodsToExec.map((function (e, n) {
                        "addText" !== e.label && "addAnnotation" !== e.label || t.globals.memory.methodsToExec.splice(n, 1)
                    })), n = p.listToArray(n), Array.prototype.forEach.call(n, (function (e) {
                        for (; e.firstChild;) e.removeChild(e.firstChild)
                    }))
                }
            }, {
                key: "removeAnnotation",
                value: function (e, t) {
                    var n = e.w,
                        i = n.globals.dom.baseEl.querySelectorAll(".".concat(t));
                    i && (n.globals.memory.methodsToExec.map((function (e, i) {
                        e.id === t && n.globals.memory.methodsToExec.splice(i, 1)
                    })), Array.prototype.forEach.call(i, (function (e) {
                        e.parentElement.removeChild(e)
                    })))
                }
            }]), e
        }(),
        S = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w, this.opts = null, this.seriesIndex = 0
            }
            return r(e, [{
                key: "clippedImgArea",
                value: function (e) {
                    var t = this.w,
                        n = t.config,
                        i = parseInt(t.globals.gridWidth, 10),
                        a = parseInt(t.globals.gridHeight, 10),
                        r = i > a ? i : a,
                        s = e.image,
                        o = 0,
                        l = 0;
                    void 0 === e.width && void 0 === e.height ? void 0 !== n.fill.image.width && void 0 !== n.fill.image.height ? (o = n.fill.image.width + 1, l = n.fill.image.height) : (o = r + 1, l = r) : (o = e.width, l = e.height);
                    var c = document.createElementNS(t.globals.SVGNS, "pattern");
                    v.setAttrs(c, {
                        id: e.patternID,
                        patternUnits: e.patternUnits ? e.patternUnits : "userSpaceOnUse",
                        width: o + "px",
                        height: l + "px"
                    });
                    var u = document.createElementNS(t.globals.SVGNS, "image");
                    c.appendChild(u), u.setAttributeNS(window.SVG.xlink, "href", s), v.setAttrs(u, {
                        x: 0,
                        y: 0,
                        preserveAspectRatio: "none",
                        width: o + "px",
                        height: l + "px"
                    }), u.style.opacity = e.opacity, t.globals.dom.elDefs.node.appendChild(c)
                }
            }, {
                key: "getSeriesIndex",
                value: function (e) {
                    var t = this.w;
                    return ("bar" === t.config.chart.type || "rangeBar" === t.config.chart.type) && t.config.plotOptions.bar.distributed || "heatmap" === t.config.chart.type || "treemap" === t.config.chart.type ? this.seriesIndex = e.seriesNumber : this.seriesIndex = e.seriesNumber % t.globals.series.length, this.seriesIndex
                }
            }, {
                key: "fillPath",
                value: function (e) {
                    var t = this.w;
                    this.opts = e;
                    var n, i, a, r = this.w.config;
                    this.seriesIndex = this.getSeriesIndex(e);
                    var s = this.getFillColors()[this.seriesIndex];
                    void 0 !== t.globals.seriesColors[this.seriesIndex] && (s = t.globals.seriesColors[this.seriesIndex]), "function" == typeof s && (s = s({
                        seriesIndex: this.seriesIndex,
                        dataPointIndex: e.dataPointIndex,
                        value: e.value,
                        w: t
                    }));
                    var o = this.getFillType(this.seriesIndex),
                        l = Array.isArray(r.fill.opacity) ? r.fill.opacity[this.seriesIndex] : r.fill.opacity;
                    e.color && (s = e.color);
                    var c = s;
                    if (-1 === s.indexOf("rgb") ? s.length < 9 && (c = p.hexToRgba(s, l)) : s.indexOf("rgba") > -1 && (l = p.getOpacityFromRGBA(s)), e.opacity && (l = e.opacity), "pattern" === o && (i = this.handlePatternFill(i, s, l, c)), "gradient" === o && (a = this.handleGradientFill(s, l, this.seriesIndex)), "image" === o) {
                        var u = r.fill.image.src,
                            d = e.patternID ? e.patternID : "";
                        this.clippedImgArea({
                            opacity: l,
                            image: Array.isArray(u) ? e.seriesNumber < u.length ? u[e.seriesNumber] : u[0] : u,
                            width: e.width ? e.width : void 0,
                            height: e.height ? e.height : void 0,
                            patternUnits: e.patternUnits,
                            patternID: "pattern".concat(t.globals.cuid).concat(e.seriesNumber + 1).concat(d)
                        }), n = "url(#pattern".concat(t.globals.cuid).concat(e.seriesNumber + 1).concat(d, ")")
                    } else n = "gradient" === o ? a : "pattern" === o ? i : c;
                    return e.solid && (n = c), n
                }
            }, {
                key: "getFillType",
                value: function (e) {
                    var t = this.w;
                    return Array.isArray(t.config.fill.type) ? t.config.fill.type[e] : t.config.fill.type
                }
            }, {
                key: "getFillColors",
                value: function () {
                    var e = this.w,
                        t = e.config,
                        n = this.opts,
                        i = [];
                    return e.globals.comboCharts ? "line" === e.config.series[this.seriesIndex].type ? Array.isArray(e.globals.stroke.colors) ? i = e.globals.stroke.colors : i.push(e.globals.stroke.colors) : Array.isArray(e.globals.fill.colors) ? i = e.globals.fill.colors : i.push(e.globals.fill.colors) : "line" === t.chart.type ? Array.isArray(e.globals.stroke.colors) ? i = e.globals.stroke.colors : i.push(e.globals.stroke.colors) : Array.isArray(e.globals.fill.colors) ? i = e.globals.fill.colors : i.push(e.globals.fill.colors), void 0 !== n.fillColors && (i = [], Array.isArray(n.fillColors) ? i = n.fillColors.slice() : i.push(n.fillColors)), i
                }
            }, {
                key: "handlePatternFill",
                value: function (e, t, n, i) {
                    var a = this.w.config,
                        r = this.opts,
                        s = new v(this.ctx),
                        o = void 0 === a.fill.pattern.strokeWidth ? Array.isArray(a.stroke.width) ? a.stroke.width[this.seriesIndex] : a.stroke.width : Array.isArray(a.fill.pattern.strokeWidth) ? a.fill.pattern.strokeWidth[this.seriesIndex] : a.fill.pattern.strokeWidth,
                        l = t;
                    return Array.isArray(a.fill.pattern.style) ? void 0 !== a.fill.pattern.style[r.seriesNumber] ? s.drawPattern(a.fill.pattern.style[r.seriesNumber], a.fill.pattern.width, a.fill.pattern.height, l, o, n) : i : s.drawPattern(a.fill.pattern.style, a.fill.pattern.width, a.fill.pattern.height, l, o, n)
                }
            }, {
                key: "handleGradientFill",
                value: function (e, t, n) {
                    var i, a = this.w.config,
                        r = this.opts,
                        s = new v(this.ctx),
                        o = new p,
                        l = a.fill.gradient.type,
                        c = e,
                        u = void 0 === a.fill.gradient.opacityFrom ? t : Array.isArray(a.fill.gradient.opacityFrom) ? a.fill.gradient.opacityFrom[n] : a.fill.gradient.opacityFrom;
                    c.indexOf("rgba") > -1 && (u = p.getOpacityFromRGBA(c));
                    var d = void 0 === a.fill.gradient.opacityTo ? t : Array.isArray(a.fill.gradient.opacityTo) ? a.fill.gradient.opacityTo[n] : a.fill.gradient.opacityTo;
                    if (void 0 === a.fill.gradient.gradientToColors || 0 === a.fill.gradient.gradientToColors.length) i = "dark" === a.fill.gradient.shade ? o.shadeColor(-1 * parseFloat(a.fill.gradient.shadeIntensity), e.indexOf("rgb") > -1 ? p.rgb2hex(e) : e) : o.shadeColor(parseFloat(a.fill.gradient.shadeIntensity), e.indexOf("rgb") > -1 ? p.rgb2hex(e) : e);
                    else if (a.fill.gradient.gradientToColors[r.seriesNumber]) {
                        var h = a.fill.gradient.gradientToColors[r.seriesNumber];
                        i = h, h.indexOf("rgba") > -1 && (d = p.getOpacityFromRGBA(h))
                    } else i = e;
                    if (a.fill.gradient.inverseColors) {
                        var f = c;
                        c = i, i = f
                    }
                    return c.indexOf("rgb") > -1 && (c = p.rgb2hex(c)), i.indexOf("rgb") > -1 && (i = p.rgb2hex(i)), s.drawGradient(l, c, i, u, d, r.size, a.fill.gradient.stops, a.fill.gradient.colorStops, n)
                }
            }]), e
        }(),
        A = function () {
            function e(t, n) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "setGlobalMarkerSize",
                value: function () {
                    var e = this.w;
                    if (e.globals.markers.size = Array.isArray(e.config.markers.size) ? e.config.markers.size : [e.config.markers.size], e.globals.markers.size.length > 0) {
                        if (e.globals.markers.size.length < e.globals.series.length + 1)
                            for (var t = 0; t <= e.globals.series.length; t++) void 0 === e.globals.markers.size[t] && e.globals.markers.size.push(e.globals.markers.size[0])
                    } else e.globals.markers.size = e.config.series.map((function (t) {
                        return e.config.markers.size
                    }))
                }
            }, {
                key: "plotChartMarkers",
                value: function (e, t, n, i) {
                    var a, r = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
                        s = this.w,
                        o = t,
                        l = e,
                        c = null,
                        u = new v(this.ctx);
                    if ((s.globals.markers.size[t] > 0 || r) && (c = u.group({
                            class: r ? "" : "apexcharts-series-markers"
                        })).attr("clip-path", "url(#gridRectMarkerMask".concat(s.globals.cuid, ")")), Array.isArray(l.x))
                        for (var d = 0; d < l.x.length; d++) {
                            var h = n;
                            1 === n && 0 === d && (h = 0), 1 === n && 1 === d && (h = 1);
                            var f = "apexcharts-marker";
                            "line" !== s.config.chart.type && "area" !== s.config.chart.type || s.globals.comboCharts || s.config.tooltip.intersect || (f += " no-pointer-events");
                            var m = Array.isArray(s.config.markers.size) ? s.globals.markers.size[t] > 0 : s.config.markers.size > 0;
                            if (m || r) {
                                p.isNumber(l.y[d]) ? f += " w".concat(p.randomId()) : f = "apexcharts-nullpoint";
                                var y = this.getMarkerConfig({
                                    cssClass: f,
                                    seriesIndex: t,
                                    dataPointIndex: h
                                });
                                s.config.series[o].data[h] && (s.config.series[o].data[h].fillColor && (y.pointFillColor = s.config.series[o].data[h].fillColor), s.config.series[o].data[h].strokeColor && (y.pointStrokeColor = s.config.series[o].data[h].strokeColor)), i && (y.pSize = i), (a = u.drawMarker(l.x[d], l.y[d], y)).attr("rel", h), a.attr("j", h), a.attr("index", t), a.node.setAttribute("default-marker-size", y.pSize);
                                var b = new g(this.ctx);
                                b.setSelectionFilter(a, t, h), this.addEvents(a), c && c.add(a)
                            } else void 0 === s.globals.pointsArray[t] && (s.globals.pointsArray[t] = []), s.globals.pointsArray[t].push([l.x[d], l.y[d]])
                        }
                    return c
                }
            }, {
                key: "getMarkerConfig",
                value: function (e) {
                    var t = e.cssClass,
                        n = e.seriesIndex,
                        i = e.dataPointIndex,
                        a = void 0 === i ? null : i,
                        r = e.finishRadius,
                        s = void 0 === r ? null : r,
                        o = this.w,
                        l = this.getMarkerStyle(n),
                        c = o.globals.markers.size[n],
                        u = o.config.markers;
                    return null !== a && u.discrete.length && u.discrete.map((function (e) {
                        e.seriesIndex === n && e.dataPointIndex === a && (l.pointStrokeColor = e.strokeColor, l.pointFillColor = e.fillColor, c = e.size, l.pointShape = e.shape)
                    })), {
                        pSize: null === s ? c : s,
                        pRadius: u.radius,
                        width: Array.isArray(u.width) ? u.width[n] : u.width,
                        height: Array.isArray(u.height) ? u.height[n] : u.height,
                        pointStrokeWidth: Array.isArray(u.strokeWidth) ? u.strokeWidth[n] : u.strokeWidth,
                        pointStrokeColor: l.pointStrokeColor,
                        pointFillColor: l.pointFillColor,
                        shape: l.pointShape || (Array.isArray(u.shape) ? u.shape[n] : u.shape),
                        class: t,
                        pointStrokeOpacity: Array.isArray(u.strokeOpacity) ? u.strokeOpacity[n] : u.strokeOpacity,
                        pointStrokeDashArray: Array.isArray(u.strokeDashArray) ? u.strokeDashArray[n] : u.strokeDashArray,
                        pointFillOpacity: Array.isArray(u.fillOpacity) ? u.fillOpacity[n] : u.fillOpacity,
                        seriesIndex: n
                    }
                }
            }, {
                key: "addEvents",
                value: function (e) {
                    var t = this.w,
                        n = new v(this.ctx);
                    e.node.addEventListener("mouseenter", n.pathMouseEnter.bind(this.ctx, e)), e.node.addEventListener("mouseleave", n.pathMouseLeave.bind(this.ctx, e)), e.node.addEventListener("mousedown", n.pathMouseDown.bind(this.ctx, e)), e.node.addEventListener("click", t.config.markers.onClick), e.node.addEventListener("dblclick", t.config.markers.onDblClick), e.node.addEventListener("touchstart", n.pathMouseDown.bind(this.ctx, e), {
                        passive: !0
                    })
                }
            }, {
                key: "getMarkerStyle",
                value: function (e) {
                    var t = this.w,
                        n = t.globals.markers.colors,
                        i = t.config.markers.strokeColor || t.config.markers.strokeColors;
                    return {
                        pointStrokeColor: Array.isArray(i) ? i[e] : i,
                        pointFillColor: Array.isArray(n) ? n[e] : n
                    }
                }
            }]), e
        }(),
        T = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w, this.initialAnim = this.w.config.chart.animations.enabled, this.dynamicAnim = this.initialAnim && this.w.config.chart.animations.dynamicAnimation.enabled
            }
            return r(e, [{
                key: "draw",
                value: function (e, t, n) {
                    var i = this.w,
                        a = new v(this.ctx),
                        r = n.realIndex,
                        s = n.pointsPos,
                        o = n.zRatio,
                        l = n.elParent,
                        c = a.group({
                            class: "apexcharts-series-markers apexcharts-series-".concat(i.config.chart.type)
                        });
                    if (c.attr("clip-path", "url(#gridRectMarkerMask".concat(i.globals.cuid, ")")), Array.isArray(s.x))
                        for (var u = 0; u < s.x.length; u++) {
                            var d = t + 1,
                                h = !0;
                            0 === t && 0 === u && (d = 0), 0 === t && 1 === u && (d = 1);
                            var f = 0,
                                p = i.globals.markers.size[r];
                            if (o !== 1 / 0) {
                                p = i.globals.seriesZ[r][d] / o;
                                var m = i.config.plotOptions.bubble;
                                m.minBubbleRadius && p < m.minBubbleRadius && (p = m.minBubbleRadius), m.maxBubbleRadius && p > m.maxBubbleRadius && (p = m.maxBubbleRadius)
                            }
                            i.config.chart.animations.enabled || (f = p);
                            var g = s.x[u],
                                y = s.y[u];
                            if (f = f || 0, null !== y && void 0 !== i.globals.series[r][d] || (h = !1), h) {
                                var b = this.drawPoint(g, y, f, p, r, d, t);
                                c.add(b)
                            }
                            l.add(c)
                        }
                }
            }, {
                key: "drawPoint",
                value: function (e, t, n, i, a, r, s) {
                    var o = this.w,
                        l = a,
                        c = new m(this.ctx),
                        u = new g(this.ctx),
                        d = new S(this.ctx),
                        h = new A(this.ctx),
                        f = new v(this.ctx),
                        p = h.getMarkerConfig({
                            cssClass: "apexcharts-marker",
                            seriesIndex: l,
                            dataPointIndex: r,
                            finishRadius: "bubble" === o.config.chart.type || o.globals.comboCharts && o.config.series[a] && "bubble" === o.config.series[a].type ? i : null
                        });
                    i = p.pSize;
                    var y, b = d.fillPath({
                        seriesNumber: a,
                        dataPointIndex: r,
                        color: p.pointFillColor,
                        patternUnits: "objectBoundingBox",
                        value: o.globals.series[a][s]
                    });
                    if ("circle" === p.shape ? y = f.drawCircle(n) : "square" !== p.shape && "rect" !== p.shape || (y = f.drawRect(0, 0, p.width - p.pointStrokeWidth / 2, p.height - p.pointStrokeWidth / 2, p.pRadius)), o.config.series[l].data[r] && o.config.series[l].data[r].fillColor && (b = o.config.series[l].data[r].fillColor), y.attr({
                            x: e - p.width / 2 - p.pointStrokeWidth / 2,
                            y: t - p.height / 2 - p.pointStrokeWidth / 2,
                            cx: e,
                            cy: t,
                            fill: b,
                            "fill-opacity": p.pointFillOpacity,
                            stroke: p.pointStrokeColor,
                            r: i,
                            "stroke-width": p.pointStrokeWidth,
                            "stroke-dasharray": p.pointStrokeDashArray,
                            "stroke-opacity": p.pointStrokeOpacity
                        }), o.config.chart.dropShadow.enabled) {
                        var x = o.config.chart.dropShadow;
                        u.dropShadow(y, x, a)
                    }
                    if (!this.initialAnim || o.globals.dataChanged || o.globals.resized) o.globals.animationEnded = !0;
                    else {
                        var _ = o.config.chart.animations.speed;
                        c.animateMarker(y, 0, "circle" === p.shape ? i : {
                            width: p.width,
                            height: p.height
                        }, _, o.globals.easing, (function () {
                            window.setTimeout((function () {
                                c.animationCompleted(y)
                            }), 100)
                        }))
                    }
                    if (o.globals.dataChanged && "circle" === p.shape)
                        if (this.dynamicAnim) {
                            var w, k, M, L, T = o.config.chart.animations.dynamicAnimation.speed;
                            null != (L = o.globals.previousPaths[a] && o.globals.previousPaths[a][s]) && (w = L.x, k = L.y, M = void 0 !== L.r ? L.r : i);
                            for (var C = 0; C < o.globals.collapsedSeries.length; C++) o.globals.collapsedSeries[C].index === a && (T = 1, i = 0);
                            0 === e && 0 === t && (i = 0), c.animateCircle(y, {
                                cx: w,
                                cy: k,
                                r: M
                            }, {
                                cx: e,
                                cy: t,
                                r: i
                            }, T, o.globals.easing)
                        } else y.attr({
                            r: i
                        });
                    return y.attr({
                        rel: r,
                        j: r,
                        index: a,
                        "default-marker-size": i
                    }), u.setSelectionFilter(y, a, r), h.addEvents(y), y.node.classList.add("apexcharts-marker"), y
                }
            }, {
                key: "centerTextInBubble",
                value: function (e) {
                    var t = this.w;
                    return {
                        y: e += parseInt(t.config.dataLabels.style.fontSize, 10) / 4
                    }
                }
            }]), e
        }(),
        C = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "dataLabelsCorrection",
                value: function (e, t, n, i, a, r, s) {
                    var o = this.w,
                        l = !1,
                        c = new v(this.ctx).getTextRects(n, s),
                        u = c.width,
                        d = c.height;
                    t < 0 && (t = 0), t > o.globals.gridHeight + d && (t = o.globals.gridHeight + d / 2), void 0 === o.globals.dataLabelsRects[i] && (o.globals.dataLabelsRects[i] = []), o.globals.dataLabelsRects[i].push({
                        x: e,
                        y: t,
                        width: u,
                        height: d
                    });
                    var h = o.globals.dataLabelsRects[i].length - 2,
                        f = void 0 !== o.globals.lastDrawnDataLabelsIndexes[i] ? o.globals.lastDrawnDataLabelsIndexes[i][o.globals.lastDrawnDataLabelsIndexes[i].length - 1] : 0;
                    if (void 0 !== o.globals.dataLabelsRects[i][h]) {
                        var p = o.globals.dataLabelsRects[i][f];
                        (e > p.x + p.width + 2 || t > p.y + p.height + 2 || e + u < p.x) && (l = !0)
                    }
                    return (0 === a || r) && (l = !0), {
                        x: e,
                        y: t,
                        textRects: c,
                        drawnextLabel: l
                    }
                }
            }, {
                key: "drawDataLabel",
                value: function (e, t, n) {
                    var i = this,
                        a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 2,
                        r = this.w,
                        s = new v(this.ctx),
                        o = r.config.dataLabels,
                        l = 0,
                        c = 0,
                        u = n,
                        d = null;
                    if (!o.enabled || !Array.isArray(e.x)) return d;
                    d = s.group({
                        class: "apexcharts-data-labels"
                    });
                    for (var h = 0; h < e.x.length; h++)
                        if (l = e.x[h] + o.offsetX, c = e.y[h] + o.offsetY + a, !isNaN(l)) {
                            1 === n && 0 === h && (u = 0), 1 === n && 1 === h && (u = 1);
                            var f = r.globals.series[t][u],
                                p = "",
                                m = function (e) {
                                    return r.config.dataLabels.formatter(e, {
                                        ctx: i.ctx,
                                        seriesIndex: t,
                                        dataPointIndex: u,
                                        w: r
                                    })
                                };
                            if ("bubble" === r.config.chart.type) {
                                p = m(f = r.globals.seriesZ[t][u]), c = e.y[h];
                                var g = new T(this.ctx),
                                    y = g.centerTextInBubble(c, t, u);
                                c = y.y
                            } else void 0 !== f && (p = m(f));
                            this.plotDataLabelsText({
                                x: l,
                                y: c,
                                text: p,
                                i: t,
                                j: u,
                                parent: d,
                                offsetCorrection: !0,
                                dataLabelsConfig: r.config.dataLabels
                            })
                        } return d
                }
            }, {
                key: "plotDataLabelsText",
                value: function (e) {
                    var t = this.w,
                        n = new v(this.ctx),
                        i = e.x,
                        a = e.y,
                        r = e.i,
                        s = e.j,
                        o = e.text,
                        l = e.textAnchor,
                        c = e.fontSize,
                        u = e.parent,
                        d = e.dataLabelsConfig,
                        h = e.color,
                        f = e.alwaysDrawDataLabel,
                        p = e.offsetCorrection;
                    if (!(Array.isArray(t.config.dataLabels.enabledOnSeries) && t.config.dataLabels.enabledOnSeries.indexOf(r) < 0)) {
                        var m = {
                            x: i,
                            y: a,
                            drawnextLabel: !0,
                            textRects: null
                        };
                        p && (m = this.dataLabelsCorrection(i, a, o, r, s, f, parseInt(d.style.fontSize, 10))), t.globals.zoomed || (i = m.x, a = m.y), m.textRects && (i < -10 - m.textRects.width || i > t.globals.gridWidth + m.textRects.width + 10) && (o = "");
                        var y = t.globals.dataLabels.style.colors[r];
                        (("bar" === t.config.chart.type || "rangeBar" === t.config.chart.type) && t.config.plotOptions.bar.distributed || t.config.dataLabels.distributed) && (y = t.globals.dataLabels.style.colors[s]), "function" == typeof y && (y = y({
                            series: t.globals.series,
                            seriesIndex: r,
                            dataPointIndex: s,
                            w: t
                        })), h && (y = h);
                        var b = d.offsetX,
                            x = d.offsetY;
                        if ("bar" !== t.config.chart.type && "rangeBar" !== t.config.chart.type || (b = 0, x = 0), m.drawnextLabel) {
                            var _ = n.drawText({
                                width: 100,
                                height: parseInt(d.style.fontSize, 10),
                                x: i + b,
                                y: a + x,
                                foreColor: y,
                                textAnchor: l || d.textAnchor,
                                text: o,
                                fontSize: c || d.style.fontSize,
                                fontFamily: d.style.fontFamily,
                                fontWeight: d.style.fontWeight || "normal"
                            });
                            if (_.attr({
                                    class: "apexcharts-datalabel",
                                    cx: i,
                                    cy: a
                                }), d.dropShadow.enabled) {
                                var w = d.dropShadow;
                                new g(this.ctx).dropShadow(_, w)
                            }
                            u.add(_), void 0 === t.globals.lastDrawnDataLabelsIndexes[r] && (t.globals.lastDrawnDataLabelsIndexes[r] = []), t.globals.lastDrawnDataLabelsIndexes[r].push(s)
                        }
                    }
                }
            }, {
                key: "addBackgroundToDataLabel",
                value: function (e, t) {
                    var n = this.w,
                        i = n.config.dataLabels.background,
                        a = i.padding,
                        r = i.padding / 2,
                        s = t.width,
                        o = t.height,
                        l = new v(this.ctx).drawRect(t.x - a, t.y - r / 2, s + 2 * a, o + r, i.borderRadius, "transparent" === n.config.chart.background ? "#fff" : n.config.chart.background, i.opacity, i.borderWidth, i.borderColor);
                    return i.dropShadow.enabled && new g(this.ctx).dropShadow(l, i.dropShadow), l
                }
            }, {
                key: "dataLabelsBackground",
                value: function () {
                    var e = this.w;
                    if ("bubble" !== e.config.chart.type)
                        for (var t = e.globals.dom.baseEl.querySelectorAll(".apexcharts-datalabels text"), n = 0; n < t.length; n++) {
                            var i = t[n],
                                a = i.getBBox(),
                                r = null;
                            if (a.width && a.height && (r = this.addBackgroundToDataLabel(i, a)), r) {
                                i.parentNode.insertBefore(r.node, i);
                                var s = i.getAttribute("fill");
                                !e.config.chart.animations.enabled || e.globals.resized || e.globals.dataChanged ? r.attr({
                                    fill: s
                                }) : r.animate().attr({
                                    fill: s
                                }), i.setAttribute("fill", e.config.dataLabels.background.foreColor)
                            }
                        }
                }
            }, {
                key: "bringForward",
                value: function () {
                    for (var e = this.w, t = e.globals.dom.baseEl.querySelectorAll(".apexcharts-datalabels"), n = e.globals.dom.baseEl.querySelector(".apexcharts-plot-series:last-child"), i = 0; i < t.length; i++) n && n.insertBefore(t[i], n.nextSibling)
                }
            }]), e
        }(),
        D = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.barCtx = t
            }
            return r(e, [{
                key: "handleBarDataLabels",
                value: function (e) {
                    var t = e.x,
                        n = e.y,
                        i = e.y1,
                        a = e.y2,
                        r = e.i,
                        s = e.j,
                        o = e.realIndex,
                        l = e.series,
                        c = e.barHeight,
                        u = e.barWidth,
                        d = e.barYPosition,
                        h = e.visibleSeries,
                        f = e.renderedPath,
                        p = this.w,
                        m = new v(this.barCtx.ctx),
                        g = Array.isArray(this.barCtx.strokeWidth) ? this.barCtx.strokeWidth[o] : this.barCtx.strokeWidth,
                        y = t + parseFloat(u * h),
                        b = n + parseFloat(c * h);
                    p.globals.isXNumeric && !p.globals.isBarHorizontal && (y = t + parseFloat(u * (h + 1)), b = n + parseFloat(c * (h + 1)) - g);
                    var x, _ = t,
                        w = n,
                        k = p.config.dataLabels,
                        M = this.barCtx.barOptions.dataLabels;
                    void 0 !== d && this.barCtx.isRangeBar && (b = d, w = d);
                    var L = k.offsetX,
                        S = k.offsetY,
                        A = {
                            width: 0,
                            height: 0
                        };
                    if (p.config.dataLabels.enabled) {
                        var T = this.barCtx.series[r][s];
                        A = m.getTextRects(p.globals.yLabelFormatters[0](T), parseFloat(k.style.fontSize))
                    }
                    var C = {
                        x: t,
                        y: n,
                        i: r,
                        j: s,
                        renderedPath: f,
                        bcx: y,
                        bcy: b,
                        barHeight: c,
                        barWidth: u,
                        textRects: A,
                        strokeWidth: g,
                        dataLabelsX: _,
                        dataLabelsY: w,
                        barDataLabelsConfig: M,
                        offX: L,
                        offY: S
                    };
                    return x = this.barCtx.isHorizontal ? this.calculateBarsDataLabelsPosition(C) : this.calculateColumnsDataLabelsPosition(C), f.attr({
                        cy: x.bcy,
                        cx: x.bcx,
                        j: s,
                        val: l[r][s],
                        barHeight: c,
                        barWidth: u
                    }), this.drawCalculatedDataLabels({
                        x: x.dataLabelsX,
                        y: x.dataLabelsY,
                        val: this.barCtx.isRangeBar ? [i, a] : l[r][s],
                        i: o,
                        j: s,
                        barWidth: u,
                        barHeight: c,
                        textRects: A,
                        dataLabelsConfig: k
                    })
                }
            }, {
                key: "calculateColumnsDataLabelsPosition",
                value: function (e) {
                    var t, n = this.w,
                        i = e.i,
                        a = e.j,
                        r = e.y,
                        s = e.bcx,
                        o = e.barWidth,
                        l = e.barHeight,
                        c = e.textRects,
                        u = e.dataLabelsY,
                        d = e.barDataLabelsConfig,
                        h = e.strokeWidth,
                        f = e.offX,
                        p = e.offY;
                    l = Math.abs(l);
                    var m = "vertical" === n.config.plotOptions.bar.dataLabels.orientation;
                    s -= h / 2;
                    var g = n.globals.gridWidth / n.globals.dataPoints;
                    t = n.globals.isXNumeric ? s - o / 2 + f : s - g + o / 2 + f, m && (t = t + c.height / 2 - h / 2 - 2);
                    var v = this.barCtx.series[i][a] < 0,
                        y = r;
                    switch (this.barCtx.isReversed && (y = r - l + (v ? 2 * l : 0), r -= l), d.position) {
                        case "center":
                            u = m ? v ? y + l / 2 + p : y + l / 2 - p : v ? y - l / 2 + c.height / 2 + p : y + l / 2 + c.height / 2 - p;
                            break;
                        case "bottom":
                            u = m ? v ? y + l + p : y + l - p : v ? y - l + c.height + h + p : y + l - c.height / 2 + h - p;
                            break;
                        case "top":
                            u = m ? v ? y + p : y - p : v ? y - c.height / 2 - p : y + c.height + p
                    }
                    return n.config.chart.stacked || (u < 0 ? u = 0 + h : u + c.height / 3 > n.globals.gridHeight && (u = n.globals.gridHeight - h)), {
                        bcx: s,
                        bcy: r,
                        dataLabelsX: t,
                        dataLabelsY: u
                    }
                }
            }, {
                key: "calculateBarsDataLabelsPosition",
                value: function (e) {
                    var t = this.w,
                        n = e.x,
                        i = e.i,
                        a = e.j,
                        r = e.bcy,
                        s = e.barHeight,
                        o = e.barWidth,
                        l = e.textRects,
                        c = e.dataLabelsX,
                        u = e.strokeWidth,
                        d = e.barDataLabelsConfig,
                        h = e.offX,
                        f = e.offY,
                        p = t.globals.gridHeight / t.globals.dataPoints;
                    o = Math.abs(o);
                    var m = r - (this.barCtx.isRangeBar ? 0 : p) + s / 2 + l.height / 2 + f - 3,
                        g = this.barCtx.series[i][a] < 0,
                        v = n;
                    switch (this.barCtx.isReversed && (v = n + o - (g ? 2 * o : 0), n = t.globals.gridWidth - o), d.position) {
                        case "center":
                            c = g ? v + o / 2 - h : Math.max(l.width / 2, v - o / 2) + h;
                            break;
                        case "bottom":
                            c = g ? v + o - u - Math.round(l.width / 2) - h : v - o + u + Math.round(l.width / 2) + h;
                            break;
                        case "top":
                            c = g ? v - u + Math.round(l.width / 2) - h : v - u - Math.round(l.width / 2) + h
                    }
                    return t.config.chart.stacked || (c < 0 ? c = c + l.width + u : c + l.width / 2 > t.globals.gridWidth && (c = t.globals.gridWidth - l.width - u)), {
                        bcx: n,
                        bcy: r,
                        dataLabelsX: c,
                        dataLabelsY: m
                    }
                }
            }, {
                key: "drawCalculatedDataLabels",
                value: function (e) {
                    var n = e.x,
                        i = e.y,
                        a = e.val,
                        r = e.i,
                        s = e.j,
                        o = e.textRects,
                        l = e.barHeight,
                        c = e.barWidth,
                        u = e.dataLabelsConfig,
                        d = this.w,
                        h = "rotate(0)";
                    "vertical" === d.config.plotOptions.bar.dataLabels.orientation && (h = "rotate(-90, ".concat(n, ", ").concat(i, ")"));
                    var f = new C(this.barCtx.ctx),
                        p = new v(this.barCtx.ctx),
                        m = u.formatter,
                        g = null,
                        y = d.globals.collapsedSeriesIndices.indexOf(r) > -1;
                    if (u.enabled && !y) {
                        g = p.group({
                            class: "apexcharts-data-labels",
                            transform: h
                        });
                        var b = "";
                        void 0 !== a && (b = m(a, {
                            seriesIndex: r,
                            dataPointIndex: s,
                            w: d
                        }));
                        var x = d.globals.series[r][s] < 0,
                            _ = d.config.plotOptions.bar.dataLabels.position;
                        "vertical" === d.config.plotOptions.bar.dataLabels.orientation && ("top" === _ && (u.textAnchor = x ? "end" : "start"), "center" === _ && (u.textAnchor = "middle"), "bottom" === _ && (u.textAnchor = x ? "end" : "start")), this.barCtx.isRangeBar && this.barCtx.barOptions.dataLabels.hideOverflowingLabels && c < p.getTextRects(b, parseFloat(u.style.fontSize)).width && (b = ""), d.config.chart.stacked && this.barCtx.barOptions.dataLabels.hideOverflowingLabels && (this.barCtx.isHorizontal ? o.width / 1.6 > Math.abs(c) && (b = "") : o.height / 1.6 > Math.abs(l) && (b = ""));
                        var w = t({}, u);
                        this.barCtx.isHorizontal && a < 0 && ("start" === u.textAnchor ? w.textAnchor = "end" : "end" === u.textAnchor && (w.textAnchor = "start")), f.plotDataLabelsText({
                            x: n,
                            y: i,
                            text: b,
                            i: r,
                            j: s,
                            parent: g,
                            dataLabelsConfig: w,
                            alwaysDrawDataLabel: !0,
                            offsetCorrection: !0
                        })
                    }
                    return g
                }
            }]), e
        }(),
        E = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w, this.legendInactiveClass = "legend-mouseover-inactive"
            }
            return r(e, [{
                key: "getAllSeriesEls",
                value: function () {
                    return this.w.globals.dom.baseEl.getElementsByClassName("apexcharts-series")
                }
            }, {
                key: "getSeriesByName",
                value: function (e) {
                    return this.w.globals.dom.baseEl.querySelector(".apexcharts-inner .apexcharts-series[seriesName='".concat(p.escapeString(e), "']"))
                }
            }, {
                key: "isSeriesHidden",
                value: function (e) {
                    var t = this.getSeriesByName(e),
                        n = parseInt(t.getAttribute("data:realIndex"), 10);
                    return {
                        isHidden: t.classList.contains("apexcharts-series-collapsed"),
                        realIndex: n
                    }
                }
            }, {
                key: "addCollapsedClassToSeries",
                value: function (e, t) {
                    var n = this.w;

                    function i(n) {
                        for (var i = 0; i < n.length; i++) n[i].index === t && e.node.classList.add("apexcharts-series-collapsed")
                    }
                    i(n.globals.collapsedSeries), i(n.globals.ancillaryCollapsedSeries)
                }
            }, {
                key: "toggleSeries",
                value: function (e) {
                    var t = this.isSeriesHidden(e);
                    return this.ctx.legend.legendHelpers.toggleDataSeries(t.realIndex, t.isHidden), t.isHidden
                }
            }, {
                key: "showSeries",
                value: function (e) {
                    var t = this.isSeriesHidden(e);
                    t.isHidden && this.ctx.legend.legendHelpers.toggleDataSeries(t.realIndex, !0)
                }
            }, {
                key: "hideSeries",
                value: function (e) {
                    var t = this.isSeriesHidden(e);
                    t.isHidden || this.ctx.legend.legendHelpers.toggleDataSeries(t.realIndex, !1)
                }
            }, {
                key: "resetSeries",
                value: function () {
                    var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
                        t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                        n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
                        i = this.w,
                        a = p.clone(i.globals.initialSeries);
                    i.globals.previousPaths = [], n ? (i.globals.collapsedSeries = [], i.globals.ancillaryCollapsedSeries = [], i.globals.collapsedSeriesIndices = [], i.globals.ancillaryCollapsedSeriesIndices = []) : a = this.emptyCollapsedSeries(a), i.config.series = a, e && (t && (i.globals.zoomed = !1, this.ctx.updateHelpers.revertDefaultAxisMinMax()), this.ctx.updateHelpers._updateSeries(a, i.config.chart.animations.dynamicAnimation.enabled))
                }
            }, {
                key: "emptyCollapsedSeries",
                value: function (e) {
                    for (var t = this.w, n = 0; n < e.length; n++) t.globals.collapsedSeriesIndices.indexOf(n) > -1 && (e[n].data = []);
                    return e
                }
            }, {
                key: "toggleSeriesOnHover",
                value: function (e, t) {
                    var n = this.w;
                    t || (t = e.target);
                    var i = n.globals.dom.baseEl.querySelectorAll(".apexcharts-series, .apexcharts-datalabels");
                    if ("mousemove" === e.type) {
                        var a = parseInt(t.getAttribute("rel"), 10) - 1,
                            r = null,
                            s = null;
                        n.globals.axisCharts || "radialBar" === n.config.chart.type ? n.globals.axisCharts ? (r = n.globals.dom.baseEl.querySelector(".apexcharts-series[data\\:realIndex='".concat(a, "']")), s = n.globals.dom.baseEl.querySelector(".apexcharts-datalabels[data\\:realIndex='".concat(a, "']"))) : r = n.globals.dom.baseEl.querySelector(".apexcharts-series[rel='".concat(a + 1, "']")) : r = n.globals.dom.baseEl.querySelector(".apexcharts-series[rel='".concat(a + 1, "'] path"));
                        for (var o = 0; o < i.length; o++) i[o].classList.add(this.legendInactiveClass);
                        null !== r && (n.globals.axisCharts || r.parentNode.classList.remove(this.legendInactiveClass), r.classList.remove(this.legendInactiveClass), null !== s && s.classList.remove(this.legendInactiveClass))
                    } else if ("mouseout" === e.type)
                        for (var l = 0; l < i.length; l++) i[l].classList.remove(this.legendInactiveClass)
                }
            }, {
                key: "highlightRangeInSeries",
                value: function (e, t) {
                    var n = this,
                        i = this.w,
                        a = i.globals.dom.baseEl.getElementsByClassName("apexcharts-heatmap-rect"),
                        r = function (e) {
                            for (var t = 0; t < a.length; t++) a[t].classList[e](n.legendInactiveClass)
                        };
                    if ("mousemove" === e.type) {
                        var s = parseInt(t.getAttribute("rel"), 10) - 1;
                        r("add"),
                            function (e) {
                                for (var t = 0; t < a.length; t++) {
                                    var i = parseInt(a[t].getAttribute("val"), 10);
                                    i >= e.from && i <= e.to && a[t].classList.remove(n.legendInactiveClass)
                                }
                            }(i.config.plotOptions.heatmap.colorScale.ranges[s])
                    } else "mouseout" === e.type && r("remove")
                }
            }, {
                key: "getActiveConfigSeriesIndex",
                value: function () {
                    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "asc",
                        n = this.w,
                        i = 0;
                    if (n.config.series.length > 1)
                        for (var a = n.config.series.map((function (t, i) {
                                var a = !1;
                                return e && (a = "bar" === n.config.series[i].type || "column" === n.config.series[i].type), t.data && t.data.length > 0 && !a ? i : -1
                            })), r = "asc" === t ? 0 : a.length - 1;
                            "asc" === t ? r < a.length : r >= 0;
                            "asc" === t ? r++ : r--)
                            if (-1 !== a[r]) {
                                i = a[r];
                                break
                            } return i
                }
            }, {
                key: "getPreviousPaths",
                value: function () {
                    var e = this.w;

                    function t(t, n, i) {
                        for (var a = t[n].childNodes, r = {
                                type: i,
                                paths: [],
                                realIndex: t[n].getAttribute("data:realIndex")
                            }, s = 0; s < a.length; s++)
                            if (a[s].hasAttribute("pathTo")) {
                                var o = a[s].getAttribute("pathTo");
                                r.paths.push({
                                    d: o
                                })
                            } e.globals.previousPaths.push(r)
                    }
                    e.globals.previousPaths = [], ["line", "area", "bar", "rangebar", "candlestick", "radar"].forEach((function (n) {
                        for (var i, a = (i = n, e.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(i, "-series .apexcharts-series"))), r = 0; r < a.length; r++) t(a, r, n)
                    })), this.handlePrevBubbleScatterPaths("bubble"), this.handlePrevBubbleScatterPaths("scatter");
                    var n = e.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e.config.chart.type, " .apexcharts-series"));
                    if (n.length > 0)
                        for (var i = function (t) {
                                for (var n = e.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e.config.chart.type, " .apexcharts-series[data\\:realIndex='").concat(t, "'] rect")), i = [], a = function (e) {
                                        var t = function (t) {
                                                return n[e].getAttribute(t)
                                            },
                                            a = {
                                                x: parseFloat(t("x")),
                                                y: parseFloat(t("y")),
                                                width: parseFloat(t("width")),
                                                height: parseFloat(t("height"))
                                            };
                                        i.push({
                                            rect: a,
                                            color: n[e].getAttribute("color")
                                        })
                                    }, r = 0; r < n.length; r++) a(r);
                                e.globals.previousPaths.push(i)
                            }, a = 0; a < n.length; a++) i(a);
                    e.globals.axisCharts || (e.globals.previousPaths = e.globals.series)
                }
            }, {
                key: "handlePrevBubbleScatterPaths",
                value: function (e) {
                    var t = this.w,
                        n = t.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e, "-series .apexcharts-series"));
                    if (n.length > 0)
                        for (var i = 0; i < n.length; i++) {
                            for (var a = t.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e, "-series .apexcharts-series[data\\:realIndex='").concat(i, "'] circle")), r = [], s = 0; s < a.length; s++) r.push({
                                x: a[s].getAttribute("cx"),
                                y: a[s].getAttribute("cy"),
                                r: a[s].getAttribute("r")
                            });
                            t.globals.previousPaths.push(r)
                        }
                }
            }, {
                key: "clearPreviousPaths",
                value: function () {
                    var e = this.w;
                    e.globals.previousPaths = [], e.globals.allSeriesCollapsed = !1
                }
            }, {
                key: "handleNoData",
                value: function () {
                    var e = this.w,
                        t = e.config.noData,
                        n = new v(this.ctx),
                        i = e.globals.svgWidth / 2,
                        a = e.globals.svgHeight / 2,
                        r = "middle";
                    if (e.globals.noData = !0, e.globals.animationEnded = !0, "left" === t.align ? (i = 10, r = "start") : "right" === t.align && (i = e.globals.svgWidth - 10, r = "end"), "top" === t.verticalAlign ? a = 50 : "bottom" === t.verticalAlign && (a = e.globals.svgHeight - 50), i += t.offsetX, a = a + parseInt(t.style.fontSize, 10) + 2 + t.offsetY, void 0 !== t.text && "" !== t.text) {
                        var s = n.drawText({
                            x: i,
                            y: a,
                            text: t.text,
                            textAnchor: r,
                            fontSize: t.style.fontSize,
                            fontFamily: t.style.fontFamily,
                            foreColor: t.style.color,
                            opacity: 1,
                            class: "apexcharts-text-nodata"
                        });
                        e.globals.dom.Paper.add(s)
                    }
                }
            }, {
                key: "setNullSeriesToZeroValues",
                value: function (e) {
                    for (var t = this.w, n = 0; n < e.length; n++)
                        if (0 === e[n].length)
                            for (var i = 0; i < e[t.globals.maxValsInArrayIndex].length; i++) e[n].push(0);
                    return e
                }
            }, {
                key: "hasAllSeriesEqualX",
                value: function () {
                    for (var e = !0, t = this.w, n = this.filteredSeriesX(), i = 0; i < n.length - 1; i++)
                        if (n[i][0] !== n[i + 1][0]) {
                            e = !1;
                            break
                        } return t.globals.allSeriesHasEqualX = e, e
                }
            }, {
                key: "filteredSeriesX",
                value: function () {
                    return this.w.globals.seriesX.map((function (e) {
                        return e.length > 0 ? e : []
                    }))
                }
            }]), e
        }(),
        O = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.barCtx = t
            }
            return r(e, [{
                key: "initVariables",
                value: function (e) {
                    var t = this.w;
                    this.barCtx.series = e, this.barCtx.totalItems = 0, this.barCtx.seriesLen = 0, this.barCtx.visibleI = -1, this.barCtx.visibleItems = 1;
                    for (var n = 0; n < e.length; n++)
                        if (e[n].length > 0 && (this.barCtx.seriesLen = this.barCtx.seriesLen + 1, this.barCtx.totalItems += e[n].length), t.globals.isXNumeric)
                            for (var i = 0; i < e[n].length; i++) t.globals.seriesX[n][i] > t.globals.minX && t.globals.seriesX[n][i] < t.globals.maxX && this.barCtx.visibleItems++;
                        else this.barCtx.visibleItems = t.globals.dataPoints;
                    0 === this.barCtx.seriesLen && (this.barCtx.seriesLen = 1), this.barCtx.zeroSerieses = [], this.barCtx.radiusOnSeriesNumber = e.length - 1, t.globals.comboCharts || this.checkZeroSeries({
                        series: e
                    })
                }
            }, {
                key: "initialPositions",
                value: function () {
                    var e, t, n, i, a, r, s, o, l = this.w,
                        c = l.globals.dataPoints;
                    this.barCtx.isRangeBar && (c = l.globals.labels.length);
                    var u = this.barCtx.seriesLen;
                    if (l.config.plotOptions.bar.rangeBarGroupRows && (u = 1), this.barCtx.isHorizontal) a = (n = l.globals.gridHeight / c) / u, l.globals.isXNumeric && (a = (n = l.globals.gridHeight / this.barCtx.totalItems) / this.barCtx.seriesLen), a = a * parseInt(this.barCtx.barOptions.barHeight, 10) / 100, o = this.barCtx.baseLineInvertedY + l.globals.padHorizontal + (this.barCtx.isReversed ? l.globals.gridWidth : 0) - (this.barCtx.isReversed ? 2 * this.barCtx.baseLineInvertedY : 0), t = (n - a * this.barCtx.seriesLen) / 2;
                    else {
                        if (i = l.globals.gridWidth / this.barCtx.visibleItems, l.config.xaxis.convertedCatToNumeric && (i = l.globals.gridWidth / l.globals.dataPoints), r = i / this.barCtx.seriesLen * parseInt(this.barCtx.barOptions.columnWidth, 10) / 100, l.globals.isXNumeric) {
                            var d = this.barCtx.xRatio;
                            l.config.xaxis.convertedCatToNumeric && (d = this.barCtx.initialXRatio), l.globals.minXDiff && .5 !== l.globals.minXDiff && l.globals.minXDiff / d > 0 && (i = l.globals.minXDiff / d), (r = i / this.barCtx.seriesLen * parseInt(this.barCtx.barOptions.columnWidth, 10) / 100) < 1 && (r = 1)
                        }
                        s = l.globals.gridHeight - this.barCtx.baseLineY[this.barCtx.yaxisIndex] - (this.barCtx.isReversed ? l.globals.gridHeight : 0) + (this.barCtx.isReversed ? 2 * this.barCtx.baseLineY[this.barCtx.yaxisIndex] : 0), e = l.globals.padHorizontal + (i - r * this.barCtx.seriesLen) / 2
                    }
                    return {
                        x: e,
                        y: t,
                        yDivision: n,
                        xDivision: i,
                        barHeight: a,
                        barWidth: r,
                        zeroH: s,
                        zeroW: o
                    }
                }
            }, {
                key: "getPathFillColor",
                value: function (e, t, n, i) {
                    var a = this.w,
                        r = new S(this.barCtx.ctx),
                        s = null,
                        o = this.barCtx.barOptions.distributed ? n : t;
                    return this.barCtx.barOptions.colors.ranges.length > 0 && this.barCtx.barOptions.colors.ranges.map((function (i) {
                        e[t][n] >= i.from && e[t][n] <= i.to && (s = i.color)
                    })), a.config.series[t].data[n] && a.config.series[t].data[n].fillColor && (s = a.config.series[t].data[n].fillColor), r.fillPath({
                        seriesNumber: this.barCtx.barOptions.distributed ? o : i,
                        dataPointIndex: n,
                        color: s,
                        value: e[t][n]
                    })
                }
            }, {
                key: "getStrokeWidth",
                value: function (e, t, n) {
                    var i = 0,
                        a = this.w;
                    return void 0 === this.barCtx.series[e][t] || null === this.barCtx.series[e][t] ? this.barCtx.isNullValue = !0 : this.barCtx.isNullValue = !1, a.config.stroke.show && (this.barCtx.isNullValue || (i = Array.isArray(this.barCtx.strokeWidth) ? this.barCtx.strokeWidth[n] : this.barCtx.strokeWidth)), i
                }
            }, {
                key: "barBackground",
                value: function (e) {
                    var t = e.j,
                        n = e.i,
                        i = e.x1,
                        a = e.x2,
                        r = e.y1,
                        s = e.y2,
                        o = e.elSeries,
                        l = this.w,
                        c = new v(this.barCtx.ctx),
                        u = new E(this.barCtx.ctx).getActiveConfigSeriesIndex();
                    if (this.barCtx.barOptions.colors.backgroundBarColors.length > 0 && u === n) {
                        t >= this.barCtx.barOptions.colors.backgroundBarColors.length && (t -= this.barCtx.barOptions.colors.backgroundBarColors.length);
                        var d = this.barCtx.barOptions.colors.backgroundBarColors[t],
                            h = c.drawRect(void 0 !== i ? i : 0, void 0 !== r ? r : 0, void 0 !== a ? a : l.globals.gridWidth, void 0 !== s ? s : l.globals.gridHeight, this.barCtx.barOptions.colors.backgroundBarRadius, d, this.barCtx.barOptions.colors.backgroundBarOpacity);
                        o.add(h), h.node.classList.add("apexcharts-backgroundBar")
                    }
                }
            }, {
                key: "getColumnPaths",
                value: function (e) {
                    var t = e.barWidth,
                        n = e.barXPosition,
                        i = e.yRatio,
                        a = e.y1,
                        r = e.y2,
                        s = e.strokeWidth,
                        o = e.series,
                        l = e.realIndex,
                        c = e.i,
                        u = e.j,
                        d = e.w,
                        h = new v(this.barCtx.ctx);
                    (s = Array.isArray(s) ? s[l] : s) || (s = 0);
                    var f = {
                            barWidth: t,
                            strokeWidth: s,
                            yRatio: i,
                            barXPosition: n,
                            y1: a,
                            y2: r
                        },
                        p = this.getRoundedBars(d, f, o, c, u),
                        m = n,
                        g = n + t,
                        y = h.move(m, a),
                        b = h.move(m, a),
                        x = h.line(g - s, a);
                    return d.globals.previousPaths.length > 0 && (b = this.barCtx.getPreviousPath(l, u, !1)), y = y + h.line(m, p.y2) + p.pathWithRadius + h.line(g - s, p.y2) + x + x + "z", b = b + h.line(m, a) + x + x + x + x + x + h.line(m, a), d.config.chart.stacked && (this.barCtx.yArrj.push(p.y2), this.barCtx.yArrjF.push(Math.abs(a - p.y2)), this.barCtx.yArrjVal.push(this.barCtx.series[c][u])), {
                        pathTo: y,
                        pathFrom: b
                    }
                }
            }, {
                key: "getBarpaths",
                value: function (e) {
                    var t = e.barYPosition,
                        n = e.barHeight,
                        i = e.x1,
                        a = e.x2,
                        r = e.strokeWidth,
                        s = e.series,
                        o = e.realIndex,
                        l = e.i,
                        c = e.j,
                        u = e.w,
                        d = new v(this.barCtx.ctx);
                    (r = Array.isArray(r) ? r[o] : r) || (r = 0);
                    var h = {
                            barHeight: n,
                            strokeWidth: r,
                            barYPosition: t,
                            x2: a,
                            x1: i
                        },
                        f = this.getRoundedBars(u, h, s, l, c),
                        p = d.move(i, t),
                        m = d.move(i, t);
                    u.globals.previousPaths.length > 0 && (m = this.barCtx.getPreviousPath(o, c, !1));
                    var g = t,
                        y = t + n,
                        b = d.line(i, y - r);
                    return p = p + d.line(f.x2, g) + f.pathWithRadius + d.line(f.x2, y - r) + b + b + "z", m = m + d.line(i, g) + b + b + b + b + b + d.line(i, g), u.config.chart.stacked && (this.barCtx.xArrj.push(f.x2), this.barCtx.xArrjF.push(Math.abs(i - f.x2)), this.barCtx.xArrjVal.push(this.barCtx.series[l][c])), {
                        pathTo: p,
                        pathFrom: m
                    }
                }
            }, {
                key: "getRoundedBars",
                value: function (e, t, n, i, a) {
                    var r = new v(this.barCtx.ctx),
                        s = 0,
                        o = e.config.plotOptions.bar.borderRadius,
                        l = Array.isArray(o);
                    if (s = l ? o[i > o.length - 1 ? o.length - 1 : i] : o, e.config.chart.stacked && n.length > 1 && i !== this.barCtx.radiusOnSeriesNumber && !l && (s = 0), this.barCtx.isHorizontal) {
                        var c = "",
                            u = t.x2;
                        if (Math.abs(t.x1 - t.x2) < s && (s = Math.abs(t.x1 - t.x2)), void 0 !== n[i][a] || null !== n[i][a]) {
                            var d = this.barCtx.isReversed ? n[i][a] > 0 : n[i][a] < 0;
                            d && (s *= -1), u -= s, c = r.quadraticCurve(u + s, t.barYPosition, u + s, t.barYPosition + (d ? -1 * s : s)) + r.line(u + s, t.barYPosition + t.barHeight - t.strokeWidth - (d ? -1 * s : s)) + r.quadraticCurve(u + s, t.barYPosition + t.barHeight - t.strokeWidth, u, t.barYPosition + t.barHeight - t.strokeWidth)
                        }
                        return {
                            pathWithRadius: c,
                            x2: u
                        }
                    }
                    var h = "",
                        f = t.y2;
                    if (Math.abs(t.y1 - t.y2) < s && (s = Math.abs(t.y1 - t.y2)), void 0 !== n[i][a] || null !== n[i][a]) {
                        var p = n[i][a] < 0;
                        p && (s *= -1), f += s, h = r.quadraticCurve(t.barXPosition, f - s, t.barXPosition + (p ? -1 * s : s), f - s) + r.line(t.barXPosition + t.barWidth - t.strokeWidth - (p ? -1 * s : s), f - s) + r.quadraticCurve(t.barXPosition + t.barWidth - t.strokeWidth, f - s, t.barXPosition + t.barWidth - t.strokeWidth, f)
                    }
                    return {
                        pathWithRadius: h,
                        y2: f
                    }
                }
            }, {
                key: "checkZeroSeries",
                value: function (e) {
                    for (var t = e.series, n = this.w, i = 0; i < t.length; i++) {
                        for (var a = 0, r = 0; r < t[n.globals.maxValsInArrayIndex].length; r++) a += t[i][r];
                        0 === a && this.barCtx.zeroSerieses.push(i)
                    }
                    for (var s = t.length - 1; s >= 0; s--) this.barCtx.zeroSerieses.indexOf(s) > -1 && s === this.radiusOnSeriesNumber && (this.barCtx.radiusOnSeriesNumber -= 1);
                    for (var o = t.length - 1; o >= 0; o--) n.globals.collapsedSeriesIndices.indexOf(this.barCtx.radiusOnSeriesNumber) > -1 && (this.barCtx.radiusOnSeriesNumber -= 1)
                }
            }, {
                key: "getXForValue",
                value: function (e, t) {
                    var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
                        i = n ? t : null;
                    return null != e && (i = t + e / this.barCtx.invertedYRatio - 2 * (this.barCtx.isReversed ? e / this.barCtx.invertedYRatio : 0)), i
                }
            }, {
                key: "getYForValue",
                value: function (e, t) {
                    var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
                        i = n ? t : null;
                    return null != e && (i = t - e / this.barCtx.yRatio[this.barCtx.yaxisIndex] + 2 * (this.barCtx.isReversed ? e / this.barCtx.yRatio[this.barCtx.yaxisIndex] : 0)), i
                }
            }, {
                key: "getGoalValues",
                value: function (e, t, n, i, a) {
                    var r = this,
                        o = this.w,
                        l = [];
                    return o.globals.seriesGoals[i] && o.globals.seriesGoals[i][a] && Array.isArray(o.globals.seriesGoals[i][a]) && o.globals.seriesGoals[i][a].forEach((function (i) {
                        var a;
                        l.push((s(a = {}, e, "x" === e ? r.getXForValue(i.value, t, !1) : r.getYForValue(i.value, n, !1)), s(a, "attrs", i), a))
                    })), l
                }
            }, {
                key: "drawGoalLine",
                value: function (e) {
                    var t = e.barXPosition,
                        n = e.barYPosition,
                        i = e.goalX,
                        a = e.goalY,
                        r = e.barWidth,
                        s = e.barHeight,
                        o = new v(this.barCtx.ctx),
                        l = o.group({
                            className: "apexcharts-bar-goals-groups"
                        }),
                        c = null;
                    return this.barCtx.isHorizontal ? Array.isArray(i) && i.forEach((function (e) {
                        var t = void 0 !== e.attrs.strokeHeight ? e.attrs.strokeHeight : s / 2,
                            i = n + t + s / 2;
                        c = o.drawLine(e.x, i - 2 * t, e.x, i, e.attrs.strokeColor ? e.attrs.strokeColor : void 0, e.attrs.strokeDashArray, e.attrs.strokeWidth ? e.attrs.strokeWidth : 2, e.attrs.strokeLineCap), l.add(c)
                    })) : Array.isArray(a) && a.forEach((function (e) {
                        var n = void 0 !== e.attrs.strokeWidth ? e.attrs.strokeWidth : r / 2,
                            i = t + n + r / 2;
                        c = o.drawLine(i - 2 * n, e.y, i, e.y, e.attrs.strokeColor ? e.attrs.strokeColor : void 0, e.attrs.strokeDashArray, e.attrs.strokeHeight ? e.attrs.strokeHeight : 2, e.attrs.strokeLineCap), l.add(c)
                    })), l
                }
            }]), e
        }(),
        P = function () {
            function e(t, n) {
                i(this, e), this.ctx = t, this.w = t.w;
                var a = this.w;
                this.barOptions = a.config.plotOptions.bar, this.isHorizontal = this.barOptions.horizontal, this.strokeWidth = a.config.stroke.width, this.isNullValue = !1, this.isRangeBar = a.globals.seriesRangeBar.length && this.isHorizontal, this.xyRatios = n, null !== this.xyRatios && (this.xRatio = n.xRatio, this.initialXRatio = n.initialXRatio, this.yRatio = n.yRatio, this.invertedXRatio = n.invertedXRatio, this.invertedYRatio = n.invertedYRatio, this.baseLineY = n.baseLineY, this.baseLineInvertedY = n.baseLineInvertedY), this.yaxisIndex = 0, this.seriesLen = 0, this.barHelpers = new O(this)
            }
            return r(e, [{
                key: "draw",
                value: function (e, n) {
                    var i = this.w,
                        a = new v(this.ctx),
                        r = new x(this.ctx, i);
                    e = r.getLogSeries(e), this.series = e, this.yRatio = r.getLogYRatios(this.yRatio), this.barHelpers.initVariables(e);
                    var s = a.group({
                        class: "apexcharts-bar-series apexcharts-plot-series"
                    });
                    i.config.dataLabels.enabled && this.totalItems > this.barOptions.dataLabels.maxItems && console.warn("WARNING: DataLabels are enabled but there are too many to display. This may cause performance issue when rendering.");
                    for (var o = 0, l = 0; o < e.length; o++, l++) {
                        var c, u, d, h, f = void 0,
                            m = void 0,
                            g = [],
                            y = [],
                            b = i.globals.comboCharts ? n[o] : o,
                            _ = a.group({
                                class: "apexcharts-series",
                                rel: o + 1,
                                seriesName: p.escapeString(i.globals.seriesNames[b]),
                                "data:realIndex": b
                            });
                        this.ctx.series.addCollapsedClassToSeries(_, b), e[o].length > 0 && (this.visibleI = this.visibleI + 1);
                        var w = 0,
                            k = 0;
                        this.yRatio.length > 1 && (this.yaxisIndex = b), this.isReversed = i.config.yaxis[this.yaxisIndex] && i.config.yaxis[this.yaxisIndex].reversed;
                        var M = this.barHelpers.initialPositions();
                        m = M.y, w = M.barHeight, u = M.yDivision, h = M.zeroW, f = M.x, k = M.barWidth, c = M.xDivision, d = M.zeroH, this.horizontal || y.push(f + k / 2);
                        for (var L = a.group({
                                class: "apexcharts-datalabels",
                                "data:realIndex": b
                            }), S = a.group({
                                class: "apexcharts-bar-goals-markers",
                                style: "pointer-events: none"
                            }), A = 0; A < i.globals.dataPoints; A++) {
                            var T = this.barHelpers.getStrokeWidth(o, A, b),
                                C = null,
                                D = {
                                    indexes: {
                                        i: o,
                                        j: A,
                                        realIndex: b,
                                        bc: l
                                    },
                                    x: f,
                                    y: m,
                                    strokeWidth: T,
                                    elSeries: _
                                };
                            this.isHorizontal ? (C = this.drawBarPaths(t(t({}, D), {}, {
                                barHeight: w,
                                zeroW: h,
                                yDivision: u
                            })), k = this.series[o][A] / this.invertedYRatio) : (C = this.drawColumnPaths(t(t({}, D), {}, {
                                xDivision: c,
                                barWidth: k,
                                zeroH: d
                            })), w = this.series[o][A] / this.yRatio[this.yaxisIndex]);
                            var E = this.barHelpers.drawGoalLine({
                                barXPosition: C.barXPosition,
                                barYPosition: C.barYPosition,
                                goalX: C.goalX,
                                goalY: C.goalY,
                                barHeight: w,
                                barWidth: k
                            });
                            E && S.add(E), m = C.y, f = C.x, A > 0 && y.push(f + k / 2), g.push(m);
                            var O = this.barHelpers.getPathFillColor(e, o, A, b);
                            this.renderSeries({
                                realIndex: b,
                                pathFill: O,
                                j: A,
                                i: o,
                                pathFrom: C.pathFrom,
                                pathTo: C.pathTo,
                                strokeWidth: T,
                                elSeries: _,
                                x: f,
                                y: m,
                                series: e,
                                barHeight: w,
                                barWidth: k,
                                elDataLabelsWrap: L,
                                elGoalsMarkers: S,
                                visibleSeries: this.visibleI,
                                type: "bar"
                            })
                        }
                        i.globals.seriesXvalues[b] = y, i.globals.seriesYvalues[b] = g, s.add(_)
                    }
                    return s
                }
            }, {
                key: "renderSeries",
                value: function (e) {
                    var t = e.realIndex,
                        n = e.pathFill,
                        i = e.lineFill,
                        a = e.j,
                        r = e.i,
                        s = e.pathFrom,
                        o = e.pathTo,
                        l = e.strokeWidth,
                        c = e.elSeries,
                        u = e.x,
                        d = e.y,
                        h = e.y1,
                        f = e.y2,
                        p = e.series,
                        m = e.barHeight,
                        y = e.barWidth,
                        b = e.barYPosition,
                        x = e.elDataLabelsWrap,
                        _ = e.elGoalsMarkers,
                        w = e.visibleSeries,
                        k = e.type,
                        M = this.w,
                        L = new v(this.ctx);
                    i || (i = this.barOptions.distributed ? M.globals.stroke.colors[a] : M.globals.stroke.colors[t]), M.config.series[r].data[a] && M.config.series[r].data[a].strokeColor && (i = M.config.series[r].data[a].strokeColor), this.isNullValue && (n = "none");
                    var S = a / M.config.chart.animations.animateGradually.delay * (M.config.chart.animations.speed / M.globals.dataPoints) / 2.4,
                        A = L.renderPaths({
                            i: r,
                            j: a,
                            realIndex: t,
                            pathFrom: s,
                            pathTo: o,
                            stroke: i,
                            strokeWidth: l,
                            strokeLineCap: M.config.stroke.lineCap,
                            fill: n,
                            animationDelay: S,
                            initialSpeed: M.config.chart.animations.speed,
                            dataChangeSpeed: M.config.chart.animations.dynamicAnimation.speed,
                            className: "apexcharts-".concat(k, "-area")
                        });
                    A.attr("clip-path", "url(#gridRectMask".concat(M.globals.cuid, ")"));
                    var T = M.config.forecastDataPoints;
                    T.count > 0 && a >= M.globals.dataPoints - T.count && (A.node.setAttribute("stroke-dasharray", T.dashArray), A.node.setAttribute("stroke-width", T.strokeWidth), A.node.setAttribute("fill-opacity", T.fillOpacity)), void 0 !== h && void 0 !== f && (A.attr("data-range-y1", h), A.attr("data-range-y2", f)), new g(this.ctx).setSelectionFilter(A, t, a), c.add(A);
                    var C = new D(this).handleBarDataLabels({
                        x: u,
                        y: d,
                        y1: h,
                        y2: f,
                        i: r,
                        j: a,
                        series: p,
                        realIndex: t,
                        barHeight: m,
                        barWidth: y,
                        barYPosition: b,
                        renderedPath: A,
                        visibleSeries: w
                    });
                    return null !== C && x.add(C), c.add(x), _ && c.add(_), c
                }
            }, {
                key: "drawBarPaths",
                value: function (e) {
                    var t = e.indexes,
                        n = e.barHeight,
                        i = e.strokeWidth,
                        a = e.zeroW,
                        r = e.x,
                        s = e.y,
                        o = e.yDivision,
                        l = e.elSeries,
                        c = this.w,
                        u = t.i,
                        d = t.j;
                    c.globals.isXNumeric && (s = (c.globals.seriesX[u][d] - c.globals.minX) / this.invertedXRatio - n);
                    var h = s + n * this.visibleI;
                    r = this.barHelpers.getXForValue(this.series[u][d], a);
                    var f = this.barHelpers.getBarpaths({
                        barYPosition: h,
                        barHeight: n,
                        x1: a,
                        x2: r,
                        strokeWidth: i,
                        series: this.series,
                        realIndex: t.realIndex,
                        i: u,
                        j: d,
                        w: c
                    });
                    return c.globals.isXNumeric || (s += o), this.barHelpers.barBackground({
                        j: d,
                        i: u,
                        y1: h - n * this.visibleI,
                        y2: n * this.seriesLen,
                        elSeries: l
                    }), {
                        pathTo: f.pathTo,
                        pathFrom: f.pathFrom,
                        x: r,
                        y: s,
                        goalX: this.barHelpers.getGoalValues("x", a, null, u, d),
                        barYPosition: h
                    }
                }
            }, {
                key: "drawColumnPaths",
                value: function (e) {
                    var t = e.indexes,
                        n = e.x,
                        i = e.y,
                        a = e.xDivision,
                        r = e.barWidth,
                        s = e.zeroH,
                        o = e.strokeWidth,
                        l = e.elSeries,
                        c = this.w,
                        u = t.realIndex,
                        d = t.i,
                        h = t.j,
                        f = t.bc;
                    if (c.globals.isXNumeric) {
                        var p = u;
                        c.globals.seriesX[u].length || (p = c.globals.maxValsInArrayIndex), n = (c.globals.seriesX[p][h] - c.globals.minX) / this.xRatio - r * this.seriesLen / 2
                    }
                    var m = n + r * this.visibleI;
                    i = this.barHelpers.getYForValue(this.series[d][h], s);
                    var g = this.barHelpers.getColumnPaths({
                        barXPosition: m,
                        barWidth: r,
                        y1: s,
                        y2: i,
                        strokeWidth: o,
                        series: this.series,
                        realIndex: t.realIndex,
                        i: d,
                        j: h,
                        w: c
                    });
                    return c.globals.isXNumeric || (n += a), this.barHelpers.barBackground({
                        bc: f,
                        j: h,
                        i: d,
                        x1: m - o / 2 - r * this.visibleI,
                        x2: r * this.seriesLen + o / 2,
                        elSeries: l
                    }), {
                        pathTo: g.pathTo,
                        pathFrom: g.pathFrom,
                        x: n,
                        y: i,
                        goalY: this.barHelpers.getGoalValues("y", null, s, d, h),
                        barXPosition: m
                    }
                }
            }, {
                key: "getPreviousPath",
                value: function (e, t) {
                    for (var n, i = this.w, a = 0; a < i.globals.previousPaths.length; a++) {
                        var r = i.globals.previousPaths[a];
                        r.paths && r.paths.length > 0 && parseInt(r.realIndex, 10) === parseInt(e, 10) && void 0 !== i.globals.previousPaths[a].paths[t] && (n = i.globals.previousPaths[a].paths[t].d)
                    }
                    return n
                }
            }]), e
        }(),
        Y = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w, this.months31 = [1, 3, 5, 7, 8, 10, 12], this.months30 = [2, 4, 6, 9, 11], this.daysCntOfYear = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
            }
            return r(e, [{
                key: "isValidDate",
                value: function (e) {
                    return !isNaN(this.parseDate(e))
                }
            }, {
                key: "getTimeStamp",
                value: function (e) {
                    return Date.parse(e) ? this.w.config.xaxis.labels.datetimeUTC ? new Date(new Date(e).toISOString().substr(0, 25)).getTime() : new Date(e).getTime() : e
                }
            }, {
                key: "getDate",
                value: function (e) {
                    return this.w.config.xaxis.labels.datetimeUTC ? new Date(new Date(e).toUTCString()) : new Date(e)
                }
            }, {
                key: "parseDate",
                value: function (e) {
                    var t = Date.parse(e);
                    if (!isNaN(t)) return this.getTimeStamp(e);
                    var n = Date.parse(e.replace(/-/g, "/").replace(/[a-z]+/gi, " "));
                    return this.getTimeStamp(n)
                }
            }, {
                key: "parseDateWithTimezone",
                value: function (e) {
                    return Date.parse(e.replace(/-/g, "/").replace(/[a-z]+/gi, " "))
                }
            }, {
                key: "formatDate",
                value: function (e, t) {
                    var n = this.w.globals.locale,
                        i = this.w.config.xaxis.labels.datetimeUTC,
                        a = ["\0"].concat(h(n.months)),
                        r = [""].concat(h(n.shortMonths)),
                        s = [""].concat(h(n.days)),
                        o = [""].concat(h(n.shortDays));

                    function l(e, t) {
                        var n = e + "";
                        for (t = t || 2; n.length < t;) n = "0" + n;
                        return n
                    }
                    var c = i ? e.getUTCFullYear() : e.getFullYear();
                    t = (t = (t = t.replace(/(^|[^\\])yyyy+/g, "$1" + c)).replace(/(^|[^\\])yy/g, "$1" + c.toString().substr(2, 2))).replace(/(^|[^\\])y/g, "$1" + c);
                    var u = (i ? e.getUTCMonth() : e.getMonth()) + 1;
                    t = (t = (t = (t = t.replace(/(^|[^\\])MMMM+/g, "$1" + a[0])).replace(/(^|[^\\])MMM/g, "$1" + r[0])).replace(/(^|[^\\])MM/g, "$1" + l(u))).replace(/(^|[^\\])M/g, "$1" + u);
                    var d = i ? e.getUTCDate() : e.getDate();
                    t = (t = (t = (t = t.replace(/(^|[^\\])dddd+/g, "$1" + s[0])).replace(/(^|[^\\])ddd/g, "$1" + o[0])).replace(/(^|[^\\])dd/g, "$1" + l(d))).replace(/(^|[^\\])d/g, "$1" + d);
                    var f = i ? e.getUTCHours() : e.getHours(),
                        p = f > 12 ? f - 12 : 0 === f ? 12 : f;
                    t = (t = (t = (t = t.replace(/(^|[^\\])HH+/g, "$1" + l(f))).replace(/(^|[^\\])H/g, "$1" + f)).replace(/(^|[^\\])hh+/g, "$1" + l(p))).replace(/(^|[^\\])h/g, "$1" + p);
                    var m = i ? e.getUTCMinutes() : e.getMinutes();
                    t = (t = t.replace(/(^|[^\\])mm+/g, "$1" + l(m))).replace(/(^|[^\\])m/g, "$1" + m);
                    var g = i ? e.getUTCSeconds() : e.getSeconds();
                    t = (t = t.replace(/(^|[^\\])ss+/g, "$1" + l(g))).replace(/(^|[^\\])s/g, "$1" + g);
                    var v = i ? e.getUTCMilliseconds() : e.getMilliseconds();
                    t = t.replace(/(^|[^\\])fff+/g, "$1" + l(v, 3)), v = Math.round(v / 10), t = t.replace(/(^|[^\\])ff/g, "$1" + l(v)), v = Math.round(v / 10);
                    var y = f < 12 ? "AM" : "PM";
                    t = (t = (t = t.replace(/(^|[^\\])f/g, "$1" + v)).replace(/(^|[^\\])TT+/g, "$1" + y)).replace(/(^|[^\\])T/g, "$1" + y.charAt(0));
                    var b = y.toLowerCase();
                    t = (t = t.replace(/(^|[^\\])tt+/g, "$1" + b)).replace(/(^|[^\\])t/g, "$1" + b.charAt(0));
                    var x = -e.getTimezoneOffset(),
                        _ = i || !x ? "Z" : x > 0 ? "+" : "-";
                    if (!i) {
                        var w = (x = Math.abs(x)) % 60;
                        _ += l(Math.floor(x / 60)) + ":" + l(w)
                    }
                    t = t.replace(/(^|[^\\])K/g, "$1" + _);
                    var k = (i ? e.getUTCDay() : e.getDay()) + 1;
                    return (t = (t = (t = (t = t.replace(new RegExp(s[0], "g"), s[k])).replace(new RegExp(o[0], "g"), o[k])).replace(new RegExp(a[0], "g"), a[u])).replace(new RegExp(r[0], "g"), r[u])).replace(/\\(.)/g, "$1")
                }
            }, {
                key: "getTimeUnitsfromTimestamp",
                value: function (e, t, n) {
                    var i = this.w;
                    void 0 !== i.config.xaxis.min && (e = i.config.xaxis.min), void 0 !== i.config.xaxis.max && (t = i.config.xaxis.max);
                    var a = this.getDate(e),
                        r = this.getDate(t),
                        s = this.formatDate(a, "yyyy MM dd HH mm ss fff").split(" "),
                        o = this.formatDate(r, "yyyy MM dd HH mm ss fff").split(" ");
                    return {
                        minMillisecond: parseInt(s[6], 10),
                        maxMillisecond: parseInt(o[6], 10),
                        minSecond: parseInt(s[5], 10),
                        maxSecond: parseInt(o[5], 10),
                        minMinute: parseInt(s[4], 10),
                        maxMinute: parseInt(o[4], 10),
                        minHour: parseInt(s[3], 10),
                        maxHour: parseInt(o[3], 10),
                        minDate: parseInt(s[2], 10),
                        maxDate: parseInt(o[2], 10),
                        minMonth: parseInt(s[1], 10) - 1,
                        maxMonth: parseInt(o[1], 10) - 1,
                        minYear: parseInt(s[0], 10),
                        maxYear: parseInt(o[0], 10)
                    }
                }
            }, {
                key: "isLeapYear",
                value: function (e) {
                    return e % 4 == 0 && e % 100 != 0 || e % 400 == 0
                }
            }, {
                key: "calculcateLastDaysOfMonth",
                value: function (e, t, n) {
                    return this.determineDaysOfMonths(e, t) - n
                }
            }, {
                key: "determineDaysOfYear",
                value: function (e) {
                    var t = 365;
                    return this.isLeapYear(e) && (t = 366), t
                }
            }, {
                key: "determineRemainingDaysOfYear",
                value: function (e, t, n) {
                    var i = this.daysCntOfYear[t] + n;
                    return t > 1 && this.isLeapYear() && i++, i
                }
            }, {
                key: "determineDaysOfMonths",
                value: function (e, t) {
                    var n = 30;
                    switch (e = p.monthMod(e), !0) {
                        case this.months30.indexOf(e) > -1:
                            2 === e && (n = this.isLeapYear(t) ? 29 : 28);
                            break;
                        case this.months31.indexOf(e) > -1:
                        default:
                            n = 31
                    }
                    return n
                }
            }]), e
        }(),
        I = function (e) {
            o(a, e);
            var n = d(a);

            function a() {
                return i(this, a), n.apply(this, arguments)
            }
            return r(a, [{
                key: "draw",
                value: function (e, n) {
                    var i = this.w,
                        a = new v(this.ctx);
                    this.rangeBarOptions = this.w.config.plotOptions.rangeBar, this.series = e, this.seriesRangeStart = i.globals.seriesRangeStart, this.seriesRangeEnd = i.globals.seriesRangeEnd, this.barHelpers.initVariables(e);
                    for (var r = a.group({
                            class: "apexcharts-rangebar-series apexcharts-plot-series"
                        }), s = 0; s < e.length; s++) {
                        var o, l, c, u = void 0,
                            d = void 0,
                            h = void 0,
                            f = i.globals.comboCharts ? n[s] : s,
                            m = a.group({
                                class: "apexcharts-series",
                                seriesName: p.escapeString(i.globals.seriesNames[f]),
                                rel: s + 1,
                                "data:realIndex": f
                            });
                        this.ctx.series.addCollapsedClassToSeries(m, f), e[s].length > 0 && (this.visibleI = this.visibleI + 1);
                        var g = 0,
                            y = 0;
                        this.yRatio.length > 1 && (this.yaxisIndex = f);
                        var b = this.barHelpers.initialPositions();
                        d = b.y, c = b.zeroW, u = b.x, y = b.barWidth, o = b.xDivision, l = b.zeroH;
                        for (var x = a.group({
                                class: "apexcharts-datalabels",
                                "data:realIndex": f
                            }), _ = a.group({
                                class: "apexcharts-rangebar-goals-markers",
                                style: "pointer-events: none"
                            }), w = 0; w < i.globals.dataPoints; w++) {
                            var k = this.barHelpers.getStrokeWidth(s, w, f),
                                M = this.seriesRangeStart[s][w],
                                L = this.seriesRangeEnd[s][w],
                                S = null,
                                A = null,
                                T = {
                                    x: u,
                                    y: d,
                                    strokeWidth: k,
                                    elSeries: m
                                };
                            if (h = b.yDivision, g = b.barHeight, this.isHorizontal) {
                                A = d + g * this.visibleI;
                                var C = this.seriesLen;
                                i.config.plotOptions.bar.rangeBarGroupRows && (C = 1);
                                var D = (h - g * C) / 2;
                                if (void 0 === i.config.series[s].data[w]) break;
                                if (i.config.series[s].data[w].x) {
                                    var E = this.detectOverlappingBars({
                                        i: s,
                                        j: w,
                                        barYPosition: A,
                                        srty: D,
                                        barHeight: g,
                                        yDivision: h,
                                        initPositions: b
                                    });
                                    g = E.barHeight, A = E.barYPosition
                                }
                                y = (S = this.drawRangeBarPaths(t({
                                    indexes: {
                                        i: s,
                                        j: w,
                                        realIndex: f
                                    },
                                    barHeight: g,
                                    barYPosition: A,
                                    zeroW: c,
                                    yDivision: h,
                                    y1: M,
                                    y2: L
                                }, T))).barWidth
                            } else g = (S = this.drawRangeColumnPaths(t({
                                indexes: {
                                    i: s,
                                    j: w,
                                    realIndex: f
                                },
                                zeroH: l,
                                barWidth: y,
                                xDivision: o
                            }, T))).barHeight;
                            var O = this.barHelpers.drawGoalLine({
                                barXPosition: S.barXPosition,
                                barYPosition: A,
                                goalX: S.goalX,
                                goalY: S.goalY,
                                barHeight: g,
                                barWidth: y
                            });
                            O && _.add(O), d = S.y, u = S.x;
                            var P = this.barHelpers.getPathFillColor(e, s, w, f),
                                Y = i.globals.stroke.colors[f];
                            this.renderSeries({
                                realIndex: f,
                                pathFill: P,
                                lineFill: Y,
                                j: w,
                                i: s,
                                x: u,
                                y: d,
                                y1: M,
                                y2: L,
                                pathFrom: S.pathFrom,
                                pathTo: S.pathTo,
                                strokeWidth: k,
                                elSeries: m,
                                series: e,
                                barHeight: g,
                                barYPosition: A,
                                barWidth: y,
                                elDataLabelsWrap: x,
                                elGoalsMarkers: _,
                                visibleSeries: this.visibleI,
                                type: "rangebar"
                            })
                        }
                        r.add(m)
                    }
                    return r
                }
            }, {
                key: "detectOverlappingBars",
                value: function (e) {
                    var t = e.i,
                        n = e.j,
                        i = e.barYPosition,
                        a = e.srty,
                        r = e.barHeight,
                        s = e.yDivision,
                        o = e.initPositions,
                        l = this.w,
                        c = [],
                        u = l.config.series[t].data[n].rangeName,
                        d = l.config.series[t].data[n].x,
                        h = l.globals.labels.indexOf(d),
                        f = l.globals.seriesRangeBar[t].findIndex((function (e) {
                            return e.x === d && e.overlaps.length > 0
                        }));
                    return i = l.config.plotOptions.bar.rangeBarGroupRows ? a + s * h : a + r * this.visibleI + s * h, f > -1 && !l.config.plotOptions.bar.rangeBarOverlap && (c = l.globals.seriesRangeBar[t][f].overlaps).indexOf(u) > -1 && (i = (r = o.barHeight / c.length) * this.visibleI + s * (100 - parseInt(this.barOptions.barHeight, 10)) / 100 / 2 + r * (this.visibleI + c.indexOf(u)) + s * h), {
                        barYPosition: i,
                        barHeight: r
                    }
                }
            }, {
                key: "drawRangeColumnPaths",
                value: function (e) {
                    var t = e.indexes,
                        n = e.x;
                    e.strokeWidth;
                    var i = e.xDivision,
                        a = e.barWidth,
                        r = e.zeroH,
                        s = this.w,
                        o = t.i,
                        l = t.j,
                        c = this.yRatio[this.yaxisIndex],
                        u = t.realIndex,
                        d = this.getRangeValue(u, l),
                        h = Math.min(d.start, d.end),
                        f = Math.max(d.start, d.end);
                    s.globals.isXNumeric && (n = (s.globals.seriesX[o][l] - s.globals.minX) / this.xRatio - a / 2);
                    var p = n + a * this.visibleI;
                    void 0 === this.series[o][l] || null === this.series[o][l] ? h = r : (h = r - h / c, f = r - f / c);
                    var m = Math.abs(f - h),
                        g = this.barHelpers.getColumnPaths({
                            barXPosition: p,
                            barWidth: a,
                            y1: h,
                            y2: f,
                            strokeWidth: this.strokeWidth,
                            series: this.seriesRangeEnd,
                            realIndex: t.realIndex,
                            i: u,
                            j: l,
                            w: s
                        });
                    return s.globals.isXNumeric || (n += i), {
                        pathTo: g.pathTo,
                        pathFrom: g.pathFrom,
                        barHeight: m,
                        x: n,
                        y: f,
                        goalY: this.barHelpers.getGoalValues("y", null, r, o, l),
                        barXPosition: p
                    }
                }
            }, {
                key: "drawRangeBarPaths",
                value: function (e) {
                    var t = e.indexes,
                        n = e.y,
                        i = e.y1,
                        a = e.y2,
                        r = e.yDivision,
                        s = e.barHeight,
                        o = e.barYPosition,
                        l = e.zeroW,
                        c = this.w,
                        u = l + i / this.invertedYRatio,
                        d = l + a / this.invertedYRatio,
                        h = Math.abs(d - u),
                        f = this.barHelpers.getBarpaths({
                            barYPosition: o,
                            barHeight: s,
                            x1: u,
                            x2: d,
                            strokeWidth: this.strokeWidth,
                            series: this.seriesRangeEnd,
                            i: t.realIndex,
                            realIndex: t.realIndex,
                            j: t.j,
                            w: c
                        });
                    return c.globals.isXNumeric || (n += r), {
                        pathTo: f.pathTo,
                        pathFrom: f.pathFrom,
                        barWidth: h,
                        x: d,
                        goalX: this.barHelpers.getGoalValues("x", l, null, t.realIndex, t.j),
                        y: n
                    }
                }
            }, {
                key: "getRangeValue",
                value: function (e, t) {
                    var n = this.w;
                    return {
                        start: n.globals.seriesRangeStart[e][t],
                        end: n.globals.seriesRangeEnd[e][t]
                    }
                }
            }, {
                key: "getTooltipValues",
                value: function (e) {
                    var t = e.ctx,
                        n = e.seriesIndex,
                        i = e.dataPointIndex,
                        a = e.y1,
                        r = e.y2,
                        s = e.w,
                        o = s.globals.seriesRangeStart[n][i],
                        l = s.globals.seriesRangeEnd[n][i],
                        c = s.globals.labels[i],
                        u = s.config.series[n].name ? s.config.series[n].name : "",
                        d = s.config.tooltip.y.formatter,
                        h = s.config.tooltip.y.title.formatter,
                        f = {
                            w: s,
                            seriesIndex: n,
                            dataPointIndex: i,
                            start: o,
                            end: l
                        };
                    "function" == typeof h && (u = h(u, f)), Number.isFinite(a) && Number.isFinite(r) && (o = a, l = r, s.config.series[n].data[i].x && (c = s.config.series[n].data[i].x + ":"), "function" == typeof d && (c = d(c, f)));
                    var p = "",
                        m = "",
                        g = s.globals.colors[n];
                    if (void 0 === s.config.tooltip.x.formatter)
                        if ("datetime" === s.config.xaxis.type) {
                            var v = new Y(t);
                            p = v.formatDate(v.getDate(o), s.config.tooltip.x.format), m = v.formatDate(v.getDate(l), s.config.tooltip.x.format)
                        } else p = o, m = l;
                    else p = s.config.tooltip.x.formatter(o), m = s.config.tooltip.x.formatter(l);
                    return {
                        start: o,
                        end: l,
                        startVal: p,
                        endVal: m,
                        ylabel: c,
                        color: g,
                        seriesName: u
                    }
                }
            }, {
                key: "buildCustomTooltipHTML",
                value: function (e) {
                    return '<div class="apexcharts-tooltip-rangebar"><div> <span class="series-name" style="color: ' + e.color + '">' + (e.seriesName || "") + '</span></div><div> <span class="category">' + e.ylabel + ' </span> <span class="value start-value">' + e.start + '</span> <span class="separator">-</span> <span class="value end-value">' + e.end + "</span></div></div>"
                }
            }]), a
        }(P),
        j = function () {
            function e(t) {
                i(this, e), this.opts = t
            }
            return r(e, [{
                key: "line",
                value: function () {
                    return {
                        chart: {
                            animations: {
                                easing: "swing"
                            }
                        },
                        dataLabels: {
                            enabled: !1
                        },
                        stroke: {
                            width: 5,
                            curve: "straight"
                        },
                        markers: {
                            size: 0,
                            hover: {
                                sizeOffset: 6
                            }
                        },
                        xaxis: {
                            crosshairs: {
                                width: 1
                            }
                        }
                    }
                }
            }, {
                key: "sparkline",
                value: function (e) {
                    return this.opts.yaxis[0].show = !1, this.opts.yaxis[0].title.text = "", this.opts.yaxis[0].axisBorder.show = !1, this.opts.yaxis[0].axisTicks.show = !1, this.opts.yaxis[0].floating = !0, p.extend(e, {
                        grid: {
                            show: !1,
                            padding: {
                                left: 0,
                                right: 0,
                                top: 0,
                                bottom: 0
                            }
                        },
                        legend: {
                            show: !1
                        },
                        xaxis: {
                            labels: {
                                show: !1
                            },
                            tooltip: {
                                enabled: !1
                            },
                            axisBorder: {
                                show: !1
                            },
                            axisTicks: {
                                show: !1
                            }
                        },
                        chart: {
                            toolbar: {
                                show: !1
                            },
                            zoom: {
                                enabled: !1
                            }
                        },
                        dataLabels: {
                            enabled: !1
                        }
                    })
                }
            }, {
                key: "bar",
                value: function () {
                    return {
                        chart: {
                            stacked: !1,
                            animations: {
                                easing: "swing"
                            }
                        },
                        plotOptions: {
                            bar: {
                                dataLabels: {
                                    position: "center"
                                }
                            }
                        },
                        dataLabels: {
                            style: {
                                colors: ["#fff"]
                            },
                            background: {
                                enabled: !1
                            }
                        },
                        stroke: {
                            width: 0,
                            lineCap: "round"
                        },
                        fill: {
                            opacity: .85
                        },
                        legend: {
                            markers: {
                                shape: "square",
                                radius: 2,
                                size: 8
                            }
                        },
                        tooltip: {
                            shared: !1,
                            intersect: !0
                        },
                        xaxis: {
                            tooltip: {
                                enabled: !1
                            },
                            tickPlacement: "between",
                            crosshairs: {
                                width: "barWidth",
                                position: "back",
                                fill: {
                                    type: "gradient"
                                },
                                dropShadow: {
                                    enabled: !1
                                },
                                stroke: {
                                    width: 0
                                }
                            }
                        }
                    }
                }
            }, {
                key: "candlestick",
                value: function () {
                    var e = this;
                    return {
                        stroke: {
                            width: 1,
                            colors: ["#333"]
                        },
                        fill: {
                            opacity: 1
                        },
                        dataLabels: {
                            enabled: !1
                        },
                        tooltip: {
                            shared: !0,
                            custom: function (t) {
                                var n = t.seriesIndex,
                                    i = t.dataPointIndex,
                                    a = t.w;
                                return e._getBoxTooltip(a, n, i, ["Open", "High", "", "Low", "Close"], "candlestick")
                            }
                        },
                        states: {
                            active: {
                                filter: {
                                    type: "none"
                                }
                            }
                        },
                        xaxis: {
                            crosshairs: {
                                width: 1
                            }
                        }
                    }
                }
            }, {
                key: "boxPlot",
                value: function () {
                    var e = this;
                    return {
                        chart: {
                            animations: {
                                dynamicAnimation: {
                                    enabled: !1
                                }
                            }
                        },
                        stroke: {
                            width: 1,
                            colors: ["#24292e"]
                        },
                        dataLabels: {
                            enabled: !1
                        },
                        tooltip: {
                            shared: !0,
                            custom: function (t) {
                                var n = t.seriesIndex,
                                    i = t.dataPointIndex,
                                    a = t.w;
                                return e._getBoxTooltip(a, n, i, ["Minimum", "Q1", "Median", "Q3", "Maximum"], "boxPlot")
                            }
                        },
                        markers: {
                            size: 5,
                            strokeWidth: 1,
                            strokeColors: "#111"
                        },
                        xaxis: {
                            crosshairs: {
                                width: 1
                            }
                        }
                    }
                }
            }, {
                key: "rangeBar",
                value: function () {
                    return {
                        stroke: {
                            width: 0,
                            lineCap: "square"
                        },
                        plotOptions: {
                            bar: {
                                borderRadius: 0,
                                dataLabels: {
                                    position: "center"
                                }
                            }
                        },
                        dataLabels: {
                            enabled: !1,
                            formatter: function (e, t) {
                                t.ctx;
                                var n = t.seriesIndex,
                                    i = t.dataPointIndex,
                                    a = t.w,
                                    r = a.globals.seriesRangeStart[n][i];
                                return a.globals.seriesRangeEnd[n][i] - r
                            },
                            background: {
                                enabled: !1
                            },
                            style: {
                                colors: ["#fff"]
                            }
                        },
                        tooltip: {
                            shared: !1,
                            followCursor: !0,
                            custom: function (e) {
                                return e.w.config.plotOptions && e.w.config.plotOptions.bar && e.w.config.plotOptions.bar.horizontal ? function (e) {
                                    var t = new I(e.ctx, null),
                                        n = t.getTooltipValues(e),
                                        i = n.color,
                                        a = n.seriesName,
                                        r = n.ylabel,
                                        s = n.startVal,
                                        o = n.endVal;
                                    return t.buildCustomTooltipHTML({
                                        color: i,
                                        seriesName: a,
                                        ylabel: r,
                                        start: s,
                                        end: o
                                    })
                                }(e) : function (e) {
                                    var t = new I(e.ctx, null),
                                        n = t.getTooltipValues(e),
                                        i = n.color,
                                        a = n.seriesName,
                                        r = n.ylabel,
                                        s = n.start,
                                        o = n.end;
                                    return t.buildCustomTooltipHTML({
                                        color: i,
                                        seriesName: a,
                                        ylabel: r,
                                        start: s,
                                        end: o
                                    })
                                }(e)
                            }
                        },
                        xaxis: {
                            tickPlacement: "between",
                            tooltip: {
                                enabled: !1
                            },
                            crosshairs: {
                                stroke: {
                                    width: 0
                                }
                            }
                        }
                    }
                }
            }, {
                key: "area",
                value: function () {
                    return {
                        stroke: {
                            width: 4
                        },
                        fill: {
                            type: "gradient",
                            gradient: {
                                inverseColors: !1,
                                shade: "light",
                                type: "vertical",
                                opacityFrom: .65,
                                opacityTo: .5,
                                stops: [0, 100, 100]
                            }
                        },
                        markers: {
                            size: 0,
                            hover: {
                                sizeOffset: 6
                            }
                        },
                        tooltip: {
                            followCursor: !1
                        }
                    }
                }
            }, {
                key: "brush",
                value: function (e) {
                    return p.extend(e, {
                        chart: {
                            toolbar: {
                                autoSelected: "selection",
                                show: !1
                            },
                            zoom: {
                                enabled: !1
                            }
                        },
                        dataLabels: {
                            enabled: !1
                        },
                        stroke: {
                            width: 1
                        },
                        tooltip: {
                            enabled: !1
                        },
                        xaxis: {
                            tooltip: {
                                enabled: !1
                            }
                        }
                    })
                }
            }, {
                key: "stacked100",
                value: function (e) {
                    e.dataLabels = e.dataLabels || {}, e.dataLabels.formatter = e.dataLabels.formatter || void 0;
                    var t = e.dataLabels.formatter;
                    return e.yaxis.forEach((function (t, n) {
                        e.yaxis[n].min = 0, e.yaxis[n].max = 100
                    })), "bar" === e.chart.type && (e.dataLabels.formatter = t || function (e) {
                        return "number" == typeof e && e ? e.toFixed(0) + "%" : e
                    }), e
                }
            }, {
                key: "convertCatToNumeric",
                value: function (e) {
                    return e.xaxis.convertedCatToNumeric = !0, e
                }
            }, {
                key: "convertCatToNumericXaxis",
                value: function (e, t, n) {
                    e.xaxis.type = "numeric", e.xaxis.labels = e.xaxis.labels || {}, e.xaxis.labels.formatter = e.xaxis.labels.formatter || function (e) {
                        return p.isNumber(e) ? Math.floor(e) : e
                    };
                    var i = e.xaxis.labels.formatter,
                        a = e.xaxis.categories && e.xaxis.categories.length ? e.xaxis.categories : e.labels;
                    return n && n.length && (a = n.map((function (e) {
                        return Array.isArray(e) ? e : String(e)
                    }))), a && a.length && (e.xaxis.labels.formatter = function (e) {
                        return p.isNumber(e) ? i(a[Math.floor(e) - 1]) : i(e)
                    }), e.xaxis.categories = [], e.labels = [], e.xaxis.tickAmount = e.xaxis.tickAmount || "dataPoints", e
                }
            }, {
                key: "bubble",
                value: function () {
                    return {
                        dataLabels: {
                            style: {
                                colors: ["#fff"]
                            }
                        },
                        tooltip: {
                            shared: !1,
                            intersect: !0
                        },
                        xaxis: {
                            crosshairs: {
                                width: 0
                            }
                        },
                        fill: {
                            type: "solid",
                            gradient: {
                                shade: "light",
                                inverse: !0,
                                shadeIntensity: .55,
                                opacityFrom: .4,
                                opacityTo: .8
                            }
                        }
                    }
                }
            }, {
                key: "scatter",
                value: function () {
                    return {
                        dataLabels: {
                            enabled: !1
                        },
                        tooltip: {
                            shared: !1,
                            intersect: !0
                        },
                        markers: {
                            size: 6,
                            strokeWidth: 1,
                            hover: {
                                sizeOffset: 2
                            }
                        }
                    }
                }
            }, {
                key: "heatmap",
                value: function () {
                    return {
                        chart: {
                            stacked: !1
                        },
                        fill: {
                            opacity: 1
                        },
                        dataLabels: {
                            style: {
                                colors: ["#fff"]
                            }
                        },
                        stroke: {
                            colors: ["#fff"]
                        },
                        tooltip: {
                            followCursor: !0,
                            marker: {
                                show: !1
                            },
                            x: {
                                show: !1
                            }
                        },
                        legend: {
                            position: "top",
                            markers: {
                                shape: "square",
                                size: 10,
                                offsetY: 2
                            }
                        },
                        grid: {
                            padding: {
                                right: 20
                            }
                        }
                    }
                }
            }, {
                key: "treemap",
                value: function () {
                    return {
                        chart: {
                            zoom: {
                                enabled: !1
                            }
                        },
                        dataLabels: {
                            style: {
                                fontSize: 14,
                                fontWeight: 600,
                                colors: ["#fff"]
                            }
                        },
                        stroke: {
                            show: !0,
                            width: 2,
                            colors: ["#fff"]
                        },
                        legend: {
                            show: !1
                        },
                        fill: {
                            gradient: {
                                stops: [0, 100]
                            }
                        },
                        tooltip: {
                            followCursor: !0,
                            x: {
                                show: !1
                            }
                        },
                        grid: {
                            padding: {
                                left: 0,
                                right: 0
                            }
                        },
                        xaxis: {
                            crosshairs: {
                                show: !1
                            },
                            tooltip: {
                                enabled: !1
                            }
                        }
                    }
                }
            }, {
                key: "pie",
                value: function () {
                    return {
                        chart: {
                            toolbar: {
                                show: !1
                            }
                        },
                        plotOptions: {
                            pie: {
                                donut: {
                                    labels: {
                                        show: !1
                                    }
                                }
                            }
                        },
                        dataLabels: {
                            formatter: function (e) {
                                return e.toFixed(1) + "%"
                            },
                            style: {
                                colors: ["#fff"]
                            },
                            background: {
                                enabled: !1
                            },
                            dropShadow: {
                                enabled: !0
                            }
                        },
                        stroke: {
                            colors: ["#fff"]
                        },
                        fill: {
                            opacity: 1,
                            gradient: {
                                shade: "light",
                                stops: [0, 100]
                            }
                        },
                        tooltip: {
                            theme: "dark",
                            fillSeriesColor: !0
                        },
                        legend: {
                            position: "right"
                        }
                    }
                }
            }, {
                key: "donut",
                value: function () {
                    return {
                        chart: {
                            toolbar: {
                                show: !1
                            }
                        },
                        dataLabels: {
                            formatter: function (e) {
                                return e.toFixed(1) + "%"
                            },
                            style: {
                                colors: ["#fff"]
                            },
                            background: {
                                enabled: !1
                            },
                            dropShadow: {
                                enabled: !0
                            }
                        },
                        stroke: {
                            colors: ["#fff"]
                        },
                        fill: {
                            opacity: 1,
                            gradient: {
                                shade: "light",
                                shadeIntensity: .35,
                                stops: [80, 100],
                                opacityFrom: 1,
                                opacityTo: 1
                            }
                        },
                        tooltip: {
                            theme: "dark",
                            fillSeriesColor: !0
                        },
                        legend: {
                            position: "right"
                        }
                    }
                }
            }, {
                key: "polarArea",
                value: function () {
                    return this.opts.yaxis[0].tickAmount = this.opts.yaxis[0].tickAmount ? this.opts.yaxis[0].tickAmount : 6, {
                        chart: {
                            toolbar: {
                                show: !1
                            }
                        },
                        dataLabels: {
                            formatter: function (e) {
                                return e.toFixed(1) + "%"
                            },
                            enabled: !1
                        },
                        stroke: {
                            show: !0,
                            width: 2
                        },
                        fill: {
                            opacity: .7
                        },
                        tooltip: {
                            theme: "dark",
                            fillSeriesColor: !0
                        },
                        legend: {
                            position: "right"
                        }
                    }
                }
            }, {
                key: "radar",
                value: function () {
                    return this.opts.yaxis[0].labels.offsetY = this.opts.yaxis[0].labels.offsetY ? this.opts.yaxis[0].labels.offsetY : 6, {
                        dataLabels: {
                            enabled: !1,
                            style: {
                                fontSize: "11px"
                            }
                        },
                        stroke: {
                            width: 2
                        },
                        markers: {
                            size: 3,
                            strokeWidth: 1,
                            strokeOpacity: 1
                        },
                        fill: {
                            opacity: .2
                        },
                        tooltip: {
                            shared: !1,
                            intersect: !0,
                            followCursor: !0
                        },
                        grid: {
                            show: !1
                        },
                        xaxis: {
                            labels: {
                                formatter: function (e) {
                                    return e
                                },
                                style: {
                                    colors: ["#a8a8a8"],
                                    fontSize: "11px"
                                }
                            },
                            tooltip: {
                                enabled: !1
                            },
                            crosshairs: {
                                show: !1
                            }
                        }
                    }
                }
            }, {
                key: "radialBar",
                value: function () {
                    return {
                        chart: {
                            animations: {
                                dynamicAnimation: {
                                    enabled: !0,
                                    speed: 800
                                }
                            },
                            toolbar: {
                                show: !1
                            }
                        },
                        fill: {
                            gradient: {
                                shade: "dark",
                                shadeIntensity: .4,
                                inverseColors: !1,
                                type: "diagonal2",
                                opacityFrom: 1,
                                opacityTo: 1,
                                stops: [70, 98, 100]
                            }
                        },
                        legend: {
                            show: !1,
                            position: "right"
                        },
                        tooltip: {
                            enabled: !1,
                            fillSeriesColor: !0
                        }
                    }
                }
            }, {
                key: "_getBoxTooltip",
                value: function (e, t, n, i, a) {
                    var r = e.globals.seriesCandleO[t][n],
                        s = e.globals.seriesCandleH[t][n],
                        o = e.globals.seriesCandleM[t][n],
                        l = e.globals.seriesCandleL[t][n],
                        c = e.globals.seriesCandleC[t][n];
                    return e.config.series[t].type && e.config.series[t].type !== a ? '<div class="apexcharts-custom-tooltip">\n          '.concat(e.config.series[t].name ? e.config.series[t].name : "series-" + (t + 1), ": <strong>").concat(e.globals.series[t][n], "</strong>\n        </div>") : '<div class="apexcharts-tooltip-box apexcharts-tooltip-'.concat(e.config.chart.type, '">') + "<div>".concat(i[0], ': <span class="value">') + r + "</span></div>" + "<div>".concat(i[1], ': <span class="value">') + s + "</span></div>" + (o ? "<div>".concat(i[2], ': <span class="value">') + o + "</span></div>" : "") + "<div>".concat(i[3], ': <span class="value">') + l + "</span></div>" + "<div>".concat(i[4], ': <span class="value">') + c + "</span></div></div>"
                }
            }]), e
        }(),
        N = function () {
            function e(t) {
                i(this, e), this.opts = t
            }
            return r(e, [{
                key: "init",
                value: function (e) {
                    var t = e.responsiveOverride,
                        i = this.opts,
                        a = new M,
                        r = new j(i);
                    this.chartType = i.chart.type, "histogram" === this.chartType && (i.chart.type = "bar", i = p.extend({
                        plotOptions: {
                            bar: {
                                columnWidth: "99.99%"
                            }
                        }
                    }, i)), i = this.extendYAxis(i), i = this.extendAnnotations(i);
                    var s = a.init(),
                        o = {};
                    if (i && "object" === n(i)) {
                        var l = {};
                        l = -1 !== ["line", "area", "bar", "candlestick", "boxPlot", "rangeBar", "histogram", "bubble", "scatter", "heatmap", "treemap", "pie", "polarArea", "donut", "radar", "radialBar"].indexOf(i.chart.type) ? r[i.chart.type]() : r.line(), i.chart.brush && i.chart.brush.enabled && (l = r.brush(l)), i.chart.stacked && "100%" === i.chart.stackType && (i = r.stacked100(i)), this.checkForDarkTheme(window.Apex), this.checkForDarkTheme(i), i.xaxis = i.xaxis || window.Apex.xaxis || {}, t || (i.xaxis.convertedCatToNumeric = !1), ((i = this.checkForCatToNumericXAxis(this.chartType, l, i)).chart.sparkline && i.chart.sparkline.enabled || window.Apex.chart && window.Apex.chart.sparkline && window.Apex.chart.sparkline.enabled) && (l = r.sparkline(l)), o = p.extend(s, l)
                    }
                    var c = p.extend(o, window.Apex);
                    return s = p.extend(c, i), this.handleUserInputErrors(s)
                }
            }, {
                key: "checkForCatToNumericXAxis",
                value: function (e, t, n) {
                    var i = new j(n),
                        a = ("bar" === e || "boxPlot" === e) && n.plotOptions && n.plotOptions.bar && n.plotOptions.bar.horizontal,
                        r = "pie" === e || "polarArea" === e || "donut" === e || "radar" === e || "radialBar" === e || "heatmap" === e,
                        s = "datetime" !== n.xaxis.type && "numeric" !== n.xaxis.type,
                        o = n.xaxis.tickPlacement ? n.xaxis.tickPlacement : t.xaxis && t.xaxis.tickPlacement;
                    return a || r || !s || "between" === o || (n = i.convertCatToNumeric(n)), n
                }
            }, {
                key: "extendYAxis",
                value: function (e, t) {
                    var n = new M;
                    (void 0 === e.yaxis || !e.yaxis || Array.isArray(e.yaxis) && 0 === e.yaxis.length) && (e.yaxis = {}), e.yaxis.constructor !== Array && window.Apex.yaxis && window.Apex.yaxis.constructor !== Array && (e.yaxis = p.extend(e.yaxis, window.Apex.yaxis)), e.yaxis.constructor !== Array ? e.yaxis = [p.extend(n.yAxis, e.yaxis)] : e.yaxis = p.extendArray(e.yaxis, n.yAxis);
                    var i = !1;
                    e.yaxis.forEach((function (e) {
                        e.logarithmic && (i = !0)
                    }));
                    var a = e.series;
                    return t && !a && (a = t.config.series), i && a.length !== e.yaxis.length && a.length && (e.yaxis = a.map((function (t, i) {
                        if (t.name || (a[i].name = "series-".concat(i + 1)), e.yaxis[i]) return e.yaxis[i].seriesName = a[i].name, e.yaxis[i];
                        var r = p.extend(n.yAxis, e.yaxis[0]);
                        return r.show = !1, r
                    }))), i && a.length > 1 && a.length !== e.yaxis.length && console.warn("A multi-series logarithmic chart should have equal number of series and y-axes. Please make sure to equalize both."), e
                }
            }, {
                key: "extendAnnotations",
                value: function (e) {
                    return void 0 === e.annotations && (e.annotations = {}, e.annotations.yaxis = [], e.annotations.xaxis = [], e.annotations.points = []), e = this.extendYAxisAnnotations(e), e = this.extendXAxisAnnotations(e), this.extendPointAnnotations(e)
                }
            }, {
                key: "extendYAxisAnnotations",
                value: function (e) {
                    var t = new M;
                    return e.annotations.yaxis = p.extendArray(void 0 !== e.annotations.yaxis ? e.annotations.yaxis : [], t.yAxisAnnotation), e
                }
            }, {
                key: "extendXAxisAnnotations",
                value: function (e) {
                    var t = new M;
                    return e.annotations.xaxis = p.extendArray(void 0 !== e.annotations.xaxis ? e.annotations.xaxis : [], t.xAxisAnnotation), e
                }
            }, {
                key: "extendPointAnnotations",
                value: function (e) {
                    var t = new M;
                    return e.annotations.points = p.extendArray(void 0 !== e.annotations.points ? e.annotations.points : [], t.pointAnnotation), e
                }
            }, {
                key: "checkForDarkTheme",
                value: function (e) {
                    e.theme && "dark" === e.theme.mode && (e.tooltip || (e.tooltip = {}), "light" !== e.tooltip.theme && (e.tooltip.theme = "dark"), e.chart.foreColor || (e.chart.foreColor = "#f6f7f8"), e.chart.background || (e.chart.background = "#424242"), e.theme.palette || (e.theme.palette = "palette4"))
                }
            }, {
                key: "handleUserInputErrors",
                value: function (e) {
                    var t = e;
                    if (t.tooltip.shared && t.tooltip.intersect) throw new Error("tooltip.shared cannot be enabled when tooltip.intersect is true. Turn off any other option by setting it to false.");
                    if ("bar" === t.chart.type && t.plotOptions.bar.horizontal) {
                        if (t.yaxis.length > 1) throw new Error("Multiple Y Axis for bars are not supported. Switch to column chart by setting plotOptions.bar.horizontal=false");
                        t.yaxis[0].reversed && (t.yaxis[0].opposite = !0), t.xaxis.tooltip.enabled = !1, t.yaxis[0].tooltip.enabled = !1, t.chart.zoom.enabled = !1
                    }
                    return "bar" !== t.chart.type && "rangeBar" !== t.chart.type || t.tooltip.shared && "barWidth" === t.xaxis.crosshairs.width && t.series.length > 1 && (t.xaxis.crosshairs.width = "tickWidth"), "candlestick" !== t.chart.type && "boxPlot" !== t.chart.type || t.yaxis[0].reversed && (console.warn("Reversed y-axis in ".concat(t.chart.type, " chart is not supported.")), t.yaxis[0].reversed = !1), Array.isArray(t.stroke.width) && "line" !== t.chart.type && "area" !== t.chart.type && (console.warn("stroke.width option accepts array only for line and area charts. Reverted back to Number"), t.stroke.width = t.stroke.width[0]), t
                }
            }]), e
        }(),
        H = function () {
            function e() {
                i(this, e)
            }
            return r(e, [{
                key: "initGlobalVars",
                value: function (e) {
                    e.series = [], e.seriesCandleO = [], e.seriesCandleH = [], e.seriesCandleM = [], e.seriesCandleL = [], e.seriesCandleC = [], e.seriesRangeStart = [], e.seriesRangeEnd = [], e.seriesRangeBar = [], e.seriesPercent = [], e.seriesGoals = [], e.seriesX = [], e.seriesZ = [], e.seriesNames = [], e.seriesTotals = [], e.seriesLog = [], e.seriesColors = [], e.stackedSeriesTotals = [], e.seriesXvalues = [], e.seriesYvalues = [], e.labels = [], e.categoryLabels = [], e.timescaleLabels = [], e.noLabelsProvided = !1, e.resizeTimer = null, e.selectionResizeTimer = null, e.delayedElements = [], e.pointsArray = [], e.dataLabelsRects = [], e.isXNumeric = !1, e.xaxisLabelsCount = 0, e.skipLastTimelinelabel = !1, e.skipFirstTimelinelabel = !1, e.isDataXYZ = !1, e.isMultiLineX = !1, e.isMultipleYAxis = !1, e.maxY = -Number.MAX_VALUE, e.minY = Number.MIN_VALUE, e.minYArr = [], e.maxYArr = [], e.maxX = -Number.MAX_VALUE, e.minX = Number.MAX_VALUE, e.initialMaxX = -Number.MAX_VALUE, e.initialMinX = Number.MAX_VALUE, e.maxDate = 0, e.minDate = Number.MAX_VALUE, e.minZ = Number.MAX_VALUE, e.maxZ = -Number.MAX_VALUE, e.minXDiff = Number.MAX_VALUE, e.yAxisScale = [], e.xAxisScale = null, e.xAxisTicksPositions = [], e.yLabelsCoords = [], e.yTitleCoords = [], e.barPadForNumericAxis = 0, e.padHorizontal = 0, e.xRange = 0, e.yRange = [], e.zRange = 0, e.dataPoints = 0, e.xTickAmount = 0
                }
            }, {
                key: "globalVars",
                value: function (e) {
                    return {
                        chartID: null,
                        cuid: null,
                        events: {
                            beforeMount: [],
                            mounted: [],
                            updated: [],
                            clicked: [],
                            selection: [],
                            dataPointSelection: [],
                            zoomed: [],
                            scrolled: []
                        },
                        colors: [],
                        clientX: null,
                        clientY: null,
                        fill: {
                            colors: []
                        },
                        stroke: {
                            colors: []
                        },
                        dataLabels: {
                            style: {
                                colors: []
                            }
                        },
                        radarPolygons: {
                            fill: {
                                colors: []
                            }
                        },
                        markers: {
                            colors: [],
                            size: e.markers.size,
                            largestSize: 0
                        },
                        animationEnded: !1,
                        isTouchDevice: "ontouchstart" in window || navigator.msMaxTouchPoints,
                        isDirty: !1,
                        isExecCalled: !1,
                        initialConfig: null,
                        initialSeries: [],
                        lastXAxis: [],
                        lastYAxis: [],
                        columnSeries: null,
                        labels: [],
                        timescaleLabels: [],
                        noLabelsProvided: !1,
                        allSeriesCollapsed: !1,
                        collapsedSeries: [],
                        collapsedSeriesIndices: [],
                        ancillaryCollapsedSeries: [],
                        ancillaryCollapsedSeriesIndices: [],
                        risingSeries: [],
                        dataFormatXNumeric: !1,
                        capturedSeriesIndex: -1,
                        capturedDataPointIndex: -1,
                        selectedDataPoints: [],
                        goldenPadding: 35,
                        invalidLogScale: !1,
                        ignoreYAxisIndexes: [],
                        yAxisSameScaleIndices: [],
                        maxValsInArrayIndex: 0,
                        radialSize: 0,
                        selection: void 0,
                        zoomEnabled: "zoom" === e.chart.toolbar.autoSelected && e.chart.toolbar.tools.zoom && e.chart.zoom.enabled,
                        panEnabled: "pan" === e.chart.toolbar.autoSelected && e.chart.toolbar.tools.pan,
                        selectionEnabled: "selection" === e.chart.toolbar.autoSelected && e.chart.toolbar.tools.selection,
                        yaxis: null,
                        mousedown: !1,
                        lastClientPosition: {},
                        visibleXRange: void 0,
                        yValueDecimal: 0,
                        total: 0,
                        SVGNS: "http://www.w3.org/2000/svg",
                        svgWidth: 0,
                        svgHeight: 0,
                        noData: !1,
                        locale: {},
                        dom: {},
                        memory: {
                            methodsToExec: []
                        },
                        shouldAnimate: !0,
                        skipLastTimelinelabel: !1,
                        skipFirstTimelinelabel: !1,
                        delayedElements: [],
                        axisCharts: !0,
                        isDataXYZ: !1,
                        resized: !1,
                        resizeTimer: null,
                        comboCharts: !1,
                        dataChanged: !1,
                        previousPaths: [],
                        allSeriesHasEqualX: !0,
                        pointsArray: [],
                        dataLabelsRects: [],
                        lastDrawnDataLabelsIndexes: [],
                        hasNullValues: !1,
                        easing: null,
                        zoomed: !1,
                        gridWidth: 0,
                        gridHeight: 0,
                        rotateXLabels: !1,
                        defaultLabels: !1,
                        xLabelFormatter: void 0,
                        yLabelFormatters: [],
                        xaxisTooltipFormatter: void 0,
                        ttKeyFormatter: void 0,
                        ttVal: void 0,
                        ttZFormatter: void 0,
                        LINE_HEIGHT_RATIO: 1.618,
                        xAxisLabelsHeight: 0,
                        xAxisLabelsWidth: 0,
                        yAxisLabelsWidth: 0,
                        scaleX: 1,
                        scaleY: 1,
                        translateX: 0,
                        translateY: 0,
                        translateYAxisX: [],
                        yAxisWidths: [],
                        translateXAxisY: 0,
                        translateXAxisX: 0,
                        tooltip: null
                    }
                }
            }, {
                key: "init",
                value: function (e) {
                    var t = this.globalVars(e);
                    return this.initGlobalVars(t), t.initialConfig = p.extend({}, e), t.initialSeries = p.clone(e.series), t.lastXAxis = p.clone(t.initialConfig.xaxis), t.lastYAxis = p.clone(t.initialConfig.yaxis), t
                }
            }]), e
        }(),
        F = function () {
            function e(t) {
                i(this, e), this.opts = t
            }
            return r(e, [{
                key: "init",
                value: function () {
                    var e = new N(this.opts).init({
                        responsiveOverride: !1
                    });
                    return {
                        config: e,
                        globals: (new H).init(e)
                    }
                }
            }]), e
        }(),
        R = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w, this.twoDSeries = [], this.threeDSeries = [], this.twoDSeriesX = [], this.seriesGoals = [], this.coreUtils = new x(this.ctx)
            }
            return r(e, [{
                key: "isMultiFormat",
                value: function () {
                    return this.isFormatXY() || this.isFormat2DArray()
                }
            }, {
                key: "isFormatXY",
                value: function () {
                    var e = this.w.config.series.slice(),
                        t = new E(this.ctx);
                    if (this.activeSeriesIndex = t.getActiveConfigSeriesIndex(), void 0 !== e[this.activeSeriesIndex].data && e[this.activeSeriesIndex].data.length > 0 && null !== e[this.activeSeriesIndex].data[0] && void 0 !== e[this.activeSeriesIndex].data[0].x && null !== e[this.activeSeriesIndex].data[0]) return !0
                }
            }, {
                key: "isFormat2DArray",
                value: function () {
                    var e = this.w.config.series.slice(),
                        t = new E(this.ctx);
                    if (this.activeSeriesIndex = t.getActiveConfigSeriesIndex(), void 0 !== e[this.activeSeriesIndex].data && e[this.activeSeriesIndex].data.length > 0 && void 0 !== e[this.activeSeriesIndex].data[0] && null !== e[this.activeSeriesIndex].data[0] && e[this.activeSeriesIndex].data[0].constructor === Array) return !0
                }
            }, {
                key: "handleFormat2DArray",
                value: function (e, t) {
                    for (var n = this.w.config, i = this.w.globals, a = "boxPlot" === n.chart.type || "boxPlot" === n.series[t].type, r = 0; r < e[t].data.length; r++)
                        if (void 0 !== e[t].data[r][1] && (Array.isArray(e[t].data[r][1]) && 4 === e[t].data[r][1].length && !a ? this.twoDSeries.push(p.parseNumber(e[t].data[r][1][3])) : e[t].data[r].length >= 5 ? this.twoDSeries.push(p.parseNumber(e[t].data[r][4])) : this.twoDSeries.push(p.parseNumber(e[t].data[r][1])), i.dataFormatXNumeric = !0), "datetime" === n.xaxis.type) {
                            var s = new Date(e[t].data[r][0]);
                            s = new Date(s).getTime(), this.twoDSeriesX.push(s)
                        } else this.twoDSeriesX.push(e[t].data[r][0]);
                    for (var o = 0; o < e[t].data.length; o++) void 0 !== e[t].data[o][2] && (this.threeDSeries.push(e[t].data[o][2]), i.isDataXYZ = !0)
                }
            }, {
                key: "handleFormatXY",
                value: function (e, t) {
                    var n = this.w.config,
                        i = this.w.globals,
                        a = new Y(this.ctx),
                        r = t;
                    i.collapsedSeriesIndices.indexOf(t) > -1 && (r = this.activeSeriesIndex);
                    for (var s = 0; s < e[t].data.length; s++) void 0 !== e[t].data[s].y && (Array.isArray(e[t].data[s].y) ? this.twoDSeries.push(p.parseNumber(e[t].data[s].y[e[t].data[s].y.length - 1])) : this.twoDSeries.push(p.parseNumber(e[t].data[s].y))), void 0 !== e[t].data[s].goals && Array.isArray(e[t].data[s].goals) ? (void 0 === this.seriesGoals[t] && (this.seriesGoals[t] = []), this.seriesGoals[t].push(e[t].data[s].goals)) : (void 0 === this.seriesGoals[t] && (this.seriesGoals[t] = []), this.seriesGoals[t].push(null));
                    for (var o = 0; o < e[r].data.length; o++) {
                        var l = "string" == typeof e[r].data[o].x,
                            c = Array.isArray(e[r].data[o].x),
                            u = !c && !!a.isValidDate(e[r].data[o].x.toString());
                        if (l || u)
                            if (l || n.xaxis.convertedCatToNumeric) {
                                var d = i.isBarHorizontal && i.isRangeData;
                                "datetime" !== n.xaxis.type || d ? (this.fallbackToCategory = !0, this.twoDSeriesX.push(e[r].data[o].x)) : this.twoDSeriesX.push(a.parseDate(e[r].data[o].x))
                            } else "datetime" === n.xaxis.type ? this.twoDSeriesX.push(a.parseDate(e[r].data[o].x.toString())) : (i.dataFormatXNumeric = !0, i.isXNumeric = !0, this.twoDSeriesX.push(parseFloat(e[r].data[o].x)));
                        else c ? (this.fallbackToCategory = !0, this.twoDSeriesX.push(e[r].data[o].x)) : (i.isXNumeric = !0, i.dataFormatXNumeric = !0, this.twoDSeriesX.push(e[r].data[o].x))
                    }
                    if (e[t].data[0] && void 0 !== e[t].data[0].z) {
                        for (var h = 0; h < e[t].data.length; h++) this.threeDSeries.push(e[t].data[h].z);
                        i.isDataXYZ = !0
                    }
                }
            }, {
                key: "handleRangeData",
                value: function (e, t) {
                    var n = this.w.globals,
                        i = {};
                    return this.isFormat2DArray() ? i = this.handleRangeDataFormat("array", e, t) : this.isFormatXY() && (i = this.handleRangeDataFormat("xy", e, t)), n.seriesRangeStart.push(i.start), n.seriesRangeEnd.push(i.end), n.seriesRangeBar.push(i.rangeUniques), n.seriesRangeBar.forEach((function (e, t) {
                        e && e.forEach((function (e, t) {
                            e.y.forEach((function (t, n) {
                                for (var i = 0; i < e.y.length; i++)
                                    if (n !== i) {
                                        var a = t.y1,
                                            r = t.y2,
                                            s = e.y[i].y1;
                                        a <= e.y[i].y2 && s <= r && (e.overlaps.indexOf(t.rangeName) < 0 && e.overlaps.push(t.rangeName), e.overlaps.indexOf(e.y[i].rangeName) < 0 && e.overlaps.push(e.y[i].rangeName))
                                    }
                            }))
                        }))
                    })), i
                }
            }, {
                key: "handleCandleStickBoxData",
                value: function (e, t) {
                    var n = this.w.globals,
                        i = {};
                    return this.isFormat2DArray() ? i = this.handleCandleStickBoxDataFormat("array", e, t) : this.isFormatXY() && (i = this.handleCandleStickBoxDataFormat("xy", e, t)), n.seriesCandleO[t] = i.o, n.seriesCandleH[t] = i.h, n.seriesCandleM[t] = i.m, n.seriesCandleL[t] = i.l, n.seriesCandleC[t] = i.c, i
                }
            }, {
                key: "handleRangeDataFormat",
                value: function (e, t, n) {
                    var i = [],
                        a = [],
                        r = t[n].data.filter((function (e, t, n) {
                            return t === n.findIndex((function (t) {
                                return t.x === e.x
                            }))
                        })).map((function (e, t) {
                            return {
                                x: e.x,
                                overlaps: [],
                                y: []
                            }
                        })),
                        s = "Please provide [Start, End] values in valid format. Read more https://apexcharts.com/docs/series/#rangecharts",
                        o = new E(this.ctx).getActiveConfigSeriesIndex();
                    if ("array" === e) {
                        if (2 !== t[o].data[0][1].length) throw new Error(s);
                        for (var l = 0; l < t[n].data.length; l++) i.push(t[n].data[l][1][0]), a.push(t[n].data[l][1][1])
                    } else if ("xy" === e) {
                        if (2 !== t[o].data[0].y.length) throw new Error(s);
                        for (var c = function (e) {
                                var s = p.randomId(),
                                    o = t[n].data[e].x,
                                    l = {
                                        y1: t[n].data[e].y[0],
                                        y2: t[n].data[e].y[1],
                                        rangeName: s
                                    };
                                t[n].data[e].rangeName = s;
                                var c = r.findIndex((function (e) {
                                    return e.x === o
                                }));
                                r[c].y.push(l), i.push(l.y1), a.push(l.y2)
                            }, u = 0; u < t[n].data.length; u++) c(u)
                    }
                    return {
                        start: i,
                        end: a,
                        rangeUniques: r
                    }
                }
            }, {
                key: "handleCandleStickBoxDataFormat",
                value: function (e, t, n) {
                    var i = this.w,
                        a = "boxPlot" === i.config.chart.type || "boxPlot" === i.config.series[n].type,
                        r = [],
                        s = [],
                        o = [],
                        l = [],
                        c = [];
                    if ("array" === e)
                        if (a && 6 === t[n].data[0].length || !a && 5 === t[n].data[0].length)
                            for (var u = 0; u < t[n].data.length; u++) r.push(t[n].data[u][1]), s.push(t[n].data[u][2]), a ? (o.push(t[n].data[u][3]), l.push(t[n].data[u][4]), c.push(t[n].data[u][5])) : (l.push(t[n].data[u][3]), c.push(t[n].data[u][4]));
                        else
                            for (var d = 0; d < t[n].data.length; d++) Array.isArray(t[n].data[d][1]) && (r.push(t[n].data[d][1][0]), s.push(t[n].data[d][1][1]), a ? (o.push(t[n].data[d][1][2]), l.push(t[n].data[d][1][3]), c.push(t[n].data[d][1][4])) : (l.push(t[n].data[d][1][2]), c.push(t[n].data[d][1][3])));
                    else if ("xy" === e)
                        for (var h = 0; h < t[n].data.length; h++) Array.isArray(t[n].data[h].y) && (r.push(t[n].data[h].y[0]), s.push(t[n].data[h].y[1]), a ? (o.push(t[n].data[h].y[2]), l.push(t[n].data[h].y[3]), c.push(t[n].data[h].y[4])) : (l.push(t[n].data[h].y[2]), c.push(t[n].data[h].y[3])));
                    return {
                        o: r,
                        h: s,
                        m: o,
                        l: l,
                        c: c
                    }
                }
            }, {
                key: "parseDataAxisCharts",
                value: function (e) {
                    var t = this,
                        n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.ctx,
                        i = this.w.config,
                        a = this.w.globals,
                        r = new Y(n),
                        s = i.labels.length > 0 ? i.labels.slice() : i.xaxis.categories.slice();
                    a.isRangeBar = "rangeBar" === i.chart.type && a.isBarHorizontal;
                    for (var o = function () {
                            for (var e = 0; e < s.length; e++)
                                if ("string" == typeof s[e]) {
                                    if (!r.isValidDate(s[e])) throw new Error("You have provided invalid Date format. Please provide a valid JavaScript Date");
                                    t.twoDSeriesX.push(r.parseDate(s[e]))
                                } else t.twoDSeriesX.push(s[e])
                        }, l = 0; l < e.length; l++) {
                        if (this.twoDSeries = [], this.twoDSeriesX = [], this.threeDSeries = [], void 0 === e[l].data) return void console.error("It is a possibility that you may have not included 'data' property in series.");
                        if ("rangeBar" !== i.chart.type && "rangeArea" !== i.chart.type && "rangeBar" !== e[l].type && "rangeArea" !== e[l].type || (a.isRangeData = !0, this.handleRangeData(e, l)), this.isMultiFormat()) this.isFormat2DArray() ? this.handleFormat2DArray(e, l) : this.isFormatXY() && this.handleFormatXY(e, l), "candlestick" !== i.chart.type && "candlestick" !== e[l].type && "boxPlot" !== i.chart.type && "boxPlot" !== e[l].type || this.handleCandleStickBoxData(e, l), a.series.push(this.twoDSeries), a.labels.push(this.twoDSeriesX), a.seriesX.push(this.twoDSeriesX), a.seriesGoals = this.seriesGoals, l !== this.activeSeriesIndex || this.fallbackToCategory || (a.isXNumeric = !0);
                        else {
                            "datetime" === i.xaxis.type ? (a.isXNumeric = !0, o(), a.seriesX.push(this.twoDSeriesX)) : "numeric" === i.xaxis.type && (a.isXNumeric = !0, s.length > 0 && (this.twoDSeriesX = s, a.seriesX.push(this.twoDSeriesX))), a.labels.push(this.twoDSeriesX);
                            var c = e[l].data.map((function (e) {
                                return p.parseNumber(e)
                            }));
                            a.series.push(c)
                        }
                        a.seriesZ.push(this.threeDSeries), void 0 !== e[l].name ? a.seriesNames.push(e[l].name) : a.seriesNames.push("series-" + parseInt(l + 1, 10)), void 0 !== e[l].color ? a.seriesColors.push(e[l].color) : a.seriesColors.push(void 0)
                    }
                    return this.w
                }
            }, {
                key: "parseDataNonAxisCharts",
                value: function (e) {
                    var t = this.w.globals,
                        n = this.w.config;
                    t.series = e.slice(), t.seriesNames = n.labels.slice();
                    for (var i = 0; i < t.series.length; i++) void 0 === t.seriesNames[i] && t.seriesNames.push("series-" + (i + 1));
                    return this.w
                }
            }, {
                key: "handleExternalLabelsData",
                value: function (e) {
                    var t = this.w.config,
                        n = this.w.globals;
                    t.xaxis.categories.length > 0 ? n.labels = t.xaxis.categories : t.labels.length > 0 ? n.labels = t.labels.slice() : this.fallbackToCategory ? (n.labels = n.labels[0], n.seriesRangeBar.length && (n.seriesRangeBar.map((function (e) {
                        e.forEach((function (e) {
                            n.labels.indexOf(e.x) < 0 && e.x && n.labels.push(e.x)
                        }))
                    })), n.labels = n.labels.filter((function (e, t, n) {
                        return n.indexOf(e) === t
                    }))), t.xaxis.convertedCatToNumeric && (new j(t).convertCatToNumericXaxis(t, this.ctx, n.seriesX[0]), this._generateExternalLabels(e))) : this._generateExternalLabels(e)
                }
            }, {
                key: "_generateExternalLabels",
                value: function (e) {
                    var t = this.w.globals,
                        n = this.w.config,
                        i = [];
                    if (t.axisCharts) {
                        if (t.series.length > 0)
                            for (var a = 0; a < t.series[t.maxValsInArrayIndex].length; a++) i.push(a + 1);
                        t.seriesX = [];
                        for (var r = 0; r < e.length; r++) t.seriesX.push(i);
                        t.isXNumeric = !0
                    }
                    if (0 === i.length) {
                        i = t.axisCharts ? [] : t.series.map((function (e, t) {
                            return t + 1
                        }));
                        for (var s = 0; s < e.length; s++) t.seriesX.push(i)
                    }
                    t.labels = i, n.xaxis.convertedCatToNumeric && (t.categoryLabels = i.map((function (e) {
                        return n.xaxis.labels.formatter(e)
                    }))), t.noLabelsProvided = !0
                }
            }, {
                key: "parseData",
                value: function (e) {
                    var t = this.w,
                        n = t.config,
                        i = t.globals;
                    if (this.excludeCollapsedSeriesInYAxis(), this.fallbackToCategory = !1, this.ctx.core.resetGlobals(), this.ctx.core.isMultipleY(), i.axisCharts ? this.parseDataAxisCharts(e) : this.parseDataNonAxisCharts(e), this.coreUtils.getLargestSeries(), "bar" === n.chart.type && n.chart.stacked) {
                        var a = new E(this.ctx);
                        i.series = a.setNullSeriesToZeroValues(i.series)
                    }
                    this.coreUtils.getSeriesTotals(), i.axisCharts && this.coreUtils.getStackedSeriesTotals(), this.coreUtils.getPercentSeries(), i.dataFormatXNumeric || i.isXNumeric && ("numeric" !== n.xaxis.type || 0 !== n.labels.length || 0 !== n.xaxis.categories.length) || this.handleExternalLabelsData(e);
                    for (var r = this.coreUtils.getCategoryLabels(i.labels), s = 0; s < r.length; s++)
                        if (Array.isArray(r[s])) {
                            i.isMultiLineX = !0;
                            break
                        }
                }
            }, {
                key: "excludeCollapsedSeriesInYAxis",
                value: function () {
                    var e = this,
                        t = this.w;
                    t.globals.ignoreYAxisIndexes = t.globals.collapsedSeries.map((function (n, i) {
                        if (e.w.globals.isMultipleYAxis && !t.config.chart.stacked) return n.index
                    }))
                }
            }]), e
        }(),
        z = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w, this.tooltipKeyFormat = "dd MMM"
            }
            return r(e, [{
                key: "xLabelFormat",
                value: function (e, t, n, i) {
                    var a = this.w;
                    if ("datetime" === a.config.xaxis.type && void 0 === a.config.xaxis.labels.formatter && void 0 === a.config.tooltip.x.formatter) {
                        var r = new Y(this.ctx);
                        return r.formatDate(r.getDate(t), a.config.tooltip.x.format)
                    }
                    return e(t, n, i)
                }
            }, {
                key: "defaultGeneralFormatter",
                value: function (e) {
                    return Array.isArray(e) ? e.map((function (e) {
                        return e
                    })) : e
                }
            }, {
                key: "defaultYFormatter",
                value: function (e, t, n) {
                    var i = this.w;
                    return p.isNumber(e) && (e = 0 !== i.globals.yValueDecimal ? e.toFixed(void 0 !== t.decimalsInFloat ? t.decimalsInFloat : i.globals.yValueDecimal) : i.globals.maxYArr[n] - i.globals.minYArr[n] < 5 ? e.toFixed(1) : e.toFixed(0)), e
                }
            }, {
                key: "setLabelFormatters",
                value: function () {
                    var e = this,
                        t = this.w;
                    return t.globals.xaxisTooltipFormatter = function (t) {
                        return e.defaultGeneralFormatter(t)
                    }, t.globals.ttKeyFormatter = function (t) {
                        return e.defaultGeneralFormatter(t)
                    }, t.globals.ttZFormatter = function (e) {
                        return e
                    }, t.globals.legendFormatter = function (t) {
                        return e.defaultGeneralFormatter(t)
                    }, void 0 !== t.config.xaxis.labels.formatter ? t.globals.xLabelFormatter = t.config.xaxis.labels.formatter : t.globals.xLabelFormatter = function (e) {
                        if (p.isNumber(e)) {
                            if (!t.config.xaxis.convertedCatToNumeric && "numeric" === t.config.xaxis.type) {
                                if (p.isNumber(t.config.xaxis.decimalsInFloat)) return e.toFixed(t.config.xaxis.decimalsInFloat);
                                var n = t.globals.maxX - t.globals.minX;
                                return n > 0 && n < 100 ? e.toFixed(1) : e.toFixed(0)
                            }
                            return t.globals.isBarHorizontal && t.globals.maxY - t.globals.minYArr < 4 ? e.toFixed(1) : e.toFixed(0)
                        }
                        return e
                    }, "function" == typeof t.config.tooltip.x.formatter ? t.globals.ttKeyFormatter = t.config.tooltip.x.formatter : t.globals.ttKeyFormatter = t.globals.xLabelFormatter, "function" == typeof t.config.xaxis.tooltip.formatter && (t.globals.xaxisTooltipFormatter = t.config.xaxis.tooltip.formatter), (Array.isArray(t.config.tooltip.y) || void 0 !== t.config.tooltip.y.formatter) && (t.globals.ttVal = t.config.tooltip.y), void 0 !== t.config.tooltip.z.formatter && (t.globals.ttZFormatter = t.config.tooltip.z.formatter), void 0 !== t.config.legend.formatter && (t.globals.legendFormatter = t.config.legend.formatter), t.config.yaxis.forEach((function (n, i) {
                        void 0 !== n.labels.formatter ? t.globals.yLabelFormatters[i] = n.labels.formatter : t.globals.yLabelFormatters[i] = function (a) {
                            return t.globals.xyCharts ? Array.isArray(a) ? a.map((function (t) {
                                return e.defaultYFormatter(t, n, i)
                            })) : e.defaultYFormatter(a, n, i) : a
                        }
                    })), t.globals
                }
            }, {
                key: "heatmapLabelFormatters",
                value: function () {
                    var e = this.w;
                    if ("heatmap" === e.config.chart.type) {
                        e.globals.yAxisScale[0].result = e.globals.seriesNames.slice();
                        var t = e.globals.seriesNames.reduce((function (e, t) {
                            return e.length > t.length ? e : t
                        }), 0);
                        e.globals.yAxisScale[0].niceMax = t, e.globals.yAxisScale[0].niceMin = t
                    }
                }
            }]), e
        }(),
        B = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "getLabel",
                value: function (e, t, n, i) {
                    var a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : [],
                        r = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : "12px",
                        s = this.w,
                        o = void 0 === e[i] ? "" : e[i],
                        l = o,
                        c = s.globals.xLabelFormatter,
                        u = s.config.xaxis.labels.formatter,
                        d = !1,
                        h = new z(this.ctx),
                        f = o;
                    l = h.xLabelFormat(c, o, f, {
                        i: i,
                        dateFormatter: new Y(this.ctx).formatDate,
                        w: s
                    }), void 0 !== u && (l = u(o, e[i], {
                        i: i,
                        dateFormatter: new Y(this.ctx).formatDate,
                        w: s
                    }));
                    var p = function (e) {
                        var n = null;
                        return t.forEach((function (e) {
                            "month" === e.unit ? n = "year" : "day" === e.unit ? n = "month" : "hour" === e.unit ? n = "day" : "minute" === e.unit && (n = "hour")
                        })), n === e
                    };
                    t.length > 0 ? (d = p(t[i].unit), n = t[i].position, l = t[i].value) : "datetime" === s.config.xaxis.type && void 0 === u && (l = ""), void 0 === l && (l = ""), l = Array.isArray(l) ? l : l.toString();
                    var m = new v(this.ctx),
                        g = {};
                    g = s.globals.rotateXLabels ? m.getTextRects(l, parseInt(r, 10), null, "rotate(".concat(s.config.xaxis.labels.rotate, " 0 0)"), !1) : m.getTextRects(l, parseInt(r, 10));
                    var y = !s.config.xaxis.labels.showDuplicates && this.ctx.timeScale;
                    return !Array.isArray(l) && (0 === l.indexOf("NaN") || 0 === l.toLowerCase().indexOf("invalid") || l.toLowerCase().indexOf("infinity") >= 0 || a.indexOf(l) >= 0 && y) && (l = ""), {
                        x: n,
                        text: l,
                        textRect: g,
                        isBold: d
                    }
                }
            }, {
                key: "checkLabelBasedOnTickamount",
                value: function (e, t, n) {
                    var i = this.w,
                        a = i.config.xaxis.tickAmount;
                    return "dataPoints" === a && (a = Math.round(i.globals.gridWidth / 120)), a > n || e % Math.round(n / (a + 1)) == 0 || (t.text = ""), t
                }
            }, {
                key: "checkForOverflowingLabels",
                value: function (e, t, n, i, a) {
                    var r = this.w;
                    if (0 === e && r.globals.skipFirstTimelinelabel && (t.text = ""), e === n - 1 && r.globals.skipLastTimelinelabel && (t.text = ""), r.config.xaxis.labels.hideOverlappingLabels && i.length > 0) {
                        var s = a[a.length - 1];
                        t.x < s.textRect.width / (r.globals.rotateXLabels ? Math.abs(r.config.xaxis.labels.rotate) / 12 : 1.01) + s.x && (t.text = "")
                    }
                    return t
                }
            }, {
                key: "checkForReversedLabels",
                value: function (e, t) {
                    var n = this.w;
                    return n.config.yaxis[e] && n.config.yaxis[e].reversed && t.reverse(), t
                }
            }, {
                key: "isYAxisHidden",
                value: function (e) {
                    var t = this.w,
                        n = new x(this.ctx);
                    return !t.config.yaxis[e].show || !t.config.yaxis[e].showForNullSeries && n.isSeriesNull(e) && -1 === t.globals.collapsedSeriesIndices.indexOf(e)
                }
            }, {
                key: "getYAxisForeColor",
                value: function (e, t) {
                    var n = this.w;
                    return Array.isArray(e) && n.globals.yAxisScale[t] && this.ctx.theme.pushExtraColors(e, n.globals.yAxisScale[t].result.length, !1), e
                }
            }, {
                key: "drawYAxisTicks",
                value: function (e, t, n, i, a, r, s) {
                    var o = this.w,
                        l = new v(this.ctx),
                        c = o.globals.translateY;
                    if (i.show && t > 0) {
                        !0 === o.config.yaxis[a].opposite && (e += i.width);
                        for (var u = t; u >= 0; u--) {
                            var d = c + t / 10 + o.config.yaxis[a].labels.offsetY - 1;
                            o.globals.isBarHorizontal && (d = r * u), "heatmap" === o.config.chart.type && (d += r / 2);
                            var h = l.drawLine(e + n.offsetX - i.width + i.offsetX, d + i.offsetY, e + n.offsetX + i.offsetX, d + i.offsetY, i.color);
                            s.add(h), c += r
                        }
                    }
                }
            }]), e
        }(),
        W = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "scaleSvgNode",
                value: function (e, t) {
                    var n = parseFloat(e.getAttributeNS(null, "width")),
                        i = parseFloat(e.getAttributeNS(null, "height"));
                    e.setAttributeNS(null, "width", n * t), e.setAttributeNS(null, "height", i * t), e.setAttributeNS(null, "viewBox", "0 0 " + n + " " + i)
                }
            }, {
                key: "fixSvgStringForIe11",
                value: function (e) {
                    if (!p.isIE11()) return e.replace(/&nbsp;/g, "&#160;");
                    var t = 0,
                        n = e.replace(/xmlns="http:\/\/www.w3.org\/2000\/svg"/g, (function (e) {
                            return 2 == ++t ? 'xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev"' : e
                        }));
                    return (n = n.replace(/xmlns:NS\d+=""/g, "")).replace(/NS\d+:(\w+:\w+=")/g, "$1")
                }
            }, {
                key: "getSvgString",
                value: function (e) {
                    var t = this.w.globals.dom.Paper.svg();
                    if (1 !== e) {
                        var n = this.w.globals.dom.Paper.node.cloneNode(!0);
                        this.scaleSvgNode(n, e), t = (new XMLSerializer).serializeToString(n)
                    }
                    return this.fixSvgStringForIe11(t)
                }
            }, {
                key: "cleanup",
                value: function () {
                    var e = this.w,
                        t = e.globals.dom.baseEl.getElementsByClassName("apexcharts-xcrosshairs"),
                        n = e.globals.dom.baseEl.getElementsByClassName("apexcharts-ycrosshairs"),
                        i = e.globals.dom.baseEl.querySelectorAll(".apexcharts-zoom-rect, .apexcharts-selection-rect");
                    Array.prototype.forEach.call(i, (function (e) {
                        e.setAttribute("width", 0)
                    })), t && t[0] && (t[0].setAttribute("x", -500), t[0].setAttribute("x1", -500), t[0].setAttribute("x2", -500)), n && n[0] && (n[0].setAttribute("y", -100), n[0].setAttribute("y1", -100), n[0].setAttribute("y2", -100))
                }
            }, {
                key: "svgUrl",
                value: function () {
                    this.cleanup();
                    var e = this.getSvgString(),
                        t = new Blob([e], {
                            type: "image/svg+xml;charset=utf-8"
                        });
                    return URL.createObjectURL(t)
                }
            }, {
                key: "dataURI",
                value: function (e) {
                    var t = this;
                    return new Promise((function (n) {
                        var i = t.w,
                            a = e ? e.scale || e.width / i.globals.svgWidth : 1;
                        t.cleanup();
                        var r = document.createElement("canvas");
                        r.width = i.globals.svgWidth * a, r.height = parseInt(i.globals.dom.elWrap.style.height, 10) * a;
                        var s = "transparent" === i.config.chart.background ? "#fff" : i.config.chart.background,
                            o = r.getContext("2d");
                        o.fillStyle = s, o.fillRect(0, 0, r.width * a, r.height * a);
                        var l = t.getSvgString(a);
                        if (window.canvg && p.isIE11()) {
                            var c = window.canvg.Canvg.fromString(o, l, {
                                ignoreClear: !0,
                                ignoreDimensions: !0
                            });
                            c.start();
                            var u = r.msToBlob();
                            c.stop(), n({
                                blob: u
                            })
                        } else {
                            var d = "data:image/svg+xml," + encodeURIComponent(l),
                                h = new Image;
                            h.crossOrigin = "anonymous", h.onload = function () {
                                if (o.drawImage(h, 0, 0), r.msToBlob) {
                                    var e = r.msToBlob();
                                    n({
                                        blob: e
                                    })
                                } else {
                                    var t = r.toDataURL("image/png");
                                    n({
                                        imgURI: t
                                    })
                                }
                            }, h.src = d
                        }
                    }))
                }
            }, {
                key: "exportToSVG",
                value: function () {
                    this.triggerDownload(this.svgUrl(), this.w.config.chart.toolbar.export.svg.filename, ".svg")
                }
            }, {
                key: "exportToPng",
                value: function () {
                    var e = this;
                    this.dataURI().then((function (t) {
                        var n = t.imgURI,
                            i = t.blob;
                        i ? navigator.msSaveOrOpenBlob(i, e.w.globals.chartID + ".png") : e.triggerDownload(n, e.w.config.chart.toolbar.export.png.filename, ".png")
                    }))
                }
            }, {
                key: "exportToCSV",
                value: function (e) {
                    var t = this,
                        n = e.series,
                        i = e.columnDelimiter,
                        a = e.lineDelimiter,
                        r = void 0 === a ? "\n" : a,
                        s = this.w,
                        o = [],
                        l = [],
                        c = "",
                        u = new R(this.ctx),
                        d = new B(this.ctx),
                        h = function (e) {
                            var n = "";
                            if (s.globals.axisCharts) {
                                if ("category" === s.config.xaxis.type || s.config.xaxis.convertedCatToNumeric)
                                    if (s.globals.isBarHorizontal) {
                                        var a = s.globals.yLabelFormatters[0],
                                            r = new E(t.ctx).getActiveConfigSeriesIndex();
                                        n = a(s.globals.labels[e], {
                                            seriesIndex: r,
                                            dataPointIndex: e,
                                            w: s
                                        })
                                    } else n = d.getLabel(s.globals.labels, s.globals.timescaleLabels, 0, e).text;
                                "datetime" === s.config.xaxis.type && (s.config.xaxis.categories.length ? n = s.config.xaxis.categories[e] : s.config.labels.length && (n = s.config.labels[e]))
                            } else n = s.config.labels[e];
                            return Array.isArray(n) && (n = n.join(" ")), p.isNumber(n) ? n : n.split(i).join("")
                        };
                    o.push(s.config.chart.toolbar.export.csv.headerCategory), n.map((function (e, t) {
                        var n = e.name ? e.name : "series-".concat(t);
                        s.globals.axisCharts && o.push(n.split(i).join("") ? n.split(i).join("") : "series-".concat(t))
                    })), s.globals.axisCharts || (o.push(s.config.chart.toolbar.export.csv.headerValue), l.push(o.join(i))), n.map((function (e, t) {
                        s.globals.axisCharts ? function (e, t) {
                            if (o.length && 0 === t && l.push(o.join(i)), e.data && e.data.length)
                                for (var a = 0; a < e.data.length; a++) {
                                    o = [];
                                    var r = h(a);
                                    if (r || (u.isFormatXY() ? r = n[t].data[a].x : u.isFormat2DArray() && (r = n[t].data[a] ? n[t].data[a][0] : "")), 0 === t) {
                                        o.push((d = r, "datetime" === s.config.xaxis.type && String(d).length >= 10 ? s.config.chart.toolbar.export.csv.dateFormatter(r) : p.isNumber(r) ? r : r.split(i).join("")));
                                        for (var c = 0; c < s.globals.series.length; c++) o.push(s.globals.series[c][a])
                                    }("candlestick" === s.config.chart.type || e.type && "candlestick" === e.type) && (o.pop(), o.push(s.globals.seriesCandleO[t][a]), o.push(s.globals.seriesCandleH[t][a]), o.push(s.globals.seriesCandleL[t][a]), o.push(s.globals.seriesCandleC[t][a])), ("boxPlot" === s.config.chart.type || e.type && "boxPlot" === e.type) && (o.pop(), o.push(s.globals.seriesCandleO[t][a]), o.push(s.globals.seriesCandleH[t][a]), o.push(s.globals.seriesCandleM[t][a]), o.push(s.globals.seriesCandleL[t][a]), o.push(s.globals.seriesCandleC[t][a])), "rangeBar" === s.config.chart.type && (o.pop(), o.push(s.globals.seriesRangeStart[t][a]), o.push(s.globals.seriesRangeEnd[t][a])), o.length && l.push(o.join(i))
                                }
                            var d
                        }(e, t) : ((o = []).push(s.globals.labels[t].split(i).join("")), o.push(s.globals.series[t]), l.push(o.join(i)))
                    })), c += l.join(r), this.triggerDownload("data:text/csv; charset=utf-8," + encodeURIComponent("\ufeff" + c), s.config.chart.toolbar.export.csv.filename, ".csv")
                }
            }, {
                key: "triggerDownload",
                value: function (e, t, n) {
                    var i = document.createElement("a");
                    i.href = e, i.download = (t || this.w.globals.chartID) + n, document.body.appendChild(i), i.click(), document.body.removeChild(i)
                }
            }]), e
        }(),
        V = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w;
                var n = this.w;
                this.axesUtils = new B(t), this.xaxisLabels = n.globals.labels.slice(), n.globals.timescaleLabels.length > 0 && !n.globals.isBarHorizontal && (this.xaxisLabels = n.globals.timescaleLabels.slice()), n.config.xaxis.overwriteCategories && (this.xaxisLabels = n.config.xaxis.overwriteCategories), this.drawnLabels = [], this.drawnLabelsRects = [], "top" === n.config.xaxis.position ? this.offY = 0 : this.offY = n.globals.gridHeight + 1, this.offY = this.offY + n.config.xaxis.axisBorder.offsetY, this.isCategoryBarHorizontal = "bar" === n.config.chart.type && n.config.plotOptions.bar.horizontal, this.xaxisFontSize = n.config.xaxis.labels.style.fontSize, this.xaxisFontFamily = n.config.xaxis.labels.style.fontFamily, this.xaxisForeColors = n.config.xaxis.labels.style.colors, this.xaxisBorderWidth = n.config.xaxis.axisBorder.width, this.isCategoryBarHorizontal && (this.xaxisBorderWidth = n.config.yaxis[0].axisBorder.width.toString()), this.xaxisBorderWidth.indexOf("%") > -1 ? this.xaxisBorderWidth = n.globals.gridWidth * parseInt(this.xaxisBorderWidth, 10) / 100 : this.xaxisBorderWidth = parseInt(this.xaxisBorderWidth, 10), this.xaxisBorderHeight = n.config.xaxis.axisBorder.height, this.yaxis = n.config.yaxis[0]
            }
            return r(e, [{
                key: "drawXaxis",
                value: function () {
                    var e, t = this,
                        n = this.w,
                        i = new v(this.ctx),
                        a = i.group({
                            class: "apexcharts-xaxis",
                            transform: "translate(".concat(n.config.xaxis.offsetX, ", ").concat(n.config.xaxis.offsetY, ")")
                        }),
                        r = i.group({
                            class: "apexcharts-xaxis-texts-g",
                            transform: "translate(".concat(n.globals.translateXAxisX, ", ").concat(n.globals.translateXAxisY, ")")
                        });
                    a.add(r);
                    for (var s = n.globals.padHorizontal, o = [], l = 0; l < this.xaxisLabels.length; l++) o.push(this.xaxisLabels[l]);
                    var c = o.length;
                    if (n.globals.isXNumeric) {
                        var u = c > 1 ? c - 1 : c;
                        e = n.globals.gridWidth / u, s = s + e / 2 + n.config.xaxis.labels.offsetX
                    } else e = n.globals.gridWidth / o.length, s = s + e + n.config.xaxis.labels.offsetX;
                    for (var d = function (a) {
                            var l = s - e / 2 + n.config.xaxis.labels.offsetX;
                            0 === a && 1 === c && e / 2 === s && 1 === n.globals.dataPoints && (l = n.globals.gridWidth / 2);
                            var u = t.axesUtils.getLabel(o, n.globals.timescaleLabels, l, a, t.drawnLabels, t.xaxisFontSize),
                                d = 28;
                            if (n.globals.rotateXLabels && (d = 22), (u = void 0 !== n.config.xaxis.tickAmount && "dataPoints" !== n.config.xaxis.tickAmount && "datetime" !== n.config.xaxis.type ? t.axesUtils.checkLabelBasedOnTickamount(a, u, c) : t.axesUtils.checkForOverflowingLabels(a, u, c, t.drawnLabels, t.drawnLabelsRects)).text && n.globals.xaxisLabelsCount++, n.config.xaxis.labels.show) {
                                var h = i.drawText({
                                    x: u.x,
                                    y: t.offY + n.config.xaxis.labels.offsetY + d - ("top" === n.config.xaxis.position ? n.globals.xAxisHeight + n.config.xaxis.axisTicks.height - 2 : 0),
                                    text: u.text,
                                    textAnchor: "middle",
                                    fontWeight: u.isBold ? 600 : n.config.xaxis.labels.style.fontWeight,
                                    fontSize: t.xaxisFontSize,
                                    fontFamily: t.xaxisFontFamily,
                                    foreColor: Array.isArray(t.xaxisForeColors) ? n.config.xaxis.convertedCatToNumeric ? t.xaxisForeColors[n.globals.minX + a - 1] : t.xaxisForeColors[a] : t.xaxisForeColors,
                                    isPlainText: !1,
                                    cssClass: "apexcharts-xaxis-label " + n.config.xaxis.labels.style.cssClass
                                });
                                r.add(h);
                                var f = document.createElementNS(n.globals.SVGNS, "title");
                                f.textContent = Array.isArray(u.text) ? u.text.join(" ") : u.text, h.node.appendChild(f), "" !== u.text && (t.drawnLabels.push(u.text), t.drawnLabelsRects.push(u))
                            }
                            s += e
                        }, h = 0; h <= c - 1; h++) d(h);
                    if (void 0 !== n.config.xaxis.title.text) {
                        var f = i.group({
                                class: "apexcharts-xaxis-title"
                            }),
                            p = i.drawText({
                                x: n.globals.gridWidth / 2 + n.config.xaxis.title.offsetX,
                                y: this.offY + parseFloat(this.xaxisFontSize) + n.globals.xAxisLabelsHeight + n.config.xaxis.title.offsetY,
                                text: n.config.xaxis.title.text,
                                textAnchor: "middle",
                                fontSize: n.config.xaxis.title.style.fontSize,
                                fontFamily: n.config.xaxis.title.style.fontFamily,
                                fontWeight: n.config.xaxis.title.style.fontWeight,
                                foreColor: n.config.xaxis.title.style.color,
                                cssClass: "apexcharts-xaxis-title-text " + n.config.xaxis.title.style.cssClass
                            });
                        f.add(p), a.add(f)
                    }
                    if (n.config.xaxis.axisBorder.show) {
                        var m = n.globals.barPadForNumericAxis,
                            g = i.drawLine(n.globals.padHorizontal + n.config.xaxis.axisBorder.offsetX - m, this.offY, this.xaxisBorderWidth + m, this.offY, n.config.xaxis.axisBorder.color, 0, this.xaxisBorderHeight);
                        a.add(g)
                    }
                    return a
                }
            }, {
                key: "drawXaxisInversed",
                value: function (e) {
                    var t, n, i = this,
                        a = this.w,
                        r = new v(this.ctx),
                        s = a.config.yaxis[0].opposite ? a.globals.translateYAxisX[e] : 0,
                        o = r.group({
                            class: "apexcharts-yaxis apexcharts-xaxis-inversed",
                            rel: e
                        }),
                        l = r.group({
                            class: "apexcharts-yaxis-texts-g apexcharts-xaxis-inversed-texts-g",
                            transform: "translate(" + s + ", 0)"
                        });
                    o.add(l);
                    var c = [];
                    if (a.config.yaxis[e].show)
                        for (var u = 0; u < this.xaxisLabels.length; u++) c.push(this.xaxisLabels[u]);
                    t = a.globals.gridHeight / c.length, n = -t / 2.2;
                    var d = a.globals.yLabelFormatters[0],
                        h = a.config.yaxis[0].labels;
                    if (h.show)
                        for (var f = function (s) {
                                var o = void 0 === c[s] ? "" : c[s];
                                o = d(o, {
                                    seriesIndex: e,
                                    dataPointIndex: s,
                                    w: a
                                });
                                var u = i.axesUtils.getYAxisForeColor(h.style.colors, e),
                                    f = 0;
                                Array.isArray(o) && (f = o.length / 2 * parseInt(h.style.fontSize, 10));
                                var p = r.drawText({
                                    x: h.offsetX - 15,
                                    y: n + t + h.offsetY - f,
                                    text: o,
                                    textAnchor: i.yaxis.opposite ? "start" : "end",
                                    foreColor: Array.isArray(u) ? u[s] : u,
                                    fontSize: h.style.fontSize,
                                    fontFamily: h.style.fontFamily,
                                    fontWeight: h.style.fontWeight,
                                    isPlainText: !1,
                                    cssClass: "apexcharts-yaxis-label " + h.style.cssClass
                                });
                                l.add(p);
                                var m = document.createElementNS(a.globals.SVGNS, "title");
                                if (m.textContent = Array.isArray(o) ? o.join(" ") : o, p.node.appendChild(m), 0 !== a.config.yaxis[e].labels.rotate) {
                                    var g = r.rotateAroundCenter(p.node);
                                    p.node.setAttribute("transform", "rotate(".concat(a.config.yaxis[e].labels.rotate, " 0 ").concat(g.y, ")"))
                                }
                                n += t
                            }, p = 0; p <= c.length - 1; p++) f(p);
                    if (void 0 !== a.config.yaxis[0].title.text) {
                        var m = r.group({
                                class: "apexcharts-yaxis-title apexcharts-xaxis-title-inversed",
                                transform: "translate(" + s + ", 0)"
                            }),
                            g = r.drawText({
                                x: 0,
                                y: a.globals.gridHeight / 2,
                                text: a.config.yaxis[0].title.text,
                                textAnchor: "middle",
                                foreColor: a.config.yaxis[0].title.style.color,
                                fontSize: a.config.yaxis[0].title.style.fontSize,
                                fontWeight: a.config.yaxis[0].title.style.fontWeight,
                                fontFamily: a.config.yaxis[0].title.style.fontFamily,
                                cssClass: "apexcharts-yaxis-title-text " + a.config.yaxis[0].title.style.cssClass
                            });
                        m.add(g), o.add(m)
                    }
                    var y = 0;
                    this.isCategoryBarHorizontal && a.config.yaxis[0].opposite && (y = a.globals.gridWidth);
                    var b = a.config.xaxis.axisBorder;
                    if (b.show) {
                        var x = r.drawLine(a.globals.padHorizontal + b.offsetX + y, 1 + b.offsetY, a.globals.padHorizontal + b.offsetX + y, a.globals.gridHeight + b.offsetY, b.color, 0);
                        o.add(x)
                    }
                    return a.config.yaxis[0].axisTicks.show && this.axesUtils.drawYAxisTicks(y, c.length, a.config.yaxis[0].axisBorder, a.config.yaxis[0].axisTicks, 0, t, o), o
                }
            }, {
                key: "drawXaxisTicks",
                value: function (e, t) {
                    var n = this.w,
                        i = e;
                    if (!(e < 0 || e - 2 > n.globals.gridWidth)) {
                        var a = this.offY + n.config.xaxis.axisTicks.offsetY,
                            r = a + n.config.xaxis.axisTicks.height;
                        if ("top" === n.config.xaxis.position && (r = a - n.config.xaxis.axisTicks.height), n.config.xaxis.axisTicks.show) {
                            var s = new v(this.ctx).drawLine(e + n.config.xaxis.axisTicks.offsetX, a + n.config.xaxis.offsetY, i + n.config.xaxis.axisTicks.offsetX, r + n.config.xaxis.offsetY, n.config.xaxis.axisTicks.color);
                            t.add(s), s.node.classList.add("apexcharts-xaxis-tick")
                        }
                    }
                }
            }, {
                key: "getXAxisTicksPositions",
                value: function () {
                    var e = this.w,
                        t = [],
                        n = this.xaxisLabels.length,
                        i = e.globals.padHorizontal;
                    if (e.globals.timescaleLabels.length > 0)
                        for (var a = 0; a < n; a++) i = this.xaxisLabels[a].position, t.push(i);
                    else
                        for (var r = n, s = 0; s < r; s++) {
                            var o = r;
                            e.globals.isXNumeric && "bar" !== e.config.chart.type && (o -= 1), i += e.globals.gridWidth / o, t.push(i)
                        }
                    return t
                }
            }, {
                key: "xAxisLabelCorrections",
                value: function () {
                    var e = this.w,
                        t = new v(this.ctx),
                        n = e.globals.dom.baseEl.querySelector(".apexcharts-xaxis-texts-g"),
                        i = e.globals.dom.baseEl.querySelectorAll(".apexcharts-xaxis-texts-g text"),
                        a = e.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxis-inversed text"),
                        r = e.globals.dom.baseEl.querySelectorAll(".apexcharts-xaxis-inversed-texts-g text tspan");
                    if (e.globals.rotateXLabels || e.config.xaxis.labels.rotateAlways)
                        for (var s = 0; s < i.length; s++) {
                            var o = t.rotateAroundCenter(i[s]);
                            o.y = o.y - 1, o.x = o.x + 1, i[s].setAttribute("transform", "rotate(".concat(e.config.xaxis.labels.rotate, " ").concat(o.x, " ").concat(o.y, ")")), i[s].setAttribute("text-anchor", "end"), n.setAttribute("transform", "translate(0, ".concat(-10, ")"));
                            var l = i[s].childNodes;
                            e.config.xaxis.labels.trim && Array.prototype.forEach.call(l, (function (n) {
                                t.placeTextWithEllipsis(n, n.textContent, e.globals.xAxisLabelsHeight - ("bottom" === e.config.legend.position ? 20 : 10))
                            }))
                        } else ! function () {
                            for (var n = e.globals.gridWidth / (e.globals.labels.length + 1), a = 0; a < i.length; a++) {
                                var r = i[a].childNodes;
                                e.config.xaxis.labels.trim && "datetime" !== e.config.xaxis.type && Array.prototype.forEach.call(r, (function (e) {
                                    t.placeTextWithEllipsis(e, e.textContent, n)
                                }))
                            }
                        }();
                    if (a.length > 0) {
                        var c = a[a.length - 1].getBBox(),
                            u = a[0].getBBox();
                        c.x < -20 && a[a.length - 1].parentNode.removeChild(a[a.length - 1]), u.x + u.width > e.globals.gridWidth && !e.globals.isBarHorizontal && a[0].parentNode.removeChild(a[0]);
                        for (var d = 0; d < r.length; d++) t.placeTextWithEllipsis(r[d], r[d].textContent, e.config.yaxis[0].labels.maxWidth - 2 * parseFloat(e.config.yaxis[0].title.style.fontSize) - 20)
                    }
                }
            }]), e
        }(),
        q = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w;
                var n = this.w;
                this.xaxisLabels = n.globals.labels.slice(), this.axesUtils = new B(t), this.isRangeBar = n.globals.seriesRangeBar.length, n.globals.timescaleLabels.length > 0 && (this.xaxisLabels = n.globals.timescaleLabels.slice())
            }
            return r(e, [{
                key: "drawGridArea",
                value: function () {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                        t = this.w,
                        n = new v(this.ctx);
                    null === e && (e = n.group({
                        class: "apexcharts-grid"
                    }));
                    var i = n.drawLine(t.globals.padHorizontal, 1, t.globals.padHorizontal, t.globals.gridHeight, "transparent"),
                        a = n.drawLine(t.globals.padHorizontal, t.globals.gridHeight, t.globals.gridWidth, t.globals.gridHeight, "transparent");
                    return e.add(a), e.add(i), e
                }
            }, {
                key: "drawGrid",
                value: function () {
                    var e = null;
                    return this.w.globals.axisCharts && (e = this.renderGrid(), this.drawGridArea(e.el)), e
                }
            }, {
                key: "createGridMask",
                value: function () {
                    var e = this.w,
                        t = e.globals,
                        n = new v(this.ctx),
                        i = Array.isArray(e.config.stroke.width) ? 0 : e.config.stroke.width;
                    if (Array.isArray(e.config.stroke.width)) {
                        var a = 0;
                        e.config.stroke.width.forEach((function (e) {
                            a = Math.max(a, e)
                        })), i = a
                    }
                    t.dom.elGridRectMask = document.createElementNS(t.SVGNS, "clipPath"), t.dom.elGridRectMask.setAttribute("id", "gridRectMask".concat(t.cuid)), t.dom.elGridRectMarkerMask = document.createElementNS(t.SVGNS, "clipPath"), t.dom.elGridRectMarkerMask.setAttribute("id", "gridRectMarkerMask".concat(t.cuid)), t.dom.elForecastMask = document.createElementNS(t.SVGNS, "clipPath"), t.dom.elForecastMask.setAttribute("id", "forecastMask".concat(t.cuid)), t.dom.elNonForecastMask = document.createElementNS(t.SVGNS, "clipPath"), t.dom.elNonForecastMask.setAttribute("id", "nonForecastMask".concat(t.cuid));
                    var r = e.config.chart.type,
                        s = 0,
                        o = 0;
                    ("bar" === r || "rangeBar" === r || "candlestick" === r || "boxPlot" === r || e.globals.comboBarCount > 0) && e.globals.isXNumeric && !e.globals.isBarHorizontal && (s = e.config.grid.padding.left, o = e.config.grid.padding.right, t.barPadForNumericAxis > s && (s = t.barPadForNumericAxis, o = t.barPadForNumericAxis)), t.dom.elGridRect = n.drawRect(-i / 2 - s - 2, -i / 2, t.gridWidth + i + o + s + 4, t.gridHeight + i, 0, "#fff"), new x(this).getLargestMarkerSize();
                    var l = e.globals.markers.largestSize + 1;
                    t.dom.elGridRectMarker = n.drawRect(2 * -l, 2 * -l, t.gridWidth + 4 * l, t.gridHeight + 4 * l, 0, "#fff"), t.dom.elGridRectMask.appendChild(t.dom.elGridRect.node), t.dom.elGridRectMarkerMask.appendChild(t.dom.elGridRectMarker.node);
                    var c = t.dom.baseEl.querySelector("defs");
                    c.appendChild(t.dom.elGridRectMask), c.appendChild(t.dom.elForecastMask), c.appendChild(t.dom.elNonForecastMask), c.appendChild(t.dom.elGridRectMarkerMask)
                }
            }, {
                key: "_drawGridLines",
                value: function (e) {
                    var t = e.i,
                        n = e.x1,
                        i = e.y1,
                        a = e.x2,
                        r = e.y2,
                        s = e.xCount,
                        o = e.parent,
                        l = this.w;
                    0 === t && l.globals.skipFirstTimelinelabel || t === s - 1 && l.globals.skipLastTimelinelabel && !l.config.xaxis.labels.formatter || "radar" === l.config.chart.type || (l.config.grid.xaxis.lines.show && this._drawGridLine({
                        x1: n,
                        y1: i,
                        x2: a,
                        y2: r,
                        parent: o
                    }), new V(this.ctx).drawXaxisTicks(n, this.elg))
                }
            }, {
                key: "_drawGridLine",
                value: function (e) {
                    var t = e.x1,
                        n = e.y1,
                        i = e.x2,
                        a = e.y2,
                        r = e.parent,
                        s = this.w,
                        o = r.node.classList.contains("apexcharts-gridlines-horizontal"),
                        l = s.config.grid.strokeDashArray,
                        c = s.globals.barPadForNumericAxis,
                        u = new v(this).drawLine(t - (o ? c : 0), n, i + (o ? c : 0), a, s.config.grid.borderColor, l);
                    u.node.classList.add("apexcharts-gridline"), r.add(u)
                }
            }, {
                key: "_drawGridBandRect",
                value: function (e) {
                    var t = e.c,
                        n = e.x1,
                        i = e.y1,
                        a = e.x2,
                        r = e.y2,
                        s = e.type,
                        o = this.w,
                        l = new v(this.ctx),
                        c = o.globals.barPadForNumericAxis;
                    if ("column" !== s || "datetime" !== o.config.xaxis.type) {
                        var u = o.config.grid[s].colors[t],
                            d = l.drawRect(n - ("row" === s ? c : 0), i, a + ("row" === s ? 2 * c : 0), r, 0, u, o.config.grid[s].opacity);
                        this.elg.add(d), d.attr("clip-path", "url(#gridRectMask".concat(o.globals.cuid, ")")), d.node.classList.add("apexcharts-grid-".concat(s))
                    }
                }
            }, {
                key: "_drawXYLines",
                value: function (e) {
                    var t = this,
                        n = e.xCount,
                        i = e.tickAmount,
                        a = this.w;
                    if (a.config.grid.xaxis.lines.show || a.config.xaxis.axisTicks.show) {
                        var r, s = a.globals.padHorizontal,
                            o = a.globals.gridHeight;
                        a.globals.timescaleLabels.length ? function (e) {
                            for (var i = e.xC, a = e.x1, r = e.y1, s = e.x2, o = e.y2, l = 0; l < i; l++) a = t.xaxisLabels[l].position, s = t.xaxisLabels[l].position, t._drawGridLines({
                                i: l,
                                x1: a,
                                y1: r,
                                x2: s,
                                y2: o,
                                xCount: n,
                                parent: t.elgridLinesV
                            })
                        }({
                            xC: n,
                            x1: s,
                            y1: 0,
                            x2: r,
                            y2: o
                        }) : (a.globals.isXNumeric && (n = a.globals.xAxisScale.result.length), a.config.xaxis.convertedCatToNumeric && (n = a.globals.xaxisLabelsCount), function (e) {
                            var i = e.xC,
                                r = e.x1,
                                s = e.y1,
                                o = e.x2,
                                l = e.y2;
                            if (void 0 !== a.config.xaxis.tickAmount && "dataPoints" !== a.config.xaxis.tickAmount) a.globals.dom.baseEl.querySelectorAll(".apexcharts-text.apexcharts-xaxis-label tspan:not(:empty)").forEach((function (e, i) {
                                var a = e.getBBox();
                                t._drawGridLines({
                                    i: i,
                                    x1: a.x + a.width / 2,
                                    y1: s,
                                    x2: a.x + a.width / 2,
                                    y2: l,
                                    xCount: n,
                                    parent: t.elgridLinesV
                                })
                            }));
                            else
                                for (var c = 0; c < i + (a.globals.isXNumeric ? 0 : 1); c++) 0 === c && 1 === i && 1 === a.globals.dataPoints && (o = r = a.globals.gridWidth / 2), t._drawGridLines({
                                    i: c,
                                    x1: r,
                                    y1: s,
                                    x2: o,
                                    y2: l,
                                    xCount: n,
                                    parent: t.elgridLinesV
                                }), o = r += a.globals.gridWidth / (a.globals.isXNumeric ? i - 1 : i)
                        }({
                            xC: n,
                            x1: s,
                            y1: 0,
                            x2: r,
                            y2: o
                        }))
                    }
                    if (a.config.grid.yaxis.lines.show) {
                        var l = 0,
                            c = 0,
                            u = a.globals.gridWidth,
                            d = i + 1;
                        this.isRangeBar && (d = a.globals.labels.length);
                        for (var h = 0; h < d + (this.isRangeBar ? 1 : 0); h++) this._drawGridLine({
                            x1: 0,
                            y1: l,
                            x2: u,
                            y2: c,
                            parent: this.elgridLinesH
                        }), c = l += a.globals.gridHeight / (this.isRangeBar ? d : i)
                    }
                }
            }, {
                key: "_drawInvertedXYLines",
                value: function (e) {
                    var t = e.xCount,
                        n = this.w;
                    if (n.config.grid.xaxis.lines.show || n.config.xaxis.axisTicks.show)
                        for (var i, a = n.globals.padHorizontal, r = n.globals.gridHeight, s = 0; s < t + 1; s++) n.config.grid.xaxis.lines.show && this._drawGridLine({
                            x1: a,
                            y1: 0,
                            x2: i,
                            y2: r,
                            parent: this.elgridLinesV
                        }), new V(this.ctx).drawXaxisTicks(a, this.elg), i = a = a + n.globals.gridWidth / t + .3;
                    if (n.config.grid.yaxis.lines.show)
                        for (var o = 0, l = 0, c = n.globals.gridWidth, u = 0; u < n.globals.dataPoints + 1; u++) this._drawGridLine({
                            x1: 0,
                            y1: o,
                            x2: c,
                            y2: l,
                            parent: this.elgridLinesH
                        }), l = o += n.globals.gridHeight / n.globals.dataPoints
                }
            }, {
                key: "renderGrid",
                value: function () {
                    var e = this.w,
                        t = new v(this.ctx);
                    this.elg = t.group({
                        class: "apexcharts-grid"
                    }), this.elgridLinesH = t.group({
                        class: "apexcharts-gridlines-horizontal"
                    }), this.elgridLinesV = t.group({
                        class: "apexcharts-gridlines-vertical"
                    }), this.elg.add(this.elgridLinesH), this.elg.add(this.elgridLinesV), e.config.grid.show || (this.elgridLinesV.hide(), this.elgridLinesH.hide());
                    for (var n, i = e.globals.yAxisScale.length ? e.globals.yAxisScale[0].result.length - 1 : 5, a = 0; a < e.globals.series.length && (void 0 !== e.globals.yAxisScale[a] && (i = e.globals.yAxisScale[a].result.length - 1), !(i > 2)); a++);
                    return !e.globals.isBarHorizontal || this.isRangeBar ? (n = this.xaxisLabels.length, this.isRangeBar && (i = e.globals.labels.length, e.config.xaxis.tickAmount && e.config.xaxis.labels.formatter && (n = e.config.xaxis.tickAmount)), this._drawXYLines({
                        xCount: n,
                        tickAmount: i
                    })) : (n = i, i = e.globals.xTickAmount, this._drawInvertedXYLines({
                        xCount: n,
                        tickAmount: i
                    })), this.drawGridBands(n, i), {
                        el: this.elg,
                        xAxisTickWidth: e.globals.gridWidth / n
                    }
                }
            }, {
                key: "drawGridBands",
                value: function (e, t) {
                    var n = this.w;
                    if (void 0 !== n.config.grid.row.colors && n.config.grid.row.colors.length > 0)
                        for (var i = 0, a = n.globals.gridHeight / t, r = n.globals.gridWidth, s = 0, o = 0; s < t; s++, o++) o >= n.config.grid.row.colors.length && (o = 0), this._drawGridBandRect({
                            c: o,
                            x1: 0,
                            y1: i,
                            x2: r,
                            y2: a,
                            type: "row"
                        }), i += n.globals.gridHeight / t;
                    if (void 0 !== n.config.grid.column.colors && n.config.grid.column.colors.length > 0)
                        for (var l = n.globals.isBarHorizontal || "category" !== n.config.xaxis.type && !n.config.xaxis.convertedCatToNumeric ? e : e - 1, c = n.globals.padHorizontal, u = n.globals.padHorizontal + n.globals.gridWidth / l, d = n.globals.gridHeight, h = 0, f = 0; h < e; h++, f++) f >= n.config.grid.column.colors.length && (f = 0), this._drawGridBandRect({
                            c: f,
                            x1: c,
                            y1: 0,
                            x2: u,
                            y2: d,
                            type: "column"
                        }), c += n.globals.gridWidth / l
                }
            }]), e
        }(),
        X = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "niceScale",
                value: function (e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 10,
                        i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
                        a = arguments.length > 4 ? arguments[4] : void 0,
                        r = this.w,
                        s = Math.abs(t - e);
                    if ("dataPoints" === (n = this._adjustTicksForSmallRange(n, i, s)) && (n = r.globals.dataPoints - 1), e === Number.MIN_VALUE && 0 === t || !p.isNumber(e) && !p.isNumber(t) || e === Number.MIN_VALUE && t === -Number.MAX_VALUE) {
                        e = 0, t = n;
                        var o = this.linearScale(e, t, n);
                        return o
                    }
                    e > t ? (console.warn("axis.min cannot be greater than axis.max"), t = e + .1) : e === t && (e = 0 === e ? 0 : e - .5, t = 0 === t ? 2 : t + .5);
                    var l = [];
                    s < 1 && a && ("candlestick" === r.config.chart.type || "candlestick" === r.config.series[i].type || "boxPlot" === r.config.chart.type || "boxPlot" === r.config.series[i].type || r.globals.isRangeData) && (t *= 1.01);
                    var c = n + 1;
                    c < 2 ? c = 2 : c > 2 && (c -= 2);
                    var u = s / c,
                        d = Math.floor(p.log10(u)),
                        h = Math.pow(10, d),
                        f = Math.round(u / h);
                    f < 1 && (f = 1);
                    var m = f * h,
                        g = m * Math.floor(e / m),
                        v = m * Math.ceil(t / m),
                        y = g;
                    if (a && s > 2) {
                        for (; l.push(y), !((y += m) > v););
                        return {
                            result: l,
                            niceMin: l[0],
                            niceMax: l[l.length - 1]
                        }
                    }
                    var b = e;
                    (l = []).push(b);
                    for (var x = Math.abs(t - e) / n, _ = 0; _ <= n; _++) b += x, l.push(b);
                    return l[l.length - 2] >= t && l.pop(), {
                        result: l,
                        niceMin: l[0],
                        niceMax: l[l.length - 1]
                    }
                }
            }, {
                key: "linearScale",
                value: function (e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 10,
                        i = arguments.length > 3 ? arguments[3] : void 0,
                        a = Math.abs(t - e);
                    "dataPoints" === (n = this._adjustTicksForSmallRange(n, i, a)) && (n = this.w.globals.dataPoints - 1);
                    var r = a / n;
                    n === Number.MAX_VALUE && (n = 10, r = 1);
                    for (var s = [], o = e; n >= 0;) s.push(o), o += r, n -= 1;
                    return {
                        result: s,
                        niceMin: s[0],
                        niceMax: s[s.length - 1]
                    }
                }
            }, {
                key: "logarithmicScale",
                value: function (e, t, n) {
                    for (var i = [], a = Math.ceil(Math.log(t) / Math.log(n)) + 1, r = 0; r < a; r++) i.push(Math.pow(n, r));
                    return 0 === e && i.unshift(e), {
                        result: i,
                        niceMin: i[0],
                        niceMax: i[i.length - 1]
                    }
                }
            }, {
                key: "_adjustTicksForSmallRange",
                value: function (e, t, n) {
                    var i = e;
                    if (void 0 !== t && this.w.config.yaxis[t].labels.formatter && void 0 === this.w.config.yaxis[t].tickAmount) {
                        var a = this.w.config.yaxis[t].labels.formatter(1);
                        p.isNumber(Number(a)) && !p.isFloat(a) && (i = Math.ceil(n))
                    }
                    return i < e ? i : e
                }
            }, {
                key: "setYScaleForIndex",
                value: function (e, t, n) {
                    var i = this.w.globals,
                        a = this.w.config,
                        r = i.isBarHorizontal ? a.xaxis : a.yaxis[e];
                    void 0 === i.yAxisScale[e] && (i.yAxisScale[e] = []);
                    var s = Math.abs(n - t);
                    if (r.logarithmic && s <= 5 && (i.invalidLogScale = !0), r.logarithmic && s > 5) i.allSeriesCollapsed = !1, i.yAxisScale[e] = this.logarithmicScale(t, n, r.logBase);
                    else if (n !== -Number.MAX_VALUE && p.isNumber(n))
                        if (i.allSeriesCollapsed = !1, void 0 === r.min && void 0 === r.max || r.forceNiceScale) {
                            var o = void 0 === a.yaxis[e].max && void 0 === a.yaxis[e].min || a.yaxis[e].forceNiceScale;
                            i.yAxisScale[e] = this.niceScale(t, n, r.tickAmount ? r.tickAmount : s < 5 && s > 1 ? s + 1 : 5, e, o)
                        } else i.yAxisScale[e] = this.linearScale(t, n, r.tickAmount, e);
                    else i.yAxisScale[e] = this.linearScale(0, 5, 5)
                }
            }, {
                key: "setXScale",
                value: function (e, t) {
                    var n = this.w,
                        i = n.globals,
                        a = n.config.xaxis,
                        r = Math.abs(t - e);
                    return t !== -Number.MAX_VALUE && p.isNumber(t) ? i.xAxisScale = this.linearScale(e, t, a.tickAmount ? a.tickAmount : r < 5 && r > 1 ? r + 1 : 5, 0) : i.xAxisScale = this.linearScale(0, 5, 5), i.xAxisScale
                }
            }, {
                key: "setMultipleYScales",
                value: function () {
                    var e = this,
                        t = this.w.globals,
                        n = this.w.config,
                        i = t.minYArr.concat([]),
                        a = t.maxYArr.concat([]),
                        r = [];
                    n.yaxis.forEach((function (t, s) {
                        var o = s;
                        n.series.forEach((function (e, n) {
                            e.name === t.seriesName && (o = n, s !== n ? r.push({
                                index: n,
                                similarIndex: s,
                                alreadyExists: !0
                            }) : r.push({
                                index: n
                            }))
                        }));
                        var l = i[o],
                            c = a[o];
                        e.setYScaleForIndex(s, l, c)
                    })), this.sameScaleInMultipleAxes(i, a, r)
                }
            }, {
                key: "sameScaleInMultipleAxes",
                value: function (e, t, n) {
                    var i = this,
                        a = this.w.config,
                        r = this.w.globals,
                        s = [];
                    n.forEach((function (e) {
                        e.alreadyExists && (void 0 === s[e.index] && (s[e.index] = []), s[e.index].push(e.index), s[e.index].push(e.similarIndex))
                    })), r.yAxisSameScaleIndices = s, s.forEach((function (e, t) {
                        s.forEach((function (n, i) {
                            var a, r;
                            t !== i && (a = e, r = n, a.filter((function (e) {
                                return -1 !== r.indexOf(e)
                            }))).length > 0 && (s[t] = s[t].concat(s[i]))
                        }))
                    }));
                    var o = s.map((function (e) {
                        return e.filter((function (t, n) {
                            return e.indexOf(t) === n
                        }))
                    })).map((function (e) {
                        return e.sort()
                    }));
                    s = s.filter((function (e) {
                        return !!e
                    }));
                    var l = o.slice(),
                        c = l.map((function (e) {
                            return JSON.stringify(e)
                        }));
                    l = l.filter((function (e, t) {
                        return c.indexOf(JSON.stringify(e)) === t
                    }));
                    var u = [],
                        d = [];
                    e.forEach((function (e, n) {
                        l.forEach((function (i, a) {
                            i.indexOf(n) > -1 && (void 0 === u[a] && (u[a] = [], d[a] = []), u[a].push({
                                key: n,
                                value: e
                            }), d[a].push({
                                key: n,
                                value: t[n]
                            }))
                        }))
                    }));
                    var h = Array.apply(null, Array(l.length)).map(Number.prototype.valueOf, Number.MIN_VALUE),
                        f = Array.apply(null, Array(l.length)).map(Number.prototype.valueOf, -Number.MAX_VALUE);
                    u.forEach((function (e, t) {
                        e.forEach((function (e, n) {
                            h[t] = Math.min(e.value, h[t])
                        }))
                    })), d.forEach((function (e, t) {
                        e.forEach((function (e, n) {
                            f[t] = Math.max(e.value, f[t])
                        }))
                    })), e.forEach((function (e, t) {
                        d.forEach((function (e, n) {
                            var s = h[n],
                                o = f[n];
                            a.chart.stacked && (o = 0, e.forEach((function (e, t) {
                                e.value !== -Number.MAX_VALUE && (o += e.value), s !== Number.MIN_VALUE && (s += u[n][t].value)
                            }))), e.forEach((function (n, l) {
                                e[l].key === t && (void 0 !== a.yaxis[t].min && (s = "function" == typeof a.yaxis[t].min ? a.yaxis[t].min(r.minY) : a.yaxis[t].min), void 0 !== a.yaxis[t].max && (o = "function" == typeof a.yaxis[t].max ? a.yaxis[t].max(r.maxY) : a.yaxis[t].max), i.setYScaleForIndex(t, s, o))
                            }))
                        }))
                    }))
                }
            }, {
                key: "autoScaleY",
                value: function (e, t, n) {
                    e || (e = this);
                    var i = e.w;
                    if (i.globals.isMultipleYAxis || i.globals.collapsedSeries.length) return console.warn("autoScaleYaxis is not supported in a multi-yaxis chart."), t;
                    var a = i.globals.seriesX[0],
                        r = i.config.chart.stacked;
                    return t.forEach((function (e, s) {
                        for (var o = 0, l = 0; l < a.length; l++)
                            if (a[l] >= n.xaxis.min) {
                                o = l;
                                break
                            } var c, u, d = i.globals.minYArr[s],
                            h = i.globals.maxYArr[s],
                            f = i.globals.stackedSeriesTotals;
                        i.globals.series.forEach((function (s, l) {
                            var p = s[o];
                            r ? (p = f[o], c = u = p, f.forEach((function (e, t) {
                                a[t] <= n.xaxis.max && a[t] >= n.xaxis.min && (e > u && null !== e && (u = e), s[t] < c && null !== s[t] && (c = s[t]))
                            }))) : (c = u = p, s.forEach((function (e, t) {
                                if (a[t] <= n.xaxis.max && a[t] >= n.xaxis.min) {
                                    var r = e,
                                        s = e;
                                    i.globals.series.forEach((function (n, i) {
                                        null !== e && (r = Math.min(n[t], r), s = Math.max(n[t], s))
                                    })), s > u && null !== s && (u = s), r < c && null !== r && (c = r)
                                }
                            }))), void 0 === c && void 0 === u && (c = d, u = h), (u *= u < 0 ? .9 : 1.1) < 0 && u < h && (u = h), (c *= c < 0 ? 1.1 : .9) < 0 && c > d && (c = d), t.length > 1 ? (t[l].min = void 0 === e.min ? c : e.min, t[l].max = void 0 === e.max ? u : e.max) : (t[0].min = void 0 === e.min ? c : e.min, t[0].max = void 0 === e.max ? u : e.max)
                        }))
                    })), t
                }
            }]), e
        }(),
        U = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w, this.scales = new X(t)
            }
            return r(e, [{
                key: "init",
                value: function () {
                    this.setYRange(), this.setXRange(), this.setZRange()
                }
            }, {
                key: "getMinYMaxY",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Number.MAX_VALUE,
                        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : -Number.MAX_VALUE,
                        i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
                        a = this.w.config,
                        r = this.w.globals,
                        s = -Number.MAX_VALUE,
                        o = Number.MIN_VALUE;
                    null === i && (i = e + 1);
                    var l = r.series,
                        c = l,
                        u = l;
                    "candlestick" === a.chart.type ? (c = r.seriesCandleL, u = r.seriesCandleH) : "boxPlot" === a.chart.type ? (c = r.seriesCandleO, u = r.seriesCandleC) : r.isRangeData && (c = r.seriesRangeStart, u = r.seriesRangeEnd);
                    for (var d = e; d < i; d++) {
                        r.dataPoints = Math.max(r.dataPoints, l[d].length);
                        for (var h = 0; h < r.series[d].length; h++) {
                            var f = l[d][h];
                            null !== f && p.isNumber(f) ? (void 0 !== u[d][h] && (s = Math.max(s, u[d][h]), t = Math.min(t, u[d][h])), void 0 !== c[d][h] && (t = Math.min(t, c[d][h]), n = Math.max(n, c[d][h])), "candlestick" !== this.w.config.chart.type && "boxPlot" !== this.w.config.chart.type || (void 0 !== r.seriesCandleC[d][h] && (s = Math.max(s, r.seriesCandleO[d][h]), s = Math.max(s, r.seriesCandleH[d][h]), s = Math.max(s, r.seriesCandleL[d][h]), s = Math.max(s, r.seriesCandleC[d][h]), "boxPlot" === this.w.config.chart.type && (s = Math.max(s, r.seriesCandleM[d][h]))), !a.series[d].type || "candlestick" === a.series[d].type && "boxPlot" === a.series[d].type || (s = Math.max(s, r.series[d][h]), t = Math.min(t, r.series[d][h])), n = s), r.seriesGoals[d] && r.seriesGoals[d][h] && Array.isArray(r.seriesGoals[d][h]) && r.seriesGoals[d][h].forEach((function (e) {
                                o !== Number.MIN_VALUE && (o = Math.min(o, e.value), t = o), s = Math.max(s, e.value), n = s
                            })), p.isFloat(f) && (f = p.noExponents(f), r.yValueDecimal = Math.max(r.yValueDecimal, f.toString().split(".")[1].length)), o > c[d][h] && c[d][h] < 0 && (o = c[d][h])) : r.hasNullValues = !0
                        }
                    }
                    return "rangeBar" === a.chart.type && r.seriesRangeStart.length && r.isBarHorizontal && (o = t), "bar" === a.chart.type && (o < 0 && s < 0 && (s = 0), o === Number.MIN_VALUE && (o = 0)), {
                        minY: o,
                        maxY: s,
                        lowestY: t,
                        highestY: n
                    }
                }
            }, {
                key: "setYRange",
                value: function () {
                    var e = this.w.globals,
                        t = this.w.config;
                    e.maxY = -Number.MAX_VALUE, e.minY = Number.MIN_VALUE;
                    var n = Number.MAX_VALUE;
                    if (e.isMultipleYAxis)
                        for (var i = 0; i < e.series.length; i++) {
                            var a = this.getMinYMaxY(i, n, null, i + 1);
                            e.minYArr.push(a.minY), e.maxYArr.push(a.maxY), n = a.lowestY
                        }
                    var r = this.getMinYMaxY(0, n, null, e.series.length);
                    if (e.minY = r.minY, e.maxY = r.maxY, n = r.lowestY, t.chart.stacked && this._setStackedMinMax(), ("line" === t.chart.type || "area" === t.chart.type || "candlestick" === t.chart.type || "boxPlot" === t.chart.type || "rangeBar" === t.chart.type && !e.isBarHorizontal) && e.minY === Number.MIN_VALUE && n !== -Number.MAX_VALUE && n !== e.maxY) {
                        var s = e.maxY - n;
                        (n >= 0 && n <= 10 || void 0 !== t.yaxis[0].min || void 0 !== t.yaxis[0].max) && (s = 0), e.minY = n - 5 * s / 100, n > 0 && e.minY < 0 && (e.minY = 0), e.maxY = e.maxY + 5 * s / 100
                    }
                    return t.yaxis.forEach((function (t, n) {
                        void 0 !== t.max && ("number" == typeof t.max ? e.maxYArr[n] = t.max : "function" == typeof t.max && (e.maxYArr[n] = t.max(e.isMultipleYAxis ? e.maxYArr[n] : e.maxY)), e.maxY = e.maxYArr[n]), void 0 !== t.min && ("number" == typeof t.min ? e.minYArr[n] = t.min : "function" == typeof t.min && (e.minYArr[n] = t.min(e.isMultipleYAxis ? e.minYArr[n] === Number.MIN_VALUE ? 0 : e.minYArr[n] : e.minY)), e.minY = e.minYArr[n])
                    })), e.isBarHorizontal && ["min", "max"].forEach((function (n) {
                        void 0 !== t.xaxis[n] && "number" == typeof t.xaxis[n] && ("min" === n ? e.minY = t.xaxis[n] : e.maxY = t.xaxis[n])
                    })), e.isMultipleYAxis ? (this.scales.setMultipleYScales(), e.minY = n, e.yAxisScale.forEach((function (t, n) {
                        e.minYArr[n] = t.niceMin, e.maxYArr[n] = t.niceMax
                    }))) : (this.scales.setYScaleForIndex(0, e.minY, e.maxY), e.minY = e.yAxisScale[0].niceMin, e.maxY = e.yAxisScale[0].niceMax, e.minYArr[0] = e.yAxisScale[0].niceMin, e.maxYArr[0] = e.yAxisScale[0].niceMax), {
                        minY: e.minY,
                        maxY: e.maxY,
                        minYArr: e.minYArr,
                        maxYArr: e.maxYArr,
                        yAxisScale: e.yAxisScale
                    }
                }
            }, {
                key: "setXRange",
                value: function () {
                    var e = this.w.globals,
                        t = this.w.config,
                        n = "numeric" === t.xaxis.type || "datetime" === t.xaxis.type || "category" === t.xaxis.type && !e.noLabelsProvided || e.noLabelsProvided || e.isXNumeric;
                    if (e.isXNumeric && function () {
                            for (var t = 0; t < e.series.length; t++)
                                if (e.labels[t])
                                    for (var n = 0; n < e.labels[t].length; n++) null !== e.labels[t][n] && p.isNumber(e.labels[t][n]) && (e.maxX = Math.max(e.maxX, e.labels[t][n]), e.initialMaxX = Math.max(e.maxX, e.labels[t][n]), e.minX = Math.min(e.minX, e.labels[t][n]), e.initialMinX = Math.min(e.minX, e.labels[t][n]))
                        }(), e.noLabelsProvided && 0 === t.xaxis.categories.length && (e.maxX = e.labels[e.labels.length - 1], e.initialMaxX = e.labels[e.labels.length - 1], e.minX = 1, e.initialMinX = 1), e.isXNumeric || e.noLabelsProvided || e.dataFormatXNumeric) {
                        var i;
                        if (void 0 === t.xaxis.tickAmount ? (i = Math.round(e.svgWidth / 150), "numeric" === t.xaxis.type && e.dataPoints < 30 && (i = e.dataPoints - 1), i > e.dataPoints && 0 !== e.dataPoints && (i = e.dataPoints - 1)) : "dataPoints" === t.xaxis.tickAmount ? (e.series.length > 1 && (i = e.series[e.maxValsInArrayIndex].length - 1), e.isXNumeric && (i = e.maxX - e.minX - 1)) : i = t.xaxis.tickAmount, e.xTickAmount = i, void 0 !== t.xaxis.max && "number" == typeof t.xaxis.max && (e.maxX = t.xaxis.max), void 0 !== t.xaxis.min && "number" == typeof t.xaxis.min && (e.minX = t.xaxis.min), void 0 !== t.xaxis.range && (e.minX = e.maxX - t.xaxis.range), e.minX !== Number.MAX_VALUE && e.maxX !== -Number.MAX_VALUE)
                            if (t.xaxis.convertedCatToNumeric && !e.dataFormatXNumeric) {
                                for (var a = [], r = e.minX - 1; r < e.maxX; r++) a.push(r + 1);
                                e.xAxisScale = {
                                    result: a,
                                    niceMin: a[0],
                                    niceMax: a[a.length - 1]
                                }
                            } else e.xAxisScale = this.scales.setXScale(e.minX, e.maxX);
                        else e.xAxisScale = this.scales.linearScale(1, i, i), e.noLabelsProvided && e.labels.length > 0 && (e.xAxisScale = this.scales.linearScale(1, e.labels.length, i - 1), e.seriesX = e.labels.slice());
                        n && (e.labels = e.xAxisScale.result.slice())
                    }
                    return e.isBarHorizontal && e.labels.length && (e.xTickAmount = e.labels.length), this._handleSingleDataPoint(), this._getMinXDiff(), {
                        minX: e.minX,
                        maxX: e.maxX
                    }
                }
            }, {
                key: "setZRange",
                value: function () {
                    var e = this.w.globals;
                    if (e.isDataXYZ)
                        for (var t = 0; t < e.series.length; t++)
                            if (void 0 !== e.seriesZ[t])
                                for (var n = 0; n < e.seriesZ[t].length; n++) null !== e.seriesZ[t][n] && p.isNumber(e.seriesZ[t][n]) && (e.maxZ = Math.max(e.maxZ, e.seriesZ[t][n]), e.minZ = Math.min(e.minZ, e.seriesZ[t][n]))
                }
            }, {
                key: "_handleSingleDataPoint",
                value: function () {
                    var e = this.w.globals,
                        t = this.w.config;
                    if (e.minX === e.maxX) {
                        var n = new Y(this.ctx);
                        if ("datetime" === t.xaxis.type) {
                            var i = n.getDate(e.minX);
                            t.xaxis.labels.datetimeUTC ? i.setUTCDate(i.getUTCDate() - 2) : i.setDate(i.getDate() - 2), e.minX = new Date(i).getTime();
                            var a = n.getDate(e.maxX);
                            t.xaxis.labels.datetimeUTC ? a.setUTCDate(a.getUTCDate() + 2) : a.setDate(a.getDate() + 2), e.maxX = new Date(a).getTime()
                        } else("numeric" === t.xaxis.type || "category" === t.xaxis.type && !e.noLabelsProvided) && (e.minX = e.minX - 2, e.initialMinX = e.minX, e.maxX = e.maxX + 2, e.initialMaxX = e.maxX)
                    }
                }
            }, {
                key: "_getMinXDiff",
                value: function () {
                    var e = this.w.globals;
                    e.isXNumeric && e.seriesX.forEach((function (t, n) {
                        1 === t.length && t.push(e.seriesX[e.maxValsInArrayIndex][e.seriesX[e.maxValsInArrayIndex].length - 1]);
                        var i = t.slice();
                        i.sort((function (e, t) {
                            return e - t
                        })), i.forEach((function (t, n) {
                            if (n > 0) {
                                var a = t - i[n - 1];
                                a > 0 && (e.minXDiff = Math.min(a, e.minXDiff))
                            }
                        })), 1 === e.dataPoints && e.minXDiff === Number.MAX_VALUE && (e.minXDiff = .5)
                    }))
                }
            }, {
                key: "_setStackedMinMax",
                value: function () {
                    var e = this.w.globals,
                        t = [],
                        n = [];
                    if (e.series.length)
                        for (var i = 0; i < e.series[e.maxValsInArrayIndex].length; i++)
                            for (var a = 0, r = 0, s = 0; s < e.series.length; s++) null !== e.series[s][i] && p.isNumber(e.series[s][i]) && (e.series[s][i] > 0 ? a = a + parseFloat(e.series[s][i]) + 1e-4 : r += parseFloat(e.series[s][i])), s === e.series.length - 1 && (t.push(a), n.push(r));
                    for (var o = 0; o < t.length; o++) e.maxY = Math.max(e.maxY, t[o]), e.minY = Math.min(e.minY, n[o])
                }
            }]), e
        }(),
        $ = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w;
                var n = this.w;
                this.xaxisFontSize = n.config.xaxis.labels.style.fontSize, this.axisFontFamily = n.config.xaxis.labels.style.fontFamily, this.xaxisForeColors = n.config.xaxis.labels.style.colors, this.isCategoryBarHorizontal = "bar" === n.config.chart.type && n.config.plotOptions.bar.horizontal, this.xAxisoffX = 0, "bottom" === n.config.xaxis.position && (this.xAxisoffX = n.globals.gridHeight), this.drawnLabels = [], this.axesUtils = new B(t)
            }
            return r(e, [{
                key: "drawYaxis",
                value: function (e) {
                    var t = this,
                        n = this.w,
                        i = new v(this.ctx),
                        a = n.config.yaxis[e].labels.style,
                        r = a.fontSize,
                        s = a.fontFamily,
                        o = a.fontWeight,
                        l = i.group({
                            class: "apexcharts-yaxis",
                            rel: e,
                            transform: "translate(" + n.globals.translateYAxisX[e] + ", 0)"
                        });
                    if (this.axesUtils.isYAxisHidden(e)) return l;
                    var c = i.group({
                        class: "apexcharts-yaxis-texts-g"
                    });
                    l.add(c);
                    var u = n.globals.yAxisScale[e].result.length - 1,
                        d = n.globals.gridHeight / u,
                        h = n.globals.translateY,
                        f = n.globals.yLabelFormatters[e],
                        p = n.globals.yAxisScale[e].result.slice();
                    p = this.axesUtils.checkForReversedLabels(e, p);
                    var m = "";
                    if (n.config.yaxis[e].labels.show)
                        for (var g = function (l) {
                                var g = p[l];
                                g = f(g, l, n);
                                var v = n.config.yaxis[e].labels.padding;
                                n.config.yaxis[e].opposite && 0 !== n.config.yaxis.length && (v *= -1);
                                var y = t.axesUtils.getYAxisForeColor(a.colors, e),
                                    b = i.drawText({
                                        x: v,
                                        y: h + u / 10 + n.config.yaxis[e].labels.offsetY + 1,
                                        text: g,
                                        textAnchor: n.config.yaxis[e].opposite ? "start" : "end",
                                        fontSize: r,
                                        fontFamily: s,
                                        fontWeight: o,
                                        foreColor: Array.isArray(y) ? y[l] : y,
                                        isPlainText: !1,
                                        cssClass: "apexcharts-yaxis-label " + a.cssClass
                                    });
                                l === u && (m = b), c.add(b);
                                var x = document.createElementNS(n.globals.SVGNS, "title");
                                if (x.textContent = Array.isArray(g) ? g.join(" ") : g, b.node.appendChild(x), 0 !== n.config.yaxis[e].labels.rotate) {
                                    var _ = i.rotateAroundCenter(m.node),
                                        w = i.rotateAroundCenter(b.node);
                                    b.node.setAttribute("transform", "rotate(".concat(n.config.yaxis[e].labels.rotate, " ").concat(_.x, " ").concat(w.y, ")"))
                                }
                                h += d
                            }, y = u; y >= 0; y--) g(y);
                    if (void 0 !== n.config.yaxis[e].title.text) {
                        var b = i.group({
                                class: "apexcharts-yaxis-title"
                            }),
                            x = 0;
                        n.config.yaxis[e].opposite && (x = n.globals.translateYAxisX[e]);
                        var _ = i.drawText({
                            x: x,
                            y: n.globals.gridHeight / 2 + n.globals.translateY + n.config.yaxis[e].title.offsetY,
                            text: n.config.yaxis[e].title.text,
                            textAnchor: "end",
                            foreColor: n.config.yaxis[e].title.style.color,
                            fontSize: n.config.yaxis[e].title.style.fontSize,
                            fontWeight: n.config.yaxis[e].title.style.fontWeight,
                            fontFamily: n.config.yaxis[e].title.style.fontFamily,
                            cssClass: "apexcharts-yaxis-title-text " + n.config.yaxis[e].title.style.cssClass
                        });
                        b.add(_), l.add(b)
                    }
                    var w = n.config.yaxis[e].axisBorder,
                        k = 31 + w.offsetX;
                    if (n.config.yaxis[e].opposite && (k = -31 - w.offsetX), w.show) {
                        var M = i.drawLine(k, n.globals.translateY + w.offsetY - 2, k, n.globals.gridHeight + n.globals.translateY + w.offsetY + 2, w.color, 0, w.width);
                        l.add(M)
                    }
                    return n.config.yaxis[e].axisTicks.show && this.axesUtils.drawYAxisTicks(k, u, w, n.config.yaxis[e].axisTicks, e, d, l), l
                }
            }, {
                key: "drawYaxisInversed",
                value: function (e) {
                    var t = this.w,
                        n = new v(this.ctx),
                        i = n.group({
                            class: "apexcharts-xaxis apexcharts-yaxis-inversed"
                        }),
                        a = n.group({
                            class: "apexcharts-xaxis-texts-g",
                            transform: "translate(".concat(t.globals.translateXAxisX, ", ").concat(t.globals.translateXAxisY, ")")
                        });
                    i.add(a);
                    var r = t.globals.yAxisScale[e].result.length - 1,
                        s = t.globals.gridWidth / r + .1,
                        o = s + t.config.xaxis.labels.offsetX,
                        l = t.globals.xLabelFormatter,
                        c = t.globals.yAxisScale[e].result.slice(),
                        u = t.globals.timescaleLabels;
                    u.length > 0 && (this.xaxisLabels = u.slice(), r = (c = u.slice()).length), c = this.axesUtils.checkForReversedLabels(e, c);
                    var d = u.length;
                    if (t.config.xaxis.labels.show)
                        for (var h = d ? 0 : r; d ? h < d : h >= 0; d ? h++ : h--) {
                            var f = c[h];
                            f = l(f, h, t);
                            var p = t.globals.gridWidth + t.globals.padHorizontal - (o - s + t.config.xaxis.labels.offsetX);
                            if (u.length) {
                                var m = this.axesUtils.getLabel(c, u, p, h, this.drawnLabels, this.xaxisFontSize);
                                p = m.x, f = m.text, this.drawnLabels.push(m.text), 0 === h && t.globals.skipFirstTimelinelabel && (f = ""), h === c.length - 1 && t.globals.skipLastTimelinelabel && (f = "")
                            }
                            var g = n.drawText({
                                x: p,
                                y: this.xAxisoffX + t.config.xaxis.labels.offsetY + 30 - ("top" === t.config.xaxis.position ? t.globals.xAxisHeight + t.config.xaxis.axisTicks.height - 2 : 0),
                                text: f,
                                textAnchor: "middle",
                                foreColor: Array.isArray(this.xaxisForeColors) ? this.xaxisForeColors[e] : this.xaxisForeColors,
                                fontSize: this.xaxisFontSize,
                                fontFamily: this.xaxisFontFamily,
                                fontWeight: t.config.xaxis.labels.style.fontWeight,
                                isPlainText: !1,
                                cssClass: "apexcharts-xaxis-label " + t.config.xaxis.labels.style.cssClass
                            });
                            a.add(g), g.tspan(f);
                            var y = document.createElementNS(t.globals.SVGNS, "title");
                            y.textContent = f, g.node.appendChild(y), o += s
                        }
                    return this.inversedYAxisTitleText(i), this.inversedYAxisBorder(i), i
                }
            }, {
                key: "inversedYAxisBorder",
                value: function (e) {
                    var t = this.w,
                        n = new v(this.ctx),
                        i = t.config.xaxis.axisBorder;
                    if (i.show) {
                        var a = 0;
                        "bar" === t.config.chart.type && t.globals.isXNumeric && (a -= 15);
                        var r = n.drawLine(t.globals.padHorizontal + a + i.offsetX, this.xAxisoffX, t.globals.gridWidth, this.xAxisoffX, i.color, 0, i.height);
                        e.add(r)
                    }
                }
            }, {
                key: "inversedYAxisTitleText",
                value: function (e) {
                    var t = this.w,
                        n = new v(this.ctx);
                    if (void 0 !== t.config.xaxis.title.text) {
                        var i = n.group({
                                class: "apexcharts-xaxis-title apexcharts-yaxis-title-inversed"
                            }),
                            a = n.drawText({
                                x: t.globals.gridWidth / 2 + t.config.xaxis.title.offsetX,
                                y: this.xAxisoffX + parseFloat(this.xaxisFontSize) + parseFloat(t.config.xaxis.title.style.fontSize) + t.config.xaxis.title.offsetY + 20,
                                text: t.config.xaxis.title.text,
                                textAnchor: "middle",
                                fontSize: t.config.xaxis.title.style.fontSize,
                                fontFamily: t.config.xaxis.title.style.fontFamily,
                                fontWeight: t.config.xaxis.title.style.fontWeight,
                                foreColor: t.config.xaxis.title.style.color,
                                cssClass: "apexcharts-xaxis-title-text " + t.config.xaxis.title.style.cssClass
                            });
                        i.add(a), e.add(i)
                    }
                }
            }, {
                key: "yAxisTitleRotate",
                value: function (e, t) {
                    var n = this.w,
                        i = new v(this.ctx),
                        a = {
                            width: 0,
                            height: 0
                        },
                        r = {
                            width: 0,
                            height: 0
                        },
                        s = n.globals.dom.baseEl.querySelector(" .apexcharts-yaxis[rel='".concat(e, "'] .apexcharts-yaxis-texts-g"));
                    null !== s && (a = s.getBoundingClientRect());
                    var o = n.globals.dom.baseEl.querySelector(".apexcharts-yaxis[rel='".concat(e, "'] .apexcharts-yaxis-title text"));
                    if (null !== o && (r = o.getBoundingClientRect()), null !== o) {
                        var l = this.xPaddingForYAxisTitle(e, a, r, t);
                        o.setAttribute("x", l.xPos - (t ? 10 : 0))
                    }
                    if (null !== o) {
                        var c = i.rotateAroundCenter(o);
                        o.setAttribute("transform", "rotate(".concat(t ? -1 * n.config.yaxis[e].title.rotate : n.config.yaxis[e].title.rotate, " ").concat(c.x, " ").concat(c.y, ")"))
                    }
                }
            }, {
                key: "xPaddingForYAxisTitle",
                value: function (e, t, n, i) {
                    var a = this.w,
                        r = 0,
                        s = 0,
                        o = 10;
                    return void 0 === a.config.yaxis[e].title.text || e < 0 ? {
                        xPos: s,
                        padd: 0
                    } : (i ? (s = t.width + a.config.yaxis[e].title.offsetX + n.width / 2 + o / 2, 0 === (r += 1) && (s -= o / 2)) : (s = -1 * t.width + a.config.yaxis[e].title.offsetX + o / 2 + n.width / 2, a.globals.isBarHorizontal && (o = 25, s = -1 * t.width - a.config.yaxis[e].title.offsetX - o)), {
                        xPos: s,
                        padd: o
                    })
                }
            }, {
                key: "setYAxisXPosition",
                value: function (e, t) {
                    var n = this.w,
                        i = 0,
                        a = 0,
                        r = 18,
                        s = 1;
                    n.config.yaxis.length > 1 && (this.multipleYs = !0), n.config.yaxis.map((function (o, l) {
                        var c = n.globals.ignoreYAxisIndexes.indexOf(l) > -1 || !o.show || o.floating || 0 === e[l].width,
                            u = e[l].width + t[l].width;
                        o.opposite ? n.globals.isBarHorizontal ? (a = n.globals.gridWidth + n.globals.translateX - 1, n.globals.translateYAxisX[l] = a - o.labels.offsetX) : (a = n.globals.gridWidth + n.globals.translateX + s, c || (s = s + u + 20), n.globals.translateYAxisX[l] = a - o.labels.offsetX + 20) : (i = n.globals.translateX - r, c || (r = r + u + 20), n.globals.translateYAxisX[l] = i + o.labels.offsetX)
                    }))
                }
            }, {
                key: "setYAxisTextAlignments",
                value: function () {
                    var e = this.w,
                        t = e.globals.dom.baseEl.getElementsByClassName("apexcharts-yaxis");
                    (t = p.listToArray(t)).forEach((function (t, n) {
                        var i = e.config.yaxis[n];
                        if (i && void 0 !== i.labels.align) {
                            var a = e.globals.dom.baseEl.querySelector(".apexcharts-yaxis[rel='".concat(n, "'] .apexcharts-yaxis-texts-g")),
                                r = e.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxis[rel='".concat(n, "'] .apexcharts-yaxis-label"));
                            r = p.listToArray(r);
                            var s = a.getBoundingClientRect();
                            "left" === i.labels.align ? (r.forEach((function (e, t) {
                                e.setAttribute("text-anchor", "start")
                            })), i.opposite || a.setAttribute("transform", "translate(-".concat(s.width, ", 0)"))) : "center" === i.labels.align ? (r.forEach((function (e, t) {
                                e.setAttribute("text-anchor", "middle")
                            })), a.setAttribute("transform", "translate(".concat(s.width / 2 * (i.opposite ? 1 : -1), ", 0)"))) : "right" === i.labels.align && (r.forEach((function (e, t) {
                                e.setAttribute("text-anchor", "end")
                            })), i.opposite && a.setAttribute("transform", "translate(".concat(s.width, ", 0)")))
                        }
                    }))
                }
            }]), e
        }(),
        G = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w, this.documentEvent = p.bind(this.documentEvent, this)
            }
            return r(e, [{
                key: "addEventListener",
                value: function (e, t) {
                    var n = this.w;
                    n.globals.events.hasOwnProperty(e) ? n.globals.events[e].push(t) : n.globals.events[e] = [t]
                }
            }, {
                key: "removeEventListener",
                value: function (e, t) {
                    var n = this.w;
                    if (n.globals.events.hasOwnProperty(e)) {
                        var i = n.globals.events[e].indexOf(t); - 1 !== i && n.globals.events[e].splice(i, 1)
                    }
                }
            }, {
                key: "fireEvent",
                value: function (e, t) {
                    var n = this.w;
                    if (n.globals.events.hasOwnProperty(e)) {
                        t && t.length || (t = []);
                        for (var i = n.globals.events[e], a = i.length, r = 0; r < a; r++) i[r].apply(null, t)
                    }
                }
            }, {
                key: "setupEventHandlers",
                value: function () {
                    var e = this,
                        t = this.w,
                        n = this.ctx,
                        i = t.globals.dom.baseEl.querySelector(t.globals.chartClass);
                    this.ctx.eventList.forEach((function (e) {
                        i.addEventListener(e, (function (e) {
                            var i = Object.assign({}, t, {
                                seriesIndex: t.globals.capturedSeriesIndex,
                                dataPointIndex: t.globals.capturedDataPointIndex
                            });
                            "mousemove" === e.type || "touchmove" === e.type ? "function" == typeof t.config.chart.events.mouseMove && t.config.chart.events.mouseMove(e, n, i) : "mouseleave" === e.type || "touchleave" === e.type ? "function" == typeof t.config.chart.events.mouseLeave && t.config.chart.events.mouseLeave(e, n, i) : ("mouseup" === e.type && 1 === e.which || "touchend" === e.type) && ("function" == typeof t.config.chart.events.click && t.config.chart.events.click(e, n, i), n.ctx.events.fireEvent("click", [e, n, i]))
                        }), {
                            capture: !1,
                            passive: !0
                        })
                    })), this.ctx.eventList.forEach((function (n) {
                        t.globals.dom.baseEl.addEventListener(n, e.documentEvent, {
                            passive: !0
                        })
                    })), this.ctx.core.setupBrushHandler()
                }
            }, {
                key: "documentEvent",
                value: function (e) {
                    var t = this.w,
                        n = e.target.className;
                    if ("click" === e.type) {
                        var i = t.globals.dom.baseEl.querySelector(".apexcharts-menu");
                        i && i.classList.contains("apexcharts-menu-open") && "apexcharts-menu-icon" !== n && i.classList.remove("apexcharts-menu-open")
                    }
                    t.globals.clientX = "touchmove" === e.type ? e.touches[0].clientX : e.clientX, t.globals.clientY = "touchmove" === e.type ? e.touches[0].clientY : e.clientY
                }
            }]), e
        }(),
        Z = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "setCurrentLocaleValues",
                value: function (e) {
                    var t = this.w.config.chart.locales;
                    window.Apex.chart && window.Apex.chart.locales && window.Apex.chart.locales.length > 0 && (t = this.w.config.chart.locales.concat(window.Apex.chart.locales));
                    var n = t.filter((function (t) {
                        return t.name === e
                    }))[0];
                    if (!n) throw new Error("Wrong locale name provided. Please make sure you set the correct locale name in options");
                    var i = p.extend(k, n);
                    this.w.globals.locale = i.options
                }
            }]), e
        }(),
        K = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "drawAxis",
                value: function (e, t) {
                    var n, i, a = this.w.globals,
                        r = this.w.config,
                        s = new V(this.ctx),
                        o = new $(this.ctx);
                    a.axisCharts && "radar" !== e && (a.isBarHorizontal ? (i = o.drawYaxisInversed(0), n = s.drawXaxisInversed(0), a.dom.elGraphical.add(n), a.dom.elGraphical.add(i)) : (n = s.drawXaxis(), a.dom.elGraphical.add(n), r.yaxis.map((function (e, t) {
                        -1 === a.ignoreYAxisIndexes.indexOf(t) && (i = o.drawYaxis(t), a.dom.Paper.add(i))
                    }))))
                }
            }]), e
        }(),
        J = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "drawXCrosshairs",
                value: function () {
                    var e = this.w,
                        t = new v(this.ctx),
                        n = new g(this.ctx),
                        i = e.config.xaxis.crosshairs.fill.gradient,
                        a = e.config.xaxis.crosshairs.dropShadow,
                        r = e.config.xaxis.crosshairs.fill.type,
                        s = i.colorFrom,
                        o = i.colorTo,
                        l = i.opacityFrom,
                        c = i.opacityTo,
                        u = i.stops,
                        d = a.enabled,
                        h = a.left,
                        f = a.top,
                        m = a.blur,
                        y = a.color,
                        b = a.opacity,
                        x = e.config.xaxis.crosshairs.fill.color;
                    if (e.config.xaxis.crosshairs.show) {
                        "gradient" === r && (x = t.drawGradient("vertical", s, o, l, c, null, u, null));
                        var _ = t.drawRect();
                        1 === e.config.xaxis.crosshairs.width && (_ = t.drawLine());
                        var w = e.globals.gridHeight;
                        (!p.isNumber(w) || w < 0) && (w = 0);
                        var k = e.config.xaxis.crosshairs.width;
                        (!p.isNumber(k) || k < 0) && (k = 0), _.attr({
                            class: "apexcharts-xcrosshairs",
                            x: 0,
                            y: 0,
                            y2: w,
                            width: k,
                            height: w,
                            fill: x,
                            filter: "none",
                            "fill-opacity": e.config.xaxis.crosshairs.opacity,
                            stroke: e.config.xaxis.crosshairs.stroke.color,
                            "stroke-width": e.config.xaxis.crosshairs.stroke.width,
                            "stroke-dasharray": e.config.xaxis.crosshairs.stroke.dashArray
                        }), d && (_ = n.dropShadow(_, {
                            left: h,
                            top: f,
                            blur: m,
                            color: y,
                            opacity: b
                        })), e.globals.dom.elGraphical.add(_)
                    }
                }
            }, {
                key: "drawYCrosshairs",
                value: function () {
                    var e = this.w,
                        t = new v(this.ctx),
                        n = e.config.yaxis[0].crosshairs,
                        i = e.globals.barPadForNumericAxis;
                    if (e.config.yaxis[0].crosshairs.show) {
                        var a = t.drawLine(-i, 0, e.globals.gridWidth + i, 0, n.stroke.color, n.stroke.dashArray, n.stroke.width);
                        a.attr({
                            class: "apexcharts-ycrosshairs"
                        }), e.globals.dom.elGraphical.add(a)
                    }
                    var r = t.drawLine(-i, 0, e.globals.gridWidth + i, 0, n.stroke.color, 0, 0);
                    r.attr({
                        class: "apexcharts-ycrosshairs-hidden"
                    }), e.globals.dom.elGraphical.add(r)
                }
            }]), e
        }(),
        Q = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "checkResponsiveConfig",
                value: function (e) {
                    var t = this,
                        n = this.w,
                        i = n.config;
                    if (0 !== i.responsive.length) {
                        var a = i.responsive.slice();
                        a.sort((function (e, t) {
                            return e.breakpoint > t.breakpoint ? 1 : t.breakpoint > e.breakpoint ? -1 : 0
                        })).reverse();
                        var r = new N({}),
                            s = function () {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                    i = a[0].breakpoint,
                                    s = window.innerWidth > 0 ? window.innerWidth : screen.width;
                                if (s > i) {
                                    var o = x.extendArrayProps(r, n.globals.initialConfig, n);
                                    e = p.extend(o, e), e = p.extend(n.config, e), t.overrideResponsiveOptions(e)
                                } else
                                    for (var l = 0; l < a.length; l++) s < a[l].breakpoint && (e = x.extendArrayProps(r, a[l].options, n), e = p.extend(n.config, e), t.overrideResponsiveOptions(e))
                            };
                        if (e) {
                            var o = x.extendArrayProps(r, e, n);
                            o = p.extend(n.config, o), s(o = p.extend(o, e))
                        } else s({})
                    }
                }
            }, {
                key: "overrideResponsiveOptions",
                value: function (e) {
                    var t = new N(e).init({
                        responsiveOverride: !0
                    });
                    this.w.config = t
                }
            }]), e
        }(),
        ee = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.colors = [], this.w = t.w;
                var n = this.w;
                this.isColorFn = !1, this.isHeatmapDistributed = "treemap" === n.config.chart.type && n.config.plotOptions.treemap.distributed || "heatmap" === n.config.chart.type && n.config.plotOptions.heatmap.distributed, this.isBarDistributed = n.config.plotOptions.bar.distributed && ("bar" === n.config.chart.type || "rangeBar" === n.config.chart.type)
            }
            return r(e, [{
                key: "init",
                value: function () {
                    this.setDefaultColors()
                }
            }, {
                key: "setDefaultColors",
                value: function () {
                    var e = this,
                        t = this.w,
                        n = new p;
                    if (t.globals.dom.elWrap.classList.add("apexcharts-theme-".concat(t.config.theme.mode)), void 0 === t.config.colors ? t.globals.colors = this.predefined() : (t.globals.colors = t.config.colors, Array.isArray(t.config.colors) && t.config.colors.length > 0 && "function" == typeof t.config.colors[0] && (t.globals.colors = t.config.series.map((function (n, i) {
                            var a = t.config.colors[i];
                            return a || (a = t.config.colors[0]), "function" == typeof a ? (e.isColorFn = !0, a({
                                value: t.globals.axisCharts ? t.globals.series[i][0] ? t.globals.series[i][0] : 0 : t.globals.series[i],
                                seriesIndex: i,
                                dataPointIndex: i,
                                w: t
                            })) : a
                        })))), t.globals.seriesColors.map((function (e, n) {
                            e && (t.globals.colors[n] = e)
                        })), t.config.theme.monochrome.enabled) {
                        var i = [],
                            a = t.globals.series.length;
                        (this.isBarDistributed || this.isHeatmapDistributed) && (a = t.globals.series[0].length * t.globals.series.length);
                        for (var r = t.config.theme.monochrome.color, s = 1 / (a / t.config.theme.monochrome.shadeIntensity), o = t.config.theme.monochrome.shadeTo, l = 0, c = 0; c < a; c++) {
                            var u = void 0;
                            "dark" === o ? (u = n.shadeColor(-1 * l, r), l += s) : (u = n.shadeColor(l, r), l += s), i.push(u)
                        }
                        t.globals.colors = i.slice()
                    }
                    var d = t.globals.colors.slice();
                    this.pushExtraColors(t.globals.colors), ["fill", "stroke"].forEach((function (n) {
                        void 0 === t.config[n].colors ? t.globals[n].colors = e.isColorFn ? t.config.colors : d : t.globals[n].colors = t.config[n].colors.slice(), e.pushExtraColors(t.globals[n].colors)
                    })), void 0 === t.config.dataLabels.style.colors ? t.globals.dataLabels.style.colors = d : t.globals.dataLabels.style.colors = t.config.dataLabels.style.colors.slice(), this.pushExtraColors(t.globals.dataLabels.style.colors, 50), void 0 === t.config.plotOptions.radar.polygons.fill.colors ? t.globals.radarPolygons.fill.colors = ["dark" === t.config.theme.mode ? "#424242" : "none"] : t.globals.radarPolygons.fill.colors = t.config.plotOptions.radar.polygons.fill.colors.slice(), this.pushExtraColors(t.globals.radarPolygons.fill.colors, 20), void 0 === t.config.markers.colors ? t.globals.markers.colors = d : t.globals.markers.colors = t.config.markers.colors.slice(), this.pushExtraColors(t.globals.markers.colors)
                }
            }, {
                key: "pushExtraColors",
                value: function (e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
                        i = this.w,
                        a = t || i.globals.series.length;
                    if (null === n && (n = this.isBarDistributed || this.isHeatmapDistributed || "heatmap" === i.config.chart.type && i.config.plotOptions.heatmap.colorScale.inverse), n && i.globals.series.length && (a = i.globals.series[i.globals.maxValsInArrayIndex].length * i.globals.series.length), e.length < a)
                        for (var r = a - e.length, s = 0; s < r; s++) e.push(e[s])
                }
            }, {
                key: "updateThemeOptions",
                value: function (e) {
                    e.chart = e.chart || {}, e.tooltip = e.tooltip || {};
                    var t = e.theme.mode || "light",
                        n = e.theme.palette ? e.theme.palette : "dark" === t ? "palette4" : "palette1",
                        i = e.chart.foreColor ? e.chart.foreColor : "dark" === t ? "#f6f7f8" : "#373d3f";
                    return e.tooltip.theme = t, e.chart.foreColor = i, e.theme.palette = n, e
                }
            }, {
                key: "predefined",
                value: function () {
                    switch (this.w.config.theme.palette) {
                        case "palette1":
                        default:
                            this.colors = ["#008FFB", "#00E396", "#FEB019", "#FF4560", "#775DD0"];
                            break;
                        case "palette2":
                            this.colors = ["#3f51b5", "#03a9f4", "#4caf50", "#f9ce1d", "#FF9800"];
                            break;
                        case "palette3":
                            this.colors = ["#33b2df", "#546E7A", "#d4526e", "#13d8aa", "#A5978B"];
                            break;
                        case "palette4":
                            this.colors = ["#4ecdc4", "#c7f464", "#81D4FA", "#fd6a6a", "#546E7A"];
                            break;
                        case "palette5":
                            this.colors = ["#2b908f", "#f9a3a4", "#90ee7e", "#fa4443", "#69d2e7"];
                            break;
                        case "palette6":
                            this.colors = ["#449DD1", "#F86624", "#EA3546", "#662E9B", "#C5D86D"];
                            break;
                        case "palette7":
                            this.colors = ["#D7263D", "#1B998B", "#2E294E", "#F46036", "#E2C044"];
                            break;
                        case "palette8":
                            this.colors = ["#662E9B", "#F86624", "#F9C80E", "#EA3546", "#43BCCD"];
                            break;
                        case "palette9":
                            this.colors = ["#5C4742", "#A5978B", "#8D5B4C", "#5A2A27", "#C4BBAF"];
                            break;
                        case "palette10":
                            this.colors = ["#A300D6", "#7D02EB", "#5653FE", "#2983FF", "#00B1F2"]
                    }
                    return this.colors
                }
            }]), e
        }(),
        te = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "draw",
                value: function () {
                    this.drawTitleSubtitle("title"), this.drawTitleSubtitle("subtitle")
                }
            }, {
                key: "drawTitleSubtitle",
                value: function (e) {
                    var t = this.w,
                        n = "title" === e ? t.config.title : t.config.subtitle,
                        i = t.globals.svgWidth / 2,
                        a = n.offsetY,
                        r = "middle";
                    if ("left" === n.align ? (i = 10, r = "start") : "right" === n.align && (i = t.globals.svgWidth - 10, r = "end"), i += n.offsetX, a = a + parseInt(n.style.fontSize, 10) + n.margin / 2, void 0 !== n.text) {
                        var s = new v(this.ctx).drawText({
                            x: i,
                            y: a,
                            text: n.text,
                            textAnchor: r,
                            fontSize: n.style.fontSize,
                            fontFamily: n.style.fontFamily,
                            fontWeight: n.style.fontWeight,
                            foreColor: n.style.color,
                            opacity: 1
                        });
                        s.node.setAttribute("class", "apexcharts-".concat(e, "-text")), t.globals.dom.Paper.add(s)
                    }
                }
            }]), e
        }(),
        ne = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.dCtx = t
            }
            return r(e, [{
                key: "getTitleSubtitleCoords",
                value: function (e) {
                    var t = this.w,
                        n = 0,
                        i = 0,
                        a = "title" === e ? t.config.title.floating : t.config.subtitle.floating,
                        r = t.globals.dom.baseEl.querySelector(".apexcharts-".concat(e, "-text"));
                    if (null !== r && !a) {
                        var s = r.getBoundingClientRect();
                        n = s.width, i = t.globals.axisCharts ? s.height + 5 : s.height
                    }
                    return {
                        width: n,
                        height: i
                    }
                }
            }, {
                key: "getLegendsRect",
                value: function () {
                    var e = this.w,
                        t = e.globals.dom.baseEl.querySelector(".apexcharts-legend");
                    e.config.legend.height || "top" !== e.config.legend.position && "bottom" !== e.config.legend.position || (t.style.maxHeight = e.globals.svgHeight / 2 + "px");
                    var n = Object.assign({}, p.getBoundingClientRect(t));
                    return null !== t && !e.config.legend.floating && e.config.legend.show ? this.dCtx.lgRect = {
                        x: n.x,
                        y: n.y,
                        height: n.height,
                        width: 0 === n.height ? 0 : n.width
                    } : this.dCtx.lgRect = {
                        x: 0,
                        y: 0,
                        height: 0,
                        width: 0
                    }, "left" !== e.config.legend.position && "right" !== e.config.legend.position || 1.5 * this.dCtx.lgRect.width > e.globals.svgWidth && (this.dCtx.lgRect.width = e.globals.svgWidth / 1.5), this.dCtx.lgRect
                }
            }, {
                key: "getLargestStringFromMultiArr",
                value: function (e, t) {
                    var n = e;
                    if (this.w.globals.isMultiLineX) {
                        var i = t.map((function (e, t) {
                                return Array.isArray(e) ? e.length : 1
                            })),
                            a = Math.max.apply(Math, h(i));
                        n = t[i.indexOf(a)]
                    }
                    return n
                }
            }]), e
        }(),
        ie = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.dCtx = t
            }
            return r(e, [{
                key: "getxAxisLabelsCoords",
                value: function () {
                    var e, t = this.w,
                        n = t.globals.labels.slice();
                    if (t.config.xaxis.convertedCatToNumeric && 0 === n.length && (n = t.globals.categoryLabels), t.globals.timescaleLabels.length > 0) {
                        var i = this.getxAxisTimeScaleLabelsCoords();
                        e = {
                            width: i.width,
                            height: i.height
                        }, t.globals.rotateXLabels = !1
                    } else {
                        this.dCtx.lgWidthForSideLegends = "left" !== t.config.legend.position && "right" !== t.config.legend.position || t.config.legend.floating ? 0 : this.dCtx.lgRect.width;
                        var a = t.globals.xLabelFormatter,
                            r = p.getLargestStringFromArr(n),
                            s = this.dCtx.dimHelpers.getLargestStringFromMultiArr(r, n);
                        t.globals.isBarHorizontal && (s = r = t.globals.yAxisScale[0].result.reduce((function (e, t) {
                            return e.length > t.length ? e : t
                        }), 0));
                        var o = new z(this.dCtx.ctx),
                            l = r;
                        r = o.xLabelFormat(a, r, l, {
                            i: void 0,
                            dateFormatter: new Y(this.dCtx.ctx).formatDate,
                            w: t
                        }), s = o.xLabelFormat(a, s, l, {
                            i: void 0,
                            dateFormatter: new Y(this.dCtx.ctx).formatDate,
                            w: t
                        }), (t.config.xaxis.convertedCatToNumeric && void 0 === r || "" === String(r).trim()) && (s = r = "1");
                        var c = new v(this.dCtx.ctx),
                            u = c.getTextRects(r, t.config.xaxis.labels.style.fontSize),
                            d = u;
                        if (r !== s && (d = c.getTextRects(s, t.config.xaxis.labels.style.fontSize)), (e = {
                                width: u.width >= d.width ? u.width : d.width,
                                height: u.height >= d.height ? u.height : d.height
                            }).width * n.length > t.globals.svgWidth - this.dCtx.lgWidthForSideLegends - this.dCtx.yAxisWidth - this.dCtx.gridPad.left - this.dCtx.gridPad.right && 0 !== t.config.xaxis.labels.rotate || t.config.xaxis.labels.rotateAlways) {
                            if (!t.globals.isBarHorizontal) {
                                t.globals.rotateXLabels = !0;
                                var h = function (e) {
                                    return c.getTextRects(e, t.config.xaxis.labels.style.fontSize, t.config.xaxis.labels.style.fontFamily, "rotate(".concat(t.config.xaxis.labels.rotate, " 0 0)"), !1)
                                };
                                u = h(r), r !== s && (d = h(s)), e.height = (u.height > d.height ? u.height : d.height) / 1.5, e.width = u.width > d.width ? u.width : d.width
                            }
                        } else t.globals.rotateXLabels = !1
                    }
                    return t.config.xaxis.labels.show || (e = {
                        width: 0,
                        height: 0
                    }), {
                        width: e.width,
                        height: e.height
                    }
                }
            }, {
                key: "getxAxisTitleCoords",
                value: function () {
                    var e = this.w,
                        t = 0,
                        n = 0;
                    if (void 0 !== e.config.xaxis.title.text) {
                        var i = new v(this.dCtx.ctx).getTextRects(e.config.xaxis.title.text, e.config.xaxis.title.style.fontSize);
                        t = i.width, n = i.height
                    }
                    return {
                        width: t,
                        height: n
                    }
                }
            }, {
                key: "getxAxisTimeScaleLabelsCoords",
                value: function () {
                    var e, t = this.w;
                    this.dCtx.timescaleLabels = t.globals.timescaleLabels.slice();
                    var n = this.dCtx.timescaleLabels.map((function (e) {
                            return e.value
                        })),
                        i = n.reduce((function (e, t) {
                            return void 0 === e ? (console.error("You have possibly supplied invalid Date format. Please supply a valid JavaScript Date"), 0) : e.length > t.length ? e : t
                        }), 0);
                    return 1.05 * (e = new v(this.dCtx.ctx).getTextRects(i, t.config.xaxis.labels.style.fontSize)).width * n.length > t.globals.gridWidth && 0 !== t.config.xaxis.labels.rotate && (t.globals.overlappingXLabels = !0), e
                }
            }, {
                key: "additionalPaddingXLabels",
                value: function (e) {
                    var t = this,
                        n = this.w,
                        i = n.globals,
                        a = n.config,
                        r = a.xaxis.type,
                        s = e.width;
                    i.skipLastTimelinelabel = !1, i.skipFirstTimelinelabel = !1;
                    var o = n.config.yaxis[0].opposite && n.globals.isBarHorizontal,
                        l = function (e, o) {
                            (function (e) {
                                return -1 !== i.collapsedSeriesIndices.indexOf(e)
                            })(o) || function (e) {
                                if (t.dCtx.timescaleLabels && t.dCtx.timescaleLabels.length) {
                                    var o = t.dCtx.timescaleLabels[0],
                                        l = t.dCtx.timescaleLabels[t.dCtx.timescaleLabels.length - 1].position + s / 1.75 - t.dCtx.yAxisWidthRight,
                                        c = o.position - s / 1.75 + t.dCtx.yAxisWidthLeft,
                                        u = "right" === n.config.legend.position && t.dCtx.lgRect.width > 0 ? t.dCtx.lgRect.width : 0;
                                    l > i.svgWidth - i.translateX - u && (i.skipLastTimelinelabel = !0), c < -(e.show && !e.floating || "bar" !== a.chart.type && "candlestick" !== a.chart.type && "rangeBar" !== a.chart.type && "boxPlot" !== a.chart.type ? 10 : s / 1.75) && (i.skipFirstTimelinelabel = !0)
                                } else "datetime" === r ? t.dCtx.gridPad.right < s && !i.rotateXLabels && (i.skipLastTimelinelabel = !0) : "datetime" !== r && t.dCtx.gridPad.right < s / 2 - t.dCtx.yAxisWidthRight && !i.rotateXLabels && !n.config.xaxis.labels.trim && ("between" !== n.config.xaxis.tickPlacement || n.globals.isBarHorizontal) && (t.dCtx.xPadRight = s / 2 + 1)
                            }(e)
                        };
                    a.yaxis.forEach((function (e, n) {
                        o ? (t.dCtx.gridPad.left < s && (t.dCtx.xPadLeft = s / 2 + 1), t.dCtx.xPadRight = s / 2 + 1) : l(e, n)
                    }))
                }
            }]), e
        }(),
        ae = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.dCtx = t
            }
            return r(e, [{
                key: "getyAxisLabelsCoords",
                value: function () {
                    var e = this,
                        t = this.w,
                        n = [],
                        i = 10,
                        a = new B(this.dCtx.ctx);
                    return t.config.yaxis.map((function (r, s) {
                        var o = t.globals.yAxisScale[s],
                            l = 0;
                        if (!a.isYAxisHidden(s) && r.labels.show && void 0 !== r.labels.minWidth && (l = r.labels.minWidth), !a.isYAxisHidden(s) && r.labels.show && o.result.length) {
                            var c = t.globals.yLabelFormatters[s],
                                u = o.niceMin === Number.MIN_VALUE ? 0 : o.niceMin,
                                d = String(u).length > String(o.niceMax).length ? u : o.niceMax,
                                h = c(d, {
                                    seriesIndex: s,
                                    dataPointIndex: -1,
                                    w: t
                                }),
                                f = h;
                            if (void 0 !== h && 0 !== h.length || (h = d), t.globals.isBarHorizontal) {
                                i = 0;
                                var m = t.globals.labels.slice();
                                h = c(h = p.getLargestStringFromArr(m), {
                                    seriesIndex: s,
                                    dataPointIndex: -1,
                                    w: t
                                }), f = e.dCtx.dimHelpers.getLargestStringFromMultiArr(h, m)
                            }
                            var g = new v(e.dCtx.ctx),
                                y = "rotate(".concat(r.labels.rotate, " 0 0)"),
                                b = g.getTextRects(h, r.labels.style.fontSize, r.labels.style.fontFamily, y, !1),
                                x = b;
                            h !== f && (x = g.getTextRects(f, r.labels.style.fontSize, r.labels.style.fontFamily, y, !1)), n.push({
                                width: (l > x.width || l > b.width ? l : x.width > b.width ? x.width : b.width) + i,
                                height: x.height > b.height ? x.height : b.height
                            })
                        } else n.push({
                            width: 0,
                            height: 0
                        })
                    })), n
                }
            }, {
                key: "getyAxisTitleCoords",
                value: function () {
                    var e = this,
                        t = this.w,
                        n = [];
                    return t.config.yaxis.map((function (t, i) {
                        if (t.show && void 0 !== t.title.text) {
                            var a = new v(e.dCtx.ctx),
                                r = "rotate(".concat(t.title.rotate, " 0 0)"),
                                s = a.getTextRects(t.title.text, t.title.style.fontSize, t.title.style.fontFamily, r, !1);
                            n.push({
                                width: s.width,
                                height: s.height
                            })
                        } else n.push({
                            width: 0,
                            height: 0
                        })
                    })), n
                }
            }, {
                key: "getTotalYAxisWidth",
                value: function () {
                    var e = this.w,
                        t = 0,
                        n = 0,
                        i = 0,
                        a = e.globals.yAxisScale.length > 1 ? 10 : 0,
                        r = new B(this.dCtx.ctx),
                        s = function (s, o) {
                            var l = e.config.yaxis[o].floating,
                                c = 0;
                            s.width > 0 && !l ? (c = s.width + a, function (t) {
                                return e.globals.ignoreYAxisIndexes.indexOf(t) > -1
                            }(o) && (c = c - s.width - a)) : c = l || r.isYAxisHidden(o) ? 0 : 5, e.config.yaxis[o].opposite ? i += c : n += c, t += c
                        };
                    return e.globals.yLabelsCoords.map((function (e, t) {
                        s(e, t)
                    })), e.globals.yTitleCoords.map((function (e, t) {
                        s(e, t)
                    })), e.globals.isBarHorizontal && !e.config.yaxis[0].floating && (t = e.globals.yLabelsCoords[0].width + e.globals.yTitleCoords[0].width + 15), this.dCtx.yAxisWidthLeft = n, this.dCtx.yAxisWidthRight = i, t
                }
            }]), e
        }(),
        re = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.dCtx = t
            }
            return r(e, [{
                key: "gridPadForColumnsInNumericAxis",
                value: function (e) {
                    var t = this.w;
                    if (t.globals.noData || t.globals.allSeriesCollapsed) return 0;
                    var n = function (e) {
                            return "bar" === e || "rangeBar" === e || "candlestick" === e || "boxPlot" === e
                        },
                        i = t.config.chart.type,
                        a = 0,
                        r = n(i) ? t.config.series.length : 1;
                    if (t.globals.comboBarCount > 0 && (r = t.globals.comboBarCount), t.globals.collapsedSeries.forEach((function (e) {
                            n(e.type) && (r -= 1)
                        })), t.config.chart.stacked && (r = 1), (n(i) || t.globals.comboBarCount > 0) && t.globals.isXNumeric && !t.globals.isBarHorizontal && r > 0) {
                        var s, o, l = Math.abs(t.globals.initialMaxX - t.globals.initialMinX);
                        l <= 3 && (l = t.globals.dataPoints), s = l / e, t.globals.minXDiff && t.globals.minXDiff / s > 0 && (o = t.globals.minXDiff / s), o > e / 2 && (o /= 2), (a = o / r * parseInt(t.config.plotOptions.bar.columnWidth, 10) / 100) < 1 && (a = 1), a = a / (r > 1 ? 1 : 1.5) + 5, t.globals.barPadForNumericAxis = a
                    }
                    return a
                }
            }, {
                key: "gridPadFortitleSubtitle",
                value: function () {
                    var e = this,
                        t = this.w,
                        n = t.globals,
                        i = this.dCtx.isSparkline || !t.globals.axisCharts ? 0 : 10;
                    ["title", "subtitle"].forEach((function (n) {
                        void 0 !== t.config[n].text ? i += t.config[n].margin : i += e.dCtx.isSparkline || !t.globals.axisCharts ? 0 : 5
                    })), !t.config.legend.show || "bottom" !== t.config.legend.position || t.config.legend.floating || t.globals.axisCharts || (i += 10);
                    var a = this.dCtx.dimHelpers.getTitleSubtitleCoords("title"),
                        r = this.dCtx.dimHelpers.getTitleSubtitleCoords("subtitle");
                    n.gridHeight = n.gridHeight - a.height - r.height - i, n.translateY = n.translateY + a.height + r.height + i
                }
            }, {
                key: "setGridXPosForDualYAxis",
                value: function (e, t) {
                    var n = this.w,
                        i = new B(this.dCtx.ctx);
                    n.config.yaxis.map((function (a, r) {
                        -1 !== n.globals.ignoreYAxisIndexes.indexOf(r) || a.floating || i.isYAxisHidden(r) || (a.opposite && (n.globals.translateX = n.globals.translateX - (t[r].width + e[r].width) - parseInt(n.config.yaxis[r].labels.style.fontSize, 10) / 1.2 - 12), n.globals.translateX < 2 && (n.globals.translateX = 2))
                    }))
                }
            }]), e
        }(),
        se = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w, this.lgRect = {}, this.yAxisWidth = 0, this.yAxisWidthLeft = 0, this.yAxisWidthRight = 0, this.xAxisHeight = 0, this.isSparkline = this.w.config.chart.sparkline.enabled, this.dimHelpers = new ne(this), this.dimYAxis = new ae(this), this.dimXAxis = new ie(this), this.dimGrid = new re(this), this.lgWidthForSideLegends = 0, this.gridPad = this.w.config.grid.padding, this.xPadRight = 0, this.xPadLeft = 0
            }
            return r(e, [{
                key: "plotCoords",
                value: function () {
                    var e = this.w.globals;
                    this.lgRect = this.dimHelpers.getLegendsRect(), e.axisCharts ? this.setDimensionsForAxisCharts() : this.setDimensionsForNonAxisCharts(), this.dimGrid.gridPadFortitleSubtitle(), e.gridHeight = e.gridHeight - this.gridPad.top - this.gridPad.bottom, e.gridWidth = e.gridWidth - this.gridPad.left - this.gridPad.right - this.xPadRight - this.xPadLeft;
                    var t = this.dimGrid.gridPadForColumnsInNumericAxis(e.gridWidth);
                    e.gridWidth = e.gridWidth - 2 * t, e.translateX = e.translateX + this.gridPad.left + this.xPadLeft + (t > 0 ? t + 4 : 0), e.translateY = e.translateY + this.gridPad.top
                }
            }, {
                key: "setDimensionsForAxisCharts",
                value: function () {
                    var e = this,
                        t = this.w,
                        n = t.globals,
                        i = this.dimYAxis.getyAxisLabelsCoords(),
                        a = this.dimYAxis.getyAxisTitleCoords();
                    t.globals.yLabelsCoords = [], t.globals.yTitleCoords = [], t.config.yaxis.map((function (e, n) {
                        t.globals.yLabelsCoords.push({
                            width: i[n].width,
                            index: n
                        }), t.globals.yTitleCoords.push({
                            width: a[n].width,
                            index: n
                        })
                    })), this.yAxisWidth = this.dimYAxis.getTotalYAxisWidth();
                    var r = this.dimXAxis.getxAxisLabelsCoords(),
                        s = this.dimXAxis.getxAxisTitleCoords();
                    this.conditionalChecksForAxisCoords(r, s), n.translateXAxisY = t.globals.rotateXLabels ? this.xAxisHeight / 8 : -4, n.translateXAxisX = t.globals.rotateXLabels && t.globals.isXNumeric && t.config.xaxis.labels.rotate <= -45 ? -this.xAxisWidth / 4 : 0, t.globals.isBarHorizontal && (n.rotateXLabels = !1, n.translateXAxisY = parseInt(t.config.xaxis.labels.style.fontSize, 10) / 1.5 * -1), n.translateXAxisY = n.translateXAxisY + t.config.xaxis.labels.offsetY, n.translateXAxisX = n.translateXAxisX + t.config.xaxis.labels.offsetX;
                    var o = this.yAxisWidth,
                        l = this.xAxisHeight;
                    n.xAxisLabelsHeight = this.xAxisHeight - s.height, n.xAxisLabelsWidth = this.xAxisWidth, n.xAxisHeight = this.xAxisHeight;
                    var c = 10;
                    ("radar" === t.config.chart.type || this.isSparkline) && (o = 0, l = n.goldenPadding), this.isSparkline && (this.lgRect = {
                        height: 0,
                        width: 0
                    }), (this.isSparkline || "treemap" === t.config.chart.type) && (o = 0, l = 0, c = 0), this.isSparkline || this.dimXAxis.additionalPaddingXLabels(r);
                    var u = function () {
                        n.translateX = o, n.gridHeight = n.svgHeight - e.lgRect.height - l - (e.isSparkline || "treemap" === t.config.chart.type ? 0 : t.globals.rotateXLabels ? 10 : 15), n.gridWidth = n.svgWidth - o
                    };
                    switch ("top" === t.config.xaxis.position && (c = n.xAxisHeight - t.config.xaxis.axisTicks.height - 5), t.config.legend.position) {
                        case "bottom":
                            n.translateY = c, u();
                            break;
                        case "top":
                            n.translateY = this.lgRect.height + c, u();
                            break;
                        case "left":
                            n.translateY = c, n.translateX = this.lgRect.width + o, n.gridHeight = n.svgHeight - l - 12, n.gridWidth = n.svgWidth - this.lgRect.width - o;
                            break;
                        case "right":
                            n.translateY = c, n.translateX = o, n.gridHeight = n.svgHeight - l - 12, n.gridWidth = n.svgWidth - this.lgRect.width - o - 5;
                            break;
                        default:
                            throw new Error("Legend position not supported")
                    }
                    this.dimGrid.setGridXPosForDualYAxis(a, i), new $(this.ctx).setYAxisXPosition(i, a)
                }
            }, {
                key: "setDimensionsForNonAxisCharts",
                value: function () {
                    var e = this.w,
                        t = e.globals,
                        n = e.config,
                        i = 0;
                    e.config.legend.show && !e.config.legend.floating && (i = 20);
                    var a = "pie" === n.chart.type || "polarArea" === n.chart.type || "donut" === n.chart.type ? "pie" : "radialBar",
                        r = n.plotOptions[a].offsetY,
                        s = n.plotOptions[a].offsetX;
                    if (!n.legend.show || n.legend.floating) return t.gridHeight = t.svgHeight - n.grid.padding.left + n.grid.padding.right, t.gridWidth = t.gridHeight, t.translateY = r, void(t.translateX = s + (t.svgWidth - t.gridWidth) / 2);
                    switch (n.legend.position) {
                        case "bottom":
                            t.gridHeight = t.svgHeight - this.lgRect.height - t.goldenPadding, t.gridWidth = t.svgWidth, t.translateY = r - 10, t.translateX = s + (t.svgWidth - t.gridWidth) / 2;
                            break;
                        case "top":
                            t.gridHeight = t.svgHeight - this.lgRect.height - t.goldenPadding, t.gridWidth = t.svgWidth, t.translateY = this.lgRect.height + r + 10, t.translateX = s + (t.svgWidth - t.gridWidth) / 2;
                            break;
                        case "left":
                            t.gridWidth = t.svgWidth - this.lgRect.width - i, t.gridHeight = "auto" !== n.chart.height ? t.svgHeight : t.gridWidth, t.translateY = r, t.translateX = s + this.lgRect.width + i;
                            break;
                        case "right":
                            t.gridWidth = t.svgWidth - this.lgRect.width - i - 5, t.gridHeight = "auto" !== n.chart.height ? t.svgHeight : t.gridWidth, t.translateY = r, t.translateX = s + 10;
                            break;
                        default:
                            throw new Error("Legend position not supported")
                    }
                }
            }, {
                key: "conditionalChecksForAxisCoords",
                value: function (e, t) {
                    var n = this.w,
                        i = e.height + t.height,
                        a = n.globals.isMultiLineX ? 1.2 : n.globals.LINE_HEIGHT_RATIO,
                        r = n.globals.rotateXLabels ? 22 : 10,
                        s = n.globals.rotateXLabels && "bottom" === n.config.legend.position ? 10 : 0;
                    this.xAxisHeight = i * a + r + s, this.xAxisWidth = e.width, this.xAxisHeight - t.height > n.config.xaxis.labels.maxHeight && (this.xAxisHeight = n.config.xaxis.labels.maxHeight), n.config.xaxis.labels.minHeight && this.xAxisHeight < n.config.xaxis.labels.minHeight && (this.xAxisHeight = n.config.xaxis.labels.minHeight), n.config.xaxis.floating && (this.xAxisHeight = 0);
                    var o = 0,
                        l = 0;
                    n.config.yaxis.forEach((function (e) {
                        o += e.labels.minWidth, l += e.labels.maxWidth
                    })), this.yAxisWidth < o && (this.yAxisWidth = o), this.yAxisWidth > l && (this.yAxisWidth = l)
                }
            }]), e
        }(),
        oe = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.lgCtx = t
            }
            return r(e, [{
                key: "getLegendStyles",
                value: function () {
                    var e = document.createElement("style");
                    e.setAttribute("type", "text/css");
                    var t = document.createTextNode("\t\n    \t\n      .apexcharts-legend {\t\n        display: flex;\t\n        overflow: auto;\t\n        padding: 0 10px;\t\n      }\t\n      .apexcharts-legend.apx-legend-position-bottom, .apexcharts-legend.apx-legend-position-top {\t\n        flex-wrap: wrap\t\n      }\t\n      .apexcharts-legend.apx-legend-position-right, .apexcharts-legend.apx-legend-position-left {\t\n        flex-direction: column;\t\n        bottom: 0;\t\n      }\t\n      .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-left, .apexcharts-legend.apx-legend-position-top.apexcharts-align-left, .apexcharts-legend.apx-legend-position-right, .apexcharts-legend.apx-legend-position-left {\t\n        justify-content: flex-start;\t\n      }\t\n      .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-center, .apexcharts-legend.apx-legend-position-top.apexcharts-align-center {\t\n        justify-content: center;  \t\n      }\t\n      .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-right, .apexcharts-legend.apx-legend-position-top.apexcharts-align-right {\t\n        justify-content: flex-end;\t\n      }\t\n      .apexcharts-legend-series {\t\n        cursor: pointer;\t\n        line-height: normal;\t\n      }\t\n      .apexcharts-legend.apx-legend-position-bottom .apexcharts-legend-series, .apexcharts-legend.apx-legend-position-top .apexcharts-legend-series{\t\n        display: flex;\t\n        align-items: center;\t\n      }\t\n      .apexcharts-legend-text {\t\n        position: relative;\t\n        font-size: 14px;\t\n      }\t\n      .apexcharts-legend-text *, .apexcharts-legend-marker * {\t\n        pointer-events: none;\t\n      }\t\n      .apexcharts-legend-marker {\t\n        position: relative;\t\n        display: inline-block;\t\n        cursor: pointer;\t\n        margin-right: 3px;\t\n        border-style: solid;\n      }\t\n      \t\n      .apexcharts-legend.apexcharts-align-right .apexcharts-legend-series, .apexcharts-legend.apexcharts-align-left .apexcharts-legend-series{\t\n        display: inline-block;\t\n      }\t\n      .apexcharts-legend-series.apexcharts-no-click {\t\n        cursor: auto;\t\n      }\t\n      .apexcharts-legend .apexcharts-hidden-zero-series, .apexcharts-legend .apexcharts-hidden-null-series {\t\n        display: none !important;\t\n      }\t\n      .apexcharts-inactive-legend {\t\n        opacity: 0.45;\t\n      }");
                    return e.appendChild(t), e
                }
            }, {
                key: "getLegendBBox",
                value: function () {
                    var e = this.w.globals.dom.baseEl.querySelector(".apexcharts-legend").getBoundingClientRect(),
                        t = e.width;
                    return {
                        clwh: e.height,
                        clww: t
                    }
                }
            }, {
                key: "appendToForeignObject",
                value: function () {
                    var e = this.w.globals;
                    e.dom.elLegendForeign = document.createElementNS(e.SVGNS, "foreignObject");
                    var t = e.dom.elLegendForeign;
                    t.setAttribute("x", 0), t.setAttribute("y", 0), t.setAttribute("width", e.svgWidth), t.setAttribute("height", e.svgHeight), e.dom.elLegendWrap.setAttribute("xmlns", "http://www.w3.org/1999/xhtml"), t.appendChild(e.dom.elLegendWrap), t.appendChild(this.getLegendStyles()), e.dom.Paper.node.insertBefore(t, e.dom.elGraphical.node)
                }
            }, {
                key: "toggleDataSeries",
                value: function (e, t) {
                    var n = this,
                        i = this.w;
                    if (i.globals.axisCharts || "radialBar" === i.config.chart.type) {
                        i.globals.resized = !0;
                        var a = null,
                            r = null;
                        i.globals.risingSeries = [], i.globals.axisCharts ? (a = i.globals.dom.baseEl.querySelector(".apexcharts-series[data\\:realIndex='".concat(e, "']")), r = parseInt(a.getAttribute("data:realIndex"), 10)) : (a = i.globals.dom.baseEl.querySelector(".apexcharts-series[rel='".concat(e + 1, "']")), r = parseInt(a.getAttribute("rel"), 10) - 1), t ? [{
                            cs: i.globals.collapsedSeries,
                            csi: i.globals.collapsedSeriesIndices
                        }, {
                            cs: i.globals.ancillaryCollapsedSeries,
                            csi: i.globals.ancillaryCollapsedSeriesIndices
                        }].forEach((function (e) {
                            n.riseCollapsedSeries(e.cs, e.csi, r)
                        })) : this.hideSeries({
                            seriesEl: a,
                            realIndex: r
                        })
                    } else {
                        var s = i.globals.dom.Paper.select(" .apexcharts-series[rel='".concat(e + 1, "'] path")),
                            o = i.config.chart.type;
                        if ("pie" === o || "polarArea" === o || "donut" === o) {
                            var l = i.config.plotOptions.pie.donut.labels;
                            new v(this.lgCtx.ctx).pathMouseDown(s.members[0], null), this.lgCtx.ctx.pie.printDataLabelsInner(s.members[0].node, l)
                        }
                        s.fire("click")
                    }
                }
            }, {
                key: "hideSeries",
                value: function (e) {
                    var t = e.seriesEl,
                        n = e.realIndex,
                        i = this.w,
                        a = p.clone(i.config.series);
                    if (i.globals.axisCharts) {
                        var r = !1;
                        if (i.config.yaxis[n] && i.config.yaxis[n].show && i.config.yaxis[n].showAlways && (r = !0, i.globals.ancillaryCollapsedSeriesIndices.indexOf(n) < 0 && (i.globals.ancillaryCollapsedSeries.push({
                                index: n,
                                data: a[n].data.slice(),
                                type: t.parentNode.className.baseVal.split("-")[1]
                            }), i.globals.ancillaryCollapsedSeriesIndices.push(n))), !r) {
                            i.globals.collapsedSeries.push({
                                index: n,
                                data: a[n].data.slice(),
                                type: t.parentNode.className.baseVal.split("-")[1]
                            }), i.globals.collapsedSeriesIndices.push(n);
                            var s = i.globals.risingSeries.indexOf(n);
                            i.globals.risingSeries.splice(s, 1)
                        }
                    } else i.globals.collapsedSeries.push({
                        index: n,
                        data: a[n]
                    }), i.globals.collapsedSeriesIndices.push(n);
                    for (var o = t.childNodes, l = 0; l < o.length; l++) o[l].classList.contains("apexcharts-series-markers-wrap") && (o[l].classList.contains("apexcharts-hide") ? o[l].classList.remove("apexcharts-hide") : o[l].classList.add("apexcharts-hide"));
                    i.globals.allSeriesCollapsed = i.globals.collapsedSeries.length === i.config.series.length, a = this._getSeriesBasedOnCollapsedState(a), this.lgCtx.ctx.updateHelpers._updateSeries(a, i.config.chart.animations.dynamicAnimation.enabled)
                }
            }, {
                key: "riseCollapsedSeries",
                value: function (e, t, n) {
                    var i = this.w,
                        a = p.clone(i.config.series);
                    if (e.length > 0) {
                        for (var r = 0; r < e.length; r++) e[r].index === n && (i.globals.axisCharts ? (a[n].data = e[r].data.slice(), e.splice(r, 1), t.splice(r, 1), i.globals.risingSeries.push(n)) : (a[n] = e[r].data, e.splice(r, 1), t.splice(r, 1), i.globals.risingSeries.push(n)));
                        a = this._getSeriesBasedOnCollapsedState(a), this.lgCtx.ctx.updateHelpers._updateSeries(a, i.config.chart.animations.dynamicAnimation.enabled)
                    }
                }
            }, {
                key: "_getSeriesBasedOnCollapsedState",
                value: function (e) {
                    var t = this.w;
                    return t.globals.axisCharts ? e.forEach((function (n, i) {
                        t.globals.collapsedSeriesIndices.indexOf(i) > -1 && (e[i].data = [])
                    })) : e.forEach((function (n, i) {
                        t.globals.collapsedSeriesIndices.indexOf(i) > -1 && (e[i] = 0)
                    })), e
                }
            }]), e
        }(),
        le = function () {
            function e(t, n) {
                i(this, e), this.ctx = t, this.w = t.w, this.onLegendClick = this.onLegendClick.bind(this), this.onLegendHovered = this.onLegendHovered.bind(this), this.isBarsDistributed = "bar" === this.w.config.chart.type && this.w.config.plotOptions.bar.distributed && 1 === this.w.config.series.length, this.legendHelpers = new oe(this)
            }
            return r(e, [{
                key: "init",
                value: function () {
                    var e = this.w,
                        t = e.globals,
                        n = e.config;
                    if ((n.legend.showForSingleSeries && 1 === t.series.length || this.isBarsDistributed || t.series.length > 1 || !t.axisCharts) && n.legend.show) {
                        for (; t.dom.elLegendWrap.firstChild;) t.dom.elLegendWrap.removeChild(t.dom.elLegendWrap.firstChild);
                        this.drawLegends(), p.isIE11() ? document.getElementsByTagName("head")[0].appendChild(this.legendHelpers.getLegendStyles()) : this.legendHelpers.appendToForeignObject(), "bottom" === n.legend.position || "top" === n.legend.position ? this.legendAlignHorizontal() : "right" !== n.legend.position && "left" !== n.legend.position || this.legendAlignVertical()
                    }
                }
            }, {
                key: "drawLegends",
                value: function () {
                    var e = this,
                        t = this.w,
                        n = t.config.legend.fontFamily,
                        i = t.globals.seriesNames,
                        a = t.globals.colors.slice();
                    if ("heatmap" === t.config.chart.type) {
                        var r = t.config.plotOptions.heatmap.colorScale.ranges;
                        i = r.map((function (e) {
                            return e.name ? e.name : e.from + " - " + e.to
                        })), a = r.map((function (e) {
                            return e.color
                        }))
                    } else this.isBarsDistributed && (i = t.globals.labels.slice());
                    t.config.legend.customLegendItems.length && (i = t.config.legend.customLegendItems);
                    for (var s = t.globals.legendFormatter, o = t.config.legend.inverseOrder, l = o ? i.length - 1 : 0; o ? l >= 0 : l <= i.length - 1; o ? l-- : l++) {
                        var c = s(i[l], {
                                seriesIndex: l,
                                w: t
                            }),
                            u = !1,
                            d = !1;
                        if (t.globals.collapsedSeries.length > 0)
                            for (var h = 0; h < t.globals.collapsedSeries.length; h++) t.globals.collapsedSeries[h].index === l && (u = !0);
                        if (t.globals.ancillaryCollapsedSeriesIndices.length > 0)
                            for (var f = 0; f < t.globals.ancillaryCollapsedSeriesIndices.length; f++) t.globals.ancillaryCollapsedSeriesIndices[f] === l && (d = !0);
                        var m = document.createElement("span");
                        m.classList.add("apexcharts-legend-marker");
                        var g = t.config.legend.markers.offsetX,
                            y = t.config.legend.markers.offsetY,
                            b = t.config.legend.markers.height,
                            _ = t.config.legend.markers.width,
                            w = t.config.legend.markers.strokeWidth,
                            k = t.config.legend.markers.strokeColor,
                            M = t.config.legend.markers.radius,
                            L = m.style;
                        L.background = a[l], L.color = a[l], L.setProperty("background", a[l], "important"), t.config.legend.markers.fillColors && t.config.legend.markers.fillColors[l] && (L.background = t.config.legend.markers.fillColors[l]), void 0 !== t.globals.seriesColors[l] && (L.background = t.globals.seriesColors[l], L.color = t.globals.seriesColors[l]), L.height = Array.isArray(b) ? parseFloat(b[l]) + "px" : parseFloat(b) + "px", L.width = Array.isArray(_) ? parseFloat(_[l]) + "px" : parseFloat(_) + "px", L.left = (Array.isArray(g) ? parseFloat(g[l]) : parseFloat(g)) + "px", L.top = (Array.isArray(y) ? parseFloat(y[l]) : parseFloat(y)) + "px", L.borderWidth = Array.isArray(w) ? w[l] : w, L.borderColor = Array.isArray(k) ? k[l] : k, L.borderRadius = Array.isArray(M) ? parseFloat(M[l]) + "px" : parseFloat(M) + "px", t.config.legend.markers.customHTML && (Array.isArray(t.config.legend.markers.customHTML) ? t.config.legend.markers.customHTML[l] && (m.innerHTML = t.config.legend.markers.customHTML[l]()) : m.innerHTML = t.config.legend.markers.customHTML()), v.setAttrs(m, {
                            rel: l + 1,
                            "data:collapsed": u || d
                        }), (u || d) && m.classList.add("apexcharts-inactive-legend");
                        var S = document.createElement("div"),
                            A = document.createElement("span");
                        A.classList.add("apexcharts-legend-text"), A.innerHTML = Array.isArray(c) ? c.join(" ") : c;
                        var T = t.config.legend.labels.useSeriesColors ? t.globals.colors[l] : t.config.legend.labels.colors;
                        T || (T = t.config.chart.foreColor), A.style.color = T, A.style.fontSize = parseFloat(t.config.legend.fontSize) + "px", A.style.fontWeight = t.config.legend.fontWeight, A.style.fontFamily = n || t.config.chart.fontFamily, v.setAttrs(A, {
                            rel: l + 1,
                            i: l,
                            "data:default-text": encodeURIComponent(c),
                            "data:collapsed": u || d
                        }), S.appendChild(m), S.appendChild(A);
                        var C = new x(this.ctx);
                        t.config.legend.showForZeroSeries || 0 === C.getSeriesTotalByIndex(l) && C.seriesHaveSameValues(l) && !C.isSeriesNull(l) && -1 === t.globals.collapsedSeriesIndices.indexOf(l) && -1 === t.globals.ancillaryCollapsedSeriesIndices.indexOf(l) && S.classList.add("apexcharts-hidden-zero-series"), t.config.legend.showForNullSeries || C.isSeriesNull(l) && -1 === t.globals.collapsedSeriesIndices.indexOf(l) && -1 === t.globals.ancillaryCollapsedSeriesIndices.indexOf(l) && S.classList.add("apexcharts-hidden-null-series"), t.globals.dom.elLegendWrap.appendChild(S), t.globals.dom.elLegendWrap.classList.add("apexcharts-align-".concat(t.config.legend.horizontalAlign)), t.globals.dom.elLegendWrap.classList.add("apx-legend-position-" + t.config.legend.position), S.classList.add("apexcharts-legend-series"), S.style.margin = "".concat(t.config.legend.itemMargin.vertical, "px ").concat(t.config.legend.itemMargin.horizontal, "px"), t.globals.dom.elLegendWrap.style.width = t.config.legend.width ? t.config.legend.width + "px" : "", t.globals.dom.elLegendWrap.style.height = t.config.legend.height ? t.config.legend.height + "px" : "", v.setAttrs(S, {
                            rel: l + 1,
                            seriesName: p.escapeString(i[l]),
                            "data:collapsed": u || d
                        }), (u || d) && S.classList.add("apexcharts-inactive-legend"), t.config.legend.onItemClick.toggleDataSeries || S.classList.add("apexcharts-no-click")
                    }
                    t.globals.dom.elWrap.addEventListener("click", e.onLegendClick, !0), t.config.legend.onItemHover.highlightDataSeries && 0 === t.config.legend.customLegendItems.length && (t.globals.dom.elWrap.addEventListener("mousemove", e.onLegendHovered, !0), t.globals.dom.elWrap.addEventListener("mouseout", e.onLegendHovered, !0))
                }
            }, {
                key: "setLegendWrapXY",
                value: function (e, t) {
                    var n = this.w,
                        i = n.globals.dom.baseEl.querySelector(".apexcharts-legend"),
                        a = i.getBoundingClientRect(),
                        r = 0,
                        s = 0;
                    if ("bottom" === n.config.legend.position) s += n.globals.svgHeight - a.height / 2;
                    else if ("top" === n.config.legend.position) {
                        var o = new se(this.ctx),
                            l = o.dimHelpers.getTitleSubtitleCoords("title").height,
                            c = o.dimHelpers.getTitleSubtitleCoords("subtitle").height;
                        s = s + (l > 0 ? l - 10 : 0) + (c > 0 ? c - 10 : 0)
                    }
                    i.style.position = "absolute", r = r + e + n.config.legend.offsetX, s = s + t + n.config.legend.offsetY, i.style.left = r + "px", i.style.top = s + "px", "bottom" === n.config.legend.position ? (i.style.top = "auto", i.style.bottom = 5 - n.config.legend.offsetY + "px") : "right" === n.config.legend.position && (i.style.left = "auto", i.style.right = 25 + n.config.legend.offsetX + "px"), ["width", "height"].forEach((function (e) {
                        i.style[e] && (i.style[e] = parseInt(n.config.legend[e], 10) + "px")
                    }))
                }
            }, {
                key: "legendAlignHorizontal",
                value: function () {
                    var e = this.w;
                    e.globals.dom.baseEl.querySelector(".apexcharts-legend").style.right = 0;
                    var t = this.legendHelpers.getLegendBBox(),
                        n = new se(this.ctx),
                        i = n.dimHelpers.getTitleSubtitleCoords("title"),
                        a = n.dimHelpers.getTitleSubtitleCoords("subtitle"),
                        r = 0;
                    "bottom" === e.config.legend.position ? r = -t.clwh / 1.8 : "top" === e.config.legend.position && (r = i.height + a.height + e.config.title.margin + e.config.subtitle.margin - 10), this.setLegendWrapXY(20, r)
                }
            }, {
                key: "legendAlignVertical",
                value: function () {
                    var e = this.w,
                        t = this.legendHelpers.getLegendBBox(),
                        n = 0;
                    "left" === e.config.legend.position && (n = 20), "right" === e.config.legend.position && (n = e.globals.svgWidth - t.clww - 10), this.setLegendWrapXY(n, 20)
                }
            }, {
                key: "onLegendHovered",
                value: function (e) {
                    var t = this.w,
                        n = e.target.classList.contains("apexcharts-legend-text") || e.target.classList.contains("apexcharts-legend-marker");
                    if ("heatmap" === t.config.chart.type || this.isBarsDistributed) {
                        if (n) {
                            var i = parseInt(e.target.getAttribute("rel"), 10) - 1;
                            this.ctx.events.fireEvent("legendHover", [this.ctx, i, this.w]), new E(this.ctx).highlightRangeInSeries(e, e.target)
                        }
                    } else !e.target.classList.contains("apexcharts-inactive-legend") && n && new E(this.ctx).toggleSeriesOnHover(e, e.target)
                }
            }, {
                key: "onLegendClick",
                value: function (e) {
                    var t = this.w;
                    if (!t.config.legend.customLegendItems.length && (e.target.classList.contains("apexcharts-legend-text") || e.target.classList.contains("apexcharts-legend-marker"))) {
                        var n = parseInt(e.target.getAttribute("rel"), 10) - 1,
                            i = "true" === e.target.getAttribute("data:collapsed"),
                            a = this.w.config.chart.events.legendClick;
                        "function" == typeof a && a(this.ctx, n, this.w), this.ctx.events.fireEvent("legendClick", [this.ctx, n, this.w]);
                        var r = this.w.config.legend.markers.onClick;
                        "function" == typeof r && e.target.classList.contains("apexcharts-legend-marker") && (r(this.ctx, n, this.w), this.ctx.events.fireEvent("legendMarkerClick", [this.ctx, n, this.w])), "treemap" !== t.config.chart.type && "heatmap" !== t.config.chart.type && !this.isBarsDistributed && t.config.legend.onItemClick.toggleDataSeries && this.legendHelpers.toggleDataSeries(n, i)
                    }
                }
            }]), e
        }(),
        ce = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w;
                var n = this.w;
                this.ev = this.w.config.chart.events, this.selectedClass = "apexcharts-selected", this.localeValues = this.w.globals.locale.toolbar, this.minX = n.globals.minX, this.maxX = n.globals.maxX
            }
            return r(e, [{
                key: "createToolbar",
                value: function () {
                    var e = this,
                        t = this.w,
                        n = function () {
                            return document.createElement("div")
                        },
                        i = n();
                    if (i.setAttribute("class", "apexcharts-toolbar"), i.style.top = t.config.chart.toolbar.offsetY + "px", i.style.right = 3 - t.config.chart.toolbar.offsetX + "px", t.globals.dom.elWrap.appendChild(i), this.elZoom = n(), this.elZoomIn = n(), this.elZoomOut = n(), this.elPan = n(), this.elSelection = n(), this.elZoomReset = n(), this.elMenuIcon = n(), this.elMenu = n(), this.elCustomIcons = [], this.t = t.config.chart.toolbar.tools, Array.isArray(this.t.customIcons))
                        for (var a = 0; a < this.t.customIcons.length; a++) this.elCustomIcons.push(n());
                    var r = [],
                        s = function (n, i, a) {
                            var s = n.toLowerCase();
                            e.t[s] && t.config.chart.zoom.enabled && r.push({
                                el: i,
                                icon: "string" == typeof e.t[s] ? e.t[s] : a,
                                title: e.localeValues[n],
                                class: "apexcharts-".concat(s, "-icon")
                            })
                        };
                    s("zoomIn", this.elZoomIn, '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">\n    <path d="M0 0h24v24H0z" fill="none"/>\n    <path d="M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4V7zm-1-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>\n</svg>\n'), s("zoomOut", this.elZoomOut, '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">\n    <path d="M0 0h24v24H0z" fill="none"/>\n    <path d="M7 11v2h10v-2H7zm5-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>\n</svg>\n');
                    var o = function (n) {
                        e.t[n] && t.config.chart[n].enabled && r.push({
                            el: "zoom" === n ? e.elZoom : e.elSelection,
                            icon: "string" == typeof e.t[n] ? e.t[n] : "zoom" === n ? '<svg xmlns="http://www.w3.org/2000/svg" fill="#000000" height="24" viewBox="0 0 24 24" width="24">\n    <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>\n    <path d="M0 0h24v24H0V0z" fill="none"/>\n    <path d="M12 10h-2v2H9v-2H7V9h2V7h1v2h2v1z"/>\n</svg>' : '<svg fill="#6E8192" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">\n    <path d="M0 0h24v24H0z" fill="none"/>\n    <path d="M3 5h2V3c-1.1 0-2 .9-2 2zm0 8h2v-2H3v2zm4 8h2v-2H7v2zM3 9h2V7H3v2zm10-6h-2v2h2V3zm6 0v2h2c0-1.1-.9-2-2-2zM5 21v-2H3c0 1.1.9 2 2 2zm-2-4h2v-2H3v2zM9 3H7v2h2V3zm2 18h2v-2h-2v2zm8-8h2v-2h-2v2zm0 8c1.1 0 2-.9 2-2h-2v2zm0-12h2V7h-2v2zm0 8h2v-2h-2v2zm-4 4h2v-2h-2v2zm0-16h2V3h-2v2z"/>\n</svg>',
                            title: e.localeValues["zoom" === n ? "selectionZoom" : "selection"],
                            class: t.globals.isTouchDevice ? "apexcharts-element-hidden" : "apexcharts-".concat(n, "-icon")
                        })
                    };
                    o("zoom"), o("selection"), this.t.pan && t.config.chart.zoom.enabled && r.push({
                        el: this.elPan,
                        icon: "string" == typeof this.t.pan ? this.t.pan : '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" height="24" viewBox="0 0 24 24" width="24">\n    <defs>\n        <path d="M0 0h24v24H0z" id="a"/>\n    </defs>\n    <clipPath id="b">\n        <use overflow="visible" xlink:href="#a"/>\n    </clipPath>\n    <path clip-path="url(#b)" d="M23 5.5V20c0 2.2-1.8 4-4 4h-7.3c-1.08 0-2.1-.43-2.85-1.19L1 14.83s1.26-1.23 1.3-1.25c.22-.19.49-.29.79-.29.22 0 .42.06.6.16.04.01 4.31 2.46 4.31 2.46V4c0-.83.67-1.5 1.5-1.5S11 3.17 11 4v7h1V1.5c0-.83.67-1.5 1.5-1.5S15 .67 15 1.5V11h1V2.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5V11h1V5.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5z"/>\n</svg>',
                        title: this.localeValues.pan,
                        class: t.globals.isTouchDevice ? "apexcharts-element-hidden" : "apexcharts-pan-icon"
                    }), s("reset", this.elZoomReset, '<svg fill="#000000" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">\n    <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>\n    <path d="M0 0h24v24H0z" fill="none"/>\n</svg>'), this.t.download && r.push({
                        el: this.elMenuIcon,
                        icon: "string" == typeof this.t.download ? this.t.download : '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0V0z"/><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>',
                        title: this.localeValues.menu,
                        class: "apexcharts-menu-icon"
                    });
                    for (var l = 0; l < this.elCustomIcons.length; l++) r.push({
                        el: this.elCustomIcons[l],
                        icon: this.t.customIcons[l].icon,
                        title: this.t.customIcons[l].title,
                        index: this.t.customIcons[l].index,
                        class: "apexcharts-toolbar-custom-icon " + this.t.customIcons[l].class
                    });
                    r.forEach((function (e, t) {
                        e.index && p.moveIndexInArray(r, t, e.index)
                    }));
                    for (var c = 0; c < r.length; c++) v.setAttrs(r[c].el, {
                        class: r[c].class,
                        title: r[c].title
                    }), r[c].el.innerHTML = r[c].icon, i.appendChild(r[c].el);
                    this._createHamburgerMenu(i), t.globals.zoomEnabled ? this.elZoom.classList.add(this.selectedClass) : t.globals.panEnabled ? this.elPan.classList.add(this.selectedClass) : t.globals.selectionEnabled && this.elSelection.classList.add(this.selectedClass), this.addToolbarEventListeners()
                }
            }, {
                key: "_createHamburgerMenu",
                value: function (e) {
                    this.elMenuItems = [], e.appendChild(this.elMenu), v.setAttrs(this.elMenu, {
                        class: "apexcharts-menu"
                    });
                    var t = [{
                        name: "exportSVG",
                        title: this.localeValues.exportToSVG
                    }, {
                        name: "exportPNG",
                        title: this.localeValues.exportToPNG
                    }, {
                        name: "exportCSV",
                        title: this.localeValues.exportToCSV
                    }];
                    this.w.globals.allSeriesHasEqualX || t.splice(2, 1);
                    for (var n = 0; n < t.length; n++) this.elMenuItems.push(document.createElement("div")), this.elMenuItems[n].innerHTML = t[n].title, v.setAttrs(this.elMenuItems[n], {
                        class: "apexcharts-menu-item ".concat(t[n].name),
                        title: t[n].title
                    }), this.elMenu.appendChild(this.elMenuItems[n])
                }
            }, {
                key: "addToolbarEventListeners",
                value: function () {
                    var e = this;
                    this.elZoomReset.addEventListener("click", this.handleZoomReset.bind(this)), this.elSelection.addEventListener("click", this.toggleZoomSelection.bind(this, "selection")), this.elZoom.addEventListener("click", this.toggleZoomSelection.bind(this, "zoom")), this.elZoomIn.addEventListener("click", this.handleZoomIn.bind(this)), this.elZoomOut.addEventListener("click", this.handleZoomOut.bind(this)), this.elPan.addEventListener("click", this.togglePanning.bind(this)), this.elMenuIcon.addEventListener("click", this.toggleMenu.bind(this)), this.elMenuItems.forEach((function (t) {
                        t.classList.contains("exportSVG") ? t.addEventListener("click", e.handleDownload.bind(e, "svg")) : t.classList.contains("exportPNG") ? t.addEventListener("click", e.handleDownload.bind(e, "png")) : t.classList.contains("exportCSV") && t.addEventListener("click", e.handleDownload.bind(e, "csv"))
                    }));
                    for (var t = 0; t < this.t.customIcons.length; t++) this.elCustomIcons[t].addEventListener("click", this.t.customIcons[t].click.bind(this, this.ctx, this.ctx.w))
                }
            }, {
                key: "toggleZoomSelection",
                value: function (e) {
                    this.ctx.getSyncedCharts().forEach((function (t) {
                        t.ctx.toolbar.toggleOtherControls();
                        var n = "selection" === e ? t.ctx.toolbar.elSelection : t.ctx.toolbar.elZoom,
                            i = "selection" === e ? "selectionEnabled" : "zoomEnabled";
                        t.w.globals[i] = !t.w.globals[i], n.classList.contains(t.ctx.toolbar.selectedClass) ? n.classList.remove(t.ctx.toolbar.selectedClass) : n.classList.add(t.ctx.toolbar.selectedClass)
                    }))
                }
            }, {
                key: "getToolbarIconsReference",
                value: function () {
                    var e = this.w;
                    this.elZoom || (this.elZoom = e.globals.dom.baseEl.querySelector(".apexcharts-zoom-icon")), this.elPan || (this.elPan = e.globals.dom.baseEl.querySelector(".apexcharts-pan-icon")), this.elSelection || (this.elSelection = e.globals.dom.baseEl.querySelector(".apexcharts-selection-icon"))
                }
            }, {
                key: "enableZoomPanFromToolbar",
                value: function (e) {
                    this.toggleOtherControls(), "pan" === e ? this.w.globals.panEnabled = !0 : this.w.globals.zoomEnabled = !0;
                    var t = "pan" === e ? this.elPan : this.elZoom,
                        n = "pan" === e ? this.elZoom : this.elPan;
                    t && t.classList.add(this.selectedClass), n && n.classList.remove(this.selectedClass)
                }
            }, {
                key: "togglePanning",
                value: function () {
                    this.ctx.getSyncedCharts().forEach((function (e) {
                        e.ctx.toolbar.toggleOtherControls(), e.w.globals.panEnabled = !e.w.globals.panEnabled, e.ctx.toolbar.elPan.classList.contains(e.ctx.toolbar.selectedClass) ? e.ctx.toolbar.elPan.classList.remove(e.ctx.toolbar.selectedClass) : e.ctx.toolbar.elPan.classList.add(e.ctx.toolbar.selectedClass)
                    }))
                }
            }, {
                key: "toggleOtherControls",
                value: function () {
                    var e = this,
                        t = this.w;
                    t.globals.panEnabled = !1, t.globals.zoomEnabled = !1, t.globals.selectionEnabled = !1, this.getToolbarIconsReference(), [this.elPan, this.elSelection, this.elZoom].forEach((function (t) {
                        t && t.classList.remove(e.selectedClass)
                    }))
                }
            }, {
                key: "handleZoomIn",
                value: function () {
                    var e = this.w;
                    e.globals.isRangeBar && (this.minX = e.globals.minY, this.maxX = e.globals.maxY);
                    var t = (this.minX + this.maxX) / 2,
                        n = (this.minX + t) / 2,
                        i = (this.maxX + t) / 2,
                        a = this._getNewMinXMaxX(n, i);
                    e.globals.disableZoomIn || this.zoomUpdateOptions(a.minX, a.maxX)
                }
            }, {
                key: "handleZoomOut",
                value: function () {
                    var e = this.w;
                    if (e.globals.isRangeBar && (this.minX = e.globals.minY, this.maxX = e.globals.maxY), !("datetime" === e.config.xaxis.type && new Date(this.minX).getUTCFullYear() < 1e3)) {
                        var t = (this.minX + this.maxX) / 2,
                            n = this.minX - (t - this.minX),
                            i = this.maxX - (t - this.maxX),
                            a = this._getNewMinXMaxX(n, i);
                        e.globals.disableZoomOut || this.zoomUpdateOptions(a.minX, a.maxX)
                    }
                }
            }, {
                key: "_getNewMinXMaxX",
                value: function (e, t) {
                    var n = this.w.config.xaxis.convertedCatToNumeric;
                    return {
                        minX: n ? Math.floor(e) : e,
                        maxX: n ? Math.floor(t) : t
                    }
                }
            }, {
                key: "zoomUpdateOptions",
                value: function (e, t) {
                    var n = this.w;
                    if (void 0 !== e || void 0 !== t) {
                        if (!(n.config.xaxis.convertedCatToNumeric && (e < 1 && (e = 1, t = n.globals.dataPoints), t - e < 2))) {
                            var i = {
                                    min: e,
                                    max: t
                                },
                                a = this.getBeforeZoomRange(i);
                            a && (i = a.xaxis);
                            var r = {
                                    xaxis: i
                                },
                                s = p.clone(n.globals.initialConfig.yaxis);
                            n.config.chart.zoom.autoScaleYaxis && (s = new X(this.ctx).autoScaleY(this.ctx, s, {
                                xaxis: i
                            })), n.config.chart.group || (r.yaxis = s), this.w.globals.zoomed = !0, this.ctx.updateHelpers._updateOptions(r, !1, this.w.config.chart.animations.dynamicAnimation.enabled), this.zoomCallback(i, s)
                        }
                    } else this.handleZoomReset()
                }
            }, {
                key: "zoomCallback",
                value: function (e, t) {
                    "function" == typeof this.ev.zoomed && this.ev.zoomed(this.ctx, {
                        xaxis: e,
                        yaxis: t
                    })
                }
            }, {
                key: "getBeforeZoomRange",
                value: function (e, t) {
                    var n = null;
                    return "function" == typeof this.ev.beforeZoom && (n = this.ev.beforeZoom(this, {
                        xaxis: e,
                        yaxis: t
                    })), n
                }
            }, {
                key: "toggleMenu",
                value: function () {
                    var e = this;
                    window.setTimeout((function () {
                        e.elMenu.classList.contains("apexcharts-menu-open") ? e.elMenu.classList.remove("apexcharts-menu-open") : e.elMenu.classList.add("apexcharts-menu-open")
                    }), 0)
                }
            }, {
                key: "handleDownload",
                value: function (e) {
                    var t = this.w,
                        n = new W(this.ctx);
                    switch (e) {
                        case "svg":
                            n.exportToSVG(this.ctx);
                            break;
                        case "png":
                            n.exportToPng(this.ctx);
                            break;
                        case "csv":
                            n.exportToCSV({
                                series: t.config.series,
                                columnDelimiter: t.config.chart.toolbar.export.csv.columnDelimiter
                            })
                    }
                }
            }, {
                key: "handleZoomReset",
                value: function (e) {
                    this.ctx.getSyncedCharts().forEach((function (e) {
                        var t = e.w;
                        if (t.globals.lastXAxis.min = void 0, t.globals.lastXAxis.max = void 0, e.updateHelpers.revertDefaultAxisMinMax(), "function" == typeof t.config.chart.events.beforeResetZoom) {
                            var n = t.config.chart.events.beforeResetZoom(e, t);
                            n && e.updateHelpers.revertDefaultAxisMinMax(n)
                        }
                        "function" == typeof t.config.chart.events.zoomed && e.ctx.toolbar.zoomCallback({
                            min: t.config.xaxis.min,
                            max: t.config.xaxis.max
                        }), t.globals.zoomed = !1;
                        var i = e.ctx.series.emptyCollapsedSeries(p.clone(t.globals.initialSeries));
                        e.updateHelpers._updateSeries(i, t.config.chart.animations.dynamicAnimation.enabled)
                    }))
                }
            }, {
                key: "destroy",
                value: function () {
                    this.elZoom = null, this.elZoomIn = null, this.elZoomOut = null, this.elPan = null, this.elSelection = null, this.elZoomReset = null, this.elMenuIcon = null
                }
            }]), e
        }(),
        ue = function (e) {
            o(n, e);
            var t = d(n);

            function n(e) {
                var a;
                return i(this, n), (a = t.call(this, e)).ctx = e, a.w = e.w, a.dragged = !1, a.graphics = new v(a.ctx), a.eventList = ["mousedown", "mouseleave", "mousemove", "touchstart", "touchmove", "mouseup", "touchend"], a.clientX = 0, a.clientY = 0, a.startX = 0, a.endX = 0, a.dragX = 0, a.startY = 0, a.endY = 0, a.dragY = 0, a.moveDirection = "none", a
            }
            return r(n, [{
                key: "init",
                value: function (e) {
                    var t = this,
                        n = e.xyRatios,
                        i = this.w,
                        a = this;
                    this.xyRatios = n, this.zoomRect = this.graphics.drawRect(0, 0, 0, 0), this.selectionRect = this.graphics.drawRect(0, 0, 0, 0), this.gridRect = i.globals.dom.baseEl.querySelector(".apexcharts-grid"), this.zoomRect.node.classList.add("apexcharts-zoom-rect"), this.selectionRect.node.classList.add("apexcharts-selection-rect"), i.globals.dom.elGraphical.add(this.zoomRect), i.globals.dom.elGraphical.add(this.selectionRect), "x" === i.config.chart.selection.type ? this.slDraggableRect = this.selectionRect.draggable({
                        minX: 0,
                        minY: 0,
                        maxX: i.globals.gridWidth,
                        maxY: i.globals.gridHeight
                    }).on("dragmove", this.selectionDragging.bind(this, "dragging")) : "y" === i.config.chart.selection.type ? this.slDraggableRect = this.selectionRect.draggable({
                        minX: 0,
                        maxX: i.globals.gridWidth
                    }).on("dragmove", this.selectionDragging.bind(this, "dragging")) : this.slDraggableRect = this.selectionRect.draggable().on("dragmove", this.selectionDragging.bind(this, "dragging")), this.preselectedSelection(), this.hoverArea = i.globals.dom.baseEl.querySelector("".concat(i.globals.chartClass, " .apexcharts-svg")), this.hoverArea.classList.add("apexcharts-zoomable"), this.eventList.forEach((function (e) {
                        t.hoverArea.addEventListener(e, a.svgMouseEvents.bind(a, n), {
                            capture: !1,
                            passive: !0
                        })
                    }))
                }
            }, {
                key: "destroy",
                value: function () {
                    this.slDraggableRect && (this.slDraggableRect.draggable(!1), this.slDraggableRect.off(), this.selectionRect.off()), this.selectionRect = null, this.zoomRect = null, this.gridRect = null
                }
            }, {
                key: "svgMouseEvents",
                value: function (e, t) {
                    var n = this.w,
                        i = this,
                        a = this.ctx.toolbar,
                        r = n.globals.zoomEnabled ? n.config.chart.zoom.type : n.config.chart.selection.type,
                        s = n.config.chart.toolbar.autoSelected;
                    if (t.shiftKey ? (this.shiftWasPressed = !0, a.enableZoomPanFromToolbar("pan" === s ? "zoom" : "pan")) : this.shiftWasPressed && (a.enableZoomPanFromToolbar(s), this.shiftWasPressed = !1), t.target) {
                        var o, l = t.target.classList;
                        if (t.target.parentNode && null !== t.target.parentNode && (o = t.target.parentNode.classList), !(l.contains("apexcharts-selection-rect") || l.contains("apexcharts-legend-marker") || l.contains("apexcharts-legend-text") || o && o.contains("apexcharts-toolbar"))) {
                            if (i.clientX = "touchmove" === t.type || "touchstart" === t.type ? t.touches[0].clientX : "touchend" === t.type ? t.changedTouches[0].clientX : t.clientX, i.clientY = "touchmove" === t.type || "touchstart" === t.type ? t.touches[0].clientY : "touchend" === t.type ? t.changedTouches[0].clientY : t.clientY, "mousedown" === t.type && 1 === t.which) {
                                var c = i.gridRect.getBoundingClientRect();
                                i.startX = i.clientX - c.left, i.startY = i.clientY - c.top, i.dragged = !1, i.w.globals.mousedown = !0
                            }
                            if (("mousemove" === t.type && 1 === t.which || "touchmove" === t.type) && (i.dragged = !0, n.globals.panEnabled ? (n.globals.selection = null, i.w.globals.mousedown && i.panDragging({
                                    context: i,
                                    zoomtype: r,
                                    xyRatios: e
                                })) : (i.w.globals.mousedown && n.globals.zoomEnabled || i.w.globals.mousedown && n.globals.selectionEnabled) && (i.selection = i.selectionDrawing({
                                    context: i,
                                    zoomtype: r
                                }))), "mouseup" === t.type || "touchend" === t.type || "mouseleave" === t.type) {
                                var u = i.gridRect.getBoundingClientRect();
                                i.w.globals.mousedown && (i.endX = i.clientX - u.left, i.endY = i.clientY - u.top, i.dragX = Math.abs(i.endX - i.startX), i.dragY = Math.abs(i.endY - i.startY), (n.globals.zoomEnabled || n.globals.selectionEnabled) && i.selectionDrawn({
                                    context: i,
                                    zoomtype: r
                                }), n.globals.panEnabled && n.config.xaxis.convertedCatToNumeric && i.delayedPanScrolled()), n.globals.zoomEnabled && i.hideSelectionRect(this.selectionRect), i.dragged = !1, i.w.globals.mousedown = !1
                            }
                            this.makeSelectionRectDraggable()
                        }
                    }
                }
            }, {
                key: "makeSelectionRectDraggable",
                value: function () {
                    var e = this.w;
                    if (this.selectionRect) {
                        var t = this.selectionRect.node.getBoundingClientRect();
                        t.width > 0 && t.height > 0 && this.slDraggableRect.selectize({
                            points: "l, r",
                            pointSize: 8,
                            pointType: "rect"
                        }).resize({
                            constraint: {
                                minX: 0,
                                minY: 0,
                                maxX: e.globals.gridWidth,
                                maxY: e.globals.gridHeight
                            }
                        }).on("resizing", this.selectionDragging.bind(this, "resizing"))
                    }
                }
            }, {
                key: "preselectedSelection",
                value: function () {
                    var e = this.w,
                        t = this.xyRatios;
                    if (!e.globals.zoomEnabled)
                        if (void 0 !== e.globals.selection && null !== e.globals.selection) this.drawSelectionRect(e.globals.selection);
                        else if (void 0 !== e.config.chart.selection.xaxis.min && void 0 !== e.config.chart.selection.xaxis.max) {
                        var n = (e.config.chart.selection.xaxis.min - e.globals.minX) / t.xRatio,
                            i = {
                                x: n,
                                y: 0,
                                width: e.globals.gridWidth - (e.globals.maxX - e.config.chart.selection.xaxis.max) / t.xRatio - n,
                                height: e.globals.gridHeight,
                                translateX: 0,
                                translateY: 0,
                                selectionEnabled: !0
                            };
                        this.drawSelectionRect(i), this.makeSelectionRectDraggable(), "function" == typeof e.config.chart.events.selection && e.config.chart.events.selection(this.ctx, {
                            xaxis: {
                                min: e.config.chart.selection.xaxis.min,
                                max: e.config.chart.selection.xaxis.max
                            },
                            yaxis: {}
                        })
                    }
                }
            }, {
                key: "drawSelectionRect",
                value: function (e) {
                    var t = e.x,
                        n = e.y,
                        i = e.width,
                        a = e.height,
                        r = e.translateX,
                        s = void 0 === r ? 0 : r,
                        o = e.translateY,
                        l = void 0 === o ? 0 : o,
                        c = this.w,
                        u = this.zoomRect,
                        d = this.selectionRect;
                    if (this.dragged || null !== c.globals.selection) {
                        var h = {
                            transform: "translate(" + s + ", " + l + ")"
                        };
                        c.globals.zoomEnabled && this.dragged && (i < 0 && (i = 1), u.attr({
                            x: t,
                            y: n,
                            width: i,
                            height: a,
                            fill: c.config.chart.zoom.zoomedArea.fill.color,
                            "fill-opacity": c.config.chart.zoom.zoomedArea.fill.opacity,
                            stroke: c.config.chart.zoom.zoomedArea.stroke.color,
                            "stroke-width": c.config.chart.zoom.zoomedArea.stroke.width,
                            "stroke-opacity": c.config.chart.zoom.zoomedArea.stroke.opacity
                        }), v.setAttrs(u.node, h)), c.globals.selectionEnabled && (d.attr({
                            x: t,
                            y: n,
                            width: i > 0 ? i : 0,
                            height: a > 0 ? a : 0,
                            fill: c.config.chart.selection.fill.color,
                            "fill-opacity": c.config.chart.selection.fill.opacity,
                            stroke: c.config.chart.selection.stroke.color,
                            "stroke-width": c.config.chart.selection.stroke.width,
                            "stroke-dasharray": c.config.chart.selection.stroke.dashArray,
                            "stroke-opacity": c.config.chart.selection.stroke.opacity
                        }), v.setAttrs(d.node, h))
                    }
                }
            }, {
                key: "hideSelectionRect",
                value: function (e) {
                    e && e.attr({
                        x: 0,
                        y: 0,
                        width: 0,
                        height: 0
                    })
                }
            }, {
                key: "selectionDrawing",
                value: function (e) {
                    var t, n = e.context,
                        i = e.zoomtype,
                        a = this.w,
                        r = n,
                        s = this.gridRect.getBoundingClientRect(),
                        o = r.startX - 1,
                        l = r.startY,
                        c = !1,
                        u = !1,
                        d = r.clientX - s.left - o,
                        h = r.clientY - s.top - l;
                    return Math.abs(d + o) > a.globals.gridWidth ? d = a.globals.gridWidth - o : r.clientX - s.left < 0 && (d = o), o > r.clientX - s.left && (c = !0, d = Math.abs(d)), l > r.clientY - s.top && (u = !0, h = Math.abs(h)), t = "x" === i ? {
                        x: c ? o - d : o,
                        y: 0,
                        width: d,
                        height: a.globals.gridHeight
                    } : "y" === i ? {
                        x: 0,
                        y: u ? l - h : l,
                        width: a.globals.gridWidth,
                        height: h
                    } : {
                        x: c ? o - d : o,
                        y: u ? l - h : l,
                        width: d,
                        height: h
                    }, r.drawSelectionRect(t), r.selectionDragging("resizing"), t
                }
            }, {
                key: "selectionDragging",
                value: function (e, t) {
                    var n = this,
                        i = this.w,
                        a = this.xyRatios,
                        r = this.selectionRect,
                        s = 0;
                    "resizing" === e && (s = 30);
                    var o = function (e) {
                            return parseFloat(r.node.getAttribute(e))
                        },
                        l = {
                            x: o("x"),
                            y: o("y"),
                            width: o("width"),
                            height: o("height")
                        };
                    i.globals.selection = l, "function" == typeof i.config.chart.events.selection && i.globals.selectionEnabled && (clearTimeout(this.w.globals.selectionResizeTimer), this.w.globals.selectionResizeTimer = window.setTimeout((function () {
                        var e = n.gridRect.getBoundingClientRect(),
                            t = r.node.getBoundingClientRect(),
                            s = {
                                xaxis: {
                                    min: i.globals.xAxisScale.niceMin + (t.left - e.left) * a.xRatio,
                                    max: i.globals.xAxisScale.niceMin + (t.right - e.left) * a.xRatio
                                },
                                yaxis: {
                                    min: i.globals.yAxisScale[0].niceMin + (e.bottom - t.bottom) * a.yRatio[0],
                                    max: i.globals.yAxisScale[0].niceMax - (t.top - e.top) * a.yRatio[0]
                                }
                            };
                        i.config.chart.events.selection(n.ctx, s), i.config.chart.brush.enabled && void 0 !== i.config.chart.events.brushScrolled && i.config.chart.events.brushScrolled(n.ctx, s)
                    }), s))
                }
            }, {
                key: "selectionDrawn",
                value: function (e) {
                    var t = e.context,
                        n = e.zoomtype,
                        i = this.w,
                        a = t,
                        r = this.xyRatios,
                        s = this.ctx.toolbar;
                    if (a.startX > a.endX) {
                        var o = a.startX;
                        a.startX = a.endX, a.endX = o
                    }
                    if (a.startY > a.endY) {
                        var l = a.startY;
                        a.startY = a.endY, a.endY = l
                    }
                    var c = void 0,
                        u = void 0;
                    i.globals.isRangeBar ? (c = i.globals.yAxisScale[0].niceMin + a.startX * r.invertedYRatio, u = i.globals.yAxisScale[0].niceMin + a.endX * r.invertedYRatio) : (c = i.globals.xAxisScale.niceMin + a.startX * r.xRatio, u = i.globals.xAxisScale.niceMin + a.endX * r.xRatio);
                    var d = [],
                        h = [];
                    if (i.config.yaxis.forEach((function (e, t) {
                            d.push(i.globals.yAxisScale[t].niceMax - r.yRatio[t] * a.startY), h.push(i.globals.yAxisScale[t].niceMax - r.yRatio[t] * a.endY)
                        })), a.dragged && (a.dragX > 10 || a.dragY > 10) && c !== u)
                        if (i.globals.zoomEnabled) {
                            var f = p.clone(i.globals.initialConfig.yaxis),
                                m = p.clone(i.globals.initialConfig.xaxis);
                            if (i.globals.zoomed = !0, i.config.xaxis.convertedCatToNumeric && (c = Math.floor(c), u = Math.floor(u), c < 1 && (c = 1, u = i.globals.dataPoints), u - c < 2 && (u = c + 1)), "xy" !== n && "x" !== n || (m = {
                                    min: c,
                                    max: u
                                }), "xy" !== n && "y" !== n || f.forEach((function (e, t) {
                                    f[t].min = h[t], f[t].max = d[t]
                                })), i.config.chart.zoom.autoScaleYaxis) {
                                var g = new X(a.ctx);
                                f = g.autoScaleY(a.ctx, f, {
                                    xaxis: m
                                })
                            }
                            if (s) {
                                var v = s.getBeforeZoomRange(m, f);
                                v && (m = v.xaxis ? v.xaxis : m, f = v.yaxis ? v.yaxis : f)
                            }
                            var y = {
                                xaxis: m
                            };
                            i.config.chart.group || (y.yaxis = f), a.ctx.updateHelpers._updateOptions(y, !1, a.w.config.chart.animations.dynamicAnimation.enabled), "function" == typeof i.config.chart.events.zoomed && s.zoomCallback(m, f)
                        } else if (i.globals.selectionEnabled) {
                        var b, x = null;
                        b = {
                            min: c,
                            max: u
                        }, "xy" !== n && "y" !== n || (x = p.clone(i.config.yaxis)).forEach((function (e, t) {
                            x[t].min = h[t], x[t].max = d[t]
                        })), i.globals.selection = a.selection, "function" == typeof i.config.chart.events.selection && i.config.chart.events.selection(a.ctx, {
                            xaxis: b,
                            yaxis: x
                        })
                    }
                }
            }, {
                key: "panDragging",
                value: function (e) {
                    var t = e.context,
                        n = this.w,
                        i = t;
                    if (void 0 !== n.globals.lastClientPosition.x) {
                        var a = n.globals.lastClientPosition.x - i.clientX,
                            r = n.globals.lastClientPosition.y - i.clientY;
                        Math.abs(a) > Math.abs(r) && a > 0 ? this.moveDirection = "left" : Math.abs(a) > Math.abs(r) && a < 0 ? this.moveDirection = "right" : Math.abs(r) > Math.abs(a) && r > 0 ? this.moveDirection = "up" : Math.abs(r) > Math.abs(a) && r < 0 && (this.moveDirection = "down")
                    }
                    n.globals.lastClientPosition = {
                        x: i.clientX,
                        y: i.clientY
                    };
                    var s = n.globals.isRangeBar ? n.globals.minY : n.globals.minX,
                        o = n.globals.isRangeBar ? n.globals.maxY : n.globals.maxX;
                    n.config.xaxis.convertedCatToNumeric || i.panScrolled(s, o)
                }
            }, {
                key: "delayedPanScrolled",
                value: function () {
                    var e = this.w,
                        t = e.globals.minX,
                        n = e.globals.maxX,
                        i = (e.globals.maxX - e.globals.minX) / 2;
                    "left" === this.moveDirection ? (t = e.globals.minX + i, n = e.globals.maxX + i) : "right" === this.moveDirection && (t = e.globals.minX - i, n = e.globals.maxX - i), t = Math.floor(t), n = Math.floor(n), this.updateScrolledChart({
                        xaxis: {
                            min: t,
                            max: n
                        }
                    }, t, n)
                }
            }, {
                key: "panScrolled",
                value: function (e, t) {
                    var n = this.w,
                        i = this.xyRatios,
                        a = p.clone(n.globals.initialConfig.yaxis),
                        r = i.xRatio,
                        s = n.globals.minX,
                        o = n.globals.maxX;
                    n.globals.isRangeBar && (r = i.invertedYRatio, s = n.globals.minY, o = n.globals.maxY), "left" === this.moveDirection ? (e = s + n.globals.gridWidth / 15 * r, t = o + n.globals.gridWidth / 15 * r) : "right" === this.moveDirection && (e = s - n.globals.gridWidth / 15 * r, t = o - n.globals.gridWidth / 15 * r), n.globals.isRangeBar || (e < n.globals.initialMinX || t > n.globals.initialMaxX) && (e = s, t = o);
                    var l = {
                        min: e,
                        max: t
                    };
                    n.config.chart.zoom.autoScaleYaxis && (a = new X(this.ctx).autoScaleY(this.ctx, a, {
                        xaxis: l
                    }));
                    var c = {
                        xaxis: {
                            min: e,
                            max: t
                        }
                    };
                    n.config.chart.group || (c.yaxis = a), this.updateScrolledChart(c, e, t)
                }
            }, {
                key: "updateScrolledChart",
                value: function (e, t, n) {
                    var i = this.w;
                    this.ctx.updateHelpers._updateOptions(e, !1, !1), "function" == typeof i.config.chart.events.scrolled && i.config.chart.events.scrolled(this.ctx, {
                        xaxis: {
                            min: t,
                            max: n
                        }
                    })
                }
            }]), n
        }(ce),
        de = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.ttCtx = t, this.ctx = t.ctx
            }
            return r(e, [{
                key: "getNearestValues",
                value: function (e) {
                    var t = e.hoverArea,
                        n = e.elGrid,
                        i = e.clientX,
                        a = e.clientY,
                        r = this.w,
                        s = n.getBoundingClientRect(),
                        o = s.width,
                        l = s.height,
                        c = o / (r.globals.dataPoints - 1),
                        u = l / r.globals.dataPoints,
                        d = this.hasBars();
                    !r.globals.comboCharts && !d || r.config.xaxis.convertedCatToNumeric || (c = o / r.globals.dataPoints);
                    var h = i - s.left - r.globals.barPadForNumericAxis,
                        f = a - s.top;
                    h < 0 || f < 0 || h > o || f > l ? (t.classList.remove("hovering-zoom"), t.classList.remove("hovering-pan")) : r.globals.zoomEnabled ? (t.classList.remove("hovering-pan"), t.classList.add("hovering-zoom")) : r.globals.panEnabled && (t.classList.remove("hovering-zoom"), t.classList.add("hovering-pan"));
                    var m = Math.round(h / c),
                        g = Math.floor(f / u);
                    d && !r.config.xaxis.convertedCatToNumeric && (m = Math.ceil(h / c), m -= 1);
                    for (var v, y = null, b = null, x = [], _ = 0; _ < r.globals.seriesXvalues.length; _++) x.push([r.globals.seriesXvalues[_][0] - 1e-6].concat(r.globals.seriesXvalues[_]));
                    if (x = x.map((function (e) {
                            return e.filter((function (e) {
                                return e
                            }))
                        })), v = r.globals.seriesYvalues.map((function (e) {
                            return e.filter((function (e) {
                                return p.isNumber(e)
                            }))
                        })), r.globals.isXNumeric) {
                        var w = this.ttCtx.getElGrid().getBoundingClientRect(),
                            k = h * (w.width / o),
                            M = f * (w.height / l);
                        y = (b = this.closestInMultiArray(k, M, x, v)).index, m = b.j, null !== y && (x = r.globals.seriesXvalues[y], m = (b = this.closestInArray(k, x)).index)
                    }
                    return r.globals.capturedSeriesIndex = null === y ? -1 : y, (!m || m < 1) && (m = 0), r.globals.isBarHorizontal ? r.globals.capturedDataPointIndex = g : r.globals.capturedDataPointIndex = m, {
                        capturedSeries: y,
                        j: r.globals.isBarHorizontal ? g : m,
                        hoverX: h,
                        hoverY: f
                    }
                }
            }, {
                key: "closestInMultiArray",
                value: function (e, t, n, i) {
                    var a = this.w,
                        r = 0,
                        s = null,
                        o = -1;
                    a.globals.series.length > 1 ? r = this.getFirstActiveXArray(n, i) : s = 0;
                    var l = i[r][0],
                        c = n[r][0],
                        u = Math.abs(e - c),
                        d = Math.abs(t - l),
                        h = d + u;
                    return i.map((function (a, r) {
                        a.map((function (a, l) {
                            var c = Math.abs(t - i[r][l]),
                                f = Math.abs(e - n[r][l]),
                                p = f + c;
                            p < h && (h = p, u = f, d = c, s = r, o = l)
                        }))
                    })), {
                        index: s,
                        j: o
                    }
                }
            }, {
                key: "getFirstActiveXArray",
                value: function (e, t) {
                    for (var n = 0, i = e.map((function (e, n) {
                            return e.length > 0 && t[n].length > 0 ? n : -1
                        })), a = 0; a < i.length; a++)
                        if (-1 !== i[a]) {
                            n = i[a];
                            break
                        } return n
                }
            }, {
                key: "closestInArray",
                value: function (e, t) {
                    for (var n = t[0], i = null, a = Math.abs(e - n), r = 0; r < t.length; r++) {
                        var s = Math.abs(e - t[r]);
                        s < a && (a = s, i = r)
                    }
                    return {
                        index: i
                    }
                }
            }, {
                key: "isXoverlap",
                value: function (e) {
                    var t = [],
                        n = this.w.globals.seriesX.filter((function (e) {
                            return void 0 !== e[0]
                        }));
                    if (n.length > 0)
                        for (var i = 0; i < n.length - 1; i++) void 0 !== n[i][e] && void 0 !== n[i + 1][e] && n[i][e] !== n[i + 1][e] && t.push("unEqual");
                    return 0 === t.length
                }
            }, {
                key: "isInitialSeriesSameLen",
                value: function () {
                    for (var e = !0, t = this.w.globals.initialSeries, n = 0; n < t.length - 1; n++)
                        if (t[n].data.length !== t[n + 1].data.length) {
                            e = !1;
                            break
                        } return e
                }
            }, {
                key: "getBarsHeight",
                value: function (e) {
                    return h(e).reduce((function (e, t) {
                        return e + t.getBBox().height
                    }), 0)
                }
            }, {
                key: "getElMarkers",
                value: function () {
                    return this.w.globals.dom.baseEl.querySelectorAll(" .apexcharts-series-markers")
                }
            }, {
                key: "getAllMarkers",
                value: function () {
                    var e = this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-series-markers-wrap");
                    (e = h(e)).sort((function (e, t) {
                        return Number(t.getAttribute("data:realIndex")) < Number(e.getAttribute("data:realIndex")) ? 0 : -1
                    }));
                    var t = [];
                    return e.forEach((function (e) {
                        t.push(e.querySelector(".apexcharts-marker"))
                    })), t
                }
            }, {
                key: "hasMarkers",
                value: function () {
                    return this.getElMarkers().length > 0
                }
            }, {
                key: "getElBars",
                value: function () {
                    return this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-bar-series,  .apexcharts-candlestick-series, .apexcharts-boxPlot-series, .apexcharts-rangebar-series")
                }
            }, {
                key: "hasBars",
                value: function () {
                    return this.getElBars().length > 0
                }
            }, {
                key: "getHoverMarkerSize",
                value: function (e) {
                    var t = this.w,
                        n = t.config.markers.hover.size;
                    return void 0 === n && (n = t.globals.markers.size[e] + t.config.markers.hover.sizeOffset), n
                }
            }, {
                key: "toggleAllTooltipSeriesGroups",
                value: function (e) {
                    var t = this.w,
                        n = this.ttCtx;
                    0 === n.allTooltipSeriesGroups.length && (n.allTooltipSeriesGroups = t.globals.dom.baseEl.querySelectorAll(".apexcharts-tooltip-series-group"));
                    for (var i = n.allTooltipSeriesGroups, a = 0; a < i.length; a++) "enable" === e ? (i[a].classList.add("apexcharts-active"), i[a].style.display = t.config.tooltip.items.display) : (i[a].classList.remove("apexcharts-active"), i[a].style.display = "none")
                }
            }]), e
        }(),
        he = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.ctx = t.ctx, this.ttCtx = t, this.tooltipUtil = new de(t)
            }
            return r(e, [{
                key: "drawSeriesTexts",
                value: function (e) {
                    var t = e.shared,
                        n = void 0 === t || t,
                        i = e.ttItems,
                        a = e.i,
                        r = void 0 === a ? 0 : a,
                        s = e.j,
                        o = void 0 === s ? null : s,
                        l = e.y1,
                        c = e.y2,
                        u = e.e,
                        d = this.w;
                    void 0 !== d.config.tooltip.custom ? this.handleCustomTooltip({
                        i: r,
                        j: o,
                        y1: l,
                        y2: c,
                        w: d
                    }) : this.toggleActiveInactiveSeries(n);
                    var h = this.getValuesToPrint({
                        i: r,
                        j: o
                    });
                    this.printLabels({
                        i: r,
                        j: o,
                        values: h,
                        ttItems: i,
                        shared: n,
                        e: u
                    });
                    var f = this.ttCtx.getElTooltip();
                    this.ttCtx.tooltipRect.ttWidth = f.getBoundingClientRect().width, this.ttCtx.tooltipRect.ttHeight = f.getBoundingClientRect().height
                }
            }, {
                key: "printLabels",
                value: function (e) {
                    var n, i = this,
                        a = e.i,
                        r = e.j,
                        s = e.values,
                        o = e.ttItems,
                        l = e.shared,
                        c = e.e,
                        u = this.w,
                        d = [],
                        h = function (e) {
                            return u.globals.seriesGoals[e] && u.globals.seriesGoals[e][r] && Array.isArray(u.globals.seriesGoals[e][r])
                        },
                        f = s.xVal,
                        p = s.zVal,
                        m = s.xAxisTTVal,
                        g = "",
                        v = u.globals.colors[a];
                    null !== r && u.config.plotOptions.bar.distributed && (v = u.globals.colors[r]);
                    for (var y = function (e, s) {
                            var y = i.getFormatters(a);
                            g = i.getSeriesName({
                                fn: y.yLbTitleFormatter,
                                index: a,
                                seriesIndex: a,
                                j: r
                            }), "treemap" === u.config.chart.type && (g = y.yLbTitleFormatter(String(u.config.series[a].data[r].x), {
                                series: u.globals.series,
                                seriesIndex: a,
                                dataPointIndex: r,
                                w: u
                            }));
                            var b = u.config.tooltip.inverseOrder ? s : e;
                            if (u.globals.axisCharts) {
                                var x = function (e) {
                                    return y.yLbFormatter(u.globals.series[e][r], {
                                        series: u.globals.series,
                                        seriesIndex: e,
                                        dataPointIndex: r,
                                        w: u
                                    })
                                };
                                l ? (y = i.getFormatters(b), g = i.getSeriesName({
                                    fn: y.yLbTitleFormatter,
                                    index: b,
                                    seriesIndex: a,
                                    j: r
                                }), v = u.globals.colors[b], n = x(b), h(b) && (d = u.globals.seriesGoals[b][r].map((function (e) {
                                    return {
                                        attrs: e,
                                        val: y.yLbFormatter(e.value, {
                                            seriesIndex: b,
                                            dataPointIndex: r,
                                            w: u
                                        })
                                    }
                                })))) : (c && c.target && c.target.getAttribute("fill") && (v = c.target.getAttribute("fill")), n = x(a), h(a) && Array.isArray(u.globals.seriesGoals[a][r]) && (d = u.globals.seriesGoals[a][r].map((function (e) {
                                    return {
                                        attrs: e,
                                        val: y.yLbFormatter(e.value, {
                                            seriesIndex: a,
                                            dataPointIndex: r,
                                            w: u
                                        })
                                    }
                                }))))
                            }
                            null === r && (n = y.yLbFormatter(u.globals.series[a], t(t({}, u), {}, {
                                seriesIndex: a,
                                dataPointIndex: a
                            }))), i.DOMHandling({
                                i: a,
                                t: b,
                                j: r,
                                ttItems: o,
                                values: {
                                    val: n,
                                    goalVals: d,
                                    xVal: f,
                                    xAxisTTVal: m,
                                    zVal: p
                                },
                                seriesName: g,
                                shared: l,
                                pColor: v
                            })
                        }, b = 0, x = u.globals.series.length - 1; b < u.globals.series.length; b++, x--) y(b, x)
                }
            }, {
                key: "getFormatters",
                value: function (e) {
                    var t, n = this.w,
                        i = n.globals.yLabelFormatters[e];
                    return void 0 !== n.globals.ttVal ? Array.isArray(n.globals.ttVal) ? (i = n.globals.ttVal[e] && n.globals.ttVal[e].formatter, t = n.globals.ttVal[e] && n.globals.ttVal[e].title && n.globals.ttVal[e].title.formatter) : (i = n.globals.ttVal.formatter, "function" == typeof n.globals.ttVal.title.formatter && (t = n.globals.ttVal.title.formatter)) : t = n.config.tooltip.y.title.formatter, "function" != typeof i && (i = n.globals.yLabelFormatters[0] ? n.globals.yLabelFormatters[0] : function (e) {
                        return e
                    }), "function" != typeof t && (t = function (e) {
                        return e
                    }), {
                        yLbFormatter: i,
                        yLbTitleFormatter: t
                    }
                }
            }, {
                key: "getSeriesName",
                value: function (e) {
                    var t = e.fn,
                        n = e.index,
                        i = e.seriesIndex,
                        a = e.j,
                        r = this.w;
                    return t(String(r.globals.seriesNames[n]), {
                        series: r.globals.series,
                        seriesIndex: i,
                        dataPointIndex: a,
                        w: r
                    })
                }
            }, {
                key: "DOMHandling",
                value: function (e) {
                    e.i;
                    var t = e.t,
                        n = e.j,
                        i = e.ttItems,
                        a = e.values,
                        r = e.seriesName,
                        s = e.shared,
                        o = e.pColor,
                        l = this.w,
                        c = this.ttCtx,
                        u = a.val,
                        d = a.goalVals,
                        h = a.xVal,
                        f = a.xAxisTTVal,
                        p = a.zVal,
                        m = null;
                    m = i[t].children, l.config.tooltip.fillSeriesColor && (i[t].style.backgroundColor = o, m[0].style.display = "none"), c.showTooltipTitle && (null === c.tooltipTitle && (c.tooltipTitle = l.globals.dom.baseEl.querySelector(".apexcharts-tooltip-title")), c.tooltipTitle.innerHTML = h), c.isXAxisTooltipEnabled && (c.xaxisTooltipText.innerHTML = "" !== f ? f : h);
                    var g = i[t].querySelector(".apexcharts-tooltip-text-y-label");
                    g && (g.innerHTML = r || "");
                    var v = i[t].querySelector(".apexcharts-tooltip-text-y-value");
                    v && (v.innerHTML = void 0 !== u ? u : ""), m[0] && m[0].classList.contains("apexcharts-tooltip-marker") && (l.config.tooltip.marker.fillColors && Array.isArray(l.config.tooltip.marker.fillColors) && (o = l.config.tooltip.marker.fillColors[t]), m[0].style.backgroundColor = o), l.config.tooltip.marker.show || (m[0].style.display = "none");
                    var y = i[t].querySelector(".apexcharts-tooltip-text-goals-label"),
                        b = i[t].querySelector(".apexcharts-tooltip-text-goals-value");
                    if (d.length && l.globals.seriesGoals[t]) {
                        var x = function () {
                            var e = "<div >",
                                t = "<div>";
                            d.forEach((function (n, i) {
                                e += ' <div style="display: flex"><span class="apexcharts-tooltip-marker" style="background-color: '.concat(n.attrs.strokeColor, '; height: 3px; border-radius: 0; top: 5px;"></span> ').concat(n.attrs.name, "</div>"), t += "<div>".concat(n.val, "</div>")
                            })), y.innerHTML = e + "</div>", b.innerHTML = t + "</div>"
                        };
                        s ? l.globals.seriesGoals[t][n] && Array.isArray(l.globals.seriesGoals[t][n]) ? x() : (y.innerHTML = "", b.innerHTML = "") : x()
                    } else y.innerHTML = "", b.innerHTML = "";
                    null !== p && (i[t].querySelector(".apexcharts-tooltip-text-z-label").innerHTML = l.config.tooltip.z.title, i[t].querySelector(".apexcharts-tooltip-text-z-value").innerHTML = void 0 !== p ? p : ""), s && m[0] && (null == u || l.globals.collapsedSeriesIndices.indexOf(t) > -1 ? m[0].parentNode.style.display = "none" : m[0].parentNode.style.display = l.config.tooltip.items.display)
                }
            }, {
                key: "toggleActiveInactiveSeries",
                value: function (e) {
                    var t = this.w;
                    if (e) this.tooltipUtil.toggleAllTooltipSeriesGroups("enable");
                    else {
                        this.tooltipUtil.toggleAllTooltipSeriesGroups("disable");
                        var n = t.globals.dom.baseEl.querySelector(".apexcharts-tooltip-series-group");
                        n && (n.classList.add("apexcharts-active"), n.style.display = t.config.tooltip.items.display)
                    }
                }
            }, {
                key: "getValuesToPrint",
                value: function (e) {
                    var t = e.i,
                        n = e.j,
                        i = this.w,
                        a = this.ctx.series.filteredSeriesX(),
                        r = "",
                        s = "",
                        o = null,
                        l = null,
                        c = {
                            series: i.globals.series,
                            seriesIndex: t,
                            dataPointIndex: n,
                            w: i
                        },
                        u = i.globals.ttZFormatter;
                    null === n ? l = i.globals.series[t] : i.globals.isXNumeric && "treemap" !== i.config.chart.type ? (r = a[t][n], 0 === a[t].length && (r = a[this.tooltipUtil.getFirstActiveXArray(a)][n])) : r = void 0 !== i.globals.labels[n] ? i.globals.labels[n] : "";
                    var d = r;
                    return r = i.globals.isXNumeric && "datetime" === i.config.xaxis.type ? new z(this.ctx).xLabelFormat(i.globals.ttKeyFormatter, d, d, {
                        i: void 0,
                        dateFormatter: new Y(this.ctx).formatDate,
                        w: this.w
                    }) : i.globals.isBarHorizontal ? i.globals.yLabelFormatters[0](d, c) : i.globals.xLabelFormatter(d, c), void 0 !== i.config.tooltip.x.formatter && (r = i.globals.ttKeyFormatter(d, c)), i.globals.seriesZ.length > 0 && i.globals.seriesZ[t].length > 0 && (o = u(i.globals.seriesZ[t][n], i)), s = "function" == typeof i.config.xaxis.tooltip.formatter ? i.globals.xaxisTooltipFormatter(d, c) : r, {
                        val: Array.isArray(l) ? l.join(" ") : l,
                        xVal: Array.isArray(r) ? r.join(" ") : r,
                        xAxisTTVal: Array.isArray(s) ? s.join(" ") : s,
                        zVal: o
                    }
                }
            }, {
                key: "handleCustomTooltip",
                value: function (e) {
                    var t = e.i,
                        n = e.j,
                        i = e.y1,
                        a = e.y2,
                        r = e.w,
                        s = this.ttCtx.getElTooltip(),
                        o = r.config.tooltip.custom;
                    Array.isArray(o) && o[t] && (o = o[t]), s.innerHTML = o({
                        ctx: this.ctx,
                        series: r.globals.series,
                        seriesIndex: t,
                        dataPointIndex: n,
                        y1: i,
                        y2: a,
                        w: r
                    })
                }
            }]), e
        }(),
        fe = function () {
            function e(t) {
                i(this, e), this.ttCtx = t, this.ctx = t.ctx, this.w = t.w
            }
            return r(e, [{
                key: "moveXCrosshairs",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                        n = this.ttCtx,
                        i = this.w,
                        a = n.getElXCrosshairs(),
                        r = e - n.xcrosshairsWidth / 2,
                        s = i.globals.labels.slice().length;
                    if (null !== t && (r = i.globals.gridWidth / s * t), null === a || i.globals.isBarHorizontal || (a.setAttribute("x", r), a.setAttribute("x1", r), a.setAttribute("x2", r), a.setAttribute("y2", i.globals.gridHeight), a.classList.add("apexcharts-active")), r < 0 && (r = 0), r > i.globals.gridWidth && (r = i.globals.gridWidth), n.isXAxisTooltipEnabled) {
                        var o = r;
                        "tickWidth" !== i.config.xaxis.crosshairs.width && "barWidth" !== i.config.xaxis.crosshairs.width || (o = r + n.xcrosshairsWidth / 2), this.moveXAxisTooltip(o)
                    }
                }
            }, {
                key: "moveYCrosshairs",
                value: function (e) {
                    var t = this.ttCtx;
                    null !== t.ycrosshairs && v.setAttrs(t.ycrosshairs, {
                        y1: e,
                        y2: e
                    }), null !== t.ycrosshairsHidden && v.setAttrs(t.ycrosshairsHidden, {
                        y1: e,
                        y2: e
                    })
                }
            }, {
                key: "moveXAxisTooltip",
                value: function (e) {
                    var t = this.w,
                        n = this.ttCtx;
                    if (null !== n.xaxisTooltip && 0 !== n.xcrosshairsWidth) {
                        n.xaxisTooltip.classList.add("apexcharts-active");
                        var i, a = n.xaxisOffY + t.config.xaxis.tooltip.offsetY + t.globals.translateY + 1 + t.config.xaxis.offsetY;
                        if (e -= n.xaxisTooltip.getBoundingClientRect().width / 2, !isNaN(e)) e += t.globals.translateX, i = new v(this.ctx).getTextRects(n.xaxisTooltipText.innerHTML), n.xaxisTooltipText.style.minWidth = i.width + "px", n.xaxisTooltip.style.left = e + "px", n.xaxisTooltip.style.top = a + "px"
                    }
                }
            }, {
                key: "moveYAxisTooltip",
                value: function (e) {
                    var t = this.w,
                        n = this.ttCtx;
                    null === n.yaxisTTEls && (n.yaxisTTEls = t.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxistooltip"));
                    var i = parseInt(n.ycrosshairsHidden.getAttribute("y1"), 10),
                        a = t.globals.translateY + i,
                        r = n.yaxisTTEls[e].getBoundingClientRect().height,
                        s = t.globals.translateYAxisX[e] - 2;
                    t.config.yaxis[e].opposite && (s -= 26), a -= r / 2, -1 === t.globals.ignoreYAxisIndexes.indexOf(e) ? (n.yaxisTTEls[e].classList.add("apexcharts-active"), n.yaxisTTEls[e].style.top = a + "px", n.yaxisTTEls[e].style.left = s + t.config.yaxis[e].tooltip.offsetX + "px") : n.yaxisTTEls[e].classList.remove("apexcharts-active")
                }
            }, {
                key: "moveTooltip",
                value: function (e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
                        i = this.w,
                        a = this.ttCtx,
                        r = a.getElTooltip(),
                        s = a.tooltipRect,
                        o = null !== n ? parseFloat(n) : 1,
                        l = parseFloat(e) + o + 5,
                        c = parseFloat(t) + o / 2;
                    if (l > i.globals.gridWidth / 2 && (l = l - s.ttWidth - o - 15), l > i.globals.gridWidth - s.ttWidth - 10 && (l = i.globals.gridWidth - s.ttWidth), l < -20 && (l = -20), i.config.tooltip.followCursor) {
                        var u = a.getElGrid(),
                            d = u.getBoundingClientRect();
                        c = a.e.clientY + i.globals.translateY - d.top - s.ttHeight / 2
                    } else i.globals.isBarHorizontal ? c -= s.ttHeight : (s.ttHeight / 2 + c > i.globals.gridHeight && (c = i.globals.gridHeight - s.ttHeight + i.globals.translateY), c < 0 && (c = 0));
                    isNaN(l) || (l += i.globals.translateX, r.style.left = l + "px", r.style.top = c + "px")
                }
            }, {
                key: "moveMarkers",
                value: function (e, t) {
                    var n = this.w,
                        i = this.ttCtx;
                    if (n.globals.markers.size[e] > 0)
                        for (var a = n.globals.dom.baseEl.querySelectorAll(" .apexcharts-series[data\\:realIndex='".concat(e, "'] .apexcharts-marker")), r = 0; r < a.length; r++) parseInt(a[r].getAttribute("rel"), 10) === t && (i.marker.resetPointsSize(), i.marker.enlargeCurrentPoint(t, a[r]));
                    else i.marker.resetPointsSize(), this.moveDynamicPointOnHover(t, e)
                }
            }, {
                key: "moveDynamicPointOnHover",
                value: function (e, t) {
                    var n, i, a = this.w,
                        r = this.ttCtx,
                        s = a.globals.pointsArray,
                        o = r.tooltipUtil.getHoverMarkerSize(t),
                        l = a.config.series[t].type;
                    if (!l || "column" !== l && "candlestick" !== l && "boxPlot" !== l) {
                        n = s[t][e][0], i = s[t][e][1] ? s[t][e][1] : 0;
                        var c = a.globals.dom.baseEl.querySelector(".apexcharts-series[data\\:realIndex='".concat(t, "'] .apexcharts-series-markers circle"));
                        c && i < a.globals.gridHeight && i > 0 && (c.setAttribute("r", o), c.setAttribute("cx", n), c.setAttribute("cy", i)), this.moveXCrosshairs(n), r.fixedTooltip || this.moveTooltip(n, i, o)
                    }
                }
            }, {
                key: "moveDynamicPointsOnHover",
                value: function (e) {
                    var t, n = this.ttCtx,
                        i = n.w,
                        a = 0,
                        r = 0,
                        s = i.globals.pointsArray;
                    t = new E(this.ctx).getActiveConfigSeriesIndex(!0);
                    var o = n.tooltipUtil.getHoverMarkerSize(t);
                    s[t] && (a = s[t][e][0], r = s[t][e][1]);
                    var l = n.tooltipUtil.getAllMarkers();
                    if (null !== l)
                        for (var c = 0; c < i.globals.series.length; c++) {
                            var u = s[c];
                            if (i.globals.comboCharts && void 0 === u && l.splice(c, 0, null), u && u.length) {
                                var d = s[c][e][1];
                                l[c].setAttribute("cx", a), null !== d && !isNaN(d) && d < i.globals.gridHeight && d > 0 ? (l[c] && l[c].setAttribute("r", o), l[c] && l[c].setAttribute("cy", d)) : l[c] && l[c].setAttribute("r", 0)
                            }
                        }
                    if (this.moveXCrosshairs(a), !n.fixedTooltip) {
                        var h = r || i.globals.gridHeight;
                        this.moveTooltip(a, h, o)
                    }
                }
            }, {
                key: "moveStickyTooltipOverBars",
                value: function (e) {
                    var t = this.w,
                        n = this.ttCtx,
                        i = t.globals.columnSeries ? t.globals.columnSeries.length : t.globals.series.length,
                        a = i >= 2 && i % 2 == 0 ? Math.floor(i / 2) : Math.floor(i / 2) + 1;
                    t.globals.isBarHorizontal && (a = new E(this.ctx).getActiveConfigSeriesIndex(!1, "desc") + 1);
                    var r = t.globals.dom.baseEl.querySelector(".apexcharts-bar-series .apexcharts-series[rel='".concat(a, "'] path[j='").concat(e, "'], .apexcharts-candlestick-series .apexcharts-series[rel='").concat(a, "'] path[j='").concat(e, "'], .apexcharts-boxPlot-series .apexcharts-series[rel='").concat(a, "'] path[j='").concat(e, "'], .apexcharts-rangebar-series .apexcharts-series[rel='").concat(a, "'] path[j='").concat(e, "']")),
                        s = r ? parseFloat(r.getAttribute("cx")) : 0,
                        o = r ? parseFloat(r.getAttribute("cy")) : 0,
                        l = r ? parseFloat(r.getAttribute("barWidth")) : 0,
                        c = r ? parseFloat(r.getAttribute("barHeight")) : 0,
                        u = n.getElGrid().getBoundingClientRect(),
                        d = r.classList.contains("apexcharts-candlestick-area") || r.classList.contains("apexcharts-boxPlot-area");
                    if (t.globals.isXNumeric ? (r && !d && (s -= i % 2 != 0 ? l / 2 : 0), r && d && t.globals.comboCharts && (s -= l / 2)) : t.globals.isBarHorizontal || (s = n.xAxisTicksPositions[e - 1] + n.dataPointsDividedWidth / 2, isNaN(s) && (s = n.xAxisTicksPositions[e] - n.dataPointsDividedWidth / 2)), t.globals.isBarHorizontal ? o += c / 3 : o = n.e.clientY - u.top - n.tooltipRect.ttHeight / 2, t.globals.isBarHorizontal || this.moveXCrosshairs(s), !n.fixedTooltip) {
                        var h = o || t.globals.gridHeight;
                        this.moveTooltip(s, h)
                    }
                }
            }]), e
        }(),
        pe = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.ttCtx = t, this.ctx = t.ctx, this.tooltipPosition = new fe(t)
            }
            return r(e, [{
                key: "drawDynamicPoints",
                value: function () {
                    var e = this.w,
                        t = new v(this.ctx),
                        n = new A(this.ctx),
                        i = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series");
                    i = h(i), e.config.chart.stacked && i.sort((function (e, t) {
                        return parseFloat(e.getAttribute("data:realIndex")) - parseFloat(t.getAttribute("data:realIndex"))
                    }));
                    for (var a = 0; a < i.length; a++) {
                        var r = i[a].querySelector(".apexcharts-series-markers-wrap");
                        if (null !== r) {
                            var s = void 0,
                                o = "apexcharts-marker w".concat((Math.random() + 1).toString(36).substring(4));
                            "line" !== e.config.chart.type && "area" !== e.config.chart.type || e.globals.comboCharts || e.config.tooltip.intersect || (o += " no-pointer-events");
                            var l = n.getMarkerConfig({
                                cssClass: o,
                                seriesIndex: Number(r.getAttribute("data:realIndex"))
                            });
                            (s = t.drawMarker(0, 0, l)).node.setAttribute("default-marker-size", 0);
                            var c = document.createElementNS(e.globals.SVGNS, "g");
                            c.classList.add("apexcharts-series-markers"), c.appendChild(s.node), r.appendChild(c)
                        }
                    }
                }
            }, {
                key: "enlargeCurrentPoint",
                value: function (e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
                        i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
                        a = this.w;
                    "bubble" !== a.config.chart.type && this.newPointSize(e, t);
                    var r = t.getAttribute("cx"),
                        s = t.getAttribute("cy");
                    if (null !== n && null !== i && (r = n, s = i), this.tooltipPosition.moveXCrosshairs(r), !this.fixedTooltip) {
                        if ("radar" === a.config.chart.type) {
                            var o = this.ttCtx.getElGrid(),
                                l = o.getBoundingClientRect();
                            r = this.ttCtx.e.clientX - l.left
                        }
                        this.tooltipPosition.moveTooltip(r, s, a.config.markers.hover.size)
                    }
                }
            }, {
                key: "enlargePoints",
                value: function (e) {
                    for (var t = this.w, n = this, i = this.ttCtx, a = e, r = t.globals.dom.baseEl.querySelectorAll(".apexcharts-series:not(.apexcharts-series-collapsed) .apexcharts-marker"), s = t.config.markers.hover.size, o = 0; o < r.length; o++) {
                        var l = r[o].getAttribute("rel"),
                            c = r[o].getAttribute("index");
                        if (void 0 === s && (s = t.globals.markers.size[c] + t.config.markers.hover.sizeOffset), a === parseInt(l, 10)) {
                            n.newPointSize(a, r[o]);
                            var u = r[o].getAttribute("cx"),
                                d = r[o].getAttribute("cy");
                            n.tooltipPosition.moveXCrosshairs(u), i.fixedTooltip || n.tooltipPosition.moveTooltip(u, d, s)
                        } else n.oldPointSize(r[o])
                    }
                }
            }, {
                key: "newPointSize",
                value: function (e, t) {
                    var n = this.w,
                        i = n.config.markers.hover.size,
                        a = 0 === e ? t.parentNode.firstChild : t.parentNode.lastChild;
                    if ("0" !== a.getAttribute("default-marker-size")) {
                        var r = parseInt(a.getAttribute("index"), 10);
                        void 0 === i && (i = n.globals.markers.size[r] + n.config.markers.hover.sizeOffset), i < 0 && (i = 0), a.setAttribute("r", i)
                    }
                }
            }, {
                key: "oldPointSize",
                value: function (e) {
                    var t = parseFloat(e.getAttribute("default-marker-size"));
                    e.setAttribute("r", t)
                }
            }, {
                key: "resetPointsSize",
                value: function () {
                    for (var e = this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-series:not(.apexcharts-series-collapsed) .apexcharts-marker"), t = 0; t < e.length; t++) {
                        var n = parseFloat(e[t].getAttribute("default-marker-size"));
                        p.isNumber(n) && n >= 0 ? e[t].setAttribute("r", n) : e[t].setAttribute("r", 0)
                    }
                }
            }]), e
        }(),
        me = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.ttCtx = t
            }
            return r(e, [{
                key: "getAttr",
                value: function (e, t) {
                    return parseFloat(e.target.getAttribute(t))
                }
            }, {
                key: "handleHeatTreeTooltip",
                value: function (e) {
                    var t = e.e,
                        n = e.opt,
                        i = e.x,
                        a = e.y,
                        r = e.type,
                        s = this.ttCtx,
                        o = this.w;
                    if (t.target.classList.contains("apexcharts-".concat(r, "-rect"))) {
                        var l = this.getAttr(t, "i"),
                            c = this.getAttr(t, "j"),
                            u = this.getAttr(t, "cx"),
                            d = this.getAttr(t, "cy"),
                            h = this.getAttr(t, "width"),
                            f = this.getAttr(t, "height");
                        if (s.tooltipLabels.drawSeriesTexts({
                                ttItems: n.ttItems,
                                i: l,
                                j: c,
                                shared: !1,
                                e: t
                            }), o.globals.capturedSeriesIndex = l, o.globals.capturedDataPointIndex = c, i = u + s.tooltipRect.ttWidth / 2 + h, a = d + s.tooltipRect.ttHeight / 2 - f / 2, s.tooltipPosition.moveXCrosshairs(u + h / 2), i > o.globals.gridWidth / 2 && (i = u - s.tooltipRect.ttWidth / 2 + h), s.w.config.tooltip.followCursor) {
                            var p = o.globals.dom.elWrap.getBoundingClientRect();
                            i = o.globals.clientX - p.left - s.tooltipRect.ttWidth / 2, a = o.globals.clientY - p.top - s.tooltipRect.ttHeight - 5
                        }
                    }
                    return {
                        x: i,
                        y: a
                    }
                }
            }, {
                key: "handleMarkerTooltip",
                value: function (e) {
                    var t, n, i = e.e,
                        a = e.opt,
                        r = e.x,
                        s = e.y,
                        o = this.w,
                        l = this.ttCtx;
                    if (i.target.classList.contains("apexcharts-marker")) {
                        var c = parseInt(a.paths.getAttribute("cx"), 10),
                            u = parseInt(a.paths.getAttribute("cy"), 10),
                            d = parseFloat(a.paths.getAttribute("val"));
                        if (n = parseInt(a.paths.getAttribute("rel"), 10), t = parseInt(a.paths.parentNode.parentNode.parentNode.getAttribute("rel"), 10) - 1, l.intersect) {
                            var h = p.findAncestor(a.paths, "apexcharts-series");
                            h && (t = parseInt(h.getAttribute("data:realIndex"), 10))
                        }
                        if (l.tooltipLabels.drawSeriesTexts({
                                ttItems: a.ttItems,
                                i: t,
                                j: n,
                                shared: !l.showOnIntersect && o.config.tooltip.shared,
                                e: i
                            }), "mouseup" === i.type && l.markerClick(i, t, n), o.globals.capturedSeriesIndex = t, o.globals.capturedDataPointIndex = n, r = c, s = u + o.globals.translateY - 1.4 * l.tooltipRect.ttHeight, l.w.config.tooltip.followCursor) {
                            var f = l.getElGrid().getBoundingClientRect();
                            s = l.e.clientY + o.globals.translateY - f.top
                        }
                        d < 0 && (s = u), l.marker.enlargeCurrentPoint(n, a.paths, r, s)
                    }
                    return {
                        x: r,
                        y: s
                    }
                }
            }, {
                key: "handleBarTooltip",
                value: function (e) {
                    var t, n, i = e.e,
                        a = e.opt,
                        r = this.w,
                        s = this.ttCtx,
                        o = s.getElTooltip(),
                        l = 0,
                        c = 0,
                        u = 0,
                        d = this.getBarTooltipXY({
                            e: i,
                            opt: a
                        });
                    t = d.i;
                    var h = d.barHeight,
                        f = d.j;
                    r.globals.capturedSeriesIndex = t, r.globals.capturedDataPointIndex = f, r.globals.isBarHorizontal && s.tooltipUtil.hasBars() || !r.config.tooltip.shared ? (c = d.x, u = d.y, n = Array.isArray(r.config.stroke.width) ? r.config.stroke.width[t] : r.config.stroke.width, l = c) : r.globals.comboCharts || r.config.tooltip.shared || (l /= 2), isNaN(u) ? u = r.globals.svgHeight - s.tooltipRect.ttHeight : u < 0 && (u = 0);
                    var p = parseInt(a.paths.parentNode.getAttribute("data:realIndex"), 10),
                        m = r.globals.isMultipleYAxis ? r.config.yaxis[p] && r.config.yaxis[p].reversed : r.config.yaxis[0].reversed;
                    if (c + s.tooltipRect.ttWidth > r.globals.gridWidth && !m ? c -= s.tooltipRect.ttWidth : c < 0 && (c = 0), s.w.config.tooltip.followCursor) {
                        var g = s.getElGrid().getBoundingClientRect();
                        u = s.e.clientY - g.top
                    }
                    null === s.tooltip && (s.tooltip = r.globals.dom.baseEl.querySelector(".apexcharts-tooltip")), r.config.tooltip.shared || (r.globals.comboBarCount > 0 ? s.tooltipPosition.moveXCrosshairs(l + n / 2) : s.tooltipPosition.moveXCrosshairs(l)), !s.fixedTooltip && (!r.config.tooltip.shared || r.globals.isBarHorizontal && s.tooltipUtil.hasBars()) && (m && (c -= s.tooltipRect.ttWidth) < 0 && (c = 0), !m || r.globals.isBarHorizontal && s.tooltipUtil.hasBars() || (u = u + h - 2 * (r.globals.series[t][f] < 0 ? h : 0)), s.tooltipRect.ttHeight + u > r.globals.gridHeight ? u = r.globals.gridHeight - s.tooltipRect.ttHeight + r.globals.translateY : (u = u + r.globals.translateY - s.tooltipRect.ttHeight / 2) < 0 && (u = 0), o.style.left = c + r.globals.translateX + "px", o.style.top = u + "px")
                }
            }, {
                key: "getBarTooltipXY",
                value: function (e) {
                    var t = e.e,
                        n = e.opt,
                        i = this.w,
                        a = null,
                        r = this.ttCtx,
                        s = 0,
                        o = 0,
                        l = 0,
                        c = 0,
                        u = 0,
                        d = t.target.classList;
                    if (d.contains("apexcharts-bar-area") || d.contains("apexcharts-candlestick-area") || d.contains("apexcharts-boxPlot-area") || d.contains("apexcharts-rangebar-area")) {
                        var h = t.target,
                            f = h.getBoundingClientRect(),
                            p = n.elGrid.getBoundingClientRect(),
                            m = f.height;
                        u = f.height;
                        var g = f.width,
                            v = parseInt(h.getAttribute("cx"), 10),
                            y = parseInt(h.getAttribute("cy"), 10);
                        c = parseFloat(h.getAttribute("barWidth"));
                        var b = "touchmove" === t.type ? t.touches[0].clientX : t.clientX;
                        a = parseInt(h.getAttribute("j"), 10), s = parseInt(h.parentNode.getAttribute("rel"), 10) - 1;
                        var x = h.getAttribute("data-range-y1"),
                            _ = h.getAttribute("data-range-y2");
                        i.globals.comboCharts && (s = parseInt(h.parentNode.getAttribute("data:realIndex"), 10)), r.tooltipLabels.drawSeriesTexts({
                            ttItems: n.ttItems,
                            i: s,
                            j: a,
                            y1: x ? parseInt(x, 10) : null,
                            y2: _ ? parseInt(_, 10) : null,
                            shared: !r.showOnIntersect && i.config.tooltip.shared,
                            e: t
                        }), i.config.tooltip.followCursor ? i.globals.isBarHorizontal ? (o = b - p.left + 15, l = y - r.dataPointsDividedHeight + m / 2 - r.tooltipRect.ttHeight / 2) : (o = i.globals.isXNumeric ? v - g / 2 : v - r.dataPointsDividedWidth + g / 2, l = t.clientY - p.top - r.tooltipRect.ttHeight / 2 - 15) : i.globals.isBarHorizontal ? ((o = v) < r.xyRatios.baseLineInvertedY && (o = v - r.tooltipRect.ttWidth), l = y - r.dataPointsDividedHeight + m / 2 - r.tooltipRect.ttHeight / 2) : (o = i.globals.isXNumeric ? v - g / 2 : v - r.dataPointsDividedWidth + g / 2, l = y)
                    }
                    return {
                        x: o,
                        y: l,
                        barHeight: u,
                        barWidth: c,
                        i: s,
                        j: a
                    }
                }
            }]), e
        }(),
        ge = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.ttCtx = t
            }
            return r(e, [{
                key: "drawXaxisTooltip",
                value: function () {
                    var e = this.w,
                        t = this.ttCtx,
                        n = "bottom" === e.config.xaxis.position;
                    t.xaxisOffY = n ? e.globals.gridHeight + 1 : -e.globals.xAxisHeight - e.config.xaxis.axisTicks.height + 3;
                    var i = n ? "apexcharts-xaxistooltip apexcharts-xaxistooltip-bottom" : "apexcharts-xaxistooltip apexcharts-xaxistooltip-top",
                        a = e.globals.dom.elWrap;
                    t.isXAxisTooltipEnabled && null === e.globals.dom.baseEl.querySelector(".apexcharts-xaxistooltip") && (t.xaxisTooltip = document.createElement("div"), t.xaxisTooltip.setAttribute("class", i + " apexcharts-theme-" + e.config.tooltip.theme), a.appendChild(t.xaxisTooltip), t.xaxisTooltipText = document.createElement("div"), t.xaxisTooltipText.classList.add("apexcharts-xaxistooltip-text"), t.xaxisTooltipText.style.fontFamily = e.config.xaxis.tooltip.style.fontFamily || e.config.chart.fontFamily, t.xaxisTooltipText.style.fontSize = e.config.xaxis.tooltip.style.fontSize, t.xaxisTooltip.appendChild(t.xaxisTooltipText))
                }
            }, {
                key: "drawYaxisTooltip",
                value: function () {
                    for (var e = this.w, t = this.ttCtx, n = function (n) {
                            var i = e.config.yaxis[n].opposite || e.config.yaxis[n].crosshairs.opposite;
                            t.yaxisOffX = i ? e.globals.gridWidth + 1 : 1;
                            var a = "apexcharts-yaxistooltip apexcharts-yaxistooltip-".concat(n, i ? " apexcharts-yaxistooltip-right" : " apexcharts-yaxistooltip-left");
                            e.globals.yAxisSameScaleIndices.map((function (t, i) {
                                t.map((function (t, i) {
                                    i === n && (a += e.config.yaxis[i].show ? " " : " apexcharts-yaxistooltip-hidden")
                                }))
                            }));
                            var r = e.globals.dom.elWrap;
                            null === e.globals.dom.baseEl.querySelector(".apexcharts-yaxistooltip apexcharts-yaxistooltip-".concat(n)) && (t.yaxisTooltip = document.createElement("div"), t.yaxisTooltip.setAttribute("class", a + " apexcharts-theme-" + e.config.tooltip.theme), r.appendChild(t.yaxisTooltip), 0 === n && (t.yaxisTooltipText = []), t.yaxisTooltipText[n] = document.createElement("div"), t.yaxisTooltipText[n].classList.add("apexcharts-yaxistooltip-text"), t.yaxisTooltip.appendChild(t.yaxisTooltipText[n]))
                        }, i = 0; i < e.config.yaxis.length; i++) n(i)
                }
            }, {
                key: "setXCrosshairWidth",
                value: function () {
                    var e = this.w,
                        t = this.ttCtx,
                        n = t.getElXCrosshairs();
                    if (t.xcrosshairsWidth = parseInt(e.config.xaxis.crosshairs.width, 10), e.globals.comboCharts) {
                        var i = e.globals.dom.baseEl.querySelector(".apexcharts-bar-area");
                        if (null !== i && "barWidth" === e.config.xaxis.crosshairs.width) {
                            var a = parseFloat(i.getAttribute("barWidth"));
                            t.xcrosshairsWidth = a
                        } else if ("tickWidth" === e.config.xaxis.crosshairs.width) {
                            var r = e.globals.labels.length;
                            t.xcrosshairsWidth = e.globals.gridWidth / r
                        }
                    } else if ("tickWidth" === e.config.xaxis.crosshairs.width) {
                        var s = e.globals.labels.length;
                        t.xcrosshairsWidth = e.globals.gridWidth / s
                    } else if ("barWidth" === e.config.xaxis.crosshairs.width) {
                        var o = e.globals.dom.baseEl.querySelector(".apexcharts-bar-area");
                        if (null !== o) {
                            var l = parseFloat(o.getAttribute("barWidth"));
                            t.xcrosshairsWidth = l
                        } else t.xcrosshairsWidth = 1
                    }
                    e.globals.isBarHorizontal && (t.xcrosshairsWidth = 0), null !== n && t.xcrosshairsWidth > 0 && n.setAttribute("width", t.xcrosshairsWidth)
                }
            }, {
                key: "handleYCrosshair",
                value: function () {
                    var e = this.w,
                        t = this.ttCtx;
                    t.ycrosshairs = e.globals.dom.baseEl.querySelector(".apexcharts-ycrosshairs"), t.ycrosshairsHidden = e.globals.dom.baseEl.querySelector(".apexcharts-ycrosshairs-hidden")
                }
            }, {
                key: "drawYaxisTooltipText",
                value: function (e, t, n) {
                    var i = this.ttCtx,
                        a = this.w,
                        r = a.globals.yLabelFormatters[e];
                    if (i.yaxisTooltips[e]) {
                        var s = i.getElGrid().getBoundingClientRect(),
                            o = (t - s.top) * n.yRatio[e],
                            l = a.globals.maxYArr[e] - a.globals.minYArr[e],
                            c = a.globals.minYArr[e] + (l - o);
                        i.tooltipPosition.moveYCrosshairs(t - s.top), i.yaxisTooltipText[e].innerHTML = r(c), i.tooltipPosition.moveYAxisTooltip(e)
                    }
                }
            }]), e
        }(),
        ve = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w;
                var n = this.w;
                this.tConfig = n.config.tooltip, this.tooltipUtil = new de(this), this.tooltipLabels = new he(this), this.tooltipPosition = new fe(this), this.marker = new pe(this), this.intersect = new me(this), this.axesTooltip = new ge(this), this.showOnIntersect = this.tConfig.intersect, this.showTooltipTitle = this.tConfig.x.show, this.fixedTooltip = this.tConfig.fixed.enabled, this.xaxisTooltip = null, this.yaxisTTEls = null, this.isBarShared = !n.globals.isBarHorizontal && this.tConfig.shared, this.lastHoverTime = Date.now()
            }
            return r(e, [{
                key: "getElTooltip",
                value: function (e) {
                    return e || (e = this), e.w.globals.dom.baseEl.querySelector(".apexcharts-tooltip")
                }
            }, {
                key: "getElXCrosshairs",
                value: function () {
                    return this.w.globals.dom.baseEl.querySelector(".apexcharts-xcrosshairs")
                }
            }, {
                key: "getElGrid",
                value: function () {
                    return this.w.globals.dom.baseEl.querySelector(".apexcharts-grid")
                }
            }, {
                key: "drawTooltip",
                value: function (e) {
                    var t = this.w;
                    this.xyRatios = e, this.isXAxisTooltipEnabled = t.config.xaxis.tooltip.enabled && t.globals.axisCharts, this.yaxisTooltips = t.config.yaxis.map((function (e, n) {
                        return !!(e.show && e.tooltip.enabled && t.globals.axisCharts)
                    })), this.allTooltipSeriesGroups = [], t.globals.axisCharts || (this.showTooltipTitle = !1);
                    var n = document.createElement("div");
                    if (n.classList.add("apexcharts-tooltip"), n.classList.add("apexcharts-theme-".concat(this.tConfig.theme)), t.globals.dom.elWrap.appendChild(n), t.globals.axisCharts) {
                        this.axesTooltip.drawXaxisTooltip(), this.axesTooltip.drawYaxisTooltip(), this.axesTooltip.setXCrosshairWidth(), this.axesTooltip.handleYCrosshair();
                        var i = new V(this.ctx);
                        this.xAxisTicksPositions = i.getXAxisTicksPositions()
                    }
                    if (!t.globals.comboCharts && !this.tConfig.intersect && "rangeBar" !== t.config.chart.type || this.tConfig.shared || (this.showOnIntersect = !0), 0 !== t.config.markers.size && 0 !== t.globals.markers.largestSize || this.marker.drawDynamicPoints(this), t.globals.collapsedSeries.length !== t.globals.series.length) {
                        this.dataPointsDividedHeight = t.globals.gridHeight / t.globals.dataPoints, this.dataPointsDividedWidth = t.globals.gridWidth / t.globals.dataPoints, this.showTooltipTitle && (this.tooltipTitle = document.createElement("div"), this.tooltipTitle.classList.add("apexcharts-tooltip-title"), this.tooltipTitle.style.fontFamily = this.tConfig.style.fontFamily || t.config.chart.fontFamily, this.tooltipTitle.style.fontSize = this.tConfig.style.fontSize, n.appendChild(this.tooltipTitle));
                        var a = t.globals.series.length;
                        (t.globals.xyCharts || t.globals.comboCharts) && this.tConfig.shared && (a = this.showOnIntersect ? 1 : t.globals.series.length), this.legendLabels = t.globals.dom.baseEl.querySelectorAll(".apexcharts-legend-text"), this.ttItems = this.createTTElements(a), this.addSVGEvents()
                    }
                }
            }, {
                key: "createTTElements",
                value: function (e) {
                    for (var t = this, n = this.w, i = [], a = this.getElTooltip(), r = function (r) {
                            var s = document.createElement("div");
                            s.classList.add("apexcharts-tooltip-series-group"), s.style.order = n.config.tooltip.inverseOrder ? e - r : r + 1, t.tConfig.shared && t.tConfig.enabledOnSeries && Array.isArray(t.tConfig.enabledOnSeries) && t.tConfig.enabledOnSeries.indexOf(r) < 0 && s.classList.add("apexcharts-tooltip-series-group-hidden");
                            var o = document.createElement("span");
                            o.classList.add("apexcharts-tooltip-marker"), o.style.backgroundColor = n.globals.colors[r], s.appendChild(o);
                            var l = document.createElement("div");
                            l.classList.add("apexcharts-tooltip-text"), l.style.fontFamily = t.tConfig.style.fontFamily || n.config.chart.fontFamily, l.style.fontSize = t.tConfig.style.fontSize, ["y", "goals", "z"].forEach((function (e) {
                                var t = document.createElement("div");
                                t.classList.add("apexcharts-tooltip-".concat(e, "-group"));
                                var n = document.createElement("span");
                                n.classList.add("apexcharts-tooltip-text-".concat(e, "-label")), t.appendChild(n);
                                var i = document.createElement("span");
                                i.classList.add("apexcharts-tooltip-text-".concat(e, "-value")), t.appendChild(i), l.appendChild(t)
                            })), s.appendChild(l), a.appendChild(s), i.push(s)
                        }, s = 0; s < e; s++) r(s);
                    return i
                }
            }, {
                key: "addSVGEvents",
                value: function () {
                    var e = this.w,
                        t = e.config.chart.type,
                        n = this.getElTooltip(),
                        i = !("bar" !== t && "candlestick" !== t && "boxPlot" !== t && "rangeBar" !== t),
                        a = "area" === t || "line" === t || "scatter" === t || "bubble" === t || "radar" === t,
                        r = e.globals.dom.Paper.node,
                        s = this.getElGrid();
                    s && (this.seriesBound = s.getBoundingClientRect());
                    var o, l = [],
                        c = [],
                        u = {
                            hoverArea: r,
                            elGrid: s,
                            tooltipEl: n,
                            tooltipY: l,
                            tooltipX: c,
                            ttItems: this.ttItems
                        };
                    if (e.globals.axisCharts && (a ? o = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series[data\\:longestSeries='true'] .apexcharts-marker") : i ? o = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series .apexcharts-bar-area, .apexcharts-series .apexcharts-candlestick-area, .apexcharts-series .apexcharts-boxPlot-area, .apexcharts-series .apexcharts-rangebar-area") : "heatmap" !== t && "treemap" !== t || (o = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series .apexcharts-heatmap, .apexcharts-series .apexcharts-treemap")), o && o.length))
                        for (var d = 0; d < o.length; d++) l.push(o[d].getAttribute("cy")), c.push(o[d].getAttribute("cx"));
                    if (e.globals.xyCharts && !this.showOnIntersect || e.globals.comboCharts && !this.showOnIntersect || i && this.tooltipUtil.hasBars() && this.tConfig.shared) this.addPathsEventListeners([r], u);
                    else if (i && !e.globals.comboCharts || a && this.showOnIntersect) this.addDatapointEventsListeners(u);
                    else if (!e.globals.axisCharts || "heatmap" === t || "treemap" === t) {
                        var h = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series");
                        this.addPathsEventListeners(h, u)
                    }
                    if (this.showOnIntersect) {
                        var f = e.globals.dom.baseEl.querySelectorAll(".apexcharts-line-series .apexcharts-marker, .apexcharts-area-series .apexcharts-marker");
                        f.length > 0 && this.addPathsEventListeners(f, u), this.tooltipUtil.hasBars() && !this.tConfig.shared && this.addDatapointEventsListeners(u)
                    }
                }
            }, {
                key: "drawFixedTooltipRect",
                value: function () {
                    var e = this.w,
                        t = this.getElTooltip(),
                        n = t.getBoundingClientRect(),
                        i = n.width + 10,
                        a = n.height + 10,
                        r = this.tConfig.fixed.offsetX,
                        s = this.tConfig.fixed.offsetY,
                        o = this.tConfig.fixed.position.toLowerCase();
                    return o.indexOf("right") > -1 && (r = r + e.globals.svgWidth - i + 10), o.indexOf("bottom") > -1 && (s = s + e.globals.svgHeight - a - 10), t.style.left = r + "px", t.style.top = s + "px", {
                        x: r,
                        y: s,
                        ttWidth: i,
                        ttHeight: a
                    }
                }
            }, {
                key: "addDatapointEventsListeners",
                value: function (e) {
                    var t = this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-series-markers .apexcharts-marker, .apexcharts-bar-area, .apexcharts-candlestick-area, .apexcharts-boxPlot-area, .apexcharts-rangebar-area");
                    this.addPathsEventListeners(t, e)
                }
            }, {
                key: "addPathsEventListeners",
                value: function (e, t) {
                    for (var n = this, i = function (i) {
                            var a = {
                                paths: e[i],
                                tooltipEl: t.tooltipEl,
                                tooltipY: t.tooltipY,
                                tooltipX: t.tooltipX,
                                elGrid: t.elGrid,
                                hoverArea: t.hoverArea,
                                ttItems: t.ttItems
                            };
                            ["mousemove", "mouseup", "touchmove", "mouseout", "touchend"].map((function (t) {
                                return e[i].addEventListener(t, n.onSeriesHover.bind(n, a), {
                                    capture: !1,
                                    passive: !0
                                })
                            }))
                        }, a = 0; a < e.length; a++) i(a)
                }
            }, {
                key: "onSeriesHover",
                value: function (e, t) {
                    var n = this,
                        i = Date.now() - this.lastHoverTime;
                    i >= 100 ? this.seriesHover(e, t) : (clearTimeout(this.seriesHoverTimeout), this.seriesHoverTimeout = setTimeout((function () {
                        n.seriesHover(e, t)
                    }), 100 - i))
                }
            }, {
                key: "seriesHover",
                value: function (e, t) {
                    var n = this;
                    this.lastHoverTime = Date.now();
                    var i = [],
                        a = this.w;
                    a.config.chart.group && (i = this.ctx.getGroupedCharts()), a.globals.axisCharts && (a.globals.minX === -1 / 0 && a.globals.maxX === 1 / 0 || 0 === a.globals.dataPoints) || (i.length ? i.forEach((function (i) {
                        var a = n.getElTooltip(i),
                            r = {
                                paths: e.paths,
                                tooltipEl: a,
                                tooltipY: e.tooltipY,
                                tooltipX: e.tooltipX,
                                elGrid: e.elGrid,
                                hoverArea: e.hoverArea,
                                ttItems: i.w.globals.tooltip.ttItems
                            };
                        i.w.globals.minX === n.w.globals.minX && i.w.globals.maxX === n.w.globals.maxX && i.w.globals.tooltip.seriesHoverByContext({
                            chartCtx: i,
                            ttCtx: i.w.globals.tooltip,
                            opt: r,
                            e: t
                        })
                    })) : this.seriesHoverByContext({
                        chartCtx: this.ctx,
                        ttCtx: this.w.globals.tooltip,
                        opt: e,
                        e: t
                    }))
                }
            }, {
                key: "seriesHoverByContext",
                value: function (e) {
                    var t = e.chartCtx,
                        n = e.ttCtx,
                        i = e.opt,
                        a = e.e,
                        r = t.w,
                        s = this.getElTooltip();
                    n.tooltipRect = {
                        x: 0,
                        y: 0,
                        ttWidth: s.getBoundingClientRect().width,
                        ttHeight: s.getBoundingClientRect().height
                    }, n.e = a, !n.tooltipUtil.hasBars() || r.globals.comboCharts || n.isBarShared || this.tConfig.onDatasetHover.highlightDataSeries && new E(t).toggleSeriesOnHover(a, a.target.parentNode), n.fixedTooltip && n.drawFixedTooltipRect(), r.globals.axisCharts ? n.axisChartsTooltips({
                        e: a,
                        opt: i,
                        tooltipRect: n.tooltipRect
                    }) : n.nonAxisChartsTooltips({
                        e: a,
                        opt: i,
                        tooltipRect: n.tooltipRect
                    })
                }
            }, {
                key: "axisChartsTooltips",
                value: function (e) {
                    var t, n, i = e.e,
                        a = e.opt,
                        r = this.w,
                        s = a.elGrid.getBoundingClientRect(),
                        o = "touchmove" === i.type ? i.touches[0].clientX : i.clientX,
                        l = "touchmove" === i.type ? i.touches[0].clientY : i.clientY;
                    if (this.clientY = l, this.clientX = o, r.globals.capturedSeriesIndex = -1, r.globals.capturedDataPointIndex = -1, l < s.top || l > s.top + s.height) this.handleMouseOut(a);
                    else {
                        if (Array.isArray(this.tConfig.enabledOnSeries) && !r.config.tooltip.shared) {
                            var c = parseInt(a.paths.getAttribute("index"), 10);
                            if (this.tConfig.enabledOnSeries.indexOf(c) < 0) return void this.handleMouseOut(a)
                        }
                        var u = this.getElTooltip(),
                            d = this.getElXCrosshairs(),
                            h = r.globals.xyCharts || "bar" === r.config.chart.type && !r.globals.isBarHorizontal && this.tooltipUtil.hasBars() && this.tConfig.shared || r.globals.comboCharts && this.tooltipUtil.hasBars();
                        if ("mousemove" === i.type || "touchmove" === i.type || "mouseup" === i.type) {
                            null !== d && d.classList.add("apexcharts-active");
                            var f = this.yaxisTooltips.filter((function (e) {
                                return !0 === e
                            }));
                            if (null !== this.ycrosshairs && f.length && this.ycrosshairs.classList.add("apexcharts-active"), h && !this.showOnIntersect) this.handleStickyTooltip(i, o, l, a);
                            else if ("heatmap" === r.config.chart.type || "treemap" === r.config.chart.type) {
                                var p = this.intersect.handleHeatTreeTooltip({
                                    e: i,
                                    opt: a,
                                    x: t,
                                    y: n,
                                    type: r.config.chart.type
                                });
                                t = p.x, n = p.y, u.style.left = t + "px", u.style.top = n + "px"
                            } else this.tooltipUtil.hasBars() && this.intersect.handleBarTooltip({
                                e: i,
                                opt: a
                            }), this.tooltipUtil.hasMarkers() && this.intersect.handleMarkerTooltip({
                                e: i,
                                opt: a,
                                x: t,
                                y: n
                            });
                            if (this.yaxisTooltips.length)
                                for (var m = 0; m < r.config.yaxis.length; m++) this.axesTooltip.drawYaxisTooltipText(m, l, this.xyRatios);
                            a.tooltipEl.classList.add("apexcharts-active")
                        } else "mouseout" !== i.type && "touchend" !== i.type || this.handleMouseOut(a)
                    }
                }
            }, {
                key: "nonAxisChartsTooltips",
                value: function (e) {
                    var t = e.e,
                        n = e.opt,
                        i = e.tooltipRect,
                        a = this.w,
                        r = n.paths.getAttribute("rel"),
                        s = this.getElTooltip(),
                        o = a.globals.dom.elWrap.getBoundingClientRect();
                    if ("mousemove" === t.type || "touchmove" === t.type) {
                        s.classList.add("apexcharts-active"), this.tooltipLabels.drawSeriesTexts({
                            ttItems: n.ttItems,
                            i: parseInt(r, 10) - 1,
                            shared: !1
                        });
                        var l = a.globals.clientX - o.left - i.ttWidth / 2,
                            c = a.globals.clientY - o.top - i.ttHeight - 10;
                        if (s.style.left = l + "px", s.style.top = c + "px", a.config.legend.tooltipHoverFormatter) {
                            var u = r - 1,
                                d = (0, a.config.legend.tooltipHoverFormatter)(this.legendLabels[u].getAttribute("data:default-text"), {
                                    seriesIndex: u,
                                    dataPointIndex: u,
                                    w: a
                                });
                            this.legendLabels[u].innerHTML = d
                        }
                    } else "mouseout" !== t.type && "touchend" !== t.type || (s.classList.remove("apexcharts-active"), a.config.legend.tooltipHoverFormatter && this.legendLabels.forEach((function (e) {
                        var t = e.getAttribute("data:default-text");
                        e.innerHTML = decodeURIComponent(t)
                    })))
                }
            }, {
                key: "handleStickyTooltip",
                value: function (e, t, n, i) {
                    var a = this.w,
                        r = this.tooltipUtil.getNearestValues({
                            context: this,
                            hoverArea: i.hoverArea,
                            elGrid: i.elGrid,
                            clientX: t,
                            clientY: n
                        }),
                        s = r.j,
                        o = r.capturedSeries,
                        l = i.elGrid.getBoundingClientRect();
                    r.hoverX < 0 || r.hoverX > l.width ? this.handleMouseOut(i) : null !== o ? this.handleStickyCapturedSeries(e, o, i, s) : (this.tooltipUtil.isXoverlap(s) || a.globals.isBarHorizontal) && this.create(e, this, 0, s, i.ttItems)
                }
            }, {
                key: "handleStickyCapturedSeries",
                value: function (e, t, n, i) {
                    var a = this.w;
                    this.tConfig.shared || null !== a.globals.series[t][i] ? void 0 !== a.globals.series[t][i] ? this.tConfig.shared && this.tooltipUtil.isXoverlap(i) && this.tooltipUtil.isInitialSeriesSameLen() ? this.create(e, this, t, i, n.ttItems) : this.create(e, this, t, i, n.ttItems, !1) : this.tooltipUtil.isXoverlap(i) && this.create(e, this, 0, i, n.ttItems) : this.handleMouseOut(n)
                }
            }, {
                key: "deactivateHoverFilter",
                value: function () {
                    for (var e = this.w, t = new v(this.ctx), n = e.globals.dom.Paper.select(".apexcharts-bar-area"), i = 0; i < n.length; i++) t.pathMouseLeave(n[i])
                }
            }, {
                key: "handleMouseOut",
                value: function (e) {
                    var t = this.w,
                        n = this.getElXCrosshairs();
                    if (e.tooltipEl.classList.remove("apexcharts-active"), this.deactivateHoverFilter(), "bubble" !== t.config.chart.type && this.marker.resetPointsSize(), null !== n && n.classList.remove("apexcharts-active"), null !== this.ycrosshairs && this.ycrosshairs.classList.remove("apexcharts-active"), this.isXAxisTooltipEnabled && this.xaxisTooltip.classList.remove("apexcharts-active"), this.yaxisTooltips.length) {
                        null === this.yaxisTTEls && (this.yaxisTTEls = t.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxistooltip"));
                        for (var i = 0; i < this.yaxisTTEls.length; i++) this.yaxisTTEls[i].classList.remove("apexcharts-active")
                    }
                    t.config.legend.tooltipHoverFormatter && this.legendLabels.forEach((function (e) {
                        var t = e.getAttribute("data:default-text");
                        e.innerHTML = decodeURIComponent(t)
                    }))
                }
            }, {
                key: "markerClick",
                value: function (e, t, n) {
                    var i = this.w;
                    "function" == typeof i.config.chart.events.markerClick && i.config.chart.events.markerClick(e, this.ctx, {
                        seriesIndex: t,
                        dataPointIndex: n,
                        w: i
                    }), this.ctx.events.fireEvent("markerClick", [e, this.ctx, {
                        seriesIndex: t,
                        dataPointIndex: n,
                        w: i
                    }])
                }
            }, {
                key: "create",
                value: function (e, t, n, i, a) {
                    var r = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
                        s = this.w,
                        o = t;
                    "mouseup" === e.type && this.markerClick(e, n, i), null === r && (r = this.tConfig.shared);
                    var l = this.tooltipUtil.hasMarkers(),
                        c = this.tooltipUtil.getElBars();
                    if (s.config.legend.tooltipHoverFormatter) {
                        var u = s.config.legend.tooltipHoverFormatter,
                            d = Array.from(this.legendLabels);
                        d.forEach((function (e) {
                            var t = e.getAttribute("data:default-text");
                            e.innerHTML = decodeURIComponent(t)
                        }));
                        for (var h = 0; h < d.length; h++) {
                            var f = d[h],
                                p = parseInt(f.getAttribute("i"), 10),
                                m = decodeURIComponent(f.getAttribute("data:default-text")),
                                g = u(m, {
                                    seriesIndex: r ? p : n,
                                    dataPointIndex: i,
                                    w: s
                                });
                            if (r) f.innerHTML = s.globals.collapsedSeriesIndices.indexOf(p) < 0 ? g : m;
                            else if (f.innerHTML = p === n ? g : m, n === p) break
                        }
                    }
                    if (r) {
                        if (o.tooltipLabels.drawSeriesTexts({
                                ttItems: a,
                                i: n,
                                j: i,
                                shared: !this.showOnIntersect && this.tConfig.shared
                            }), l && (s.globals.markers.largestSize > 0 ? o.marker.enlargePoints(i) : o.tooltipPosition.moveDynamicPointsOnHover(i)), this.tooltipUtil.hasBars() && (this.barSeriesHeight = this.tooltipUtil.getBarsHeight(c), this.barSeriesHeight > 0)) {
                            var y = new v(this.ctx),
                                b = s.globals.dom.Paper.select(".apexcharts-bar-area[j='".concat(i, "']"));
                            this.deactivateHoverFilter(), this.tooltipPosition.moveStickyTooltipOverBars(i);
                            for (var x = 0; x < b.length; x++) y.pathMouseEnter(b[x])
                        }
                    } else o.tooltipLabels.drawSeriesTexts({
                        shared: !1,
                        ttItems: a,
                        i: n,
                        j: i
                    }), this.tooltipUtil.hasBars() && o.tooltipPosition.moveStickyTooltipOverBars(i), l && o.tooltipPosition.moveMarkers(n, i)
                }
            }]), e
        }(),
        ye = function (e) {
            o(a, e);
            var n = d(a);

            function a() {
                return i(this, a), n.apply(this, arguments)
            }
            return r(a, [{
                key: "draw",
                value: function (e, n) {
                    var i = this,
                        a = this.w;
                    this.graphics = new v(this.ctx), this.bar = new P(this.ctx, this.xyRatios);
                    var r = new x(this.ctx, a);
                    e = r.getLogSeries(e), this.yRatio = r.getLogYRatios(this.yRatio), this.barHelpers.initVariables(e), "100%" === a.config.chart.stackType && (e = a.globals.seriesPercent.slice()), this.series = e, this.totalItems = 0, this.prevY = [], this.prevX = [], this.prevYF = [], this.prevXF = [], this.prevYVal = [], this.prevXVal = [], this.xArrj = [], this.xArrjF = [], this.xArrjVal = [], this.yArrj = [], this.yArrjF = [], this.yArrjVal = [];
                    for (var s = 0; s < e.length; s++) e[s].length > 0 && (this.totalItems += e[s].length);
                    for (var o = this.graphics.group({
                            class: "apexcharts-bar-series apexcharts-plot-series"
                        }), l = 0, c = 0, u = function (r, s) {
                            var u = void 0,
                                d = void 0,
                                h = void 0,
                                f = void 0,
                                m = [],
                                g = [],
                                v = a.globals.comboCharts ? n[r] : r;
                            i.yRatio.length > 1 && (i.yaxisIndex = v), i.isReversed = a.config.yaxis[i.yaxisIndex] && a.config.yaxis[i.yaxisIndex].reversed;
                            var y = i.graphics.group({
                                class: "apexcharts-series",
                                seriesName: p.escapeString(a.globals.seriesNames[v]),
                                rel: r + 1,
                                "data:realIndex": v
                            });
                            i.ctx.series.addCollapsedClassToSeries(y, v);
                            var b = i.graphics.group({
                                    class: "apexcharts-datalabels",
                                    "data:realIndex": v
                                }),
                                x = 0,
                                _ = 0,
                                w = i.initialPositions(l, c, u, d, h, f);
                            c = w.y, x = w.barHeight, d = w.yDivision, f = w.zeroW, l = w.x, _ = w.barWidth, u = w.xDivision, h = w.zeroH, i.yArrj = [], i.yArrjF = [], i.yArrjVal = [], i.xArrj = [], i.xArrjF = [], i.xArrjVal = [], 1 === i.prevY.length && i.prevY[0].every((function (e) {
                                return isNaN(e)
                            })) && (i.prevY[0] = i.prevY[0].map((function (e) {
                                return h
                            })), i.prevYF[0] = i.prevYF[0].map((function (e) {
                                return 0
                            })));
                            for (var k = 0; k < a.globals.dataPoints; k++) {
                                var M = i.barHelpers.getStrokeWidth(r, k, v),
                                    L = {
                                        indexes: {
                                            i: r,
                                            j: k,
                                            realIndex: v,
                                            bc: s
                                        },
                                        strokeWidth: M,
                                        x: l,
                                        y: c,
                                        elSeries: y
                                    },
                                    S = null;
                                i.isHorizontal ? (S = i.drawStackedBarPaths(t(t({}, L), {}, {
                                    zeroW: f,
                                    barHeight: x,
                                    yDivision: d
                                })), _ = i.series[r][k] / i.invertedYRatio) : (S = i.drawStackedColumnPaths(t(t({}, L), {}, {
                                    xDivision: u,
                                    barWidth: _,
                                    zeroH: h
                                })), x = i.series[r][k] / i.yRatio[i.yaxisIndex]), c = S.y, l = S.x, m.push(l), g.push(c);
                                var A = i.barHelpers.getPathFillColor(e, r, k, v);
                                y = i.renderSeries({
                                    realIndex: v,
                                    pathFill: A,
                                    j: k,
                                    i: r,
                                    pathFrom: S.pathFrom,
                                    pathTo: S.pathTo,
                                    strokeWidth: M,
                                    elSeries: y,
                                    x: l,
                                    y: c,
                                    series: e,
                                    barHeight: x,
                                    barWidth: _,
                                    elDataLabelsWrap: b,
                                    type: "bar",
                                    visibleSeries: 0
                                })
                            }
                            a.globals.seriesXvalues[v] = m, a.globals.seriesYvalues[v] = g, i.prevY.push(i.yArrj), i.prevYF.push(i.yArrjF), i.prevYVal.push(i.yArrjVal), i.prevX.push(i.xArrj), i.prevXF.push(i.xArrjF), i.prevXVal.push(i.xArrjVal), o.add(y)
                        }, d = 0, h = 0; d < e.length; d++, h++) u(d, h);
                    return o
                }
            }, {
                key: "initialPositions",
                value: function (e, t, n, i, a, r) {
                    var s, o, l = this.w;
                    return this.isHorizontal ? (s = (s = i = l.globals.gridHeight / l.globals.dataPoints) * parseInt(l.config.plotOptions.bar.barHeight, 10) / 100, r = this.baseLineInvertedY + l.globals.padHorizontal + (this.isReversed ? l.globals.gridWidth : 0) - (this.isReversed ? 2 * this.baseLineInvertedY : 0), t = (i - s) / 2) : (o = n = l.globals.gridWidth / l.globals.dataPoints, o = l.globals.isXNumeric && l.globals.dataPoints > 1 ? (n = l.globals.minXDiff / this.xRatio) * parseInt(this.barOptions.columnWidth, 10) / 100 : o * parseInt(l.config.plotOptions.bar.columnWidth, 10) / 100, a = this.baseLineY[this.yaxisIndex] + (this.isReversed ? l.globals.gridHeight : 0) - (this.isReversed ? 2 * this.baseLineY[this.yaxisIndex] : 0), e = l.globals.padHorizontal + (n - o) / 2), {
                        x: e,
                        y: t,
                        yDivision: i,
                        xDivision: n,
                        barHeight: s,
                        barWidth: o,
                        zeroH: a,
                        zeroW: r
                    }
                }
            }, {
                key: "drawStackedBarPaths",
                value: function (e) {
                    for (var t, n = e.indexes, i = e.barHeight, a = e.strokeWidth, r = e.zeroW, s = e.x, o = e.y, l = e.yDivision, c = e.elSeries, u = this.w, d = o, h = n.i, f = n.j, p = 0, m = 0; m < this.prevXF.length; m++) p += this.prevXF[m][f];
                    if (h > 0) {
                        var g = r;
                        this.prevXVal[h - 1][f] < 0 ? g = this.series[h][f] >= 0 ? this.prevX[h - 1][f] + p - 2 * (this.isReversed ? p : 0) : this.prevX[h - 1][f] : this.prevXVal[h - 1][f] >= 0 && (g = this.series[h][f] >= 0 ? this.prevX[h - 1][f] : this.prevX[h - 1][f] - p + 2 * (this.isReversed ? p : 0)), t = g
                    } else t = r;
                    s = null === this.series[h][f] ? t : t + this.series[h][f] / this.invertedYRatio - 2 * (this.isReversed ? this.series[h][f] / this.invertedYRatio : 0);
                    var v = this.barHelpers.getBarpaths({
                        barYPosition: d,
                        barHeight: i,
                        x1: t,
                        x2: s,
                        strokeWidth: a,
                        series: this.series,
                        realIndex: n.realIndex,
                        i: h,
                        j: f,
                        w: u
                    });
                    return this.barHelpers.barBackground({
                        j: f,
                        i: h,
                        y1: d,
                        y2: i,
                        elSeries: c
                    }), o += l, {
                        pathTo: v.pathTo,
                        pathFrom: v.pathFrom,
                        x: s,
                        y: o
                    }
                }
            }, {
                key: "drawStackedColumnPaths",
                value: function (e) {
                    var t = e.indexes,
                        n = e.x,
                        i = e.y,
                        a = e.xDivision,
                        r = e.barWidth,
                        s = e.zeroH;
                    e.strokeWidth;
                    var o = e.elSeries,
                        l = this.w,
                        c = t.i,
                        u = t.j,
                        d = t.bc;
                    if (l.globals.isXNumeric) {
                        var h = l.globals.seriesX[c][u];
                        h || (h = 0), n = (h - l.globals.minX) / this.xRatio - r / 2
                    }
                    for (var f, p = n, m = 0, g = 0; g < this.prevYF.length; g++) m += isNaN(this.prevYF[g][u]) ? 0 : this.prevYF[g][u];
                    if (c > 0 && !l.globals.isXNumeric || c > 0 && l.globals.isXNumeric && l.globals.seriesX[c - 1][u] === l.globals.seriesX[c][u]) {
                        var v, y, b = Math.min(this.yRatio.length + 1, c + 1);
                        if (void 0 !== this.prevY[c - 1])
                            for (var x = 1; x < b; x++)
                                if (!isNaN(this.prevY[c - x][u])) {
                                    y = this.prevY[c - x][u];
                                    break
                                } for (var _ = 1; _ < b; _++) {
                            if (this.prevYVal[c - _][u] < 0) {
                                v = this.series[c][u] >= 0 ? y - m + 2 * (this.isReversed ? m : 0) : y;
                                break
                            }
                            if (this.prevYVal[c - _][u] >= 0) {
                                v = this.series[c][u] >= 0 ? y : y + m - 2 * (this.isReversed ? m : 0);
                                break
                            }
                        }
                        void 0 === v && (v = l.globals.gridHeight), f = this.prevYF[0].every((function (e) {
                            return 0 === e
                        })) && this.prevYF.slice(1, c).every((function (e) {
                            return e.every((function (e) {
                                return isNaN(e)
                            }))
                        })) ? l.globals.gridHeight - s : v
                    } else f = l.globals.gridHeight - s;
                    i = f - this.series[c][u] / this.yRatio[this.yaxisIndex] + 2 * (this.isReversed ? this.series[c][u] / this.yRatio[this.yaxisIndex] : 0);
                    var w = this.barHelpers.getColumnPaths({
                        barXPosition: p,
                        barWidth: r,
                        y1: f,
                        y2: i,
                        yRatio: this.yRatio[this.yaxisIndex],
                        strokeWidth: this.strokeWidth,
                        series: this.series,
                        realIndex: t.realIndex,
                        i: c,
                        j: u,
                        w: l
                    });
                    return this.barHelpers.barBackground({
                        bc: d,
                        j: u,
                        i: c,
                        x1: p,
                        x2: r,
                        elSeries: o
                    }), n += a, {
                        pathTo: w.pathTo,
                        pathFrom: w.pathFrom,
                        x: l.globals.isXNumeric ? n - a : n,
                        y: i
                    }
                }
            }]), a
        }(P),
        be = function (e) {
            o(a, e);
            var n = d(a);

            function a() {
                return i(this, a), n.apply(this, arguments)
            }
            return r(a, [{
                key: "draw",
                value: function (e, n) {
                    var i = this,
                        a = this.w,
                        r = new v(this.ctx),
                        s = new S(this.ctx);
                    this.candlestickOptions = this.w.config.plotOptions.candlestick, this.boxOptions = this.w.config.plotOptions.boxPlot, this.isHorizontal = a.config.plotOptions.bar.horizontal;
                    var o = new x(this.ctx, a);
                    e = o.getLogSeries(e), this.series = e, this.yRatio = o.getLogYRatios(this.yRatio), this.barHelpers.initVariables(e);
                    for (var l = r.group({
                            class: "apexcharts-".concat(a.config.chart.type, "-series apexcharts-plot-series")
                        }), c = function (o) {
                            i.isBoxPlot = "boxPlot" === a.config.chart.type || "boxPlot" === a.config.series[o].type;
                            var c, u, d, h, f, m, g = void 0,
                                v = void 0,
                                y = [],
                                b = [],
                                x = a.globals.comboCharts ? n[o] : o,
                                _ = r.group({
                                    class: "apexcharts-series",
                                    seriesName: p.escapeString(a.globals.seriesNames[x]),
                                    rel: o + 1,
                                    "data:realIndex": x
                                });
                            i.ctx.series.addCollapsedClassToSeries(_, x), e[o].length > 0 && (i.visibleI = i.visibleI + 1), i.yRatio.length > 1 && (i.yaxisIndex = x);
                            var w = i.barHelpers.initialPositions();
                            v = w.y, f = w.barHeight, u = w.yDivision, h = w.zeroW, g = w.x, m = w.barWidth, c = w.xDivision, d = w.zeroH, b.push(g + m / 2);
                            for (var k = r.group({
                                    class: "apexcharts-datalabels",
                                    "data:realIndex": x
                                }), M = function (n) {
                                    var r = i.barHelpers.getStrokeWidth(o, n, x),
                                        l = null,
                                        p = {
                                            indexes: {
                                                i: o,
                                                j: n,
                                                realIndex: x
                                            },
                                            x: g,
                                            y: v,
                                            strokeWidth: r,
                                            elSeries: _
                                        };
                                    l = i.isHorizontal ? i.drawHorizontalBoxPaths(t(t({}, p), {}, {
                                        yDivision: u,
                                        barHeight: f,
                                        zeroW: h
                                    })) : i.drawVerticalBoxPaths(t(t({}, p), {}, {
                                        xDivision: c,
                                        barWidth: m,
                                        zeroH: d
                                    })), v = l.y, g = l.x, n > 0 && b.push(g + m / 2), y.push(v), l.pathTo.forEach((function (t, c) {
                                        var u = !i.isBoxPlot && i.candlestickOptions.wick.useFillColor ? l.color[c] : a.globals.stroke.colors[o],
                                            d = s.fillPath({
                                                seriesNumber: x,
                                                dataPointIndex: n,
                                                color: l.color[c],
                                                value: e[o][n]
                                            });
                                        i.renderSeries({
                                            realIndex: x,
                                            pathFill: d,
                                            lineFill: u,
                                            j: n,
                                            i: o,
                                            pathFrom: l.pathFrom,
                                            pathTo: t,
                                            strokeWidth: r,
                                            elSeries: _,
                                            x: g,
                                            y: v,
                                            series: e,
                                            barHeight: f,
                                            barWidth: m,
                                            elDataLabelsWrap: k,
                                            visibleSeries: i.visibleI,
                                            type: a.config.chart.type
                                        })
                                    }))
                                }, L = 0; L < a.globals.dataPoints; L++) M(L);
                            a.globals.seriesXvalues[x] = b, a.globals.seriesYvalues[x] = y, l.add(_)
                        }, u = 0; u < e.length; u++) c(u);
                    return l
                }
            }, {
                key: "drawVerticalBoxPaths",
                value: function (e) {
                    var t = e.indexes,
                        n = e.x;
                    e.y;
                    var i = e.xDivision,
                        a = e.barWidth,
                        r = e.zeroH,
                        s = e.strokeWidth,
                        o = this.w,
                        l = new v(this.ctx),
                        c = t.i,
                        u = t.j,
                        d = !0,
                        h = o.config.plotOptions.candlestick.colors.upward,
                        f = o.config.plotOptions.candlestick.colors.downward,
                        p = "";
                    this.isBoxPlot && (p = [this.boxOptions.colors.lower, this.boxOptions.colors.upper]);
                    var m = this.yRatio[this.yaxisIndex],
                        g = t.realIndex,
                        y = this.getOHLCValue(g, u),
                        b = r,
                        x = r;
                    y.o > y.c && (d = !1);
                    var _ = Math.min(y.o, y.c),
                        w = Math.max(y.o, y.c),
                        k = y.m;
                    o.globals.isXNumeric && (n = (o.globals.seriesX[g][u] - o.globals.minX) / this.xRatio - a / 2);
                    var M = n + a * this.visibleI;
                    void 0 === this.series[c][u] || null === this.series[c][u] ? (_ = r, w = r) : (_ = r - _ / m, w = r - w / m, b = r - y.h / m, x = r - y.l / m, k = r - y.m / m);
                    var L = l.move(M, r),
                        S = l.move(M + a / 2, _);
                    return o.globals.previousPaths.length > 0 && (S = this.getPreviousPath(g, u, !0)), L = this.isBoxPlot ? [l.move(M, _) + l.line(M + a / 2, _) + l.line(M + a / 2, b) + l.line(M + a / 4, b) + l.line(M + a - a / 4, b) + l.line(M + a / 2, b) + l.line(M + a / 2, _) + l.line(M + a, _) + l.line(M + a, k) + l.line(M, k) + l.line(M, _ + s / 2), l.move(M, k) + l.line(M + a, k) + l.line(M + a, w) + l.line(M + a / 2, w) + l.line(M + a / 2, x) + l.line(M + a - a / 4, x) + l.line(M + a / 4, x) + l.line(M + a / 2, x) + l.line(M + a / 2, w) + l.line(M, w) + l.line(M, k) + "z"] : [l.move(M, w) + l.line(M + a / 2, w) + l.line(M + a / 2, b) + l.line(M + a / 2, w) + l.line(M + a, w) + l.line(M + a, _) + l.line(M + a / 2, _) + l.line(M + a / 2, x) + l.line(M + a / 2, _) + l.line(M, _) + l.line(M, w - s / 2)], S += l.move(M, _), o.globals.isXNumeric || (n += i), {
                        pathTo: L,
                        pathFrom: S,
                        x: n,
                        y: w,
                        barXPosition: M,
                        color: this.isBoxPlot ? p : d ? [h] : [f]
                    }
                }
            }, {
                key: "drawHorizontalBoxPaths",
                value: function (e) {
                    var t = e.indexes;
                    e.x;
                    var n = e.y,
                        i = e.yDivision,
                        a = e.barHeight,
                        r = e.zeroW,
                        s = e.strokeWidth,
                        o = this.w,
                        l = new v(this.ctx),
                        c = t.i,
                        u = t.j,
                        d = this.boxOptions.colors.lower;
                    this.isBoxPlot && (d = [this.boxOptions.colors.lower, this.boxOptions.colors.upper]);
                    var h = this.invertedYRatio,
                        f = t.realIndex,
                        p = this.getOHLCValue(f, u),
                        m = r,
                        g = r,
                        y = Math.min(p.o, p.c),
                        b = Math.max(p.o, p.c),
                        x = p.m;
                    o.globals.isXNumeric && (n = (o.globals.seriesX[f][u] - o.globals.minX) / this.invertedXRatio - a / 2);
                    var _ = n + a * this.visibleI;
                    void 0 === this.series[c][u] || null === this.series[c][u] ? (y = r, b = r) : (y = r + y / h, b = r + b / h, m = r + p.h / h, g = r + p.l / h, x = r + p.m / h);
                    var w = l.move(r, _),
                        k = l.move(y, _ + a / 2);
                    return o.globals.previousPaths.length > 0 && (k = this.getPreviousPath(f, u, !0)), w = [l.move(y, _) + l.line(y, _ + a / 2) + l.line(m, _ + a / 2) + l.line(m, _ + a / 2 - a / 4) + l.line(m, _ + a / 2 + a / 4) + l.line(m, _ + a / 2) + l.line(y, _ + a / 2) + l.line(y, _ + a) + l.line(x, _ + a) + l.line(x, _) + l.line(y + s / 2, _), l.move(x, _) + l.line(x, _ + a) + l.line(b, _ + a) + l.line(b, _ + a / 2) + l.line(g, _ + a / 2) + l.line(g, _ + a - a / 4) + l.line(g, _ + a / 4) + l.line(g, _ + a / 2) + l.line(b, _ + a / 2) + l.line(b, _) + l.line(x, _) + "z"], k += l.move(y, _), o.globals.isXNumeric || (n += i), {
                        pathTo: w,
                        pathFrom: k,
                        x: b,
                        y: n,
                        barYPosition: _,
                        color: d
                    }
                }
            }, {
                key: "getOHLCValue",
                value: function (e, t) {
                    var n = this.w;
                    return {
                        o: this.isBoxPlot ? n.globals.seriesCandleH[e][t] : n.globals.seriesCandleO[e][t],
                        h: this.isBoxPlot ? n.globals.seriesCandleO[e][t] : n.globals.seriesCandleH[e][t],
                        m: n.globals.seriesCandleM[e][t],
                        l: this.isBoxPlot ? n.globals.seriesCandleC[e][t] : n.globals.seriesCandleL[e][t],
                        c: this.isBoxPlot ? n.globals.seriesCandleL[e][t] : n.globals.seriesCandleC[e][t]
                    }
                }
            }]), a
        }(P),
        xe = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "checkColorRange",
                value: function () {
                    var e = this.w,
                        t = !1,
                        n = e.config.plotOptions[e.config.chart.type];
                    return n.colorScale.ranges.length > 0 && n.colorScale.ranges.map((function (e, n) {
                        e.from <= 0 && (t = !0)
                    })), t
                }
            }, {
                key: "getShadeColor",
                value: function (e, t, n, i) {
                    var a = this.w,
                        r = 1,
                        s = a.config.plotOptions[e].shadeIntensity,
                        o = this.determineColor(e, t, n);
                    a.globals.hasNegs || i ? r = a.config.plotOptions[e].reverseNegativeShade ? o.percent < 0 ? o.percent / 100 * (1.25 * s) : (1 - o.percent / 100) * (1.25 * s) : o.percent <= 0 ? 1 - (1 + o.percent / 100) * s : (1 - o.percent / 100) * s : (r = 1 - o.percent / 100, "treemap" === e && (r = (1 - o.percent / 100) * (1.25 * s)));
                    var l = o.color,
                        c = new p;
                    return a.config.plotOptions[e].enableShades && (l = "dark" === this.w.config.theme.mode ? p.hexToRgba(c.shadeColor(-1 * r, o.color), a.config.fill.opacity) : p.hexToRgba(c.shadeColor(r, o.color), a.config.fill.opacity)), {
                        color: l,
                        colorProps: o
                    }
                }
            }, {
                key: "determineColor",
                value: function (e, t, n) {
                    var i = this.w,
                        a = i.globals.series[t][n],
                        r = i.config.plotOptions[e],
                        s = r.colorScale.inverse ? n : t;
                    r.distributed && "treemap" === i.config.chart.type && (s = n);
                    var o = i.globals.colors[s],
                        l = null,
                        c = Math.min.apply(Math, h(i.globals.series[t])),
                        u = Math.max.apply(Math, h(i.globals.series[t]));
                    r.distributed || "heatmap" !== e || (c = i.globals.minY, u = i.globals.maxY), void 0 !== r.colorScale.min && (c = r.colorScale.min < i.globals.minY ? r.colorScale.min : i.globals.minY, u = r.colorScale.max > i.globals.maxY ? r.colorScale.max : i.globals.maxY);
                    var d = Math.abs(u) + Math.abs(c),
                        f = 100 * a / (0 === d ? d - 1e-6 : d);
                    return r.colorScale.ranges.length > 0 && r.colorScale.ranges.map((function (e, t) {
                        if (a >= e.from && a <= e.to) {
                            o = e.color, l = e.foreColor ? e.foreColor : null, c = e.from, u = e.to;
                            var n = Math.abs(u) + Math.abs(c);
                            f = 100 * a / (0 === n ? n - 1e-6 : n)
                        }
                    })), {
                        color: o,
                        foreColor: l,
                        percent: f
                    }
                }
            }, {
                key: "calculateDataLabels",
                value: function (e) {
                    var t = e.text,
                        n = e.x,
                        i = e.y,
                        a = e.i,
                        r = e.j,
                        s = e.colorProps,
                        o = e.fontSize,
                        l = this.w.config.dataLabels,
                        c = new v(this.ctx),
                        u = new C(this.ctx),
                        d = null;
                    if (l.enabled) {
                        d = c.group({
                            class: "apexcharts-data-labels"
                        });
                        var h = l.offsetX,
                            f = l.offsetY,
                            p = n + h,
                            m = i + parseFloat(l.style.fontSize) / 3 + f;
                        u.plotDataLabelsText({
                            x: p,
                            y: m,
                            text: t,
                            i: a,
                            j: r,
                            color: s.foreColor,
                            parent: d,
                            fontSize: o,
                            dataLabelsConfig: l
                        })
                    }
                    return d
                }
            }, {
                key: "addListeners",
                value: function (e) {
                    var t = new v(this.ctx);
                    e.node.addEventListener("mouseenter", t.pathMouseEnter.bind(this, e)), e.node.addEventListener("mouseleave", t.pathMouseLeave.bind(this, e)), e.node.addEventListener("mousedown", t.pathMouseDown.bind(this, e))
                }
            }]), e
        }(),
        _e = function () {
            function e(t, n) {
                i(this, e), this.ctx = t, this.w = t.w, this.xRatio = n.xRatio, this.yRatio = n.yRatio, this.dynamicAnim = this.w.config.chart.animations.dynamicAnimation, this.helpers = new xe(t), this.rectRadius = this.w.config.plotOptions.heatmap.radius, this.strokeWidth = this.w.config.stroke.show ? this.w.config.stroke.width : 0
            }
            return r(e, [{
                key: "draw",
                value: function (e) {
                    var t = this.w,
                        n = new v(this.ctx),
                        i = n.group({
                            class: "apexcharts-heatmap"
                        });
                    i.attr("clip-path", "url(#gridRectMask".concat(t.globals.cuid, ")"));
                    var a = t.globals.gridWidth / t.globals.dataPoints,
                        r = t.globals.gridHeight / t.globals.series.length,
                        s = 0,
                        o = !1;
                    this.negRange = this.helpers.checkColorRange();
                    var l = e.slice();
                    t.config.yaxis[0].reversed && (o = !0, l.reverse());
                    for (var c = o ? 0 : l.length - 1; o ? c < l.length : c >= 0; o ? c++ : c--) {
                        var u = n.group({
                            class: "apexcharts-series apexcharts-heatmap-series",
                            seriesName: p.escapeString(t.globals.seriesNames[c]),
                            rel: c + 1,
                            "data:realIndex": c
                        });
                        if (this.ctx.series.addCollapsedClassToSeries(u, c), t.config.chart.dropShadow.enabled) {
                            var d = t.config.chart.dropShadow;
                            new g(this.ctx).dropShadow(u, d, c)
                        }
                        for (var h = 0, f = t.config.plotOptions.heatmap.shadeIntensity, m = 0; m < l[c].length; m++) {
                            var y = this.helpers.getShadeColor(t.config.chart.type, c, m, this.negRange),
                                b = y.color,
                                x = y.colorProps;
                            "image" === t.config.fill.type && (b = new S(this.ctx).fillPath({
                                seriesNumber: c,
                                dataPointIndex: m,
                                opacity: t.globals.hasNegs ? x.percent < 0 ? 1 - (1 + x.percent / 100) : f + x.percent / 100 : x.percent / 100,
                                patternID: p.randomId(),
                                width: t.config.fill.image.width ? t.config.fill.image.width : a,
                                height: t.config.fill.image.height ? t.config.fill.image.height : r
                            }));
                            var _ = this.rectRadius,
                                w = n.drawRect(h, s, a, r, _);
                            if (w.attr({
                                    cx: h,
                                    cy: s
                                }), w.node.classList.add("apexcharts-heatmap-rect"), u.add(w), w.attr({
                                    fill: b,
                                    i: c,
                                    index: c,
                                    j: m,
                                    val: l[c][m],
                                    "stroke-width": this.strokeWidth,
                                    stroke: t.config.plotOptions.heatmap.useFillColorAsStroke ? b : t.globals.stroke.colors[0],
                                    color: b
                                }), this.helpers.addListeners(w), t.config.chart.animations.enabled && !t.globals.dataChanged) {
                                var k = 1;
                                t.globals.resized || (k = t.config.chart.animations.speed), this.animateHeatMap(w, h, s, a, r, k)
                            }
                            if (t.globals.dataChanged) {
                                var M = 1;
                                if (this.dynamicAnim.enabled && t.globals.shouldAnimate) {
                                    M = this.dynamicAnim.speed;
                                    var L = t.globals.previousPaths[c] && t.globals.previousPaths[c][m] && t.globals.previousPaths[c][m].color;
                                    L || (L = "rgba(255, 255, 255, 0)"), this.animateHeatColor(w, p.isColorHex(L) ? L : p.rgb2hex(L), p.isColorHex(b) ? b : p.rgb2hex(b), M)
                                }
                            }
                            var A = (0, t.config.dataLabels.formatter)(t.globals.series[c][m], {
                                    value: t.globals.series[c][m],
                                    seriesIndex: c,
                                    dataPointIndex: m,
                                    w: t
                                }),
                                T = this.helpers.calculateDataLabels({
                                    text: A,
                                    x: h + a / 2,
                                    y: s + r / 2,
                                    i: c,
                                    j: m,
                                    colorProps: x,
                                    series: l
                                });
                            null !== T && u.add(T), h += a
                        }
                        s += r, i.add(u)
                    }
                    var C = t.globals.yAxisScale[0].result.slice();
                    t.config.yaxis[0].reversed ? C.unshift("") : C.push(""), t.globals.yAxisScale[0].result = C;
                    var D = t.globals.gridHeight / t.globals.series.length;
                    return t.config.yaxis[0].labels.offsetY = -D / 2, i
                }
            }, {
                key: "animateHeatMap",
                value: function (e, t, n, i, a, r) {
                    var s = new m(this.ctx);
                    s.animateRect(e, {
                        x: t + i / 2,
                        y: n + a / 2,
                        width: 0,
                        height: 0
                    }, {
                        x: t,
                        y: n,
                        width: i,
                        height: a
                    }, r, (function () {
                        s.animationCompleted(e)
                    }))
                }
            }, {
                key: "animateHeatColor",
                value: function (e, t, n, i) {
                    e.attr({
                        fill: t
                    }).animate(i).attr({
                        fill: n
                    })
                }
            }]), e
        }(),
        we = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "drawYAxisTexts",
                value: function (e, t, n, i) {
                    var a = this.w,
                        r = a.config.yaxis[0],
                        s = a.globals.yLabelFormatters[0];
                    return new v(this.ctx).drawText({
                        x: e + r.labels.offsetX,
                        y: t + r.labels.offsetY,
                        text: s(i, n),
                        textAnchor: "middle",
                        fontSize: r.labels.style.fontSize,
                        fontFamily: r.labels.style.fontFamily,
                        foreColor: Array.isArray(r.labels.style.colors) ? r.labels.style.colors[n] : r.labels.style.colors
                    })
                }
            }]), e
        }(),
        ke = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w;
                var n = this.w;
                this.chartType = this.w.config.chart.type, this.initialAnim = this.w.config.chart.animations.enabled, this.dynamicAnim = this.initialAnim && this.w.config.chart.animations.dynamicAnimation.enabled, this.animBeginArr = [0], this.animDur = 0, this.donutDataLabels = this.w.config.plotOptions.pie.donut.labels, this.lineColorArr = void 0 !== n.globals.stroke.colors ? n.globals.stroke.colors : n.globals.colors, this.defaultSize = Math.min(n.globals.gridWidth, n.globals.gridHeight), this.centerY = this.defaultSize / 2, this.centerX = n.globals.gridWidth / 2, "radialBar" === n.config.chart.type ? this.fullAngle = 360 : this.fullAngle = Math.abs(n.config.plotOptions.pie.endAngle - n.config.plotOptions.pie.startAngle), this.initialAngle = n.config.plotOptions.pie.startAngle % this.fullAngle, n.globals.radialSize = this.defaultSize / 2.05 - n.config.stroke.width - (n.config.chart.sparkline.enabled ? 0 : n.config.chart.dropShadow.blur), this.donutSize = n.globals.radialSize * parseInt(n.config.plotOptions.pie.donut.size, 10) / 100, this.maxY = 0, this.sliceLabels = [], this.sliceSizes = [], this.prevSectorAngleArr = []
            }
            return r(e, [{
                key: "draw",
                value: function (e) {
                    var t = this,
                        n = this.w,
                        i = new v(this.ctx);
                    if (this.ret = i.group({
                            class: "apexcharts-pie"
                        }), n.globals.noData) return this.ret;
                    for (var a = 0, r = 0; r < e.length; r++) a += p.negToZero(e[r]);
                    var s = [],
                        o = i.group();
                    0 === a && (a = 1e-5), e.forEach((function (e) {
                        t.maxY = Math.max(t.maxY, e)
                    })), n.config.yaxis[0].max && (this.maxY = n.config.yaxis[0].max), "back" === n.config.grid.position && "polarArea" === this.chartType && this.drawPolarElements(this.ret);
                    for (var l = 0; l < e.length; l++) {
                        var c = this.fullAngle * p.negToZero(e[l]) / a;
                        s.push(c), "polarArea" === this.chartType ? (s[l] = this.fullAngle / e.length, this.sliceSizes.push(n.globals.radialSize * e[l] / this.maxY)) : this.sliceSizes.push(n.globals.radialSize)
                    }
                    if (n.globals.dataChanged) {
                        for (var u, d = 0, h = 0; h < n.globals.previousPaths.length; h++) d += p.negToZero(n.globals.previousPaths[h]);
                        for (var f = 0; f < n.globals.previousPaths.length; f++) u = this.fullAngle * p.negToZero(n.globals.previousPaths[f]) / d, this.prevSectorAngleArr.push(u)
                    }
                    this.donutSize < 0 && (this.donutSize = 0);
                    var m = n.config.plotOptions.pie.customScale,
                        g = n.globals.gridWidth / 2,
                        y = n.globals.gridHeight / 2,
                        b = g - n.globals.gridWidth / 2 * m,
                        x = y - n.globals.gridHeight / 2 * m;
                    if ("donut" === this.chartType) {
                        var _ = i.drawCircle(this.donutSize);
                        _.attr({
                            cx: this.centerX,
                            cy: this.centerY,
                            fill: n.config.plotOptions.pie.donut.background ? n.config.plotOptions.pie.donut.background : "transparent"
                        }), o.add(_)
                    }
                    var w = this.drawArcs(s, e);
                    if (this.sliceLabels.forEach((function (e) {
                            w.add(e)
                        })), o.attr({
                            transform: "translate(".concat(b, ", ").concat(x, ") scale(").concat(m, ")")
                        }), o.add(w), this.ret.add(o), this.donutDataLabels.show) {
                        var k = this.renderInnerDataLabels(this.donutDataLabels, {
                            hollowSize: this.donutSize,
                            centerX: this.centerX,
                            centerY: this.centerY,
                            opacity: this.donutDataLabels.show,
                            translateX: b,
                            translateY: x
                        });
                        this.ret.add(k)
                    }
                    return "front" === n.config.grid.position && "polarArea" === this.chartType && this.drawPolarElements(this.ret), this.ret
                }
            }, {
                key: "drawArcs",
                value: function (e, t) {
                    var n = this.w,
                        i = new g(this.ctx),
                        a = new v(this.ctx),
                        r = new S(this.ctx),
                        s = a.group({
                            class: "apexcharts-slices"
                        }),
                        o = this.initialAngle,
                        l = this.initialAngle,
                        c = this.initialAngle,
                        u = this.initialAngle;
                    this.strokeWidth = n.config.stroke.show ? n.config.stroke.width : 0;
                    for (var d = 0; d < e.length; d++) {
                        var h = a.group({
                            class: "apexcharts-series apexcharts-pie-series",
                            seriesName: p.escapeString(n.globals.seriesNames[d]),
                            rel: d + 1,
                            "data:realIndex": d
                        });
                        s.add(h), l = u, c = (o = c) + e[d], u = l + this.prevSectorAngleArr[d];
                        var f = c < o ? this.fullAngle + c - o : c - o,
                            m = r.fillPath({
                                seriesNumber: d,
                                size: this.sliceSizes[d],
                                value: t[d]
                            }),
                            y = this.getChangedPath(l, u),
                            b = a.drawPath({
                                d: y,
                                stroke: Array.isArray(this.lineColorArr) ? this.lineColorArr[d] : this.lineColorArr,
                                strokeWidth: 0,
                                fill: m,
                                fillOpacity: n.config.fill.opacity,
                                classes: "apexcharts-pie-area apexcharts-".concat(this.chartType.toLowerCase(), "-slice-").concat(d)
                            });
                        if (b.attr({
                                index: 0,
                                j: d
                            }), i.setSelectionFilter(b, 0, d), n.config.chart.dropShadow.enabled) {
                            var x = n.config.chart.dropShadow;
                            i.dropShadow(b, x, d)
                        }
                        this.addListeners(b, this.donutDataLabels), v.setAttrs(b.node, {
                            "data:angle": f,
                            "data:startAngle": o,
                            "data:strokeWidth": this.strokeWidth,
                            "data:value": t[d]
                        });
                        var _ = {
                            x: 0,
                            y: 0
                        };
                        "pie" === this.chartType || "polarArea" === this.chartType ? _ = p.polarToCartesian(this.centerX, this.centerY, n.globals.radialSize / 1.25 + n.config.plotOptions.pie.dataLabels.offset, (o + f / 2) % this.fullAngle) : "donut" === this.chartType && (_ = p.polarToCartesian(this.centerX, this.centerY, (n.globals.radialSize + this.donutSize) / 2 + n.config.plotOptions.pie.dataLabels.offset, (o + f / 2) % this.fullAngle)), h.add(b);
                        var w = 0;
                        if (!this.initialAnim || n.globals.resized || n.globals.dataChanged ? this.animBeginArr.push(0) : (0 == (w = f / this.fullAngle * n.config.chart.animations.speed) && (w = 1), this.animDur = w + this.animDur, this.animBeginArr.push(this.animDur)), this.dynamicAnim && n.globals.dataChanged ? this.animatePaths(b, {
                                size: this.sliceSizes[d],
                                endAngle: c,
                                startAngle: o,
                                prevStartAngle: l,
                                prevEndAngle: u,
                                animateStartingPos: !0,
                                i: d,
                                animBeginArr: this.animBeginArr,
                                shouldSetPrevPaths: !0,
                                dur: n.config.chart.animations.dynamicAnimation.speed
                            }) : this.animatePaths(b, {
                                size: this.sliceSizes[d],
                                endAngle: c,
                                startAngle: o,
                                i: d,
                                totalItems: e.length - 1,
                                animBeginArr: this.animBeginArr,
                                dur: w
                            }), n.config.plotOptions.pie.expandOnClick && "polarArea" !== this.chartType && b.click(this.pieClicked.bind(this, d)), void 0 !== n.globals.selectedDataPoints[0] && n.globals.selectedDataPoints[0].indexOf(d) > -1 && this.pieClicked(d), n.config.dataLabels.enabled) {
                            var k = _.x,
                                M = _.y,
                                L = 100 * f / this.fullAngle + "%";
                            if (0 !== f && n.config.plotOptions.pie.dataLabels.minAngleToShowLabel < e[d]) {
                                var A = n.config.dataLabels.formatter;
                                void 0 !== A && (L = A(n.globals.seriesPercent[d][0], {
                                    seriesIndex: d,
                                    w: n
                                }));
                                var T = n.globals.dataLabels.style.colors[d],
                                    C = a.group({
                                        class: "apexcharts-datalabels"
                                    }),
                                    D = a.drawText({
                                        x: k,
                                        y: M,
                                        text: L,
                                        textAnchor: "middle",
                                        fontSize: n.config.dataLabels.style.fontSize,
                                        fontFamily: n.config.dataLabels.style.fontFamily,
                                        fontWeight: n.config.dataLabels.style.fontWeight,
                                        foreColor: T
                                    });
                                if (C.add(D), n.config.dataLabels.dropShadow.enabled) {
                                    var E = n.config.dataLabels.dropShadow;
                                    i.dropShadow(D, E)
                                }
                                D.node.classList.add("apexcharts-pie-label"), n.config.chart.animations.animate && !1 === n.globals.resized && (D.node.classList.add("apexcharts-pie-label-delay"), D.node.style.animationDelay = n.config.chart.animations.speed / 940 + "s"), this.sliceLabels.push(C)
                            }
                        }
                    }
                    return s
                }
            }, {
                key: "addListeners",
                value: function (e, t) {
                    var n = new v(this.ctx);
                    e.node.addEventListener("mouseenter", n.pathMouseEnter.bind(this, e)), e.node.addEventListener("mouseleave", n.pathMouseLeave.bind(this, e)), e.node.addEventListener("mouseleave", this.revertDataLabelsInner.bind(this, e.node, t)), e.node.addEventListener("mousedown", n.pathMouseDown.bind(this, e)), this.donutDataLabels.total.showAlways || (e.node.addEventListener("mouseenter", this.printDataLabelsInner.bind(this, e.node, t)), e.node.addEventListener("mousedown", this.printDataLabelsInner.bind(this, e.node, t)))
                }
            }, {
                key: "animatePaths",
                value: function (e, t) {
                    var n = this.w,
                        i = t.endAngle < t.startAngle ? this.fullAngle + t.endAngle - t.startAngle : t.endAngle - t.startAngle,
                        a = i,
                        r = t.startAngle,
                        s = t.startAngle;
                    void 0 !== t.prevStartAngle && void 0 !== t.prevEndAngle && (r = t.prevEndAngle, a = t.prevEndAngle < t.prevStartAngle ? this.fullAngle + t.prevEndAngle - t.prevStartAngle : t.prevEndAngle - t.prevStartAngle), t.i === n.config.series.length - 1 && (i + s > this.fullAngle ? t.endAngle = t.endAngle - (i + s) : i + s < this.fullAngle && (t.endAngle = t.endAngle + (this.fullAngle - (i + s)))), i === this.fullAngle && (i = this.fullAngle - .01), this.animateArc(e, r, s, i, a, t)
                }
            }, {
                key: "animateArc",
                value: function (e, t, n, i, a, r) {
                    var s, o = this,
                        l = this.w,
                        c = new m(this.ctx),
                        u = r.size;
                    (isNaN(t) || isNaN(a)) && (t = n, a = i, r.dur = 0);
                    var d = i,
                        h = n,
                        f = t < n ? this.fullAngle + t - n : t - n;
                    l.globals.dataChanged && r.shouldSetPrevPaths && r.prevEndAngle && (s = o.getPiePath({
                        me: o,
                        startAngle: r.prevStartAngle,
                        angle: r.prevEndAngle < r.prevStartAngle ? this.fullAngle + r.prevEndAngle - r.prevStartAngle : r.prevEndAngle - r.prevStartAngle,
                        size: u
                    }), e.attr({
                        d: s
                    })), 0 !== r.dur ? e.animate(r.dur, l.globals.easing, r.animBeginArr[r.i]).afterAll((function () {
                        "pie" !== o.chartType && "donut" !== o.chartType && "polarArea" !== o.chartType || this.animate(l.config.chart.animations.dynamicAnimation.speed).attr({
                            "stroke-width": o.strokeWidth
                        }), r.i === l.config.series.length - 1 && c.animationCompleted(e)
                    })).during((function (l) {
                        d = f + (i - f) * l, r.animateStartingPos && (d = a + (i - a) * l, h = t - a + (n - (t - a)) * l), s = o.getPiePath({
                            me: o,
                            startAngle: h,
                            angle: d,
                            size: u
                        }), e.node.setAttribute("data:pathOrig", s), e.attr({
                            d: s
                        })
                    })) : (s = o.getPiePath({
                        me: o,
                        startAngle: h,
                        angle: i,
                        size: u
                    }), r.isTrack || (l.globals.animationEnded = !0), e.node.setAttribute("data:pathOrig", s), e.attr({
                        d: s,
                        "stroke-width": o.strokeWidth
                    }))
                }
            }, {
                key: "pieClicked",
                value: function (e) {
                    var t, n = this.w,
                        i = this,
                        a = i.sliceSizes[e] + (n.config.plotOptions.pie.expandOnClick ? 4 : 0),
                        r = n.globals.dom.Paper.select(".apexcharts-".concat(i.chartType.toLowerCase(), "-slice-").concat(e)).members[0];
                    if ("true" !== r.attr("data:pieClicked")) {
                        var s = n.globals.dom.baseEl.getElementsByClassName("apexcharts-pie-area");
                        Array.prototype.forEach.call(s, (function (e) {
                            e.setAttribute("data:pieClicked", "false");
                            var t = e.getAttribute("data:pathOrig");
                            e.setAttribute("d", t)
                        })), r.attr("data:pieClicked", "true");
                        var o = parseInt(r.attr("data:startAngle"), 10),
                            l = parseInt(r.attr("data:angle"), 10);
                        t = i.getPiePath({
                            me: i,
                            startAngle: o,
                            angle: l,
                            size: a
                        }), 360 !== l && r.plot(t)
                    } else {
                        r.attr({
                            "data:pieClicked": "false"
                        }), this.revertDataLabelsInner(r.node, this.donutDataLabels);
                        var c = r.attr("data:pathOrig");
                        r.attr({
                            d: c
                        })
                    }
                }
            }, {
                key: "getChangedPath",
                value: function (e, t) {
                    var n = "";
                    return this.dynamicAnim && this.w.globals.dataChanged && (n = this.getPiePath({
                        me: this,
                        startAngle: e,
                        angle: t - e,
                        size: this.size
                    })), n
                }
            }, {
                key: "getPiePath",
                value: function (e) {
                    var t = e.me,
                        n = e.startAngle,
                        i = e.angle,
                        a = e.size,
                        r = n,
                        s = Math.PI * (r - 90) / 180,
                        o = i + n;
                    Math.ceil(o) >= this.fullAngle + this.w.config.plotOptions.pie.startAngle % this.fullAngle && (o = this.fullAngle + this.w.config.plotOptions.pie.startAngle % this.fullAngle - .01), Math.ceil(o) > this.fullAngle && (o -= this.fullAngle);
                    var l = Math.PI * (o - 90) / 180,
                        c = t.centerX + a * Math.cos(s),
                        u = t.centerY + a * Math.sin(s),
                        d = t.centerX + a * Math.cos(l),
                        h = t.centerY + a * Math.sin(l),
                        f = p.polarToCartesian(t.centerX, t.centerY, t.donutSize, o),
                        m = p.polarToCartesian(t.centerX, t.centerY, t.donutSize, r),
                        g = i > 180 ? 1 : 0,
                        v = ["M", c, u, "A", a, a, 0, g, 1, d, h];
                    return "donut" === t.chartType ? [].concat(v, ["L", f.x, f.y, "A", t.donutSize, t.donutSize, 0, g, 0, m.x, m.y, "L", c, u, "z"]).join(" ") : "pie" === t.chartType || "polarArea" === t.chartType ? [].concat(v, ["L", t.centerX, t.centerY, "L", c, u]).join(" ") : [].concat(v).join(" ")
                }
            }, {
                key: "drawPolarElements",
                value: function (e) {
                    var t = this.w,
                        n = new X(this.ctx),
                        i = new v(this.ctx),
                        a = new we(this.ctx),
                        r = i.group(),
                        s = i.group(),
                        o = n.niceScale(0, Math.ceil(this.maxY), t.config.yaxis[0].tickAmount, 0, !0),
                        l = o.result.reverse(),
                        c = o.result.length;
                    this.maxY = o.niceMax;
                    for (var u = t.globals.radialSize, d = u / (c - 1), h = 0; h < c - 1; h++) {
                        var f = i.drawCircle(u);
                        if (f.attr({
                                cx: this.centerX,
                                cy: this.centerY,
                                fill: "none",
                                "stroke-width": t.config.plotOptions.polarArea.rings.strokeWidth,
                                stroke: t.config.plotOptions.polarArea.rings.strokeColor
                            }), t.config.yaxis[0].show) {
                            var p = a.drawYAxisTexts(this.centerX, this.centerY - u + parseInt(t.config.yaxis[0].labels.style.fontSize, 10) / 2, h, l[h]);
                            s.add(p)
                        }
                        r.add(f), u -= d
                    }
                    this.drawSpokes(e), e.add(r), e.add(s)
                }
            }, {
                key: "renderInnerDataLabels",
                value: function (e, t) {
                    var n = this.w,
                        i = new v(this.ctx),
                        a = i.group({
                            class: "apexcharts-datalabels-group",
                            transform: "translate(".concat(t.translateX ? t.translateX : 0, ", ").concat(t.translateY ? t.translateY : 0, ") scale(").concat(n.config.plotOptions.pie.customScale, ")")
                        }),
                        r = e.total.show;
                    a.node.style.opacity = t.opacity;
                    var s, o, l = t.centerX,
                        c = t.centerY;
                    s = void 0 === e.name.color ? n.globals.colors[0] : e.name.color;
                    var u = e.name.fontSize,
                        d = e.name.fontFamily,
                        h = e.name.fontWeight;
                    o = void 0 === e.value.color ? n.config.chart.foreColor : e.value.color;
                    var f = e.value.formatter,
                        p = "",
                        m = "";
                    if (r ? (s = e.total.color, u = e.total.fontSize, d = e.total.fontFamily, h = e.total.fontWeight, m = e.total.label, p = e.total.formatter(n)) : 1 === n.globals.series.length && (p = f(n.globals.series[0], n), m = n.globals.seriesNames[0]), m && (m = e.name.formatter(m, e.total.show, n)), e.name.show) {
                        var g = i.drawText({
                            x: l,
                            y: c + parseFloat(e.name.offsetY),
                            text: m,
                            textAnchor: "middle",
                            foreColor: s,
                            fontSize: u,
                            fontWeight: h,
                            fontFamily: d
                        });
                        g.node.classList.add("apexcharts-datalabel-label"), a.add(g)
                    }
                    if (e.value.show) {
                        var y = e.name.show ? parseFloat(e.value.offsetY) + 16 : e.value.offsetY,
                            b = i.drawText({
                                x: l,
                                y: c + y,
                                text: p,
                                textAnchor: "middle",
                                foreColor: o,
                                fontWeight: e.value.fontWeight,
                                fontSize: e.value.fontSize,
                                fontFamily: e.value.fontFamily
                            });
                        b.node.classList.add("apexcharts-datalabel-value"), a.add(b)
                    }
                    return a
                }
            }, {
                key: "printInnerLabels",
                value: function (e, t, n, i) {
                    var a, r = this.w;
                    i ? a = void 0 === e.name.color ? r.globals.colors[parseInt(i.parentNode.getAttribute("rel"), 10) - 1] : e.name.color : r.globals.series.length > 1 && e.total.show && (a = e.total.color);
                    var s = r.globals.dom.baseEl.querySelector(".apexcharts-datalabel-label"),
                        o = r.globals.dom.baseEl.querySelector(".apexcharts-datalabel-value");
                    n = (0, e.value.formatter)(n, r), i || "function" != typeof e.total.formatter || (n = e.total.formatter(r));
                    var l = t === e.total.label;
                    t = e.name.formatter(t, l, r), null !== s && (s.textContent = t), null !== o && (o.textContent = n), null !== s && (s.style.fill = a)
                }
            }, {
                key: "printDataLabelsInner",
                value: function (e, t) {
                    var n = this.w,
                        i = e.getAttribute("data:value"),
                        a = n.globals.seriesNames[parseInt(e.parentNode.getAttribute("rel"), 10) - 1];
                    n.globals.series.length > 1 && this.printInnerLabels(t, a, i, e);
                    var r = n.globals.dom.baseEl.querySelector(".apexcharts-datalabels-group");
                    null !== r && (r.style.opacity = 1)
                }
            }, {
                key: "drawSpokes",
                value: function (e) {
                    var t = this,
                        n = this.w,
                        i = new v(this.ctx),
                        a = n.config.plotOptions.polarArea.spokes;
                    if (0 !== a.strokeWidth) {
                        for (var r = [], s = 360 / n.globals.series.length, o = 0; o < n.globals.series.length; o++) r.push(p.polarToCartesian(this.centerX, this.centerY, n.globals.radialSize, n.config.plotOptions.pie.startAngle + s * o));
                        r.forEach((function (n, r) {
                            var s = i.drawLine(n.x, n.y, t.centerX, t.centerY, Array.isArray(a.connectorColors) ? a.connectorColors[r] : a.connectorColors);
                            e.add(s)
                        }))
                    }
                }
            }, {
                key: "revertDataLabelsInner",
                value: function (e, t, n) {
                    var i = this,
                        a = this.w,
                        r = a.globals.dom.baseEl.querySelector(".apexcharts-datalabels-group"),
                        s = !1,
                        o = a.globals.dom.baseEl.getElementsByClassName("apexcharts-pie-area"),
                        l = function (e) {
                            var n = e.makeSliceOut,
                                a = e.printLabel;
                            Array.prototype.forEach.call(o, (function (e) {
                                "true" === e.getAttribute("data:pieClicked") && (n && (s = !0), a && i.printDataLabelsInner(e, t))
                            }))
                        };
                    if (l({
                            makeSliceOut: !0,
                            printLabel: !1
                        }), t.total.show && a.globals.series.length > 1) s && !t.total.showAlways ? l({
                        makeSliceOut: !1,
                        printLabel: !0
                    }) : this.printInnerLabels(t, t.total.label, t.total.formatter(a));
                    else if (l({
                            makeSliceOut: !1,
                            printLabel: !0
                        }), !s)
                        if (a.globals.selectedDataPoints.length && a.globals.series.length > 1)
                            if (a.globals.selectedDataPoints[0].length > 0) {
                                var c = a.globals.selectedDataPoints[0],
                                    u = a.globals.dom.baseEl.querySelector(".apexcharts-".concat(this.chartType.toLowerCase(), "-slice-").concat(c));
                                this.printDataLabelsInner(u, t)
                            } else r && a.globals.selectedDataPoints.length && 0 === a.globals.selectedDataPoints[0].length && (r.style.opacity = 0);
                    else r && a.globals.series.length > 1 && (r.style.opacity = 0)
                }
            }]), e
        }(),
        Me = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w, this.chartType = this.w.config.chart.type, this.initialAnim = this.w.config.chart.animations.enabled, this.dynamicAnim = this.initialAnim && this.w.config.chart.animations.dynamicAnimation.enabled, this.animDur = 0;
                var n = this.w;
                this.graphics = new v(this.ctx), this.lineColorArr = void 0 !== n.globals.stroke.colors ? n.globals.stroke.colors : n.globals.colors, this.defaultSize = n.globals.svgHeight < n.globals.svgWidth ? n.globals.gridHeight + 1.5 * n.globals.goldenPadding : n.globals.gridWidth, this.isLog = n.config.yaxis[0].logarithmic, this.coreUtils = new x(this.ctx), this.maxValue = this.isLog ? this.coreUtils.getLogVal(n.globals.maxY, 0) : n.globals.maxY, this.minValue = this.isLog ? this.coreUtils.getLogVal(this.w.globals.minY, 0) : n.globals.minY, this.polygons = n.config.plotOptions.radar.polygons, this.strokeWidth = n.config.stroke.show ? n.config.stroke.width : 0, this.size = this.defaultSize / 2.1 - this.strokeWidth - n.config.chart.dropShadow.blur, n.config.xaxis.labels.show && (this.size = this.size - n.globals.xAxisLabelsWidth / 1.75), void 0 !== n.config.plotOptions.radar.size && (this.size = n.config.plotOptions.radar.size), this.dataRadiusOfPercent = [], this.dataRadius = [], this.angleArr = [], this.yaxisLabelsTextsPos = []
            }
            return r(e, [{
                key: "draw",
                value: function (e) {
                    var n = this,
                        i = this.w,
                        a = new S(this.ctx),
                        r = [],
                        s = new C(this.ctx);
                    e.length && (this.dataPointsLen = e[i.globals.maxValsInArrayIndex].length), this.disAngle = 2 * Math.PI / this.dataPointsLen;
                    var o = i.globals.gridWidth / 2,
                        l = i.globals.gridHeight / 2,
                        c = o + i.config.plotOptions.radar.offsetX,
                        u = l + i.config.plotOptions.radar.offsetY,
                        d = this.graphics.group({
                            class: "apexcharts-radar-series apexcharts-plot-series",
                            transform: "translate(".concat(c || 0, ", ").concat(u || 0, ")")
                        }),
                        h = [],
                        f = null,
                        m = null;
                    if (this.yaxisLabels = this.graphics.group({
                            class: "apexcharts-yaxis"
                        }), e.forEach((function (e, o) {
                            var l = e.length === i.globals.dataPoints,
                                c = n.graphics.group().attr({
                                    class: "apexcharts-series",
                                    "data:longestSeries": l,
                                    seriesName: p.escapeString(i.globals.seriesNames[o]),
                                    rel: o + 1,
                                    "data:realIndex": o
                                });
                            n.dataRadiusOfPercent[o] = [], n.dataRadius[o] = [], n.angleArr[o] = [], e.forEach((function (e, t) {
                                var i = Math.abs(n.maxValue - n.minValue);
                                e += Math.abs(n.minValue), n.isLog && (e = n.coreUtils.getLogVal(e, 0)), n.dataRadiusOfPercent[o][t] = e / i, n.dataRadius[o][t] = n.dataRadiusOfPercent[o][t] * n.size, n.angleArr[o][t] = t * n.disAngle
                            })), h = n.getDataPointsPos(n.dataRadius[o], n.angleArr[o]);
                            var u = n.createPaths(h, {
                                x: 0,
                                y: 0
                            });
                            f = n.graphics.group({
                                class: "apexcharts-series-markers-wrap apexcharts-element-hidden"
                            }), m = n.graphics.group({
                                class: "apexcharts-datalabels",
                                "data:realIndex": o
                            }), i.globals.delayedElements.push({
                                el: f.node,
                                index: o
                            });
                            var d = {
                                    i: o,
                                    realIndex: o,
                                    animationDelay: o,
                                    initialSpeed: i.config.chart.animations.speed,
                                    dataChangeSpeed: i.config.chart.animations.dynamicAnimation.speed,
                                    className: "apexcharts-radar",
                                    shouldClipToGrid: !1,
                                    bindEventsOnPaths: !1,
                                    stroke: i.globals.stroke.colors[o],
                                    strokeLineCap: i.config.stroke.lineCap
                                },
                                v = null;
                            i.globals.previousPaths.length > 0 && (v = n.getPreviousPath(o));
                            for (var y = 0; y < u.linePathsTo.length; y++) {
                                var b = n.graphics.renderPaths(t(t({}, d), {}, {
                                    pathFrom: null === v ? u.linePathsFrom[y] : v,
                                    pathTo: u.linePathsTo[y],
                                    strokeWidth: Array.isArray(n.strokeWidth) ? n.strokeWidth[o] : n.strokeWidth,
                                    fill: "none",
                                    drawShadow: !1
                                }));
                                c.add(b);
                                var x = a.fillPath({
                                        seriesNumber: o
                                    }),
                                    _ = n.graphics.renderPaths(t(t({}, d), {}, {
                                        pathFrom: null === v ? u.areaPathsFrom[y] : v,
                                        pathTo: u.areaPathsTo[y],
                                        strokeWidth: 0,
                                        fill: x,
                                        drawShadow: !1
                                    }));
                                if (i.config.chart.dropShadow.enabled) {
                                    var w = new g(n.ctx),
                                        k = i.config.chart.dropShadow;
                                    w.dropShadow(_, Object.assign({}, k, {
                                        noUserSpaceOnUse: !0
                                    }), o)
                                }
                                c.add(_)
                            }
                            e.forEach((function (e, a) {
                                var r = new A(n.ctx).getMarkerConfig({
                                        cssClass: "apexcharts-marker",
                                        seriesIndex: o,
                                        dataPointIndex: a
                                    }),
                                    l = n.graphics.drawMarker(h[a].x, h[a].y, r);
                                l.attr("rel", a), l.attr("j", a), l.attr("index", o), l.node.setAttribute("default-marker-size", r.pSize);
                                var u = n.graphics.group({
                                    class: "apexcharts-series-markers"
                                });
                                u && u.add(l), f.add(u), c.add(f);
                                var d = i.config.dataLabels;
                                if (d.enabled) {
                                    var p = d.formatter(i.globals.series[o][a], {
                                        seriesIndex: o,
                                        dataPointIndex: a,
                                        w: i
                                    });
                                    s.plotDataLabelsText({
                                        x: h[a].x,
                                        y: h[a].y,
                                        text: p,
                                        textAnchor: "middle",
                                        i: o,
                                        j: o,
                                        parent: m,
                                        offsetCorrection: !1,
                                        dataLabelsConfig: t({}, d)
                                    })
                                }
                                c.add(m)
                            })), r.push(c)
                        })), this.drawPolygons({
                            parent: d
                        }), i.config.xaxis.labels.show) {
                        var v = this.drawXAxisTexts();
                        d.add(v)
                    }
                    return r.forEach((function (e) {
                        d.add(e)
                    })), d.add(this.yaxisLabels), d
                }
            }, {
                key: "drawPolygons",
                value: function (e) {
                    for (var t = this, n = this.w, i = e.parent, a = new we(this.ctx), r = n.globals.yAxisScale[0].result.reverse(), s = r.length, o = [], l = this.size / (s - 1), c = 0; c < s; c++) o[c] = l * c;
                    o.reverse();
                    var u = [],
                        d = [];
                    o.forEach((function (e, n) {
                        var i = p.getPolygonPos(e, t.dataPointsLen),
                            a = "";
                        i.forEach((function (e, i) {
                            if (0 === n) {
                                var r = t.graphics.drawLine(e.x, e.y, 0, 0, Array.isArray(t.polygons.connectorColors) ? t.polygons.connectorColors[i] : t.polygons.connectorColors);
                                d.push(r)
                            }
                            0 === i && t.yaxisLabelsTextsPos.push({
                                x: e.x,
                                y: e.y
                            }), a += e.x + "," + e.y + " "
                        })), u.push(a)
                    })), u.forEach((function (e, a) {
                        var r = t.polygons.strokeColors,
                            s = t.polygons.strokeWidth,
                            o = t.graphics.drawPolygon(e, Array.isArray(r) ? r[a] : r, Array.isArray(s) ? s[a] : s, n.globals.radarPolygons.fill.colors[a]);
                        i.add(o)
                    })), d.forEach((function (e) {
                        i.add(e)
                    })), n.config.yaxis[0].show && this.yaxisLabelsTextsPos.forEach((function (e, n) {
                        var i = a.drawYAxisTexts(e.x, e.y, n, r[n]);
                        t.yaxisLabels.add(i)
                    }))
                }
            }, {
                key: "drawXAxisTexts",
                value: function () {
                    var e = this,
                        n = this.w,
                        i = n.config.xaxis.labels,
                        a = this.graphics.group({
                            class: "apexcharts-xaxis"
                        }),
                        r = p.getPolygonPos(this.size, this.dataPointsLen);
                    return n.globals.labels.forEach((function (s, o) {
                        var l = n.config.xaxis.labels.formatter,
                            c = new C(e.ctx);
                        if (r[o]) {
                            var u = e.getTextPos(r[o], e.size),
                                d = l(s, {
                                    seriesIndex: -1,
                                    dataPointIndex: o,
                                    w: n
                                });
                            c.plotDataLabelsText({
                                x: u.newX,
                                y: u.newY,
                                text: d,
                                textAnchor: u.textAnchor,
                                i: o,
                                j: o,
                                parent: a,
                                color: Array.isArray(i.style.colors) && i.style.colors[o] ? i.style.colors[o] : "#a8a8a8",
                                dataLabelsConfig: t({
                                    textAnchor: u.textAnchor,
                                    dropShadow: {
                                        enabled: !1
                                    }
                                }, i),
                                offsetCorrection: !1
                            })
                        }
                    })), a
                }
            }, {
                key: "createPaths",
                value: function (e, t) {
                    var n = this,
                        i = [],
                        a = [],
                        r = [],
                        s = [];
                    if (e.length) {
                        a = [this.graphics.move(t.x, t.y)], s = [this.graphics.move(t.x, t.y)];
                        var o = this.graphics.move(e[0].x, e[0].y),
                            l = this.graphics.move(e[0].x, e[0].y);
                        e.forEach((function (t, i) {
                            o += n.graphics.line(t.x, t.y), l += n.graphics.line(t.x, t.y), i === e.length - 1 && (o += "Z", l += "Z")
                        })), i.push(o), r.push(l)
                    }
                    return {
                        linePathsFrom: a,
                        linePathsTo: i,
                        areaPathsFrom: s,
                        areaPathsTo: r
                    }
                }
            }, {
                key: "getTextPos",
                value: function (e, t) {
                    var n = "middle",
                        i = e.x,
                        a = e.y;
                    return Math.abs(e.x) >= 10 ? e.x > 0 ? (n = "start", i += 10) : e.x < 0 && (n = "end", i -= 10) : n = "middle", Math.abs(e.y) >= t - 10 && (e.y < 0 ? a -= 10 : e.y > 0 && (a += 10)), {
                        textAnchor: n,
                        newX: i,
                        newY: a
                    }
                }
            }, {
                key: "getPreviousPath",
                value: function (e) {
                    for (var t = this.w, n = null, i = 0; i < t.globals.previousPaths.length; i++) {
                        var a = t.globals.previousPaths[i];
                        a.paths.length > 0 && parseInt(a.realIndex, 10) === parseInt(e, 10) && void 0 !== t.globals.previousPaths[i].paths[0] && (n = t.globals.previousPaths[i].paths[0].d)
                    }
                    return n
                }
            }, {
                key: "getDataPointsPos",
                value: function (e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.dataPointsLen;
                    e = e || [], t = t || [];
                    for (var i = [], a = 0; a < n; a++) {
                        var r = {};
                        r.x = e[a] * Math.sin(t[a]), r.y = -e[a] * Math.cos(t[a]), i.push(r)
                    }
                    return i
                }
            }]), e
        }(),
        Le = function (e) {
            o(n, e);
            var t = d(n);

            function n(e) {
                var a;
                i(this, n), (a = t.call(this, e)).ctx = e, a.w = e.w, a.animBeginArr = [0], a.animDur = 0;
                var r = a.w;
                return a.startAngle = r.config.plotOptions.radialBar.startAngle, a.endAngle = r.config.plotOptions.radialBar.endAngle, a.totalAngle = Math.abs(r.config.plotOptions.radialBar.endAngle - r.config.plotOptions.radialBar.startAngle), a.trackStartAngle = r.config.plotOptions.radialBar.track.startAngle, a.trackEndAngle = r.config.plotOptions.radialBar.track.endAngle, a.donutDataLabels = a.w.config.plotOptions.radialBar.dataLabels, a.radialDataLabels = a.donutDataLabels, a.trackStartAngle || (a.trackStartAngle = a.startAngle), a.trackEndAngle || (a.trackEndAngle = a.endAngle), 360 === a.endAngle && (a.endAngle = 359.99), a.margin = parseInt(r.config.plotOptions.radialBar.track.margin, 10), a
            }
            return r(n, [{
                key: "draw",
                value: function (e) {
                    var t = this.w,
                        n = new v(this.ctx),
                        i = n.group({
                            class: "apexcharts-radialbar"
                        });
                    if (t.globals.noData) return i;
                    var a = n.group(),
                        r = this.defaultSize / 2,
                        s = t.globals.gridWidth / 2,
                        o = this.defaultSize / 2.05;
                    t.config.chart.sparkline.enabled || (o = o - t.config.stroke.width - t.config.chart.dropShadow.blur);
                    var l = t.globals.fill.colors;
                    if (t.config.plotOptions.radialBar.track.show) {
                        var c = this.drawTracks({
                            size: o,
                            centerX: s,
                            centerY: r,
                            colorArr: l,
                            series: e
                        });
                        a.add(c)
                    }
                    var u = this.drawArcs({
                            size: o,
                            centerX: s,
                            centerY: r,
                            colorArr: l,
                            series: e
                        }),
                        d = 360;
                    t.config.plotOptions.radialBar.startAngle < 0 && (d = this.totalAngle);
                    var h = (360 - d) / 360;
                    if (t.globals.radialSize = o - o * h, this.radialDataLabels.value.show) {
                        var f = Math.max(this.radialDataLabels.value.offsetY, this.radialDataLabels.name.offsetY);
                        t.globals.radialSize += f * h
                    }
                    return a.add(u.g), "front" === t.config.plotOptions.radialBar.hollow.position && (u.g.add(u.elHollow), u.dataLabels && u.g.add(u.dataLabels)), i.add(a), i
                }
            }, {
                key: "drawTracks",
                value: function (e) {
                    var t = this.w,
                        n = new v(this.ctx),
                        i = n.group({
                            class: "apexcharts-tracks"
                        }),
                        a = new g(this.ctx),
                        r = new S(this.ctx),
                        s = this.getStrokeWidth(e);
                    e.size = e.size - s / 2;
                    for (var o = 0; o < e.series.length; o++) {
                        var l = n.group({
                            class: "apexcharts-radialbar-track apexcharts-track"
                        });
                        i.add(l), l.attr({
                            rel: o + 1
                        }), e.size = e.size - s - this.margin;
                        var c = t.config.plotOptions.radialBar.track,
                            u = r.fillPath({
                                seriesNumber: 0,
                                size: e.size,
                                fillColors: Array.isArray(c.background) ? c.background[o] : c.background,
                                solid: !0
                            }),
                            d = this.trackStartAngle,
                            h = this.trackEndAngle;
                        Math.abs(h) + Math.abs(d) >= 360 && (h = 360 - Math.abs(this.startAngle) - .1);
                        var f = n.drawPath({
                            d: "",
                            stroke: u,
                            strokeWidth: s * parseInt(c.strokeWidth, 10) / 100,
                            fill: "none",
                            strokeOpacity: c.opacity,
                            classes: "apexcharts-radialbar-area"
                        });
                        if (c.dropShadow.enabled) {
                            var p = c.dropShadow;
                            a.dropShadow(f, p)
                        }
                        l.add(f), f.attr("id", "apexcharts-radialbarTrack-" + o), this.animatePaths(f, {
                            centerX: e.centerX,
                            centerY: e.centerY,
                            endAngle: h,
                            startAngle: d,
                            size: e.size,
                            i: o,
                            totalItems: 2,
                            animBeginArr: 0,
                            dur: 0,
                            isTrack: !0,
                            easing: t.globals.easing
                        })
                    }
                    return i
                }
            }, {
                key: "drawArcs",
                value: function (e) {
                    var t = this.w,
                        n = new v(this.ctx),
                        i = new S(this.ctx),
                        a = new g(this.ctx),
                        r = n.group(),
                        s = this.getStrokeWidth(e);
                    e.size = e.size - s / 2;
                    var o = t.config.plotOptions.radialBar.hollow.background,
                        l = e.size - s * e.series.length - this.margin * e.series.length - s * parseInt(t.config.plotOptions.radialBar.track.strokeWidth, 10) / 100 / 2,
                        c = l - t.config.plotOptions.radialBar.hollow.margin;
                    void 0 !== t.config.plotOptions.radialBar.hollow.image && (o = this.drawHollowImage(e, r, l, o));
                    var u = this.drawHollow({
                        size: c,
                        centerX: e.centerX,
                        centerY: e.centerY,
                        fill: o || "transparent"
                    });
                    if (t.config.plotOptions.radialBar.hollow.dropShadow.enabled) {
                        var d = t.config.plotOptions.radialBar.hollow.dropShadow;
                        a.dropShadow(u, d)
                    }
                    var h = 1;
                    !this.radialDataLabels.total.show && t.globals.series.length > 1 && (h = 0);
                    var f = null;
                    this.radialDataLabels.show && (f = this.renderInnerDataLabels(this.radialDataLabels, {
                        hollowSize: l,
                        centerX: e.centerX,
                        centerY: e.centerY,
                        opacity: h
                    })), "back" === t.config.plotOptions.radialBar.hollow.position && (r.add(u), f && r.add(f));
                    var m = !1;
                    t.config.plotOptions.radialBar.inverseOrder && (m = !0);
                    for (var y = m ? e.series.length - 1 : 0; m ? y >= 0 : y < e.series.length; m ? y-- : y++) {
                        var b = n.group({
                            class: "apexcharts-series apexcharts-radial-series",
                            seriesName: p.escapeString(t.globals.seriesNames[y])
                        });
                        r.add(b), b.attr({
                            rel: y + 1,
                            "data:realIndex": y
                        }), this.ctx.series.addCollapsedClassToSeries(b, y), e.size = e.size - s - this.margin;
                        var x = i.fillPath({
                                seriesNumber: y,
                                size: e.size,
                                value: e.series[y]
                            }),
                            _ = this.startAngle,
                            w = void 0,
                            k = p.negToZero(e.series[y] > 100 ? 100 : e.series[y]) / 100,
                            M = Math.round(this.totalAngle * k) + this.startAngle,
                            L = void 0;
                        t.globals.dataChanged && (w = this.startAngle, L = Math.round(this.totalAngle * p.negToZero(t.globals.previousPaths[y]) / 100) + w), Math.abs(M) + Math.abs(_) >= 360 && (M -= .01), Math.abs(L) + Math.abs(w) >= 360 && (L -= .01);
                        var A = M - _,
                            T = Array.isArray(t.config.stroke.dashArray) ? t.config.stroke.dashArray[y] : t.config.stroke.dashArray,
                            C = n.drawPath({
                                d: "",
                                stroke: x,
                                strokeWidth: s,
                                fill: "none",
                                fillOpacity: t.config.fill.opacity,
                                classes: "apexcharts-radialbar-area apexcharts-radialbar-slice-" + y,
                                strokeDashArray: T
                            });
                        if (v.setAttrs(C.node, {
                                "data:angle": A,
                                "data:value": e.series[y]
                            }), t.config.chart.dropShadow.enabled) {
                            var D = t.config.chart.dropShadow;
                            a.dropShadow(C, D, y)
                        }
                        a.setSelectionFilter(C, 0, y), this.addListeners(C, this.radialDataLabels), b.add(C), C.attr({
                            index: 0,
                            j: y
                        });
                        var E = 0;
                        !this.initialAnim || t.globals.resized || t.globals.dataChanged || (E = (M - _) / 360 * t.config.chart.animations.speed, this.animDur = E / (1.2 * e.series.length) + this.animDur, this.animBeginArr.push(this.animDur)), t.globals.dataChanged && (E = (M - _) / 360 * t.config.chart.animations.dynamicAnimation.speed, this.animDur = E / (1.2 * e.series.length) + this.animDur, this.animBeginArr.push(this.animDur)), this.animatePaths(C, {
                            centerX: e.centerX,
                            centerY: e.centerY,
                            endAngle: M,
                            startAngle: _,
                            prevEndAngle: L,
                            prevStartAngle: w,
                            size: e.size,
                            i: y,
                            totalItems: 2,
                            animBeginArr: this.animBeginArr,
                            dur: E,
                            shouldSetPrevPaths: !0,
                            easing: t.globals.easing
                        })
                    }
                    return {
                        g: r,
                        elHollow: u,
                        dataLabels: f
                    }
                }
            }, {
                key: "drawHollow",
                value: function (e) {
                    var t = new v(this.ctx).drawCircle(2 * e.size);
                    return t.attr({
                        class: "apexcharts-radialbar-hollow",
                        cx: e.centerX,
                        cy: e.centerY,
                        r: e.size,
                        fill: e.fill
                    }), t
                }
            }, {
                key: "drawHollowImage",
                value: function (e, t, n, i) {
                    var a = this.w,
                        r = new S(this.ctx),
                        s = p.randomId(),
                        o = a.config.plotOptions.radialBar.hollow.image;
                    if (a.config.plotOptions.radialBar.hollow.imageClipped) r.clippedImgArea({
                        width: n,
                        height: n,
                        image: o,
                        patternID: "pattern".concat(a.globals.cuid).concat(s)
                    }), i = "url(#pattern".concat(a.globals.cuid).concat(s, ")");
                    else {
                        var l = a.config.plotOptions.radialBar.hollow.imageWidth,
                            c = a.config.plotOptions.radialBar.hollow.imageHeight;
                        if (void 0 === l && void 0 === c) {
                            var u = a.globals.dom.Paper.image(o).loaded((function (t) {
                                this.move(e.centerX - t.width / 2 + a.config.plotOptions.radialBar.hollow.imageOffsetX, e.centerY - t.height / 2 + a.config.plotOptions.radialBar.hollow.imageOffsetY)
                            }));
                            t.add(u)
                        } else {
                            var d = a.globals.dom.Paper.image(o).loaded((function (t) {
                                this.move(e.centerX - l / 2 + a.config.plotOptions.radialBar.hollow.imageOffsetX, e.centerY - c / 2 + a.config.plotOptions.radialBar.hollow.imageOffsetY), this.size(l, c)
                            }));
                            t.add(d)
                        }
                    }
                    return i
                }
            }, {
                key: "getStrokeWidth",
                value: function (e) {
                    var t = this.w;
                    return e.size * (100 - parseInt(t.config.plotOptions.radialBar.hollow.size, 10)) / 100 / (e.series.length + 1) - this.margin
                }
            }]), n
        }(ke),
        Se = function () {
            function e(t) {
                i(this, e), this.w = t.w, this.lineCtx = t
            }
            return r(e, [{
                key: "sameValueSeriesFix",
                value: function (e, t) {
                    var n = this.w;
                    if ("line" === n.config.chart.type && ("gradient" === n.config.fill.type || "gradient" === n.config.fill.type[e]) && new x(this.lineCtx.ctx, n).seriesHaveSameValues(e)) {
                        var i = t[e].slice();
                        i[i.length - 1] = i[i.length - 1] + 1e-6, t[e] = i
                    }
                    return t
                }
            }, {
                key: "calculatePoints",
                value: function (e) {
                    var t = e.series,
                        n = e.realIndex,
                        i = e.x,
                        a = e.y,
                        r = e.i,
                        s = e.j,
                        o = e.prevY,
                        l = this.w,
                        c = [],
                        u = [];
                    if (0 === s) {
                        var d = this.lineCtx.categoryAxisCorrection + l.config.markers.offsetX;
                        l.globals.isXNumeric && (d = (l.globals.seriesX[n][0] - l.globals.minX) / this.lineCtx.xRatio + l.config.markers.offsetX), c.push(d), u.push(p.isNumber(t[r][0]) ? o + l.config.markers.offsetY : null), c.push(i + l.config.markers.offsetX), u.push(p.isNumber(t[r][s + 1]) ? a + l.config.markers.offsetY : null)
                    } else c.push(i + l.config.markers.offsetX), u.push(p.isNumber(t[r][s + 1]) ? a + l.config.markers.offsetY : null);
                    return {
                        x: c,
                        y: u
                    }
                }
            }, {
                key: "checkPreviousPaths",
                value: function (e) {
                    for (var t = e.pathFromLine, n = e.pathFromArea, i = e.realIndex, a = this.w, r = 0; r < a.globals.previousPaths.length; r++) {
                        var s = a.globals.previousPaths[r];
                        ("line" === s.type || "area" === s.type) && s.paths.length > 0 && parseInt(s.realIndex, 10) === parseInt(i, 10) && ("line" === s.type ? (this.lineCtx.appendPathFrom = !1, t = a.globals.previousPaths[r].paths[0].d) : "area" === s.type && (this.lineCtx.appendPathFrom = !1, n = a.globals.previousPaths[r].paths[0].d, a.config.stroke.show && a.globals.previousPaths[r].paths[1] && (t = a.globals.previousPaths[r].paths[1].d)))
                    }
                    return {
                        pathFromLine: t,
                        pathFromArea: n
                    }
                }
            }, {
                key: "determineFirstPrevY",
                value: function (e) {
                    var t = e.i,
                        n = e.series,
                        i = e.prevY,
                        a = e.lineYPosition,
                        r = this.w;
                    if (void 0 !== n[t][0]) i = (a = r.config.chart.stacked && t > 0 ? this.lineCtx.prevSeriesY[t - 1][0] : this.lineCtx.zeroY) - n[t][0] / this.lineCtx.yRatio[this.lineCtx.yaxisIndex] + 2 * (this.lineCtx.isReversed ? n[t][0] / this.lineCtx.yRatio[this.lineCtx.yaxisIndex] : 0);
                    else if (r.config.chart.stacked && t > 0 && void 0 === n[t][0])
                        for (var s = t - 1; s >= 0; s--)
                            if (null !== n[s][0] && void 0 !== n[s][0]) {
                                i = a = this.lineCtx.prevSeriesY[s][0];
                                break
                            } return {
                        prevY: i,
                        lineYPosition: a
                    }
                }
            }]), e
        }(),
        Ae = function () {
            function e(t, n, a) {
                i(this, e), this.ctx = t, this.w = t.w, this.xyRatios = n, this.pointsChart = !("bubble" !== this.w.config.chart.type && "scatter" !== this.w.config.chart.type) || a, this.scatter = new T(this.ctx), this.noNegatives = this.w.globals.minX === Number.MAX_VALUE, this.lineHelpers = new Se(this), this.markers = new A(this.ctx), this.prevSeriesY = [], this.categoryAxisCorrection = 0, this.yaxisIndex = 0
            }
            return r(e, [{
                key: "draw",
                value: function (e, t, n) {
                    var i = this.w,
                        a = new v(this.ctx),
                        r = i.globals.comboCharts ? t : i.config.chart.type,
                        s = a.group({
                            class: "apexcharts-".concat(r, "-series apexcharts-plot-series")
                        }),
                        o = new x(this.ctx, i);
                    this.yRatio = this.xyRatios.yRatio, this.zRatio = this.xyRatios.zRatio, this.xRatio = this.xyRatios.xRatio, this.baseLineY = this.xyRatios.baseLineY, e = o.getLogSeries(e), this.yRatio = o.getLogYRatios(this.yRatio);
                    for (var l = [], c = 0; c < e.length; c++) {
                        e = this.lineHelpers.sameValueSeriesFix(c, e);
                        var u = i.globals.comboCharts ? n[c] : c;
                        this._initSerieVariables(e, c, u);
                        var d = [],
                            h = [],
                            f = i.globals.padHorizontal + this.categoryAxisCorrection;
                        this.ctx.series.addCollapsedClassToSeries(this.elSeries, u), i.globals.isXNumeric && i.globals.seriesX.length > 0 && (f = (i.globals.seriesX[u][0] - i.globals.minX) / this.xRatio), h.push(f);
                        var p, m = f,
                            g = m,
                            y = this.zeroY;
                        y = this.lineHelpers.determineFirstPrevY({
                            i: c,
                            series: e,
                            prevY: y,
                            lineYPosition: 0
                        }).prevY, d.push(y), p = y;
                        var b = this._calculatePathsFrom({
                                series: e,
                                i: c,
                                realIndex: u,
                                prevX: g,
                                prevY: y
                            }),
                            _ = this._iterateOverDataPoints({
                                series: e,
                                realIndex: u,
                                i: c,
                                x: f,
                                y: 1,
                                pX: m,
                                pY: p,
                                pathsFrom: b,
                                linePaths: [],
                                areaPaths: [],
                                seriesIndex: n,
                                lineYPosition: 0,
                                xArrj: h,
                                yArrj: d
                            });
                        this._handlePaths({
                            type: r,
                            realIndex: u,
                            i: c,
                            paths: _
                        }), this.elSeries.add(this.elPointsMain), this.elSeries.add(this.elDataLabelsWrap), l.push(this.elSeries)
                    }
                    if (i.config.chart.stacked)
                        for (var w = l.length; w > 0; w--) s.add(l[w - 1]);
                    else
                        for (var k = 0; k < l.length; k++) s.add(l[k]);
                    return s
                }
            }, {
                key: "_initSerieVariables",
                value: function (e, t, n) {
                    var i = this.w,
                        a = new v(this.ctx);
                    this.xDivision = i.globals.gridWidth / (i.globals.dataPoints - ("on" === i.config.xaxis.tickPlacement ? 1 : 0)), this.strokeWidth = Array.isArray(i.config.stroke.width) ? i.config.stroke.width[n] : i.config.stroke.width, this.yRatio.length > 1 && (this.yaxisIndex = n), this.isReversed = i.config.yaxis[this.yaxisIndex] && i.config.yaxis[this.yaxisIndex].reversed, this.zeroY = i.globals.gridHeight - this.baseLineY[this.yaxisIndex] - (this.isReversed ? i.globals.gridHeight : 0) + (this.isReversed ? 2 * this.baseLineY[this.yaxisIndex] : 0), this.areaBottomY = this.zeroY, (this.zeroY > i.globals.gridHeight || "end" === i.config.plotOptions.area.fillTo) && (this.areaBottomY = i.globals.gridHeight), this.categoryAxisCorrection = this.xDivision / 2, this.elSeries = a.group({
                        class: "apexcharts-series",
                        seriesName: p.escapeString(i.globals.seriesNames[n])
                    }), this.elPointsMain = a.group({
                        class: "apexcharts-series-markers-wrap",
                        "data:realIndex": n
                    }), this.elDataLabelsWrap = a.group({
                        class: "apexcharts-datalabels",
                        "data:realIndex": n
                    });
                    var r = e[t].length === i.globals.dataPoints;
                    this.elSeries.attr({
                        "data:longestSeries": r,
                        rel: t + 1,
                        "data:realIndex": n
                    }), this.appendPathFrom = !0
                }
            }, {
                key: "_calculatePathsFrom",
                value: function (e) {
                    var t, n, i, a, r = e.series,
                        s = e.i,
                        o = e.realIndex,
                        l = e.prevX,
                        c = e.prevY,
                        u = this.w,
                        d = new v(this.ctx);
                    if (null === r[s][0]) {
                        for (var h = 0; h < r[s].length; h++)
                            if (null !== r[s][h]) {
                                l = this.xDivision * h, c = this.zeroY - r[s][h] / this.yRatio[this.yaxisIndex], t = d.move(l, c), n = d.move(l, this.areaBottomY);
                                break
                            }
                    } else t = d.move(l, c), n = d.move(l, this.areaBottomY) + d.line(l, c);
                    if (i = d.move(-1, this.zeroY) + d.line(-1, this.zeroY), a = d.move(-1, this.zeroY) + d.line(-1, this.zeroY), u.globals.previousPaths.length > 0) {
                        var f = this.lineHelpers.checkPreviousPaths({
                            pathFromLine: i,
                            pathFromArea: a,
                            realIndex: o
                        });
                        i = f.pathFromLine, a = f.pathFromArea
                    }
                    return {
                        prevX: l,
                        prevY: c,
                        linePath: t,
                        areaPath: n,
                        pathFromLine: i,
                        pathFromArea: a
                    }
                }
            }, {
                key: "_handlePaths",
                value: function (e) {
                    var n = e.type,
                        i = e.realIndex,
                        a = e.i,
                        r = e.paths,
                        s = this.w,
                        o = new v(this.ctx),
                        l = new S(this.ctx);
                    this.prevSeriesY.push(r.yArrj), s.globals.seriesXvalues[i] = r.xArrj, s.globals.seriesYvalues[i] = r.yArrj;
                    var c = s.config.forecastDataPoints;
                    if (c.count > 0) {
                        var u = s.globals.seriesXvalues[i][s.globals.seriesXvalues[i].length - c.count - 1],
                            d = o.drawRect(u, 0, s.globals.gridWidth, s.globals.gridHeight, 0);
                        s.globals.dom.elForecastMask.appendChild(d.node);
                        var h = o.drawRect(0, 0, u, s.globals.gridHeight, 0);
                        s.globals.dom.elNonForecastMask.appendChild(h.node)
                    }
                    this.pointsChart || s.globals.delayedElements.push({
                        el: this.elPointsMain.node,
                        index: i
                    });
                    var f = {
                        i: a,
                        realIndex: i,
                        animationDelay: a,
                        initialSpeed: s.config.chart.animations.speed,
                        dataChangeSpeed: s.config.chart.animations.dynamicAnimation.speed,
                        className: "apexcharts-".concat(n)
                    };
                    if ("area" === n)
                        for (var p = l.fillPath({
                                seriesNumber: i
                            }), m = 0; m < r.areaPaths.length; m++) {
                            var g = o.renderPaths(t(t({}, f), {}, {
                                pathFrom: r.pathFromArea,
                                pathTo: r.areaPaths[m],
                                stroke: "none",
                                strokeWidth: 0,
                                strokeLineCap: null,
                                fill: p
                            }));
                            this.elSeries.add(g)
                        }
                    if (s.config.stroke.show && !this.pointsChart) {
                        var y;
                        y = "line" === n ? l.fillPath({
                            seriesNumber: i,
                            i: a
                        }) : s.globals.stroke.colors[i];
                        for (var b = 0; b < r.linePaths.length; b++) {
                            var x = t(t({}, f), {}, {
                                    pathFrom: r.pathFromLine,
                                    pathTo: r.linePaths[b],
                                    stroke: y,
                                    strokeWidth: this.strokeWidth,
                                    strokeLineCap: s.config.stroke.lineCap,
                                    fill: "none"
                                }),
                                _ = o.renderPaths(x);
                            if (this.elSeries.add(_), c.count > 0) {
                                var w = o.renderPaths(x);
                                w.node.setAttribute("stroke-dasharray", c.dashArray), c.strokeWidth && w.node.setAttribute("stroke-width", c.strokeWidth), this.elSeries.add(w), w.attr("clip-path", "url(#forecastMask".concat(s.globals.cuid, ")")), _.attr("clip-path", "url(#nonForecastMask".concat(s.globals.cuid, ")"))
                            }
                        }
                    }
                }
            }, {
                key: "_iterateOverDataPoints",
                value: function (e) {
                    for (var t = e.series, n = e.realIndex, i = e.i, a = e.x, r = e.y, s = e.pX, o = e.pY, l = e.pathsFrom, c = e.linePaths, u = e.areaPaths, d = e.seriesIndex, h = e.lineYPosition, f = e.xArrj, m = e.yArrj, g = this.w, y = new v(this.ctx), b = this.yRatio, x = l.prevY, _ = l.linePath, w = l.areaPath, k = l.pathFromLine, M = l.pathFromArea, L = p.isNumber(g.globals.minYArr[n]) ? g.globals.minYArr[n] : g.globals.minY, S = g.globals.dataPoints > 1 ? g.globals.dataPoints - 1 : g.globals.dataPoints, A = 0; A < S; A++) {
                        var T = void 0 === t[i][A + 1] || null === t[i][A + 1];
                        if (g.globals.isXNumeric) {
                            var C = g.globals.seriesX[n][A + 1];
                            void 0 === g.globals.seriesX[n][A + 1] && (C = g.globals.seriesX[n][S - 1]), a = (C - g.globals.minX) / this.xRatio
                        } else a += this.xDivision;
                        h = g.config.chart.stacked && i > 0 && g.globals.collapsedSeries.length < g.config.series.length - 1 ? this.prevSeriesY[function (e) {
                            for (var t = e, n = 0; n < g.globals.series.length; n++)
                                if (g.globals.collapsedSeriesIndices.indexOf(e) > -1) {
                                    t--;
                                    break
                                } return t >= 0 ? t : 0
                        }(i - 1)][A + 1] : this.zeroY, r = T ? h - L / b[this.yaxisIndex] + 2 * (this.isReversed ? L / b[this.yaxisIndex] : 0) : h - t[i][A + 1] / b[this.yaxisIndex] + 2 * (this.isReversed ? t[i][A + 1] / b[this.yaxisIndex] : 0), f.push(a), m.push(r);
                        var D = this.lineHelpers.calculatePoints({
                                series: t,
                                x: a,
                                y: r,
                                realIndex: n,
                                i: i,
                                j: A,
                                prevY: x
                            }),
                            E = this._createPaths({
                                series: t,
                                i: i,
                                realIndex: n,
                                j: A,
                                x: a,
                                y: r,
                                pX: s,
                                pY: o,
                                linePath: _,
                                areaPath: w,
                                linePaths: c,
                                areaPaths: u,
                                seriesIndex: d
                            });
                        u = E.areaPaths, c = E.linePaths, s = E.pX, o = E.pY, w = E.areaPath, _ = E.linePath, this.appendPathFrom && (k += y.line(a, this.zeroY), M += y.line(a, this.zeroY)), this.handleNullDataPoints(t, D, i, A, n), this._handleMarkersAndLabels({
                            pointsPos: D,
                            series: t,
                            x: a,
                            y: r,
                            prevY: x,
                            i: i,
                            j: A,
                            realIndex: n
                        })
                    }
                    return {
                        yArrj: m,
                        xArrj: f,
                        pathFromArea: M,
                        areaPaths: u,
                        pathFromLine: k,
                        linePaths: c
                    }
                }
            }, {
                key: "_handleMarkersAndLabels",
                value: function (e) {
                    var t = e.pointsPos;
                    e.series, e.x, e.y, e.prevY;
                    var n = e.i,
                        i = e.j,
                        a = e.realIndex,
                        r = this.w,
                        s = new C(this.ctx);
                    if (this.pointsChart) this.scatter.draw(this.elSeries, i, {
                        realIndex: a,
                        pointsPos: t,
                        zRatio: this.zRatio,
                        elParent: this.elPointsMain
                    });
                    else {
                        r.globals.series[n].length > 1 && this.elPointsMain.node.classList.add("apexcharts-element-hidden");
                        var o = this.markers.plotChartMarkers(t, a, i + 1);
                        null !== o && this.elPointsMain.add(o)
                    }
                    var l = s.drawDataLabel(t, a, i + 1, null);
                    null !== l && this.elDataLabelsWrap.add(l)
                }
            }, {
                key: "_createPaths",
                value: function (e) {
                    var t = e.series,
                        n = e.i,
                        i = e.realIndex,
                        a = e.j,
                        r = e.x,
                        s = e.y,
                        o = e.pX,
                        l = e.pY,
                        c = e.linePath,
                        u = e.areaPath,
                        d = e.linePaths,
                        h = e.areaPaths,
                        f = e.seriesIndex,
                        p = this.w,
                        m = new v(this.ctx),
                        g = p.config.stroke.curve,
                        y = this.areaBottomY;
                    if (Array.isArray(p.config.stroke.curve) && (g = Array.isArray(f) ? p.config.stroke.curve[f[n]] : p.config.stroke.curve[n]), "smooth" === g) {
                        var b = .35 * (r - o);
                        p.globals.hasNullValues ? (null !== t[n][a] && (null !== t[n][a + 1] ? (c = m.move(o, l) + m.curve(o + b, l, r - b, s, r + 1, s), u = m.move(o + 1, l) + m.curve(o + b, l, r - b, s, r + 1, s) + m.line(r, y) + m.line(o, y) + "z") : (c = m.move(o, l), u = m.move(o, l) + "z")), d.push(c), h.push(u)) : (c += m.curve(o + b, l, r - b, s, r, s), u += m.curve(o + b, l, r - b, s, r, s)), o = r, l = s, a === t[n].length - 2 && (u = u + m.curve(o, l, r, s, r, y) + m.move(r, s) + "z", p.globals.hasNullValues || (d.push(c), h.push(u)))
                    } else {
                        if (null === t[n][a + 1]) {
                            c += m.move(r, s);
                            var x = p.globals.isXNumeric ? (p.globals.seriesX[i][a] - p.globals.minX) / this.xRatio : r - this.xDivision;
                            u = u + m.line(x, y) + m.move(r, s) + "z"
                        }
                        null === t[n][a] && (c += m.move(r, s), u += m.move(r, y)), "stepline" === g ? (c = c + m.line(r, null, "H") + m.line(null, s, "V"), u = u + m.line(r, null, "H") + m.line(null, s, "V")) : "straight" === g && (c += m.line(r, s), u += m.line(r, s)), a === t[n].length - 2 && (u = u + m.line(r, y) + m.move(r, s) + "z", d.push(c), h.push(u))
                    }
                    return {
                        linePaths: d,
                        areaPaths: h,
                        pX: o,
                        pY: l,
                        linePath: c,
                        areaPath: u
                    }
                }
            }, {
                key: "handleNullDataPoints",
                value: function (e, t, n, i, a) {
                    var r = this.w;
                    if (null === e[n][i] && r.config.markers.showNullDataPoints || 1 === e[n].length) {
                        var s = this.markers.plotChartMarkers(t, a, i + 1, this.strokeWidth - r.config.markers.strokeWidth / 2, !0);
                        null !== s && this.elPointsMain.add(s)
                    }
                }
            }]), e
        }();
    window.TreemapSquared = {}, window.TreemapSquared.generate = function () {
        function e(t, n, i, a) {
            this.xoffset = t, this.yoffset = n, this.height = a, this.width = i, this.shortestEdge = function () {
                return Math.min(this.height, this.width)
            }, this.getCoordinates = function (e) {
                var t, n = [],
                    i = this.xoffset,
                    a = this.yoffset,
                    s = r(e) / this.height,
                    o = r(e) / this.width;
                if (this.width >= this.height)
                    for (t = 0; t < e.length; t++) n.push([i, a, i + s, a + e[t] / s]), a += e[t] / s;
                else
                    for (t = 0; t < e.length; t++) n.push([i, a, i + e[t] / o, a + o]), i += e[t] / o;
                return n
            }, this.cutArea = function (t) {
                var n;
                if (this.width >= this.height) {
                    var i = t / this.height,
                        a = this.width - i;
                    n = new e(this.xoffset + i, this.yoffset, a, this.height)
                } else {
                    var r = t / this.width,
                        s = this.height - r;
                    n = new e(this.xoffset, this.yoffset + r, this.width, s)
                }
                return n
            }
        }

        function t(t, i, a, s, o) {
            return s = void 0 === s ? 0 : s, o = void 0 === o ? 0 : o,
                function (e) {
                    var t, n, i = [];
                    for (t = 0; t < e.length; t++)
                        for (n = 0; n < e[t].length; n++) i.push(e[t][n]);
                    return i
                }(n(function (e, t) {
                    var n, i = [],
                        a = t / r(e);
                    for (n = 0; n < e.length; n++) i[n] = e[n] * a;
                    return i
                }(t, i * a), [], new e(s, o, i, a), []))
        }

        function n(e, t, a, s) {
            var o, l, c;
            if (0 !== e.length) return o = a.shortestEdge(),
                function (e, t, n) {
                    var a;
                    return 0 === e.length || ((a = e.slice()).push(t), i(e, n) >= i(a, n))
                }(t, l = e[0], o) ? (t.push(l), n(e.slice(1), t, a, s)) : (c = a.cutArea(r(t), s), s.push(a.getCoordinates(t)), n(e, [], c, s)), s;
            s.push(a.getCoordinates(t))
        }

        function i(e, t) {
            var n = Math.min.apply(Math, e),
                i = Math.max.apply(Math, e),
                a = r(e);
            return Math.max(Math.pow(t, 2) * i / Math.pow(a, 2), Math.pow(a, 2) / (Math.pow(t, 2) * n))
        }

        function a(e) {
            return e && e.constructor === Array
        }

        function r(e) {
            var t, n = 0;
            for (t = 0; t < e.length; t++) n += e[t];
            return n
        }

        function s(e) {
            var t, n = 0;
            if (a(e[0]))
                for (t = 0; t < e.length; t++) n += s(e[t]);
            else n = r(e);
            return n
        }
        return function e(n, i, r, o, l) {
            o = void 0 === o ? 0 : o, l = void 0 === l ? 0 : l;
            var c, u, d = [],
                h = [];
            if (a(n[0])) {
                for (u = 0; u < n.length; u++) d[u] = s(n[u]);
                for (c = t(d, i, r, o, l), u = 0; u < n.length; u++) h.push(e(n[u], c[u][2] - c[u][0], c[u][3] - c[u][1], c[u][0], c[u][1]))
            } else h = t(n, i, r, o, l);
            return h
        }
    }();
    var Te, Ce, De = function () {
            function e(t, n) {
                i(this, e), this.ctx = t, this.w = t.w, this.strokeWidth = this.w.config.stroke.width, this.helpers = new xe(t), this.dynamicAnim = this.w.config.chart.animations.dynamicAnimation, this.labels = []
            }
            return r(e, [{
                key: "draw",
                value: function (e) {
                    var t = this,
                        n = this.w,
                        i = new v(this.ctx),
                        a = new S(this.ctx),
                        r = i.group({
                            class: "apexcharts-treemap"
                        });
                    if (n.globals.noData) return r;
                    var s = [];
                    return e.forEach((function (e) {
                        var t = e.map((function (e) {
                            return Math.abs(e)
                        }));
                        s.push(t)
                    })), this.negRange = this.helpers.checkColorRange(), n.config.series.forEach((function (e, n) {
                        e.data.forEach((function (e) {
                            Array.isArray(t.labels[n]) || (t.labels[n] = []), t.labels[n].push(e.x)
                        }))
                    })), window.TreemapSquared.generate(s, n.globals.gridWidth, n.globals.gridHeight).forEach((function (s, o) {
                        var l = i.group({
                            class: "apexcharts-series apexcharts-treemap-series",
                            seriesName: p.escapeString(n.globals.seriesNames[o]),
                            rel: o + 1,
                            "data:realIndex": o
                        });
                        if (n.config.chart.dropShadow.enabled) {
                            var c = n.config.chart.dropShadow;
                            new g(t.ctx).dropShadow(r, c, o)
                        }
                        var u = i.group({
                            class: "apexcharts-data-labels"
                        });
                        s.forEach((function (r, s) {
                            var c = r[0],
                                u = r[1],
                                d = r[2],
                                h = r[3],
                                f = i.drawRect(c, u, d - c, h - u, 0, "#fff", 1, t.strokeWidth, n.config.plotOptions.treemap.useFillColorAsStroke ? m : n.globals.stroke.colors[o]);
                            f.attr({
                                cx: c,
                                cy: u,
                                index: o,
                                i: o,
                                j: s,
                                width: d - c,
                                height: h - u
                            });
                            var p = t.helpers.getShadeColor(n.config.chart.type, o, s, t.negRange),
                                m = p.color;
                            void 0 !== n.config.series[o].data[s] && n.config.series[o].data[s].fillColor && (m = n.config.series[o].data[s].fillColor);
                            var g = a.fillPath({
                                color: m,
                                seriesNumber: o,
                                dataPointIndex: s
                            });
                            f.node.classList.add("apexcharts-treemap-rect"), f.attr({
                                fill: g
                            }), t.helpers.addListeners(f);
                            var v = {
                                    x: c + (d - c) / 2,
                                    y: u + (h - u) / 2,
                                    width: 0,
                                    height: 0
                                },
                                y = {
                                    x: c,
                                    y: u,
                                    width: d - c,
                                    height: h - u
                                };
                            if (n.config.chart.animations.enabled && !n.globals.dataChanged) {
                                var b = 1;
                                n.globals.resized || (b = n.config.chart.animations.speed), t.animateTreemap(f, v, y, b)
                            }
                            if (n.globals.dataChanged) {
                                var x = 1;
                                t.dynamicAnim.enabled && n.globals.shouldAnimate && (x = t.dynamicAnim.speed, n.globals.previousPaths[o] && n.globals.previousPaths[o][s] && n.globals.previousPaths[o][s].rect && (v = n.globals.previousPaths[o][s].rect), t.animateTreemap(f, v, y, x))
                            }
                            var _ = t.getFontSize(r),
                                w = n.config.dataLabels.formatter(t.labels[o][s], {
                                    value: n.globals.series[o][s],
                                    seriesIndex: o,
                                    dataPointIndex: s,
                                    w: n
                                }),
                                k = t.helpers.calculateDataLabels({
                                    text: w,
                                    x: (c + d) / 2,
                                    y: (u + h) / 2 + t.strokeWidth / 2 + _ / 3,
                                    i: o,
                                    j: s,
                                    colorProps: p,
                                    fontSize: _,
                                    series: e
                                });
                            n.config.dataLabels.enabled && k && t.rotateToFitLabel(k, w, c, u, d, h), l.add(f), null !== k && l.add(k)
                        })), l.add(u), r.add(l)
                    })), r
                }
            }, {
                key: "getFontSize",
                value: function (e) {
                    var t, n, i = this.w,
                        a = function e(t) {
                            var n, i = 0;
                            if (Array.isArray(t[0]))
                                for (n = 0; n < t.length; n++) i += e(t[n]);
                            else
                                for (n = 0; n < t.length; n++) i += t[n].length;
                            return i
                        }(this.labels) / function e(t) {
                            var n, i = 0;
                            if (Array.isArray(t[0]))
                                for (n = 0; n < t.length; n++) i += e(t[n]);
                            else
                                for (n = 0; n < t.length; n++) i += 1;
                            return i
                        }(this.labels);
                    return t = (e[2] - e[0]) * (e[3] - e[1]), n = Math.pow(t, .5), Math.min(n / a, parseInt(i.config.dataLabels.style.fontSize, 10))
                }
            }, {
                key: "rotateToFitLabel",
                value: function (e, t, n, i, a, r) {
                    var s = new v(this.ctx),
                        o = s.getTextRects(t);
                    if (o.width + 5 > a - n && o.width <= r - i) {
                        var l = s.rotateAroundCenter(e.node);
                        e.node.setAttribute("transform", "rotate(-90 ".concat(l.x, " ").concat(l.y, ")"))
                    }
                }
            }, {
                key: "animateTreemap",
                value: function (e, t, n, i) {
                    var a = new m(this.ctx);
                    a.animateRect(e, {
                        x: t.x,
                        y: t.y,
                        width: t.width,
                        height: t.height
                    }, {
                        x: n.x,
                        y: n.y,
                        width: n.width,
                        height: n.height
                    }, i, (function () {
                        a.animationCompleted(e)
                    }))
                }
            }]), e
        }(),
        Ee = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w, this.timeScaleArray = [], this.utc = this.w.config.xaxis.labels.datetimeUTC
            }
            return r(e, [{
                key: "calculateTimeScaleTicks",
                value: function (e, n) {
                    var i = this,
                        a = this.w;
                    if (a.globals.allSeriesCollapsed) return a.globals.labels = [], a.globals.timescaleLabels = [], [];
                    var r = new Y(this.ctx),
                        s = (n - e) / 864e5;
                    this.determineInterval(s), a.globals.disableZoomIn = !1, a.globals.disableZoomOut = !1, s < .00011574074074074075 ? a.globals.disableZoomIn = !0 : s > 5e4 && (a.globals.disableZoomOut = !0);
                    var o = r.getTimeUnitsfromTimestamp(e, n, this.utc),
                        l = a.globals.gridWidth / s,
                        c = l / 24,
                        u = c / 60,
                        d = u / 60,
                        h = Math.floor(24 * s),
                        f = Math.floor(1440 * s),
                        p = Math.floor(86400 * s),
                        m = Math.floor(s),
                        g = Math.floor(s / 30),
                        v = Math.floor(s / 365),
                        y = {
                            minMillisecond: o.minMillisecond,
                            minSecond: o.minSecond,
                            minMinute: o.minMinute,
                            minHour: o.minHour,
                            minDate: o.minDate,
                            minMonth: o.minMonth,
                            minYear: o.minYear
                        },
                        b = {
                            firstVal: y,
                            currentMillisecond: y.minMillisecond,
                            currentSecond: y.minSecond,
                            currentMinute: y.minMinute,
                            currentHour: y.minHour,
                            currentMonthDate: y.minDate,
                            currentDate: y.minDate,
                            currentMonth: y.minMonth,
                            currentYear: y.minYear,
                            daysWidthOnXAxis: l,
                            hoursWidthOnXAxis: c,
                            minutesWidthOnXAxis: u,
                            secondsWidthOnXAxis: d,
                            numberOfSeconds: p,
                            numberOfMinutes: f,
                            numberOfHours: h,
                            numberOfDays: m,
                            numberOfMonths: g,
                            numberOfYears: v
                        };
                    switch (this.tickInterval) {
                        case "years":
                            this.generateYearScale(b);
                            break;
                        case "months":
                        case "half_year":
                            this.generateMonthScale(b);
                            break;
                        case "months_days":
                        case "months_fortnight":
                        case "days":
                        case "week_days":
                            this.generateDayScale(b);
                            break;
                        case "hours":
                            this.generateHourScale(b);
                            break;
                        case "minutes_fives":
                        case "minutes":
                            this.generateMinuteScale(b);
                            break;
                        case "seconds_tens":
                        case "seconds_fives":
                        case "seconds":
                            this.generateSecondScale(b)
                    }
                    var x = this.timeScaleArray.map((function (e) {
                        var n = {
                            position: e.position,
                            unit: e.unit,
                            year: e.year,
                            day: e.day ? e.day : 1,
                            hour: e.hour ? e.hour : 0,
                            month: e.month + 1
                        };
                        return "month" === e.unit ? t(t({}, n), {}, {
                            day: 1,
                            value: e.value + 1
                        }) : "day" === e.unit || "hour" === e.unit ? t(t({}, n), {}, {
                            value: e.value
                        }) : "minute" === e.unit ? t(t({}, n), {}, {
                            value: e.value,
                            minute: e.value
                        }) : "second" === e.unit ? t(t({}, n), {}, {
                            value: e.value,
                            minute: e.minute,
                            second: e.second
                        }) : e
                    }));
                    return x.filter((function (e) {
                        var t = 1,
                            n = Math.ceil(a.globals.gridWidth / 120),
                            r = e.value;
                        void 0 !== a.config.xaxis.tickAmount && (n = a.config.xaxis.tickAmount), x.length > n && (t = Math.floor(x.length / n));
                        var s = !1,
                            o = !1;
                        switch (i.tickInterval) {
                            case "years":
                                "year" === e.unit && (s = !0);
                                break;
                            case "half_year":
                                t = 7, "year" === e.unit && (s = !0);
                                break;
                            case "months":
                                t = 1, "year" === e.unit && (s = !0);
                                break;
                            case "months_fortnight":
                                t = 15, "year" !== e.unit && "month" !== e.unit || (s = !0), 30 === r && (o = !0);
                                break;
                            case "months_days":
                                t = 10, "month" === e.unit && (s = !0), 30 === r && (o = !0);
                                break;
                            case "week_days":
                                t = 8, "month" === e.unit && (s = !0);
                                break;
                            case "days":
                                t = 1, "month" === e.unit && (s = !0);
                                break;
                            case "hours":
                                "day" === e.unit && (s = !0);
                                break;
                            case "minutes_fives":
                            case "seconds_fives":
                                r % 5 != 0 && (o = !0);
                                break;
                            case "seconds_tens":
                                r % 10 != 0 && (o = !0)
                        }
                        if ("hours" === i.tickInterval || "minutes_fives" === i.tickInterval || "seconds_tens" === i.tickInterval || "seconds_fives" === i.tickInterval) {
                            if (!o) return !0
                        } else if ((r % t == 0 || s) && !o) return !0
                    }))
                }
            }, {
                key: "recalcDimensionsBasedOnFormat",
                value: function (e, t) {
                    var n = this.w,
                        i = this.formatDates(e),
                        a = this.removeOverlappingTS(i);
                    n.globals.timescaleLabels = a.slice(), new se(this.ctx).plotCoords()
                }
            }, {
                key: "determineInterval",
                value: function (e) {
                    var t = 24 * e,
                        n = 60 * t;
                    switch (!0) {
                        case e / 365 > 5:
                            this.tickInterval = "years";
                            break;
                        case e > 800:
                            this.tickInterval = "half_year";
                            break;
                        case e > 180:
                            this.tickInterval = "months";
                            break;
                        case e > 90:
                            this.tickInterval = "months_fortnight";
                            break;
                        case e > 60:
                            this.tickInterval = "months_days";
                            break;
                        case e > 30:
                            this.tickInterval = "week_days";
                            break;
                        case e > 2:
                            this.tickInterval = "days";
                            break;
                        case t > 2.4:
                            this.tickInterval = "hours";
                            break;
                        case n > 15:
                            this.tickInterval = "minutes_fives";
                            break;
                        case n > 5:
                            this.tickInterval = "minutes";
                            break;
                        case n > 1:
                            this.tickInterval = "seconds_tens";
                            break;
                        case 60 * n > 20:
                            this.tickInterval = "seconds_fives";
                            break;
                        default:
                            this.tickInterval = "seconds"
                    }
                }
            }, {
                key: "generateYearScale",
                value: function (e) {
                    var t = e.firstVal,
                        n = e.currentMonth,
                        i = e.currentYear,
                        a = e.daysWidthOnXAxis,
                        r = e.numberOfYears,
                        s = t.minYear,
                        o = 0,
                        l = new Y(this.ctx),
                        c = "year";
                    if (t.minDate > 1 || t.minMonth > 0) {
                        var u = l.determineRemainingDaysOfYear(t.minYear, t.minMonth, t.minDate);
                        o = (l.determineDaysOfYear(t.minYear) - u + 1) * a, s = t.minYear + 1, this.timeScaleArray.push({
                            position: o,
                            value: s,
                            unit: c,
                            year: s,
                            month: p.monthMod(n + 1)
                        })
                    } else 1 === t.minDate && 0 === t.minMonth && this.timeScaleArray.push({
                        position: o,
                        value: s,
                        unit: c,
                        year: i,
                        month: p.monthMod(n + 1)
                    });
                    for (var d = s, h = o, f = 0; f < r; f++) d++, h = l.determineDaysOfYear(d - 1) * a + h, this.timeScaleArray.push({
                        position: h,
                        value: d,
                        unit: c,
                        year: d,
                        month: 1
                    })
                }
            }, {
                key: "generateMonthScale",
                value: function (e) {
                    var t = e.firstVal,
                        n = e.currentMonthDate,
                        i = e.currentMonth,
                        a = e.currentYear,
                        r = e.daysWidthOnXAxis,
                        s = e.numberOfMonths,
                        o = i,
                        l = 0,
                        c = new Y(this.ctx),
                        u = "month",
                        d = 0;
                    if (t.minDate > 1) {
                        l = (c.determineDaysOfMonths(i + 1, t.minYear) - n + 1) * r, o = p.monthMod(i + 1);
                        var h = a + d,
                            f = p.monthMod(o),
                            m = o;
                        0 === o && (u = "year", m = h, f = 1, h += d += 1), this.timeScaleArray.push({
                            position: l,
                            value: m,
                            unit: u,
                            year: h,
                            month: f
                        })
                    } else this.timeScaleArray.push({
                        position: l,
                        value: o,
                        unit: u,
                        year: a,
                        month: p.monthMod(i)
                    });
                    for (var g = o + 1, v = l, y = 0, b = 1; y < s; y++, b++) {
                        0 === (g = p.monthMod(g)) ? (u = "year", d += 1) : u = "month";
                        var x = this._getYear(a, g, d);
                        v = c.determineDaysOfMonths(g, x) * r + v;
                        var _ = 0 === g ? x : g;
                        this.timeScaleArray.push({
                            position: v,
                            value: _,
                            unit: u,
                            year: x,
                            month: 0 === g ? 1 : g
                        }), g++
                    }
                }
            }, {
                key: "generateDayScale",
                value: function (e) {
                    var t = e.firstVal,
                        n = e.currentMonth,
                        i = e.currentYear,
                        a = e.hoursWidthOnXAxis,
                        r = e.numberOfDays,
                        s = new Y(this.ctx),
                        o = "day",
                        l = t.minDate + 1,
                        c = l,
                        u = function (e, t, n) {
                            return e > s.determineDaysOfMonths(t + 1, n) ? (c = 1, o = "month", h = t += 1, t) : t
                        },
                        d = (24 - t.minHour) * a,
                        h = l,
                        f = u(c, n, i);
                    0 === t.minHour && 1 === t.minDate ? (d = 0, h = p.monthMod(t.minMonth), o = "month", c = t.minDate, r++) : 1 !== t.minDate && 0 === t.minHour && 0 === t.minMinute && (d = 0, l = t.minDate, h = l, f = u(c = l, n, i)), this.timeScaleArray.push({
                        position: d,
                        value: h,
                        unit: o,
                        year: this._getYear(i, f, 0),
                        month: p.monthMod(f),
                        day: c
                    });
                    for (var m = d, g = 0; g < r; g++) {
                        o = "day", f = u(c += 1, f, this._getYear(i, f, 0));
                        var v = this._getYear(i, f, 0);
                        m = 24 * a + m;
                        var y = 1 === c ? p.monthMod(f) : c;
                        this.timeScaleArray.push({
                            position: m,
                            value: y,
                            unit: o,
                            year: v,
                            month: p.monthMod(f),
                            day: y
                        })
                    }
                }
            }, {
                key: "generateHourScale",
                value: function (e) {
                    var t = e.firstVal,
                        n = e.currentDate,
                        i = e.currentMonth,
                        a = e.currentYear,
                        r = e.minutesWidthOnXAxis,
                        s = e.numberOfHours,
                        o = new Y(this.ctx),
                        l = "hour",
                        c = function (e, t) {
                            return e > o.determineDaysOfMonths(t + 1, a) && (g = 1, t += 1), {
                                month: t,
                                date: g
                            }
                        },
                        u = function (e, t) {
                            return e > o.determineDaysOfMonths(t + 1, a) ? t += 1 : t
                        },
                        d = 60 - (t.minMinute + t.minSecond / 60),
                        h = d * r,
                        f = t.minHour + 1,
                        m = f + 1;
                    60 === d && (h = 0, m = (f = t.minHour) + 1);
                    var g = n,
                        v = u(g, i);
                    this.timeScaleArray.push({
                        position: h,
                        value: f,
                        unit: l,
                        day: g,
                        hour: m,
                        year: a,
                        month: p.monthMod(v)
                    });
                    for (var y = h, b = 0; b < s; b++) {
                        l = "hour", m >= 24 && (m = 0, l = "day", v = c(g += 1, v).month, v = u(g, v));
                        var x = this._getYear(a, v, 0);
                        y = 0 === m && 0 === b ? d * r : 60 * r + y;
                        var _ = 0 === m ? g : m;
                        this.timeScaleArray.push({
                            position: y,
                            value: _,
                            unit: l,
                            hour: m,
                            day: g,
                            year: x,
                            month: p.monthMod(v)
                        }), m++
                    }
                }
            }, {
                key: "generateMinuteScale",
                value: function (e) {
                    for (var t = e.currentMillisecond, n = e.currentSecond, i = e.currentMinute, a = e.currentHour, r = e.currentDate, s = e.currentMonth, o = e.currentYear, l = e.minutesWidthOnXAxis, c = e.secondsWidthOnXAxis, u = e.numberOfMinutes, d = i + 1, h = r, f = s, m = o, g = a, v = (60 - n - t / 1e3) * c, y = 0; y < u; y++) d >= 60 && (d = 0, 24 === (g += 1) && (g = 0)), this.timeScaleArray.push({
                        position: v,
                        value: d,
                        unit: "minute",
                        hour: g,
                        minute: d,
                        day: h,
                        year: this._getYear(m, f, 0),
                        month: p.monthMod(f)
                    }), v += l, d++
                }
            }, {
                key: "generateSecondScale",
                value: function (e) {
                    for (var t = e.currentMillisecond, n = e.currentSecond, i = e.currentMinute, a = e.currentHour, r = e.currentDate, s = e.currentMonth, o = e.currentYear, l = e.secondsWidthOnXAxis, c = e.numberOfSeconds, u = n + 1, d = i, h = r, f = s, m = o, g = a, v = (1e3 - t) / 1e3 * l, y = 0; y < c; y++) u >= 60 && (u = 0, ++d >= 60 && (d = 0, 24 == ++g && (g = 0))), this.timeScaleArray.push({
                        position: v,
                        value: u,
                        unit: "second",
                        hour: g,
                        minute: d,
                        second: u,
                        day: h,
                        year: this._getYear(m, f, 0),
                        month: p.monthMod(f)
                    }), v += l, u++
                }
            }, {
                key: "createRawDateString",
                value: function (e, t) {
                    var n = e.year;
                    return 0 === e.month && (e.month = 1), n += "-" + ("0" + e.month.toString()).slice(-2), "day" === e.unit ? n += "day" === e.unit ? "-" + ("0" + t).slice(-2) : "-01" : n += "-" + ("0" + (e.day ? e.day : "1")).slice(-2), "hour" === e.unit ? n += "hour" === e.unit ? "T" + ("0" + t).slice(-2) : "T00" : n += "T" + ("0" + (e.hour ? e.hour : "0")).slice(-2), "minute" === e.unit ? n += ":" + ("0" + t).slice(-2) : n += ":" + (e.minute ? ("0" + e.minute).slice(-2) : "00"), "second" === e.unit ? n += ":" + ("0" + t).slice(-2) : n += ":00", this.utc && (n += ".000Z"), n
                }
            }, {
                key: "formatDates",
                value: function (e) {
                    var t = this,
                        n = this.w;
                    return e.map((function (e) {
                        var i = e.value.toString(),
                            a = new Y(t.ctx),
                            r = t.createRawDateString(e, i),
                            s = a.getDate(a.parseDate(r));
                        if (t.utc || (s = a.getDate(a.parseDateWithTimezone(r))), void 0 === n.config.xaxis.labels.format) {
                            var o = "dd MMM",
                                l = n.config.xaxis.labels.datetimeFormatter;
                            "year" === e.unit && (o = l.year), "month" === e.unit && (o = l.month), "day" === e.unit && (o = l.day), "hour" === e.unit && (o = l.hour), "minute" === e.unit && (o = l.minute), "second" === e.unit && (o = l.second), i = a.formatDate(s, o)
                        } else i = a.formatDate(s, n.config.xaxis.labels.format);
                        return {
                            dateString: r,
                            position: e.position,
                            value: i,
                            unit: e.unit,
                            year: e.year,
                            month: e.month
                        }
                    }))
                }
            }, {
                key: "removeOverlappingTS",
                value: function (e) {
                    var t, n = this,
                        i = new v(this.ctx),
                        a = !1;
                    e.length > 0 && e[0].value && e.every((function (t) {
                        return t.value.length === e[0].value.length
                    })) && (a = !0, t = i.getTextRects(e[0].value).width);
                    var r = 0,
                        s = e.map((function (s, o) {
                            if (o > 0 && n.w.config.xaxis.labels.hideOverlappingLabels) {
                                var l = a ? t : i.getTextRects(e[r].value).width,
                                    c = e[r].position;
                                return s.position > c + l + 10 ? (r = o, s) : null
                            }
                            return s
                        }));
                    return s.filter((function (e) {
                        return null !== e
                    }))
                }
            }, {
                key: "_getYear",
                value: function (e, t, n) {
                    return e + Math.floor(t / 12) + n
                }
            }]), e
        }(),
        Oe = function () {
            function e(t, n) {
                i(this, e), this.ctx = n, this.w = n.w, this.el = t
            }
            return r(e, [{
                key: "setupElements",
                value: function () {
                    var e = this.w.globals,
                        t = this.w.config,
                        n = t.chart.type;
                    e.axisCharts = ["line", "area", "bar", "rangeBar", "candlestick", "boxPlot", "scatter", "bubble", "radar", "heatmap", "treemap"].indexOf(n) > -1, e.xyCharts = ["line", "area", "bar", "rangeBar", "candlestick", "boxPlot", "scatter", "bubble"].indexOf(n) > -1, e.isBarHorizontal = ("bar" === t.chart.type || "rangeBar" === t.chart.type || "boxPlot" === t.chart.type) && t.plotOptions.bar.horizontal, e.chartClass = ".apexcharts" + e.chartID, e.dom.baseEl = this.el, e.dom.elWrap = document.createElement("div"), v.setAttrs(e.dom.elWrap, {
                        id: e.chartClass.substring(1),
                        class: "apexcharts-canvas " + e.chartClass.substring(1)
                    }), this.el.appendChild(e.dom.elWrap), e.dom.Paper = new window.SVG.Doc(e.dom.elWrap), e.dom.Paper.attr({
                        class: "apexcharts-svg",
                        "xmlns:data": "ApexChartsNS",
                        transform: "translate(".concat(t.chart.offsetX, ", ").concat(t.chart.offsetY, ")")
                    }), e.dom.Paper.node.style.background = t.chart.background, this.setSVGDimensions(), e.dom.elGraphical = e.dom.Paper.group().attr({
                        class: "apexcharts-inner apexcharts-graphical"
                    }), e.dom.elAnnotations = e.dom.Paper.group().attr({
                        class: "apexcharts-annotations"
                    }), e.dom.elDefs = e.dom.Paper.defs(), e.dom.elLegendWrap = document.createElement("div"), e.dom.elLegendWrap.classList.add("apexcharts-legend"), e.dom.elWrap.appendChild(e.dom.elLegendWrap), e.dom.Paper.add(e.dom.elGraphical), e.dom.elGraphical.add(e.dom.elDefs)
                }
            }, {
                key: "plotChartType",
                value: function (e, t) {
                    var n = this.w,
                        i = n.config,
                        a = n.globals,
                        r = {
                            series: [],
                            i: []
                        },
                        s = {
                            series: [],
                            i: []
                        },
                        o = {
                            series: [],
                            i: []
                        },
                        l = {
                            series: [],
                            i: []
                        },
                        c = {
                            series: [],
                            i: []
                        },
                        u = {
                            series: [],
                            i: []
                        },
                        d = {
                            series: [],
                            i: []
                        };
                    a.series.map((function (t, h) {
                        var f = 0;
                        void 0 !== e[h].type ? ("column" === e[h].type || "bar" === e[h].type ? (a.series.length > 1 && i.plotOptions.bar.horizontal && console.warn("Horizontal bars are not supported in a mixed/combo chart. Please turn off `plotOptions.bar.horizontal`"), c.series.push(t), c.i.push(h), f++, n.globals.columnSeries = c.series) : "area" === e[h].type ? (s.series.push(t), s.i.push(h), f++) : "line" === e[h].type ? (r.series.push(t), r.i.push(h), f++) : "scatter" === e[h].type ? (o.series.push(t), o.i.push(h)) : "bubble" === e[h].type ? (l.series.push(t), l.i.push(h), f++) : "candlestick" === e[h].type ? (u.series.push(t), u.i.push(h), f++) : "boxPlot" === e[h].type ? (d.series.push(t), d.i.push(h), f++) : console.warn("You have specified an unrecognized chart type. Available types for this property are line/area/column/bar/scatter/bubble"), f > 1 && (a.comboCharts = !0)) : (r.series.push(t), r.i.push(h))
                    }));
                    var h = new Ae(this.ctx, t),
                        f = new be(this.ctx, t);
                    this.ctx.pie = new ke(this.ctx);
                    var p = new Le(this.ctx);
                    this.ctx.rangeBar = new I(this.ctx, t);
                    var m = new Me(this.ctx),
                        g = [];
                    if (a.comboCharts) {
                        if (s.series.length > 0 && g.push(h.draw(s.series, "area", s.i)), c.series.length > 0)
                            if (n.config.chart.stacked) {
                                var v = new ye(this.ctx, t);
                                g.push(v.draw(c.series, c.i))
                            } else this.ctx.bar = new P(this.ctx, t), g.push(this.ctx.bar.draw(c.series, c.i));
                        if (r.series.length > 0 && g.push(h.draw(r.series, "line", r.i)), u.series.length > 0 && g.push(f.draw(u.series, u.i)), d.series.length > 0 && g.push(f.draw(d.series, d.i)), o.series.length > 0) {
                            var y = new Ae(this.ctx, t, !0);
                            g.push(y.draw(o.series, "scatter", o.i))
                        }
                        if (l.series.length > 0) {
                            var b = new Ae(this.ctx, t, !0);
                            g.push(b.draw(l.series, "bubble", l.i))
                        }
                    } else switch (i.chart.type) {
                        case "line":
                            g = h.draw(a.series, "line");
                            break;
                        case "area":
                            g = h.draw(a.series, "area");
                            break;
                        case "bar":
                            i.chart.stacked ? g = new ye(this.ctx, t).draw(a.series) : (this.ctx.bar = new P(this.ctx, t), g = this.ctx.bar.draw(a.series));
                            break;
                        case "candlestick":
                        case "boxPlot":
                            g = new be(this.ctx, t).draw(a.series);
                            break;
                        case "rangeBar":
                            g = this.ctx.rangeBar.draw(a.series);
                            break;
                        case "heatmap":
                            g = new _e(this.ctx, t).draw(a.series);
                            break;
                        case "treemap":
                            g = new De(this.ctx, t).draw(a.series);
                            break;
                        case "pie":
                        case "donut":
                        case "polarArea":
                            g = this.ctx.pie.draw(a.series);
                            break;
                        case "radialBar":
                            g = p.draw(a.series);
                            break;
                        case "radar":
                            g = m.draw(a.series);
                            break;
                        default:
                            g = h.draw(a.series)
                    }
                    return g
                }
            }, {
                key: "setSVGDimensions",
                value: function () {
                    var e = this.w.globals,
                        t = this.w.config;
                    e.svgWidth = t.chart.width, e.svgHeight = t.chart.height;
                    var n = p.getDimensions(this.el),
                        i = t.chart.width.toString().split(/[0-9]+/g).pop();
                    "%" === i ? p.isNumber(n[0]) && (0 === n[0].width && (n = p.getDimensions(this.el.parentNode)), e.svgWidth = n[0] * parseInt(t.chart.width, 10) / 100) : "px" !== i && "" !== i || (e.svgWidth = parseInt(t.chart.width, 10));
                    var a = t.chart.height.toString().split(/[0-9]+/g).pop();
                    if ("auto" !== e.svgHeight && "" !== e.svgHeight)
                        if ("%" === a) {
                            var r = p.getDimensions(this.el.parentNode);
                            e.svgHeight = r[1] * parseInt(t.chart.height, 10) / 100
                        } else e.svgHeight = parseInt(t.chart.height, 10);
                    else e.axisCharts ? e.svgHeight = e.svgWidth / 1.61 : e.svgHeight = e.svgWidth / 1.2;
                    if (e.svgWidth < 0 && (e.svgWidth = 0), e.svgHeight < 0 && (e.svgHeight = 0), v.setAttrs(e.dom.Paper.node, {
                            width: e.svgWidth,
                            height: e.svgHeight
                        }), "%" !== a) {
                        var s = t.chart.sparkline.enabled ? 0 : e.axisCharts ? t.chart.parentHeightOffset : 0;
                        e.dom.Paper.node.parentNode.parentNode.style.minHeight = e.svgHeight + s + "px"
                    }
                    e.dom.elWrap.style.width = e.svgWidth + "px", e.dom.elWrap.style.height = e.svgHeight + "px"
                }
            }, {
                key: "shiftGraphPosition",
                value: function () {
                    var e = this.w.globals,
                        t = e.translateY,
                        n = {
                            transform: "translate(" + e.translateX + ", " + t + ")"
                        };
                    v.setAttrs(e.dom.elGraphical.node, n)
                }
            }, {
                key: "resizeNonAxisCharts",
                value: function () {
                    var e = this.w,
                        t = e.globals,
                        n = 0,
                        i = e.config.chart.sparkline.enabled ? 1 : 15;
                    i += e.config.grid.padding.bottom, "top" !== e.config.legend.position && "bottom" !== e.config.legend.position || !e.config.legend.show || e.config.legend.floating || (n = new le(this.ctx).legendHelpers.getLegendBBox().clwh + 10);
                    var a = e.globals.dom.baseEl.querySelector(".apexcharts-radialbar, .apexcharts-pie"),
                        r = 2.05 * e.globals.radialSize;
                    if (a && !e.config.chart.sparkline.enabled && 0 !== e.config.plotOptions.radialBar.startAngle) {
                        var s = p.getBoundingClientRect(a);
                        r = s.bottom;
                        var o = s.bottom - s.top;
                        r = Math.max(2.05 * e.globals.radialSize, o)
                    }
                    var l = r + t.translateY + n + i;
                    t.dom.elLegendForeign && t.dom.elLegendForeign.setAttribute("height", l), t.dom.elWrap.style.height = l + "px", v.setAttrs(t.dom.Paper.node, {
                        height: l
                    }), t.dom.Paper.node.parentNode.parentNode.style.minHeight = l + "px"
                }
            }, {
                key: "coreCalculations",
                value: function () {
                    new U(this.ctx).init()
                }
            }, {
                key: "resetGlobals",
                value: function () {
                    var e = this,
                        t = function () {
                            return e.w.config.series.map((function (e) {
                                return []
                            }))
                        },
                        n = new H,
                        i = this.w.globals;
                    n.initGlobalVars(i), i.seriesXvalues = t(), i.seriesYvalues = t()
                }
            }, {
                key: "isMultipleY",
                value: function () {
                    if (this.w.config.yaxis.constructor === Array && this.w.config.yaxis.length > 1) return this.w.globals.isMultipleYAxis = !0, !0
                }
            }, {
                key: "xySettings",
                value: function () {
                    var e = null,
                        t = this.w;
                    if (t.globals.axisCharts) {
                        if ("back" === t.config.xaxis.crosshairs.position && new J(this.ctx).drawXCrosshairs(), "back" === t.config.yaxis[0].crosshairs.position && new J(this.ctx).drawYCrosshairs(), "datetime" === t.config.xaxis.type && void 0 === t.config.xaxis.labels.formatter) {
                            this.ctx.timeScale = new Ee(this.ctx);
                            var n = [];
                            isFinite(t.globals.minX) && isFinite(t.globals.maxX) && !t.globals.isBarHorizontal ? n = this.ctx.timeScale.calculateTimeScaleTicks(t.globals.minX, t.globals.maxX) : t.globals.isBarHorizontal && (n = this.ctx.timeScale.calculateTimeScaleTicks(t.globals.minY, t.globals.maxY)), this.ctx.timeScale.recalcDimensionsBasedOnFormat(n)
                        }
                        e = new x(this.ctx).getCalculatedRatios()
                    }
                    return e
                }
            }, {
                key: "updateSourceChart",
                value: function (e) {
                    this.ctx.w.globals.selection = void 0, this.ctx.updateHelpers._updateOptions({
                        chart: {
                            selection: {
                                xaxis: {
                                    min: e.w.globals.minX,
                                    max: e.w.globals.maxX
                                }
                            }
                        }
                    }, !1, !1)
                }
            }, {
                key: "setupBrushHandler",
                value: function () {
                    var e = this,
                        n = this.w;
                    if (n.config.chart.brush.enabled && "function" != typeof n.config.chart.events.selection) {
                        var i = n.config.chart.brush.targets || [n.config.chart.brush.target];
                        i.forEach((function (t) {
                            var n = ApexCharts.getChartByID(t);
                            n.w.globals.brushSource = e.ctx, "function" != typeof n.w.config.chart.events.zoomed && (n.w.config.chart.events.zoomed = function () {
                                e.updateSourceChart(n)
                            }), "function" != typeof n.w.config.chart.events.scrolled && (n.w.config.chart.events.scrolled = function () {
                                e.updateSourceChart(n)
                            })
                        })), n.config.chart.events.selection = function (e, a) {
                            i.forEach((function (e) {
                                var i = ApexCharts.getChartByID(e),
                                    r = p.clone(n.config.yaxis);
                                if (n.config.chart.brush.autoScaleYaxis && 1 === i.w.globals.series.length) {
                                    var s = new X(i);
                                    r = s.autoScaleY(i, r, a)
                                }
                                var o = i.w.config.yaxis.reduce((function (e, n, a) {
                                    return [].concat(h(e), [t(t({}, i.w.config.yaxis[a]), {}, {
                                        min: r[0].min,
                                        max: r[0].max
                                    })])
                                }), []);
                                i.ctx.updateHelpers._updateOptions({
                                    xaxis: {
                                        min: a.xaxis.min,
                                        max: a.xaxis.max
                                    },
                                    yaxis: o
                                }, !1, !1, !1, !1)
                            }))
                        }
                    }
                }
            }]), e
        }(),
        Pe = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "_updateOptions",
                value: function (e) {
                    var t = this,
                        i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                        a = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
                        r = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
                        s = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
                    return new Promise((function (o) {
                        var l = [t.ctx];
                        r && (l = t.ctx.getSyncedCharts()), t.ctx.w.globals.isExecCalled && (l = [t.ctx], t.ctx.w.globals.isExecCalled = !1), l.forEach((function (r, c) {
                            var u = r.w;
                            return u.globals.shouldAnimate = a, i || (u.globals.resized = !0, u.globals.dataChanged = !0, a && r.series.getPreviousPaths()), e && "object" === n(e) && (r.config = new N(e), e = x.extendArrayProps(r.config, e, u), r.w.globals.chartID !== t.ctx.w.globals.chartID && delete e.series, u.config = p.extend(u.config, e), s && (u.globals.lastXAxis = e.xaxis ? p.clone(e.xaxis) : [], u.globals.lastYAxis = e.yaxis ? p.clone(e.yaxis) : [], u.globals.initialConfig = p.extend({}, u.config), u.globals.initialSeries = p.clone(u.config.series))), r.update(e).then((function () {
                                c === l.length - 1 && o(r)
                            }))
                        }))
                    }))
                }
            }, {
                key: "_updateSeries",
                value: function (e, t) {
                    var n = this,
                        i = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                    return new Promise((function (a) {
                        var r, s = n.w;
                        return s.globals.shouldAnimate = t, s.globals.dataChanged = !0, t && n.ctx.series.getPreviousPaths(), s.globals.axisCharts ? (0 === (r = e.map((function (e, t) {
                            return n._extendSeries(e, t)
                        }))).length && (r = [{
                            data: []
                        }]), s.config.series = r) : s.config.series = e.slice(), i && (s.globals.initialSeries = p.clone(s.config.series)), n.ctx.update().then((function () {
                            a(n.ctx)
                        }))
                    }))
                }
            }, {
                key: "_extendSeries",
                value: function (e, n) {
                    var i = this.w,
                        a = i.config.series[n];
                    return t(t({}, i.config.series[n]), {}, {
                        name: e.name ? e.name : a && a.name,
                        color: e.color ? e.color : a && a.color,
                        type: e.type ? e.type : a && a.type,
                        data: e.data ? e.data : a && a.data
                    })
                }
            }, {
                key: "toggleDataPointSelection",
                value: function (e, t) {
                    var n = this.w,
                        i = null,
                        a = ".apexcharts-series[data\\:realIndex='".concat(e, "']");
                    return n.globals.axisCharts ? i = n.globals.dom.Paper.select("".concat(a, " path[j='").concat(t, "'], ").concat(a, " circle[j='").concat(t, "'], ").concat(a, " rect[j='").concat(t, "']")).members[0] : void 0 === t && (i = n.globals.dom.Paper.select("".concat(a, " path[j='").concat(e, "']")).members[0], "pie" !== n.config.chart.type && "polarArea" !== n.config.chart.type && "donut" !== n.config.chart.type || this.ctx.pie.pieClicked(e)), i ? (new v(this.ctx).pathMouseDown(i, null), i.node ? i.node : null) : (console.warn("toggleDataPointSelection: Element not found"), null)
                }
            }, {
                key: "forceXAxisUpdate",
                value: function (e) {
                    var t = this.w;
                    if (["min", "max"].forEach((function (n) {
                            void 0 !== e.xaxis[n] && (t.config.xaxis[n] = e.xaxis[n], t.globals.lastXAxis[n] = e.xaxis[n])
                        })), e.xaxis.categories && e.xaxis.categories.length && (t.config.xaxis.categories = e.xaxis.categories), t.config.xaxis.convertedCatToNumeric) {
                        var n = new j(e);
                        e = n.convertCatToNumericXaxis(e, this.ctx)
                    }
                    return e
                }
            }, {
                key: "forceYAxisUpdate",
                value: function (e) {
                    var t = this.w;
                    return t.config.chart.stacked && "100%" === t.config.chart.stackType && (Array.isArray(e.yaxis) ? e.yaxis.forEach((function (t, n) {
                        e.yaxis[n].min = 0, e.yaxis[n].max = 100
                    })) : (e.yaxis.min = 0, e.yaxis.max = 100)), e
                }
            }, {
                key: "revertDefaultAxisMinMax",
                value: function (e) {
                    var t = this,
                        n = this.w,
                        i = n.globals.lastXAxis,
                        a = n.globals.lastYAxis;
                    e && e.xaxis && (i = e.xaxis), e && e.yaxis && (a = e.yaxis), n.config.xaxis.min = i.min, n.config.xaxis.max = i.max;
                    n.config.yaxis.map((function (e, i) {
                        n.globals.zoomed || void 0 !== a[i] ? function (e) {
                            void 0 !== a[e] && (n.config.yaxis[e].min = a[e].min, n.config.yaxis[e].max = a[e].max)
                        }(i) : void 0 !== t.ctx.opts.yaxis[i] && (e.min = t.ctx.opts.yaxis[i].min, e.max = t.ctx.opts.yaxis[i].max)
                    }))
                }
            }]), e
        }();
    Te = "undefined" != typeof window ? window : void 0, Ce = function (e, t) {
            var i = (void 0 !== this ? this : e).SVG = function (e) {
                if (i.supported) return e = new i.Doc(e), i.parser.draw || i.prepare(), e
            };
            if (i.ns = "http://www.w3.org/2000/svg", i.xmlns = "http://www.w3.org/2000/xmlns/", i.xlink = "http://www.w3.org/1999/xlink", i.svgjs = "http://svgjs.dev", i.supported = !0, !i.supported) return !1;
            i.did = 1e3, i.eid = function (e) {
                return "Svgjs" + d(e) + i.did++
            }, i.create = function (e) {
                var n = t.createElementNS(this.ns, e);
                return n.setAttribute("id", this.eid(e)), n
            }, i.extend = function () {
                var e, t;
                t = (e = [].slice.call(arguments)).pop();
                for (var n = e.length - 1; n >= 0; n--)
                    if (e[n])
                        for (var a in t) e[n].prototype[a] = t[a];
                i.Set && i.Set.inherit && i.Set.inherit()
            }, i.invent = function (e) {
                var t = "function" == typeof e.create ? e.create : function () {
                    this.constructor.call(this, i.create(e.create))
                };
                return e.inherit && (t.prototype = new e.inherit), e.extend && i.extend(t, e.extend), e.construct && i.extend(e.parent || i.Container, e.construct), t
            }, i.adopt = function (t) {
                return t ? t.instance ? t.instance : ((n = "svg" == t.nodeName ? t.parentNode instanceof e.SVGElement ? new i.Nested : new i.Doc : "linearGradient" == t.nodeName ? new i.Gradient("linear") : "radialGradient" == t.nodeName ? new i.Gradient("radial") : i[d(t.nodeName)] ? new(i[d(t.nodeName)]) : new i.Element(t)).type = t.nodeName, n.node = t, t.instance = n, n instanceof i.Doc && n.namespace().defs(), n.setData(JSON.parse(t.getAttribute("svgjs:data")) || {}), n) : null;
                var n
            }, i.prepare = function () {
                var e = t.getElementsByTagName("body")[0],
                    n = (e ? new i.Doc(e) : i.adopt(t.documentElement).nested()).size(2, 0);
                i.parser = {
                    body: e || t.documentElement,
                    draw: n.style("opacity:0;position:absolute;left:-100%;top:-100%;overflow:hidden").node,
                    poly: n.polyline().node,
                    path: n.path().node,
                    native: i.create("svg")
                }
            }, i.parser = {
                native: i.create("svg")
            }, t.addEventListener("DOMContentLoaded", (function () {
                i.parser.draw || i.prepare()
            }), !1), i.regex = {
                numberAndUnit: /^([+-]?(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?)([a-z%]*)$/i,
                hex: /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i,
                rgb: /rgb\((\d+),(\d+),(\d+)\)/,
                reference: /#([a-z0-9\-_]+)/i,
                transforms: /\)\s*,?\s*/,
                whitespace: /\s/g,
                isHex: /^#[a-f0-9]{3,6}$/i,
                isRgb: /^rgb\(/,
                isCss: /[^:]+:[^;]+;?/,
                isBlank: /^(\s+)?$/,
                isNumber: /^[+-]?(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i,
                isPercent: /^-?[\d\.]+%$/,
                isImage: /\.(jpg|jpeg|png|gif|svg)(\?[^=]+.*)?/i,
                delimiter: /[\s,]+/,
                hyphen: /([^e])\-/gi,
                pathLetters: /[MLHVCSQTAZ]/gi,
                isPathLetter: /[MLHVCSQTAZ]/i,
                numbersWithDots: /((\d?\.\d+(?:e[+-]?\d+)?)((?:\.\d+(?:e[+-]?\d+)?)+))+/gi,
                dots: /\./g
            }, i.utils = {
                map: function (e, t) {
                    for (var n = e.length, i = [], a = 0; a < n; a++) i.push(t(e[a]));
                    return i
                },
                filter: function (e, t) {
                    for (var n = e.length, i = [], a = 0; a < n; a++) t(e[a]) && i.push(e[a]);
                    return i
                },
                filterSVGElements: function (t) {
                    return this.filter(t, (function (t) {
                        return t instanceof e.SVGElement
                    }))
                }
            }, i.defaults = {
                attrs: {
                    "fill-opacity": 1,
                    "stroke-opacity": 1,
                    "stroke-width": 0,
                    "stroke-linejoin": "miter",
                    "stroke-linecap": "butt",
                    fill: "#000000",
                    stroke: "#000000",
                    opacity: 1,
                    x: 0,
                    y: 0,
                    cx: 0,
                    cy: 0,
                    width: 0,
                    height: 0,
                    r: 0,
                    rx: 0,
                    ry: 0,
                    offset: 0,
                    "stop-opacity": 1,
                    "stop-color": "#000000",
                    "font-size": 16,
                    "font-family": "Helvetica, Arial, sans-serif",
                    "text-anchor": "start"
                }
            }, i.Color = function (e) {
                var t, a;
                this.r = 0, this.g = 0, this.b = 0, e && ("string" == typeof e ? i.regex.isRgb.test(e) ? (t = i.regex.rgb.exec(e.replace(i.regex.whitespace, "")), this.r = parseInt(t[1]), this.g = parseInt(t[2]), this.b = parseInt(t[3])) : i.regex.isHex.test(e) && (t = i.regex.hex.exec(4 == (a = e).length ? ["#", a.substring(1, 2), a.substring(1, 2), a.substring(2, 3), a.substring(2, 3), a.substring(3, 4), a.substring(3, 4)].join("") : a), this.r = parseInt(t[1], 16), this.g = parseInt(t[2], 16), this.b = parseInt(t[3], 16)) : "object" === n(e) && (this.r = e.r, this.g = e.g, this.b = e.b))
            }, i.extend(i.Color, {
                toString: function () {
                    return this.toHex()
                },
                toHex: function () {
                    return "#" + h(this.r) + h(this.g) + h(this.b)
                },
                toRgb: function () {
                    return "rgb(" + [this.r, this.g, this.b].join() + ")"
                },
                brightness: function () {
                    return this.r / 255 * .3 + this.g / 255 * .59 + this.b / 255 * .11
                },
                morph: function (e) {
                    return this.destination = new i.Color(e), this
                },
                at: function (e) {
                    return this.destination ? (e = e < 0 ? 0 : e > 1 ? 1 : e, new i.Color({
                        r: ~~(this.r + (this.destination.r - this.r) * e),
                        g: ~~(this.g + (this.destination.g - this.g) * e),
                        b: ~~(this.b + (this.destination.b - this.b) * e)
                    })) : this
                }
            }), i.Color.test = function (e) {
                return e += "", i.regex.isHex.test(e) || i.regex.isRgb.test(e)
            }, i.Color.isRgb = function (e) {
                return e && "number" == typeof e.r && "number" == typeof e.g && "number" == typeof e.b
            }, i.Color.isColor = function (e) {
                return i.Color.isRgb(e) || i.Color.test(e)
            }, i.Array = function (e, t) {
                0 == (e = (e || []).valueOf()).length && t && (e = t.valueOf()), this.value = this.parse(e)
            }, i.extend(i.Array, {
                toString: function () {
                    return this.value.join(" ")
                },
                valueOf: function () {
                    return this.value
                },
                parse: function (e) {
                    return e = e.valueOf(), Array.isArray(e) ? e : this.split(e)
                }
            }), i.PointArray = function (e, t) {
                i.Array.call(this, e, t || [
                    [0, 0]
                ])
            }, i.PointArray.prototype = new i.Array, i.PointArray.prototype.constructor = i.PointArray;
            for (var a = {
                    M: function (e, t, n) {
                        return t.x = n.x = e[0], t.y = n.y = e[1], ["M", t.x, t.y]
                    },
                    L: function (e, t) {
                        return t.x = e[0], t.y = e[1], ["L", e[0], e[1]]
                    },
                    H: function (e, t) {
                        return t.x = e[0], ["H", e[0]]
                    },
                    V: function (e, t) {
                        return t.y = e[0], ["V", e[0]]
                    },
                    C: function (e, t) {
                        return t.x = e[4], t.y = e[5], ["C", e[0], e[1], e[2], e[3], e[4], e[5]]
                    },
                    Q: function (e, t) {
                        return t.x = e[2], t.y = e[3], ["Q", e[0], e[1], e[2], e[3]]
                    },
                    Z: function (e, t, n) {
                        return t.x = n.x, t.y = n.y, ["Z"]
                    }
                }, r = "mlhvqtcsaz".split(""), s = 0, o = r.length; s < o; ++s) a[r[s]] = function (e) {
                return function (t, n, i) {
                    if ("H" == e) t[0] = t[0] + n.x;
                    else if ("V" == e) t[0] = t[0] + n.y;
                    else if ("A" == e) t[5] = t[5] + n.x, t[6] = t[6] + n.y;
                    else
                        for (var r = 0, s = t.length; r < s; ++r) t[r] = t[r] + (r % 2 ? n.y : n.x);
                    if (a && "function" == typeof a[e]) return a[e](t, n, i)
                }
            }(r[s].toUpperCase());
            i.PathArray = function (e, t) {
                i.Array.call(this, e, t || [
                    ["M", 0, 0]
                ])
            }, i.PathArray.prototype = new i.Array, i.PathArray.prototype.constructor = i.PathArray, i.extend(i.PathArray, {
                toString: function () {
                    return function (e) {
                        for (var t = 0, n = e.length, i = ""; t < n; t++) i += e[t][0], null != e[t][1] && (i += e[t][1], null != e[t][2] && (i += " ", i += e[t][2], null != e[t][3] && (i += " ", i += e[t][3], i += " ", i += e[t][4], null != e[t][5] && (i += " ", i += e[t][5], i += " ", i += e[t][6], null != e[t][7] && (i += " ", i += e[t][7])))));
                        return i + " "
                    }(this.value)
                },
                move: function (e, t) {
                    var n = this.bbox();
                    return n.x, n.y, this
                },
                at: function (e) {
                    if (!this.destination) return this;
                    for (var t = this.value, n = this.destination.value, a = [], r = new i.PathArray, s = 0, o = t.length; s < o; s++) {
                        a[s] = [t[s][0]];
                        for (var l = 1, c = t[s].length; l < c; l++) a[s][l] = t[s][l] + (n[s][l] - t[s][l]) * e;
                        "A" === a[s][0] && (a[s][4] = +(0 != a[s][4]), a[s][5] = +(0 != a[s][5]))
                    }
                    return r.value = a, r
                },
                parse: function (e) {
                    if (e instanceof i.PathArray) return e.valueOf();
                    var t, n = {
                        M: 2,
                        L: 2,
                        H: 1,
                        V: 1,
                        C: 6,
                        S: 4,
                        Q: 4,
                        T: 2,
                        A: 7,
                        Z: 0
                    };
                    e = "string" == typeof e ? e.replace(i.regex.numbersWithDots, c).replace(i.regex.pathLetters, " $& ").replace(i.regex.hyphen, "$1 -").trim().split(i.regex.delimiter) : e.reduce((function (e, t) {
                        return [].concat.call(e, t)
                    }), []);
                    var r = [],
                        s = new i.Point,
                        o = new i.Point,
                        l = 0,
                        u = e.length;
                    do {
                        i.regex.isPathLetter.test(e[l]) ? (t = e[l], ++l) : "M" == t ? t = "L" : "m" == t && (t = "l"), r.push(a[t].call(null, e.slice(l, l += n[t.toUpperCase()]).map(parseFloat), s, o))
                    } while (u > l);
                    return r
                },
                bbox: function () {
                    return i.parser.draw || i.prepare(), i.parser.path.setAttribute("d", this.toString()), i.parser.path.getBBox()
                }
            }), i.Number = i.invent({
                create: function (e, t) {
                    this.value = 0, this.unit = t || "", "number" == typeof e ? this.value = isNaN(e) ? 0 : isFinite(e) ? e : e < 0 ? -34e37 : 34e37 : "string" == typeof e ? (t = e.match(i.regex.numberAndUnit)) && (this.value = parseFloat(t[1]), "%" == t[5] ? this.value /= 100 : "s" == t[5] && (this.value *= 1e3), this.unit = t[5]) : e instanceof i.Number && (this.value = e.valueOf(), this.unit = e.unit)
                },
                extend: {
                    toString: function () {
                        return ("%" == this.unit ? ~~(1e8 * this.value) / 1e6 : "s" == this.unit ? this.value / 1e3 : this.value) + this.unit
                    },
                    toJSON: function () {
                        return this.toString()
                    },
                    valueOf: function () {
                        return this.value
                    },
                    plus: function (e) {
                        return e = new i.Number(e), new i.Number(this + e, this.unit || e.unit)
                    },
                    minus: function (e) {
                        return e = new i.Number(e), new i.Number(this - e, this.unit || e.unit)
                    },
                    times: function (e) {
                        return e = new i.Number(e), new i.Number(this * e, this.unit || e.unit)
                    },
                    divide: function (e) {
                        return e = new i.Number(e), new i.Number(this / e, this.unit || e.unit)
                    },
                    to: function (e) {
                        var t = new i.Number(this);
                        return "string" == typeof e && (t.unit = e), t
                    },
                    morph: function (e) {
                        return this.destination = new i.Number(e), e.relative && (this.destination.value += this.value), this
                    },
                    at: function (e) {
                        return this.destination ? new i.Number(this.destination).minus(this).times(e).plus(this) : this
                    }
                }
            }), i.Element = i.invent({
                create: function (e) {
                    this._stroke = i.defaults.attrs.stroke, this._event = null, this.dom = {}, (this.node = e) && (this.type = e.nodeName, this.node.instance = this, this._stroke = e.getAttribute("stroke") || this._stroke)
                },
                extend: {
                    x: function (e) {
                        return this.attr("x", e)
                    },
                    y: function (e) {
                        return this.attr("y", e)
                    },
                    cx: function (e) {
                        return null == e ? this.x() + this.width() / 2 : this.x(e - this.width() / 2)
                    },
                    cy: function (e) {
                        return null == e ? this.y() + this.height() / 2 : this.y(e - this.height() / 2)
                    },
                    move: function (e, t) {
                        return this.x(e).y(t)
                    },
                    center: function (e, t) {
                        return this.cx(e).cy(t)
                    },
                    width: function (e) {
                        return this.attr("width", e)
                    },
                    height: function (e) {
                        return this.attr("height", e)
                    },
                    size: function (e, t) {
                        var n = f(this, e, t);
                        return this.width(new i.Number(n.width)).height(new i.Number(n.height))
                    },
                    clone: function (e) {
                        this.writeDataToDom();
                        var t = g(this.node.cloneNode(!0));
                        return e ? e.add(t) : this.after(t), t
                    },
                    remove: function () {
                        return this.parent() && this.parent().removeElement(this), this
                    },
                    replace: function (e) {
                        return this.after(e).remove(), e
                    },
                    addTo: function (e) {
                        return e.put(this)
                    },
                    putIn: function (e) {
                        return e.add(this)
                    },
                    id: function (e) {
                        return this.attr("id", e)
                    },
                    show: function () {
                        return this.style("display", "")
                    },
                    hide: function () {
                        return this.style("display", "none")
                    },
                    visible: function () {
                        return "none" != this.style("display")
                    },
                    toString: function () {
                        return this.attr("id")
                    },
                    classes: function () {
                        var e = this.attr("class");
                        return null == e ? [] : e.trim().split(i.regex.delimiter)
                    },
                    hasClass: function (e) {
                        return -1 != this.classes().indexOf(e)
                    },
                    addClass: function (e) {
                        if (!this.hasClass(e)) {
                            var t = this.classes();
                            t.push(e), this.attr("class", t.join(" "))
                        }
                        return this
                    },
                    removeClass: function (e) {
                        return this.hasClass(e) && this.attr("class", this.classes().filter((function (t) {
                            return t != e
                        })).join(" ")), this
                    },
                    toggleClass: function (e) {
                        return this.hasClass(e) ? this.removeClass(e) : this.addClass(e)
                    },
                    reference: function (e) {
                        return i.get(this.attr(e))
                    },
                    parent: function (t) {
                        var n = this;
                        if (!n.node.parentNode) return null;
                        if (n = i.adopt(n.node.parentNode), !t) return n;
                        for (; n && n.node instanceof e.SVGElement;) {
                            if ("string" == typeof t ? n.matches(t) : n instanceof t) return n;
                            if (!n.node.parentNode || "#document" == n.node.parentNode.nodeName) return null;
                            n = i.adopt(n.node.parentNode)
                        }
                    },
                    doc: function () {
                        return this instanceof i.Doc ? this : this.parent(i.Doc)
                    },
                    parents: function (e) {
                        var t = [],
                            n = this;
                        do {
                            if (!(n = n.parent(e)) || !n.node) break;
                            t.push(n)
                        } while (n.parent);
                        return t
                    },
                    matches: function (e) {
                        return function (e, t) {
                            return (e.matches || e.matchesSelector || e.msMatchesSelector || e.mozMatchesSelector || e.webkitMatchesSelector || e.oMatchesSelector).call(e, t)
                        }(this.node, e)
                    },
                    native: function () {
                        return this.node
                    },
                    svg: function (e) {
                        var n = t.createElement("svg");
                        if (!(e && this instanceof i.Parent)) return n.appendChild(e = t.createElement("svg")), this.writeDataToDom(), e.appendChild(this.node.cloneNode(!0)), n.innerHTML.replace(/^<svg>/, "").replace(/<\/svg>$/, "");
                        n.innerHTML = "<svg>" + e.replace(/\n/, "").replace(/<([\w:-]+)([^<]+?)\/>/g, "<$1$2></$1>") + "</svg>";
                        for (var a = 0, r = n.firstChild.childNodes.length; a < r; a++) this.node.appendChild(n.firstChild.firstChild);
                        return this
                    },
                    writeDataToDom: function () {
                        return (this.each || this.lines) && (this.each ? this : this.lines()).each((function () {
                            this.writeDataToDom()
                        })), this.node.removeAttribute("svgjs:data"), Object.keys(this.dom).length && this.node.setAttribute("svgjs:data", JSON.stringify(this.dom)), this
                    },
                    setData: function (e) {
                        return this.dom = e, this
                    },
                    is: function (e) {
                        return function (e, t) {
                            return e instanceof t
                        }(this, e)
                    }
                }
            }), i.easing = {
                "-": function (e) {
                    return e
                },
                "<>": function (e) {
                    return -Math.cos(e * Math.PI) / 2 + .5
                },
                ">": function (e) {
                    return Math.sin(e * Math.PI / 2)
                },
                "<": function (e) {
                    return 1 - Math.cos(e * Math.PI / 2)
                }
            }, i.morph = function (e) {
                return function (t, n) {
                    return new i.MorphObj(t, n).at(e)
                }
            }, i.Situation = i.invent({
                create: function (e) {
                    this.init = !1, this.reversed = !1, this.reversing = !1, this.duration = new i.Number(e.duration).valueOf(), this.delay = new i.Number(e.delay).valueOf(), this.start = +new Date + this.delay, this.finish = this.start + this.duration, this.ease = e.ease, this.loop = 0, this.loops = !1, this.animations = {}, this.attrs = {}, this.styles = {}, this.transforms = [], this.once = {}
                }
            }), i.FX = i.invent({
                create: function (e) {
                    this._target = e, this.situations = [], this.active = !1, this.situation = null, this.paused = !1, this.lastPos = 0, this.pos = 0, this.absPos = 0, this._speed = 1
                },
                extend: {
                    animate: function (e, t, a) {
                        "object" === n(e) && (t = e.ease, a = e.delay, e = e.duration);
                        var r = new i.Situation({
                            duration: e || 1e3,
                            delay: a || 0,
                            ease: i.easing[t || "-"] || t
                        });
                        return this.queue(r), this
                    },
                    target: function (e) {
                        return e && e instanceof i.Element ? (this._target = e, this) : this._target
                    },
                    timeToAbsPos: function (e) {
                        return (e - this.situation.start) / (this.situation.duration / this._speed)
                    },
                    absPosToTime: function (e) {
                        return this.situation.duration / this._speed * e + this.situation.start
                    },
                    startAnimFrame: function () {
                        this.stopAnimFrame(), this.animationFrame = e.requestAnimationFrame(function () {
                            this.step()
                        }.bind(this))
                    },
                    stopAnimFrame: function () {
                        e.cancelAnimationFrame(this.animationFrame)
                    },
                    start: function () {
                        return !this.active && this.situation && (this.active = !0, this.startCurrent()), this
                    },
                    startCurrent: function () {
                        return this.situation.start = +new Date + this.situation.delay / this._speed, this.situation.finish = this.situation.start + this.situation.duration / this._speed, this.initAnimations().step()
                    },
                    queue: function (e) {
                        return ("function" == typeof e || e instanceof i.Situation) && this.situations.push(e), this.situation || (this.situation = this.situations.shift()), this
                    },
                    dequeue: function () {
                        return this.stop(), this.situation = this.situations.shift(), this.situation && (this.situation instanceof i.Situation ? this.start() : this.situation.call(this)), this
                    },
                    initAnimations: function () {
                        var e, t = this.situation;
                        if (t.init) return this;
                        for (var n in t.animations) {
                            e = this.target()[n](), Array.isArray(e) || (e = [e]), Array.isArray(t.animations[n]) || (t.animations[n] = [t.animations[n]]);
                            for (var a = e.length; a--;) t.animations[n][a] instanceof i.Number && (e[a] = new i.Number(e[a])), t.animations[n][a] = e[a].morph(t.animations[n][a])
                        }
                        for (var n in t.attrs) t.attrs[n] = new i.MorphObj(this.target().attr(n), t.attrs[n]);
                        for (var n in t.styles) t.styles[n] = new i.MorphObj(this.target().style(n), t.styles[n]);
                        return t.initialTransformation = this.target().matrixify(), t.init = !0, this
                    },
                    clearQueue: function () {
                        return this.situations = [], this
                    },
                    clearCurrent: function () {
                        return this.situation = null, this
                    },
                    stop: function (e, t) {
                        var n = this.active;
                        return this.active = !1, t && this.clearQueue(), e && this.situation && (!n && this.startCurrent(), this.atEnd()), this.stopAnimFrame(), this.clearCurrent()
                    },
                    after: function (e) {
                        var t = this.last();
                        return this.target().on("finished.fx", (function n(i) {
                            i.detail.situation == t && (e.call(this, t), this.off("finished.fx", n))
                        })), this._callStart()
                    },
                    during: function (e) {
                        var t = this.last(),
                            n = function (n) {
                                n.detail.situation == t && e.call(this, n.detail.pos, i.morph(n.detail.pos), n.detail.eased, t)
                            };
                        return this.target().off("during.fx", n).on("during.fx", n), this.after((function () {
                            this.off("during.fx", n)
                        })), this._callStart()
                    },
                    afterAll: function (e) {
                        var t = function t(n) {
                            e.call(this), this.off("allfinished.fx", t)
                        };
                        return this.target().off("allfinished.fx", t).on("allfinished.fx", t), this._callStart()
                    },
                    last: function () {
                        return this.situations.length ? this.situations[this.situations.length - 1] : this.situation
                    },
                    add: function (e, t, n) {
                        return this.last()[n || "animations"][e] = t, this._callStart()
                    },
                    step: function (e) {
                        var t, n, i;
                        e || (this.absPos = this.timeToAbsPos(+new Date)), !1 !== this.situation.loops ? (t = Math.max(this.absPos, 0), n = Math.floor(t), !0 === this.situation.loops || n < this.situation.loops ? (this.pos = t - n, i = this.situation.loop, this.situation.loop = n) : (this.absPos = this.situation.loops, this.pos = 1, i = this.situation.loop - 1, this.situation.loop = this.situation.loops), this.situation.reversing && (this.situation.reversed = this.situation.reversed != Boolean((this.situation.loop - i) % 2))) : (this.absPos = Math.min(this.absPos, 1), this.pos = this.absPos), this.pos < 0 && (this.pos = 0), this.situation.reversed && (this.pos = 1 - this.pos);
                        var a = this.situation.ease(this.pos);
                        for (var r in this.situation.once) r > this.lastPos && r <= a && (this.situation.once[r].call(this.target(), this.pos, a), delete this.situation.once[r]);
                        return this.active && this.target().fire("during", {
                            pos: this.pos,
                            eased: a,
                            fx: this,
                            situation: this.situation
                        }), this.situation ? (this.eachAt(), 1 == this.pos && !this.situation.reversed || this.situation.reversed && 0 == this.pos ? (this.stopAnimFrame(), this.target().fire("finished", {
                            fx: this,
                            situation: this.situation
                        }), this.situations.length || (this.target().fire("allfinished"), this.situations.length || (this.target().off(".fx"), this.active = !1)), this.active ? this.dequeue() : this.clearCurrent()) : !this.paused && this.active && this.startAnimFrame(), this.lastPos = a, this) : this
                    },
                    eachAt: function () {
                        var e, t = this,
                            n = this.target(),
                            a = this.situation;
                        for (var r in a.animations) e = [].concat(a.animations[r]).map((function (e) {
                            return "string" != typeof e && e.at ? e.at(a.ease(t.pos), t.pos) : e
                        })), n[r].apply(n, e);
                        for (var r in a.attrs) e = [r].concat(a.attrs[r]).map((function (e) {
                            return "string" != typeof e && e.at ? e.at(a.ease(t.pos), t.pos) : e
                        })), n.attr.apply(n, e);
                        for (var r in a.styles) e = [r].concat(a.styles[r]).map((function (e) {
                            return "string" != typeof e && e.at ? e.at(a.ease(t.pos), t.pos) : e
                        })), n.style.apply(n, e);
                        if (a.transforms.length) {
                            e = a.initialTransformation, r = 0;
                            for (var s = a.transforms.length; r < s; r++) {
                                var o = a.transforms[r];
                                o instanceof i.Matrix ? e = o.relative ? e.multiply((new i.Matrix).morph(o).at(a.ease(this.pos))) : e.morph(o).at(a.ease(this.pos)) : (o.relative || o.undo(e.extract()), e = e.multiply(o.at(a.ease(this.pos))))
                            }
                            n.matrix(e)
                        }
                        return this
                    },
                    once: function (e, t, n) {
                        var i = this.last();
                        return n || (e = i.ease(e)), i.once[e] = t, this
                    },
                    _callStart: function () {
                        return setTimeout(function () {
                            this.start()
                        }.bind(this), 0), this
                    }
                },
                parent: i.Element,
                construct: {
                    animate: function (e, t, n) {
                        return (this.fx || (this.fx = new i.FX(this))).animate(e, t, n)
                    },
                    delay: function (e) {
                        return (this.fx || (this.fx = new i.FX(this))).delay(e)
                    },
                    stop: function (e, t) {
                        return this.fx && this.fx.stop(e, t), this
                    },
                    finish: function () {
                        return this.fx && this.fx.finish(), this
                    }
                }
            }), i.MorphObj = i.invent({
                create: function (e, t) {
                    return i.Color.isColor(t) ? new i.Color(e).morph(t) : i.regex.delimiter.test(e) ? i.regex.pathLetters.test(e) ? new i.PathArray(e).morph(t) : new i.Array(e).morph(t) : i.regex.numberAndUnit.test(t) ? new i.Number(e).morph(t) : (this.value = e, void(this.destination = t))
                },
                extend: {
                    at: function (e, t) {
                        return t < 1 ? this.value : this.destination
                    },
                    valueOf: function () {
                        return this.value
                    }
                }
            }), i.extend(i.FX, {
                attr: function (e, t, i) {
                    if ("object" === n(e))
                        for (var a in e) this.attr(a, e[a]);
                    else this.add(e, t, "attrs");
                    return this
                },
                plot: function (e, t, n, i) {
                    return 4 == arguments.length ? this.plot([e, t, n, i]) : this.add("plot", new(this.target().morphArray)(e))
                }
            }), i.Box = i.invent({
                create: function (e, t, a, r) {
                    if (!("object" !== n(e) || e instanceof i.Element)) return i.Box.call(this, null != e.left ? e.left : e.x, null != e.top ? e.top : e.y, e.width, e.height);
                    4 == arguments.length && (this.x = e, this.y = t, this.width = a, this.height = r), v(this)
                }
            }), i.BBox = i.invent({
                create: function (e) {
                    if (i.Box.apply(this, [].slice.call(arguments)), e instanceof i.Element) {
                        var n;
                        try {
                            if (!t.documentElement.contains) {
                                for (var a = e.node; a.parentNode;) a = a.parentNode;
                                if (a != t) throw new Error("Element not in the dom")
                            }
                            n = e.node.getBBox()
                        } catch (t) {
                            if (e instanceof i.Shape) {
                                i.parser.draw || i.prepare();
                                var r = e.clone(i.parser.draw.instance).show();
                                r && r.node && "function" == typeof r.node.getBBox && (n = r.node.getBBox()), r && "function" == typeof r.remove && r.remove()
                            } else n = {
                                x: e.node.clientLeft,
                                y: e.node.clientTop,
                                width: e.node.clientWidth,
                                height: e.node.clientHeight
                            }
                        }
                        i.Box.call(this, n)
                    }
                },
                inherit: i.Box,
                parent: i.Element,
                construct: {
                    bbox: function () {
                        return new i.BBox(this)
                    }
                }
            }), i.BBox.prototype.constructor = i.BBox, i.Matrix = i.invent({
                create: function (e) {
                    var t = m([1, 0, 0, 1, 0, 0]);
                    e = null === e ? t : e instanceof i.Element ? e.matrixify() : "string" == typeof e ? m(e.split(i.regex.delimiter).map(parseFloat)) : 6 == arguments.length ? m([].slice.call(arguments)) : Array.isArray(e) ? m(e) : e && "object" === n(e) ? e : t;
                    for (var a = b.length - 1; a >= 0; --a) this[b[a]] = null != e[b[a]] ? e[b[a]] : t[b[a]]
                },
                extend: {
                    extract: function () {
                        var e = p(this, 0, 1);
                        p(this, 1, 0);
                        var t = 180 / Math.PI * Math.atan2(e.y, e.x) - 90;
                        return {
                            x: this.e,
                            y: this.f,
                            transformedX: (this.e * Math.cos(t * Math.PI / 180) + this.f * Math.sin(t * Math.PI / 180)) / Math.sqrt(this.a * this.a + this.b * this.b),
                            transformedY: (this.f * Math.cos(t * Math.PI / 180) + this.e * Math.sin(-t * Math.PI / 180)) / Math.sqrt(this.c * this.c + this.d * this.d),
                            rotation: t,
                            a: this.a,
                            b: this.b,
                            c: this.c,
                            d: this.d,
                            e: this.e,
                            f: this.f,
                            matrix: new i.Matrix(this)
                        }
                    },
                    clone: function () {
                        return new i.Matrix(this)
                    },
                    morph: function (e) {
                        return this.destination = new i.Matrix(e), this
                    },
                    multiply: function (e) {
                        return new i.Matrix(this.native().multiply(function (e) {
                            return e instanceof i.Matrix || (e = new i.Matrix(e)), e
                        }(e).native()))
                    },
                    inverse: function () {
                        return new i.Matrix(this.native().inverse())
                    },
                    translate: function (e, t) {
                        return new i.Matrix(this.native().translate(e || 0, t || 0))
                    },
                    native: function () {
                        for (var e = i.parser.native.createSVGMatrix(), t = b.length - 1; t >= 0; t--) e[b[t]] = this[b[t]];
                        return e
                    },
                    toString: function () {
                        return "matrix(" + y(this.a) + "," + y(this.b) + "," + y(this.c) + "," + y(this.d) + "," + y(this.e) + "," + y(this.f) + ")"
                    }
                },
                parent: i.Element,
                construct: {
                    ctm: function () {
                        return new i.Matrix(this.node.getCTM())
                    },
                    screenCTM: function () {
                        if (this instanceof i.Nested) {
                            var e = this.rect(1, 1),
                                t = e.node.getScreenCTM();
                            return e.remove(), new i.Matrix(t)
                        }
                        return new i.Matrix(this.node.getScreenCTM())
                    }
                }
            }), i.Point = i.invent({
                create: function (e, t) {
                    var i;
                    i = Array.isArray(e) ? {
                        x: e[0],
                        y: e[1]
                    } : "object" === n(e) ? {
                        x: e.x,
                        y: e.y
                    } : null != e ? {
                        x: e,
                        y: null != t ? t : e
                    } : {
                        x: 0,
                        y: 0
                    }, this.x = i.x, this.y = i.y
                },
                extend: {
                    clone: function () {
                        return new i.Point(this)
                    },
                    morph: function (e, t) {
                        return this.destination = new i.Point(e, t), this
                    }
                }
            }), i.extend(i.Element, {
                point: function (e, t) {
                    return new i.Point(e, t).transform(this.screenCTM().inverse())
                }
            }), i.extend(i.Element, {
                attr: function (e, t, a) {
                    if (null == e) {
                        for (e = {}, a = (t = this.node.attributes).length - 1; a >= 0; a--) e[t[a].nodeName] = i.regex.isNumber.test(t[a].nodeValue) ? parseFloat(t[a].nodeValue) : t[a].nodeValue;
                        return e
                    }
                    if ("object" === n(e))
                        for (var r in e) this.attr(r, e[r]);
                    else if (null === t) this.node.removeAttribute(e);
                    else {
                        if (null == t) return null == (t = this.node.getAttribute(e)) ? i.defaults.attrs[e] : i.regex.isNumber.test(t) ? parseFloat(t) : t;
                        "stroke-width" == e ? this.attr("stroke", parseFloat(t) > 0 ? this._stroke : null) : "stroke" == e && (this._stroke = t), "fill" != e && "stroke" != e || (i.regex.isImage.test(t) && (t = this.doc().defs().image(t, 0, 0)), t instanceof i.Image && (t = this.doc().defs().pattern(0, 0, (function () {
                            this.add(t)
                        })))), "number" == typeof t ? t = new i.Number(t) : i.Color.isColor(t) ? t = new i.Color(t) : Array.isArray(t) && (t = new i.Array(t)), "leading" == e ? this.leading && this.leading(t) : "string" == typeof a ? this.node.setAttributeNS(a, e, t.toString()) : this.node.setAttribute(e, t.toString()), !this.rebuild || "font-size" != e && "x" != e || this.rebuild(e, t)
                    }
                    return this
                }
            }), i.extend(i.Element, {
                transform: function (e, t) {
                    var a;
                    return "object" !== n(e) ? (a = new i.Matrix(this).extract(), "string" == typeof e ? a[e] : a) : (a = new i.Matrix(this), t = !!t || !!e.relative, null != e.a && (a = t ? a.multiply(new i.Matrix(e)) : new i.Matrix(e)), this.attr("transform", a))
                }
            }), i.extend(i.Element, {
                untransform: function () {
                    return this.attr("transform", null)
                },
                matrixify: function () {
                    return (this.attr("transform") || "").split(i.regex.transforms).slice(0, -1).map((function (e) {
                        var t = e.trim().split("(");
                        return [t[0], t[1].split(i.regex.delimiter).map((function (e) {
                            return parseFloat(e)
                        }))]
                    })).reduce((function (e, t) {
                        return "matrix" == t[0] ? e.multiply(m(t[1])) : e[t[0]].apply(e, t[1])
                    }), new i.Matrix)
                },
                toParent: function (e) {
                    if (this == e) return this;
                    var t = this.screenCTM(),
                        n = e.screenCTM().inverse();
                    return this.addTo(e).untransform().transform(n.multiply(t)), this
                },
                toDoc: function () {
                    return this.toParent(this.doc())
                }
            }), i.Transformation = i.invent({
                create: function (e, t) {
                    if (arguments.length > 1 && "boolean" != typeof t) return this.constructor.call(this, [].slice.call(arguments));
                    if (Array.isArray(e))
                        for (var i = 0, a = this.arguments.length; i < a; ++i) this[this.arguments[i]] = e[i];
                    else if (e && "object" === n(e))
                        for (i = 0, a = this.arguments.length; i < a; ++i) this[this.arguments[i]] = e[this.arguments[i]];
                    this.inversed = !1, !0 === t && (this.inversed = !0)
                }
            }), i.Translate = i.invent({
                parent: i.Matrix,
                inherit: i.Transformation,
                create: function (e, t) {
                    this.constructor.apply(this, [].slice.call(arguments))
                },
                extend: {
                    arguments: ["transformedX", "transformedY"],
                    method: "translate"
                }
            }), i.extend(i.Element, {
                style: function (e, t) {
                    if (0 == arguments.length) return this.node.style.cssText || "";
                    if (arguments.length < 2)
                        if ("object" === n(e))
                            for (var a in e) this.style(a, e[a]);
                        else {
                            if (!i.regex.isCss.test(e)) return this.node.style[u(e)];
                            for (e = e.split(/\s*;\s*/).filter((function (e) {
                                    return !!e
                                })).map((function (e) {
                                    return e.split(/\s*:\s*/)
                                })); t = e.pop();) this.style(t[0], t[1])
                        }
                    else this.node.style[u(e)] = null === t || i.regex.isBlank.test(t) ? "" : t;
                    return this
                }
            }), i.Parent = i.invent({
                create: function (e) {
                    this.constructor.call(this, e)
                },
                inherit: i.Element,
                extend: {
                    children: function () {
                        return i.utils.map(i.utils.filterSVGElements(this.node.childNodes), (function (e) {
                            return i.adopt(e)
                        }))
                    },
                    add: function (e, t) {
                        return null == t ? this.node.appendChild(e.node) : e.node != this.node.childNodes[t] && this.node.insertBefore(e.node, this.node.childNodes[t]), this
                    },
                    put: function (e, t) {
                        return this.add(e, t), e
                    },
                    has: function (e) {
                        return this.index(e) >= 0
                    },
                    index: function (e) {
                        return [].slice.call(this.node.childNodes).indexOf(e.node)
                    },
                    get: function (e) {
                        return i.adopt(this.node.childNodes[e])
                    },
                    first: function () {
                        return this.get(0)
                    },
                    last: function () {
                        return this.get(this.node.childNodes.length - 1)
                    },
                    each: function (e, t) {
                        for (var n = this.children(), a = 0, r = n.length; a < r; a++) n[a] instanceof i.Element && e.apply(n[a], [a, n]), t && n[a] instanceof i.Container && n[a].each(e, t);
                        return this
                    },
                    removeElement: function (e) {
                        return this.node.removeChild(e.node), this
                    },
                    clear: function () {
                        for (; this.node.hasChildNodes();) this.node.removeChild(this.node.lastChild);
                        return delete this._defs, this
                    },
                    defs: function () {
                        return this.doc().defs()
                    }
                }
            }), i.extend(i.Parent, {
                ungroup: function (e, t) {
                    return 0 === t || this instanceof i.Defs || this.node == i.parser.draw || (e = e || (this instanceof i.Doc ? this : this.parent(i.Parent)), t = t || 1 / 0, this.each((function () {
                        return this instanceof i.Defs ? this : this instanceof i.Parent ? this.ungroup(e, t - 1) : this.toParent(e)
                    })), this.node.firstChild || this.remove()), this
                },
                flatten: function (e, t) {
                    return this.ungroup(e, t)
                }
            }), i.Container = i.invent({
                create: function (e) {
                    this.constructor.call(this, e)
                },
                inherit: i.Parent
            }), i.ViewBox = i.invent({
                parent: i.Container,
                construct: {}
            }), ["click", "dblclick", "mousedown", "mouseup", "mouseover", "mouseout", "mousemove", "touchstart", "touchmove", "touchleave", "touchend", "touchcancel"].forEach((function (e) {
                i.Element.prototype[e] = function (t) {
                    return i.on(this.node, e, t), this
                }
            })), i.listeners = [], i.handlerMap = [], i.listenerId = 0, i.on = function (e, t, n, a, r) {
                var s = n.bind(a || e.instance || e),
                    o = (i.handlerMap.indexOf(e) + 1 || i.handlerMap.push(e)) - 1,
                    l = t.split(".")[0],
                    c = t.split(".")[1] || "*";
                i.listeners[o] = i.listeners[o] || {}, i.listeners[o][l] = i.listeners[o][l] || {}, i.listeners[o][l][c] = i.listeners[o][l][c] || {}, n._svgjsListenerId || (n._svgjsListenerId = ++i.listenerId), i.listeners[o][l][c][n._svgjsListenerId] = s, e.addEventListener(l, s, r || {
                    passive: !0
                })
            }, i.off = function (e, t, n) {
                var a = i.handlerMap.indexOf(e),
                    r = t && t.split(".")[0],
                    s = t && t.split(".")[1],
                    o = "";
                if (-1 != a)
                    if (n) {
                        if ("function" == typeof n && (n = n._svgjsListenerId), !n) return;
                        i.listeners[a][r] && i.listeners[a][r][s || "*"] && (e.removeEventListener(r, i.listeners[a][r][s || "*"][n], !1), delete i.listeners[a][r][s || "*"][n])
                    } else if (s && r) {
                    if (i.listeners[a][r] && i.listeners[a][r][s]) {
                        for (var l in i.listeners[a][r][s]) i.off(e, [r, s].join("."), l);
                        delete i.listeners[a][r][s]
                    }
                } else if (s)
                    for (var c in i.listeners[a])
                        for (var o in i.listeners[a][c]) s === o && i.off(e, [c, s].join("."));
                else if (r) {
                    if (i.listeners[a][r]) {
                        for (var o in i.listeners[a][r]) i.off(e, [r, o].join("."));
                        delete i.listeners[a][r]
                    }
                } else {
                    for (var c in i.listeners[a]) i.off(e, c);
                    delete i.listeners[a], delete i.handlerMap[a]
                }
            }, i.extend(i.Element, {
                on: function (e, t, n, a) {
                    return i.on(this.node, e, t, n, a), this
                },
                off: function (e, t) {
                    return i.off(this.node, e, t), this
                },
                fire: function (t, n) {
                    return t instanceof e.Event ? this.node.dispatchEvent(t) : this.node.dispatchEvent(t = new i.CustomEvent(t, {
                        detail: n,
                        cancelable: !0
                    })), this._event = t, this
                },
                event: function () {
                    return this._event
                }
            }), i.Defs = i.invent({
                create: "defs",
                inherit: i.Container
            }), i.G = i.invent({
                create: "g",
                inherit: i.Container,
                extend: {
                    x: function (e) {
                        return null == e ? this.transform("x") : this.transform({
                            x: e - this.x()
                        }, !0)
                    }
                },
                construct: {
                    group: function () {
                        return this.put(new i.G)
                    }
                }
            }), i.Doc = i.invent({
                create: function (e) {
                    e && ("svg" == (e = "string" == typeof e ? t.getElementById(e) : e).nodeName ? this.constructor.call(this, e) : (this.constructor.call(this, i.create("svg")), e.appendChild(this.node), this.size("100%", "100%")), this.namespace().defs())
                },
                inherit: i.Container,
                extend: {
                    namespace: function () {
                        return this.attr({
                            xmlns: i.ns,
                            version: "1.1"
                        }).attr("xmlns:xlink", i.xlink, i.xmlns).attr("xmlns:svgjs", i.svgjs, i.xmlns)
                    },
                    defs: function () {
                        var e;
                        return this._defs || ((e = this.node.getElementsByTagName("defs")[0]) ? this._defs = i.adopt(e) : this._defs = new i.Defs, this.node.appendChild(this._defs.node)), this._defs
                    },
                    parent: function () {
                        return this.node.parentNode && "#document" != this.node.parentNode.nodeName ? this.node.parentNode : null
                    },
                    remove: function () {
                        return this.parent() && this.parent().removeChild(this.node), this
                    },
                    clear: function () {
                        for (; this.node.hasChildNodes();) this.node.removeChild(this.node.lastChild);
                        return delete this._defs, i.parser.draw && !i.parser.draw.parentNode && this.node.appendChild(i.parser.draw), this
                    },
                    clone: function (e) {
                        this.writeDataToDom();
                        var t = this.node,
                            n = g(t.cloneNode(!0));
                        return e ? (e.node || e).appendChild(n.node) : t.parentNode.insertBefore(n.node, t.nextSibling), n
                    }
                }
            }), i.extend(i.Element, {}), i.Gradient = i.invent({
                create: function (e) {
                    this.constructor.call(this, i.create(e + "Gradient")), this.type = e
                },
                inherit: i.Container,
                extend: {
                    at: function (e, t, n) {
                        return this.put(new i.Stop).update(e, t, n)
                    },
                    update: function (e) {
                        return this.clear(), "function" == typeof e && e.call(this, this), this
                    },
                    fill: function () {
                        return "url(#" + this.id() + ")"
                    },
                    toString: function () {
                        return this.fill()
                    },
                    attr: function (e, t, n) {
                        return "transform" == e && (e = "gradientTransform"), i.Container.prototype.attr.call(this, e, t, n)
                    }
                },
                construct: {
                    gradient: function (e, t) {
                        return this.defs().gradient(e, t)
                    }
                }
            }), i.extend(i.Gradient, i.FX, {
                from: function (e, t) {
                    return "radial" == (this._target || this).type ? this.attr({
                        fx: new i.Number(e),
                        fy: new i.Number(t)
                    }) : this.attr({
                        x1: new i.Number(e),
                        y1: new i.Number(t)
                    })
                },
                to: function (e, t) {
                    return "radial" == (this._target || this).type ? this.attr({
                        cx: new i.Number(e),
                        cy: new i.Number(t)
                    }) : this.attr({
                        x2: new i.Number(e),
                        y2: new i.Number(t)
                    })
                }
            }), i.extend(i.Defs, {
                gradient: function (e, t) {
                    return this.put(new i.Gradient(e)).update(t)
                }
            }), i.Stop = i.invent({
                create: "stop",
                inherit: i.Element,
                extend: {
                    update: function (e) {
                        return ("number" == typeof e || e instanceof i.Number) && (e = {
                            offset: arguments[0],
                            color: arguments[1],
                            opacity: arguments[2]
                        }), null != e.opacity && this.attr("stop-opacity", e.opacity), null != e.color && this.attr("stop-color", e.color), null != e.offset && this.attr("offset", new i.Number(e.offset)), this
                    }
                }
            }), i.Pattern = i.invent({
                create: "pattern",
                inherit: i.Container,
                extend: {
                    fill: function () {
                        return "url(#" + this.id() + ")"
                    },
                    update: function (e) {
                        return this.clear(), "function" == typeof e && e.call(this, this), this
                    },
                    toString: function () {
                        return this.fill()
                    },
                    attr: function (e, t, n) {
                        return "transform" == e && (e = "patternTransform"), i.Container.prototype.attr.call(this, e, t, n)
                    }
                },
                construct: {
                    pattern: function (e, t, n) {
                        return this.defs().pattern(e, t, n)
                    }
                }
            }), i.extend(i.Defs, {
                pattern: function (e, t, n) {
                    return this.put(new i.Pattern).update(n).attr({
                        x: 0,
                        y: 0,
                        width: e,
                        height: t,
                        patternUnits: "userSpaceOnUse"
                    })
                }
            }), i.Shape = i.invent({
                create: function (e) {
                    this.constructor.call(this, e)
                },
                inherit: i.Element
            }), i.Symbol = i.invent({
                create: "symbol",
                inherit: i.Container,
                construct: {
                    symbol: function () {
                        return this.put(new i.Symbol)
                    }
                }
            }), i.Use = i.invent({
                create: "use",
                inherit: i.Shape,
                extend: {
                    element: function (e, t) {
                        return this.attr("href", (t || "") + "#" + e, i.xlink)
                    }
                },
                construct: {
                    use: function (e, t) {
                        return this.put(new i.Use).element(e, t)
                    }
                }
            }), i.Rect = i.invent({
                create: "rect",
                inherit: i.Shape,
                construct: {
                    rect: function (e, t) {
                        return this.put(new i.Rect).size(e, t)
                    }
                }
            }), i.Circle = i.invent({
                create: "circle",
                inherit: i.Shape,
                construct: {
                    circle: function (e) {
                        return this.put(new i.Circle).rx(new i.Number(e).divide(2)).move(0, 0)
                    }
                }
            }), i.extend(i.Circle, i.FX, {
                rx: function (e) {
                    return this.attr("r", e)
                },
                ry: function (e) {
                    return this.rx(e)
                }
            }), i.Ellipse = i.invent({
                create: "ellipse",
                inherit: i.Shape,
                construct: {
                    ellipse: function (e, t) {
                        return this.put(new i.Ellipse).size(e, t).move(0, 0)
                    }
                }
            }), i.extend(i.Ellipse, i.Rect, i.FX, {
                rx: function (e) {
                    return this.attr("rx", e)
                },
                ry: function (e) {
                    return this.attr("ry", e)
                }
            }), i.extend(i.Circle, i.Ellipse, {
                x: function (e) {
                    return null == e ? this.cx() - this.rx() : this.cx(e + this.rx())
                },
                y: function (e) {
                    return null == e ? this.cy() - this.ry() : this.cy(e + this.ry())
                },
                cx: function (e) {
                    return null == e ? this.attr("cx") : this.attr("cx", e)
                },
                cy: function (e) {
                    return null == e ? this.attr("cy") : this.attr("cy", e)
                },
                width: function (e) {
                    return null == e ? 2 * this.rx() : this.rx(new i.Number(e).divide(2))
                },
                height: function (e) {
                    return null == e ? 2 * this.ry() : this.ry(new i.Number(e).divide(2))
                },
                size: function (e, t) {
                    var n = f(this, e, t);
                    return this.rx(new i.Number(n.width).divide(2)).ry(new i.Number(n.height).divide(2))
                }
            }), i.Line = i.invent({
                create: "line",
                inherit: i.Shape,
                extend: {
                    array: function () {
                        return new i.PointArray([
                            [this.attr("x1"), this.attr("y1")],
                            [this.attr("x2"), this.attr("y2")]
                        ])
                    },
                    plot: function (e, t, n, a) {
                        return null == e ? this.array() : (e = void 0 !== t ? {
                            x1: e,
                            y1: t,
                            x2: n,
                            y2: a
                        } : new i.PointArray(e).toLine(), this.attr(e))
                    },
                    move: function (e, t) {
                        return this.attr(this.array().move(e, t).toLine())
                    },
                    size: function (e, t) {
                        var n = f(this, e, t);
                        return this.attr(this.array().size(n.width, n.height).toLine())
                    }
                },
                construct: {
                    line: function (e, t, n, a) {
                        return i.Line.prototype.plot.apply(this.put(new i.Line), null != e ? [e, t, n, a] : [0, 0, 0, 0])
                    }
                }
            }), i.Polyline = i.invent({
                create: "polyline",
                inherit: i.Shape,
                construct: {
                    polyline: function (e) {
                        return this.put(new i.Polyline).plot(e || new i.PointArray)
                    }
                }
            }), i.Polygon = i.invent({
                create: "polygon",
                inherit: i.Shape,
                construct: {
                    polygon: function (e) {
                        return this.put(new i.Polygon).plot(e || new i.PointArray)
                    }
                }
            }), i.extend(i.Polyline, i.Polygon, {
                array: function () {
                    return this._array || (this._array = new i.PointArray(this.attr("points")))
                },
                plot: function (e) {
                    return null == e ? this.array() : this.clear().attr("points", "string" == typeof e ? e : this._array = new i.PointArray(e))
                },
                clear: function () {
                    return delete this._array, this
                },
                move: function (e, t) {
                    return this.attr("points", this.array().move(e, t))
                },
                size: function (e, t) {
                    var n = f(this, e, t);
                    return this.attr("points", this.array().size(n.width, n.height))
                }
            }), i.extend(i.Line, i.Polyline, i.Polygon, {
                morphArray: i.PointArray,
                x: function (e) {
                    return null == e ? this.bbox().x : this.move(e, this.bbox().y)
                },
                y: function (e) {
                    return null == e ? this.bbox().y : this.move(this.bbox().x, e)
                },
                width: function (e) {
                    var t = this.bbox();
                    return null == e ? t.width : this.size(e, t.height)
                },
                height: function (e) {
                    var t = this.bbox();
                    return null == e ? t.height : this.size(t.width, e)
                }
            }), i.Path = i.invent({
                create: "path",
                inherit: i.Shape,
                extend: {
                    morphArray: i.PathArray,
                    array: function () {
                        return this._array || (this._array = new i.PathArray(this.attr("d")))
                    },
                    plot: function (e) {
                        return null == e ? this.array() : this.clear().attr("d", "string" == typeof e ? e : this._array = new i.PathArray(e))
                    },
                    clear: function () {
                        return delete this._array, this
                    }
                },
                construct: {
                    path: function (e) {
                        return this.put(new i.Path).plot(e || new i.PathArray)
                    }
                }
            }), i.Image = i.invent({
                create: "image",
                inherit: i.Shape,
                extend: {
                    load: function (t) {
                        if (!t) return this;
                        var n = this,
                            a = new e.Image;
                        return i.on(a, "load", (function () {
                            i.off(a);
                            var e = n.parent(i.Pattern);
                            null !== e && (0 == n.width() && 0 == n.height() && n.size(a.width, a.height), e && 0 == e.width() && 0 == e.height() && e.size(n.width(), n.height()), "function" == typeof n._loaded && n._loaded.call(n, {
                                width: a.width,
                                height: a.height,
                                ratio: a.width / a.height,
                                url: t
                            }))
                        })), i.on(a, "error", (function (e) {
                            i.off(a), "function" == typeof n._error && n._error.call(n, e)
                        })), this.attr("href", a.src = this.src = t, i.xlink)
                    },
                    loaded: function (e) {
                        return this._loaded = e, this
                    },
                    error: function (e) {
                        return this._error = e, this
                    }
                },
                construct: {
                    image: function (e, t, n) {
                        return this.put(new i.Image).load(e).size(t || 0, n || t || 0)
                    }
                }
            }), i.Text = i.invent({
                create: function () {
                    this.constructor.call(this, i.create("text")), this.dom.leading = new i.Number(1.3), this._rebuild = !0, this._build = !1, this.attr("font-family", i.defaults.attrs["font-family"])
                },
                inherit: i.Shape,
                extend: {
                    x: function (e) {
                        return null == e ? this.attr("x") : this.attr("x", e)
                    },
                    text: function (e) {
                        if (void 0 === e) {
                            e = "";
                            for (var t = this.node.childNodes, n = 0, a = t.length; n < a; ++n) 0 != n && 3 != t[n].nodeType && 1 == i.adopt(t[n]).dom.newLined && (e += "\n"), e += t[n].textContent;
                            return e
                        }
                        if (this.clear().build(!0), "function" == typeof e) e.call(this, this);
                        else {
                            n = 0;
                            for (var r = (e = e.split("\n")).length; n < r; n++) this.tspan(e[n]).newLine()
                        }
                        return this.build(!1).rebuild()
                    },
                    size: function (e) {
                        return this.attr("font-size", e).rebuild()
                    },
                    leading: function (e) {
                        return null == e ? this.dom.leading : (this.dom.leading = new i.Number(e), this.rebuild())
                    },
                    lines: function () {
                        var e = (this.textPath && this.textPath() || this).node,
                            t = i.utils.map(i.utils.filterSVGElements(e.childNodes), (function (e) {
                                return i.adopt(e)
                            }));
                        return new i.Set(t)
                    },
                    rebuild: function (e) {
                        if ("boolean" == typeof e && (this._rebuild = e), this._rebuild) {
                            var t = this,
                                n = 0,
                                a = this.dom.leading * new i.Number(this.attr("font-size"));
                            this.lines().each((function () {
                                this.dom.newLined && (t.textPath() || this.attr("x", t.attr("x")), "\n" == this.text() ? n += a : (this.attr("dy", a + n), n = 0))
                            })), this.fire("rebuild")
                        }
                        return this
                    },
                    build: function (e) {
                        return this._build = !!e, this
                    },
                    setData: function (e) {
                        return this.dom = e, this.dom.leading = new i.Number(e.leading || 1.3), this
                    }
                },
                construct: {
                    text: function (e) {
                        return this.put(new i.Text).text(e)
                    },
                    plain: function (e) {
                        return this.put(new i.Text).plain(e)
                    }
                }
            }), i.Tspan = i.invent({
                create: "tspan",
                inherit: i.Shape,
                extend: {
                    text: function (e) {
                        return null == e ? this.node.textContent + (this.dom.newLined ? "\n" : "") : ("function" == typeof e ? e.call(this, this) : this.plain(e), this)
                    },
                    dx: function (e) {
                        return this.attr("dx", e)
                    },
                    dy: function (e) {
                        return this.attr("dy", e)
                    },
                    newLine: function () {
                        var e = this.parent(i.Text);
                        return this.dom.newLined = !0, this.dy(e.dom.leading * e.attr("font-size")).attr("x", e.x())
                    }
                }
            }), i.extend(i.Text, i.Tspan, {
                plain: function (e) {
                    return !1 === this._build && this.clear(), this.node.appendChild(t.createTextNode(e)), this
                },
                tspan: function (e) {
                    var t = (this.textPath && this.textPath() || this).node,
                        n = new i.Tspan;
                    return !1 === this._build && this.clear(), t.appendChild(n.node), n.text(e)
                },
                clear: function () {
                    for (var e = (this.textPath && this.textPath() || this).node; e.hasChildNodes();) e.removeChild(e.lastChild);
                    return this
                },
                length: function () {
                    return this.node.getComputedTextLength()
                }
            }), i.TextPath = i.invent({
                create: "textPath",
                inherit: i.Parent,
                parent: i.Text,
                construct: {
                    morphArray: i.PathArray,
                    array: function () {
                        var e = this.track();
                        return e ? e.array() : null
                    },
                    plot: function (e) {
                        var t = this.track(),
                            n = null;
                        return t && (n = t.plot(e)), null == e ? n : this
                    },
                    track: function () {
                        var e = this.textPath();
                        if (e) return e.reference("href")
                    },
                    textPath: function () {
                        if (this.node.firstChild && "textPath" == this.node.firstChild.nodeName) return i.adopt(this.node.firstChild)
                    }
                }
            }), i.Nested = i.invent({
                create: function () {
                    this.constructor.call(this, i.create("svg")), this.style("overflow", "visible")
                },
                inherit: i.Container,
                construct: {
                    nested: function () {
                        return this.put(new i.Nested)
                    }
                }
            });
            var l = {
                stroke: ["color", "width", "opacity", "linecap", "linejoin", "miterlimit", "dasharray", "dashoffset"],
                fill: ["color", "opacity", "rule"],
                prefix: function (e, t) {
                    return "color" == t ? e : e + "-" + t
                }
            };

            function c(e, t, n, a) {
                return n + a.replace(i.regex.dots, " .")
            }

            function u(e) {
                return e.toLowerCase().replace(/-(.)/g, (function (e, t) {
                    return t.toUpperCase()
                }))
            }

            function d(e) {
                return e.charAt(0).toUpperCase() + e.slice(1)
            }

            function h(e) {
                var t = e.toString(16);
                return 1 == t.length ? "0" + t : t
            }

            function f(e, t, n) {
                if (null == t || null == n) {
                    var i = e.bbox();
                    null == t ? t = i.width / i.height * n : null == n && (n = i.height / i.width * t)
                }
                return {
                    width: t,
                    height: n
                }
            }

            function p(e, t, n) {
                return {
                    x: t * e.a + n * e.c + 0,
                    y: t * e.b + n * e.d + 0
                }
            }

            function m(e) {
                return {
                    a: e[0],
                    b: e[1],
                    c: e[2],
                    d: e[3],
                    e: e[4],
                    f: e[5]
                }
            }

            function g(t) {
                for (var n = t.childNodes.length - 1; n >= 0; n--) t.childNodes[n] instanceof e.SVGElement && g(t.childNodes[n]);
                return i.adopt(t).id(i.eid(t.nodeName))
            }

            function v(e) {
                return null == e.x && (e.x = 0, e.y = 0, e.width = 0, e.height = 0), e.w = e.width, e.h = e.height, e.x2 = e.x + e.width, e.y2 = e.y + e.height, e.cx = e.x + e.width / 2, e.cy = e.y + e.height / 2, e
            }

            function y(e) {
                return Math.abs(e) > 1e-37 ? e : 0
            } ["fill", "stroke"].forEach((function (e) {
                var t = {};
                t[e] = function (t) {
                    if (void 0 === t) return this;
                    if ("string" == typeof t || i.Color.isRgb(t) || t && "function" == typeof t.fill) this.attr(e, t);
                    else
                        for (var n = l[e].length - 1; n >= 0; n--) null != t[l[e][n]] && this.attr(l.prefix(e, l[e][n]), t[l[e][n]]);
                    return this
                }, i.extend(i.Element, i.FX, t)
            })), i.extend(i.Element, i.FX, {
                translate: function (e, t) {
                    return this.transform({
                        x: e,
                        y: t
                    })
                },
                matrix: function (e) {
                    return this.attr("transform", new i.Matrix(6 == arguments.length ? [].slice.call(arguments) : e))
                },
                opacity: function (e) {
                    return this.attr("opacity", e)
                },
                dx: function (e) {
                    return this.x(new i.Number(e).plus(this instanceof i.FX ? 0 : this.x()), !0)
                },
                dy: function (e) {
                    return this.y(new i.Number(e).plus(this instanceof i.FX ? 0 : this.y()), !0)
                }
            }), i.extend(i.Path, {
                length: function () {
                    return this.node.getTotalLength()
                },
                pointAt: function (e) {
                    return this.node.getPointAtLength(e)
                }
            }), i.Set = i.invent({
                create: function (e) {
                    Array.isArray(e) ? this.members = e : this.clear()
                },
                extend: {
                    add: function () {
                        for (var e = [].slice.call(arguments), t = 0, n = e.length; t < n; t++) this.members.push(e[t]);
                        return this
                    },
                    remove: function (e) {
                        var t = this.index(e);
                        return t > -1 && this.members.splice(t, 1), this
                    },
                    each: function (e) {
                        for (var t = 0, n = this.members.length; t < n; t++) e.apply(this.members[t], [t, this.members]);
                        return this
                    },
                    clear: function () {
                        return this.members = [], this
                    },
                    length: function () {
                        return this.members.length
                    },
                    has: function (e) {
                        return this.index(e) >= 0
                    },
                    index: function (e) {
                        return this.members.indexOf(e)
                    },
                    get: function (e) {
                        return this.members[e]
                    },
                    first: function () {
                        return this.get(0)
                    },
                    last: function () {
                        return this.get(this.members.length - 1)
                    },
                    valueOf: function () {
                        return this.members
                    }
                },
                construct: {
                    set: function (e) {
                        return new i.Set(e)
                    }
                }
            }), i.FX.Set = i.invent({
                create: function (e) {
                    this.set = e
                }
            }), i.Set.inherit = function () {
                var e = [];
                for (var t in i.Shape.prototype) "function" == typeof i.Shape.prototype[t] && "function" != typeof i.Set.prototype[t] && e.push(t);
                for (var t in e.forEach((function (e) {
                        i.Set.prototype[e] = function () {
                            for (var t = 0, n = this.members.length; t < n; t++) this.members[t] && "function" == typeof this.members[t][e] && this.members[t][e].apply(this.members[t], arguments);
                            return "animate" == e ? this.fx || (this.fx = new i.FX.Set(this)) : this
                        }
                    })), e = [], i.FX.prototype) "function" == typeof i.FX.prototype[t] && "function" != typeof i.FX.Set.prototype[t] && e.push(t);
                e.forEach((function (e) {
                    i.FX.Set.prototype[e] = function () {
                        for (var t = 0, n = this.set.members.length; t < n; t++) this.set.members[t].fx[e].apply(this.set.members[t].fx, arguments);
                        return this
                    }
                }))
            }, i.extend(i.Element, {}), i.extend(i.Element, {
                remember: function (e, t) {
                    if ("object" === n(arguments[0]))
                        for (var i in e) this.remember(i, e[i]);
                    else {
                        if (1 == arguments.length) return this.memory()[e];
                        this.memory()[e] = t
                    }
                    return this
                },
                forget: function () {
                    if (0 == arguments.length) this._memory = {};
                    else
                        for (var e = arguments.length - 1; e >= 0; e--) delete this.memory()[arguments[e]];
                    return this
                },
                memory: function () {
                    return this._memory || (this._memory = {})
                }
            }), i.get = function (e) {
                var n = t.getElementById(function (e) {
                    var t = (e || "").toString().match(i.regex.reference);
                    if (t) return t[1]
                }(e) || e);
                return i.adopt(n)
            }, i.select = function (e, n) {
                return new i.Set(i.utils.map((n || t).querySelectorAll(e), (function (e) {
                    return i.adopt(e)
                })))
            }, i.extend(i.Parent, {
                select: function (e) {
                    return i.select(e, this.node)
                }
            });
            var b = "abcdef".split("");
            if ("function" != typeof e.CustomEvent) {
                var x = function (e, n) {
                    n = n || {
                        bubbles: !1,
                        cancelable: !1,
                        detail: void 0
                    };
                    var i = t.createEvent("CustomEvent");
                    return i.initCustomEvent(e, n.bubbles, n.cancelable, n.detail), i
                };
                x.prototype = e.Event.prototype, i.CustomEvent = x
            } else i.CustomEvent = e.CustomEvent;
            return i
        }, "function" == typeof define && define.amd ? define((function () {
            return Ce(Te, Te.document)
        })) : "object" === ("undefined" == typeof exports ? "undefined" : n(exports)) && "undefined" != typeof module ? module.exports = Te.document ? Ce(Te, Te.document) : function (e) {
            return Ce(e, e.document)
        } : Te.SVG = Ce(Te, Te.document),
        /*! svg.filter.js - v2.0.2 - 2016-02-24
         * https://github.com/wout/svg.filter.js
         * Copyright (c) 2016 Wout Fierens; Licensed MIT */
        function () {
            SVG.Filter = SVG.invent({
                create: "filter",
                inherit: SVG.Parent,
                extend: {
                    source: "SourceGraphic",
                    sourceAlpha: "SourceAlpha",
                    background: "BackgroundImage",
                    backgroundAlpha: "BackgroundAlpha",
                    fill: "FillPaint",
                    stroke: "StrokePaint",
                    autoSetIn: !0,
                    put: function (e, t) {
                        return this.add(e, t), !e.attr("in") && this.autoSetIn && e.attr("in", this.source), e.attr("result") || e.attr("result", e), e
                    },
                    blend: function (e, t, n) {
                        return this.put(new SVG.BlendEffect(e, t, n))
                    },
                    colorMatrix: function (e, t) {
                        return this.put(new SVG.ColorMatrixEffect(e, t))
                    },
                    convolveMatrix: function (e) {
                        return this.put(new SVG.ConvolveMatrixEffect(e))
                    },
                    componentTransfer: function (e) {
                        return this.put(new SVG.ComponentTransferEffect(e))
                    },
                    composite: function (e, t, n) {
                        return this.put(new SVG.CompositeEffect(e, t, n))
                    },
                    flood: function (e, t) {
                        return this.put(new SVG.FloodEffect(e, t))
                    },
                    offset: function (e, t) {
                        return this.put(new SVG.OffsetEffect(e, t))
                    },
                    image: function (e) {
                        return this.put(new SVG.ImageEffect(e))
                    },
                    merge: function () {
                        var e = [void 0];
                        for (var t in arguments) e.push(arguments[t]);
                        return this.put(new(SVG.MergeEffect.bind.apply(SVG.MergeEffect, e)))
                    },
                    gaussianBlur: function (e, t) {
                        return this.put(new SVG.GaussianBlurEffect(e, t))
                    },
                    morphology: function (e, t) {
                        return this.put(new SVG.MorphologyEffect(e, t))
                    },
                    diffuseLighting: function (e, t, n) {
                        return this.put(new SVG.DiffuseLightingEffect(e, t, n))
                    },
                    displacementMap: function (e, t, n, i, a) {
                        return this.put(new SVG.DisplacementMapEffect(e, t, n, i, a))
                    },
                    specularLighting: function (e, t, n, i) {
                        return this.put(new SVG.SpecularLightingEffect(e, t, n, i))
                    },
                    tile: function () {
                        return this.put(new SVG.TileEffect)
                    },
                    turbulence: function (e, t, n, i, a) {
                        return this.put(new SVG.TurbulenceEffect(e, t, n, i, a))
                    },
                    toString: function () {
                        return "url(#" + this.attr("id") + ")"
                    }
                }
            }), SVG.extend(SVG.Defs, {
                filter: function (e) {
                    var t = this.put(new SVG.Filter);
                    return "function" == typeof e && e.call(t, t), t
                }
            }), SVG.extend(SVG.Container, {
                filter: function (e) {
                    return this.defs().filter(e)
                }
            }), SVG.extend(SVG.Element, SVG.G, SVG.Nested, {
                filter: function (e) {
                    return this.filterer = e instanceof SVG.Element ? e : this.doc().filter(e), this.doc() && this.filterer.doc() !== this.doc() && this.doc().defs().add(this.filterer), this.attr("filter", this.filterer), this.filterer
                },
                unfilter: function (e) {
                    return this.filterer && !0 === e && this.filterer.remove(), delete this.filterer, this.attr("filter", null)
                }
            }), SVG.Effect = SVG.invent({
                create: function () {
                    this.constructor.call(this)
                },
                inherit: SVG.Element,
                extend: {
                    in: function (e) {
                        return null == e ? this.parent() && this.parent().select('[result="' + this.attr("in") + '"]').get(0) || this.attr("in") : this.attr("in", e)
                    },
                    result: function (e) {
                        return null == e ? this.attr("result") : this.attr("result", e)
                    },
                    toString: function () {
                        return this.result()
                    }
                }
            }), SVG.ParentEffect = SVG.invent({
                create: function () {
                    this.constructor.call(this)
                },
                inherit: SVG.Parent,
                extend: {
                    in: function (e) {
                        return null == e ? this.parent() && this.parent().select('[result="' + this.attr("in") + '"]').get(0) || this.attr("in") : this.attr("in", e)
                    },
                    result: function (e) {
                        return null == e ? this.attr("result") : this.attr("result", e)
                    },
                    toString: function () {
                        return this.result()
                    }
                }
            });
            var e = {
                blend: function (e, t) {
                    return this.parent() && this.parent().blend(this, e, t)
                },
                colorMatrix: function (e, t) {
                    return this.parent() && this.parent().colorMatrix(e, t).in(this)
                },
                convolveMatrix: function (e) {
                    return this.parent() && this.parent().convolveMatrix(e).in(this)
                },
                componentTransfer: function (e) {
                    return this.parent() && this.parent().componentTransfer(e).in(this)
                },
                composite: function (e, t) {
                    return this.parent() && this.parent().composite(this, e, t)
                },
                flood: function (e, t) {
                    return this.parent() && this.parent().flood(e, t)
                },
                offset: function (e, t) {
                    return this.parent() && this.parent().offset(e, t).in(this)
                },
                image: function (e) {
                    return this.parent() && this.parent().image(e)
                },
                merge: function () {
                    return this.parent() && this.parent().merge.apply(this.parent(), [this].concat(arguments))
                },
                gaussianBlur: function (e, t) {
                    return this.parent() && this.parent().gaussianBlur(e, t).in(this)
                },
                morphology: function (e, t) {
                    return this.parent() && this.parent().morphology(e, t).in(this)
                },
                diffuseLighting: function (e, t, n) {
                    return this.parent() && this.parent().diffuseLighting(e, t, n).in(this)
                },
                displacementMap: function (e, t, n, i) {
                    return this.parent() && this.parent().displacementMap(this, e, t, n, i)
                },
                specularLighting: function (e, t, n, i) {
                    return this.parent() && this.parent().specularLighting(e, t, n, i).in(this)
                },
                tile: function () {
                    return this.parent() && this.parent().tile().in(this)
                },
                turbulence: function (e, t, n, i, a) {
                    return this.parent() && this.parent().turbulence(e, t, n, i, a).in(this)
                }
            };
            SVG.extend(SVG.Effect, e), SVG.extend(SVG.ParentEffect, e), SVG.ChildEffect = SVG.invent({
                create: function () {
                    this.constructor.call(this)
                },
                inherit: SVG.Element,
                extend: {
                    in: function (e) {
                        this.attr("in", e)
                    }
                }
            });
            var t = {
                    blend: function (e, t, n) {
                        this.attr({
                            in: e,
                            in2: t,
                            mode: n || "normal"
                        })
                    },
                    colorMatrix: function (e, t) {
                        "matrix" == e && (t = a(t)), this.attr({
                            type: e,
                            values: void 0 === t ? null : t
                        })
                    },
                    convolveMatrix: function (e) {
                        e = a(e), this.attr({
                            order: Math.sqrt(e.split(" ").length),
                            kernelMatrix: e
                        })
                    },
                    composite: function (e, t, n) {
                        this.attr({
                            in: e,
                            in2: t,
                            operator: n
                        })
                    },
                    flood: function (e, t) {
                        this.attr("flood-color", e), null != t && this.attr("flood-opacity", t)
                    },
                    offset: function (e, t) {
                        this.attr({
                            dx: e,
                            dy: t
                        })
                    },
                    image: function (e) {
                        this.attr("href", e, SVG.xlink)
                    },
                    displacementMap: function (e, t, n, i, a) {
                        this.attr({
                            in: e,
                            in2: t,
                            scale: n,
                            xChannelSelector: i,
                            yChannelSelector: a
                        })
                    },
                    gaussianBlur: function (e, t) {
                        null != e || null != t ? this.attr("stdDeviation", r(Array.prototype.slice.call(arguments))) : this.attr("stdDeviation", "0 0")
                    },
                    morphology: function (e, t) {
                        this.attr({
                            operator: e,
                            radius: t
                        })
                    },
                    tile: function () {},
                    turbulence: function (e, t, n, i, a) {
                        this.attr({
                            numOctaves: t,
                            seed: n,
                            stitchTiles: i,
                            baseFrequency: e,
                            type: a
                        })
                    }
                },
                n = {
                    merge: function () {
                        var e;
                        if (arguments[0] instanceof SVG.Set) {
                            var t = this;
                            arguments[0].each((function (e) {
                                this instanceof SVG.MergeNode ? t.put(this) : (this instanceof SVG.Effect || this instanceof SVG.ParentEffect) && t.put(new SVG.MergeNode(this))
                            }))
                        } else {
                            e = Array.isArray(arguments[0]) ? arguments[0] : arguments;
                            for (var n = 0; n < e.length; n++) e[n] instanceof SVG.MergeNode ? this.put(e[n]) : this.put(new SVG.MergeNode(e[n]))
                        }
                    },
                    componentTransfer: function (e) {
                        if (this.rgb = new SVG.Set, ["r", "g", "b", "a"].forEach(function (e) {
                                this[e] = new(SVG["Func" + e.toUpperCase()])("identity"), this.rgb.add(this[e]), this.node.appendChild(this[e].node)
                            }.bind(this)), e)
                            for (var t in e.rgb && (["r", "g", "b"].forEach(function (t) {
                                    this[t].attr(e.rgb)
                                }.bind(this)), delete e.rgb), e) this[t].attr(e[t])
                    },
                    diffuseLighting: function (e, t, n) {
                        this.attr({
                            surfaceScale: e,
                            diffuseConstant: t,
                            kernelUnitLength: n
                        })
                    },
                    specularLighting: function (e, t, n, i) {
                        this.attr({
                            surfaceScale: e,
                            diffuseConstant: t,
                            specularExponent: n,
                            kernelUnitLength: i
                        })
                    }
                },
                i = {
                    distantLight: function (e, t) {
                        this.attr({
                            azimuth: e,
                            elevation: t
                        })
                    },
                    pointLight: function (e, t, n) {
                        this.attr({
                            x: e,
                            y: t,
                            z: n
                        })
                    },
                    spotLight: function (e, t, n, i, a, r) {
                        this.attr({
                            x: e,
                            y: t,
                            z: n,
                            pointsAtX: i,
                            pointsAtY: a,
                            pointsAtZ: r
                        })
                    },
                    mergeNode: function (e) {
                        this.attr("in", e)
                    }
                };

            function a(e) {
                return Array.isArray(e) && (e = new SVG.Array(e)), e.toString().replace(/^\s+/, "").replace(/\s+$/, "").replace(/\s+/g, " ")
            }

            function r(e) {
                if (!Array.isArray(e)) return e;
                for (var t = 0, n = e.length, i = []; t < n; t++) i.push(e[t]);
                return i.join(" ")
            }

            function s() {
                var e = function () {};
                for (var t in "function" == typeof arguments[arguments.length - 1] && (e = arguments[arguments.length - 1], Array.prototype.splice.call(arguments, arguments.length - 1, 1)), arguments)
                    for (var n in arguments[t]) e(arguments[t][n], n, arguments[t])
            } ["r", "g", "b", "a"].forEach((function (e) {
                i["Func" + e.toUpperCase()] = function (e) {
                    switch (this.attr("type", e), e) {
                        case "table":
                            this.attr("tableValues", arguments[1]);
                            break;
                        case "linear":
                            this.attr("slope", arguments[1]), this.attr("intercept", arguments[2]);
                            break;
                        case "gamma":
                            this.attr("amplitude", arguments[1]), this.attr("exponent", arguments[2]), this.attr("offset", arguments[2])
                    }
                }
            })), s(t, (function (e, t) {
                var n = t.charAt(0).toUpperCase() + t.slice(1);
                SVG[n + "Effect"] = SVG.invent({
                    create: function () {
                        this.constructor.call(this, SVG.create("fe" + n)), e.apply(this, arguments), this.result(this.attr("id") + "Out")
                    },
                    inherit: SVG.Effect,
                    extend: {}
                })
            })), s(n, (function (e, t) {
                var n = t.charAt(0).toUpperCase() + t.slice(1);
                SVG[n + "Effect"] = SVG.invent({
                    create: function () {
                        this.constructor.call(this, SVG.create("fe" + n)), e.apply(this, arguments), this.result(this.attr("id") + "Out")
                    },
                    inherit: SVG.ParentEffect,
                    extend: {}
                })
            })), s(i, (function (e, t) {
                var n = t.charAt(0).toUpperCase() + t.slice(1);
                SVG[n] = SVG.invent({
                    create: function () {
                        this.constructor.call(this, SVG.create("fe" + n)), e.apply(this, arguments)
                    },
                    inherit: SVG.ChildEffect,
                    extend: {}
                })
            })), SVG.extend(SVG.MergeEffect, {
                in: function (e) {
                    return e instanceof SVG.MergeNode ? this.add(e, 0) : this.add(new SVG.MergeNode(e), 0), this
                }
            }), SVG.extend(SVG.CompositeEffect, SVG.BlendEffect, SVG.DisplacementMapEffect, {
                in2: function (e) {
                    return null == e ? this.parent() && this.parent().select('[result="' + this.attr("in2") + '"]').get(0) || this.attr("in2") : this.attr("in2", e)
                }
            }), SVG.filter = {
                sepiatone: [.343, .669, .119, 0, 0, .249, .626, .13, 0, 0, .172, .334, .111, 0, 0, 0, 0, 0, 1, 0]
            }
        }.call(void 0),
        function () {
            function e(e, a, r, s, o, l, c) {
                for (var u = e.slice(a, r || c), d = s.slice(o, l || c), h = 0, f = {
                        pos: [0, 0],
                        start: [0, 0]
                    }, p = {
                        pos: [0, 0],
                        start: [0, 0]
                    }; u[h] = t.call(f, u[h]), d[h] = t.call(p, d[h]), u[h][0] != d[h][0] || "M" == u[h][0] || "A" == u[h][0] && (u[h][4] != d[h][4] || u[h][5] != d[h][5]) ? (Array.prototype.splice.apply(u, [h, 1].concat(i.call(f, u[h]))), Array.prototype.splice.apply(d, [h, 1].concat(i.call(p, d[h])))) : (u[h] = n.call(f, u[h]), d[h] = n.call(p, d[h])), ++h != u.length || h != d.length;) h == u.length && u.push(["C", f.pos[0], f.pos[1], f.pos[0], f.pos[1], f.pos[0], f.pos[1]]), h == d.length && d.push(["C", p.pos[0], p.pos[1], p.pos[0], p.pos[1], p.pos[0], p.pos[1]]);
                return {
                    start: u,
                    dest: d
                }
            }

            function t(e) {
                switch (e[0]) {
                    case "z":
                    case "Z":
                        e[0] = "L", e[1] = this.start[0], e[2] = this.start[1];
                        break;
                    case "H":
                        e[0] = "L", e[2] = this.pos[1];
                        break;
                    case "V":
                        e[0] = "L", e[2] = e[1], e[1] = this.pos[0];
                        break;
                    case "T":
                        e[0] = "Q", e[3] = e[1], e[4] = e[2], e[1] = this.reflection[1], e[2] = this.reflection[0];
                        break;
                    case "S":
                        e[0] = "C", e[6] = e[4], e[5] = e[3], e[4] = e[2], e[3] = e[1], e[2] = this.reflection[1], e[1] = this.reflection[0]
                }
                return e
            }

            function n(e) {
                var t = e.length;
                return this.pos = [e[t - 2], e[t - 1]], -1 != "SCQT".indexOf(e[0]) && (this.reflection = [2 * this.pos[0] - e[t - 4], 2 * this.pos[1] - e[t - 3]]), e
            }

            function i(e) {
                var t = [e];
                switch (e[0]) {
                    case "M":
                        return this.pos = this.start = [e[1], e[2]], t;
                    case "L":
                        e[5] = e[3] = e[1], e[6] = e[4] = e[2], e[1] = this.pos[0], e[2] = this.pos[1];
                        break;
                    case "Q":
                        e[6] = e[4], e[5] = e[3], e[4] = 1 * e[4] / 3 + 2 * e[2] / 3, e[3] = 1 * e[3] / 3 + 2 * e[1] / 3, e[2] = 1 * this.pos[1] / 3 + 2 * e[2] / 3, e[1] = 1 * this.pos[0] / 3 + 2 * e[1] / 3;
                        break;
                    case "A":
                        e = (t = function (e, t) {
                            var n, i, a, r, s, o, l, c, u, d, h, f, p, m, g, v, y, b, x, _, w, k, M, L, S, A, T = Math.abs(t[1]),
                                C = Math.abs(t[2]),
                                D = t[3] % 360,
                                E = t[4],
                                O = t[5],
                                P = t[6],
                                Y = t[7],
                                I = new SVG.Point(e),
                                j = new SVG.Point(P, Y),
                                N = [];
                            if (0 === T || 0 === C || I.x === j.x && I.y === j.y) return [
                                ["C", I.x, I.y, j.x, j.y, j.x, j.y]
                            ];
                            for ((i = (n = new SVG.Point((I.x - j.x) / 2, (I.y - j.y) / 2).transform((new SVG.Matrix).rotate(D))).x * n.x / (T * T) + n.y * n.y / (C * C)) > 1 && (T *= i = Math.sqrt(i), C *= i), a = (new SVG.Matrix).rotate(D).scale(1 / T, 1 / C).rotate(-D), I = I.transform(a), o = (r = [(j = j.transform(a)).x - I.x, j.y - I.y])[0] * r[0] + r[1] * r[1], s = Math.sqrt(o), r[0] /= s, r[1] /= s, l = o < 4 ? Math.sqrt(1 - o / 4) : 0, E === O && (l *= -1), c = new SVG.Point((j.x + I.x) / 2 + l * -r[1], (j.y + I.y) / 2 + l * r[0]), u = new SVG.Point(I.x - c.x, I.y - c.y), d = new SVG.Point(j.x - c.x, j.y - c.y), h = Math.acos(u.x / Math.sqrt(u.x * u.x + u.y * u.y)), u.y < 0 && (h *= -1), f = Math.acos(d.x / Math.sqrt(d.x * d.x + d.y * d.y)), d.y < 0 && (f *= -1), O && h > f && (f += 2 * Math.PI), !O && h < f && (f -= 2 * Math.PI), v = [], y = h, p = (f - h) / (m = Math.ceil(2 * Math.abs(h - f) / Math.PI)), g = 4 * Math.tan(p / 4) / 3, w = 0; w <= m; w++) x = Math.cos(y), b = Math.sin(y), _ = new SVG.Point(c.x + x, c.y + b), v[w] = [new SVG.Point(_.x + g * b, _.y - g * x), _, new SVG.Point(_.x - g * b, _.y + g * x)], y += p;
                            for (v[0][0] = v[0][1].clone(), v[v.length - 1][2] = v[v.length - 1][1].clone(), a = (new SVG.Matrix).rotate(D).scale(T, C).rotate(-D), w = 0, k = v.length; w < k; w++) v[w][0] = v[w][0].transform(a), v[w][1] = v[w][1].transform(a), v[w][2] = v[w][2].transform(a);
                            for (w = 1, k = v.length; w < k; w++) M = (_ = v[w - 1][2]).x, L = _.y, S = (_ = v[w][0]).x, A = _.y, P = (_ = v[w][1]).x, Y = _.y, N.push(["C", M, L, S, A, P, Y]);
                            return N
                        }(this.pos, e))[0]
                }
                return e[0] = "C", this.pos = [e[5], e[6]], this.reflection = [2 * e[5] - e[3], 2 * e[6] - e[4]], t
            }

            function a(e, t) {
                if (!1 === t) return !1;
                for (var n = t, i = e.length; n < i; ++n)
                    if ("M" == e[n][0]) return n;
                return !1
            }
            SVG.extend(SVG.PathArray, {
                morph: function (t) {
                    for (var n = this.value, i = this.parse(t), r = 0, s = 0, o = !1, l = !1; !1 !== r || !1 !== s;) {
                        var c;
                        o = a(n, !1 !== r && r + 1), l = a(i, !1 !== s && s + 1), !1 === r && (r = 0 == (c = new SVG.PathArray(u.start).bbox()).height || 0 == c.width ? n.push(n[0]) - 1 : n.push(["M", c.x + c.width / 2, c.y + c.height / 2]) - 1), !1 === s && (s = 0 == (c = new SVG.PathArray(u.dest).bbox()).height || 0 == c.width ? i.push(i[0]) - 1 : i.push(["M", c.x + c.width / 2, c.y + c.height / 2]) - 1);
                        var u = e(n, r, o, i, s, l);
                        n = n.slice(0, r).concat(u.start, !1 === o ? [] : n.slice(o)), i = i.slice(0, s).concat(u.dest, !1 === l ? [] : i.slice(l)), r = !1 !== o && r + u.start.length, s = !1 !== l && s + u.dest.length
                    }
                    return this.value = n, this.destination = new SVG.PathArray, this.destination.value = i, this
                }
            })
        }(),
        /*! svg.draggable.js - v2.2.2 - 2019-01-08
         * https://github.com/svgdotjs/svg.draggable.js
         * Copyright (c) 2019 Wout Fierens; Licensed MIT */
        function () {
            function e(e) {
                e.remember("_draggable", this), this.el = e
            }
            e.prototype.init = function (e, t) {
                var n = this;
                this.constraint = e, this.value = t, this.el.on("mousedown.drag", (function (e) {
                    n.start(e)
                })), this.el.on("touchstart.drag", (function (e) {
                    n.start(e)
                }))
            }, e.prototype.transformPoint = function (e, t) {
                var n = (e = e || window.event).changedTouches && e.changedTouches[0] || e;
                return this.p.x = n.clientX - (t || 0), this.p.y = n.clientY, this.p.matrixTransform(this.m)
            }, e.prototype.getBBox = function () {
                var e = this.el.bbox();
                return this.el instanceof SVG.Nested && (e = this.el.rbox()), (this.el instanceof SVG.G || this.el instanceof SVG.Use || this.el instanceof SVG.Nested) && (e.x = this.el.x(), e.y = this.el.y()), e
            }, e.prototype.start = function (e) {
                if ("click" != e.type && "mousedown" != e.type && "mousemove" != e.type || 1 == (e.which || e.buttons)) {
                    var t = this;
                    if (this.el.fire("beforedrag", {
                            event: e,
                            handler: this
                        }), !this.el.event().defaultPrevented) {
                        e.preventDefault(), e.stopPropagation(), this.parent = this.parent || this.el.parent(SVG.Nested) || this.el.parent(SVG.Doc), this.p = this.parent.node.createSVGPoint(), this.m = this.el.node.getScreenCTM().inverse();
                        var n, i = this.getBBox();
                        if (this.el instanceof SVG.Text) switch (n = this.el.node.getComputedTextLength(), this.el.attr("text-anchor")) {
                            case "middle":
                                n /= 2;
                                break;
                            case "start":
                                n = 0
                        }
                        this.startPoints = {
                            point: this.transformPoint(e, n),
                            box: i,
                            transform: this.el.transform()
                        }, SVG.on(window, "mousemove.drag", (function (e) {
                            t.drag(e)
                        })), SVG.on(window, "touchmove.drag", (function (e) {
                            t.drag(e)
                        })), SVG.on(window, "mouseup.drag", (function (e) {
                            t.end(e)
                        })), SVG.on(window, "touchend.drag", (function (e) {
                            t.end(e)
                        })), this.el.fire("dragstart", {
                            event: e,
                            p: this.startPoints.point,
                            m: this.m,
                            handler: this
                        })
                    }
                }
            }, e.prototype.drag = function (e) {
                var t = this.getBBox(),
                    n = this.transformPoint(e),
                    i = this.startPoints.box.x + n.x - this.startPoints.point.x,
                    a = this.startPoints.box.y + n.y - this.startPoints.point.y,
                    r = this.constraint,
                    s = n.x - this.startPoints.point.x,
                    o = n.y - this.startPoints.point.y;
                if (this.el.fire("dragmove", {
                        event: e,
                        p: n,
                        m: this.m,
                        handler: this
                    }), this.el.event().defaultPrevented) return n;
                if ("function" == typeof r) {
                    var l = r.call(this.el, i, a, this.m);
                    "boolean" == typeof l && (l = {
                        x: l,
                        y: l
                    }), !0 === l.x ? this.el.x(i) : !1 !== l.x && this.el.x(l.x), !0 === l.y ? this.el.y(a) : !1 !== l.y && this.el.y(l.y)
                } else "object" == typeof r && (null != r.minX && i < r.minX ? s = (i = r.minX) - this.startPoints.box.x : null != r.maxX && i > r.maxX - t.width && (s = (i = r.maxX - t.width) - this.startPoints.box.x), null != r.minY && a < r.minY ? o = (a = r.minY) - this.startPoints.box.y : null != r.maxY && a > r.maxY - t.height && (o = (a = r.maxY - t.height) - this.startPoints.box.y), null != r.snapToGrid && (i -= i % r.snapToGrid, a -= a % r.snapToGrid, s -= s % r.snapToGrid, o -= o % r.snapToGrid), this.el instanceof SVG.G ? this.el.matrix(this.startPoints.transform).transform({
                    x: s,
                    y: o
                }, !0) : this.el.move(i, a));
                return n
            }, e.prototype.end = function (e) {
                var t = this.drag(e);
                this.el.fire("dragend", {
                    event: e,
                    p: t,
                    m: this.m,
                    handler: this
                }), SVG.off(window, "mousemove.drag"), SVG.off(window, "touchmove.drag"), SVG.off(window, "mouseup.drag"), SVG.off(window, "touchend.drag")
            }, SVG.extend(SVG.Element, {
                draggable: function (t, n) {
                    "function" != typeof t && "object" != typeof t || (n = t, t = !0);
                    var i = this.remember("_draggable") || new e(this);
                    return (t = void 0 === t || t) ? i.init(n || {}, t) : (this.off("mousedown.drag"), this.off("touchstart.drag")), this
                }
            })
        }.call(void 0),
        function () {
            function e(e) {
                this.el = e, e.remember("_selectHandler", this), this.pointSelection = {
                    isSelected: !1
                }, this.rectSelection = {
                    isSelected: !1
                }, this.pointsList = {
                    lt: [0, 0],
                    rt: ["width", 0],
                    rb: ["width", "height"],
                    lb: [0, "height"],
                    t: ["width", 0],
                    r: ["width", "height"],
                    b: ["width", "height"],
                    l: [0, "height"]
                }, this.pointCoord = function (e, t, n) {
                    var i = "string" != typeof e ? e : t[e];
                    return n ? i / 2 : i
                }, this.pointCoords = function (e, t) {
                    var n = this.pointsList[e];
                    return {
                        x: this.pointCoord(n[0], t, "t" === e || "b" === e),
                        y: this.pointCoord(n[1], t, "r" === e || "l" === e)
                    }
                }
            }
            e.prototype.init = function (e, t) {
                var n = this.el.bbox();
                this.options = {};
                var i = this.el.selectize.defaults.points;
                for (var a in this.el.selectize.defaults) this.options[a] = this.el.selectize.defaults[a], void 0 !== t[a] && (this.options[a] = t[a]);
                var r = ["points", "pointsExclude"];
                for (var a in r) {
                    var s = this.options[r[a]];
                    "string" == typeof s ? s = s.length > 0 ? s.split(/\s*,\s*/i) : [] : "boolean" == typeof s && "points" === r[a] && (s = s ? i : []), this.options[r[a]] = s
                }
                this.options.points = [i, this.options.points].reduce((function (e, t) {
                    return e.filter((function (e) {
                        return t.indexOf(e) > -1
                    }))
                })), this.options.points = [this.options.points, this.options.pointsExclude].reduce((function (e, t) {
                    return e.filter((function (e) {
                        return t.indexOf(e) < 0
                    }))
                })), this.parent = this.el.parent(), this.nested = this.nested || this.parent.group(), this.nested.matrix(new SVG.Matrix(this.el).translate(n.x, n.y)), this.options.deepSelect && -1 !== ["line", "polyline", "polygon"].indexOf(this.el.type) ? this.selectPoints(e) : this.selectRect(e), this.observe(), this.cleanup()
            }, e.prototype.selectPoints = function (e) {
                return this.pointSelection.isSelected = e, this.pointSelection.set || (this.pointSelection.set = this.parent.set(), this.drawPoints()), this
            }, e.prototype.getPointArray = function () {
                var e = this.el.bbox();
                return this.el.array().valueOf().map((function (t) {
                    return [t[0] - e.x, t[1] - e.y]
                }))
            }, e.prototype.drawPoints = function () {
                for (var e = this, t = this.getPointArray(), n = 0, i = t.length; n < i; ++n) {
                    var a = function (t) {
                            return function (n) {
                                (n = n || window.event).preventDefault ? n.preventDefault() : n.returnValue = !1, n.stopPropagation();
                                var i = n.pageX || n.touches[0].pageX,
                                    a = n.pageY || n.touches[0].pageY;
                                e.el.fire("point", {
                                    x: i,
                                    y: a,
                                    i: t,
                                    event: n
                                })
                            }
                        }(n),
                        r = this.drawPoint(t[n][0], t[n][1]).addClass(this.options.classPoints).addClass(this.options.classPoints + "_point").on("touchstart", a).on("mousedown", a);
                    this.pointSelection.set.add(r)
                }
            }, e.prototype.drawPoint = function (e, t) {
                var n = this.options.pointType;
                switch (n) {
                    case "circle":
                        return this.drawCircle(e, t);
                    case "rect":
                        return this.drawRect(e, t);
                    default:
                        if ("function" == typeof n) return n.call(this, e, t);
                        throw new Error("Unknown " + n + " point type!")
                }
            }, e.prototype.drawCircle = function (e, t) {
                return this.nested.circle(this.options.pointSize).center(e, t)
            }, e.prototype.drawRect = function (e, t) {
                return this.nested.rect(this.options.pointSize, this.options.pointSize).center(e, t)
            }, e.prototype.updatePointSelection = function () {
                var e = this.getPointArray();
                this.pointSelection.set.each((function (t) {
                    this.cx() === e[t][0] && this.cy() === e[t][1] || this.center(e[t][0], e[t][1])
                }))
            }, e.prototype.updateRectSelection = function () {
                var e = this,
                    t = this.el.bbox();
                if (this.rectSelection.set.get(0).attr({
                        width: t.width,
                        height: t.height
                    }), this.options.points.length && this.options.points.map((function (n, i) {
                        var a = e.pointCoords(n, t);
                        e.rectSelection.set.get(i + 1).center(a.x, a.y)
                    })), this.options.rotationPoint) {
                    var n = this.rectSelection.set.length();
                    this.rectSelection.set.get(n - 1).center(t.width / 2, 20)
                }
            }, e.prototype.selectRect = function (e) {
                var t = this,
                    n = this.el.bbox();

                function i(e) {
                    return function (n) {
                        (n = n || window.event).preventDefault ? n.preventDefault() : n.returnValue = !1, n.stopPropagation();
                        var i = n.pageX || n.touches[0].pageX,
                            a = n.pageY || n.touches[0].pageY;
                        t.el.fire(e, {
                            x: i,
                            y: a,
                            event: n
                        })
                    }
                }
                if (this.rectSelection.isSelected = e, this.rectSelection.set = this.rectSelection.set || this.parent.set(), this.rectSelection.set.get(0) || this.rectSelection.set.add(this.nested.rect(n.width, n.height).addClass(this.options.classRect)), this.options.points.length && this.rectSelection.set.length() < 2 && (this.options.points.map((function (e, a) {
                        var r = t.pointCoords(e, n),
                            s = t.drawPoint(r.x, r.y).attr("class", t.options.classPoints + "_" + e).on("mousedown", i(e)).on("touchstart", i(e));
                        t.rectSelection.set.add(s)
                    })), this.rectSelection.set.each((function () {
                        this.addClass(t.options.classPoints)
                    }))), this.options.rotationPoint && (this.options.points && !this.rectSelection.set.get(9) || !this.options.points && !this.rectSelection.set.get(1))) {
                    var a = function (e) {
                            (e = e || window.event).preventDefault ? e.preventDefault() : e.returnValue = !1, e.stopPropagation();
                            var n = e.pageX || e.touches[0].pageX,
                                i = e.pageY || e.touches[0].pageY;
                            t.el.fire("rot", {
                                x: n,
                                y: i,
                                event: e
                            })
                        },
                        r = this.drawPoint(n.width / 2, 20).attr("class", this.options.classPoints + "_rot").on("touchstart", a).on("mousedown", a);
                    this.rectSelection.set.add(r)
                }
            }, e.prototype.handler = function () {
                var e = this.el.bbox();
                this.nested.matrix(new SVG.Matrix(this.el).translate(e.x, e.y)), this.rectSelection.isSelected && this.updateRectSelection(), this.pointSelection.isSelected && this.updatePointSelection()
            }, e.prototype.observe = function () {
                var e = this;
                if (MutationObserver)
                    if (this.rectSelection.isSelected || this.pointSelection.isSelected) this.observerInst = this.observerInst || new MutationObserver((function () {
                        e.handler()
                    })), this.observerInst.observe(this.el.node, {
                        attributes: !0
                    });
                    else try {
                        this.observerInst.disconnect(), delete this.observerInst
                    } catch (e) {} else this.el.off("DOMAttrModified.select"), (this.rectSelection.isSelected || this.pointSelection.isSelected) && this.el.on("DOMAttrModified.select", (function () {
                        e.handler()
                    }))
            }, e.prototype.cleanup = function () {
                !this.rectSelection.isSelected && this.rectSelection.set && (this.rectSelection.set.each((function () {
                    this.remove()
                })), this.rectSelection.set.clear(), delete this.rectSelection.set), !this.pointSelection.isSelected && this.pointSelection.set && (this.pointSelection.set.each((function () {
                    this.remove()
                })), this.pointSelection.set.clear(), delete this.pointSelection.set), this.pointSelection.isSelected || this.rectSelection.isSelected || (this.nested.remove(), delete this.nested)
            }, SVG.extend(SVG.Element, {
                selectize: function (t, n) {
                    return "object" == typeof t && (n = t, t = !0), (this.remember("_selectHandler") || new e(this)).init(void 0 === t || t, n || {}), this
                }
            }), SVG.Element.prototype.selectize.defaults = {
                points: ["lt", "rt", "rb", "lb", "t", "r", "b", "l"],
                pointsExclude: [],
                classRect: "svg_select_boundingRect",
                classPoints: "svg_select_points",
                pointSize: 7,
                rotationPoint: !0,
                deepSelect: !1,
                pointType: "circle"
            }
        }(),
        function () {
            (function () {
                function e(e) {
                    e.remember("_resizeHandler", this), this.el = e, this.parameters = {}, this.lastUpdateCall = null, this.p = e.doc().node.createSVGPoint()
                }
                e.prototype.transformPoint = function (e, t, n) {
                    return this.p.x = e - (this.offset.x - window.pageXOffset), this.p.y = t - (this.offset.y - window.pageYOffset), this.p.matrixTransform(n || this.m)
                }, e.prototype._extractPosition = function (e) {
                    return {
                        x: null != e.clientX ? e.clientX : e.touches[0].clientX,
                        y: null != e.clientY ? e.clientY : e.touches[0].clientY
                    }
                }, e.prototype.init = function (e) {
                    var t = this;
                    if (this.stop(), "stop" !== e) {
                        for (var n in this.options = {}, this.el.resize.defaults) this.options[n] = this.el.resize.defaults[n], void 0 !== e[n] && (this.options[n] = e[n]);
                        this.el.on("lt.resize", (function (e) {
                            t.resize(e || window.event)
                        })), this.el.on("rt.resize", (function (e) {
                            t.resize(e || window.event)
                        })), this.el.on("rb.resize", (function (e) {
                            t.resize(e || window.event)
                        })), this.el.on("lb.resize", (function (e) {
                            t.resize(e || window.event)
                        })), this.el.on("t.resize", (function (e) {
                            t.resize(e || window.event)
                        })), this.el.on("r.resize", (function (e) {
                            t.resize(e || window.event)
                        })), this.el.on("b.resize", (function (e) {
                            t.resize(e || window.event)
                        })), this.el.on("l.resize", (function (e) {
                            t.resize(e || window.event)
                        })), this.el.on("rot.resize", (function (e) {
                            t.resize(e || window.event)
                        })), this.el.on("point.resize", (function (e) {
                            t.resize(e || window.event)
                        })), this.update()
                    }
                }, e.prototype.stop = function () {
                    return this.el.off("lt.resize"), this.el.off("rt.resize"), this.el.off("rb.resize"), this.el.off("lb.resize"), this.el.off("t.resize"), this.el.off("r.resize"), this.el.off("b.resize"), this.el.off("l.resize"), this.el.off("rot.resize"), this.el.off("point.resize"), this
                }, e.prototype.resize = function (e) {
                    var t = this;
                    this.m = this.el.node.getScreenCTM().inverse(), this.offset = {
                        x: window.pageXOffset,
                        y: window.pageYOffset
                    };
                    var n = this._extractPosition(e.detail.event);
                    if (this.parameters = {
                            type: this.el.type,
                            p: this.transformPoint(n.x, n.y),
                            x: e.detail.x,
                            y: e.detail.y,
                            box: this.el.bbox(),
                            rotation: this.el.transform().rotation
                        }, "text" === this.el.type && (this.parameters.fontSize = this.el.attr()["font-size"]), void 0 !== e.detail.i) {
                        var i = this.el.array().valueOf();
                        this.parameters.i = e.detail.i, this.parameters.pointCoords = [i[e.detail.i][0], i[e.detail.i][1]]
                    }
                    switch (e.type) {
                        case "lt":
                            this.calc = function (e, t) {
                                var n = this.snapToGrid(e, t);
                                if (this.parameters.box.width - n[0] > 0 && this.parameters.box.height - n[1] > 0) {
                                    if ("text" === this.parameters.type) return this.el.move(this.parameters.box.x + n[0], this.parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize - n[0]);
                                    n = this.checkAspectRatio(n), this.el.move(this.parameters.box.x + n[0], this.parameters.box.y + n[1]).size(this.parameters.box.width - n[0], this.parameters.box.height - n[1])
                                }
                            };
                            break;
                        case "rt":
                            this.calc = function (e, t) {
                                var n = this.snapToGrid(e, t, 2);
                                if (this.parameters.box.width + n[0] > 0 && this.parameters.box.height - n[1] > 0) {
                                    if ("text" === this.parameters.type) return this.el.move(this.parameters.box.x - n[0], this.parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize + n[0]);
                                    n = this.checkAspectRatio(n, !0), this.el.move(this.parameters.box.x, this.parameters.box.y + n[1]).size(this.parameters.box.width + n[0], this.parameters.box.height - n[1])
                                }
                            };
                            break;
                        case "rb":
                            this.calc = function (e, t) {
                                var n = this.snapToGrid(e, t, 0);
                                if (this.parameters.box.width + n[0] > 0 && this.parameters.box.height + n[1] > 0) {
                                    if ("text" === this.parameters.type) return this.el.move(this.parameters.box.x - n[0], this.parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize + n[0]);
                                    n = this.checkAspectRatio(n), this.el.move(this.parameters.box.x, this.parameters.box.y).size(this.parameters.box.width + n[0], this.parameters.box.height + n[1])
                                }
                            };
                            break;
                        case "lb":
                            this.calc = function (e, t) {
                                var n = this.snapToGrid(e, t, 1);
                                if (this.parameters.box.width - n[0] > 0 && this.parameters.box.height + n[1] > 0) {
                                    if ("text" === this.parameters.type) return this.el.move(this.parameters.box.x + n[0], this.parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize - n[0]);
                                    n = this.checkAspectRatio(n, !0), this.el.move(this.parameters.box.x + n[0], this.parameters.box.y).size(this.parameters.box.width - n[0], this.parameters.box.height + n[1])
                                }
                            };
                            break;
                        case "t":
                            this.calc = function (e, t) {
                                var n = this.snapToGrid(e, t, 2);
                                if (this.parameters.box.height - n[1] > 0) {
                                    if ("text" === this.parameters.type) return;
                                    this.el.move(this.parameters.box.x, this.parameters.box.y + n[1]).height(this.parameters.box.height - n[1])
                                }
                            };
                            break;
                        case "r":
                            this.calc = function (e, t) {
                                var n = this.snapToGrid(e, t, 0);
                                if (this.parameters.box.width + n[0] > 0) {
                                    if ("text" === this.parameters.type) return;
                                    this.el.move(this.parameters.box.x, this.parameters.box.y).width(this.parameters.box.width + n[0])
                                }
                            };
                            break;
                        case "b":
                            this.calc = function (e, t) {
                                var n = this.snapToGrid(e, t, 0);
                                if (this.parameters.box.height + n[1] > 0) {
                                    if ("text" === this.parameters.type) return;
                                    this.el.move(this.parameters.box.x, this.parameters.box.y).height(this.parameters.box.height + n[1])
                                }
                            };
                            break;
                        case "l":
                            this.calc = function (e, t) {
                                var n = this.snapToGrid(e, t, 1);
                                if (this.parameters.box.width - n[0] > 0) {
                                    if ("text" === this.parameters.type) return;
                                    this.el.move(this.parameters.box.x + n[0], this.parameters.box.y).width(this.parameters.box.width - n[0])
                                }
                            };
                            break;
                        case "rot":
                            this.calc = function (e, t) {
                                var n = e + this.parameters.p.x,
                                    i = t + this.parameters.p.y,
                                    a = Math.atan2(this.parameters.p.y - this.parameters.box.y - this.parameters.box.height / 2, this.parameters.p.x - this.parameters.box.x - this.parameters.box.width / 2),
                                    r = Math.atan2(i - this.parameters.box.y - this.parameters.box.height / 2, n - this.parameters.box.x - this.parameters.box.width / 2),
                                    s = this.parameters.rotation + 180 * (r - a) / Math.PI + this.options.snapToAngle / 2;
                                this.el.center(this.parameters.box.cx, this.parameters.box.cy).rotate(s - s % this.options.snapToAngle, this.parameters.box.cx, this.parameters.box.cy)
                            };
                            break;
                        case "point":
                            this.calc = function (e, t) {
                                var n = this.snapToGrid(e, t, this.parameters.pointCoords[0], this.parameters.pointCoords[1]),
                                    i = this.el.array().valueOf();
                                i[this.parameters.i][0] = this.parameters.pointCoords[0] + n[0], i[this.parameters.i][1] = this.parameters.pointCoords[1] + n[1], this.el.plot(i)
                            }
                    }
                    this.el.fire("resizestart", {
                        dx: this.parameters.x,
                        dy: this.parameters.y,
                        event: e
                    }), SVG.on(window, "touchmove.resize", (function (e) {
                        t.update(e || window.event)
                    })), SVG.on(window, "touchend.resize", (function () {
                        t.done()
                    })), SVG.on(window, "mousemove.resize", (function (e) {
                        t.update(e || window.event)
                    })), SVG.on(window, "mouseup.resize", (function () {
                        t.done()
                    }))
                }, e.prototype.update = function (e) {
                    if (e) {
                        var t = this._extractPosition(e),
                            n = this.transformPoint(t.x, t.y),
                            i = n.x - this.parameters.p.x,
                            a = n.y - this.parameters.p.y;
                        this.lastUpdateCall = [i, a], this.calc(i, a), this.el.fire("resizing", {
                            dx: i,
                            dy: a,
                            event: e
                        })
                    } else this.lastUpdateCall && this.calc(this.lastUpdateCall[0], this.lastUpdateCall[1])
                }, e.prototype.done = function () {
                    this.lastUpdateCall = null, SVG.off(window, "mousemove.resize"), SVG.off(window, "mouseup.resize"), SVG.off(window, "touchmove.resize"), SVG.off(window, "touchend.resize"), this.el.fire("resizedone")
                }, e.prototype.snapToGrid = function (e, t, n, i) {
                    var a;
                    return void 0 !== i ? a = [(n + e) % this.options.snapToGrid, (i + t) % this.options.snapToGrid] : (n = null == n ? 3 : n, a = [(this.parameters.box.x + e + (1 & n ? 0 : this.parameters.box.width)) % this.options.snapToGrid, (this.parameters.box.y + t + (2 & n ? 0 : this.parameters.box.height)) % this.options.snapToGrid]), e < 0 && (a[0] -= this.options.snapToGrid), t < 0 && (a[1] -= this.options.snapToGrid), e -= Math.abs(a[0]) < this.options.snapToGrid / 2 ? a[0] : a[0] - (e < 0 ? -this.options.snapToGrid : this.options.snapToGrid), t -= Math.abs(a[1]) < this.options.snapToGrid / 2 ? a[1] : a[1] - (t < 0 ? -this.options.snapToGrid : this.options.snapToGrid), this.constraintToBox(e, t, n, i)
                }, e.prototype.constraintToBox = function (e, t, n, i) {
                    var a, r, s = this.options.constraint || {};
                    return void 0 !== i ? (a = n, r = i) : (a = this.parameters.box.x + (1 & n ? 0 : this.parameters.box.width), r = this.parameters.box.y + (2 & n ? 0 : this.parameters.box.height)), void 0 !== s.minX && a + e < s.minX && (e = s.minX - a), void 0 !== s.maxX && a + e > s.maxX && (e = s.maxX - a), void 0 !== s.minY && r + t < s.minY && (t = s.minY - r), void 0 !== s.maxY && r + t > s.maxY && (t = s.maxY - r), [e, t]
                }, e.prototype.checkAspectRatio = function (e, t) {
                    if (!this.options.saveAspectRatio) return e;
                    var n = e.slice(),
                        i = this.parameters.box.width / this.parameters.box.height,
                        a = this.parameters.box.width + e[0],
                        r = this.parameters.box.height - e[1],
                        s = a / r;
                    return s < i ? (n[1] = a / i - this.parameters.box.height, t && (n[1] = -n[1])) : s > i && (n[0] = this.parameters.box.width - r * i, t && (n[0] = -n[0])), n
                }, SVG.extend(SVG.Element, {
                    resize: function (t) {
                        return (this.remember("_resizeHandler") || new e(this)).init(t || {}), this
                    }
                }), SVG.Element.prototype.resize.defaults = {
                    snapToAngle: .1,
                    snapToGrid: 1,
                    constraint: {},
                    saveAspectRatio: !1
                }
            }).call(this)
        }(), void 0 === window.Apex && (window.Apex = {});
    var Ye = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "initModules",
                value: function () {
                    this.ctx.publicMethods = ["updateOptions", "updateSeries", "appendData", "appendSeries", "toggleSeries", "showSeries", "hideSeries", "setLocale", "resetSeries", "zoomX", "toggleDataPointSelection", "dataURI", "addXaxisAnnotation", "addYaxisAnnotation", "addPointAnnotation", "clearAnnotations", "removeAnnotation", "paper", "destroy"], this.ctx.eventList = ["click", "mousedown", "mousemove", "mouseleave", "touchstart", "touchmove", "touchleave", "mouseup", "touchend"], this.ctx.animations = new m(this.ctx), this.ctx.axes = new K(this.ctx), this.ctx.core = new Oe(this.ctx.el, this.ctx), this.ctx.config = new N({}), this.ctx.data = new R(this.ctx), this.ctx.grid = new q(this.ctx), this.ctx.graphics = new v(this.ctx), this.ctx.coreUtils = new x(this.ctx), this.ctx.crosshairs = new J(this.ctx), this.ctx.events = new G(this.ctx), this.ctx.exports = new W(this.ctx), this.ctx.localization = new Z(this.ctx), this.ctx.options = new M, this.ctx.responsive = new Q(this.ctx), this.ctx.series = new E(this.ctx), this.ctx.theme = new ee(this.ctx), this.ctx.formatters = new z(this.ctx), this.ctx.titleSubtitle = new te(this.ctx), this.ctx.legend = new le(this.ctx), this.ctx.toolbar = new ce(this.ctx), this.ctx.dimensions = new se(this.ctx), this.ctx.updateHelpers = new Pe(this.ctx), this.ctx.zoomPanSelection = new ue(this.ctx), this.ctx.w.globals.tooltip = new ve(this.ctx)
                }
            }]), e
        }(),
        Ie = function () {
            function e(t) {
                i(this, e), this.ctx = t, this.w = t.w
            }
            return r(e, [{
                key: "clear",
                value: function (e) {
                    var t = e.isUpdating;
                    this.ctx.zoomPanSelection && this.ctx.zoomPanSelection.destroy(), this.ctx.toolbar && this.ctx.toolbar.destroy(), this.ctx.animations = null, this.ctx.axes = null, this.ctx.annotations = null, this.ctx.core = null, this.ctx.data = null, this.ctx.grid = null, this.ctx.series = null, this.ctx.responsive = null, this.ctx.theme = null, this.ctx.formatters = null, this.ctx.titleSubtitle = null, this.ctx.legend = null, this.ctx.dimensions = null, this.ctx.options = null, this.ctx.crosshairs = null, this.ctx.zoomPanSelection = null, this.ctx.updateHelpers = null, this.ctx.toolbar = null, this.ctx.localization = null, this.ctx.w.globals.tooltip = null, this.clearDomElements({
                        isUpdating: t
                    })
                }
            }, {
                key: "killSVG",
                value: function (e) {
                    e.each((function (e, t) {
                        this.removeClass("*"), this.off(), this.stop()
                    }), !0), e.ungroup(), e.clear()
                }
            }, {
                key: "clearDomElements",
                value: function (e) {
                    var t = this,
                        n = e.isUpdating,
                        i = this.w.globals.dom.Paper.node;
                    i.parentNode && i.parentNode.parentNode && !n && (i.parentNode.parentNode.style.minHeight = "unset");
                    var a = this.w.globals.dom.baseEl;
                    a && this.ctx.eventList.forEach((function (e) {
                        a.removeEventListener(e, t.ctx.events.documentEvent)
                    }));
                    var r = this.w.globals.dom;
                    if (null !== this.ctx.el)
                        for (; this.ctx.el.firstChild;) this.ctx.el.removeChild(this.ctx.el.firstChild);
                    this.killSVG(r.Paper), r.Paper.remove(), r.elWrap = null, r.elGraphical = null, r.elAnnotations = null, r.elLegendWrap = null, r.baseEl = null, r.elGridRect = null, r.elGridRectMask = null, r.elGridRectMarkerMask = null, r.elForecastMask = null, r.elNonForecastMask = null, r.elDefs = null
                }
            }]), e
        }(),
        je = new WeakMap;
    return function () {
        function e(t, n) {
            i(this, e), this.opts = n, this.ctx = this, this.w = new F(n).init(), this.el = t, this.w.globals.cuid = p.randomId(), this.w.globals.chartID = this.w.config.chart.id ? p.escapeString(this.w.config.chart.id) : this.w.globals.cuid, new Ye(this).initModules(), this.create = p.bind(this.create, this), this.windowResizeHandler = this._windowResizeHandler.bind(this), this.parentResizeHandler = this._parentResizeCallback.bind(this)
        }
        return r(e, [{
            key: "render",
            value: function () {
                var e = this;
                return new Promise((function (t, n) {
                    if (null !== e.el) {
                        void 0 === Apex._chartInstances && (Apex._chartInstances = []), e.w.config.chart.id && Apex._chartInstances.push({
                            id: e.w.globals.chartID,
                            group: e.w.config.chart.group,
                            chart: e
                        }), e.setLocale(e.w.config.chart.defaultLocale);
                        var i = e.w.config.chart.events.beforeMount;
                        if ("function" == typeof i && i(e, e.w), e.events.fireEvent("beforeMount", [e, e.w]), window.addEventListener("resize", e.windowResizeHandler), c = e.el.parentNode, u = e.parentResizeHandler, d = !1, h = new ResizeObserver((function (e) {
                                d && u.call(c, e), d = !0
                            })), c.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? Array.from(c.children).forEach((function (e) {
                                return h.observe(e)
                            })) : h.observe(c), je.set(u, h), !e.css) {
                            var a = e.el.getRootNode && e.el.getRootNode(),
                                r = p.is("ShadowRoot", a),
                                s = e.el.ownerDocument,
                                o = s.getElementById("apexcharts-css");
                            !r && o || (e.css = document.createElement("style"), e.css.id = "apexcharts-css", e.css.textContent = '.apexcharts-canvas {\n  position: relative;\n  user-select: none;\n  /* cannot give overflow: hidden as it will crop tooltips which overflow outside chart area */\n}\n\n\n/* scrollbar is not visible by default for legend, hence forcing the visibility */\n.apexcharts-canvas ::-webkit-scrollbar {\n  -webkit-appearance: none;\n  width: 6px;\n}\n\n.apexcharts-canvas ::-webkit-scrollbar-thumb {\n  border-radius: 4px;\n  background-color: rgba(0, 0, 0, .5);\n  box-shadow: 0 0 1px rgba(255, 255, 255, .5);\n  -webkit-box-shadow: 0 0 1px rgba(255, 255, 255, .5);\n}\n\n\n.apexcharts-inner {\n  position: relative;\n}\n\n.apexcharts-text tspan {\n  font-family: inherit;\n}\n\n.legend-mouseover-inactive {\n  transition: 0.15s ease all;\n  opacity: 0.20;\n}\n\n.apexcharts-series-collapsed {\n  opacity: 0;\n}\n\n.apexcharts-tooltip {\n  border-radius: 5px;\n  box-shadow: 2px 2px 6px -4px #999;\n  cursor: default;\n  font-size: 14px;\n  left: 62px;\n  opacity: 0;\n  pointer-events: none;\n  position: absolute;\n  top: 20px;\n  display: flex;\n  flex-direction: column;\n  overflow: hidden;\n  white-space: nowrap;\n  z-index: 12;\n  transition: 0.15s ease all;\n}\n\n.apexcharts-tooltip.apexcharts-active {\n  opacity: 1;\n  transition: 0.15s ease all;\n}\n\n.apexcharts-tooltip.apexcharts-theme-light {\n  border: 1px solid #e3e3e3;\n  background: rgba(255, 255, 255, 0.96);\n}\n\n.apexcharts-tooltip.apexcharts-theme-dark {\n  color: #fff;\n  background: rgba(30, 30, 30, 0.8);\n}\n\n.apexcharts-tooltip * {\n  font-family: inherit;\n}\n\n\n.apexcharts-tooltip-title {\n  padding: 6px;\n  font-size: 15px;\n  margin-bottom: 4px;\n}\n\n.apexcharts-tooltip.apexcharts-theme-light .apexcharts-tooltip-title {\n  background: #ECEFF1;\n  border-bottom: 1px solid #ddd;\n}\n\n.apexcharts-tooltip.apexcharts-theme-dark .apexcharts-tooltip-title {\n  background: rgba(0, 0, 0, 0.7);\n  border-bottom: 1px solid #333;\n}\n\n.apexcharts-tooltip-text-y-value,\n.apexcharts-tooltip-text-goals-value,\n.apexcharts-tooltip-text-z-value {\n  display: inline-block;\n  font-weight: 600;\n  margin-left: 5px;\n}\n\n.apexcharts-tooltip-text-y-label:empty,\n.apexcharts-tooltip-text-y-value:empty,\n.apexcharts-tooltip-text-goals-label:empty,\n.apexcharts-tooltip-text-goals-value:empty,\n.apexcharts-tooltip-text-z-value:empty {\n  display: none;\n}\n\n.apexcharts-tooltip-text-y-value,\n.apexcharts-tooltip-text-goals-value,\n.apexcharts-tooltip-text-z-value {\n  font-weight: 600;\n}\n\n.apexcharts-tooltip-text-goals-label, \n.apexcharts-tooltip-text-goals-value {\n  padding: 6px 0 5px;\n}\n\n.apexcharts-tooltip-goals-group, \n.apexcharts-tooltip-text-goals-label, \n.apexcharts-tooltip-text-goals-value {\n  display: flex;\n}\n.apexcharts-tooltip-text-goals-label:not(:empty),\n.apexcharts-tooltip-text-goals-value:not(:empty) {\n  margin-top: -6px;\n}\n\n.apexcharts-tooltip-marker {\n  width: 12px;\n  height: 12px;\n  position: relative;\n  top: 0px;\n  margin-right: 10px;\n  border-radius: 50%;\n}\n\n.apexcharts-tooltip-series-group {\n  padding: 0 10px;\n  display: none;\n  text-align: left;\n  justify-content: left;\n  align-items: center;\n}\n\n.apexcharts-tooltip-series-group.apexcharts-active .apexcharts-tooltip-marker {\n  opacity: 1;\n}\n\n.apexcharts-tooltip-series-group.apexcharts-active,\n.apexcharts-tooltip-series-group:last-child {\n  padding-bottom: 4px;\n}\n\n.apexcharts-tooltip-series-group-hidden {\n  opacity: 0;\n  height: 0;\n  line-height: 0;\n  padding: 0 !important;\n}\n\n.apexcharts-tooltip-y-group {\n  padding: 6px 0 5px;\n}\n\n.apexcharts-tooltip-box, .apexcharts-custom-tooltip {\n  padding: 4px 8px;\n}\n\n.apexcharts-tooltip-boxPlot {\n  display: flex;\n  flex-direction: column-reverse;\n}\n\n.apexcharts-tooltip-box>div {\n  margin: 4px 0;\n}\n\n.apexcharts-tooltip-box span.value {\n  font-weight: bold;\n}\n\n.apexcharts-tooltip-rangebar {\n  padding: 5px 8px;\n}\n\n.apexcharts-tooltip-rangebar .category {\n  font-weight: 600;\n  color: #777;\n}\n\n.apexcharts-tooltip-rangebar .series-name {\n  font-weight: bold;\n  display: block;\n  margin-bottom: 5px;\n}\n\n.apexcharts-xaxistooltip {\n  opacity: 0;\n  padding: 9px 10px;\n  pointer-events: none;\n  color: #373d3f;\n  font-size: 13px;\n  text-align: center;\n  border-radius: 2px;\n  position: absolute;\n  z-index: 10;\n  background: #ECEFF1;\n  border: 1px solid #90A4AE;\n  transition: 0.15s ease all;\n}\n\n.apexcharts-xaxistooltip.apexcharts-theme-dark {\n  background: rgba(0, 0, 0, 0.7);\n  border: 1px solid rgba(0, 0, 0, 0.5);\n  color: #fff;\n}\n\n.apexcharts-xaxistooltip:after,\n.apexcharts-xaxistooltip:before {\n  left: 50%;\n  border: solid transparent;\n  content: " ";\n  height: 0;\n  width: 0;\n  position: absolute;\n  pointer-events: none;\n}\n\n.apexcharts-xaxistooltip:after {\n  border-color: rgba(236, 239, 241, 0);\n  border-width: 6px;\n  margin-left: -6px;\n}\n\n.apexcharts-xaxistooltip:before {\n  border-color: rgba(144, 164, 174, 0);\n  border-width: 7px;\n  margin-left: -7px;\n}\n\n.apexcharts-xaxistooltip-bottom:after,\n.apexcharts-xaxistooltip-bottom:before {\n  bottom: 100%;\n}\n\n.apexcharts-xaxistooltip-top:after,\n.apexcharts-xaxistooltip-top:before {\n  top: 100%;\n}\n\n.apexcharts-xaxistooltip-bottom:after {\n  border-bottom-color: #ECEFF1;\n}\n\n.apexcharts-xaxistooltip-bottom:before {\n  border-bottom-color: #90A4AE;\n}\n\n.apexcharts-xaxistooltip-bottom.apexcharts-theme-dark:after {\n  border-bottom-color: rgba(0, 0, 0, 0.5);\n}\n\n.apexcharts-xaxistooltip-bottom.apexcharts-theme-dark:before {\n  border-bottom-color: rgba(0, 0, 0, 0.5);\n}\n\n.apexcharts-xaxistooltip-top:after {\n  border-top-color: #ECEFF1\n}\n\n.apexcharts-xaxistooltip-top:before {\n  border-top-color: #90A4AE;\n}\n\n.apexcharts-xaxistooltip-top.apexcharts-theme-dark:after {\n  border-top-color: rgba(0, 0, 0, 0.5);\n}\n\n.apexcharts-xaxistooltip-top.apexcharts-theme-dark:before {\n  border-top-color: rgba(0, 0, 0, 0.5);\n}\n\n.apexcharts-xaxistooltip.apexcharts-active {\n  opacity: 1;\n  transition: 0.15s ease all;\n}\n\n.apexcharts-yaxistooltip {\n  opacity: 0;\n  padding: 4px 10px;\n  pointer-events: none;\n  color: #373d3f;\n  font-size: 13px;\n  text-align: center;\n  border-radius: 2px;\n  position: absolute;\n  z-index: 10;\n  background: #ECEFF1;\n  border: 1px solid #90A4AE;\n}\n\n.apexcharts-yaxistooltip.apexcharts-theme-dark {\n  background: rgba(0, 0, 0, 0.7);\n  border: 1px solid rgba(0, 0, 0, 0.5);\n  color: #fff;\n}\n\n.apexcharts-yaxistooltip:after,\n.apexcharts-yaxistooltip:before {\n  top: 50%;\n  border: solid transparent;\n  content: " ";\n  height: 0;\n  width: 0;\n  position: absolute;\n  pointer-events: none;\n}\n\n.apexcharts-yaxistooltip:after {\n  border-color: rgba(236, 239, 241, 0);\n  border-width: 6px;\n  margin-top: -6px;\n}\n\n.apexcharts-yaxistooltip:before {\n  border-color: rgba(144, 164, 174, 0);\n  border-width: 7px;\n  margin-top: -7px;\n}\n\n.apexcharts-yaxistooltip-left:after,\n.apexcharts-yaxistooltip-left:before {\n  left: 100%;\n}\n\n.apexcharts-yaxistooltip-right:after,\n.apexcharts-yaxistooltip-right:before {\n  right: 100%;\n}\n\n.apexcharts-yaxistooltip-left:after {\n  border-left-color: #ECEFF1;\n}\n\n.apexcharts-yaxistooltip-left:before {\n  border-left-color: #90A4AE;\n}\n\n.apexcharts-yaxistooltip-left.apexcharts-theme-dark:after {\n  border-left-color: rgba(0, 0, 0, 0.5);\n}\n\n.apexcharts-yaxistooltip-left.apexcharts-theme-dark:before {\n  border-left-color: rgba(0, 0, 0, 0.5);\n}\n\n.apexcharts-yaxistooltip-right:after {\n  border-right-color: #ECEFF1;\n}\n\n.apexcharts-yaxistooltip-right:before {\n  border-right-color: #90A4AE;\n}\n\n.apexcharts-yaxistooltip-right.apexcharts-theme-dark:after {\n  border-right-color: rgba(0, 0, 0, 0.5);\n}\n\n.apexcharts-yaxistooltip-right.apexcharts-theme-dark:before {\n  border-right-color: rgba(0, 0, 0, 0.5);\n}\n\n.apexcharts-yaxistooltip.apexcharts-active {\n  opacity: 1;\n}\n\n.apexcharts-yaxistooltip-hidden {\n  display: none;\n}\n\n.apexcharts-xcrosshairs,\n.apexcharts-ycrosshairs {\n  pointer-events: none;\n  opacity: 0;\n  transition: 0.15s ease all;\n}\n\n.apexcharts-xcrosshairs.apexcharts-active,\n.apexcharts-ycrosshairs.apexcharts-active {\n  opacity: 1;\n  transition: 0.15s ease all;\n}\n\n.apexcharts-ycrosshairs-hidden {\n  opacity: 0;\n}\n\n.apexcharts-selection-rect {\n  cursor: move;\n}\n\n.svg_select_boundingRect, .svg_select_points_rot {\n  pointer-events: none;\n  opacity: 0;\n  visibility: hidden;\n}\n.apexcharts-selection-rect + g .svg_select_boundingRect,\n.apexcharts-selection-rect + g .svg_select_points_rot {\n  opacity: 0;\n  visibility: hidden;\n}\n\n.apexcharts-selection-rect + g .svg_select_points_l,\n.apexcharts-selection-rect + g .svg_select_points_r {\n  cursor: ew-resize;\n  opacity: 1;\n  visibility: visible;\n}\n\n.svg_select_points {\n  fill: #efefef;\n  stroke: #333;\n  rx: 2;\n}\n\n.apexcharts-svg.apexcharts-zoomable.hovering-zoom {\n  cursor: crosshair\n}\n\n.apexcharts-svg.apexcharts-zoomable.hovering-pan {\n  cursor: move\n}\n\n.apexcharts-zoom-icon,\n.apexcharts-zoomin-icon,\n.apexcharts-zoomout-icon,\n.apexcharts-reset-icon,\n.apexcharts-pan-icon,\n.apexcharts-selection-icon,\n.apexcharts-menu-icon,\n.apexcharts-toolbar-custom-icon {\n  cursor: pointer;\n  width: 20px;\n  height: 20px;\n  line-height: 24px;\n  color: #6E8192;\n  text-align: center;\n}\n\n.apexcharts-zoom-icon svg,\n.apexcharts-zoomin-icon svg,\n.apexcharts-zoomout-icon svg,\n.apexcharts-reset-icon svg,\n.apexcharts-menu-icon svg {\n  fill: #6E8192;\n}\n\n.apexcharts-selection-icon svg {\n  fill: #444;\n  transform: scale(0.76)\n}\n\n.apexcharts-theme-dark .apexcharts-zoom-icon svg,\n.apexcharts-theme-dark .apexcharts-zoomin-icon svg,\n.apexcharts-theme-dark .apexcharts-zoomout-icon svg,\n.apexcharts-theme-dark .apexcharts-reset-icon svg,\n.apexcharts-theme-dark .apexcharts-pan-icon svg,\n.apexcharts-theme-dark .apexcharts-selection-icon svg,\n.apexcharts-theme-dark .apexcharts-menu-icon svg,\n.apexcharts-theme-dark .apexcharts-toolbar-custom-icon svg {\n  fill: #f3f4f5;\n}\n\n.apexcharts-canvas .apexcharts-zoom-icon.apexcharts-selected svg,\n.apexcharts-canvas .apexcharts-selection-icon.apexcharts-selected svg,\n.apexcharts-canvas .apexcharts-reset-zoom-icon.apexcharts-selected svg {\n  fill: #008FFB;\n}\n\n.apexcharts-theme-light .apexcharts-selection-icon:not(.apexcharts-selected):hover svg,\n.apexcharts-theme-light .apexcharts-zoom-icon:not(.apexcharts-selected):hover svg,\n.apexcharts-theme-light .apexcharts-zoomin-icon:hover svg,\n.apexcharts-theme-light .apexcharts-zoomout-icon:hover svg,\n.apexcharts-theme-light .apexcharts-reset-icon:hover svg,\n.apexcharts-theme-light .apexcharts-menu-icon:hover svg {\n  fill: #333;\n}\n\n.apexcharts-selection-icon,\n.apexcharts-menu-icon {\n  position: relative;\n}\n\n.apexcharts-reset-icon {\n  margin-left: 5px;\n}\n\n.apexcharts-zoom-icon,\n.apexcharts-reset-icon,\n.apexcharts-menu-icon {\n  transform: scale(0.85);\n}\n\n.apexcharts-zoomin-icon,\n.apexcharts-zoomout-icon {\n  transform: scale(0.7)\n}\n\n.apexcharts-zoomout-icon {\n  margin-right: 3px;\n}\n\n.apexcharts-pan-icon {\n  transform: scale(0.62);\n  position: relative;\n  left: 1px;\n  top: 0px;\n}\n\n.apexcharts-pan-icon svg {\n  fill: #fff;\n  stroke: #6E8192;\n  stroke-width: 2;\n}\n\n.apexcharts-pan-icon.apexcharts-selected svg {\n  stroke: #008FFB;\n}\n\n.apexcharts-pan-icon:not(.apexcharts-selected):hover svg {\n  stroke: #333;\n}\n\n.apexcharts-toolbar {\n  position: absolute;\n  z-index: 11;\n  max-width: 176px;\n  text-align: right;\n  border-radius: 3px;\n  padding: 0px 6px 2px 6px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n\n.apexcharts-menu {\n  background: #fff;\n  position: absolute;\n  top: 100%;\n  border: 1px solid #ddd;\n  border-radius: 3px;\n  padding: 3px;\n  right: 10px;\n  opacity: 0;\n  min-width: 110px;\n  transition: 0.15s ease all;\n  pointer-events: none;\n}\n\n.apexcharts-menu.apexcharts-menu-open {\n  opacity: 1;\n  pointer-events: all;\n  transition: 0.15s ease all;\n}\n\n.apexcharts-menu-item {\n  padding: 6px 7px;\n  font-size: 12px;\n  cursor: pointer;\n}\n\n.apexcharts-theme-light .apexcharts-menu-item:hover {\n  background: #eee;\n}\n\n.apexcharts-theme-dark .apexcharts-menu {\n  background: rgba(0, 0, 0, 0.7);\n  color: #fff;\n}\n\n@media screen and (min-width: 768px) {\n  .apexcharts-canvas:hover .apexcharts-toolbar {\n    opacity: 1;\n  }\n}\n\n.apexcharts-datalabel.apexcharts-element-hidden {\n  opacity: 0;\n}\n\n.apexcharts-pie-label,\n.apexcharts-datalabels,\n.apexcharts-datalabel,\n.apexcharts-datalabel-label,\n.apexcharts-datalabel-value {\n  cursor: default;\n  pointer-events: none;\n}\n\n.apexcharts-pie-label-delay {\n  opacity: 0;\n  animation-name: opaque;\n  animation-duration: 0.3s;\n  animation-fill-mode: forwards;\n  animation-timing-function: ease;\n}\n\n.apexcharts-canvas .apexcharts-element-hidden {\n  opacity: 0;\n}\n\n.apexcharts-hide .apexcharts-series-points {\n  opacity: 0;\n}\n\n.apexcharts-gridline,\n.apexcharts-annotation-rect,\n.apexcharts-tooltip .apexcharts-marker,\n.apexcharts-area-series .apexcharts-area,\n.apexcharts-line,\n.apexcharts-zoom-rect,\n.apexcharts-toolbar svg,\n.apexcharts-area-series .apexcharts-series-markers .apexcharts-marker.no-pointer-events,\n.apexcharts-line-series .apexcharts-series-markers .apexcharts-marker.no-pointer-events,\n.apexcharts-radar-series path,\n.apexcharts-radar-series polygon {\n  pointer-events: none;\n}\n\n\n/* markers */\n\n.apexcharts-marker {\n  transition: 0.15s ease all;\n}\n\n@keyframes opaque {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n\n\n/* Resize generated styles */\n\n@keyframes resizeanim {\n  from {\n    opacity: 0;\n  }\n  to {\n    opacity: 0;\n  }\n}\n\n.resize-triggers {\n  animation: 1ms resizeanim;\n  visibility: hidden;\n  opacity: 0;\n}\n\n.resize-triggers,\n.resize-triggers>div,\n.contract-trigger:before {\n  content: " ";\n  display: block;\n  position: absolute;\n  top: 0;\n  left: 0;\n  height: 100%;\n  width: 100%;\n  overflow: hidden;\n}\n\n.resize-triggers>div {\n  background: #eee;\n  overflow: auto;\n}\n\n.contract-trigger:before {\n  width: 200%;\n  height: 200%;\n}', r ? a.prepend(e.css) : s.head.appendChild(e.css))
                        }
                        var l = e.create(e.w.config.series, {});
                        if (!l) return t(e);
                        e.mount(l).then((function () {
                            "function" == typeof e.w.config.chart.events.mounted && e.w.config.chart.events.mounted(e, e.w), e.events.fireEvent("mounted", [e, e.w]), t(l)
                        })).catch((function (e) {
                            n(e)
                        }))
                    } else n(new Error("Element not found"));
                    var c, u, d, h
                }))
            }
        }, {
            key: "create",
            value: function (e, t) {
                var n = this.w;
                new Ye(this).initModules();
                var i = this.w.globals;
                if (i.noData = !1, i.animationEnded = !1, this.responsive.checkResponsiveConfig(t), n.config.xaxis.convertedCatToNumeric && new j(n.config).convertCatToNumericXaxis(n.config, this.ctx), null === this.el) return i.animationEnded = !0, null;
                if (this.core.setupElements(), "treemap" === n.config.chart.type && (n.config.grid.show = !1, n.config.yaxis[0].show = !1), 0 === i.svgWidth) return i.animationEnded = !0, null;
                var a = x.checkComboSeries(e);
                i.comboCharts = a.comboCharts, i.comboBarCount = a.comboBarCount;
                var r = e.every((function (e) {
                    return e.data && 0 === e.data.length
                }));
                (0 === e.length || r) && this.series.handleNoData(), this.events.setupEventHandlers(), this.data.parseData(e), this.theme.init(), new A(this).setGlobalMarkerSize(), this.formatters.setLabelFormatters(), this.titleSubtitle.draw(), i.noData && i.collapsedSeries.length !== i.series.length && !n.config.legend.showForSingleSeries || this.legend.init(), this.series.hasAllSeriesEqualX(), i.axisCharts && (this.core.coreCalculations(), "category" !== n.config.xaxis.type && this.formatters.setLabelFormatters(), this.ctx.toolbar.minX = n.globals.minX, this.ctx.toolbar.maxX = n.globals.maxX), this.formatters.heatmapLabelFormatters(), this.dimensions.plotCoords();
                var s = this.core.xySettings();
                this.grid.createGridMask();
                var o = this.core.plotChartType(e, s),
                    l = new C(this);
                l.bringForward(), n.config.dataLabels.background.enabled && l.dataLabelsBackground(), this.core.shiftGraphPosition();
                var c = {
                    plot: {
                        left: n.globals.translateX,
                        top: n.globals.translateY,
                        width: n.globals.gridWidth,
                        height: n.globals.gridHeight
                    }
                };
                return {
                    elGraph: o,
                    xyRatios: s,
                    elInner: n.globals.dom.elGraphical,
                    dimensions: c
                }
            }
        }, {
            key: "mount",
            value: function () {
                var e = this,
                    t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                    n = this,
                    i = n.w;
                return new Promise((function (a, r) {
                    if (null === n.el) return r(new Error("Not enough data to display or target element not found"));
                    (null === t || i.globals.allSeriesCollapsed) && n.series.handleNoData(), "treemap" !== i.config.chart.type && n.axes.drawAxis(i.config.chart.type, t.xyRatios), n.grid = new q(n);
                    var s = n.grid.drawGrid();
                    n.annotations = new L(n), n.annotations.drawImageAnnos(), n.annotations.drawTextAnnos(), "back" === i.config.grid.position && s && i.globals.dom.elGraphical.add(s.el);
                    var o = new V(e.ctx),
                        l = new $(e.ctx);
                    if (null !== s && (o.xAxisLabelCorrections(s.xAxisTickWidth), l.setYAxisTextAlignments(), i.config.yaxis.map((function (e, t) {
                            -1 === i.globals.ignoreYAxisIndexes.indexOf(t) && l.yAxisTitleRotate(t, e.opposite)
                        }))), "back" === i.config.annotations.position && (i.globals.dom.Paper.add(i.globals.dom.elAnnotations), n.annotations.drawAxesAnnotations()), Array.isArray(t.elGraph))
                        for (var c = 0; c < t.elGraph.length; c++) i.globals.dom.elGraphical.add(t.elGraph[c]);
                    else i.globals.dom.elGraphical.add(t.elGraph);
                    if ("front" === i.config.grid.position && s && i.globals.dom.elGraphical.add(s.el), "front" === i.config.xaxis.crosshairs.position && n.crosshairs.drawXCrosshairs(), "front" === i.config.yaxis[0].crosshairs.position && n.crosshairs.drawYCrosshairs(), "front" === i.config.annotations.position && (i.globals.dom.Paper.add(i.globals.dom.elAnnotations), n.annotations.drawAxesAnnotations()), !i.globals.noData) {
                        if (i.config.tooltip.enabled && !i.globals.noData && n.w.globals.tooltip.drawTooltip(t.xyRatios), i.globals.axisCharts && (i.globals.isXNumeric || i.config.xaxis.convertedCatToNumeric || i.globals.isRangeBar))(i.config.chart.zoom.enabled || i.config.chart.selection && i.config.chart.selection.enabled || i.config.chart.pan && i.config.chart.pan.enabled) && n.zoomPanSelection.init({
                            xyRatios: t.xyRatios
                        });
                        else {
                            var u = i.config.chart.toolbar.tools;
                            ["zoom", "zoomin", "zoomout", "selection", "pan", "reset"].forEach((function (e) {
                                u[e] = !1
                            }))
                        }
                        i.config.chart.toolbar.show && !i.globals.allSeriesCollapsed && n.toolbar.createToolbar()
                    }
                    i.globals.memory.methodsToExec.length > 0 && i.globals.memory.methodsToExec.forEach((function (e) {
                        e.method(e.params, !1, e.context)
                    })), i.globals.axisCharts || i.globals.noData || n.core.resizeNonAxisCharts(), a(n)
                }))
            }
        }, {
            key: "destroy",
            value: function () {
                var e, t;
                window.removeEventListener("resize", this.windowResizeHandler), this.el.parentNode, e = this.parentResizeHandler, (t = je.get(e)) && (t.disconnect(), je.delete(e));
                var n = this.w.config.chart.id;
                n && Apex._chartInstances.forEach((function (e, t) {
                    e.id === p.escapeString(n) && Apex._chartInstances.splice(t, 1)
                })), new Ie(this.ctx).clear({
                    isUpdating: !1
                })
            }
        }, {
            key: "updateOptions",
            value: function (e) {
                var t = this,
                    n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    i = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
                    a = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
                    r = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
                    s = this.w;
                return s.globals.selection = void 0, e.series && (this.series.resetSeries(!1, !0, !1), e.series.length && e.series[0].data && (e.series = e.series.map((function (e, n) {
                    return t.updateHelpers._extendSeries(e, n)
                }))), this.updateHelpers.revertDefaultAxisMinMax()), e.xaxis && (e = this.updateHelpers.forceXAxisUpdate(e)), e.yaxis && (e = this.updateHelpers.forceYAxisUpdate(e)), s.globals.collapsedSeriesIndices.length > 0 && this.series.clearPreviousPaths(), e.theme && (e = this.theme.updateThemeOptions(e)), this.updateHelpers._updateOptions(e, n, i, a, r)
            }
        }, {
            key: "updateSeries",
            value: function () {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
                    t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                    n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                return this.series.resetSeries(!1), this.updateHelpers.revertDefaultAxisMinMax(), this.updateHelpers._updateSeries(e, t, n)
            }
        }, {
            key: "appendSeries",
            value: function (e) {
                var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                    n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
                    i = this.w.config.series.slice();
                return i.push(e), this.series.resetSeries(!1), this.updateHelpers.revertDefaultAxisMinMax(), this.updateHelpers._updateSeries(i, t, n)
            }
        }, {
            key: "appendData",
            value: function (e) {
                var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                    n = this;
                n.w.globals.dataChanged = !0, n.series.getPreviousPaths();
                for (var i = n.w.config.series.slice(), a = 0; a < i.length; a++)
                    if (null !== e[a] && void 0 !== e[a])
                        for (var r = 0; r < e[a].data.length; r++) i[a].data.push(e[a].data[r]);
                return n.w.config.series = i, t && (n.w.globals.initialSeries = p.clone(n.w.config.series)), this.update()
            }
        }, {
            key: "update",
            value: function (e) {
                var t = this;
                return new Promise((function (n, i) {
                    new Ie(t.ctx).clear({
                        isUpdating: !0
                    });
                    var a = t.create(t.w.config.series, e);
                    if (!a) return n(t);
                    t.mount(a).then((function () {
                        "function" == typeof t.w.config.chart.events.updated && t.w.config.chart.events.updated(t, t.w), t.events.fireEvent("updated", [t, t.w]), t.w.globals.isDirty = !0, n(t)
                    })).catch((function (e) {
                        i(e)
                    }))
                }))
            }
        }, {
            key: "getSyncedCharts",
            value: function () {
                var e = this.getGroupedCharts(),
                    t = [this];
                return e.length && (t = [], e.forEach((function (e) {
                    t.push(e)
                }))), t
            }
        }, {
            key: "getGroupedCharts",
            value: function () {
                var e = this;
                return Apex._chartInstances.filter((function (e) {
                    if (e.group) return !0
                })).map((function (t) {
                    return e.w.config.chart.group === t.group ? t.chart : e
                }))
            }
        }, {
            key: "toggleSeries",
            value: function (e) {
                return this.series.toggleSeries(e)
            }
        }, {
            key: "highlightSeriesOnLegendHover",
            value: function (e, t) {
                return this.series.toggleSeriesOnHover(e, t)
            }
        }, {
            key: "showSeries",
            value: function (e) {
                this.series.showSeries(e)
            }
        }, {
            key: "hideSeries",
            value: function (e) {
                this.series.hideSeries(e)
            }
        }, {
            key: "resetSeries",
            value: function () {
                var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
                    t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                this.series.resetSeries(e, t)
            }
        }, {
            key: "addEventListener",
            value: function (e, t) {
                this.events.addEventListener(e, t)
            }
        }, {
            key: "removeEventListener",
            value: function (e, t) {
                this.events.removeEventListener(e, t)
            }
        }, {
            key: "addXaxisAnnotation",
            value: function (e) {
                var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                    n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0,
                    i = this;
                n && (i = n), i.annotations.addXaxisAnnotationExternal(e, t, i)
            }
        }, {
            key: "addYaxisAnnotation",
            value: function (e) {
                var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                    n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0,
                    i = this;
                n && (i = n), i.annotations.addYaxisAnnotationExternal(e, t, i)
            }
        }, {
            key: "addPointAnnotation",
            value: function (e) {
                var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                    n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0,
                    i = this;
                n && (i = n), i.annotations.addPointAnnotationExternal(e, t, i)
            }
        }, {
            key: "clearAnnotations",
            value: function () {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : void 0,
                    t = this;
                e && (t = e), t.annotations.clearAnnotations(t)
            }
        }, {
            key: "removeAnnotation",
            value: function (e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : void 0,
                    n = this;
                t && (n = t), n.annotations.removeAnnotation(n, e)
            }
        }, {
            key: "getChartArea",
            value: function () {
                return this.w.globals.dom.baseEl.querySelector(".apexcharts-inner")
            }
        }, {
            key: "getSeriesTotalXRange",
            value: function (e, t) {
                return this.coreUtils.getSeriesTotalsXRange(e, t)
            }
        }, {
            key: "getHighestValueInSeries",
            value: function () {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                    t = new U(this.ctx);
                return t.getMinYMaxY(e).highestY
            }
        }, {
            key: "getLowestValueInSeries",
            value: function () {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                    t = new U(this.ctx);
                return t.getMinYMaxY(e).lowestY
            }
        }, {
            key: "getSeriesTotal",
            value: function () {
                return this.w.globals.seriesTotals
            }
        }, {
            key: "toggleDataPointSelection",
            value: function (e, t) {
                return this.updateHelpers.toggleDataPointSelection(e, t)
            }
        }, {
            key: "zoomX",
            value: function (e, t) {
                this.ctx.toolbar.zoomUpdateOptions(e, t)
            }
        }, {
            key: "setLocale",
            value: function (e) {
                this.localization.setCurrentLocaleValues(e)
            }
        }, {
            key: "dataURI",
            value: function (e) {
                return new W(this.ctx).dataURI(e)
            }
        }, {
            key: "paper",
            value: function () {
                return this.w.globals.dom.Paper
            }
        }, {
            key: "_parentResizeCallback",
            value: function () {
                this.w.globals.animationEnded && this.w.config.chart.redrawOnParentResize && this._windowResize()
            }
        }, {
            key: "_windowResize",
            value: function () {
                var e = this;
                clearTimeout(this.w.globals.resizeTimer), this.w.globals.resizeTimer = window.setTimeout((function () {
                    e.w.globals.resized = !0, e.w.globals.dataChanged = !1, e.ctx.update()
                }), 150)
            }
        }, {
            key: "_windowResizeHandler",
            value: function () {
                var e = this.w.config.chart.redrawOnWindowResize;
                "function" == typeof e && (e = e()), e && this._windowResize()
            }
        }], [{
            key: "getChartByID",
            value: function (e) {
                var t = p.escapeString(e),
                    n = Apex._chartInstances.filter((function (e) {
                        return e.id === t
                    }))[0];
                return n && n.chart
            }
        }, {
            key: "initOnLoad",
            value: function () {
                for (var t = document.querySelectorAll("[data-apexcharts]"), n = 0; n < t.length; n++) new e(t[n], JSON.parse(t[n].getAttribute("data-options"))).render()
            }
        }, {
            key: "exec",
            value: function (e, t) {
                var n = this.getChartByID(e);
                if (n) {
                    n.w.globals.isExecCalled = !0;
                    var i = null;
                    if (-1 !== n.publicMethods.indexOf(t)) {
                        for (var a = arguments.length, r = new Array(a > 2 ? a - 2 : 0), s = 2; s < a; s++) r[s - 2] = arguments[s];
                        i = n[t].apply(n, r)
                    }
                    return i
                }
            }
        }, {
            key: "merge",
            value: function (e, t) {
                return p.extend(e, t)
            }
        }]), e
    }()
}))