"use strict";
var LXBlockUI = function (e, t) {
    var n = this;
    if (null != e) {
        var i = {
                zIndex: !1,
                overlayClass: "",
                overflow: "hidden",
                message: '<span class="spinner-border text-primary"></span>'
            },
            r = function () {
                n.options = LXUtil.deepExtend({}, i, t), n.element = e, n.overlayElement = null, n.blocked = !1, n.positionChanged = !1, n.overflowChanged = !1, LXUtil.data(n.element).set("blockui", n)
            };
        LXUtil.data(e).has("blockui") ? n = LXUtil.data(e).get("blockui") : r(), n.block = function () {
            ! function () {
                if (!1 !== LXEventHandler.trigger(n.element, "lx.blockui.block", n)) {
                    var e = "BODY" === n.element.tagName,
                        t = LXUtil.css(n.element, "position"),
                        i = LXUtil.css(n.element, "overflow"),
                        r = e ? 1e4 : 1;
                    n.options.zIndex > 0 ? r = n.options.zIndex : "auto" != LXUtil.css(n.element, "z-index") && (r = LXUtil.css(n.element, "z-index")), n.element.classList.add("blockui"), "absolute" !== t && "relative" !== t && "fixed" !== t || (LXUtil.css(n.element, "position", "relative"), n.positionChanged = !0), "hidden" === n.options.overflow && "visible" === i && (LXUtil.css(n.element, "overflow", "hidden"), n.overflowChanged = !0), n.overlayElement = document.createElement("DIV"), n.overlayElement.setAttribute("class", "blockui-overlay " + n.options.overlayClass), n.overlayElement.innerHTML = n.options.message, LXUtil.css(n.overlayElement, "z-index", r), n.element.append(n.overlayElement), n.blocked = !0, LXEventHandler.trigger(n.element, "lx.blockui.after.blocked", n)
                }
            }()
        }, n.release = function () {
            !1 !== LXEventHandler.trigger(n.element, "lx.blockui.release", n) && (n.element.classList.add("blockui"), n.positionChanged && LXUtil.css(n.element, "position", ""), n.overflowChanged && LXUtil.css(n.element, "overflow", ""), n.overlayElement && LXUtil.remove(n.overlayElement), n.blocked = !1, LXEventHandler.trigger(n.element, "lx.blockui.released", n))
        }, n.isBlocked = function () {
            return n.blocked
        }, n.destroy = function () {
            LXUtil.data(n.element).remove("blockui")
        }, n.on = function (e, t) {
            return LXEventHandler.on(n.element, e, t)
        }, n.one = function (e, t) {
            return LXEventHandler.one(n.element, e, t)
        }, n.off = function (e) {
            return LXEventHandler.off(n.element, e)
        }, n.trigger = function (e, t) {
            return LXEventHandler.trigger(n.element, e, t, n, t)
        }
    }
};
LXBlockUI.getInstance = function (e) {
    return null !== e && LXUtil.data(e).has("blockui") ? LXUtil.data(e).get("blockui") : null
}, "undefined" != typeof module && void 0 !== module.exports && (module.exports = LXBlockUI);
var LXCookie = {
    get: function (e) {
        var t = document.cookie.match(new RegExp("(?:^|; )" + e.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, "\\$1") + "=([^;]*)"));
        return t ? decodeURIComponent(t[1]) : null
    },
    set: function (e, t, n) {
        null == n && (n = {}), (n = Object.assign({}, {
            path: "/"
        }, n)).expires instanceof Date && (n.expires = n.expires.toUTCString());
        var i = encodeURIComponent(e) + "=" + encodeURIComponent(t);
        for (var r in n)
            if (!1 !== n.hasOwnProperty(r)) {
                i += "; " + r;
                var o = n[r];
                !0 !== o && (i += "=" + o)
            } document.cookie = i
    },
    remove: function (e) {
        this.set(e, "", {
            "max-age": -1
        })
    }
};
"undefined" != typeof module && void 0 !== module.exports && (module.exports = LXCookie);
var LXDialer = function (e, t) {
    var n = this;
    if (e) {
        var i = {
                min: null,
                max: null,
                step: 1,
                decimals: 0,
                prefix: "",
                suffix: ""
            },
            r = function () {
                n.options = LXUtil.deepExtend({}, i, t), n.element = e, n.incElement = n.element.querySelector('[data-lx-dialer-control="increase"]'), n.decElement = n.element.querySelector('[data-lx-dialer-control="decrease"]'), n.inputElement = n.element.querySelector("input[type]"), c("decimals") && (n.options.decimals = parseInt(c("decimals"))), c("prefix") && (n.options.prefix = c("prefix")), c("suffix") && (n.options.suffix = c("suffix")), c("step") && (n.options.step = parseFloat(c("step"))), c("min") && (n.options.min = parseFloat(c("min"))), c("max") && (n.options.max = parseFloat(c("max"))), n.value = parseFloat(n.inputElement.value.replace(/[^\d.]/g, "")), s(), o(), LXUtil.data(n.element).set("dialer", n)
            },
            o = function () {
                LXUtil.addEvent(n.incElement, "click", (function (e) {
                    e.preventDefault(), a()
                })), LXUtil.addEvent(n.decElement, "click", (function (e) {
                    e.preventDefault(), l()
                })), LXUtil.addEvent(n.inputElement, "input", (function (e) {
                    e.preventDefault(), s()
                }))
            },
            a = function () {
                return LXEventHandler.trigger(n.element, "lx.dialer.increase", n), n.inputElement.value = n.value + n.options.step, s(), LXEventHandler.trigger(n.element, "lx.dialer.increased", n), n
            },
            l = function () {
                return LXEventHandler.trigger(n.element, "lx.dialer.decrease", n), n.inputElement.value = n.value - n.options.step, s(), LXEventHandler.trigger(n.element, "lx.dialer.decreased", n), n
            },
            s = function (e) {
                LXEventHandler.trigger(n.element, "lx.dialer.change", n), n.value = void 0 !== e ? e : u(n.inputElement.value), null !== n.options.min && n.value < n.options.min && (n.value = n.options.min), null !== n.options.max && n.value > n.options.max && (n.value = n.options.max), n.inputElement.value = d(n.value), n.inputElement.dispatchEvent(new Event("change")), LXEventHandler.trigger(n.element, "lx.dialer.changed", n)
            },
            u = function (e) {
                return e = e.replace(/[^0-9.-]/g, "").replace(/(\..*)\./g, "$1").replace(/(?!^)-/g, "").replace(/^0+(\d)/gm, "$1"), e = parseFloat(e), isNaN(e) && (e = 0), e
            },
            d = function (e) {
                return n.options.prefix + parseFloat(e).toFixed(n.options.decimals) + n.options.suffix
            },
            c = function (e) {
                return !0 === n.element.hasAttribute("data-lx-dialer-" + e) ? n.element.getAttribute("data-lx-dialer-" + e) : null
            };
        !0 === LXUtil.data(e).has("dialer") ? n = LXUtil.data(e).get("dialer") : r(), n.setMinValue = function (e) {
            n.options.min = e
        }, n.setMaxValue = function (e) {
            n.options.max = e
        }, n.setValue = function (e) {
            s(e)
        }, n.getValue = function () {
            return n.inputElement.value
        }, n.update = function () {
            s()
        }, n.increase = function () {
            return a()
        }, n.decrease = function () {
            return l()
        }, n.getElement = function () {
            return n.element
        }, n.destroy = function () {
            LXUtil.data(n.element).remove("dialer")
        }, n.on = function (e, t) {
            return LXEventHandler.on(n.element, e, t)
        }, n.one = function (e, t) {
            return LXEventHandler.one(n.element, e, t)
        }, n.off = function (e) {
            return LXEventHandler.off(n.element, e)
        }, n.trigger = function (e, t) {
            return LXEventHandler.trigger(n.element, e, t, n, t)
        }
    }
};
LXDialer.getInstance = function (e) {
    return null !== e && LXUtil.data(e).has("dialer") ? LXUtil.data(e).get("dialer") : null
}, LXDialer.createInstances = function (e = '[data-lx-dialer="true"]') {
    var t = document.body.querySelectorAll(e);
    if (t && t.length > 0)
        for (var n = 0, i = t.length; n < i; n++) new LXDialer(t[n])
}, LXDialer.init = function () {
    LXDialer.createInstances()
}, "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", LXDialer.init) : LXDialer.init(), "undefined" != typeof module && void 0 !== module.exports && (module.exports = LXDialer);
var LXDrawer = function (e, t) {
    var n = this,
        i = document.getElementsByTagName("BODY")[0];
    if (null != e) {
        var r = {
                overlay: !0,
                direction: "end",
                baseClass: "drawer",
                overlayClass: "drawer-overlay"
            },
            o = function () {
                n.options = LXUtil.deepExtend({}, r, t), n.uid = LXUtil.getUniqueId("drawer"), n.element = e, n.overlayElement = null, n.name = n.element.getAttribute("data-lx-drawer-name"), n.shown = !1, n.lastWidth, n.toggleElement = null, n.element.setAttribute("data-lx-drawer", "true"), a(), d(), LXUtil.data(n.element).set("drawer", n)
            },
            a = function () {
                var e = f("toggle"),
                    t = f("close");
                null !== e && e.length > 0 && LXUtil.on(i, e, "click", (function (e) {
                    e.preventDefault(), n.toggleElement = this, l()
                })), null !== t && t.length > 0 && LXUtil.on(i, t, "click", (function (e) {
                    e.preventDefault(), n.closeElement = this, s()
                }))
            },
            l = function () {
                !1 !== LXEventHandler.trigger(n.element, "lx.drawer.toggle", n) && (!0 === n.shown ? s() : u(), LXEventHandler.trigger(n.element, "lx.drawer.toggled", n))
            },
            s = function () {
                !1 !== LXEventHandler.trigger(n.element, "lx.drawer.hide", n) && (n.shown = !1, m(), i.removeAttribute("data-lx-drawer-" + n.name, "on"), i.removeAttribute("data-lx-drawer"), LXUtil.removeClass(n.element, n.options.baseClass + "-on"), null !== n.toggleElement && LXUtil.removeClass(n.toggleElement, "active"), LXEventHandler.trigger(n.element, "lx.drawer.after.hidden", n))
            },
            u = function () {
                !1 !== LXEventHandler.trigger(n.element, "lx.drawer.show", n) && (n.shown = !0, c(), i.setAttribute("data-lx-drawer-" + n.name, "on"), i.setAttribute("data-lx-drawer", "on"), LXUtil.addClass(n.element, n.options.baseClass + "-on"), null !== n.toggleElement && LXUtil.addClass(n.toggleElement, "active"), LXEventHandler.trigger(n.element, "lx.drawer.shown", n))
            },
            d = function () {
                var e = p(),
                    t = f("direction");
                !0 === LXUtil.hasClass(n.element, n.options.baseClass + "-on") && "on" === String(i.getAttribute("data-lx-drawer-" + n.name + "-")) ? n.shown = !0 : n.shown = !1, !0 === f("activate") ? (LXUtil.addClass(n.element, n.options.baseClass), LXUtil.addClass(n.element, n.options.baseClass + "-" + t), LXUtil.css(n.element, "width", e, !0), n.lastWidth = e) : (LXUtil.css(n.element, "width", ""), LXUtil.removeClass(n.element, n.options.baseClass), LXUtil.removeClass(n.element, n.options.baseClass + "-" + t), s())
            },
            c = function () {
                !0 === f("overlay") && (n.overlayElement = document.createElement("DIV"), LXUtil.css(n.overlayElement, "z-index", LXUtil.css(n.element, "z-index") - 1), i.append(n.overlayElement), LXUtil.addClass(n.overlayElement, f("overlay-class")), LXUtil.addEvent(n.overlayElement, "click", (function (e) {
                    e.preventDefault(), s()
                })))
            },
            m = function () {
                null !== n.overlayElement && LXUtil.remove(n.overlayElement)
            },
            f = function (e) {
                if (!0 === n.element.hasAttribute("data-lx-drawer-" + e)) {
                    var t = n.element.getAttribute("data-lx-drawer-" + e),
                        i = LXUtil.getResponsiveValue(t);
                    return null !== i && "true" === String(i) ? i = !0 : null !== i && "false" === String(i) && (i = !1), i
                }
                var r = LXUtil.snakeToCamel(e);
                return n.options[r] ? LXUtil.getResponsiveValue(n.options[r]) : null
            },
            p = function () {
                var e = f("width");
                return "auto" === e && (e = LXUtil.css(n.element, "width")), e
            };
        LXUtil.data(e).has("drawer") ? n = LXUtil.data(e).get("drawer") : o(), n.toggle = function () {
            return l()
        }, n.show = function () {
            return u()
        }, n.hide = function () {
            return s()
        }, n.isShown = function () {
            return n.shown
        }, n.update = function () {
            d()
        }, n.goElement = function () {
            return n.element
        }, n.destroy = function () {
            LXUtil.data(n.element).remove("drawer")
        }, n.on = function (e, t) {
            return LXEventHandler.on(n.element, e, t)
        }, n.one = function (e, t) {
            return LXEventHandler.one(n.element, e, t)
        }, n.off = function (e) {
            return LXEventHandler.off(n.element, e)
        }, n.trigger = function (e, t) {
            return LXEventHandler.trigger(n.element, e, t, n, t)
        }
    }
};
LXDrawer.getInstance = function (e) {
    return null !== e && LXUtil.data(e).has("drawer") ? LXUtil.data(e).get("drawer") : null
}, LXDrawer.hideAll = function (e = null, t = '[data-lx-drawer="true"]') {
    var n = document.querySelectorAll(t);
    if (n && n.length > 0)
        for (var i = 0, r = n.length; i < r; i++) {
            var o = n[i],
                a = LXDrawer.getInstance(o);
            a && (e ? o !== e && a.hide() : a.hide())
        }
}, LXDrawer.updateAll = function (e = '[data-lx-drawer="true"]') {
    var t = document.querySelectorAll(e);
    if (t && t.length > 0)
        for (var n = 0, i = t.length; n < i; n++) {
            var r = t[n],
                o = LXDrawer.getInstance(r);
            o && o.update()
        }
}, LXDrawer.createInstances = function (e = '[data-lx-drawer="true"]') {
    var t = document.getElementsByTagName("BODY")[0].querySelectorAll(e);
    if (t && t.length > 0)
        for (var n = 0, i = t.length; n < i; n++) new LXDrawer(t[n])
}, LXDrawer.handleShow = function () {
    LXUtil.on(document.body, '[data-lx-drawer-show="true"][data-lx-drawer-target]', "click", (function (e) {
        var t = document.querySelector(this.getAttribute("data-lx-drawer-target"));
        t && LXDrawer.getInstance(t).show()
    }))
}, LXDrawer.handleDismiss = function () {
    LXUtil.on(document.body, '[data-lx-drawer-dismiss="true"]', "click", (function (e) {
        var t = this.closest('[data-lx-drawer="true"]');
        if (t) {
            var n = LXDrawer.getInstance(t);
            n.isShown() && n.hide()
        }
    }))
}, window.addEventListener("resize", (function () {
    var e = document.getElementsByTagName("BODY")[0];
    LXUtil.throttle(undefined, (function () {
        var t = e.querySelectorAll('[data-lx-drawer="true"]');
        if (t && t.length > 0)
            for (var n = 0, i = t.length; n < i; n++) {
                var r = LXDrawer.getInstance(t[n]);
                r && r.update()
            }
    }), 200)
})), LXDrawer.init = function () {
    LXDrawer.createInstances(), LXDrawer.handleShow(), LXDrawer.handleDismiss()
}, "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", LXDrawer.init) : LXDrawer.init(), "undefined" != typeof module && void 0 !== module.exports && (module.exports = LXDrawer);
var LXEventHandler = function () {
    var e = {},
        t = function (t, n, i, r) {
            var o = LXUtil.getUniqueId("event");
            LXUtil.data(t).set(n, o), e[n] || (e[n] = {}), e[n][o] = {
                name: n,
                callback: i,
                one: r,
                fired: !1
            }
        };
    return {
        trigger: function (t, n, i, r) {
            return function (t, n, i, r) {
                if (!0 === LXUtil.data(t).has(n)) {
                    var o = LXUtil.data(t).get(n);
                    if (e[n] && e[n][o]) {
                        var a = e[n][o];
                        if (a.name === n) {
                            if (1 != a.one) return a.callback.call(this, i, r);
                            if (0 == a.fired) return e[n][o].fired = !0, a.callback.call(this, i, r)
                        }
                    }
                }
                return null
            }(t, n, i, r)
        },
        on: function (e, n, i) {
            return t(e, n, i)
        },
        one: function (e, n, i) {
            return t(e, n, i, !0)
        },
        off: function (t, n) {
            return function (t, n) {
                var i = LXUtil.data(t).get(n);
                e[n] && e[n][i] && delete e[n][i]
            }(t, n)
        },
        debug: function () {
            for (var t in e) e.hasOwnProperty(t) && console.log(t)
        }
    }
}();
"undefined" != typeof module && void 0 !== module.exports && (module.exports = LXEventHandler);
var LXFeedback = function (e) {
    var t = this,
        n = document.getElementsByTagName("BODY")[0],
        i = {
            width: 100,
            placement: "top-center",
            content: "",
            type: "popup"
        },
        r = function () {
            t.options = LXUtil.deepExtend({}, i, e), t.uid = LXUtil.getUniqueId("feedback"), t.element, t.shown = !1, o(), LXUtil.data(t.element).set("feedback", t)
        },
        o = function () {
            LXUtil.addEvent(t.element, "click", (function (e) {
                e.preventDefault(), _go()
            }))
        },
        a = function () {
            t.element = document.createElement("DIV"), LXUtil.addClass(t.element, "feedback feedback-popup"), LXUtil.setHTML(t.element, t.options.content), "top-center" == t.options.placement && l(), n.appendChild(t.element), LXUtil.addClass(t.element, "feedback-shown"), t.shown = !0
        },
        l = function () {
            var e = LXUtil.getResponsiveValue(t.options.width),
                n = LXUtil.css(t.element, "height");
            LXUtil.addClass(t.element, "feedback-top-center"), LXUtil.css(t.element, "width", e), LXUtil.css(t.element, "left", "50%"), LXUtil.css(t.element, "top", "-" + n)
        },
        s = function () {
            t.element.remove()
        };
    r(), t.show = function () {
        return function () {
            if (!1 !== LXEventHandler.trigger(t.element, "lx.feedback.show", t)) return "popup" === t.options.type && a(), LXEventHandler.trigger(t.element, "lx.feedback.shown", t), t
        }()
    }, t.hide = function () {
        return function () {
            if (!1 !== LXEventHandler.trigger(t.element, "lx.feedback.hide", t)) return "popup" === t.options.type && s(), t.shown = !1, LXEventHandler.trigger(t.element, "lx.feedback.hidden", t), t
        }()
    }, t.isShown = function () {
        return t.shown
    }, t.getElement = function () {
        return t.element
    }, t.destroy = function () {
        LXUtil.data(t.element).remove("feedback")
    }, t.on = function (e, n) {
        return LXEventHandler.on(t.element, e, n)
    }, t.one = function (e, n) {
        return LXEventHandler.one(t.element, e, n)
    }, t.off = function (e) {
        return LXEventHandler.off(t.element, e)
    }, t.trigger = function (e, n) {
        return LXEventHandler.trigger(t.element, e, n, t, n)
    }
};
"undefined" != typeof module && void 0 !== module.exports && (module.exports = LXFeedback);
var LXImageInput = function (e, t) {
    var n = this;
    if (null != e) {
        var i = {},
            r = function () {
                n.options = LXUtil.deepExtend({}, i, t), n.uid = LXUtil.getUniqueId("image-input"), n.element = e, n.inputElement = LXUtil.find(e, 'input[type="file"]'), n.wrapperElement = LXUtil.find(e, ".image-input-wrapper"), n.cancelElement = LXUtil.find(e, '[data-lx-image-input-action="cancel"]'), n.removeElement = LXUtil.find(e, '[data-lx-image-input-action="remove"]'), n.hiddenElement = LXUtil.find(e, 'input[type="hidden"]'), n.src = LXUtil.css(n.wrapperElement, "backgroundImage"), n.element.setAttribute("data-lx-image-input", "true"), o(), LXUtil.data(n.element).set("image-input", n)
            },
            o = function () {
                LXUtil.addEvent(n.inputElement, "change", a), LXUtil.addEvent(n.cancelElement, "click", l), LXUtil.addEvent(n.removeElement, "click", s)
            },
            a = function (e) {
                if (e.preventDefault(), null !== n.inputElement && n.inputElement.files && n.inputElement.files[0]) {
                    if (!1 === LXEventHandler.trigger(n.element, "lx.imageinput.change", n)) return;
                    var t = new FileReader;
                    t.onload = function (e) {
                        LXUtil.css(n.wrapperElement, "background-image", "url(" + e.target.result + ")")
                    }, t.readAsDataURL(n.inputElement.files[0]), n.element.classList.add("image-input-changed"), n.element.classList.remove("image-input-empty"), LXEventHandler.trigger(n.element, "lx.imageinput.changed", n)
                }
            },
            l = function (e) {
                e.preventDefault(), !1 !== LXEventHandler.trigger(n.element, "lx.imageinput.cancel", n) && (n.element.classList.remove("image-input-changed"), n.element.classList.remove("image-input-empty"), "none" === n.src ? (LXUtil.css(n.wrapperElement, "background-image", ""), n.element.classList.add("image-input-empty")) : LXUtil.css(n.wrapperElement, "background-image", n.src), n.inputElement.value = "", null !== n.hiddenElement && (n.hiddenElement.value = "0"), LXEventHandler.trigger(n.element, "lx.imageinput.canceled", n))
            },
            s = function (e) {
                e.preventDefault(), !1 !== LXEventHandler.trigger(n.element, "lx.imageinput.remove", n) && (n.element.classList.remove("image-input-changed"), n.element.classList.add("image-input-empty"), LXUtil.css(n.wrapperElement, "background-image", "none"), n.inputElement.value = "", null !== n.hiddenElement && (n.hiddenElement.value = "1"), LXEventHandler.trigger(n.element, "lx.imageinput.removed", n))
            };
        !0 === LXUtil.data(e).has("image-input") ? n = LXUtil.data(e).get("image-input") : r(), n.getInputElement = function () {
            return n.inputElement
        }, n.goElement = function () {
            return n.element
        }, n.destroy = function () {
            LXUtil.data(n.element).remove("image-input")
        }, n.on = function (e, t) {
            return LXEventHandler.on(n.element, e, t)
        }, n.one = function (e, t) {
            return LXEventHandler.one(n.element, e, t)
        }, n.off = function (e) {
            return LXEventHandler.off(n.element, e)
        }, n.trigger = function (e, t) {
            return LXEventHandler.trigger(n.element, e, t, n, t)
        }
    }
};
LXImageInput.getInstance = function (e) {
    return null !== e && LXUtil.data(e).has("image-input") ? LXUtil.data(e).get("image-input") : null
}, LXImageInput.createInstances = function (e = "[data-lx-image-input]") {
    var t = document.querySelectorAll(e);
    if (t && t.length > 0)
        for (var n = 0, i = t.length; n < i; n++) new LXImageInput(t[n])
}, LXImageInput.init = function () {
    LXImageInput.createInstances()
}, "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", LXImageInput.init) : LXImageInput.init(), "undefined" != typeof module && void 0 !== module.exports && (module.exports = LXImageInput);
var LXMenu = function (e, t) {
    var n = this;
    if (null != e) {
        var i = {
                dropdown: {
                    hoverTimeout: 200,
                    zindex: 105
                },
                accordion: {
                    slideSpeed: 250,
                    expand: !1
                }
            },
            r = function () {
                n.options = LXUtil.deepExtend({}, i, t), n.uid = LXUtil.getUniqueId("menu"), n.element = e, n.triggerElement, n.element.setAttribute("data-lx-menu", "true"), d(), u(), LXUtil.data(n.element).set("menu", n)
            },
            o = function (e) {
                e || (e = n.triggerElement), !0 === m(e) ? l(e) : a(e)
            },
            a = function (e) {
                e || (e = n.triggerElement), !0 !== m(e) && ("dropdown" === v(e) ? U(e) : "accordion" === v(e) && S(e), LXUtil.data(e).set("type", v(e)))
            },
            l = function (e) {
                e || (e = n.triggerElement), !1 !== m(e) && ("dropdown" === v(e) ? w(e) : "accordion" === v(e) && A(e))
            },
            s = function (e) {
                if (!1 !== f(e)) {
                    var t = g(e);
                    LXUtil.data(e).has("type") && LXUtil.data(e).get("type") !== v(e) && (LXUtil.removeClass(e, "hover"), LXUtil.removeClass(e, "show"), LXUtil.removeClass(t, "show"))
                }
            },
            u = function () {
                var e = n.element.querySelectorAll(".menu-item[data-lx-menu-trigger]");
                if (e && e.length > 0)
                    for (var t = 0, i = e.length; t < i; t++) s(e[t])
            },
            d = function () {
                var e = document.querySelector('[data-lx-menu-target="# ' + n.element.getAttribute("id") + '"]');
                null !== e ? n.triggerElement = e : n.element.closest("[data-lx-menu-trigger]") ? n.triggerElement = n.element.closest("[data-lx-menu-trigger]") : n.element.parentNode && LXUtil.child(n.element.parentNode, "[data-lx-menu-trigger]") && (n.triggerElement = LXUtil.child(n.element.parentNode, "[data-lx-menu-trigger]")), n.triggerElement && LXUtil.data(n.triggerElement).set("menu", n)
            },
            c = function (e) {
                return n.triggerElement === e
            },
            m = function (e) {
                var t = g(e);
                return null !== t && ("dropdown" === v(e) ? !0 === LXUtil.hasClass(t, "show") && !0 === t.hasAttribute("data-popper-placement") : LXUtil.hasClass(e, "show"))
            },
            f = function (e) {
                return LXUtil.hasClass(e, "menu-item") && e.hasAttribute("data-lx-menu-trigger")
            },
            p = function (e) {
                return LXUtil.child(e, ".menu-link")
            },
            g = function (e) {
                return !0 === c(e) ? n.element : !0 === e.classList.contains("menu-sub") ? e : LXUtil.data(e).has("sub") ? LXUtil.data(e).get("sub") : LXUtil.child(e, ".menu-sub")
            },
            v = function (e) {
                var t = g(e);
                return t && parseInt(LXUtil.css(t, "z-index")) > 0 ? "dropdown" : "accordion"
            },
            T = function (e) {
                var t, n;
                return c(e) || e.hasAttribute("data-lx-menu-trigger") ? e : LXUtil.data(e).has("item") ? LXUtil.data(e).get("item") : (t = e.closest(".menu-item[data-lx-menu-trigger]")) ? t : (n = e.closest(".menu-sub")) && !0 === LXUtil.data(n).has("item") ? LXUtil.data(n).get("item") : void 0
            },
            h = function (e) {
                var t, n = e.closest(".menu-sub");
                return LXUtil.data(n).has("item") ? LXUtil.data(n).get("item") : n && (t = n.closest(".menu-item[data-lx-menu-trigger]")) ? t : null
            },
            K = function (e) {
                var t = e;
                return LXUtil.data(e).get("sub") && (t = LXUtil.data(e).get("sub")), null !== t && t.querySelector(".menu-item[data-lx-menu-trigger]") || null
            },
            E = function (e) {
                var t, n = [],
                    i = 0;
                do {
                    (t = K(e)) && (n.push(t), e = t), i++
                } while (null !== t && i < 20);
                return n
            },
            U = function (e) {
                if (!1 !== LXEventHandler.trigger(n.element, "lx.menu.dropdown.show", e)) {
                    LXMenu.hideDropdowns(e);
                    c(e) || p(e);
                    var t = g(e),
                        i = x(e, "width"),
                        r = x(e, "height"),
                        o = n.options.dropdown.zindex,
                        a = LXUtil.getHighestZindex(e);
                    null !== a && a >= o && (o = a + 1), o > 0 && LXUtil.css(t, "z-index", o), null !== i && LXUtil.css(t, "width", i), null !== r && LXUtil.css(t, "height", r), LXUtil.css(t, "display", ""), LXUtil.css(t, "overflow", ""), b(e, t), LXUtil.addClass(e, "show"), LXUtil.addClass(e, "menu-dropdown"), LXUtil.addClass(t, "show"), !0 === x(e, "overflow") ? (document.body.appendChild(t), LXUtil.data(e).set("sub", t), LXUtil.data(t).set("item", e), LXUtil.data(t).set("menu", n)) : LXUtil.data(t).set("item", e), LXEventHandler.trigger(n.element, "lx.menu.dropdown.shown", e)
                }
            },
            w = function (e) {
                if (!1 !== LXEventHandler.trigger(n.element, "lx.menu.dropdown.hide", e)) {
                    var t = g(e);
                    LXUtil.css(t, "z-index", ""), LXUtil.css(t, "width", ""), LXUtil.css(t, "height", ""), LXUtil.removeClass(e, "show"), LXUtil.removeClass(e, "menu-dropdown"), LXUtil.removeClass(t, "show"), !0 === x(e, "overflow") && (e.classList.contains("menu-item") ? e.appendChild(t) : LXUtil.insertAfter(n.element, e), LXUtil.data(e).remove("sub"), LXUtil.data(t).remove("item"), LXUtil.data(t).remove("menu")), k(e), LXEventHandler.trigger(n.element, "lx.menu.dropdown.hidden", e)
                }
            },
            b = function (e, t) {
                var n, i = x(e, "attach");
                n = i ? "parent" === i ? e.parentNode : document.querySelector(i) : e;
                var r = Popper.createPopper(n, t, y(e));
                LXUtil.data(e).set("popper", r)
            },
            k = function (e) {
                !0 === LXUtil.data(e).has("popper") && (LXUtil.data(e).get("popper").destroy(), LXUtil.data(e).remove("popper"))
            },
            y = function (e) {
                var t = x(e, "placement");
                t || (t = "right");
                var n = x(e, "offset"),
                    i = n ? n.split(",") : [];
                return {
                    placement: t,
                    strategy: !0 === x(e, "overflow") ? "absolute" : "fixed",
                    modifiers: [{
                        name: "offset",
                        options: {
                            offset: i
                        }
                    }, {
                        name: "preventOverflow",
                        options: {
                            altAxis: !1 !== x(e, "flip")
                        }
                    }, {
                        name: "flip",
                        options: {
                            flipVariations: !1
                        }
                    }]
                }
            },
            S = function (e) {
                if (!1 !== LXEventHandler.trigger(n.element, "lx.menu.accordion.show", e)) {
                    !1 === n.options.accordion.expand && I(e);
                    var t = g(e);
                    !0 === LXUtil.data(e).has("popper") && w(e), LXUtil.addClass(e, "hover"), LXUtil.addClass(e, "showing"), LXUtil.slideDown(t, n.options.accordion.slideSpeed, (function () {
                        LXUtil.removeClass(e, "showing"), LXUtil.addClass(e, "show"), LXUtil.addClass(t, "show"), LXEventHandler.trigger(n.element, "lx.menu.accordion.shown", e)
                    }))
                }
            },
            A = function (e) {
                if (!1 !== LXEventHandler.trigger(n.element, "lx.menu.accordion.hide", e)) {
                    var t = g(e);
                    LXUtil.addClass(e, "hiding"), LXUtil.slideUp(t, n.options.accordion.slideSpeed, (function () {
                        LXUtil.removeClass(e, "hiding"), LXUtil.removeClass(e, "show"), LXUtil.removeClass(t, "show"), LXUtil.removeClass(e, "hover"), LXEventHandler.trigger(n.element, "lx.menu.accordion.hidden", e)
                    }))
                }
            },
            I = function (e) {
                var t, i = LXUtil.findAll(n.element, ".show[data-lx-menu-trigger]");
                if (i && i.length > 0)
                    for (var r = 0, o = i.length; r < o; r++) t = i[r], "accordion" === v(t) && t !== e && !1 === e.contains(t) && !1 === t.contains(e) && A(t)
            },
            x = function (e, t) {
                var n, i = null;
                return e && e.hasAttribute("data-lx-menu-" + t) && (n = e.getAttribute("data-lx-menu-" + t), null !== (i = LXUtil.getResponsiveValue(n)) && "true" === String(i) ? i = !0 : null !== i && "false" === String(i) && (i = !1)), i
            };
        !0 === LXUtil.data(e).has("menu") ? n = LXUtil.data(e).get("menu") : r(), n.click = function (e, t) {
            return function (e, t) {
                t.preventDefault();
                var n = T(e);
                "click" === x(n, "trigger") && (!1 === x(n, "toggle") ? a(n) : o(n))
            }(e, t)
        }, n.link = function (e, t) {
            !1 !== LXEventHandler.trigger(n.element, "lx.menu.link.click", n) && (LXMenu.hideDropdowns(), LXEventHandler.trigger(n.element, "lx.menu.link.clicked", n))
        }, n.dismiss = function (e, t) {
            return function (e, t) {
                var n = T(e),
                    i = E(n);
                if (null !== n && "dropdown" === v(n) && (l(n), i.length > 0))
                    for (var r = 0, o = i.length; r < o; r++) null !== i[r] && "dropdown" === v(i[r]) && l(tems[r])
            }(e)
        }, n.mouseover = function (e, t) {
            return function (e, t) {
                var n = T(e);
                null !== n && "hover" === x(n, "trigger") && ("1" === LXUtil.data(n).get("hover") && (clearTimeout(LXUtil.data(n).get("timeout")), LXUtil.data(n).remove("hover"), LXUtil.data(n).remove("timeout")), a(n))
            }(e)
        }, n.mouseout = function (e, t) {
            return function (e, t) {
                var i = T(e);
                if (null !== i && "hover" === x(i, "trigger")) {
                    var r = setTimeout((function () {
                        "1" === LXUtil.data(i).get("hover") && l(i)
                    }), n.options.dropdown.hoverTimeout);
                    LXUtil.data(i).set("hover", "1"), LXUtil.data(i).set("timeout", r)
                }
            }(e)
        }, n.getItemTriggerType = function (e) {
            return x(e, "trigger")
        }, n.getItemSubType = function (e) {
            return v(e)
        }, n.show = function (e) {
            return a(e)
        }, n.hide = function (e) {
            return l(e)
        }, n.reset = function (e) {
            return s(e)
        }, n.update = function () {
            return u()
        }, n.getElement = function () {
            return n.element
        }, n.getItemLinkElement = function (e) {
            return p(e)
        }, n.getItemToggleElement = function (e) {
            return function (e) {
                return n.triggerElement ? n.triggerElement : p(e)
            }(e)
        }, n.getItemSubElement = function (e) {
            return g(e)
        }, n.getItemParentElements = function (e) {
            return function (e) {
                var t, i = [],
                    r = 0;
                do {
                    (t = h(e)) && (i.push(t), e = t), r++
                } while (null !== t && r < 20);
                return n.triggerElement && i.unshift(n.triggerElement), i
            }(e)
        }, n.isItemSubShown = function (e) {
            return m(e)
        }, n.isItemParentShown = function (e) {
            return function (e) {
                return LXUtil.parents(e, ".menu-item.show").length > 0
            }(e)
        }, n.getTriggerElement = function () {
            return n.triggerElement
        }, n.isItemDropdownPermanent = function (e) {
            return function (e) {
                return !0 === x(e, "permanent")
            }(e)
        }, n.destroy = function () {
            LXUtil.data(n.element).remove("menu")
        }, n.hideAccordions = function (e) {
            return I(e)
        }, n.on = function (e, t) {
            return LXEventHandler.on(n.element, e, t)
        }, n.one = function (e, t) {
            return LXEventHandler.one(n.element, e, t)
        }, n.off = function (e) {
            return LXEventHandler.off(n.element, e)
        }
    }
};
LXMenu.getInstance = function (e) {
    var t;
    if (LXUtil.data(e).has("menu")) return LXUtil.data(e).get("menu");
    if ((t = e.closest(".menu")) && LXUtil.data(t).has("menu")) return LXUtil.data(t).get("menu");
    if (LXUtil.hasClass(e, "menu-link")) {
        var n = e.closest(".menu-sub");
        if (LXUtil.data(n).has("menu")) return LXUtil.data(n).get("menu")
    }
    return null
}, LXMenu.hideDropdowns = function (e) {
    var t = document.querySelectorAll(".show.menu-dropdown[data-lx-menu-trigger]");
    if (t && t.length > 0)
        for (var n = 0, i = t.length; n < i; n++) {
            var r = t[n],
                o = LXMenu.getInstance(r);
            o && "dropdown" === o.getItemSubType(r) && (e ? !1 === o.getItemSubElement(r).contains(e) && !1 === r.contains(e) && r !== e && o.hide(r) : o.hide(r))
        }
}, LXMenu.updateDropdowns = function () {
    var e = document.querySelectorAll(".show.menu-dropdown[data-lx-menu-trigger]");
    if (e && e.length > 0)
        for (var t = 0, n = e.length; t < n; t++) {
            var i = e[t];
            LXUtil.data(i).has("popper") && LXUtil.data(i).get("popper").forceUpdate()
        }
}, LXMenu.initGlobalHandlers = function () {
    document.addEventListener("click", (function (e) {
        var t, n, i, r = document.querySelectorAll(".show.menu-dropdown[data-lx-menu-trigger]");
        if (r && r.length > 0)
            for (var o = 0, a = r.length; o < a; o++)
                if (t = r[o], (i = LXMenu.getInstance(t)) && "dropdown" === i.getItemSubType(t)) {
                    if (i.getElement(), n = i.getItemSubElement(t), t === e.target || t.contains(e.target)) continue;
                    if (n === e.target || n.contains(e.target)) continue;
                    i.hide(t)
                }
    })), LXUtil.on(document.body, '.menu-item[data-lx-menu-trigger] > .menu-link, [data-lx-menu-trigger]:not(.menu-item):not([data-lx-menu-trigger="auto"])', "click", (function (e) {
        var t = LXMenu.getInstance(this);
        if (null !== t) return t.click(this, e)
    })), LXUtil.on(document.body, ".menu-item:not([data-lx-menu-trigger]) > .menu-link", "click", (function (e) {
        var t = LXMenu.getInstance(this);
        if (null !== t) return t.link(this, e)
    })), LXUtil.on(document.body, '[data-lx-menu-dismiss="true"]', "click", (function (e) {
        var t = LXMenu.getInstance(this);
        if (null !== t) return t.dismiss(this, e)
    })), LXUtil.on(document.body, "[data-lx-menu-trigger], .menu-sub", "mouseover", (function (e) {
        var t = LXMenu.getInstance(this);
        if (null !== t && "dropdown" === t.getItemSubType(this)) return t.mouseover(this, e)
    })), LXUtil.on(document.body, "[data-lx-menu-trigger], .menu-sub", "mouseout", (function (e) {
        var t = LXMenu.getInstance(this);
        if (null !== t && "dropdown" === t.getItemSubType(this)) return t.mouseout(this, e)
    })), window.addEventListener("resize", (function () {
        var e;
        LXUtil.throttle(undefined, (function () {
            var t = document.querySelectorAll('[data-lx-menu="true"]');
            if (t && t.length > 0)
                for (var n = 0, i = t.length; n < i; n++)(e = LXMenu.getInstance(t[n])) && e.update()
        }), 200)
    }))
}, LXMenu.createInstances = function (e = '[data-lx-menu="true"]') {
    var t = document.querySelectorAll(e);
    if (t && t.length > 0)
        for (var n = 0, i = t.length; n < i; n++) new LXMenu(t[n])
}, LXMenu.init = function () {
    LXMenu.initGlobalHandlers(), LXMenu.createInstances()
}, "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", LXMenu.init) : LXMenu.init(), "undefined" != typeof module && void 0 !== module.exports && (module.exports = LXMenu);
var LXPasswordMeter = function (e, t) {
    var n = this;
    if (e) {
        var i = {
                minLength: 8,
                checkUppercase: !0,
                checkLowercase: !0,
                checkDigit: !0,
                checkChar: !0,
                scoreHighlightClass: "active"
            },
            r = function () {
                n.options = LXUtil.deepExtend({}, i, t), n.score = 0, n.checkSteps = 5, n.element = e, n.inputElement = n.element.querySelector("input[type]"), n.visibilityElement = n.element.querySelector('[data-lx-password-meter-control="visibility"]'), n.highlightElement = n.element.querySelector('[data-lx-password-meter-control="highlight"]'), n.element.setAttribute("data-lx-password-meter", "true"), o(), LXUtil.data(n.element).set("password-meter", n)
            },
            o = function () {
                n.inputElement.addEventListener("input", (function () {
                    a()
                })), n.visibilityElement && n.visibilityElement.addEventListener("click", (function () {
                    p()
                }))
            },
            a = function () {
                var e = 0,
                    t = m();
                !0 === l() && (e += t), !0 === n.options.checkUppercase && !0 === s() && (e += t), !0 === n.options.checkLowercase && !0 === u() && (e += t), !0 === n.options.checkDigit && !0 === d() && (e += t), !0 === n.options.checkChar && !0 === c() && (e += t), n.score = e, f()
            },
            l = function () {
                return n.inputElement.value.length >= n.options.minLength
            },
            s = function () {
                return /[a-z]/.test(n.inputElement.value)
            },
            u = function () {
                return /[A-Z]/.test(n.inputElement.value)
            },
            d = function () {
                return /[0-9]/.test(n.inputElement.value)
            },
            c = function () {
                return /[~`!#$%\^&*+=\-\[\]\\';,/{}|\\":<>\?]/g.test(n.inputElement.value)
            },
            m = function () {
                var e = 1;
                return !0 === n.options.checkUppercase && e++, !0 === n.options.checkLowercase && e++, !0 === n.options.checkDigit && e++, !0 === n.options.checkChar && e++, n.checkSteps = e, 100 / n.checkSteps
            },
            f = function () {
                var e = [].slice.call(n.highlightElement.querySelectorAll("div")),
                    t = e.length,
                    i = 0,
                    r = m(),
                    o = g();
                e.map((function (e) {
                    i++, r * i * (n.checkSteps / t) <= o ? e.classList.add("active") : e.classList.remove("active")
                }))
            },
            p = function () {
                var e = n.visibilityElement.querySelector("i:not(.d-none), .svg-icon:not(.d-none)"),
                    t = n.visibilityElement.querySelector("i.d-none, .svg-icon.d-none");
                "password" === n.inputElement.getAttribute("type").toLowerCase() ? n.inputElement.setAttribute("type", "text") : n.inputElement.setAttribute("type", "password"), e.classList.add("d-none"), t.classList.remove("d-none"), n.inputElement.focus()
            },
            g = function () {
                return n.score
            };
        !0 === LXUtil.data(e).has("password-meter") ? n = LXUtil.data(e).get("password-meter") : r(), n.check = function () {
            return a()
        }, n.getScore = function () {
            return g()
        }, n.reset = function () {
            return n.score = 0, void f()
        }, n.destroy = function () {
            LXUtil.data(n.element).remove("password-meter")
        }
    }
};
LXPasswordMeter.getInstance = function (e) {
    return null !== e && LXUtil.data(e).has("password-meter") ? LXUtil.data(e).get("password-meter") : null
}, LXPasswordMeter.createInstances = function (e = "[data-lx-password-meter]") {
    var t = document.body.querySelectorAll(e);
    if (t && t.length > 0)
        for (var n = 0, i = t.length; n < i; n++) new LXPasswordMeter(t[n])
}, LXPasswordMeter.init = function () {
    LXPasswordMeter.createInstances()
}, "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", LXPasswordMeter.init) : LXPasswordMeter.init(), "undefined" != typeof module && void 0 !== module.exports && (module.exports = LXPasswordMeter);
var LXScroll = function (e, t) {
    var n = this;
    document.getElementsByTagName("BODY")[0];
    if (e) {
        var i = {
                saveState: !0
            },
            r = function () {
                n.options = LXUtil.deepExtend({}, i, t), n.element = e, n.id = n.element.getAttribute("id"), n.element.setAttribute("data-lx-scroll", "true"), a(), LXUtil.data(n.element).set("scroll", n)
            },
            o = function () {
                LXCookie.set(n.id + "st", n.element.scrollTop)
            },
            a = function () {
                var e, t;
                !0 === u("activate") || !1 === n.element.hasAttribute("data-lx-scroll-activate") ? (e = d(), null !== (t = l()) && t.length > 0 ? LXUtil.css(n.element, e, t) : LXUtil.css(n.element, e, ""), !0 === u("save-state") && void 0 !== LXCookie && n.id ? n.element.addEventListener("scroll", o) : n.element.removeEventListener("scroll", o), function () {
                    if (!0 === u("save-state") && void 0 !== LXCookie && n.id && LXCookie.get(n.id + "st")) {
                        var e = parseInt(LXCookie.get(n.id + "st"));
                        e > 0 && (n.element.scrollTop = e)
                    }
                }()) : (LXUtil.css(n.element, d(), ""), n.element.removeEventListener("scroll", o))
            },
            l = function () {
                var e = u(d());
                return e instanceof Function ? e.call() : null !== e && "string" == typeof e && "auto" === e.toLowerCase() ? s() : e
            },
            s = function () {
                var e, t = LXUtil.getViewPort().height,
                    i = u("dependencies"),
                    r = u("wrappers"),
                    o = u("offset");
                if (null !== i && ((e = document.querySelectorAll(i)) && e.length > 0))
                    for (var a = 0, l = e.length; a < l; a++) {
                        var s = e[a];
                        !1 !== LXUtil.visible(s) && (t -= parseInt(LXUtil.css(s, "height")), t -= parseInt(LXUtil.css(s, "margin-top")), t -= parseInt(LXUtil.css(s, "margin-bottom")), LXUtil.css(s, "border-top") && (t -= parseInt(LXUtil.css(s, "border-top"))), LXUtil.css(s, "border-bottom") && (t -= parseInt(LXUtil.css(s, "border-bottom"))))
                    }
                if (null !== r && ((e = document.querySelectorAll(r)) && e.length > 0))
                    for (a = 0, l = e.length; a < l; a++) {
                        s = e[a];
                        !1 !== LXUtil.visible(s) && (t -= parseInt(LXUtil.css(s, "margin-top")), t -= parseInt(LXUtil.css(s, "margin-bottom")), t -= parseInt(LXUtil.css(s, "padding-top")), t -= parseInt(LXUtil.css(s, "padding-bottom")), LXUtil.css(s, "border-top") && (t -= parseInt(LXUtil.css(s, "border-top"))), LXUtil.css(s, "border-bottom") && (t -= parseInt(LXUtil.css(s, "border-bottom"))))
                    }
                return null !== o && "object" != typeof o && (t -= parseInt(o)), t -= parseInt(LXUtil.css(n.element, "margin-top")), t -= parseInt(LXUtil.css(n.element, "margin-bottom")), LXUtil.css(s, "border-top") && (t -= parseInt(LXUtil.css(s, "border-top"))), LXUtil.css(s, "border-bottom") && (t -= parseInt(LXUtil.css(s, "border-bottom"))), t = String(t) + "px"
            },
            u = function (e) {
                if (!0 === n.element.hasAttribute("data-lx-scroll-" + e)) {
                    var t = n.element.getAttribute("data-lx-scroll-" + e),
                        i = LXUtil.getResponsiveValue(t);
                    return null !== i && "true" === String(i) ? i = !0 : null !== i && "false" === String(i) && (i = !1), i
                }
                var r = LXUtil.snakeToCamel(e);
                return n.options[r] ? LXUtil.getResponsiveValue(n.options[r]) : null
            },
            d = function () {
                return u("height") ? "height" : u("min-height") ? "min-height" : u("max-height") ? "max-height" : void 0
            };
        LXUtil.data(e).has("scroll") ? n = LXUtil.data(e).get("scroll") : r(), n.update = function () {
            return a()
        }, n.getHeight = function () {
            return l()
        }, n.getElement = function () {
            return n.element
        }, n.destroy = function () {
            LXUtil.data(n.element).remove("scroll")
        }
    }
};
LXScroll.getInstance = function (e) {
    return null !== e && LXUtil.data(e).has("scroll") ? LXUtil.data(e).get("scroll") : null
}, LXScroll.createInstances = function (e = '[data-lx-scroll="true"]') {
    var t = document.getElementsByTagName("BODY")[0].querySelectorAll(e);
    if (t && t.length > 0)
        for (var n = 0, i = t.length; n < i; n++) new LXScroll(t[n])
}, window.addEventListener("resize", (function () {
    var e = document.getElementsByTagName("BODY")[0];
    LXUtil.throttle(undefined, (function () {
        var t = e.querySelectorAll('[data-lx-scroll="true"]');
        if (t && t.length > 0)
            for (var n = 0, i = t.length; n < i; n++) {
                var r = LXScroll.getInstance(t[n]);
                r && r.update()
            }
    }), 200)
})), LXScroll.init = function () {
    LXScroll.createInstances()
}, "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", LXScroll.init) : LXScroll.init(), "undefined" != typeof module && void 0 !== module.exports && (module.exports = LXScroll);
var LXScrolltop = function (e, t) {
    var n = this,
        i = document.getElementsByTagName("BODY")[0];
    if (null != e) {
        var r = {
                offset: 300,
                speed: 600
            },
            o = function () {
                n.options = LXUtil.deepExtend({}, r, t), n.uid = LXUtil.getUniqueId("scrolltop"), n.element = e, n.element.setAttribute("data-lx-scrolltop", "true"), a(), LXUtil.data(n.element).set("scrolltop", n)
            },
            a = function () {
                window.addEventListener("scroll", (function () {
                    LXUtil.throttle(undefined, (function () {
                        l()
                    }), 200)
                })), LXUtil.addEvent(n.element, "click", (function (e) {
                    e.preventDefault(), s()
                }))
            },
            l = function () {
                var e = parseInt(u("offset"));
                LXUtil.getScrollTop() > e ? !1 === i.hasAttribute("data-lx-scrolltop") && i.setAttribute("data-lx-scrolltop", "on") : !0 === i.hasAttribute("data-lx-scrolltop") && i.removeAttribute("data-lx-scrolltop")
            },
            s = function () {
                var e = parseInt(u("speed"));
                LXUtil.scrollTop(0, e)
            },
            u = function (e) {
                if (!0 === n.element.hasAttribute("data-lx-scrolltop-" + e)) {
                    var t = n.element.getAttribute("data-lx-scrolltop-" + e),
                        i = LXUtil.getResponsiveValue(t);
                    return null !== i && "true" === String(i) ? i = !0 : null !== i && "false" === String(i) && (i = !1), i
                }
                var r = LXUtil.snakeToCamel(e);
                return n.options[r] ? LXUtil.getResponsiveValue(n.options[r]) : null
            };
        LXUtil.data(e).has("scrolltop") ? n = LXUtil.data(e).get("scrolltop") : o(), n.go = function () {
            return s()
        }, n.getElement = function () {
            return n.element
        }, n.destroy = function () {
            LXUtil.data(n.element).remove("scrolltop")
        }
    }
};
LXScrolltop.getInstance = function (e) {
    return e && LXUtil.data(e).has("scrolltop") ? LXUtil.data(e).get("scrolltop") : null
}, LXScrolltop.createInstances = function (e = '[data-lx-scrolltop="true"]') {
    var t = document.getElementsByTagName("BODY")[0].querySelectorAll(e);
    if (t && t.length > 0)
        for (var n = 0, i = t.length; n < i; n++) new LXScrolltop(t[n])
}, LXScrolltop.init = function () {
    LXScrolltop.createInstances()
}, "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", LXScrolltop.init) : LXScrolltop.init(), "undefined" != typeof module && void 0 !== module.exports && (module.exports = LXScrolltop);
var LXSearch = function (e, t) {
    var n = this;
    if (e) {
        var i = {
                minLength: 2,
                keypress: !0,
                enter: !0,
                layout: "menu",
                responsive: null,
                showOnFocus: !0
            },
            r = function () {
                n.options = LXUtil.deepExtend({}, i, t), n.processing = !1, n.element = e, n.contentElement = v("content"), n.formElement = v("form"), n.inputElement = v("input"), n.spinnerElement = v("spinner"), n.clearElement = v("clear"), n.toggleElement = v("toggle"), n.submitElement = v("submit"), n.toolbarElement = v("toolbar"), n.resultsElement = v("results"), n.suggestionElement = v("suggestion"), n.emptyElement = v("empty"), n.element.setAttribute("data-lx-search", "true"), n.layout = g("layout"), "menu" === n.layout ? n.menuObject = new LXMenu(n.contentElement) : n.menuObject = null, m(), o(), LXUtil.data(n.element).set("search", n)
            },
            o = function () {
                n.inputElement.addEventListener("focus", a), n.inputElement.addEventListener("blur", l), !0 === g("keypress") && n.inputElement.addEventListener("input", u), n.submitElement && n.submitElement.addEventListener("click", d), !0 === g("enter") && n.inputElement.addEventListener("keypress", s), n.clearElement && n.clearElement.addEventListener("click", c), n.menuObject && (n.toggleElement && (n.toggleElement.addEventListener("click", f), n.menuObject.on("lx.menu.dropdown.show", (function (e) {
                    LXUtil.visible(n.toggleElement) && (n.toggleElement.classList.add("active"), n.toggleElement.classList.add("show"))
                })), n.menuObject.on("lx.menu.dropdown.hide", (function (e) {
                    LXUtil.visible(n.toggleElement) && (n.toggleElement.classList.remove("active"), n.toggleElement.classList.remove("show"))
                }))), n.menuObject.on("lx.menu.dropdown.shown", (function () {
                    n.inputElement.focus()
                }))), window.addEventListener("resize", (function () {
                    LXUtil.throttle(undefined, (function () {
                        m()
                    }), 200)
                }))
            },
            a = function () {
                n.element.classList.add("focus"), (!0 === g("show-on-focus") || n.inputElement.value.length >= minLength) && f()
            },
            l = function () {
                n.element.classList.remove("focus")
            },
            s = function (e) {
                13 == (e.charCode || e.keyCode || 0) && (e.preventDefault(), d())
            },
            u = function () {
                if (g("min-length")) {
                    var e = parseInt(g("min-length"));
                    n.inputElement.value.length >= e ? d() : 0 === n.inputElement.value.length && c()
                }
            },
            d = function () {
                !1 === n.processing && (n.spinnerElement && n.spinnerElement.classList.remove("d-none"), n.clearElement && n.clearElement.classList.add("d-none"), n.toolbarElement && n.formElement.contains(n.toolbarElement) && n.toolbarElement.classList.add("d-none"), n.inputElement.focus(), n.processing = !0, LXEventHandler.trigger(n.element, "lx.search.process", n))
            },
            c = function () {
                !1 !== LXEventHandler.trigger(n.element, "lx.search.clear", n) && (n.inputElement.value = "", n.inputElement.focus(), n.clearElement && n.clearElement.classList.add("d-none"), n.toolbarElement && n.formElement.contains(n.toolbarElement) && n.toolbarElement.classList.remove("d-none"), !1 === g("show-on-focus") && p(), LXEventHandler.trigger(n.element, "lx.search.cleared", n))
            },
            m = function () {
                if ("menu" === n.layout) {
                    var e = T();
                    "on" === e && !1 === n.contentElement.contains(n.formElement) ? (n.contentElement.prepend(n.formElement), n.formElement.classList.remove("d-none")) : "off" === e && !0 === n.contentElement.contains(n.formElement) && (n.element.prepend(n.formElement), n.formElement.classList.add("d-none"))
                }
            },
            f = function () {
                n.menuObject && (m(), n.menuObject.show(n.element))
            },
            p = function () {
                n.menuObject && (m(), n.menuObject.hide(n.element))
            },
            g = function (e) {
                if (!0 === n.element.hasAttribute("data-lx-search-" + e)) {
                    var t = n.element.getAttribute("data-lx-search-" + e),
                        i = LXUtil.getResponsiveValue(t);
                    return null !== i && "true" === String(i) ? i = !0 : null !== i && "false" === String(i) && (i = !1), i
                }
                var r = LXUtil.snakeToCamel(e);
                return n.options[r] ? LXUtil.getResponsiveValue(n.options[r]) : null
            },
            v = function (e) {
                return n.element.querySelector('[data-lx-search-element="' + e + '"]')
            },
            T = function () {
                var e = g("responsive"),
                    t = LXUtil.getViewPort().width;
                if (!e) return null;
                var n = LXUtil.getBreakpoint(e);
                return n || (n = parseInt(e)), t < n ? "on" : "off"
            };
        !0 === LXUtil.data(e).has("search") ? n = LXUtil.data(e).get("search") : r(), n.show = function () {
            return f()
        }, n.hide = function () {
            return p()
        }, n.update = function () {
            return m()
        }, n.search = function () {
            return d()
        }, n.complete = function () {
            return n.spinnerElement && n.spinnerElement.classList.add("d-none"), n.clearElement && n.clearElement.classList.remove("d-none"), 0 === n.inputElement.value.length && c(), n.inputElement.focus(), f(), void(n.processing = !1)
        }, n.clear = function () {
            return c()
        }, n.isProcessing = function () {
            return n.processing
        }, n.getQuery = function () {
            return n.inputElement.value
        }, n.getMenu = function () {
            return n.menuObject
        }, n.getFormElement = function () {
            return n.formElement
        }, n.getInputElement = function () {
            return n.inputElement
        }, n.getContentElement = function () {
            return n.contentElement
        }, n.getElement = function () {
            return n.element
        }, n.destroy = function () {
            LXUtil.data(n.element).remove("search")
        }, n.on = function (e, t) {
            return LXEventHandler.on(n.element, e, t)
        }, n.one = function (e, t) {
            return LXEventHandler.one(n.element, e, t)
        }, n.off = function (e) {
            return LXEventHandler.off(n.element, e)
        }
    }
};
LXSearch.getInstance = function (e) {
    return null !== e && LXUtil.data(e).has("search") ? LXUtil.data(e).get("search") : null
}, "undefined" != typeof module && void 0 !== module.exports && (module.exports = LXSearch);
var LXStepper = function (e, t) {
    var n = this;
    document.getElementsByTagName("BODY")[0];
    if (null != e) {
        var i = {
                startIndex: 1,
                animation: !1,
                animationSpeed: "0.3s",
                animationNextClass: "animate__animated animate__slideInRight animate__fast",
                animationPreviousClass: "animate__animated animate__slideInLeft animate__fast"
            },
            r = function () {
                n.options = LXUtil.deepExtend({}, i, t), n.uid = LXUtil.getUniqueId("stepper"), n.element = e, n.element.setAttribute("data-lx-stepper", "true"), n.steps = LXUtil.findAll(n.element, '[data-lx-stepper-element="nav"]'), n.btnNext = LXUtil.find(n.element, '[data-lx-stepper-action="next"]'), n.btnPrevious = LXUtil.find(n.element, '[data-lx-stepper-action="previous"]'), n.btnSubmit = LXUtil.find(n.element, '[data-lx-stepper-action="submit"]'), n.totalStepsNumber = n.steps.length, n.passedStepIndex = 0, n.currentStepIndex = 1, n.clickedStepIndex = 0, n.options.startIndex > 1 && o(n.options.startIndex), LXUtil.addEvent(n.btnNext, "click", (function (e) {
                    e.preventDefault(), LXEventHandler.trigger(n.element, "lx.stepper.next", n)
                })), LXUtil.addEvent(n.btnPrevious, "click", (function (e) {
                    e.preventDefault(), LXEventHandler.trigger(n.element, "lx.stepper.previous", n)
                })), LXUtil.on(n.element, '[data-lx-stepper-action="step"]', "click", (function (e) {
                    if (e.preventDefault(), n.steps && n.steps.length > 0)
                        for (var t = 0, i = n.steps.length; t < i; t++)
                            if (n.steps[t] === this) return n.clickedStepIndex = t + 1, void LXEventHandler.trigger(n.element, "lx.stepper.click", n)
                })), LXUtil.data(n.element).set("stepper", n)
            },
            o = function (e) {
                if (LXEventHandler.trigger(n.element, "lx.stepper.change", n), !(e === n.currentStepIndex || e > n.totalStepsNumber || e < 0)) return e = parseInt(e), n.passedStepIndex = n.currentStepIndex, n.currentStepIndex = e, a(), LXEventHandler.trigger(n.element, "lx.stepper.changed", n), n
            },
            a = function () {
                var e = "";
                e = l() ? "last" : s() ? "first" : "between", LXUtil.removeClass(n.element, "last"), LXUtil.removeClass(n.element, "first"), LXUtil.removeClass(n.element, "between"), LXUtil.addClass(n.element, e);
                var t = LXUtil.findAll(n.element, '[data-lx-stepper-element="nav"], [data-lx-stepper-element="content"], [data-lx-stepper-element="info"]');
                if (t && t.length > 0)
                    for (var i = 0, r = t.length; i < r; i++) {
                        var o = t[i],
                            a = LXUtil.index(o) + 1;
                        if (LXUtil.removeClass(o, "current"), LXUtil.removeClass(o, "completed"), LXUtil.removeClass(o, "pending"), a == n.currentStepIndex) {
                            if (LXUtil.addClass(o, "current"), !1 !== n.options.animation && "content" == o.getAttribute("data-lx-stepper-element")) {
                                LXUtil.css(o, "animationDuration", n.options.animationSpeed);
                                var u = "previous" === f(n.passedStepIndex) ? n.options.animationPreviousClass : n.options.animationNextClass;
                                LXUtil.animateClass(o, u)
                            }
                        } else a < n.currentStepIndex ? LXUtil.addClass(o, "completed") : LXUtil.addClass(o, "pending")
                    }
            },
            l = function () {
                return n.currentStepIndex === n.totalStepsNumber
            },
            s = function () {
                return 1 === n.currentStepIndex
            },
            u = function () {
                return n.totalStepsNumber >= n.currentStepIndex + 1 ? n.currentStepIndex + 1 : n.totalStepsNumber
            },
            d = function () {
                return n.currentStepIndex - 1 > 1 ? n.currentStepIndex - 1 : 1
            },
            c = function () {
                return 1
            },
            m = function () {
                return n.totalStepsNumber
            },
            f = function (e) {
                return e > n.currentStepIndex ? "next" : "previous"
            };
        !0 === LXUtil.data(e).has("stepper") ? n = LXUtil.data(e).get("stepper") : r(), n.getElement = function (e) {
            return n.element
        }, n.goTo = function (e) {
            return o(e)
        }, n.goPrevious = function () {
            return o(d())
        }, n.goNext = function () {
            return o(u())
        }, n.goFirst = function () {
            return o(c())
        }, n.goLast = function () {
            return o(m())
        }, n.getCurrentStepIndex = function () {
            return n.currentStepIndex
        }, n.getNextStepIndex = function () {
            return n.nextStepIndex
        }, n.getPassedStepIndex = function () {
            return n.passedStepIndex
        }, n.getClickedStepIndex = function () {
            return n.clickedStepIndex
        }, n.getPreviousStepIndex = function () {
            return n.PreviousStepIndex
        }, n.destroy = function () {
            LXUtil.data(n.element).remove("stepper")
        }, n.on = function (e, t) {
            return LXEventHandler.on(n.element, e, t)
        }, n.one = function (e, t) {
            return LXEventHandler.one(n.element, e, t)
        }, n.off = function (e) {
            return LXEventHandler.off(n.element, e)
        }, n.trigger = function (e, t) {
            return LXEventHandler.trigger(n.element, e, t, n, t)
        }
    }
};
LXStepper.getInstance = function (e) {
    return null !== e && LXUtil.data(e).has("stepper") ? LXUtil.data(e).get("stepper") : null
}, "undefined" != typeof module && void 0 !== module.exports && (module.exports = LXStepper);
var LXSticky = function (e, t) {
    var n = this,
        i = document.getElementsByTagName("BODY")[0];
    if (null != e) {
        var r = {
                offset: 200,
                releaseOffset: 0,
                reverse: !1,
                animation: !0,
                animationSpeed: "0.3s",
                animationClass: "animation-slide-in-down"
            },
            o = function () {
                n.element = e, n.options = LXUtil.deepExtend({}, r, t), n.uid = LXUtil.getUniqueId("sticky"), n.name = n.element.getAttribute("data-lx-sticky-name"), n.attributeName = "data-lx-sticky-" + n.name, n.eventTriggerState = !0, n.lastScrollTop = 0, n.scrollHandler, n.element.setAttribute("data-lx-sticky", "true"), window.addEventListener("scroll", a), a(), LXUtil.data(n.element).set("sticky", n)
            },
            a = function (e) {
                var t, r, o = u("offset"),
                    a = u("release-offset"),
                    d = u("reverse");
                !1 !== o && (o = parseInt(o), a = a ? parseInt(a) : 0, t = LXUtil.getScrollTop(), r = document.documentElement.scrollHeight - window.innerHeight - LXUtil.getScrollTop(), !0 === d ? (t > o && (0 === a || a < r) ? (!1 === i.hasAttribute(n.attributeName) && (l(), i.setAttribute(n.attributeName, "on")), !0 === n.eventTriggerState && (LXEventHandler.trigger(n.element, "lx.sticky.on", n), LXEventHandler.trigger(n.element, "lx.sticky.change", n), n.eventTriggerState = !1)) : (!0 === i.hasAttribute(n.attributeName) && (s(), i.removeAttribute(n.attributeName)), !1 === n.eventTriggerState && (LXEventHandler.trigger(n.element, "lx.sticky.off", n), LXEventHandler.trigger(n.element, "lx.sticky.change", n), n.eventTriggerState = !0)), n.lastScrollTop = t) : t > o && (0 === a || a < r) ? (!1 === i.hasAttribute(n.attributeName) && (l(), i.setAttribute(n.attributeName, "on")), !0 === n.eventTriggerState && (LXEventHandler.trigger(n.element, "lx.sticky.on", n), LXEventHandler.trigger(n.element, "lx.sticky.change", n), n.eventTriggerState = !1)) : (!0 === i.hasAttribute(n.attributeName) && (s(), i.removeAttribute(n.attributeName)), !1 === n.eventTriggerState && (LXEventHandler.trigger(n.element, "lx.sticky.off", n), LXEventHandler.trigger(n.element, "lx.sticky.change", n), n.eventTriggerState = !0)), a > 0 && (r < a ? n.element.setAttribute("data-lx-sticky-released", "true") : n.element.removeAttribute("data-lx-sticky-released")))
            },
            l = function (e) {
                var t = u("top"),
                    i = u("left"),
                    r = (u("right"), u("width")),
                    o = u("zindex");
                if (!0 !== e && !0 === u("animation") && (LXUtil.css(n.element, "animationDuration", u("animationSpeed")), LXUtil.animateClass(n.element, "animation " + u("animationClass"))), null !== o && (LXUtil.css(n.element, "z-index", o), LXUtil.css(n.element, "position", "fixed")), null !== t && LXUtil.css(n.element, "top", t), null !== r) {
                    if (r.target) {
                        var a = document.querySelector(r.target);
                        a && (r = LXUtil.css(a, "width"))
                    }
                    LXUtil.css(n.element, "width", r)
                }
                if (null !== i && "auto" === String(i).toLowerCase()) {
                    var l = LXUtil.offset(n.element).left;
                    l > 0 && LXUtil.css(n.element, "left", String(l) + "px")
                }
            },
            s = function () {
                LXUtil.css(n.element, "top", ""), LXUtil.css(n.element, "width", ""), LXUtil.css(n.element, "left", ""), LXUtil.css(n.element, "right", ""), LXUtil.css(n.element, "z-index", ""), LXUtil.css(n.element, "position", "")
            },
            u = function (e) {
                if (!0 === n.element.hasAttribute("data-lx-sticky-" + e)) {
                    var t = n.element.getAttribute("data-lx-sticky-" + e),
                        i = LXUtil.getResponsiveValue(t);
                    return null !== i && "true" === String(i) ? i = !0 : null !== i && "false" === String(i) && (i = !1), i
                }
                var r = LXUtil.snakeToCamel(e);
                return n.options[r] ? LXUtil.getResponsiveValue(n.options[r]) : null
            };
        !0 === LXUtil.data(e).has("sticky") ? n = LXUtil.data(e).get("sticky") : o(), n.update = function () {
            !0 === i.hasAttribute(n.attributeName) && (s(), i.removeAttribute(n.attributeName), l(!0), i.setAttribute(n.attributeName, "on"))
        }, n.destroy = function () {
            return window.removeEventListener("scroll", a), void LXUtil.data(n.element).remove("sticky")
        }, n.on = function (e, t) {
            return LXEventHandler.on(n.element, e, t)
        }, n.one = function (e, t) {
            return LXEventHandler.one(n.element, e, t)
        }, n.off = function (e) {
            return LXEventHandler.off(n.element, e)
        }, n.trigger = function (e, t) {
            return LXEventHandler.trigger(n.element, e, t, n, t)
        }
    }
};
LXSticky.getInstance = function (e) {
    return null !== e && LXUtil.data(e).has("sticky") ? LXUtil.data(e).get("sticky") : null
}, LXSticky.createInstances = function (e = '[data-lx-sticky="true"]') {
    var t = document.getElementsByTagName("BODY")[0].querySelectorAll(e);
    if (t && t.length > 0)
        for (var n = 0, i = t.length; n < i; n++) new LXSticky(t[n])
}, window.addEventListener("resize", (function () {
    var e = document.getElementsByTagName("BODY")[0];
    LXUtil.throttle(undefined, (function () {
        var t = e.querySelectorAll('[data-lx-sticky="true"]');
        if (t && t.length > 0)
            for (var n = 0, i = t.length; n < i; n++) {
                var r = LXSticky.getInstance(t[n]);
                r && r.update()
            }
    }), 200)
})), LXSticky.init = function () {
    LXSticky.createInstances()
}, "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", LXSticky.init) : LXSticky.init(), "undefined" != typeof module && void 0 !== module.exports && (module.exports = LXSticky);
var LXSwapper = function (e, t) {
    var n = this;
    if (null != e) {
        var i = {
                mode: "append"
            },
            r = function () {
                n.element = e, n.options = LXUtil.deepExtend({}, i, t), n.element.setAttribute("data-lx-swapper", "true"), o(), LXUtil.data(n.element).set("swapper", n)
            },
            o = function (t) {
                var n = a("parent"),
                    i = a("mode"),
                    r = n ? document.querySelector(n) : null;
                r && e.parentNode !== r && ("prepend" === i ? r.prepend(e) : "append" === i && r.append(e))
            },
            a = function (e) {
                if (!0 === n.element.hasAttribute("data-lx-swapper-" + e)) {
                    var t = n.element.getAttribute("data-lx-swapper-" + e),
                        i = LXUtil.getResponsiveValue(t);
                    return null !== i && "true" === String(i) ? i = !0 : null !== i && "false" === String(i) && (i = !1), i
                }
                var r = LXUtil.snakeToCamel(e);
                return n.options[r] ? LXUtil.getResponsiveValue(n.options[r]) : null
            };
        !0 === LXUtil.data(e).has("swapper") ? n = LXUtil.data(e).get("swapper") : r(), n.update = function () {
            o()
        }, n.destroy = function () {
            LXUtil.data(n.element).remove("swapper")
        }, n.on = function (e, t) {
            return LXEventHandler.on(n.element, e, t)
        }, n.one = function (e, t) {
            return LXEventHandler.one(n.element, e, t)
        }, n.off = function (e) {
            return LXEventHandler.off(n.element, e)
        }, n.trigger = function (e, t) {
            return LXEventHandler.trigger(n.element, e, t, n, t)
        }
    }
};
LXSwapper.getInstance = function (e) {
    return null !== e && LXUtil.data(e).has("swapper") ? LXUtil.data(e).get("swapper") : null
}, LXSwapper.createInstances = function (e = '[data-lx-swapper="true"]') {
    var t = document.querySelectorAll(e);
    if (t && t.length > 0)
        for (var n = 0, i = t.length; n < i; n++) new LXSwapper(t[n])
}, window.addEventListener("resize", (function () {
    LXUtil.throttle(undefined, (function () {
        var e = document.querySelectorAll('[data-lx-swapper="true"]');
        if (e && e.length > 0)
            for (var t = 0, n = e.length; t < n; t++) {
                var i = LXSwapper.getInstance(e[t]);
                i && i.update()
            }
    }), 200)
})), LXSwapper.init = function () {
    LXSwapper.createInstances()
}, "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", LXSwapper.init) : LXSwapper.init(), "undefined" != typeof module && void 0 !== module.exports && (module.exports = LXSwapper);
var LXToggle = function (e, t) {
    var n = this;
    document.getElementsByTagName("BODY")[0];
    if (e) {
        var i = {
                saveState: !0
            },
            r = function () {
                n.options = LXUtil.deepExtend({}, i, t), n.uid = LXUtil.getUniqueId("toggle"), n.element = e, n.target = document.querySelector(n.element.getAttribute("data-lx-toggle-target")) ? document.querySelector(n.element.getAttribute("data-lx-toggle-target")) : n.element, n.state = n.element.hasAttribute("data-lx-toggle-state") ? n.element.getAttribute("data-lx-toggle-state") : "", n.attribute = "data-lx-" + n.element.getAttribute("data-lx-toggle-name"), o(), LXUtil.data(n.element).set("toggle", n)
            },
            o = function () {
                LXUtil.addEvent(n.element, "click", (function (e) {
                    e.preventDefault(), a()
                }))
            },
            a = function () {
                return LXEventHandler.trigger(n.element, "lx.toggle.change", n), u() ? s() : l(), LXEventHandler.trigger(n.element, "lx.toggle.changed", n), n
            },
            l = function () {
                if (!0 !== u()) return LXEventHandler.trigger(n.element, "lx.toggle.enable", n), n.target.setAttribute(n.attribute, "on"), n.state.length > 0 && n.element.classList.add(n.state), void 0 !== LXCookie && !0 === n.options.saveState && LXCookie.set(n.attribute, "on"), LXEventHandler.trigger(n.element, "lx.toggle.enabled", n), n
            },
            s = function () {
                if (!1 !== u()) return LXEventHandler.trigger(n.element, "lx.toggle.disable", n), n.target.removeAttribute(n.attribute), n.state.length > 0 && n.element.classList.remove(n.state), void 0 !== LXCookie && !0 === n.options.saveState && LXCookie.remove(n.attribute), LXEventHandler.trigger(n.element, "lx.toggle.disabled", n), n
            },
            u = function () {
                return "on" === String(n.target.getAttribute(n.attribute)).toLowerCase()
            };
        !0 === LXUtil.data(e).has("toggle") ? n = LXUtil.data(e).get("toggle") : r(), n.toggle = function () {
            return a()
        }, n.enable = function () {
            return l()
        }, n.disable = function () {
            return s()
        }, n.isEnabled = function () {
            return u()
        }, n.goElement = function () {
            return n.element
        }, n.destroy = function () {
            LXUtil.data(n.element).remove("toggle")
        }, n.on = function (e, t) {
            return LXEventHandler.on(n.element, e, t)
        }, n.one = function (e, t) {
            return LXEventHandler.one(n.element, e, t)
        }, n.off = function (e) {
            return LXEventHandler.off(n.element, e)
        }, n.trigger = function (e, t) {
            return LXEventHandler.trigger(n.element, e, t, n, t)
        }
    }
};
LXToggle.getInstance = function (e) {
        return null !== e && LXUtil.data(e).has("toggle") ? LXUtil.data(e).get("toggle") : null
    }, LXToggle.createInstances = function (e = "[data-lx-toggle]") {
        var t = document.getElementsByTagName("BODY")[0].querySelectorAll(e);
        if (t && t.length > 0)
            for (var n = 0, i = t.length; n < i; n++) new LXToggle(t[n])
    }, LXToggle.init = function () {
        LXToggle.createInstances()
    }, "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", LXToggle.init) : LXToggle.init(), "undefined" != typeof module && void 0 !== module.exports && (module.exports = LXToggle), Element.prototype.matches || (Element.prototype.matches = function (e) {
        for (var t = (this.document || this.ownerDocument).querySelectorAll(e), n = t.length; --n >= 0 && t.item(n) !== this;);
        return n > -1
    }), Element.prototype.closest || (Element.prototype.closest = function (e) {
        var t = this;
        if (!document.documentElement.contains(this)) return null;
        do {
            if (t.matches(e)) return t;
            t = t.parentElement
        } while (null !== t);
        return null
    })
    /**
     * ChildNode.remove() polyfill
     * https://gomakethings.com/removing-an-element-from-the-dom-the-es6-way/
     * @author Chris Ferdinandi
     * @license MIT
     */
    ,
    function (e) {
        for (var t = 0; t < e.length; t++) window[e[t]] && !("remove" in window[e[t]].prototype) && (window[e[t]].prototype.remove = function () {
            this.parentNode.removeChild(this)
        })
    }(["Element", "CharacterData", "DocumentType"]),
    function () {
        for (var e = 0, t = ["webkit", "moz"], n = 0; n < t.length && !window.requestAnimationFrame; ++n) window.requestAnimationFrame = window[t[n] + "RequestAnimationFrame"], window.cancelAnimationFrame = window[t[n] + "CancelAnimationFrame"] || window[t[n] + "CancelRequestAnimationFrame"];
        window.requestAnimationFrame || (window.requestAnimationFrame = function (t) {
            var n = (new Date).getTime(),
                i = Math.max(0, 16 - (n - e)),
                r = window.setTimeout((function () {
                    t(n + i)
                }), i);
            return e = n + i, r
        }), window.cancelAnimationFrame || (window.cancelAnimationFrame = function (e) {
            clearTimeout(e)
        })
    }(), [Element.prototype, Document.prototype, DocumentFragment.prototype].forEach((function (e) {
        e.hasOwnProperty("prepend") || Object.defineProperty(e, "prepend", {
            configurable: !0,
            enumerable: !0,
            writable: !0,
            value: function () {
                var e = Array.prototype.slice.call(arguments),
                    t = document.createDocumentFragment();
                e.forEach((function (e) {
                    var n = e instanceof Node;
                    t.appendChild(n ? e : document.createTextNode(String(e)))
                })), this.insertBefore(t, this.firstChild)
            }
        })
    })), null == Element.prototype.getAttributeNames && (Element.prototype.getAttributeNames = function () {
        for (var e = this.attributes, t = e.length, n = new Array(t), i = 0; i < t; i++) n[i] = e[i].name;
        return n
    }), window.LXUtilElementDataStore = {}, window.LXUtilElementDataStoreID = 0, window.LXUtilDelegatedEventHandlers = {};
var LXUtil = function () {
    var e = [],
        t = function () {
            window.addEventListener("resize", (function () {
                LXUtil.throttle(undefined, (function () {
                    ! function () {
                        for (var t = 0; t < e.length; t++) e[t].call()
                    }()
                }), 200)
            }))
        };
    return {
        init: function (e) {
            t()
        },
        addResizeHandler: function (t) {
            e.push(t)
        },
        removeResizeHandler: function (t) {
            for (var n = 0; n < e.length; n++) t === e[n] && delete e[n]
        },
        runResizeHandlers: function () {
            _runResizeHandlers()
        },
        resize: function () {
            if ("function" == typeof Event) window.dispatchEvent(new Event("resize"));
            else {
                var e = window.document.createEvent("UIEvents");
                e.initUIEvent("resize", !0, !1, window, 0), window.dispatchEvent(e)
            }
        },
        getURLParam: function (e) {
            var t, n, i = window.location.search.substring(1).split("&");
            for (t = 0; t < i.length; t++)
                if ((n = i[t].split("="))[0] == e) return unescape(n[1]);
            return null
        },
        isMobileDevice: function () {
            var e = this.getViewPort().width < this.getBreakpoint("lg");
            return !1 === e && (e = null != navigator.userAgent.match(/iPad/i)), e
        },
        isDeslxopDevice: function () {
            return !LXUtil.isMobileDevice()
        },
        getViewPort: function () {
            var e = window,
                t = "inner";
            return "innerWidth" in window || (t = "client", e = document.documentElement || document.body), {
                width: e[t + "Width"],
                height: e[t + "Height"]
            }
        },
        isBreakpointUp: function (e) {
            return this.getViewPort().width >= this.getBreakpoint(e)
        },
        isBreakpointDown: function (e) {
            return this.getViewPort().width < this.getBreakpoint(e)
        },
        getViewportWidth: function () {
            return this.getViewPort().width
        },
        getUniqueId: function (e) {
            return e + Math.floor(Math.random() * (new Date).getTime())
        },
        getBreakpoint: function (e) {
            var t = this.getCssVariableValue("--bs-" + e);
            return t && (t = parseInt(t.trim())), t
        },
        isset: function (e, t) {
            var n;
            if (-1 !== (t = t || "").indexOf("[")) throw new Error("Unsupported object path notation.");
            t = t.split(".");
            do {
                if (void 0 === e) return !1;
                if (n = t.shift(), !e.hasOwnProperty(n)) return !1;
                e = e[n]
            } while (t.length);
            return !0
        },
        getHighestZindex: function (e) {
            for (var t, n; e && e !== document;) {
                if (("absolute" === (t = LXUtil.css(e, "position")) || "relative" === t || "fixed" === t) && (n = parseInt(LXUtil.css(e, "z-index")), !isNaN(n) && 0 !== n)) return n;
                e = e.parentNode
            }
            return 1
        },
        hasFixedPositionedParent: function (e) {
            for (; e && e !== document;) {
                if ("fixed" === LXUtil.css(e, "position")) return !0;
                e = e.parentNode
            }
            return !1
        },
        sleep: function (e) {
            for (var t = (new Date).getTime(), n = 0; n < 1e7 && !((new Date).getTime() - t > e); n++);
        },
        getRandomInt: function (e, t) {
            return Math.floor(Math.random() * (t - e + 1)) + e
        },
        isAngularVersion: function () {
            return void 0 !== window.Zone
        },
        deepExtend: function (e) {
            e = e || {};
            for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                if (n)
                    for (var i in n) n.hasOwnProperty(i) && ("[object Object]" !== Object.prototype.toString.call(n[i]) ? e[i] = n[i] : e[i] = LXUtil.deepExtend(e[i], n[i]))
            }
            return e
        },
        extend: function (e) {
            e = e || {};
            for (var t = 1; t < arguments.length; t++)
                if (arguments[t])
                    for (var n in arguments[t]) arguments[t].hasOwnProperty(n) && (e[n] = arguments[t][n]);
            return e
        },
        getBody: function () {
            return document.getElementsByTagName("body")[0]
        },
        hasClasses: function (e, t) {
            if (e) {
                for (var n = t.split(" "), i = 0; i < n.length; i++)
                    if (0 == LXUtil.hasClass(e, LXUtil.trim(n[i]))) return !1;
                return !0
            }
        },
        hasClass: function (e, t) {
            if (e) return e.classList ? e.classList.contains(t) : new RegExp("\\b" + t + "\\b").test(e.className)
        },
        addClass: function (e, t) {
            if (e && void 0 !== t) {
                var n = t.split(" ");
                if (e.classList)
                    for (var i = 0; i < n.length; i++) n[i] && n[i].length > 0 && e.classList.add(LXUtil.trim(n[i]));
                else if (!LXUtil.hasClass(e, t))
                    for (var r = 0; r < n.length; r++) e.className += " " + LXUtil.trim(n[r])
            }
        },
        removeClass: function (e, t) {
            if (e && void 0 !== t) {
                var n = t.split(" ");
                if (e.classList)
                    for (var i = 0; i < n.length; i++) e.classList.remove(LXUtil.trim(n[i]));
                else if (LXUtil.hasClass(e, t))
                    for (var r = 0; r < n.length; r++) e.className = e.className.replace(new RegExp("\\b" + LXUtil.trim(n[r]) + "\\b", "g"), "")
            }
        },
        triggerCustomEvent: function (e, t, n) {
            var i;
            window.CustomEvent ? i = new CustomEvent(t, {
                detail: n
            }) : (i = document.createEvent("CustomEvent")).initCustomEvent(t, !0, !0, n), e.dispatchEvent(i)
        },
        triggerEvent: function (e, t) {
            var n;
            if (e.ownerDocument) n = e.ownerDocument;
            else {
                if (9 != e.nodeType) throw new Error("Invalid node passed to fireEvent: " + e.id);
                n = e
            }
            if (e.dispatchEvent) {
                var i = "";
                switch (t) {
                    case "click":
                    case "mouseenter":
                    case "mouseleave":
                    case "mousedown":
                    case "mouseup":
                        i = "MouseEvents";
                        break;
                    case "focus":
                    case "change":
                    case "blur":
                    case "select":
                        i = "HTMLEvents";
                        break;
                    default:
                        throw "fireEvent: Couldn't find an event class for event '" + t + "'."
                }
                var r = "change" != t;
                (o = n.createEvent(i)).initEvent(t, r, !0), o.synthetic = !0, e.dispatchEvent(o, !0)
            } else if (e.fireEvent) {
                var o;
                (o = n.createEventObject()).synthetic = !0, e.fireEvent("on" + t, o)
            }
        },
        index: function (e) {
            for (var t = e.parentNode.children, n = 0; n < t.length; n++)
                if (t[n] == e) return n
        },
        trim: function (e) {
            return e.trim()
        },
        eventTriggered: function (e) {
            return !!e.currentTarget.dataset.triggered || (e.currentTarget.dataset.triggered = !0, !1)
        },
        remove: function (e) {
            e && e.parentNode && e.parentNode.removeChild(e)
        },
        find: function (e, t) {
            return null !== e ? e.querySelector(t) : null
        },
        findAll: function (e, t) {
            return null !== e ? e.querySelectorAll(t) : null
        },
        insertAfter: function (e, t) {
            return t.parentNode.insertBefore(e, t.nextSibling)
        },
        parents: function (e, t) {
            for (var n = []; e && e !== document; e = e.parentNode) t ? e.matches(t) && n.push(e) : n.push(e);
            return n
        },
        children: function (e, t, n) {
            if (!e || !e.childNodes) return null;
            for (var i = [], r = 0, o = e.childNodes.length; r < o; ++r) 1 == e.childNodes[r].nodeType && LXUtil.matches(e.childNodes[r], t, n) && i.push(e.childNodes[r]);
            return i
        },
        child: function (e, t, n) {
            var i = LXUtil.children(e, t, n);
            return i ? i[0] : null
        },
        matches: function (e, t, n) {
            var i = Element.prototype,
                r = i.matches || i.webkitMatchesSelector || i.mozMatchesSelector || i.msMatchesSelector || function (e) {
                    return -1 !== [].indexOf.call(document.querySelectorAll(e), this)
                };
            return !(!e || !e.tagName) && r.call(e, t)
        },
        data: function (e) {
            return {
                set: function (t, n) {
                    e && (void 0 === e.customDataTag && (window.LXUtilElementDataStoreID++, e.customDataTag = window.LXUtilElementDataStoreID), void 0 === window.LXUtilElementDataStore[e.customDataTag] && (window.LXUtilElementDataStore[e.customDataTag] = {}), window.LXUtilElementDataStore[e.customDataTag][t] = n)
                },
                get: function (t) {
                    if (e) return void 0 === e.customDataTag ? null : this.has(t) ? window.LXUtilElementDataStore[e.customDataTag][t] : null
                },
                has: function (t) {
                    return !!e && (void 0 !== e.customDataTag && !(!window.LXUtilElementDataStore[e.customDataTag] || !window.LXUtilElementDataStore[e.customDataTag][t]))
                },
                remove: function (t) {
                    e && this.has(t) && delete window.LXUtilElementDataStore[e.customDataTag][t]
                }
            }
        },
        outerWidth: function (e, t) {
            var n;
            return !0 === t ? (n = parseFloat(e.offsetWidth), n += parseFloat(LXUtil.css(e, "margin-left")) + parseFloat(LXUtil.css(e, "margin-right")), parseFloat(n)) : n = parseFloat(e.offsetWidth)
        },
        offset: function (e) {
            var t, n;
            if (e) return e.getClientRects().length ? (t = e.getBoundingClientRect(), n = e.ownerDocument.defaultView, {
                top: t.top + n.pageYOffset,
                left: t.left + n.pageXOffset,
                right: window.innerWidth - (e.offsetLeft + e.offsetWidth)
            }) : {
                top: 0,
                left: 0
            }
        },
        height: function (e) {
            return LXUtil.css(e, "height")
        },
        outerHeight: function (e, t) {
            var n, i = e.offsetHeight;
            return void 0 !== t && !0 === t ? (n = getComputedStyle(e), i += parseInt(n.marginTop) + parseInt(n.marginBottom)) : i
        },
        visible: function (e) {
            return !(0 === e.offsetWidth && 0 === e.offsetHeight)
        },
        attr: function (e, t, n) {
            if (null != e) return void 0 === n ? e.getAttribute(t) : void e.setAttribute(t, n)
        },
        hasAttr: function (e, t) {
            if (null != e) return !!e.getAttribute(t)
        },
        removeAttr: function (e, t) {
            null != e && e.removeAttribute(t)
        },
        animate: function (e, t, n, i, r, o) {
            var a = {};
            if (a.linear = function (e, t, n, i) {
                    return n * e / i + t
                }, r = a.linear, "number" == typeof e && "number" == typeof t && "number" == typeof n && "function" == typeof i) {
                "function" != typeof o && (o = function () {});
                var l = window.requestAnimationFrame || function (e) {
                        window.setTimeout(e, 20)
                    },
                    s = t - e;
                i(e);
                var u = window.performance && window.performance.now ? window.performance.now() : +new Date;
                l((function a(d) {
                    var c = (d || +new Date) - u;
                    c >= 0 && i(r(c, e, s, n)), c >= 0 && c >= n ? (i(t), o()) : l(a)
                }))
            }
        },
        actualCss: function (e, t, n) {
            var i, r = "";
            if (e instanceof HTMLElement != !1) return e.getAttribute("lx-hidden-" + t) && !1 !== n ? parseFloat(e.getAttribute("lx-hidden-" + t)) : (r = e.style.cssText, e.style.cssText = "position: absolute; visibility: hidden; display: block;", "width" == t ? i = e.offsetWidth : "height" == t && (i = e.offsetHeight), e.style.cssText = r, e.setAttribute("lx-hidden-" + t, i), parseFloat(i))
        },
        actualHeight: function (e, t) {
            return LXUtil.actualCss(e, "height", t)
        },
        actualWidth: function (e, t) {
            return LXUtil.actualCss(e, "width", t)
        },
        getScroll: function (e, t) {
            return t = "scroll" + t, e == window || e == document ? self["scrollTop" == t ? "pageYOffset" : "pageXOffset"] || browserSupportsBoxModel && document.documentElement[t] || document.body[t] : e[t]
        },
        css: function (e, t, n, i) {
            if (e)
                if (void 0 !== n) !0 === i ? e.style.setProperty(t, n, "important") : e.style[t] = n;
                else {
                    var r = (e.ownerDocument || document).defaultView;
                    if (r && r.getComputedStyle) return t = t.replace(/([A-Z])/g, "-$1").toLowerCase(), r.getComputedStyle(e, null).getPropertyValue(t);
                    if (e.currentStyle) return t = t.replace(/\-(\w)/g, (function (e, t) {
                        return t.toUpperCase()
                    })), n = e.currentStyle[t], /^\d+(em|pt|%|ex)?$/i.test(n) ? function (t) {
                        var n = e.style.left,
                            i = e.runtimeStyle.left;
                        return e.runtimeStyle.left = e.currentStyle.left, e.style.left = t || 0, t = e.style.pixelLeft + "px", e.style.left = n, e.runtimeStyle.left = i, t
                    }(n) : n
                }
        },
        slide: function (e, t, n, i, r) {
            if (!(!e || "up" == t && !1 === LXUtil.visible(e) || "down" == t && !0 === LXUtil.visible(e))) {
                n = n || 600;
                var o = LXUtil.actualHeight(e),
                    a = !1,
                    l = !1;
                LXUtil.css(e, "padding-top") && !0 !== LXUtil.data(e).has("slide-padding-top") && LXUtil.data(e).set("slide-padding-top", LXUtil.css(e, "padding-top")), LXUtil.css(e, "padding-bottom") && !0 !== LXUtil.data(e).has("slide-padding-bottom") && LXUtil.data(e).set("slide-padding-bottom", LXUtil.css(e, "padding-bottom")), LXUtil.data(e).has("slide-padding-top") && (a = parseInt(LXUtil.data(e).get("slide-padding-top"))), LXUtil.data(e).has("slide-padding-bottom") && (l = parseInt(LXUtil.data(e).get("slide-padding-bottom"))), "up" == t ? (e.style.cssText = "display: block; overflow: hidden;", a && LXUtil.animate(0, a, n, (function (t) {
                    e.style.paddingTop = a - t + "px"
                }), "linear"), l && LXUtil.animate(0, l, n, (function (t) {
                    e.style.paddingBottom = l - t + "px"
                }), "linear"), LXUtil.animate(0, o, n, (function (t) {
                    e.style.height = o - t + "px"
                }), "linear", (function () {
                    e.style.height = "", e.style.display = "none", "function" == typeof i && i()
                }))) : "down" == t && (e.style.cssText = "display: block; overflow: hidden;", a && LXUtil.animate(0, a, n, (function (t) {
                    e.style.paddingTop = t + "px"
                }), "linear", (function () {
                    e.style.paddingTop = ""
                })), l && LXUtil.animate(0, l, n, (function (t) {
                    e.style.paddingBottom = t + "px"
                }), "linear", (function () {
                    e.style.paddingBottom = ""
                })), LXUtil.animate(0, o, n, (function (t) {
                    e.style.height = t + "px"
                }), "linear", (function () {
                    e.style.height = "", e.style.display = "", e.style.overflow = "", "function" == typeof i && i()
                })))
            }
        },
        slideUp: function (e, t, n) {
            LXUtil.slide(e, "up", t, n)
        },
        slideDown: function (e, t, n) {
            LXUtil.slide(e, "down", t, n)
        },
        show: function (e, t) {
            void 0 !== e && (e.style.display = t || "block")
        },
        hide: function (e) {
            void 0 !== e && (e.style.display = "none")
        },
        addEvent: function (e, t, n, i) {
            null != e && e.addEventListener(t, n)
        },
        removeEvent: function (e, t, n) {
            null !== e && e.removeEventListener(t, n)
        },
        on: function (e, t, n, i) {
            if (null !== e) {
                var r = LXUtil.getUniqueId("event");
                return window.LXUtilDelegatedEventHandlers[r] = function (n) {
                    for (var r = e.querySelectorAll(t), o = n.target; o && o !== e;) {
                        for (var a = 0, l = r.length; a < l; a++) o === r[a] && i.call(o, n);
                        o = o.parentNode
                    }
                }, LXUtil.addEvent(e, n, window.LXUtilDelegatedEventHandlers[r]), r
            }
        },
        off: function (e, t, n) {
            e && window.LXUtilDelegatedEventHandlers[n] && (LXUtil.removeEvent(e, t, window.LXUtilDelegatedEventHandlers[n]), delete window.LXUtilDelegatedEventHandlers[n])
        },
        one: function (e, t, n) {
            e.addEventListener(t, (function t(i) {
                return i.target && i.target.removeEventListener && i.target.removeEventListener(i.type, t), e && e.removeEventListener && i.currentTarget.removeEventListener(i.type, t), n(i)
            }))
        },
        hash: function (e) {
            var t, n = 0;
            if (0 === e.length) return n;
            for (t = 0; t < e.length; t++) n = (n << 5) - n + e.charCodeAt(t), n |= 0;
            return n
        },
        animateClass: function (e, t, n) {
            var i, r = {
                animation: "animationend",
                OAnimation: "oAnimationEnd",
                MozAnimation: "mozAnimationEnd",
                WebkitAnimation: "webkitAnimationEnd",
                msAnimation: "msAnimationEnd"
            };
            for (var o in r) void 0 !== e.style[o] && (i = r[o]);
            LXUtil.addClass(e, t), LXUtil.one(e, i, (function () {
                LXUtil.removeClass(e, t)
            })), n && LXUtil.one(e, i, n)
        },
        transitionEnd: function (e, t) {
            var n, i = {
                transition: "transitionend",
                OTransition: "oTransitionEnd",
                MozTransition: "mozTransitionEnd",
                WebkitTransition: "webkitTransitionEnd",
                msTransition: "msTransitionEnd"
            };
            for (var r in i) void 0 !== e.style[r] && (n = i[r]);
            LXUtil.one(e, n, t)
        },
        animationEnd: function (e, t) {
            var n, i = {
                animation: "animationend",
                OAnimation: "oAnimationEnd",
                MozAnimation: "mozAnimationEnd",
                WebkitAnimation: "webkitAnimationEnd",
                msAnimation: "msAnimationEnd"
            };
            for (var r in i) void 0 !== e.style[r] && (n = i[r]);
            LXUtil.one(e, n, t)
        },
        animateDelay: function (e, t) {
            for (var n = ["webkit-", "moz-", "ms-", "o-", ""], i = 0; i < n.length; i++) LXUtil.css(e, n[i] + "animation-delay", t)
        },
        animateDuration: function (e, t) {
            for (var n = ["webkit-", "moz-", "ms-", "o-", ""], i = 0; i < n.length; i++) LXUtil.css(e, n[i] + "animation-duration", t)
        },
        scrollTo: function (e, t, n) {
            n = n || 500;
            var i, r, o = e ? LXUtil.offset(e).top : 0;
            t && (o -= t), i = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0, r = o, LXUtil.animate(i, r, n, (function (e) {
                document.documentElement.scrollTop = e, document.body.parentNode.scrollTop = e, document.body.scrollTop = e
            }))
        },
        scrollTop: function (e, t) {
            LXUtil.scrollTo(null, e, t)
        },
        isArray: function (e) {
            return e && Array.isArray(e)
        },
        isEmpty: function (e) {
            for (var t in e)
                if (e.hasOwnProperty(t)) return !1;
            return !0
        },
        numberString: function (e) {
            for (var t = (e += "").split("."), n = t[0], i = t.length > 1 ? "." + t[1] : "", r = /(\d+)(\d{3})/; r.test(n);) n = n.replace(r, "$1,$2");
            return n + i
        },
        isRTL: function () {
            return "rtl" === document.querySelector("html").getAttribute("direction")
        },
        snakeToCamel: function (e) {
            return e.replace(/(\-\w)/g, (function (e) {
                return e[1].toUpperCase()
            }))
        },
        filterBoolean: function (e) {
            return !0 === e || "true" === e || !1 !== e && "false" !== e && e
        },
        setHTML: function (e, t) {
            e.innerHTML = t
        },
        getHTML: function (e) {
            if (e) return e.innerHTML
        },
        getDocumentHeight: function () {
            var e = document.body,
                t = document.documentElement;
            return Math.max(e.scrollHeight, e.offsetHeight, t.clientHeight, t.scrollHeight, t.offsetHeight)
        },
        getScrollTop: function () {
            return (document.scrollingElement || document.documentElement).scrollTop
        },
        colorLighten: function (e, t) {
            const n = function (e, t) {
                let n = parseInt(e, 16) + t,
                    i = n > 255 ? 255 : n;
                return i = i.toString(16).length > 1 ? i.toString(16) : `0${i.toString(16)}`, i
            };
            return e = e.indexOf("#") >= 0 ? e.substring(1, e.length) : e, t = parseInt(255 * t / 100), `#${n(e.substring(0,2),t)}${n(e.substring(2,4),t)}${n(e.substring(4,6),t)}`
        },
        colorDarken: function (e, t) {
            const n = function (e, t) {
                let n = parseInt(e, 16) - t,
                    i = n < 0 ? 0 : n;
                return i = i.toString(16).length > 1 ? i.toString(16) : `0${i.toString(16)}`, i
            };
            return e = e.indexOf("#") >= 0 ? e.substring(1, e.length) : e, t = parseInt(255 * t / 100), `#${n(e.substring(0,2),t)}${n(e.substring(2,4),t)}${n(e.substring(4,6),t)}`
        },
        throttle: function (e, t, n) {
            e || (e = setTimeout((function () {
                t(), e = void 0
            }), n))
        },
        debounce: function (e, t, n) {
            clearTimeout(e), e = setTimeout(t, n)
        },
        parseJson: function (e) {
            if ("string" == typeof e) {
                var t = (e = e.replace(/'/g, '"')).replace(/(\w+:)|(\w+ :)/g, (function (e) {
                    return '"' + e.substring(0, e.length - 1) + '":'
                }));
                try {
                    e = JSON.parse(t)
                } catch (e) {}
            }
            return e
        },
        getResponsiveValue: function (e, t) {
            var n, i = this.getViewPort().width;
            if ("object" == typeof (e = LXUtil.parseJson(e))) {
                var r, o, a = -1;
                for (var l in e)(o = "default" === l ? 0 : this.getBreakpoint(l) ? this.getBreakpoint(l) : parseInt(l)) <= i && o > a && (r = l, a = o);
                n = r ? e[r] : e
            } else n = e;
            return n
        },
        each: function (e, t) {
            return [].slice.call(e).map(t)
        },
        getSelectorMatchValue: function (e) {
            var t = null;
            if ("object" == typeof (e = LXUtil.parseJson(e))) {
                if (void 0 !== e.match) {
                    var n = Object.keys(e.match)[0];
                    e = Object.values(e.match)[0], null !== document.querySelector(n) && (t = e)
                }
            } else t = e;
            return t
        },
        getConditionalValue: function (e) {
            e = LXUtil.parseJson(e);
            var t = LXUtil.getResponsiveValue(e);
            return null !== t && void 0 !== t.match && (t = LXUtil.getSelectorMatchValue(t)), null === t && null !== e && void 0 !== e.default && (t = e.default), t
        },
        getCssVariableValue: function (e) {
            var t = getComputedStyle(document.documentElement).getPropertyValue(e);
            return t && t.length > 0 && (t = t.trim()), t
        },
        isInViewport: function (e) {
            var t = e.getBoundingClientRect();
            return t.top >= 0 && t.left >= 0 && t.bottom <= (window.innerHeight || document.documentElement.clientHeight) && t.right <= (window.innerWidth || document.documentElement.clientWidth)
        },
        onDOMContentLoaded: function (e) {
            "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", e) : e()
        },
        inIframe: function () {
            try {
                return window.self !== window.top
            } catch (e) {
                return !0
            }
        },
        isHexColor: e => /^#[0-9A-F]{6}$/i.test(e)
    }
}();
"undefined" != typeof module && void 0 !== module.exports && (module.exports = LXUtil);
var LXApp = function () {
    var e = !1,
        t = function (e, t) {
            var n = {};
            e.hasAttribute("data-bs-delay-hide") && (n.hide = e.getAttribute("data-bs-delay-hide")), e.hasAttribute("data-bs-delay-show") && (n.show = e.getAttribute("data-bs-delay-show")), n && (t.delay = n), e.hasAttribute("data-bs-dismiss") && "click" == e.getAttribute("data-bs-dismiss") && (t.dismiss = "click");
            var i = new bootstrap.Tooltip(e, t);
            return t.dismiss && "click" === t.dismiss && e.addEventListener("click", (function (e) {
                i.hide()
            })), i
        },
        n = function (e, t) {
            var n = {};
            e.hasAttribute("data-bs-delay-hide") && (n.hide = e.getAttribute("data-bs-delay-hide")), e.hasAttribute("data-bs-delay-show") && (n.show = e.getAttribute("data-bs-delay-show")), n && (t.delay = n), "true" == e.getAttribute("data-bs-dismiss") && (t.dismiss = !0), !0 === t.dismiss && (t.template = '<div class="popover" role="tooltip"><div class="popover-arrow"></div><span class="popover-dismiss btn btn-icon"><i class="bi bi-x fs-2"></i></span><h3 class="popover-header"></h3><div class="popover-body"></div></div>');
            var i = new bootstrap.Popover(e, t);
            if (!0 === t.dismiss) {
                var r = function (e) {
                    i.hide()
                };
                e.addEventListener("shown.bs.popover", (function () {
                    document.getElementById(e.getAttribute("aria-describedby")).addEventListener("click", r)
                })), e.addEventListener("hide.bs.popover", (function () {
                    document.getElementById(e.getAttribute("aria-describedby")).removeEventListener("click", r)
                }))
            }
            return i
        },
        i = function () {
            [].slice.call(document.querySelectorAll('[data-lx-countup="true"]:not(.counted)')).map((function (e) {
                if (LXUtil.isInViewport(e) && LXUtil.visible(e)) {
                    var t = {},
                        n = e.getAttribute("data-lx-countup-value");
                    n = parseFloat(n.replace(/,/g, "")), e.hasAttribute("data-lx-countup-start-val") && (t.startVal = parseFloat(e.getAttribute("data-lx-countup-start-val"))), e.hasAttribute("data-lx-countup-duration") && (t.duration = parseInt(e.getAttribute("data-lx-countup-duration"))), e.hasAttribute("data-lx-countup-decimal-places") && (t.decimalPlaces = parseInt(e.getAttribute("data-lx-countup-decimal-places"))), e.hasAttribute("data-lx-countup-prefix") && (t.prefix = e.getAttribute("data-lx-countup-prefix")), e.hasAttribute("data-lx-countup-separator") && (t.separator = e.getAttribute("data-lx-countup-separator")), e.hasAttribute("data-lx-countup-suffix") && (t.suffix = e.getAttribute("data-lx-countup-suffix")), new countUp.CountUp(e, n, t).start(), e.classList.add("counted")
                }
            }))
        },
        r = function () {
            const e = Array.prototype.slice.call(document.querySelectorAll('[data-tns="true"]'), 0);
            (e || 0 !== e.length) && e.forEach((function (e) {
                ! function (e) {
                    if (!e) return;
                    const t = {};
                    e.getAttributeNames().forEach((function (n) {
                        if (/^data-tns-.*/g.test(n)) {
                            let r = n.replace("data-tns-", "").toLowerCase().replace(/(?:[\s-])\w/g, (function (e) {
                                return e.replace("-", "").toUpperCase()
                            }));
                            if ("data-tns-responsive" === n) {
                                const i = e.getAttribute(n).replace(/(\w+:)|(\w+ :)/g, (function (e) {
                                    return '"' + e.substring(0, e.length - 1) + '":'
                                }));
                                try {
                                    t[r] = JSON.parse(i)
                                } catch (e) {}
                            } else t[r] = "true" === (i = e.getAttribute(n)) || "false" !== i && i
                        }
                        var i
                    }));
                    const n = Object.assign({}, {
                        container: e,
                        slideBy: "page",
                        autoplay: !0,
                        autoplayButtonOutput: !1
                    }, t);
                    e.closest(".tns") && LXUtil.addClass(e.closest(".tns"), "tns-initiazlied"), tns(n)
                }(e)
            }))
        };
    return {
        init: function () {
            this.initPageLoader(), this.initBootstrapTooltips(), this.initBootstrapPopovers(), this.initBootstrapScrollSpy(), this.initDaterangepicker(), this.initButtons(), this.initCheck(), this.initSelect2(), this.initCountUp(), this.initCountUpTabs(), this.initAutosize(), this.initTinySliders(), this.initSmoothScroll(), this.initBootstrapToast()
        },
        initPageLoader: function () {
            LXUtil.removeClass(document.body, "page-loading")
        },
        initDaterangepicker: function () {
          
        },
        initBootstrapTooltip: function (e, n) {
            return t(e, n)
        },
        initBootstrapTooltips: function () {
            [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]')).map((function (e) {
                t(e, {})
            }))
        },
        initBootstrapModal: function () {
            -1 !== navigator.userAgent.toLowerCase().indexOf("firefox") && document.querySelectorAll(".modal:not(.initialized)").forEach((e => {
                e.addEventListener("shown.bs.modal", (function () {
                    bootstrap.Modal.getInstance(this).handleUpdate(), this.classList.add("initialized"), alert(2)
                }))
            }))
        },
        initBootstrapPopovers: function () {
            [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]')).map((function (e) {
                n(e, {})
            }))
        },
        initBootstrapPopover: function (e, t) {
            return n(e, t)
        },
        initBootstrapScrollSpy: function () {
            [].slice.call(document.querySelectorAll('[data-bs-spy="scroll"]')).map((function (e) {
                e.getAttribute("data-bs-target");
                var t = document.querySelector(e.getAttribute("data-bs-target")),
                    n = bootstrap.ScrollSpy.getInstance(t);
                n && n.refresh()
            }))
        },
        initBootstrapToast: function () {
            [].slice.call(document.querySelectorAll(".toast")).map((function (e) {
                return new bootstrap.Toast(e, {})
            }))
        },
        initButtons: function () {
            [].slice.call(document.querySelectorAll('[data-lx-buttons="true"]')).map((function (e) {
                var t = e.hasAttribute("data-lx-buttons-target") ? e.getAttribute("data-lx-buttons-target") : ".btn";
                LXUtil.on(e, t, "click", (function (n) {
                    [].slice.call(e.querySelectorAll(t + ".active")).map((function (e) {
                        e.classList.remove("active")
                    })), this.classList.add("active")
                }))
            }))
        },
        initCheck: function () {
            LXUtil.on(document.body, '[data-lx-check="true"]', "change", (function (e) {
                var t = this,
                    n = document.querySelectorAll(t.getAttribute("data-lx-check-target"));
                LXUtil.each(n, (function (e) {
                    "checkbox" == e.type ? e.checked = t.checked : e.classList.toggle("active")
                }))
            }))
        },
        initSelect2: function () {
            "undefined" != typeof jQuery && void 0 !== $.fn.select2 && ([].slice.call(document.querySelectorAll('[data-control="select2"], [data-lx-select2="true"]')).map((function (e) {
                var t = {
                    dir: document.body.getAttribute("direction")
                };
                e.closest(".modal") && (t.dropdownParent = $(e).closest(".modal"));

                "true" == e.getAttribute("data-hide-search") && (t.minimumResultsForSearch = 1 / 0), $(e).select2(t)
            })), !1 === e && (e = !0, $(document).on("select2:open", (function (e) {
                var t = document.querySelectorAll(".select2-container--open .select2-search__field");
                t.length > 0 && t[t.length - 1].focus()
            }))))
        },
        initCountUp: function () {
            i()
        },
        initCountUpTabs: function () {
            i(), window.addEventListener("scroll", i), [].slice.call(document.querySelectorAll('[data-lx-countup-tabs="true"][data-bs-toggle="tab"]')).map((function (e) {
                e.addEventListener("shown.bs.tab", i)
            }))
        },
        initAutosize: function () {
            [].slice.call(document.querySelectorAll('[data-lx-autosize="true"]')).map((function (e) {
                autosize(e)
            }))
        },
        initTinySliders: function () {
            r()
        },
        initSmoothScroll: function () {
            SmoothScroll && new SmoothScroll('a[data-lx-scroll-toggle][href*="#"]', {
                speed: 900,
                offset: function (e, t) {
                    return e.hasAttribute("data-lx-scroll-offset") ? LXUtil.getResponsiveValue(e.getAttribute("data-lx-scroll-offset")) : 0
                }
            })
        },
        isDarkMode: function () {
            return document.body.classList.contains("dark-mode")
        }
    }
}();
LXUtil.onDOMContentLoaded((function () {
    LXApp.init()
})), window.addEventListener("load", (function () {
    LXApp.initPageLoader()
})), "undefined" != typeof module && void 0 !== module.exports && (module.exports = LXApp);
var LXLayoutSearch = function () {
    var e, t, n, i, r, o, a, l, s, u, d, c, m, f = function (e) {
            setTimeout((function () {
                var i = LXUtil.getRandomInt(1, 3);
                t.classList.add("d-none"), 3 === i ? (n.classList.add("d-none"), r.classList.remove("d-none")) : (n.classList.remove("d-none"), r.classList.add("d-none")), e.complete()
            }), 1500)
        },
        p = function (e) {
            t.classList.remove("d-none"), n.classList.add("d-none"), r.classList.add("d-none")
        };
    return {
        init: function () {
            (e = document.querySelector("#lx_header_search")) && (i = e.querySelector('[data-lx-search-element="wrapper"]'), e.querySelector('[data-lx-search-element="form"]'), t = e.querySelector('[data-lx-search-element="main"]'), n = e.querySelector('[data-lx-search-element="results"]'), r = e.querySelector('[data-lx-search-element="empty"]'), o = e.querySelector('[data-lx-search-element="preferences"]'), a = e.querySelector('[data-lx-search-element="preferences-show"]'), l = e.querySelector('[data-lx-search-element="preferences-dismiss"]'), s = e.querySelector('[data-lx-search-element="advanced-options-form"]'), u = e.querySelector('[data-lx-search-element="advanced-options-form-show"]'), d = e.querySelector('[data-lx-search-element="advanced-options-form-cancel"]'), c = e.querySelector('[data-lx-search-element="advanced-options-form-search"]'), (m = new LXSearch(e)).on("lx.search.process", f), m.on("lx.search.clear", p), a.addEventListener("click", (function () {
                i.classList.add("d-none"), o.classList.remove("d-none")
            })), l.addEventListener("click", (function () {
                i.classList.remove("d-none"), o.classList.add("d-none")
            })), u.addEventListener("click", (function () {
                i.classList.add("d-none"), s.classList.remove("d-none")
            })), d.addEventListener("click", (function () {
                i.classList.remove("d-none"), s.classList.add("d-none")
            })), c.addEventListener("click", (function () {})))
        }
    }
}();
LXUtil.onDOMContentLoaded((function () {
    LXLayoutSearch.init()
}));