((_) => {
  "use strict";
  const cl = console.log;
  typeof String.prototype.toCapitalize === "undefined" &&
    Object.defineProperty(String.prototype, "toCapitalize", {
      value: function () {
        return this.charAt(0).toUpperCase() + this.slice(1);
      },
      enumerable: false,
    });
  const changePageUrl = (z) => {
    if (!z.replace) {
      window.history.pushState({ path: z.url }, "", z.url);
    } else {
      window.history.replaceState({ path: z.url }, "", z.url);
    }
  };
  const ajaxPageLocate = (z) => {
    let u;
    const r = new XMLHttpRequest();
    r.open("POST", z.url);
    r.setRequestHeader("Request-Type", "POST");

    disableElement($("body"), 2);
    r.addEventListener("load", function () {
      const resText = this.responseText;
      u = this.responseURL;
      document.open();
      document.write(resText);
      document.close();
      z.url = u;
      changePageUrl(z);
      $("html, body").animate(
        {
          scrollTop: 0,
        },
        400
      );
      enableElement($("body"));
    });
    r.send();
    return false;
  };
  const locateTo = (url, time, is_replace) => {
    typeof url === "undefined"
      ? ((url = location.href),
        (time = time || 0),
        setTimeout(() => {
          ajaxPageLocate({
            url: url,
            replace: true,
          });
        }, time))
      : ((time = time || 500),
        setTimeout(function () {
          switch (is_replace) {
            case true:
              ajaxPageLocate({
                url: url,
                replace: true,
              });
              break;
            case 1:
              ajaxPageLocate({
                url: url,
                replace: false,
              });
              break;
            default:
              ajaxPageLocate({
                url: url,
              });
              break;
          }
        }, time));
  };
  const locateToAnchorUrl = (t) => {
    const url = t.attr("href");
    
    if(is_empty(url)) return ajaxPageLocate({
      url: base_url+"/",
      replace: false,
    });

    if (isHttpUrl(url)) {
      const durl = new URL(url);
      durl.host !== location.host && t.attr("target", "_blank");
    }

    const replace = t.data("replace") == true ? true : false;
    if (t.attr("target") == "_blank") return;
    if (
      t.attr("href") == t[0].hash ||
      url == location.href ||
      t.attr("href") == "#"
    )
      return false;
    ajaxPageLocate({
      url: url,
      replace: replace,
    });
    return false;
  };
  const is_empty = (text) =>
    typeof text === "undefined" ||
    text == null ||
    text.length === 0 ||
    (typeof text === "string" && text.trim().length === 0) ||
    text == "" ||
    false;

  const resetForm = (f) => {
    f.trigger("reset");
    f.removeClass("was-validated");
    f.find(".is-valid").removeClass("is-valid");
    f.find("select").val("").trigger("change");
  };
  const removeTooltips = () => {
    $(".tooltip").remove();
  };
  const hide = (e) => e.slideUp();

  const show = (e) => e.slideDown();

  const remove = (e) => e.slideUp(() => e.remove());

  is_empty(window.Setting) && (window.Setting = {});
  const base_url = Setting.base_url;
  const ajax_url = {
    v: base_url + "/assets/php/process/visitor",
    s: base_url + "/assets/php/process/seller",
    a: base_url + "/assets/php/process/admin",
  };
  const ajax_error = Setting.ajax_error;
  const formString = (o) => "&" + $.param(o);
  const isArray = function (a) {
    return !!a && a.constructor === Array;
  };
  const isObject = function (a) {
    return !!a && a.constructor === Object;
  };
  const isHttpUrl = (s) => {
    let url;
    try {
      url = new URL(s);
    } catch (_) {
      return false;
    }
    return url.protocol === "http:" || url.protocol === "https:";
  };
  const sweetAlert = (type, title) => {
    type == "success" &&
      iziToast.success({
        message: title,
      });
    type == "error" &&
      iziToast.error({
        message: title,
      });
    type == "warning" &&
      iziToast.warning({
        message: title,
      });
    type == "info" &&
      iziToast.info({
        message: title,
      });
  };

  const disableElement = (e, x) => {
    if (!(e instanceof jQuery)) e = $(e);
    e.attr("disabled", true);
    if (
      e.length &&
      e[0].nodeName === "FORM" &&
      e.find("button[type=submit]").length
    ) {
      disableBtn(e.find("button[type=submit]"));
    }
    let html;
    switch (x) {
      case 1:
      case true:
        html =
          '<div class="absolute-preloader" ><div class="preloader-message" ><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Please Wait...</div></div>';
        break;
      case 2:
        e.addClass("preloader-instance-lg");
        html =
          '<div class="absolute-preloader" ><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span></div>';
        break;
      default:
        html =
          '<div class="absolute-preloader" ><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span></div>';
        break;
    }
    e.append(html).addClass("preloader-instance-disabled");
  };
  const enableElement = (e) => {
    if (!(e instanceof jQuery)) e = $(e);
    if (e[0].nodeName === "FORM" && e.find("button[type=submit]").length) {
      enableBtn(e.find("button[type=submit]"));
    }
    e.attr("disabled", false);
    e.find(".absolute-preloader:not([id])").remove();
    e.removeClass("preloader-instance-disabled").removeClass(
      "preloader-instance-lg"
    );
  };
  const disableBtn = (e, x) => {
    let preloader =
      '<span class="indicator-progress">Please wait...\
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>';
    if (x == "no-text" || x === "false") {
      preloader = `<span class="indicator-progress">
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>`;
    }

    if (e instanceof jQuery) e = e[0];

    if (!$(e).find(".indicator-label")[0] && x !== "false") {
      const text = $(e).html();
      $(e).html('<span class="indicator-label">' + text + "</span>");
    }

    if (!$(e).find(".indicator-progress")[0]) {
      $(e).append(preloader);
    }

    e.setAttribute("data-lx-indicator", "on"), (e.disabled = !0);
  };
  const enableBtn = (e) => {
    if (e instanceof jQuery) e = e[0];
    e.removeAttribute("data-lx-indicator"), (e.disabled = !1);
  };
  const initOtpPaste = () => {
    const form = $(".otp-form-group");
    const inputs = form.find(".form-control");
    const intRegex = /^\d+$/;
    inputs.on("paste", function (e) {
      const pastedValue = e.originalEvent.clipboardData.getData("Text");
      if (pastedValue.length === 6 && intRegex.test(pastedValue)) {
        const values = pastedValue.split("");
        $(values).each(function (index) {
          const i = $(
            '.otp-form-group .form-control[name="' + (index + 1) + '"]'
          );
          i.val(values[index]);
        });
      }
    });
    inputs.on("keyup", (e) => {
      const eve = e.originalEvent;
      e = e.target;
      intRegex.test(e.value) || $(e).val("");
      if (eve.keyCode === 224 || eve.keyCode === 86) return false;
      if (eve.keyCode === 8)
        e.value.length ||
          ($(e).prev(".form-control").length &&
            $(e).blur().prev(".form-control").focus());
      e.value.length == e.maxLength &&
        $(e).next(".form-control").length &&
        $(e).blur().next(".form-control").focus();
      f() && form.closest("form").trigger("submit");
    });
    const f = () => {
      let r = true;
      form.find(".form-control").each((f, e) => {
        if (e.value.length != e.maxLength) r = false;
      });
      return r;
    };
  };
  const getQueryParams = (qs) => {
    qs = qs.split("+").join(" ");
    var params = {},
      tokens,
      re = /[?&]?([^=]+)=([^&]*)/g;

    while ((tokens = re.exec(qs))) {
      params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
    }
    return params;
  };
  const $_GET = getQueryParams(document.location.search);
  const fillSelect = () => {
    $("select").each((f, e) => {
      e = $(e);
      const v = e.attr("val") || e.attr("value");
      if (is_empty(v)) return;
      if (is_empty(e.val())) {
        e.val(v).trigger("change");
      }
    });
  };

  const fillRadio = (n) => {
    $(`[type=radio][name=${n}]`).each((f, e) => {
      e = $(e);
      e.val() == e.data("value")
        ? e.prop("checked", true)
        : e.prop("checked", false);
    });
  };

  $(".form-disabled").each((f, e) => {
    const form = $(e);
    form.find("input").attr("disabled", true);
    form.find("select").attr("disabled", true);
    form.find("textarea").attr("disabled", true);
  });

  const Check = class {
    checkedTarget() {
      const t = [];
      this.target.each((f, e) => {
        e.checked && t.push(e);
      });
      return t;
    }
    init() {
      const c = () => {
        let cnt = 0;
        this.target.each((f, e) => {
          e.checked && cnt++;
        });
        cnt > 0 ? this.success() : this.error();
      };
      this.selector.on("click", (b) => {
        this.target.each((f, e) => {
          b.currentTarget.checked ? (e.checked = true) : (e.checked = false);
        }),
          c();
      });
      this.target.on("change", () => c());
      c();
    }
  };

  const Ajax = class {
    url = ajax_url.v;
    method = "POST";
    data = null;
    showError = true;
    paceIgnore = false;
    before = () => {};
    success = (r) => {};
    error = () => {};
    complete = () => {};
    send() {
      const x = this;
      $.ajax({
        url: x.url,
        method: x.method,
        data: x.data,
        beforeSend() {
          x.before();
        },
        success(r) {
          x.success(r);
        },
        error(jqXHR, textStatus, thrownError) {
          x.error();
          if (!x.showError) return false;
          let status = jqXHR.status;
          let text = jqXHR.responseText;
          let res;

          switch (status) {
            case 400:
            case 500:
              try {
                res = JSON.parse(text);
                sweetAlert("error", res.message);
              } catch (error) {
                cl(error);
                sweetAlert("error", text);
              }
              break;
            case 401:
              try {
                res = JSON.parse(text);
                showLogin(res);
              } catch (error) {
                cl(error);
                sweetAlert("error", text);
              }
              break;
            default:
              sweetAlert("error", ajax_error);
              break;
          }
        },
        complete() {
          x.complete();
        },
      });
    }
  };
  const Confirm = class {
    cancel = () => {};
    ok = () => {};
    head = "Are you sure?";
    text = "This action can't be undone";
    cancelText = "No, Cancel";
    okText = "Yes delete";
    okClass = "btn-danger";
    cancelClass = "btn-light-primary";
    iconColor = "warning";
    textClass = "";
    headClass = "";

    show() {
      const x = this;
      const b = $("body");
      const modal = $(
        `<div class="modal fade" tabindex="-1" style="display: none;" aria-hidden="true">
        <div class="modal-dialog p-2 mx-auto modal-dialog-centered mw-400px">
            <div class="card p-8 position-relative justify-align-center pointer-auto w-100 rounded-4">
                <div data-bs-dismiss="modal" class="btn me-4 mt-4 position-absolute top-0 end-0 btn-icon btn-active-light-primary btn-sm btn-active-icon-primary">
                    <span class="svg-icon svg-icon-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                        </svg>
                    </span>
                </div>
                <div class="swal2-icon swal2-${x.iconColor} swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">!</div>
                </div>
                <h2 class="swal2-title ${x.headClass}" id="swal2-title" style="display: block;">${x.head}</h2>
                <div class="swal2-html-container ${x.textClass}" id="swal2-html-container">${x.text}</div>
                <div class="swal2-actions d-flex mt-12 mb-6">
                    <button type="button" class="btn-confirm ns btn fw-bold ${x.okClass}">${x.okText}</button>
                    <button type="button" class="btn-cancel ns ms-4 btn fw-bold ${x.cancelClass}">${x.cancelText}</button>
                </div>
            </div>
        </div>
    </div>`
      );
      b.append(modal);
      modal.modal("show");
      b.find(".btn-cancel").on("click", () => {
        modal.modal("hide");
        modal.remove();
        x.cancel();
      });
      b.find(".btn-confirm").on("click", () => {
        modal.modal("hide");
        modal.remove();
        x.ok();
      });
    }
  };
  const ImageUpload = class {
    url = ajax_url.v;
    ext = ["png", "jpg", "jpeg", "webp"];
    data = {};
    name = "image";
    fileIndex = 0;
    showError = true;
    xhr = () => {};
    before = () => {};
    success = (res) => {};
    error = () => {};
    complete = () => {};
    constructor(chooser) {
      this.chooser = chooser;
    }
    upload() {
      const x = this;
      const chooser = this.chooser;
      const fileName = chooser.files[x.fileIndex].name;
      const ext = fileName.split(".").pop().toLowerCase();
      x.extErr = `Invalid Image File. <br> Valid files are ${x.ext.join(",")}`;

      if (x.ext.length && $.inArray(ext, x.ext) == -1) {
        x.error();
        return sweetAlert("error", x.extErr);
      }
      const files = chooser.files[x.fileIndex];
      const f = new FormData();
      f.append(x.name, files);
      Object.keys(x.data).forEach((k) => {
        f.append(k, x.data[k]);
      });

      const r = new FileReader();
      r.readAsDataURL(files);

      const xhr = $.ajax({
        xhr: function () {
          var xhr = new window.XMLHttpRequest();
          xhr.upload.addEventListener(
            "progress",
            function (evt) {
              if (evt.lengthComputable) {
                x.xhr(evt);
              }
            },
            false
          );
          return xhr;
        },
        url: x.url,
        method: "POST",
        data: f,
        contentType: false,
        cache: false,
        processData: false,
        before: function () {
          x.before();
        },
        success: function (res) {
          try {
            JSON.parse(res);
            x.success(res);
          } catch (error) {
            cl(error);
            x.error();
            sweetAlert("error", res);
          }
        },
        error: function (jqXHR, textStatus, thrownError) {
          x.error();
          if (!x.showError) return false;
          let status = jqXHR.status;
          let text = jqXHR.responseText;
          let res;

          switch (status) {
            case 400:
            case 500:
              try {
                res = JSON.parse(text);
                sweetAlert("error", res.message);
              } catch (error) {
                cl(error);
                sweetAlert("error", text);
              }
              break;
            case 401:
              try {
                res = JSON.parse(text);
                showLogin(res);
              } catch (error) {
                cl(error);
                sweetAlert("error", text);
              }
              break;
            default:
              sweetAlert("error", ajax_error);
              break;
          }
        },
        complete: function () {
          x.complete();
        },
      });

      x.abort = () => {
        xhr.abort();
      };

      return;
    }
  };
  const select2 = () => {
    document.querySelectorAll("select").forEach((e) => {
      const t = {
        minimumResultsForSearch:
          $(e).data("hide-search") || $(e).attr("name") == "data_table_length"
            ? -1
            : 1,
      };
      e.closest(".modal") && (t.dropdownParent = $(e).closest(".modal"));
      $(e).hasClass("select2-hidden-accessible") || $(e).select2(t);
    });
  };

  const Validations = {
    isNumber: (t) => {
      return /^\d+$/.test(t);
    },
    isAlphabet: (t) => {
      return /^[a-zA-Z /s]+$/.test(t);
    },
    isMobileNumber(t) {
      if (!this.isNumber(t)) return false;
      return t.length === 10;
    },
    isEmail(e) {
      const r = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      return r.test(e);
    },
    isValidBudget(t) {
      t = parseFloat(t);
      return t >= jobs.minBudget && t <= jobs.maxBudget;
    },
    isUserId(t) {
      function action($status) {
        if ($status == "1") {
          return {
            valid: true,
          };
        }
        return {
          valid: false,
        };
      }
      return new Promise((success, error) => {
        $.ajax({
          url: ajax_url.v,
          method: "POST",
          data: {
            referral_code: t,
            case: "validateReferralId",
            action: "account_action",
          },
          success: function (res) {
            try {
              res = JSON.parse(res);
              if (res.status == "1") {
                success(action($status));
              }
            } catch (error) {
              cl(error);
              success(action(0));
            }
          },
          error: function () {
            success(action(0));
          },
        });
      });
    },
  };
  const toSelect = (options) => {
    let selectElement = "";
    let selectOptions = "";
    options.forEach((e) => {
      selectElement += ` <option value="${e}" >${e}</option>`;
      selectOptions += `<input class="d-none" name="selectOptions" value="${e}">`;
    });
    return `${selectOptions}<select class="form-select form-select-solid" data-placeholder="Select" data-hide-search="true" data-control="select2" >${selectElement}</select>`;
  };

  const getObjLength = (o) => {
    return Object.keys(o).length;
  };

  const FormValidate = class {
    constructor(f, v) {
      this.form = f;
      this.elements = v || {};
      this.validate();
      this.checkValidity(false);
    }
    validate() {
      const x = this;
      const form = this.form;
      form.on("submit", function (e) {
        e.preventDefault();
        form.addClass("was-validated");
        x.checkValidity();
        this.checkValidity() && x.onValidate();
      });
    }
    checkValidity(hasSubmit) {
      const x = this;
      x.elements || (x.elements = {});

      x.form.find("input, textarea, select").each((f, e) => {
        const key = e.name;
        if (!is_empty(key) && !x.elements[key]) {
          x.elements[key] = {};
        }
      });

      Object.entries(x.elements).forEach(([key, val]) => {
        const element = x.getElementDom(key);
        const isRequired = element.prop("required");
        let feedback;
        if (!x.elements[key].validators) {
          const element = x.getElementDom(key);
          x.elements[key] = {};
          x.elements[key].validators = val;
          x.elements[key].element = element;
          x.elements[key].wrapper = element.closest(".fv-row");

          if (element.data("mask") === "integer") {
            x.elements[key].validators.number = {
              text: "Only numbers are allowed",
            };
          }
          if (typeof element.data("max") !== "undefined") {
            x.elements[key].validators.max = {
              max: element.data("max"),
              text: `Max ${element.data("max")} characters are allowed`,
            };
          }
          // if(typeof element.data("equal") !== "undefined")
          // {
          //   x.elements[key].validators.equal = {
          //     text:`Max ${element.data("max")} characters are allowed`,
          //   }
          // }
        }
        if (isRequired) {
          let text = "";
          feedback = x.elements[key].wrapper.find(".invalid-feedback");
          if (feedback.length) {
            text = feedback.html();
            feedback.remove();
          }
          x.elements[key].validators.required = { text: text };
        } else {
          // delete x.elements[key].element.off("input change")
        }
        x.validateField(key, hasSubmit);
      });
    }
    getElementDom(k) {
      return this.form.find(`input[name="${k}"]`);
    }
    validator = {
      required: (element) => {
        if (element[0].type === "checkbox") {
          return element[0].checked;
        }
        if (element[0].type === "radio") {
          return element
            .closest("form")
            .find("[type=radio][name=" + element.attr("name") + "]")
            .is(":checked");
        }
        return !is_empty(element.val());
      },
      equalTo: (element, data) => {
        return (
          is_empty(element.val()) ||
          this.getElementDom(data.field).val() === element.val()
        );
      },
      unEqual: (element, data) => {
        return (
          is_empty(element.val()) ||
          this.getElementDom(data.field).val() !== element.val()
        );
      },
      email: (element) => {
        return is_empty(element.val()) || Validations.isEmail(element.val());
      },
      number: (element) => {
        return is_empty(element.val()) || Validations.isNumber(element.val());
      },
      alphabet: (element) => {
        return is_empty(element.val()) || Validations.isAlphabet(element.val());
      },
      mobileNumber: (element) => {
        return (
          is_empty(element.val()) || Validations.isMobileNumber(element.val())
        );
      },
      postCode: (element) => {
        return (
          is_empty(element.val()) ||
          (element.val().length === 6 && Validations.isNumber(element.val()))
        );
      },
      alphaNumeric: (element) => {
        return (
          is_empty(element.val()) || Validations.isAlphaNumeric(element.val())
        );
      },
      url: (element) => {
        return is_empty(element.val()) || isHttpUrl(element.val());
      },
      min: (element, data) => {
        return is_empty(element.val()) || element.val().length >= data.min;
      },
      max: (element, data) => {
        return is_empty(element.val()) || element.val().length <= data.max;
      },
      equal: (element, data) => {
        return is_empty(element.val()) || element.val().length === data.max;
      },
    };
    validateField(z, hasSubmit = true) {
      const x = this;
      const elementValidation = x.elements[z];
      const wrapper = elementValidation.wrapper;
      const element = elementValidation.element;

      if (!elementValidation.eventInited) {
        elementValidation.eventInited = true;
        elementValidation.feedback = {};
        elementValidation.errors = {};
        elementValidation.inited = {};
      }

      Object.entries(elementValidation.validators).forEach(
        ([validator, data]) => {
          if (!elementValidation.feedback[validator]) {
            elementValidation.feedback[validator] = $(
              `<div class="bs-invalid-feedback invalid-feedback" >${data.text}</div>`
            );
          }

          const f = () => {
            if (typeof x.validator[validator] !== "function") {
              throw new Error(`${validator} is not a validator`);
            }

            if (x.validator[validator](element, data)) {
              elementValidation.feedback[validator] &&
                elementValidation.feedback[validator].remove();
              delete elementValidation.errors[validator];
              if (getObjLength(elementValidation.errors) === 0) {
                element[0].setCustomValidity("");
                element.removeClass("is-invalid").addClass("is-valid");
              }
            } else {
              elementValidation.errors[validator] = true;
              wrapper.append(elementValidation.feedback[validator]),
                element[0].setCustomValidity(data.text),
                element.removeClass("is-valid").addClass("is-invalid");
            }
          };

          hasSubmit && f();
          if (!elementValidation.inited[validator]) {
            elementValidation.inited[validator] = true;
            element.on("input change", (e) => f());
          }
        }
      );
    }
  };

  const clamp = () => {
    $("[data-clamp]").each((f, e) => {
      const t = $(e);
      const clamp = t.data("clamp");
      const clampClass = `line-clamp line-clamp-${clamp}`;
      const text = t.text();
      const replace = $(`<div class="${clampClass}"></div>`);
      const showMOre = $(`<a role="button"
                class="w-100 justify-align-center white-space-normal bg-white ps-2 text-dark text-hover-primary text-uppercase fs-7 fw-bolder">
                <span class="svg-icon rotate-180 svg-icon-dark svg-icon-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path opacity="0.5"
                            d="M12.5657 9.63427L16.75 5.44995C17.1642 5.03574 17.8358 5.03574 18.25 5.44995C18.6642 5.86416 18.6642 6.53574 18.25 6.94995L12.7071 12.4928C12.3166 12.8834 11.6834 12.8834 11.2929 12.4928L5.75 6.94995C5.33579 6.53574 5.33579 5.86416 5.75 5.44995C6.16421 5.03574 6.83579 5.03574 7.25 5.44995L11.4343 9.63427C11.7467 9.94669 12.2533 9.94668 12.5657 9.63427Z"
                            fill="black">
                        </path>
                        <path
                            d="M12.5657 15.6343L16.75 11.45C17.1642 11.0357 17.8358 11.0357 18.25 11.45C18.6642 11.8642 18.6642 12.5357 18.25 12.95L12.7071 18.4928C12.3166 18.8834 11.6834 18.8834 11.2929 18.4928L5.75 12.95C5.33579 12.5357 5.33579 11.8642 5.75 11.45C6.16421 11.0357 6.83579 11.0357 7.25 11.45L11.4343 15.6343C11.7467 15.9467 12.2533 15.9467 12.5657 15.6343Z"
                            fill="black">
                        </path>
                    </svg>
                </span>
                <div class="text">Show More...</div>
            </a>`);

      let hasShown = false;
      const init = () => {
        let scrollHeight = e.scrollHeight;
        let offsetHeight = e.offsetHeight;

        if (scrollHeight <= offsetHeight) {
          showMOre.remove();
        } else {
          t.removeClass(clampClass).html(replace);
          replace.html(text).addClass("height-trans");
          t.append(showMOre);

          showMOre.on("click", () => {
            if (hasShown) {
              hasShown = false;
              replace.addClass(clampClass);
              showMOre.removeClass("active").find(".text").html("Show More");
            } else {
              hasShown = true;
              replace.removeClass(clampClass);
              showMOre.addClass("active").find(".text").html("Show Less");
            }
          });
        }
      };

      init();
    });
  };

  const showLogin = function (c) {
    const loginModal = $(c.card);
    $("body").append(loginModal);
    loginModal.modal("show");
    Login.userLogin({
      role: c.role,
      popUp: true,
    });

    $(".modal").modal("hide");

    loginModal.on("hidden.bs.modal", function (e) {
      loginModal.remove();
    });
  };

  _.getCurrentDirPath = () =>
    window.location.pathname.substring(
      0,
      window.location.pathname.lastIndexOf("/") + 1
    );

  _.setActiveNavItem = (url) => {
    url = url || getCurrentDirPath();
    const menu = $(".navigationMenu");
    const t = menu.find('a[href="' + url + '"]');
    if (!t.length) return false;
    t.addClass("active");
    let next = t.closest(".menu-item.menu-accordion");
    const checkNext = () => {
      if (!next.length) return false;
      next.addClass("show");
      next.parent()[0] == menu[0]
        ? next.addClass("show")
        : ((next = next.parent().closest(".menu-item.menu-accordion")),
          checkNext());
    };
    checkNext();
  };

  _.Login = {
    userLogin(arg) {
      const role = (arg && arg.role) || "visitor";
      const popUp = (arg && arg.popUp) || false;
      const z = {
        email: null,
      };

      const t = $("#loginForm");
      const F = new FormValidate(t, {
        email: {
          email: {
            text: "Email is not valid",
          },
        },
      });
      F.onValidate = () => {
        const k = $("input#keeplogged").is(":checked") ? 1 : 0;
        const r = new Ajax();
        r.data =
          t.serialize() +
          formString({
            role: role,
            keeplogged: k,
            case: "login",
            action: "account_action",
          });
        r.before = () => disableElement(t, 2);
        r.error = () => enableElement(t);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            if (res.verification == "off") {
              const url = popUp ? undefined : $_GET["redirect_url"] || res.url;
              sweetAlert("success", res.message);
              locateTo(url, 1000, true);
            } else {
              const email = res.email;
              const $content = res.content;
              $("#loginCard").html($content);
              z.email = email;
              v();
            }
          } catch (error) {
            cl(error);
            r.error();
            sweetAlert("error", res);
          }
        };
        r.send();
      };

      const v = () => {
        $("#resendOtp").on("click", (x) => {
          const e = z.email;
          const b = $(x.currentTarget);
          const r = new Ajax();
          r.data =
            "user_email=" +
            e +
            "&case=login_verification_code&action=account_action";
          r.before = () => disableElement(b);
          r.success = (res) => {
            try {
              $(".otp-form-group input").val("");
              res = JSON.parse(res);
              sweetAlert("success", res.message);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.complete = () => enableElement(b);
          r.send();
        });

        initOtpPaste();

        let sending = !1;
        const t = $("#confirm_login_with_otp_form");
        const R = new FormValidate(t);
        R.onValidate = () => {
          if (sending) return false;
          sending = !0;

          const e = z.email;
          const f = t.serialize();
          const r = new Ajax();
          r.data =
            f +
            "&user_email=" +
            e +
            "&case=login_with_verification&action=account_action";
          r.before = () => disableElement(t, 2);
          r.error = () => enableElement(t);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              let message = res.message;
              let url = popUp ? undefined : res.url;
              sweetAlert("success", message);
              locateTo(url, 500, true);
            } catch (error) {
              cl(error);
              r.error();
              sweetAlert("error", res);
            }
          };
          r.complete = () => (sending = !1);
          r.send();
        };
      };

      role == "seller" &&
        $(".swiper").each(function (index) {
          let sliderSelector = this;
          let options = {
            init: false,
            loop: true,
            speed: 800,
            slidesPerView: 1,
            centeredSlides: true,
            autoplay: true,
            // autoplaydelay:100,
            autoplay: {
              delay: 1000,
            },
            effect: "coverflow", // 'cube', 'fade', 'coverflow',
            autoplayDisableOnInteraction: true,
            grabCursor: true,
            parallax: true,
            pagination: {
              el: ".swiper-pagination",
              clickable: true,
            },
            on: {
              imagesReady: function () {
                this.el.classList.remove("loading");
              },
            },
          };

          let mySwiper = new Swiper(sliderSelector, options);
          mySwiper.init();
        });
    },
    adminLogin() {
      const t = $("#loginForm");
      const F = new FormValidate(t);
      F.onValidate = () => {
        const f = t.serialize();
        let k = 0;
        if ($("input#keeplogged").is(":checked")) k = 1;
        const r = new Ajax();
        r.url = ajax_url.a;
        r.data = f + "&keeplogged=" + k + "&case=login&action=account_action";
        r.before = () => disableElement(t, 2);
        r.error = () => enableElement(t);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            const mes = res.message;
            const url = res.url;
            sweetAlert("success", mes);
            locateTo(url, 500, true);
          } catch (error) {
            cl(error);
            r.error();
            sweetAlert("error", res);
          }
        };
        r.send();
      };
    },
    userRegister(role) {
      role || (role = "visitor");
      const r_id = $_GET["referral"];
      typeof r_id === "string" && localStorage.setItem("referral_id", rid);

      const regForm = $("#regForm");
      const otpForm = $("#otpForm");

      const step1 = () => {
        regForm.removeClass("d-none");
        otpForm.addClass("d-none");
      };

      const step2 = () => {
        regForm.addClass("d-none");
        otpForm.removeClass("d-none");
      };

      let register;
      let next = false;

      const have_rc = () => {
        let have_rcode = "false";
        if ($("input#have_referral_code").prop("checked")) have_rcode = "true";
        return have_rcode;
      };

      const F = new FormValidate(regForm, {
        first_name: {
          alphabet: {
            text: "First Name is not valid",
          },
        },
        last_name: {
          alphabet: {
            text: "Last Name is not valid",
          },
        },
        password: {
          equalTo: {
            field: "confirm_password",
            text: "Passwords are not matching",
          },
        },
        confirm_password: {
          equalTo: {
            field: "password",
            text: "Passwords are not matching",
          },
        },
        email: { email: { text: "Email format is not valid" } },
      });

      F.elements.password.element.on("input", () => {
        F.validateField("confirm_password");
      });
      F.elements.confirm_password.element.on("input", () => {
        F.validateField("password");
      });

      F.onValidate = () => {
        const r = new Ajax();
        r.data =
          regForm.serialize() +
          formString({
            event: "register",
            role: role,
            case: "register",
            action: "account_action",
          });
        r.before = () => disableElement(regForm, 2);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            register = r;
            sweetAlert("success", res.message);
            step2();
            $("#email_sent_to").html(res.email);
            next || verifyOtp();
          } catch (error) {
            cl(error);
            r.error();
            sweetAlert("error", res);
          }
        };
        r.complete = () => enableElement(regForm);
        r.send();
      };

      const verifyOtp = () => {
        next = true;
        let sending = false;
        const R = new FormValidate(otpForm);
        R.onValidate = () => {
          if (sending) return false;
          const r = new Ajax();
          r.data =
            regForm.serialize() +
            "&" +
            otpForm.serialize() +
            formString({
              event: "verifyOtp",
              role: role,
              case: "register",
              action: "account_action",
            });
          r.before = () => {
            sending = true;
            disableElement(otpForm, 2);
          };
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              locateTo(res.url, 1000);
            } catch (error) {
              cl(error);
              r.error();
              sweetAlert("error", res);
            }
          };
          r.error = () => {
            enableElement(otpForm);
          };
          r.complete = () => {
            sending = false;
          };
          r.send();
        };

        $("#resendOtp").on("click", (h) => {
          resetForm(otpForm);
          register.before = () => disableElement(h.currentTarget);
          register.complete = () => enableElement(h.currentTarget);
          register.send();
        });

        initOtpPaste();
      };
    },
    userForgotPassword(role) {
      is_empty(role) && (role = "visitor");
      const z = {
        email: null,
        otp: null,
      };

      const forForm = $("#forForm");
      const otpForm = $("#otpForm");
      const resForm = $("#resForm");

      let currentStep = 1;
      let forgot;

      const step1 = () => {
        forForm.removeClass("d-none");
        otpForm.addClass("d-none");
        resForm.addClass("d-none");
      };

      const step2 = () => {
        otpForm.removeClass("d-none");
        forForm.addClass("d-none");
        resForm.addClass("d-none");
        currentStep = 2;
      };

      const step3 = () => {
        resForm.removeClass("d-none");
        otpForm.addClass("d-none");
        forForm.addClass("d-none");
        currentStep = 3;
      };

      const F = new FormValidate(forForm, {
        email: {
          email: {
            text: "Email is not valid",
          },
        },
      });
      const R = new FormValidate(otpForm);
      const S = new FormValidate(resForm, {
        password: {
          equalTo: {
            field: "confirm_password",
            text: "Passwords are not matching",
          },
        },
        confirm_password: {
          equalTo: {
            field: "password",
            text: "Passwords are not matching",
          },
        },
      });
      S.elements.password.element.on("input", () => {
        S.validateField("confirm_password");
      });
      S.elements.confirm_password.element.on("input", () => {
        S.validateField("password");
      });

      let next = false;

      F.onValidate = () => {
        if (currentStep !== 1) return false;
        const r = new Ajax();
        r.data =
          forForm.serialize() +
          formString({
            role: role,
            case: "forgot_password",
            action: "account_action",
          });
        r.before = () => disableElement(forForm, 2);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            z.email = res.email;
            sweetAlert("success", res.message);
            step2();
            next || verifyOtp();
            forgot = r;
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.complete = () => enableElement(forForm);
        r.send();
      };

      const verifyOtp = () => {
        next = true;
        initOtpPaste();
        let sending = !1;
        const g = z.email;
        $("#email_sent_to").html(g);

        $("#resendOtp").on("click", (h) => {
          resetForm(otpForm);
          forgot.before = () => disableElement(h.currentTarget);
          forgot.complete = () => enableElement(h.currentTarget);
          forgot.send();
        });

        R.onValidate = () => {
          if (currentStep !== 2) return false;
          if (sending) return false;
          sending = !0;
          const r = new Ajax();
          r.data =
            otpForm.serialize() +
            formString({
              email: z.email,
              role: role,
              case: "verify_forgot_password_otp",
              action: "account_action",
            });
          r.before = () => disableElement(otpForm, 2);
          r.complete = () => ((sending = !1), enableElement(otpForm));
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              z.otp = res.otp;
              step3();
              resPass();
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        };
      };

      const resPass = () => {
        resForm.find("#email").val(z.email);
        S.onValidate = () => {
          if (currentStep !== 3) return false;
          const r = new Ajax();
          r.data =
            resForm.serialize() +
            formString({
              otp: z.otp,
              role: role,
              email: z.email,
              case: "reset_password",
              action: "account_action",
            });
          r.before = () => disableElement(resForm, 2);
          r.error = () => enableElement(resForm);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              locateTo(res.url, 1000);
            } catch (error) {
              cl(error);
              r.error();
              sweetAlert("error", res);
            }
          };
          r.send();
        };
      };
    },
    userGoogleRegister(role) {
      role || (role = "visitor");
      const t = $("#userRegisterForm");
      const F = new FormValidate(t, {
        first_name: {
          alphabet: {
            text: "First Name is not valid",
          },
        },
        last_name: {
          alphabet: {
            text: "Last Name is not valid",
          },
        },
        password: {
          equalTo: {
            field: "confirm_password",
            text: "Passwords are not matching",
          },
        },
        confirm_password: {
          equalTo: {
            field: "password",
            text: "Passwords are not matching",
          },
        },
      });
      F.elements.password.element.on("input", () => {
        F.validateField("confirm_password");
      });
      F.elements.confirm_password.element.on("input", () => {
        F.validateField("password");
      });

      F.onValidate = () => {
        const r = new Ajax();
        r.data =
          t.serialize() +
          formString({
            google_id: $_GET["google"],
            step_id: 3,
            role: role,
            case: "register_with_google",
            action: "account_action",
          });
        r.before = () => disableElement(t, 2);
        r.error = () => enableElement(t);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            const mes = res.message;
            const url = res.url;
            sweetAlert("success", mes);
            locateTo(url, 1000);
          } catch (error) {
            cl(error);
            r.error();
            sweetAlert("error", res);
          }
        };
        r.send();
      };
    },
  };

  _.MyProfile = {
    Billing: function (action) {
      action = is_empty(action) ? "profile_action" : action;
      const modal = $("#addAddress");

      const Form = (z) => {
        const modal = z.modal;
        const e = modal.find("form");
        const F = new FormValidate(e, {
          full_name: {
            alphabet: {
              text: "Full name must consist of alphabets and spaces only",
            },
          },
          mobile_number: {
            mobileNumber: { text: "Mobile number is not valid" },
          },
          postcode: {
            postCode: {
              text: "Post Code is not valid",
            },
          },
        });

        F.onValidate = () => {
          const r = new Ajax();
          r.data =
            e.serialize() +
            formString({
              event: z.event,
              address_id: z.address_id,
              case: "add_new_address",
              action: action,
            });
          r.before = () => disableElement(e, 2);
          r.complete = () => enableElement(e);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message),
                z.successEvent(res),
                modal.modal("hide"),
                resetForm(e);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        };
      };
      Form({
        modal: modal,
        event: "create",
        address_id: 0,
        successEvent(res) {
          $("#addressRow").prepend(res.data), R();
        },
      });
      //
      const R = () => {
        $(".address-card").each((f, e) => {
          const card = $(e);
          if (card.hasClass("init-true")) return true;
          LXMenu.createInstances();
          card.addClass("init-true");
          const edit = card.find('[data-action="edit"]');
          const mark = card.find('[data-action="mark"]');
          const del = card.find('[data-action="delete"]');
          const id = card.data("id");
          const modal = $("#editAddress");
          let h;

          edit.on("click", () => {
            const r = new Ajax();
            r.data = {
              address_id: id,
              case: "get_address_form",
              action: "profile_action",
            };
            r.before = () => disableElement(card);
            r.complete = () => enableElement(card);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                modal.modal("show"),
                  modal.find(".modal-content").html(res.data),
                  fillRadio("address_type"),
                  Form({
                    modal: modal,
                    event: "update",
                    address_id: id,
                    successEvent: function (res) {
                      res = $(res.data);
                      h = card.hasClass("success-active");
                      card.replaceWith(res);
                      R();
                      cl(R);
                      action == "profile_action" ||
                        (h && res.addClass("success-active"));
                    },
                  });
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.send();
          });

          mark.on("click", () => {
            const r = new Ajax();
            r.data = {
              address_id: id,
              case: "mark_address_primary",
              action: "profile_action",
            };
            r.before = () => disableElement(card);
            r.complete = () => enableElement(card);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message),
                  res.pid &&
                    $(`.address-card[data-id=${res.pid}]`).replaceWith(
                      res.pdata
                    ),
                  card.replaceWith(res.data),
                  R();
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.send();
          });

          del.on("click", () => {
            const r = new Ajax();
            r.data = {
              address_id: id,
              case: "delete_address",
              action: "profile_action",
            };
            r.before = () => disableElement(card);
            r.complete = () => enableElement(card);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message), remove(card);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            const c = new Confirm();
            c.ok = () => r.send();
            c.show();
          });
        });
      };
      R();
    },
    Setting: function () {
      const profile_details_form = $("#profile_details_form");
      const F = new FormValidate(profile_details_form, {
        first_name: {
          alphabet: {
            text: "First name must consist of alphabets and spaces only",
          },
          max: {
            max: 20,
            text: "Maximum 20 letters are allowed",
          },
        },
        last_name: {
          alphabet: {
            text: "Latst name must consist of alphabets and spaces only",
          },
          max: {
            max: 20,
            text: "Maximum 20 letters are allowed",
          },
        },
        contact_number: {
          mobileNumber: {
            text: "Contact Number is not valid",
          },
        },
        contact_email: {
          email: { text: "The value is not a valid email address" },
        },
      });
      const fe = new FormEdit();
      fe.form = profile_details_form;
      fe.edit = $('[type="edit"][data-form="profile_details_form"]');
      fe.init();
      F.onValidate = () => {
        const r = new Ajax();
        r.data =
          profile_details_form.serialize() +
          formString({
            case: "update_profile_details",
            action: "profile_action",
          });
        r.before = () => disableElement(profile_details_form, 2);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message);
            fe.start();
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.complete = () => enableElement(profile_details_form);
        r.send();
      };

      //Profile Image Change
      const profileContainer = $("#profileContainer");
      const imageContainer = profileContainer.find("img");
      const progress = profileContainer.find(".profile-progress");
      const avatar_image_id = profileContainer.find(
        "input[name=avatar_image_id]"
      );
      const inputChooser = profileContainer.find("input[type=file]");
      const removeBtn = profileContainer.find(
        "[data-lx-image-input-action=remove]"
      );

      removeBtn.on("click", () => removeProfile());

      inputChooser.on("change", (e) => {
        const u = new ImageUpload(e.target);
        u.name = "image";
        u.data = {
          type: "image",
          action: "file_upload",
        };
        u.xhr = (evt) => {
          let percentComplete = (evt.loaded / evt.total) * 100;
          percentComplete = parseInt(percentComplete);
          profileContainer.addClass("uploading");
          progress.css({
            "--value": percentComplete,
          });
        };
        u.success = (res) => {
          try {
            res = JSON.parse(res);
            let image_id = res.file_id;
            let image_src = res.file_url;
            imageContainer.attr("src", image_src);
            avatar_image_id.val(image_id);
            profileContainer.removeClass("image-input-changed");
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        u.complete = () => profileContainer.removeClass("uploading");
        u.upload();
      });

      const removeProfile = () => {
        const r = new Ajax();
        r.data = {
          remove_profile: 1,
          case: "remove_profile",
          action: "profile_action",
        };
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            let image_id = res.image_id;
            let image_src = res.image_src;
            imageContainer.attr("src", image_src);
            avatar_image_id.val(image_id);
            profileContainer.addClass("image-input-changed");
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      };

      //Change password
      const login_change_password = $("#login_change_password");
      const signin_password = $("#signin_password");
      const signin_password_edit = $("#signin_password_edit");
      const password_cancel = $("#password_cancel");

      login_change_password
        .find("button")
        .on("click", () => toggleChangePassword());
      password_cancel.on("click", () => toggleChangePassword());

      const toggleChangePassword = () => {
        signin_password.toggleClass("d-none"),
          signin_password_edit.toggleClass("d-none"),
          login_change_password.toggleClass("d-none");
      };

      const changePasswordForm = $("#changePasswordForm");
      const R = new FormValidate(changePasswordForm, {
        new_password: {
          equalTo: {
            field: "confirm_password",
            text: "New password and its confirm are not the same",
          },
          unEqual: {
            field: "current_password",
            text: "New password must not be current password",
          },
        },
        confirm_password: {
          equalTo: {
            field: "new_password",
            text: "New password and its confirm are not the same",
          },
        },
      });
      R.elements.new_password.element.on("input", () => {
        R.validateField("confirm_password");
        R.validateField("current_password");
      });
      R.elements.confirm_password.element.on("input", () => {
        R.validateField("new_password");
      });
      R.onValidate = () => {
        const r = new Ajax();
        r.data =
          changePasswordForm.serialize() +
          formString({
            case: "change_password",
            action: "profile_action",
          });
        r.before = () => disableElement(changePasswordForm);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            toggleChangePassword();
            sweetAlert("success", res.message);
            resetForm(changePasswordForm);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.complete = () => enableElement(changePasswordForm);
        r.send();
      };

      //Add password

      const add_password_button = $("#add_password_button");
      const add_password_edit = $("#add_password_edit");
      const add_password_cancel = $("#add_password_cancel");

      add_password_button.find("button").on("click", () => toggleAddPassword());
      add_password_cancel.on("click", () => toggleAddPassword());
      const toggleAddPassword = () => {
        signin_password.toggleClass("d-none"),
          add_password_edit.toggleClass("d-none"),
          add_password_button.toggleClass("d-none");
      };

      const add_password_form = $("#add_password_form");
      const S = new FormValidate(add_password_form, {
        password: {
          equalTo: {
            field: "confirm_password",
            text: "Password and its confirm are not the same",
          },
        },
        confirm_password: {
          equalTo: {
            field: "password",
            text: "Password and its confirm are not the same",
          },
        },
      });
      S.elements.password.element.on("input", () =>
        S.validateField("confirm_password")
      );
      S.elements.confirm_password.element.on("input", () =>
        S.validateField("password")
      );

      S.onValidate = () => {
        const r = new Ajax();
        r.data =
          add_password_form.serialize() +
          formString({
            case: "add_password",
            action: "profile_action",
          });
        r.before = () => disableElement(add_password_form);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            add_password_cancel.trigger("click");
            sweetAlert("success", res.message);
            locateTo(undefined, 1000);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.complete = () => enableElement(add_password_form);
        r.send();
      };

      // Add 2 Step Verification
      const enableVerification = $("#enableVerification");
      enableVerification.on("click", () =>
        sendVerification(1, enableVerification)
      );
      const sendVerification = (s, b) => {
        const r = new Ajax();
        r.data = {
          code: 1,
          case: "twoStepVerificationCodeConfirm",
          action: "profile_action",
        };
        r.before = () => disableElement(b);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            if (s == 1) {
              $("#email_sent_to").html(res.email_sent_to);
              addVerificationEvent(res.header);
            } else {
              $("#email_sent_to").html(res.email_sent_to);
              sweetAlert("success", res.message);
            }
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.complete = () => enableElement(b);
        r.send();
      };

      const authentication_modal = $("#authentication_modal");
      const authentication_modal_form = authentication_modal.find("form");

      const addVerificationEvent = (headerText) => {
        resetForm(authentication_modal_form);
        authentication_modal.modal("show");
        authentication_modal.find(".modal-header").find("h2").html(headerText);
        if (authentication_modal_form.hasClass("init")) return false;
        authentication_modal_form.addClass("init");

        $("#resendOtp").on("click", (e) => {
          resetForm(authentication_modal_form);
          sendVerification(2, $(e.target).parent());
        });
        initOtpPaste();
        const F = new FormValidate(authentication_modal_form);
        let sending = false;
        F.onValidate = () => {
          const r = new Ajax();
          r.data =
            authentication_modal_form.serialize() +
            formString({
              case: "enable_login_verification",
              action: "profile_action",
            });
          r.before = () => {
            sending = true;
            disableElement(authentication_modal_form, 2);
          };
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              enableVerification.html(res.btn_text);
              authentication_modal.modal("hide");
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.complete = () => {
            sending = false;
            enableElement(authentication_modal_form);
          };
          sending || r.send();
        };
      };
    },
  };

  _.userLoginSessionTbl = function () {
    const t = $("#loginSessionTbl").DataTable({
      processing: true,
      serverSide: true,
      order: [[4, "desc"]],
      columns: [
        {
          data: null,
          orderable: false,
          render: function (data, type, row, meta) {
            return meta.row + meta.settings._iDisplayStart + 1;
          },
        },
        {
          data: "0",
        },
        {
          data: "1",
        },
        {
          data: "2",
        },
        {
          data: "3",
        },
        {
          data: "4",
        },
        {
          data: "5",
        },
      ],
      ajax: {
        url: ajax_url.v,
        type: "POST",
        data: {
          action: "loadTblData",
          case: "userLoginSessionTbl",
        },
      },
    });
    t.on("draw", () => r());

    const r = () => {
      select2();
      $(".removeUserSession").on("click", (e) => {
        const t = $(e.currentTarget);
        const id = t.data("id");
        const c = new Confirm();
        c.text = "Are you sure want to logout from this device?";
        c.okText = "Yes, Logout";
        c.ok = () => {
          const r = new Ajax();
          r.data = {
            session_id: id,
            case: "remove_user_session",
            action: "profile_action",
          };
          r.before = () => disableElement(t.closest("tr"));
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              const m = res.message;
              const b = t.closest("tr").find(".badge");

              b.removeClass("badge-light-success")
                .addClass("badge-light-danger")
                .html("expired");
              t.after("<span>Logged Out</span>");
              t.hide();
              sweetAlert("success", m);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.complete = () => enableElement(t.closest("tr"));
          r.send();
        };
        c.show();
      });
    };

    $("#log_out_all_sessions").on("click", (e) => {
      const b = $(e.currentTarget);
      const r = new Ajax();
      r.data = {
        event: 1,
        case: "remove_all_session",
        action: "profile_action",
      };
      r.before = () => disableBtn(b);
      r.success = (res) => {
        try {
          res = JSON.parse(res);
          sweetAlert("success", res.message);
          t.ajax.reload();
        } catch (error) {
          cl(error);
          sweetAlert("error", res);
        }
      };
      r.complete = () => enableBtn(b);

      const c = new Confirm();
      c.ok = () => r.send();
      c.okText = "Yes,Logout";
      c.show();
    });
  };

  _.Admin = {
    Transactions: function () {
      const t = $("#data_table").DataTable({
        processing: true,
        serverSide: true,
        order: [[6, "desc"]],
        columns: [
          {
            data: null,
            orderable: false,
            sortable: false,
            render: function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            },
          },
          {
            data: "transaction_id",
          },
          {
            data: "amount",
          },
          {
            data: "txn_charge",
          },
          {
            data: "net_amount",
          },
          {
            data: "details",
          },
          {
            data: "date",
          },
          {
            data: "last_updated",
          },
          {
            data: "status",
          },
        ],
        ajax: {
          url: ajax_url.a,
          type: "POST",
          data: {
            action: "loadTblData",
            case: "transactions_TBl",
          },
        },
      });
      t.on("draw", () => {
        select2(), LXApp.initBootstrapTooltips();
      });
    },
    Service: {
      init: () => {
        $("body").on("click", "[data-action=delete]", (e) => {
          e = $(e.currentTarget);
          removeCourier(e);
        });

        $("body").on("click", "[data-action=edit]", (e) => {
          e = $(e.currentTarget);
          edit(e);
        });

        const modal = $("#addService");
        const form = modal.find("form");
        const F = new FormValidate(form, {
          service_charge: {
            number: {
              text: "Service Charge must consist of numbers only",
            },
          },
        });
        F.onValidate = () => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data =
            form.serialize() +
            formString({
              case: "create_service",
              action: "ecommerce_service_actions",
            });
          r.before = () => disableElement(form, 2);
          r.complete = () => enableElement(form);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message),
                $("#data").html(res.data),
                modal.modal("hide"),
                resetForm(form);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        };

        const edit = (w) => {
          const editForm = w.siblings("form");
          const modal = $("#editService");
          modal.modal("show");
          const b = modal.find(".modal-body");
          b.html("");
          editForm.appendTo(b);
          modal.modal("show");
          const form = modal.find("form");
          form.removeClass("d-none");

          select2();
          fillSelect();

          const F = new FormValidate(form, {
            service_charge: {
              number: {
                text: "Service Charge must consist of numbers only",
              },
            },
          });
          F.onValidate = () => {
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data =
              form.serialize() +
              formString({
                case: "edit_service",
                action: "ecommerce_service_actions",
              });
            r.before = () => disableElement(form, 2);
            r.complete = () => enableElement(form);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message),
                  $("#data").html(res.data),
                  modal.modal("hide");
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.send();
          };
        };

        const removeCourier = (t) => {
          const tr = t.closest("tr");
          const id = t.data("id");
          const c = new Confirm();
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data = {
            service_id: id,
            case: "delete_service",
            action: "ecommerce_service_actions",
          };
          r.before = () => disableElement(tr);
          r.complete = () => enableElement(tr);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              remove(tr),
                sweetAlert("success", res.message),
                $("#data").html(res.data);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          c.ok = () => r.send();
          c.show();
        };
      },
    },
    Courier: {
      init: function () {
        const modal = $("#addCourier");
        const t = modal.find("form");

        const F = new FormValidate(t, {
          url: {
            url: {
              text: "Courier Url is not valid",
            },
          },
        });
        F.onValidate = () => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data =
            t.serialize() +
            formString({
              case: "create_courier",
              action: "ecommerce_courier_actions",
            });
          r.before = () => disableElement(t, 2);
          r.complete = () => enableElement(t);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message),
                $("#data").html(res.data),
                modal.modal("hide"),
                resetForm(t);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        };

        const edit = (w) => {
          const id = w.data("id");
          const name = w.data("name");
          const url = w.data("url");

          const form = $(`<form novalidate="" >
                            <div class="fv-row mb-7">
                                <label class="required form-label mb-2">Courier Name</label>
                                <input required maxlength="100" type="text" class="form-control form-control-solid" name="name" value="${name}">
                                <div class="invalid-feedback" >Courier Name is required</div>
                            </div>

                            <div class="fv-row mb-7">
                                <label class="required form-label mb-2">Courier Url</label>
                                <input required maxlength="1000" type="text" class="form-control form-control-solid" name="url" value="${url}">
                                <div class="invalid-feedback" >Courier Url is required</div>
                            </div>

                            <div class="justify-right">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>`);

          const modal = $("#editCourier");
          modal.modal("show");
          modal.find(".modal-body").html(form);

          const t = modal.find("form");
          const F = new FormValidate(t, {
            url: {
              url: {
                text: "Courier Url is not valid",
              },
            },
          });
          F.onValidate = () => {
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data =
              t.serialize() +
              formString({
                courier_id: id,
                case: "edit_courier",
                action: "ecommerce_courier_actions",
              });
            r.before = () => disableElement(t, 2);
            r.complete = () => enableElement(t);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message),
                  $("#data").html(res.data),
                  modal.modal("hide"),
                  resetForm(t);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.send();
          };
        };

        const removeCourier = (t) => {
          const tr = t.closest("tr");
          const id = t.data("id");
          const c = new Confirm();
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data = {
            courier_id: id,
            case: "delete_courier",
            action: "ecommerce_courier_actions",
          };
          r.before = () => disableElement(tr);
          r.complete = () => enableElement(tr);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              remove(tr),
                sweetAlert("success", res.message),
                $("#data").html(res.data);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          c.ok = () => r.send();
          c.show();
        };

        $("body").on("click", "[data-action=delete]", (e) => {
          e = $(e.currentTarget);
          removeCourier(e);
        });

        $("body").on("click", "[data-action=edit]", (e) => {
          e = $(e.currentTarget);
          edit(e);
        });
      },
    },
    Category: function () {
      const categoryGroup = $(".category-group");
      const createInstances = () => {
        categoryGroup.find(".category-list").each((f, x) => {
          $(x).hasClass("data-init-true") || createEvent(x);
        });
        categoryGroup.find(".category-progress").each((f, x) => {
          $(x).hasClass("data-init-true") || childEvent(x);
        });
        LXMenu.createInstances();
      };

      let lastActiveCategory = {};
      const createEvent = (x) => {
        const currentCategory = $(x);

        const parentElement = currentCategory.closest("[data-level]");
        const level = parentElement.data("level");
        let nextParentElement = categoryGroup.find(
          `[data-level=${parseInt(level) + 1}]`
        );
        if (parseInt(level) < 3) {
          if (!nextParentElement.length) {
            nextParentElement = $(
              `<div data-level="${parseInt(level) + 1}" ><ul></ul></div>`
            );
          }
        }
        parentElement.after(nextParentElement);

        const drop = currentCategory.find('[data-lx-menu="true"]');
        const textContainer = currentCategory.find(".text-container");
        const edit = drop.find("#edit");
        const create_child = drop.find("#create_child");
        const create_sibling = drop.find("#create_sibling");
        const add_details = drop.find("#add_details");
        const delete_listings = drop.find("#delete_listings");
        const archive = drop.find("#archive");
        const category_id = currentCategory.data("id");
        const parent_category_id = currentCategory.data("pid");
        const form = currentCategory.find("form");
        const btn = form.find("#submit");
        currentCategory.addClass("data-init-true");

        currentCategory.on("click", (e) => {
          let is_active = currentCategory.hasClass("active");
          parentElement.find(".category-list").removeClass("active");
          categoryGroup.find("[data-level]").hide();
          const clevel = parseInt(level) + 1;
          for (let i = 0; i <= clevel; i++) {
            let level_group = categoryGroup.find(`[data-level=${i}]`);
            $(level_group).show();
          }

          categoryGroup
            .find(`[data-level=${clevel}]`)
            .find(".category-list")
            .removeClass("active")
            .addClass("d-none");

          categoryGroup.find(`[data-pid=${category_id}]`).removeClass("d-none");
          currentCategory.removeClass("d-none").addClass("active");

          if (!currentCategory.find(".drop-container").has(e.target).length) {
            categoryGroup[0].scrollLeft = categoryGroup[0].scrollWidth;
          }

          lastActiveCategory[0] == currentCategory[0] ||
            $("#updateDataWrapper").html("");
          lastActiveCategory = currentCategory;
          if (currentCategory.hasClass("has-details") && !is_active)
            getDetails();
        });

        const toggleEdit = () => {
          textContainer.find("> span").toggleClass("d-none");
          textContainer.find("form").toggleClass("d-none");
        };

        const createCatForm = (id) => {
          return `<li class="category-progress active align-justify-between">
                            <form novalidate="novalidate" class="w-100">
                                <input type="hidden" name="parent_id" value="${id}">
                                <div class="fv-row">
                                    <div class="input-group">
                                        <span id="removeList" class="input-group-text bg-danger"><i class="text-white fas fa-minus"></i></span>
                                        <input required name="category" type="text" class="form-control form-control-solid">
                                        <button type="submit" class="btn input-group-text bg-success"><i class="text-white fas fa-check"></i></button>
                                    </div>
                                </div>
                            </form>
                            </li>`;
        };

        const fill = (text) => {
          textContainer.find("> span").html(text);
          textContainer.find("form").find("input").val(text);
        };
        const getDetails = (e) => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data = {
            category_id: category_id,
            action: "ecommerce_category_actions",
            case: "fetch_details",
          };

          r.before = () => disableElement(currentCategory);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              currentCategory.addClass("has-details");
              e && (e.innerHTML = "Show details");
              this.detailsFunctions(category_id, res);
            } catch (error) {
              cl(error);
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.complete = () => enableElement(currentCategory);
          r.send();
        };

        const F = new FormValidate(form);
        F.onValidate = () => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data =
            form.serialize() +
            formString({
              category_id: category_id,
              action: "ecommerce_category_actions",
              case: "edit_category",
            });
          r.before = () => disableElement(btn);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              toggleEdit();
              fill(res.category);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.complete = () => enableBtn(btn);
          r.send();
        };

        edit.on("click", () => toggleEdit());

        create_sibling.on("click", () => {
          currentCategory.after(createCatForm(parent_category_id));
          createInstances();
        });

        create_child.on("click", () => {
          nextParentElement.find("ul").append(createCatForm(category_id));
          createInstances();
        });

        add_details.on("click", (e) => {
          getDetails(e.currentTarget);
        });

        archive.on("click", () => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data = {
            category_id: category_id,
            action: "ecommerce_category_actions",
            case: "archive_category",
          };

          r.before = () => {
            disableElement(currentCategory);
            currentCategory.find(".drop-container").hide();
          };

          r.success = (res) => {
            try {
              res = JSON.parse(res);
              const $message = res.message;
              sweetAlert("success", $message);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };

          r.complete = () => {
            enableElement(currentCategory);
            currentCategory.find(".drop-container").show();
          };

          const c = new Confirm();
          c.ok = () => r.send();
          c.iconColor = "error";
          c.textClass = "text-danger";
          c.headClass = "text-danger";
          c.text =
            "New listings will not be available more, but all current listings will be remain unchanged.";
          c.okText = "Yes, Close Category";
          c.show();
        });

        delete_listings.on("click", () => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data = {
            category_id: category_id,
            action: "ecommerce_category_actions",
            case: "reject_listings",
          };

          r.before = () => {
            disableElement(currentCategory);
            currentCategory.find(".drop-container").hide();
          };

          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              remove(currentCategory);
              remove($(`.category-list[data-pid="${category_id}"]`));
              $("#updateDataWrapper").html("");
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };

          r.complete = () => {
            enableElement(currentCategory);
            currentCategory.find(".drop-container").show();
          };

          const c = new Confirm();
          c.ok = () => r.send();
          c.iconColor = "error";
          c.textClass = "text-danger";
          c.headClass = "text-danger";
          c.text =
            "All listings in this category will be removed and no longer available for users & sellers.";
          c.okText = "Yes, Delete";
          c.show();
        });
      };
      const childEvent = (f) => {
        const list = $(f);
        const removeList = list.find("#removeList");
        const form = list.find("form");
        list.addClass("data-init-true");

        removeList.on("click", () => {
          list.remove();
        });
        const setView = ($content) => {
          list.after($content);
          list.next().removeClass("d-none");
          list.remove();
        };

        const F = new FormValidate(form);
        F.onValidate = () => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data =
            form.serialize() +
            formString({
              action: "ecommerce_category_actions",
              case: "create_category",
            });
          r.before = () => disableElement(form);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              setView(res.category_list);
              createInstances();
            } catch (error) {
              cl(error);
              weetAlert("error", res);
            }
          };
          r.complete = () => enableElement(form);
          r.send();
        };
      };
      createInstances();
      $("#apply_changes").on("click", (e) => {
        const r = new Ajax();
        r.url = ajax_url.a;
        r.data = {
          case: "apply_category_changes",
          action: "ecommerce_category_actions",
        };
        r.before = () => disableBtn(e.currentTarget);
        r.complete = () => enableBtn(e.currentTarget);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message), locateTo(undefined, 1000);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      });
    },
    detailsFunctions: function (cid, res) {
      $("body").on("change", 'select[name="select_id"]', (e) => {
        const target = $(e.currentTarget)
          .parent()
          .parent()
          .find("#customSelectWrapper");

        const selectPreview = $(e.currentTarget)
          .parent()
          .parent()
          .find("#selectPreview");

        if (e.target.value === "custom") {
          target.show(),
            selectPreview.hide(),
            is_empty(target.html()) && this.createSelectLibrary(target);
        } else if (!is_empty(e.target.value)) {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data = {
            select_id: e.target.value,
            case: "get_select_options",
            action: "ecommerce_select_actions",
          };
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              selectPreview.html(res.preview);
              select2();
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
          target.hide(), selectPreview.show();
        } else {
          selectPreview.hide(), target.hide();
        }
      });

      let z = res.data;
      try {
        if (is_empty(z)) throw new Error("");
        z = JSON.parse(z);
      } catch (error) {
        cl(error);
        z = {
          images: [],
          variations: {},
          details: {},
          deldetails: [],
        };
      }
      z.variations.length === 0 && (z.variations = {});
      z.maxImages = z.maxImages || 8;
      z.currentImages = z.currentImages || 0;

      const W = $("#updateDataWrapper");
      W.html(res.card);
      LXMenu.createInstances();
      LXApp.initBootstrapTooltips();
      LXApp.initBootstrapPopovers();

      $("#verifyCategory").on("click", (e) => {
        const aj = {
          data: JSON.stringify(z),
          category_id: cid,
          case: "verify_category",
          action: "ecommerce_category_actions",
        };
        const t = $(e.currentTarget);
        const r = new Ajax();
        r.url = ajax_url.a;
        r.data = aj;
        r.before = () => disableBtn(t);
        r.complete = () => enableBtn(t);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message), locateTo(undefined, 1000);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      });

      {
        const chooser = $(
          `<input class="sr-only" accept=".png, .jpg, .jpeg,.webp" multiple="" type="file" name="images">`
        );
        const u = W.find('[data-category-image="true"]');
        u.before(chooser);
        u.on("click", () => chooser.trigger("click"));

        $("#catImages").on(
          "click",
          '[data-category-image-delete="true"]',
          (e) => {
            const t = $(e.currentTarget);
            const fileId = t.data("id").toString();
            z.images = z.images.filter((e) => e !== fileId);
            t.parent().remove();
            dec();
          }
        );

        const check = () => {
          z.currentImages == z.maxImages
            ? u.addClass("d-none")
            : u.removeClass("d-none");
        };
        check();

        const inc = () => {
          z.currentImages += 1;
          check();
        };

        const dec = () => {
          (z.currentImages -= 1), check();
        };

        chooser.on("change", (e) => {
          const t = e.target;
          const files = t.files;
          const required_files = z.maxImages - z.currentImages;

          for (var i = 0; i < files.length; i++) {
            if (i < required_files) {
              const preloader =
                $(`<div class="me-4 position-relative cursor-pointer min-w-80px justify-align-center mb-2 bg-light hover h-100px">
                                                    <div class="bottom-inherit image-upload-progress top-0">
                                                        <div class="progress-bar h-3px"></div>
                                                    </div>
                                                    <span class="svg-icon svg-icon-muted svg-icon-4x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <rect opacity="0.5" x="11" y="18" width="12" height="2" rx="1" transform="rotate(-90 11 18)" fill="currentColor"></rect>
                                                            <rect x="6" y="11" width="12" height="2" rx="1" fill="currentColor"></rect>
                                                        </svg></span>
                                                </div>`);
              u.before(preloader);

              const create = (src, id) => {
                const del = $(
                  `<div data-category-image-delete="true" data-id="${id}" class="delete-alt"><i class="fas fa-times"></i></div>`
                );
                preloader.html(`<div class="bottom-inherit image-upload-progress top-0">
                                                            <div class="progress-bar h-3px"></div>
                                                        </div><img class="img-fluid mh-100" src="${src}" >`);
                preloader.append(del);
                z.images.push(id);
              };
              inc();

              const p = preloader.find(".image-upload-progress");
              const r = new ImageUpload(e.currentTarget);
              r.url = ajax_url.a;
              r.fileIndex = i;
              r.data = {
                type: "image",
                action: "file_upload",
              };
              r.xhr = (evt) => {
                let c = (evt.loaded / evt.total) * 100;
                c = parseInt(c);
                p.show()
                  .find(".progress-bar")
                  .width(c + "%");
              };
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  create(res.file_url, res.file_id);
                } catch (error) {
                  cl(error);
                  sweetAlert("error", res);
                }
              };
              r.error = (e) => {
                dec();
                preloader.remove();
              };
              r.complete = () => p.hide().find(".progress-bar").width(0);
              r.upload();
            }
          }
        });
      }

      const addDetailsModal = $("#addDetailsModal");
      const sel = (n, t) => {
        t.value == "select"
          ? (n.find("#selectIdWrapper").show(),
            n.find('[name="select_id"]').attr("required", true))
          : (n.find("#selectIdWrapper").hide(),
            n.find('[name="select_id"]').attr("required", false));
      };

      const form = addDetailsModal.find("form");
      sel(form, form.find("select[name=option_type]")[0]);

      form.find("select[name=option_type]").on("change", (t) => {
        $(t).hasClass("init") || ($(t).addClass("init"), sel(form, t.target));
      });
      select2();
      form.off();

      const F = new FormValidate(form);
      F.onValidate = () => {
        let detailsArray = form.serializeArray();
        let details = {};
        addDetailsModal.modal("hide");
        detailsArray.forEach((e) => {
          details[e.name] = e.value;
        });
        const selectOptions = [];
        form.find("[name=selectOptions]").each((f, e) => {
          selectOptions.push(e.value);
        });
        details.selectOptions = selectOptions;
        addUpdateDetails(details);
        resetForm(form);
        fillSelect();
        form.find("#customSelectWrapper").html("");
      };

      const addUpdateDetails = (details) => {
        const action = is_empty(details.detail_id) ? "create" : "update";
        const id = is_empty(details.detail_id) ? Date.now() : details.detail_id;

        const element = $(`<tr data-id="detail_${id}" >
                            <td class="text-capitalize">${details.mandatory}</td>
                            <td>${details.option_text}</td>
                            <td class="text-capitalize">${details.option_type}</td>
                            <td class="text-capitalize">${details.filter}</td>
                            <td><div class="d-flex">
                              <button data-id="${id}" data-action="editCatDetail" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                              <span class="svg-icon svg-icon-3">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                      <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                      <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                  </svg>
                              </span>
                                  </button>
                              <button data-id="${id}" data-action="deleteCatDetail" class="btn ms-2 btn-icon btn-bg-light btn-active-color-primary btn-sm">
                                  <span class="svg-icon svg-icon-3">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                          <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="currentColor"></path>
                                          <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="currentColor"></path>
                                          <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="currentColor"></path>
                                      </svg>
                                  </span>
                              </button>
                              </div></td>
                       </tr>`);

        switch (action) {
          case "create":
            $("#pro_details_tbl").find("tbody").append(element);
            z.details[id] = details;
            break;

          case "update":
            $("#pro_details_tbl")
              .find("tbody")
              .find(`tr[data-id=detail_${id}]`)
              .replaceWith(element);
            z.details[id] = details;
            break;
        }
      };

      $("#pro_details_tbl").on(
        "click",
        '[data-action="deleteCatDetail"]',
        (e) => {
          const c = new Confirm();
          c.ok = () => {
            const id = $(e.currentTarget).data("id");
            const element = $("#pro_details_tbl")
              .find("tbody")
              .find(`tr[data-id=detail_${id}]`);
            element.remove();
            delete z.details[id];
            z.deldetails.push(id);
          };
          c.show();
        }
      );

      $("#pro_details_tbl").on(
        "click",
        '[data-action="editCatDetail"]',
        (e) => {
          const btn = $(e.currentTarget);
          const modal = $("#editDetailsModal");
          modal.modal("show");
          const id = btn.data("id");
          const details = z.details[id];
          const selectOptions = details.selectOptions;
          const select_id = details.select_id;

          let selectOptionsRepeater = "";
          let customSelectWrapper = "";
          if (select_id == "custom") {
            selectOptions.forEach((e) => {
              selectOptionsRepeater += `<div data-repeater-item="" class="form-group d-flex flex-wrap gap-5">
                                      <input value="${e}" type="text" class="data-heading form-control mw-100 w-300px" placeholder="Value" />
                                      <button type="button" data-repeater-delete="" class="btn btn-sm btn-icon btn-light-danger">
                                              <i class="fas fa-times"></i>
                                      </button>
                                </div>`;
            });
            customSelectWrapper = toSelect(selectOptions);
            customSelectWrapper = ` <div class="fv-row mb-7">
                                    <label class="required fs-6 fw-bold form-label mb-2">Custom Select Value</label>
                                   <div class="d-flex" >
                                    ${customSelectWrapper}
                                    <a id="editSelect" class="btn height-inherit btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                        <span class="svg-icon svg-icon-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                            </svg>
                        </span>
                    </a></div>
                                </div>`;
          }

          const editForm =
            $(`<form class="needs-validation" default-validation novalidate >
                              <input type="hidden" class="form-control form-control-solid" name="custom_select_id" value="${details.custom_select_id}">
                             <input value="${id}" type="hidden" class="form-control form-control-solid" name="detail_id" >
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Mandatory</label>
                                <select required value="${details.mandatory}" class="form-select form-select-solid" name="mandatory" data-control="select2" data-placeholder="Select an option" data-hide-search="true" tabindex="-1" aria-hidden="true">
                                    <option></option>
                                    <option value="yes">Yes</option>
                                    <option value="no">No</option>
                                </select>
                                <div class="invalid-feedback">This field is required</div>
                            </div>
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Label</label>
                                <input required value="${details.option_text}" type="text" class="form-control form-control-solid" name="option_text" value="">
                                <div class="invalid-feedback">Label is required</div>
                                </div>
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Label Type</label>
                                <select required value="${details.option_type}" class="form-select form-select-solid" name="option_type" data-control="select2" data-placeholder="Select an option" data-hide-search="true" tabindex="-1" aria-hidden="true">
                                    <option></option>
                                    <option value="input">Input</option>
                                    <option value="select">Select</option>
                                </select>
                                <div class="invalid-feedback">Label Type is required</div>
                            </div>
                            <div id="selectIdWrapper" class="d1-none">
                                <div class="fv-row mb-7">
                                    <label class="required fs-6 fw-bold form-label mb-2">Select (dropdown) value</label>
                                    <select value="${details.select_id}" id="detailSelectLibrary" class="form-select form-select-solid" name="select_id" data-control="select2" data-placeholder="Select an option to copy value">
                                        <option></option>
                                    </select>
                                </div>
                                <div id="customSelectWrapper">${customSelectWrapper}</div>
                                 <div id="selectPreview"></div>
                            </div>

                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Filter</label>
                                <select required value="${details.filter}" class="form-select form-select-solid" name="filter" data-control="select2" data-placeholder="Select an option" data-hide-search="true" tabindex="-1" aria-hidden="true">
                                    <option></option>
                                    <option value="yes">Yes</option>
                                    <option value="no">No</option>
                                </select>
                                <div class="invalid-feedback">Filter is required</div>
                            </div>
                            <div class="text-center">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>`);

          modal.find(".modal-body").html(editForm);
          select2();
          sel(editForm, editForm.find("select[name=option_type]")[0]);
          editForm.find("select[name=option_type]").on("change", (t) => {
            sel(editForm, t.target);
          });

          const target = editForm.find("#customSelectWrapper");
          const edit = editForm.find("#editSelect");
          edit.on("click", () => {
            this.createSelectLibrary(target, selectOptionsRepeater);
          });

          const F = new FormValidate(editForm);
          F.onValidate = () => {
            let detailsArray = editForm.serializeArray();
            let details = {};
            modal.modal("hide");
            detailsArray.forEach((e) => {
              details[e.name] = e.value;
            });
            const selectOptions = [];
            editForm.find("[name=selectOptions]").each((f, e) => {
              selectOptions.push(e.value);
            });
            details.selectOptions = selectOptions;
            addUpdateDetails(details);
          };
        }
      );

      this.addVariations(cid, z);
    },
    addVariations: function (cid, z) {
      const check = () => {
        Object.keys(z.variations).length === 2
          ? $("#addVariation").hide()
          : $("#addVariation").show();
      };
      check();
      const toDetailsSelect = () => {
        const entries = Object.keys(z.details);
        let selectOptions = "<option></option>";
        entries.forEach((e) => {
          selectOptions += ` <option value="${e}" >${z.details[e].option_text}</option>`;
        });
        return selectOptions;
      };

      const Fill = (modal, id) => {
        const r = new Ajax();
        r.url = ajax_url.a;
        r.data = {
          category_id: cid,
          case: "fetch_information_select",
          action: "ecommerce_category_actions",
        };
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            modal.find("[name=select_id]").html(res.select).trigger("change"),
              fillSelect();
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };

        modal.off().on("shown.bs.modal", function () {
          r.send();
          select2();
          if (id === 1 || id === 2) {
            modal
              .find("[name=detail_id]")
              .html(toDetailsSelect())
              .trigger("change");
          }
        });
      };

      Fill($("#variationModal"), 1);
      Fill($("#editVariationModal"), 2);
      Fill($("#addDetailsModal"));
      Fill($("#editDetailsModal"));

      const addUpdateDetails = (details) => {
        const action = is_empty(details.vid) ? "create" : "update";
        const id = is_empty(details.vid) ? Date.now() : details.vid;
        const element = $(`<tr data-id="${id}" > 
                <td class="text-capitalize">${details.name}</td>
                <td class="text-capitalize">${details.type}</td>
                <td class="text-capitalize">${details.role}</td>
                <td>
                <div class="d-flex">
                        <button data-id="${id}" data-action="editCategoryVariation" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                            <span class="svg-icon svg-icon-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                    <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                </svg>
                            </span>
                        </button>
                        <button data-id="${id}" data-action="deleteCategoryVariation" class="ms-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                            <span class="svg-icon svg-icon-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="currentColor"></path>
                                    <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="currentColor"></path>
                                    <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="currentColor"></path>
                                </svg>
                            </span>
                        </button>
                    </div></td>
            </tr>`);

        switch (action) {
          case "create":
            $("#var_table").find("tbody").append(element);
            z.variations[id] = details;
            check();

            break;

          case "update":
            $("#var_table")
              .find("tbody")
              .find(`tr[data-id=${id}]`)
              .replaceWith(element);
            z.variations[id] = details;
            break;
        }
      };

      $("#var_table").on(
        "click",
        '[data-action="deleteCategoryVariation"]',
        (e) => {
          const c = new Confirm();
          c.ok = () => {
            const id = $(e.currentTarget).data("id");
            const element = $("#var_table")
              .find("tbody")
              .find(`tr[data-id=${id}]`);
            element.remove();
            delete z.variations[id];
            check();
          };
          c.show();
        }
      );

      const sel = (form, t) => {
        switch (t.value) {
          case "select":
            form.find("#selectIdWrapper").show(),
              form.find("#detailIdWrapper").hide();
            form.find('[name="select_id"]').attr("required", true);
            form.find('[name="detail_id"]').attr("required", false);

            break;
          case "image":
            form.find("#detailIdWrapper").show(),
              form.find("#selectIdWrapper").hide();
            form.find('[name="select_id"]').attr("required", false);
            form.find('[name="detail_id"]').attr("required", true);
            break;
          default:
            form.find("#detailIdWrapper").hide(),
              form.find("#selectIdWrapper").hide();
            form.find('[name="select_id"]').attr("required", false);
            form.find('[name="detail_id"]').attr("required", false);

            break;
        }
      };

      $("#var_table").on(
        "click",
        '[data-action="editCategoryVariation"]',
        (e) => {
          const btn = $(e.currentTarget);
          const modal = $("#editVariationModal");
          modal.modal("show");
          const id = btn.data("id");
          const details = z.variations[id];
          const selectOptions = details.selectOptions;
          const select_id = details.select_id;

          let selectOptionsRepeater = "";
          let customSelectWrapper = "";
          if (select_id == "custom") {
            selectOptions.forEach((e) => {
              selectOptionsRepeater += `<div data-repeater-item="" class="form-group d-flex flex-wrap gap-5">
                                      <input value="${e}" type="text" class="data-heading form-control mw-100 w-300px" placeholder="Value" />
                                      <button type="button" data-repeater-delete="" class="btn btn-sm btn-icon btn-light-danger">
                                              <i class="fas fa-times"></i>
                                      </button>
                                </div>`;
            });
            customSelectWrapper = toSelect(selectOptions);
            customSelectWrapper = ` <div class="fv-row mb-7">
                                    <label class="required fs-6 fw-bold form-label mb-2">Custom Select Value</label>
                                   <div class="d-flex" >
                                    ${customSelectWrapper}
                                    <a id="editSelect" class="btn height-inherit btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                        <span class="svg-icon svg-icon-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                            </svg>
                        </span>
                    </a></div></div>`;
          }

          const editForm =
            $(` <form class="needs-validation" default-validation novalidate >
              <input value="${id}" type="hidden" class="form-control form-control-solid" name="vid" >
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Variation Name</label>
                                   <input type="hidden" class="form-control form-control-solid" name="custom_select_id" value="${details.custom_select_id}">
                                <input required type="text" class="form-control form-control-solid" name="name" value="${details.name}">
                            </div>
                            <div class="fv-row mb-7">
                                <label class="required fs-6 form-label mb-2">Variation Type</label>
                                <select required value="${details.type}" class="form-select form-select-solid" name="type" data-control="select2" data-placeholder="Select an option" data-hide-search="true">
                                    <option></option>
                                    <option value="input">Input (custom text) </option>
                                    <option value="select">Select (dropdown) </option>
                                    <option value="image">Image (choose image) </option>
                                </select>
                            </div>
                            <div id="detailIdWrapper" class="fv-row d1-none mb-7">
                                <label class="fs-6 fw-bold form-label mb-2">Detail Id</label>
                                <select value="${details.detail_id}" class="form-select form-select-solid" name="detail_id" data-control="select2" data-placeholder="Select an option">
                                    <option></option>
                                </select>
                            </div>
                            <div id="selectIdWrapper" class="d1-none">
                                <div class="fv-row mb-7">
                                    <label class="required fs-6 fw-bold form-label mb-2">Select (dropdown) value</label>
                                    <select value="${details.select_id}" id="selectLibrary" class="form-select form-select-solid" name="select_id" data-control="select2" data-placeholder="Select an option to copy value">
                                        <option></option>
                                    </select>
                                </div>
                                <div id="customSelectWrapper">${customSelectWrapper}</div>
                                <div id="selectPreview"></div>
                            </div>
                            <div class="fv-row mb-7">
                                <label class="required fs-6 form-label mb-2">Role Type</label>
                                <select required value="${details.role}" class="form-select form-select-solid" name="role" data-control="select2" data-placeholder="Select an option " data-hide-search="true">
                                    <option></option>
                                    <option value="parent">Parent</option>
                                    <option value="child">Child</option>
                                </select>
                            </div>
                            <div class="text-center">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>`);

          modal.find(".modal-body").html(editForm);
          select2();
          sel(editForm, editForm.find("select[name=type]")[0]);
          editForm.find("select[name=type]").on("change", (t) => {
            sel(editForm, t.target);
          });

          const target = editForm.find("#customSelectWrapper");
          const edit = editForm.find("#editSelect");
          edit.on("click", () => {
            this.createSelectLibrary(target, selectOptionsRepeater);
          });

          const F = new FormValidate(editForm);
          F.onValidate = () => {
            const role = editForm.find('[name="role"]').val();
            const type = editForm.find("select[name=type]").val();

            let detailsArray = editForm.serializeArray();
            let details = {};
            modal.modal("hide");
            detailsArray.forEach((e) => {
              details[e.name] = e.value;
            });
            const selectOptions = [];
            editForm.find("[name=selectOptions]").each((f, e) => {
              selectOptions.push(e.value);
            });
            details.selectOptions = selectOptions;
            addUpdateDetails(details);
          };
        }
      );

      const modal = $("#variationModal");
      const form = modal.find("form");
      form.off();
      const F = new FormValidate(form);
      F.onValidate = () => {
        let detailsArray = form.serializeArray();
        let details = {};
        modal.modal("hide");
        detailsArray.forEach((e) => {
          details[e.name] = e.value;
        });
        const selectOptions = [];
        form.find("[name=selectOptions]").each((f, e) => {
          selectOptions.push(e.value);
        });
        details.selectOptions = selectOptions;
        addUpdateDetails(details);
        resetForm(form);
        form.find("#customSelectWrapper").html("");
      };

      sel(form, form.find("select[name=type]")[0]);
      form.find("select[name=type]").on("change", (t) => {
        sel(form, t.target);
      });
    },
    createSelectLibrary: (target, lists) => {
      const modal = $("#addSelectLibraryModal");
      const body = modal.find(".modal-body");
      modal.modal("show");
      const form = $(`<form novalidate >
                            <div>
                                <label class="form-label">Create Select Value </label>
                                <div id="repeater">
                                    <div class="form-group">
                                        <div data-repeater-list="repeater" class="d-flex flex-column gap-3">
                                            <div data-repeater-item="" class="form-group d-flex flex-wrap gap-5">
                                                <input required type="text" class="data-heading form-control mw-100 w-300px" placeholder="Value" />
                                                <button type="button" data-repeater-delete="" class="btn btn-sm btn-icon btn-light-danger">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group mt-5">
                                        <button data-bs-trigger="hover" data-bs-toggle="tooltip" data-bs-original-title="Remove all input boxes" type="button" data-repeater-remove="" class="btn btn-sm btn-light-danger">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                        <button type="button" data-repeater-create="" class="btn btn-sm btn-light-primary">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>`);
      body.html(form);
      let initEmpty = 0;
      lists &&
        ((initEmpty = 1),
        form.find('[data-repeater-list="repeater"]').append(lists));
      form.find("[data-repeater-remove]").on("click", () => {
        const c = new Confirm();
        c.ok = () => {
          form.find("[data-repeater-item]").remove();
        };
        c.text = "All custom select values will be deleted.";
        c.show();
      });

      modal.find("#repeater").repeater({
        initEmpty: initEmpty,
        show: function () {
          $(this).slideDown();
        },
        hide: function (e) {
          $(this).slideUp(e);
        },
      });

      const F = new FormValidate(form);
      F.onValidate = () => {
        let trueOptions = 0;
        let selectElement = $(
          `<select class="form-select form-select-solid" data-placeholder="Select" data-hide-search="true" data-control="select2" ></select>`
        );
        target.html("");

        form.find("[data-repeater-item]").each((f, e) => {
          const selectOption = $(e).find("input").val();
          if (!is_empty(selectOption)) {
            trueOptions++;
            selectElement.append(
              `<option value="${selectOption}" >${selectOption}</option>`
            );
            target.append(
              `<input class="d-none" name="selectOptions" value="${selectOption}" >`
            );
          }
        });
        if (!trueOptions) return sweetAlert("error", "Please add some values");
        modal.modal("hide");

        const createdSelectWrapper = $(`<div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Created Select <i></i></label>
                                <div class="d-flex" > </div>
                            </div>`);

        const edit =
          $(`<a id="editSelect" class="btn height-inherit btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                        <span class="svg-icon svg-icon-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                            </svg>
                        </span>
                    </a>`);

        edit.on("click", () => {
          modal.modal("show");
        });

        target.append(createdSelectWrapper);
        createdSelectWrapper.find("div.d-flex").append(selectElement);
        createdSelectWrapper.find("div.d-flex").append(edit);
        select2();
      };
    },
    Library: function () {
      const modal = $("#modal");
      $("#addSelect").on("click", () => {
        modal.modal("show");
      });

      const FormVal = (modal, event, select_id = false) => {
        const showOption = event !== "create";
        modal.find("#repeater").repeater({
          initEmpty: showOption,
          show: function () {
            $(this).slideDown();
          },
          hide: function (e) {
            $(this).slideUp(e);
          },
        });

        const form = modal.find("form");
        const F = new FormValidate(form);
        F.onValidate = () => {
          const data = [];
          modal.find("[data-repeater-item]").each((f, e) => {
            is_empty($(e).find(".data-heading").val()) ||
              data.push($(e).find(".data-heading").val());
          });

          const r = new Ajax();
          r.url = ajax_url.a;
          r.data =
            form.serialize() +
            formString({
              select_id: select_id,
              event: event,
              data: data,
              case: "create_select",
              action: "ecommerce_select_actions",
            });
          r.before = () => disableElement(form, 2);
          r.complete = () => enableElement(form);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              $("#data").html(res.data);
              select2();
              resetForm(form);
              $(
                "[data-repeater-list] [data-repeater-item]:not(:first-child)"
              ).remove();
              modal.modal("hide");
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        };
      };
      FormVal(modal, "create");

      // Delete
      $("body").on("click", '[data-action="delete"]', (e) => {
        const t = $(e.currentTarget);
        const select_id = t.data("id");
        const tr = t.closest("tr");
        const r = new Ajax();
        r.url = ajax_url.a;
        r.data = {
          select_id: select_id,
          case: "delete_select",
          action: "ecommerce_select_actions",
        };
        r.before = () => disableElement(tr);
        r.complete = (e) => enableElement(tr);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            tr.remove(), sweetAlert("success", res.message);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        const c = new Confirm();
        c.ok = () => r.send();
        c.show();
      });

      //Edit
      $("body").on("click", '[data-action="edit"]', (e) => {
        const t = $(e.currentTarget);
        const select_id = t.data("id");
        const tr = t.closest("tr");
        const r = new Ajax();
        r.url = ajax_url.a;
        r.data = {
          select_id: select_id,
          case: "fetch_select",
          action: "ecommerce_select_actions",
        };
        r.before = () => disableElement(tr);
        r.complete = () => enableElement(tr);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            editSelect(res.data, select_id);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      });

      const editSelect = (data, select_id) => {
        const modal = $("#editModal");
        modal.modal("show");
        modal.find(".modal-body").html(data);
        FormVal(modal, "update", select_id);
      };
    },
    SellerVerification: function () {
      const Tbl = (status) => {
        return $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[3, "desc"]],
          columnDefs: [
            {
              targets: [0, 1, 4, 5],
              orderable: false,
            },
          ],
          columns: [
            {
              data: null,
              orderable: false,
              render: function (data, type, row, meta) {
                return meta.row + meta.settings._iDisplayStart + 1;
              },
            },
            {
              data: "seller",
            },
            {
              data: "member_since",
            },
            {
              data: "requested_date",
            },
            {
              data: "status",
            },
            {
              data: "actions",
            },
          ],
          ajax: {
            url: ajax_url.a,
            type: "POST",
            data: {
              status: status,
              action: "loadTblData",
              case: "sellers_verification_tbl",
            },
          },
        });
      };
      return {
        pending: function () {
          const t = Tbl("pending");
          t.on("draw", () => {
            select2();
          });
        },
        verified: function () {
          const t = Tbl("verified");
          t.on("draw", () => {
            select2();
          });
        },
        rejected: function () {
          const t = Tbl("rejected");
          t.on("draw", () => {
            select2();
          });
        },
      };
    },
    viewSellerVerification: function (verification_id) {
      const modal = $("#rejectVerificationModal");
      const form = modal.find("form");
      const approve = $("#approveVerification");

      approve.on("click", () => {
        const r = new Ajax();
        r.url = ajax_url.a;
        r.data = {
          approve: 1,
          verification_id: verification_id,
          case: "approve_verification",
          action: "seller_verification",
        };
        r.before = () => disableBtn(approve);
        r.error = () => enableBtn(approve);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message), locateTo(res.url, 1000);
          } catch (error) {
            cl(error);
            r.error();
            sweetAlert("error", res);
          }
        };
        r.send();
      });

      const F = new FormValidate(form);
      F.onValidate = () => {
        const r = new Ajax();
        r.url = ajax_url.a;
        r.data =
          form.serialize() +
          formString({
            verification_id: verification_id,
            case: "reject_verification",
            action: "seller_verification",
          });
        r.before = () => disableElement(form, 2);
        r.error = () => enableElement(form);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message), locateTo(res.url, 1000);
          } catch (error) {
            cl(error);
            r.error();
            sweetAlert("error", res);
          }
        };
        r.send();
      };
    },
    SellersList: function (status) {
      const t = $("#data_table").DataTable({
        processing: true,
        serverSide: true,
        order: [[3, "desc"]],
        columns: [
          {
            data: null,
            orderable: false,
            render: function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            },
          },
          {
            data: "seller",
          },
          {
            data: "products",
          },
          {
            data: "seller_since",
          },
          {
            data: "status",
          },
          {
            data: "actions",
          },
        ],
        ajax: {
          url: ajax_url.a,
          type: "POST",
          data: {
            status: status,
            action: "loadTblData",
            case: "all_sellers_list",
          },
        },
      });
      t.on("draw", () => {
        select2();
      });
    },
    CustomersList: function (status) {
      const t = $("#data_table").DataTable({
        processing: true,
        serverSide: true,
        order: [[3, "desc"]],
        columns: [
          {
            data: null,
            orderable: false,
            render: function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            },
          },
          {
            data: "user",
          },
          {
            data: "email",
          },
          {
            data: "purchased",
          },
          {
            data: "status",
          },
          {
            data: "member_since",
          },
          {
            data: "actions",
          },
        ],
        ajax: {
          url: ajax_url.a,
          type: "POST",
          data: {
            status: status,
            action: "loadTblData",
            case: "all_ecommerce_customers_list",
          },
        },
      });
      t.on("draw", () => {
        select2();
      });
    },
    viewSeller: {
      init: function () {
        const modal = $("#statusModal");
        const form = modal.find("form");
        const select = $("#changeStatus");

        select.on("change", () => {
          const val = select.val();
          const headText = val == "reject" ? "Reject Seller" : "Block Seller";
          modal.find("#heading").html(headText);
          modal.modal("show");
        });

        const F = new FormValidate(form);
        F.onValidate = () => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data =
            form.serialize() +
            formString({
              status: select.val(),
              user_id: $_GET["id"],
              case: "change_seller_status",
              action: "change_seller_details",
            });
          r.before = () => disableElement(form, 2);
          r.complete = () => enableElement(form);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message),
                resetForm(form),
                $("#account_status").html(res.status),
                modal.modal("hide"),
                $("#changeStatusWrapper").remove();
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        };
      },
      listings: (status) => {
        const columns = [
          {
            data: null,
            orderable: false,
            render: function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            },
          },
          {
            data: "product",
          },
          {
            data: "status",
          },
          {
            data: "stock",
          },
          {
            data: "price",
          },
          {
            data: "mrp",
          },
          {
            data: "category",
          },
          {
            data: "sell",
          },
          {
            data: "date",
          },
        ];

        const t = $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[7, "desc"]],
          columnDefs: [
            {
              targets: [0, 1, 7],
              orderable: false,
            },
          ],
          columns: columns,
          ajax: {
            url: ajax_url.a,
            type: "POST",
            data: {
              id: $_GET["id"],
              status: status,
              action: "loadTblData",
              case: "seller_listings_tbl",
            },
          },
        });

        t.on("draw", () => select2());
      },
      orders: (status) => {
        status == "rtd" && (status = "labelled");
        status == "handover" && (status = "rtd");
        status == "completed" && (status = "delivered");
        const columns = [
          {
            data: null,
            orderable: false,
            render: function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            },
          },
          {
            data: "order_id",
          },
          {
            data: "details",
          },
          {
            data: "buyer",
          },
          {
            data: "quantity",
          },
          {
            data: "amount",
          },
          {
            data: "order_date",
          },
          {
            data: "actions",
          },
        ];

        let columnSort = "asc";
        status = status.toUpperCase();

        switch (status) {
          case "CANCELLED":
            columns.splice(7, 0, {
              data: "cancelled_on",
            });
            columnSort = "desc";
            break;
          case "DELIVERED":
            columns.splice(7, 0, {
              data: "delivered_on",
            });
            columnSort = "desc";
            break;
          case "RTD":
            columns.splice(7, 0, {
              data: "rtd_on",
            });
            break;
          case "REJECTED":
            columns.splice(7, 0, {
              data: "rejected_on",
            });
            columnSort = "desc";
            break;
          case "LABELLED":
            columns.splice(7, 0, {
              data: "labelled_on",
            });
            break;
          case "SHIPPED":
            columns.splice(7, 0, {
              data: "shipped_on",
            });
            columnSort = "desc";
            break;
        }

        const t = $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[6, columnSort]],
          columnDefs: [
            {
              targets: [0, 1, 7],
              orderable: false,
            },
          ],
          columns: columns,
          ajax: {
            url: ajax_url.a,
            type: "POST",
            data: {
              order_status: status,
              action: "loadTblData",
              case: "all_sellers_orders_tbl",
            },
          },
        });
        t.on("draw", () => select2());
      },
      transactions: () => {
        const t = $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[6, "desc"]],
          columns: [
            {
              data: null,
              orderable: false,
              sortable: false,
              render: function (data, type, row, meta) {
                return meta.row + meta.settings._iDisplayStart + 1;
              },
            },
            {
              data: "transaction_id",
            },
            {
              data: "amount",
            },
            {
              data: "txn_charge",
            },
            {
              data: "net_amount",
            },
            {
              data: "details",
            },
            {
              data: "date",
            },
            {
              data: "status",
            },
          ],
          ajax: {
            url: ajax_url.a,
            type: "POST",
            data: {
              id: $_GET["id"],
              action: "loadTblData",
              case: "seller_transactions_TBl",
            },
          },
        });
        t.on("draw", () => select2());
      },
    },
    Withdraw: {
      addNewMethod: function (params) {
        let currentLabels = (params && params.currentLabels) || 0;

        // Image Change
        const profileContainer = $("#profileContainer");
        const imageContainer = profileContainer.find("img");
        const progress = profileContainer.find(".profile-progress");
        const logo_image_id = profileContainer.find(
          "input[name=logo_image_id]"
        );
        const inputChooser = profileContainer.find("input[type=file]");
        const removeBtn = profileContainer.find(
          "[data-lx-image-input-action=remove]"
        );

        removeBtn.on("click", () => removeProfile());

        inputChooser.on("change", (e) => {
          const u = new ImageUpload(e.target);
          u.name = "image";
          u.data = {
            type: "image",
            action: "file_upload",
          };
          u.xhr = (evt) => {
            let percentComplete = (evt.loaded / evt.total) * 100;
            percentComplete = parseInt(percentComplete);
            profileContainer.addClass("uploading");
            progress.css({
              "--value": percentComplete,
            });
          };
          u.success = (res) => {
            try {
              res = JSON.parse(res);
              let image_id = res.file_id;
              let image_src = res.file_url;
              imageContainer.attr("src", image_src);
              logo_image_id.val(image_id);
              profileContainer.removeClass("image-input-changed");
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          u.complete = () => profileContainer.removeClass("uploading");
          u.upload();
        });

        const removeProfile = () => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data = {
            gateway_id: $_GET["id"],
            remove_gateway_logo: 1,
            case: "remove_gateway_logo",
            action: "withdraw_actions",
          };
          r.before = () => {};
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              let image_id = res.image_id;
              let image_src = res.image_src;
              imageContainer.attr("src", image_src);
              logo_image_id.val(image_id);
              profileContainer.addClass("image-input-changed");
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        };

        const card = $("#repeater");
        const btn = card.find("[data-repeater-create]");
        const imgBtn = card.find("[data-repeater-create-image]");
        const maxLabels = 10;

        const check = () => {
          maxLabels == currentLabels
            ? (btn.addClass("d-none"), imgBtn.addClass("d-none"))
            : (btn.removeClass("d-none"), imgBtn.removeClass("d-none"));
        };
        check();

        $("#repeater").repeater({
          initEmpty: true,
          show: function () {
            currentLabels += 1;
            check();
            $(this).slideDown();
            select2();
          },
          hide: function (e) {
            currentLabels -= 1;
            check();
            $(this).slideUp(e);
          },
        });

        imgBtn.on("click", () => {
          const imgFormRow =
            $(`<div data-repeater-item="" class="d1-none form-group">
                                                <div class="d-flex align-items-end mb-5">
                                                    <div class="flex-grow-1 fv-row">
                                                        <label class="fs-6 fw-bold mb-2 required"> Add Label <small>(image)</small> </label>
                                                        <input data-type="image" data-id="0" type="text" required class="form-control form-control-solid flex-grow-1 " placeholder="Add Label" name="labels" value="">
                                                    </div>
                                                    <button type="button" data-repeater-delete="" class="ms-4 btn btn-sm btn-icon btn-light-danger">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                </div>
                                            </div>`);
          $("[data-repeater-list]").append(imgFormRow);
          imgFormRow.slideDown();
          currentLabels += 1;
          check();
        });

        const form = $("#createWithdrawMethod");
        const F = new FormValidate(form, {
          charge: {
            number: {
              text: "Charge must consist of numbers only ",
            },
          },
        });
        F.onValidate = () => {
          if (currentLabels == 0)
            return sweetAlert("error", "Add atleast a payment requirement");

          const labels = [];
          form.find('[name="labels"]').each((f, e) => {
            const t = $(e);
            labels.push({
              type: t.data("type"),
              id: t.data("id"),
              value: t.val(),
            });
          });

          const r = new Ajax();
          r.url = ajax_url.a;
          r.data =
            form.serialize() +
            formString({
              labels: labels,
              case: "create_withdraw_method",
              action: "withdraw_actions",
            });
          r.before = () => disableElement(form, 2);
          r.error = () => enableElement(form);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message), locateTo(res.url, 1000);
            } catch (error) {
              cl(error);
              r.error();
              sweetAlert("error", res);
            }
          };
          r.send();
        };

        $("#delete_gateway").on("click", (e) => {
          const t = $(e.currentTarget);
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data = {
            gateway_id: $_GET["id"],
            case: "delete_withdraw_gateway",
            action: "withdraw_actions",
          };
          r.before = () => disableBtn(t);
          r.error = () => enableBtn(t);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message), locateTo(res.url, 2000);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          const c = new Confirm();
          c.text =
            "This withdraw method will be deleted and no longer available to use";
          c.ok = () => r.send();
          c.show();
        });
      },
      withdrawMethods: function () {
        const t = $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[3, "desc"]],
          columns: [
            {
              data: null,
              orderable: false,
              render: function (data, type, row, meta) {
                return meta.row + meta.settings._iDisplayStart + 1;
              },
            },
            {
              data: "gateway",
            },
            {
              data: "time",
            },
            {
              data: "date",
            },
            {
              data: "status",
            },
            {
              data: "actions",
            },
          ],
          ajax: {
            url: ajax_url.a,
            type: "POST",
            data: {
              action: "loadTblData",
              case: "all_ecommerce_withdraw_methods",
            },
          },
        });
        t.on("draw", () => {
          select2();
        });
      },
      dataTbl: function (order, status) {
        const columns = [
          {
            data: null,
            orderable: false,
            render: function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            },
          },
          {
            data: "transaction_id",
          },
          {
            data: "seller",
          },
          {
            data: "gateway",
          },
          {
            data: "gross_amount",
          },
          {
            data: "charge",
          },
          {
            data: "net_amount",
          },
          {
            data: "requested_date",
          },
          {
            data: "status",
          },
          {
            data: "action",
          },
        ];

        status !== "pending" &&
          columns.splice(8, 0, {
            data: "processed_date",
          });

        const t = $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[7, order]],
          columns: columns,
          ajax: {
            url: ajax_url.a,
            type: "POST",
            data: {
              status: status,
              action: "loadTblData",
              case: "ecommerce_withdraw_data_tbl",
            },
          },
        });
        t.on("draw", () => {
          select2();
        });
      },
      Process: function () {
        const modal = $("#rejectWithdrawModal");
        const form = modal.find("form");
        const success = $("#success_withdraw");

        success.on("click", () => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data = {
            success: 1,
            withdraw_id: $_GET["id"],
            case: "success_withdraw",
            action: "withdraw_actions",
          };
          r.before = () => disableBtn(success);
          r.error = () => enableBtn(success);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message), locateTo(res.url, 1000);
            } catch (error) {
              cl(error);
              r.error();
              sweetAlert("error", res);
            }
          };
          const c = new Confirm();
          c.text = "You've transfered the amount to the seller account";
          c.okText = "Yes, Sure";
          c.ok = () => r.send();
          c.show();
        });

        const F = new FormValidate(form);
        F.onValidate = () => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data =
            form.serialize() +
            formString({
              withdraw_id: $_GET["id"],
              case: "reject_withdraw",
              action: "withdraw_actions",
            });
          r.before = () => disableElement(form, 2);
          r.error = () => enableElement(form);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message), locateTo(res.url, 1000);
            } catch (error) {
              cl(error);
              r.error();
              sweetAlert("error", res);
            }
          };
          r.send();
        };
      },
    },
    Orders: (status) => {
      const columns = [
        {
          data: null,
          orderable: false,
          render: function (data, type, row, meta) {
            return meta.row + meta.settings._iDisplayStart + 1;
          },
        },
        {
          data: "seller",
        },
        {
          data: "order_id",
        },
        {
          data: "details",
        },
        {
          data: "buyer",
        },
        {
          data: "quantity",
        },
        {
          data: "amount",
        },
        {
          data: "order_date",
        },
        {
          data: "actions",
        },
      ];

      let columnSort = "asc";
      let columnNumber = status == "SUCCESS" ? 7 : 8;
      let extraSort = "";

      switch (status) {
        case "CANCELLED":
          columns.splice(8, 0, {
            data: "cancelled_on",
          });
          columns.splice(7, 0, {
            data: "refund",
          });
          columnSort = "desc";
          extraSort = [7, "asc"];
          columnNumber = 9;
          break;
        case "DELIVERED":
          columns.splice(8, 0, {
            data: "delivered_on",
          });
          columnSort = "desc";
          break;
        case "RTD":
          columns.splice(8, 0, {
            data: "rtd_on",
          });
          break;
        case "PICKUP_SCHEDULED":
          columns.splice(8, 0, {
            data: "scheduled_on",
          });
          break;
        case "REJECTED":
          columns.splice(8, 0, {
            data: "rejected_on",
          });
          columns.splice(7, 0, {
            data: "refund",
          });
          columnSort = "desc";
          extraSort = [7, "asc"];
          columnNumber = 9;
          break;
        case "LABELLED":
          columns.splice(8, 0, {
            data: "labelled_on",
          });
          break;
        case "SHIPPED":
          columns.splice(8, 0, {
            data: "shipped_on",
          });
          break;
      }

      let order = is_empty(extraSort)
        ? [[columnNumber, columnSort]]
        : [[columnNumber, columnSort], extraSort];

      const t = $("#data_table").DataTable({
        processing: true,
        serverSide: true,
        order: order,
        columnDefs: [
          {
            targets: [0, 1, columnNumber + 1],
            orderable: false,
          },
        ],
        columns: columns,
        ajax: {
          url: ajax_url.a,
          type: "POST",
          data: {
            order_status: status,
            action: "loadTblData",
            case: "all_sellers_orders_tbl",
          },
        },
      });
      t.on("draw", () => select2());
    },
    ReturnOrders: function () {
      const Tbl = (status, date) => {
        const columns = [
          {
            data: null,
            orderable: false,
            render: function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            },
          },
          {
            data: "order_id",
          },
          {
            data: "return_id",
          },
          {
            data: "details",
          },
          {
            data: "buyer",
          },
          {
            data: "quantity",
          },
          {
            data: "amount",
          },
          {
            data: "delivered_on",
          },
          {
            data: date,
          },
          {
            data: "actions",
          },
        ];

        let order = 8;
        let dorder = 3;

        if (status == "completed" || status == "rejected")
          columns.splice(7, 0, {
            data: "refund",
          });

        return $("#data_table")
          .DataTable({
            processing: true,
            serverSide: true,
            order: [[order, "asc"]],
            columnDefs: [
              {
                targets: [0, dorder, 9],
                orderable: false,
              },
            ],
            columns: columns,
            ajax: {
              url: ajax_url.a,
              type: "POST",
              data: {
                status: status,
                action: "loadTblData",
                case: "return_orders_datatbl",
              },
            },
          })
          .on("draw", () => select2());
      };

      return {
        requests: function () {
          Tbl("initiated", "requested_date");
        },
        completed: function () {
          Tbl("completed", "completed_date");
        },
        accepted: function () {
          Tbl("accepted", "accepted_on");
        },
        scheduledPickup: function () {
          Tbl("pickup_scheduled", "pickup_scheduled_date");
        },
        rejected: function () {
          Tbl("rejected", "rejected_on");
        },
        proceed: function (order_id) {
          const rejectModal = $("#rejectModal");
          const rejectModalForm = rejectModal.find("form");
          const rejectModalForm_V = new FormValidate(rejectModalForm);
          rejectModalForm_V.onValidate = () => {
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data =
              rejectModalForm.serialize() +
              formString({
                case: "reject_return_request",
                action: "ecommerce_orders_actions",
                order_id: order_id,
              });
            r.before = () => disableElement(rejectModalForm, 2);
            r.error = () => enableElement(rejectModalForm);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message),
                  rejectModal.modal("hide"),
                  locateTo(undefined, 1000);
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.send();
          };

          const acceptModal = $("#acceptModal");
          const acceptModalForm = acceptModal.find("form");
          const acceptModalForm_V = new FormValidate(acceptModalForm);
          acceptModalForm_V.onValidate = () => {
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data =
              acceptModalForm.serialize() +
              formString({
                case: "accept_return_request",
                action: "ecommerce_orders_actions",
                order_id: order_id,
              });
            r.before = () => disableElement(acceptModalForm, 2);
            r.error = () => enableElement(acceptModalForm);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message),
                  acceptModal.modal("hide"),
                  locateTo(undefined, 1000);
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.send();
          };

          const scheduleModal = $("#scheduleModal");
          const scheduleModalForm = scheduleModal.find("form");
          const scheduleModalForm_V = new FormValidate(scheduleModalForm);
          scheduleModalForm_V.onValidate = () => {
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data =
              scheduleModalForm.serialize() +
              formString({
                case: "schedule_return_pickup",
                action: "ecommerce_orders_actions",
                order_id: order_id,
              });
            r.before = () => disableElement(scheduleModalForm, 2);
            r.error = () => enableElement(scheduleModalForm);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message),
                  scheduleModal.modal("hide"),
                  locateTo(undefined, 1000);
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.send();
          };

          $("#markCompleted").on("click", (e) => {
            const r = new Ajax();
            const t = $(e.currentTarget);
            r.url = ajax_url.a;
            r.data = {
              case: "mark_return_order_completed",
              action: "ecommerce_orders_actions",
              order_id: order_id,
            };
            r.before = () => disableBtn(t);
            r.complete = () => enableBtn(t);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message), locateTo(undefined, 1000);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            const c = new Confirm();
            c.ok = () => r.send();
            c.text =
              "The product has reached to the seller. This return will be moved to refund payment status.";
            c.okText = "Yes, Sure";
            c.show();
          });
        },
      };
    },
    ReplacementOrders: function () {
      const Tbl = (status, date) => {
        const columns = [
          {
            data: null,
            orderable: false,
            render: function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            },
          },
          {
            data: "order_id",
          },
          {
            data: "replacement_id",
          },
          {
            data: "details",
          },
          {
            data: "buyer",
          },
          {
            data: "quantity",
          },
          {
            data: "amount",
          },
          {
            data: "delivered_on",
          },
          {
            data: date,
          },
          {
            data: "actions",
          },
        ];

        let order = 8;
        let dorder = 3;

        return $("#data_table")
          .DataTable({
            processing: true,
            serverSide: true,
            order: [[order, "desc"]],
            columnDefs: [
              {
                targets: [0, dorder, 9],
                orderable: false,
              },
            ],
            columns: columns,
            ajax: {
              url: ajax_url.a,
              type: "POST",
              data: {
                status: status,
                action: "loadTblData",
                case: "replacement_orders_datatbl",
              },
            },
          })
          .on("draw", () => select2());
      };

      return {
        requests: function () {
          Tbl("initiated", "requested_date");
        },
        completed: function () {
          Tbl("completed", "completed_date");
        },
        accepted: function () {
          Tbl("accepted", "accepted_on");
        },
        scheduledPickup: function () {
          Tbl("pickup_scheduled", "pickup_scheduled_date");
        },
        rejected: function () {
          Tbl("rejected", "rejected_on");
        },
        proceed: function (orderId) {
          const rejectModal = $("#rejectModal");
          const rejectModalForm = rejectModal.find("form");
          const rejectModalForm_V = new FormValidate(rejectModalForm);

          rejectModalForm_V.onValidate = () => {
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data =
              rejectModalForm.serialize() +
              formString({
                case: "reject_replacement_request",
                action: "ecommerce_orders_actions",
                order_id: orderId,
              });
            r.before = () => disableElement(rejectModalForm, 2);
            r.error = () => enableElement(rejectModalForm);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message),
                  rejectModal.modal("hide"),
                  locateTo(undefined, 1000);
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.send();
          };

          const acceptModal = $("#acceptModal");
          const acceptModalForm = acceptModal.find("form");
          const acceptModalForm_V = new FormValidate(acceptModalForm);
          acceptModalForm_V.onValidate = () => {
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data =
              acceptModalForm.serialize() +
              formString({
                case: "accept_replacement_request",
                action: "ecommerce_orders_actions",
                order_id: orderId,
              });
            r.before = () => disableElement(acceptModalForm, 2);
            r.error = () => enableElement(acceptModalForm);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message),
                  acceptModal.modal("hide"),
                  locateTo(undefined, 1000);
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.send();
          };

          const scheduleModal = $("#scheduleModal");
          const scheduleModalForm = scheduleModal.find("form");
          const scheduleModalForm_V = new FormValidate(scheduleModalForm, {
            return_shipping_charge: {
              number: {
                text: "Only numbers are allowed",
              },
            },
          });
          scheduleModalForm_V.onValidate = () => {
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data =
              scheduleModalForm.serialize() +
              formString({
                case: "schedule_replacement_pickup",
                action: "ecommerce_orders_actions",
                order_id: orderId,
              });
            r.before = () => disableElement(scheduleModalForm, 2);
            r.error = () => enableElement(scheduleModalForm);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message),
                  scheduleModal.modal("hide"),
                  locateTo(undefined, 1000);
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.send();
          };

          $("#markCompleted").on("click", (e) => {
            const r = new Ajax();
            const t = $(e.currentTarget);
            r.url = ajax_url.a;
            r.data = {
              case: "mark_replacement_order_completed",
              action: "ecommerce_orders_actions",
              order_id: orderId,
            };
            r.before = () => disableBtn(t);
            r.complete = () => enableBtn(t);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message), locateTo(undefined, 1000);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            const c = new Confirm();
            c.ok = () => r.send();
            c.text =
              "The product has reached to the seller. A new order will be placed.";
            c.okText = "Yes, Sure";
            c.show();
          });

          //Refund
          const modal = $("#refundReplacementModal");
          const form = modal.find("form");
          const F = new FormValidate(form);
          F.onValidate = () => {
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data =
              form.serialize() +
              formString({
                case: "refund_replacement_request",
                action: "ecommerce_orders_actions",
                order_id: orderId,
              });
            r.before = () => disableElement(form, 2);
            r.error = () => enableElement(form);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message);
                modal.modal("hide");
                locateTo(undefined, 1000);
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.send();
          };
        },
      };
    },
    RefundOrders: (status) => {
      const order = status === "pending" ? "asc" : "desc";
      const t = $("#data_table").DataTable({
        processing: true,
        serverSide: true,
        order: [[9, order]],
        columns: [
          {
            data: null,
            orderable: false,
            render: function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            },
          },
          {
            data: "seller",
          },
          {
            data: "order_id",
          },
          {
            data: "details",
          },
          {
            data: "buyer",
          },
          {
            data: "quantity",
          },
          {
            data: "amount",
          },
          {
            data: "status",
          },
          {
            data: "refund",
          },
          {
            data: "refund_inited_on",
          },
          {
            data: "actions",
          },
        ],
        ajax: {
          url: ajax_url.a,
          type: "POST",
          data: {
            status: status,
            action: "loadTblData",
            case: "refund_orders_tbl",
          },
        },
      });
      t.on("draw", () => {
        select2();
      });
    },
    ViewOrder: (order_id) => {
      const addTrackingModal = $("#addTrackingModal");
      const addTrackingForm = addTrackingModal.find("form");
      const F = new FormValidate(addTrackingForm, {
        courier_charge: {
          number: {
            text: "Courier Charge must consist of numbers only",
          },
        },
      });
      F.onValidate = () => {
        const r = new Ajax();
        r.url = ajax_url.a;
        r.data =
          addTrackingForm.serialize() +
          formString({
            order_id: order_id,
            case: "schedule_pickup_order",
            action: "ecommerce_orders_actions",
          });
        r.before = () => disableElement(addTrackingForm, 2);
        r.complete = () => enableElement(addTrackingForm);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message);
            resetForm(form);
            addTrackingModal.modal("hide");
            locateTo(undefined, 1000);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      };

      const modal = $("#refundModal");
      const form = modal.find("form");
      const RF = new FormValidate(form);
      RF.onValidate = () => {
        const r = new Ajax();
        r.url = ajax_url.a;
        r.data =
          form.serialize() +
          formString({
            case: "mark_refund_completed",
            action: "ecommerce_orders_actions",
            order_id: order_id,
          });
        r.before = () => disableElement(form, 2);
        r.error = () => enableElement(form);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message),
              modal.modal("hide"),
              locateTo(undefined, 1000);
          } catch (error) {
            cl(error);
            r.error();
            sweetAlert("error", res);
          }
        };
        r.send();
      };

      //

      $("#markDelivered").on("click", (e) => {
        const t = $(e.currentTarget);
        const r = new Ajax();
        r.url = ajax_url.a;
        r.data = {
          order_id: order_id,
          case: "mark_delivered",
          action: "ecommerce_orders_actions",
        };
        r.before = () => disableBtn(t);
        r.complete = () => enableBtn(t);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message), locateTo(undefined, 1000);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        const A = new Confirm();
        A.ok = () => r.send();
        A.head = "Mark Order as Delivered";
        A.text = `Are you sure you want to mark the order as Delivered? This action can't be reversed. `;
        A.okText = "Mark as Delivered";
        A.show();
      });

      $("#markAsShipped").on("click", (e) => {
        const t = $(e.currentTarget);
        const r = new Ajax();
        r.url = ajax_url.a;
        r.data = {
          case: "mark_order_as_shipped",
          action: "ecommerce_orders_actions",
          order_id: order_id,
        };
        r.before = () => disableBtn(t);
        r.error = () => enableBtn(t);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message), locateTo(undefined, 1000);
          } catch (error) {
            cl(error);
            r.error();
            sweetAlert("error", res);
          }
        };
        const A = new Confirm();
        A.ok = () => r.send();
        A.head = "Mark Order as Shipped";
        A.text = `Are you sure you want to mark the order as Shipped? This action can't be reversed. `;
        A.okText = "Mark as Shipped";
        A.show();
      });

      const rejectForm = $("#rejectOrderModal").find("form");
      const SF = new FormValidate(rejectForm);
      SF.onValidate = () => {
        const r = new Ajax();
        r.url = ajax_url.a;
        r.data =
          rejectForm.serialize() +
          formString({
            order_id: order_id,
            case: "reject_order",
            action: "ecommerce_orders_actions",
          });
        r.before = () => disableElement(rejectForm, 2);
        r.error = () => enableElement(rejectForm);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message),
              modal.modal("hide"),
              locateTo(undefined, 1000);
          } catch (error) {
            cl(error);
            r.error();
            sweetAlert("error", res);
          }
        };
        r.send();
      };
    },
    Setting: {
      emailSetting: function () {
        // Email
        const emailForm = $("#emailForm");
        const F = new FormValidate(emailForm);
        F.onValidate = () => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data =
            emailForm.serialize() +
            formString({
              case: "update_email_setting",
              action: "site_settings",
            });
          r.before = () => disableElement(emailForm, 2);
          r.complete = () => enableElement(emailForm);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              fe.start(), sweetAlert("success", res.message);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        };
        const fe = new FormEdit();
        fe.form = emailForm;
        fe.edit = $('[type="edit"][data-form="emailForm"]');
        fe.init();

        // Email
        const testEmailForm = $("#testEmailForm");
        const R = new FormValidate(testEmailForm);
        R.onValidate = () => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data =
            testEmailForm.serialize() +
            formString({
              case: "send_test_email",
              action: "site_settings",
            });
          r.before = () => disableElement(testEmailForm, 2);
          r.complete = () => enableElement(testEmailForm);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        };
      },
      LogoSetting: function () {
        $('[data-input-parent="logoUpload"]').each((f, e) => {
          const c = $(e);

          const input = c.find('[data-input="changeLogo"]');
          const p = c.find(".image-upload-progress");

          input.on("change", () => {
            const r = new ImageUpload(input[0]);
            r.url = ajax_url.a;
            r.data = {
              type: input.data("type"),
              panel: input.data("panel"),
              case: "change_site_logo",
              action: "site_settings",
            };
            r.xhr = (evt) => {
              let c = (evt.loaded / evt.total) * 100;
              c = parseInt(c);
              p.show()
                .find(".progress-bar")
                .width(c + "%");
            };
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message),
                  c.find("img").attr("src", res.url);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.complete = () => p.hide().find(".progress-bar").width(0);
            r.upload();
          });
        });
      },
      basicSetting: function () {
        // Email
        const basicForm = $("#basicForm");

        const fe = new FormEdit();
        fe.form = basicForm;
        fe.edit = $('[type="edit"][data-form="basicForm"]');
        fe.init();

        const F = new FormValidate(basicForm);
        F.onValidate = () => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data =
            basicForm.serialize() +
            formString({
              case: "update_basic_setting",
              action: "site_settings",
            });
          r.before = () => disableElement(basicForm, 2);
          r.complete = () => enableElement(basicForm);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              fe.start(), sweetAlert("success", res.message);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        };

        //reset

        $("#reset").on("click", (e) => {
          const b = $(e.currentTarget);
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data = {
            case: "reset_basic_setting",
            action: "site_settings",
          };
          r.before = () => disableBtn(b);
          r.complete = () => enableBtn(b);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message), locateTo(res.url, 1000);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };

          const c = new Confirm();
          c.ok = () => r.send();
          c.okText = "Yes, Reset";
          c.show();
        });
      },
      Banners: {
        init() {
          const addCollection = $("#addCollection");
          addCollection.on("click", () => {
            const r = new Ajax();
            r.data = {
              case: "create_new_banner_collection",
              action: "home_page_settings",
            };
            r.before = () => disableBtn(addCollection);
            r.complete = () => enableBtn(addCollection);
            r.url = ajax_url.a;
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                const card = $(res.card);
                $("#collections").append(card);
                removeTooltips();
                LXApp.initBootstrapTooltips();
                sweetAlert("success","New banner collection has been created");
                $('html, body').animate({
                  scrollTop: card.offset().top
              }, 500);
    
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.send();
          });
    
          $("body").on("click", '[data-action="delete_collection"]', (e) => {
            const t = $(e.currentTarget);
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data = {
              component_id: t.data("component_id"),
              case: "delete_banner_collection",
              action: "home_page_settings",
            };
            r.before = () => disableBtn(t, "no-text");
            r.complete = () => enableBtn(t);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message);
                remove(t.closest(".card"));
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            const c = new Confirm();
            c.ok = () => r.send();
            c.show();
          });
    
          // Update
          const updateCollectionDetails = $("#updateCollectionDetails");
          $("body").on("click", '[data-action="update_collection"]', (e) => {
            const t = $(e.currentTarget);
            const heading = t.data("heading");
            const card = t.closest(".card");
            const columns = t.data("columns");
            const tab_columns = t.data("tab_columns");
            const mobile_columns = t.data("mobile_columns");
            updateCollectionDetails.modal("show");
    
            const form = updateCollectionDetails.find("form");
            form.off();
            form.find("input[name=heading]").val(heading);
            form.find("input[name=columns]").val(columns);
            form.find("input[name=tab_columns]").val(tab_columns);
            form.find("input[name=mobile_columns]").val(mobile_columns);
    
            const F = new FormValidate(form);
            F.onValidate = () => {
              const r = new Ajax();
              r.url = ajax_url.a;
              r.data =
                form.serialize() +
                formString({
                  component_id: t.data("component_id"),
                  case: "update_banner_collection",
                  action: "home_page_settings",
                });
              r.before = () => disableElement(form);
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  sweetAlert("success", res.message);
                  updateCollectionDetails.modal("hide");
                  card.find(".collection-heading").html(res.heading);
                  t.data("heading", res.heading);
                  t.data("columns", res.columns);
                  t.data("mobile_columns", res.mobile_columns);
                  t.data("tab_columns", res.tab_columns);
                  resetForm(form);
                } catch (error) {
                  cl(error);
                  sweetAlert("error", res);
                }
              };
              r.complete = () => enableElement(form);
              r.send();
            };
          });
    
          const addBannerModal = $("#addBannerModal");
          $("body").on("click", '[data-action="add_banner"]', (e) => {
            const t = $(e.currentTarget);
            const component_id = t.data("component_id");
            const card = t.closest(".card");
    
            addBannerModal.modal("show");
            const form = addBannerModal.find("form");
            form.off();
            this.create(form, component_id, (res) => {
              addBannerModal.modal("hide");
              card.find("tbody").html(res.content);
            });
          });
    
          // Update Banner
          const updateBannerModal = $("#updateBannerModal");
          $("body").on("click", '[data-action="updateBanner"]', (e) => {
            const t = $(e.currentTarget);
            const component_id = t.data("component_id");
            const key = $(e.currentTarget).data("key");
            const tr = $(e.currentTarget).closest("tr");
            const r = new Ajax();
            const card = t.closest(".card");
    
            r.url = ajax_url.a;
            r.data = {
              component_id:component_id,
              key: key,
              case: "get_banner_update_form",
              action: "home_page_settings",
            };
            r.before = () => disableElement(tr);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                updateBannerModal.find(".modal-body").html(res.data);
                fillSelect();
                updateBannerModal.modal("show");
                const form = updateBannerModal.find("form");
                this.create(form, component_id, (res) => {
                  updateBannerModal.modal("hide");
                  card.find("tbody").html(res.content);
                });
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.complete = () => enableElement(tr);
            r.send();
          });
    
          // Change Banner Status
          $("body").on("click", '[data-action="changeBannerStatus"]', (e) => {
            const t = $(e.currentTarget);
            const component_id = t.data("component_id");
            const key = $(e.currentTarget).data("key");
            const tr = $(e.currentTarget).closest("tr");
            const r = new Ajax();
    
            r.url = ajax_url.a;
            r.data = {
              component_id:component_id,
              key: key,
              case: "change_banner_status",
              action: "home_page_settings",
            };
            r.before = () => disableElement(tr);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message);
                tr.find(".badge").replaceWith(res.badge);
                t.replaceWith(res.button);
                removeTooltips();
                LXApp.initBootstrapTooltips();
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.complete = () => enableElement(tr);
            r.send();
          });
    
          // Delete Banner
          $("body").on("click", '[data-action="deleteBanner"]', (e) => {
            const t = $(e.currentTarget);
            const component_id = t.data("component_id");
            const key = $(e.currentTarget).data("key");
            const tr = $(e.currentTarget).closest("tr");
            const r = new Ajax();
    
            r.url = ajax_url.a;
            r.data = {
              component_id:component_id,
              key: key,
              case: "delete_banner",
              action: "home_page_settings",
            };
            r.before = () => disableElement(tr);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message);
                tr.remove();
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.error = () => enableElement(tr);
            const c = new Confirm();
            c.ok = () => r.send();
            c.show();
          });
    
        },
        create(form, component_id, success) {
          let select = form.find("select");
          if (select.hasClass("select2-hidden-accessible")) {
            select = select.data("select2");
            select.destroy();
          }
    
          const original = form.html();
          select2();
          const imageId = form.find("[name=image_id]");
          const chooser = $(
            `<input class="sr-only" accept=".png, .jpg, .jpeg,.webp" type="file" name="images">`
          );
          const uploadCard = form.find("#uploadCard");
    
          uploadCard.on("click", () => {
            chooser.trigger("click");
          });
    
          chooser.on("change", (e) => {
            const progress = uploadCard.find(".image-upload-progress");
            const r = new ImageUpload(e.currentTarget);
            r.data = {
              type: "image",
              action: "file_upload",
            };
            r.xhr = (evt) => {
              let c = (evt.loaded / evt.total) * 100;
              c = parseInt(c);
              progress
                .show()
                .find(".progress-bar")
                .width(c + "%");
            };
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                imageId.val(res.file_id).trigger("change"),
                  uploadCard
                    .find("#innerContent")
                    .html(
                      `<img src="${res.file_url}" class="img-fluid mh-100" >`
                    );
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.complete = () => progress.hide().find(".progress-bar").width(0);
            r.upload();
          });
    
          const F = new FormValidate(form, {
            url: {
              url: {
                text: "Url is not a valid url",
              },
            },
          });
          F.onValidate = () => {
            const r = new Ajax();
            r.data =
              form.serialize() +
              formString({
                component_id:component_id,
                case: "create_new_banner",
                action: "home_page_settings",
              });
            r.url = ajax_url.a;
            r.before = () => disableElement(form, 2);
            r.complete = () => enableElement(form);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                resetForm(form);
                form.html(original);
                sweetAlert("success", res.message), success(res);
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.send();
          };
        },
      },
      productSliders: {
        init() {
          // Category
          const modal = $("#categoryModal");
          const modalBody = modal.find("#content");
    
          // Update Banner
          const updateSliderModal = $("#updateSliderModal");
          $("body").on("click", '[data-action="update"]', (e) => {
            const t = $(e.currentTarget);
            const component_id = t.data("component_id");
            const tr = $(e.currentTarget).closest("tr");
            const r = new Ajax();
            const card = t.closest(".card");
    
            r.url = ajax_url.a;
            r.data = {
              component_id:component_id,
              case: "get_product_slider_update_form",
              action: "home_page_settings",
            };
            r.before = () => disableElement(tr);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                updateSliderModal.find(".modal-body").html(res.data);
                fillSelect();
                updateSliderModal.modal("show");
                const form = updateSliderModal.find("form");
                this.create(form, modal, (res) => {
                  updateSliderModal.modal("hide");
                  card.find("tbody").html(res.content);
                });
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.complete = () => enableElement(tr);
            r.send();
          });
    
          // Change Status
          $("body").on("click", '[data-action="changeStatus"]', (e) => {
            const t = $(e.currentTarget);
            const component_id = t.data("component_id");
            const tr = $(e.currentTarget).closest("tr");
            const r = new Ajax();
    
            r.url = ajax_url.a;
            r.data = {
              component_id:component_id,
              case: "change_product_slider_status",
              action: "home_page_settings",
            };
            r.before = () => disableElement(tr);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message);
                tr.find(".badge").replaceWith(res.badge);
                t.replaceWith(res.button);
                removeTooltips();
                LXApp.initBootstrapTooltips();
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.complete = () => enableElement(tr);
            r.send();
          });
    
          $("body").on("click", '[data-action="delete"]', (e) => {
            const component_id  = $(e.currentTarget).data("component_id");
            const t = $(e.currentTarget).closest("tr");
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data = {
              component_id:component_id,
              case: "delete_product_slider",
              action: "home_page_settings",
            };
            r.before = () => disableElement(t);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message);
                remove(t);
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.error = () => enableElement(t);
            const c = new Confirm();
            c.ok = () => r.send();
            c.show();
          });
    
          const addSliderModal = $("#addSliderModal");
          const form = addSliderModal.find("form");
          const select = form.find('[name="category"]');
    
          select.on("change", (e) => {
            e.target.value === "choose"
              ? modal.modal("show")
              : modal.modal("hide");
          });
    
          this.create(form, modal, (res) => {
            addSliderModal.modal("hide");
            $("#sliderData").html(res.content);
          });
    
          $("body").on("click", '[data-choose-category="true"]', (e) => {
            const t = $(e.currentTarget);
            const id = t.data("id");
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data = {
              category_id:id,
              case: "fetch_categories",
              action: "home_page_settings",
            };
            r.before = () => disableElement(t);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                modalBody.html($(res.data));
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.send();
            r.complete = () => enableElement(t);
          });
    
          $("body").on("click", '[data-choose-category="done"]', (e) => {
            const val = e.currentTarget.dataset.id;
            const text = e.currentTarget.dataset.text;
            const option = $(
              `<option selected class="category-choosed" value="${val}" >${text}</option>`
            );
    
            const activeModal = $(".modal.show:has(select)");
            const select = activeModal.find('[name="category"]');
            select.find(".category-choosed").remove();
            select.append(option);
            modal.modal("hide");
          });
        },
        create(form, modal, success) {
          const select = form.find('[name="category"]');
    
          select.on("change", (e) => {
            e.target.value === "choose"
              ? modal.modal("show")
              : modal.modal("hide");
          });
    
          select2();
          const V = new FormValidate(form, {
            heading: {
              max: {
                max: 25,
                text: "Maximum 25 characters are allowed",
              },
            },
          });
          V.onValidate = () => {
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data =
              form.serialize() +
              formString({
                case: "product_slider_add_update",
                action: "home_page_settings",
              });
            r.before = () => disableElement(form, 2);
            r.complete = () => enableElement(form);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message);
                resetForm(form);
                success(res);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
                r.error();
              }
            };
            r.send();
          };
        },
      },
      Category: {
        init() {
          const addCollection = $("#addCollection");
          addCollection.on("click", () => {
            const r = new Ajax();
            r.data = {
              case: "create_new_category_collection",
              action: "home_page_settings",
            };
            r.before = () => disableBtn(addCollection);
            r.complete = () => enableBtn(addCollection);
            r.url = ajax_url.a;
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                const card = $(res.card);
                $("#collections").append(card);
                removeTooltips();
                LXApp.initBootstrapTooltips();
    
                sweetAlert("success","New collection has been created");
                $('html, body').animate({
                  scrollTop: card.offset().top
              }, 500);
    
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.send();
          });
    
          $("body").on("click", '[data-action="delete_collection"]', (e) => {
            const t = $(e.currentTarget);
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data = {
              component_id:t.data("component_id"),
              case: "delete_category_collection",
              action: "home_page_settings",
            };
            r.before = () => disableBtn(t, "no-text");
            r.complete = () => enableBtn(t);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message);
                remove(t.closest(".card"));
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            const c = new Confirm();
            c.ok = () => r.send();
            c.show();
          });
    
          // Update
          const updateCollectionDetails = $("#updateCollectionDetails");
          $("body").on("click", '[data-action="update_collection"]', (e) => {
            const t = $(e.currentTarget);
            const heading = t.data("heading");
            const columns = t.data("columns");
            const tab_columns = t.data("tab_columns");
            const mobile_columns = t.data("mobile_columns");
            const card = t.closest(".card");
            updateCollectionDetails.modal("show");
    
            const form = updateCollectionDetails.find("form");
            form.off();
            form.find("input[name=heading]").val(heading);
            form.find("input[name=columns]").val(columns);
            form.find("input[name=tab_columns]").val(tab_columns);
            form.find("input[name=mobile_columns]").val(mobile_columns);
            const F = new FormValidate(form);
            F.onValidate = () => {
              const r = new Ajax();
              r.url = ajax_url.a;
              r.data =
                form.serialize() +
                formString({
                  component_id:t.data("component_id"),
                  case: "update_category_collection",
                  action: "home_page_settings",
                });
              r.before = () => disableElement(form);
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  sweetAlert("success", res.message);
                  updateCollectionDetails.modal("hide");
                  card.find(".collection-heading").html(res.heading);
                  t.data("heading", res.heading);
                  t.data("columns", res.columns);
                  t.data("mobile_columns", res.mobile_columns);
                  t.data("tab_columns", res.tab_columns);
                  resetForm(form);
                } catch (error) {
                  cl(error);
                  sweetAlert("error", res);
                }
              };
              r.complete = () => enableElement(form);
              r.send();
            };
          });
    
          const addCategoryModal = $("#addCategoryModal");
    
          // Add
          $("body").on("click", '[data-action="add_category"]', (e) => {
            const t = $(e.currentTarget);
            const component_id = t.data("component_id");
            const card = t.closest(".card");
    
            addCategoryModal.modal("show");
            const form = addCategoryModal.find("form");
            form.off();
            this.create(form, component_id, (res) => {
              addCategoryModal.modal("hide");
              card.find("tbody").html(res.content);
            });
          });
    
          // Update
          const updateCategoryModal = $("#updateCategoryModal");
          $("body").on("click", '[data-action="updateCategory"]', (e) => {
            const t = $(e.currentTarget);
            const key = t.data("key");
            const component_id = t.data("component_id");
            const tr = $(e.currentTarget).closest("tr");
            const r = new Ajax();
            const card = t.closest(".card");
    
            r.url = ajax_url.a;
            r.data = {
              key: key,
              component_id:component_id,
              case: "get_category_update_form",
              action: "home_page_settings",
            };
            r.before = () => disableElement(tr);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                updateCategoryModal.find(".modal-body").html(res.data);
                fillSelect();
                updateCategoryModal.modal("show");
                const form = updateCategoryModal.find("form");
                this.create(form, component_id, (res) => {
                  updateCategoryModal.modal("hide");
                  card.find("tbody").html(res.content);
                });
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.complete = () => enableElement(tr);
            r.send();
          });
    
          // Change Status
          $("body").on("click", '[data-action="changeCategoryStatus"]', (e) => {
            const t = $(e.currentTarget);
            const component_id = t.data("component_id");
            const key = t.data("key");
    
            const tr = $(e.currentTarget).closest("tr");
            const r = new Ajax();
    
            r.url = ajax_url.a;
            r.data = {
              component_id:component_id,
              key: key,
              case: "change_category_status",
              action: "home_page_settings",
            };
            r.before = () => disableElement(tr);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message);
                tr.find(".badge").replaceWith(res.badge);
                t.replaceWith(res.button);
                removeTooltips();
                LXApp.initBootstrapTooltips();
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.complete = () => enableElement(tr);
            r.send();
          });
    
          $("body").on("click", '[data-action="deleteCategory"]', (e) => {
            const t = $(e.currentTarget);
            const component_id = t.data("component_id");
            const tr = t.closest("tr");
            const r = new Ajax();
            const key = t.data("key");
    
            r.url = ajax_url.a;
            r.data = {
              component_id:component_id,
              key: key,
              case: "delete_category_component",
              action: "home_page_settings",
            };
            r.before = () => disableElement(tr);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message);
                remove(tr);
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.complete = () => enableElement(tr);
            const c = new Confirm();
            c.ok = () => r.send();
            c.show();
          });
        },
        create(form, component_id, success) {
          let select = form.find("select");
          if (select.hasClass("select2-hidden-accessible")) {
            select = select.data("select2");
            select.destroy();
          }
    
          const original = form.html();
          select2();
          const imageId = form.find("[name=image_id]");
          const chooser = $(
            `<input class="sr-only" accept=".png, .jpg, .jpeg,.webp" type="file" name="images">`
          );
          const uploadCard = form.find("#uploadCard");
    
          uploadCard.on("click", () => {
            chooser.trigger("click");
          });
    
          chooser.on("change", (e) => {
            const progress = uploadCard.find(".image-upload-progress");
            const r = new ImageUpload(e.currentTarget);
            r.data = {
              type: "image",
              action: "file_upload",
            };
            r.xhr = (evt) => {
              let c = (evt.loaded / evt.total) * 100;
              c = parseInt(c);
              progress
                .show()
                .find(".progress-bar")
                .width(c + "%");
            };
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                imageId.val(res.file_id).trigger("change"),
                  uploadCard
                    .find("#innerContent")
                    .html(
                      `<img src="${res.file_url}" class="img-fluid mh-100" >`
                    );
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.complete = () => progress.hide().find(".progress-bar").width(0);
            r.upload();
          });
    
          const F = new FormValidate(form, {
            url: {
              url: {
                text: "Url is not a valid url",
              },
            },
          });
          F.onValidate = () => {
            const r = new Ajax();
            r.data =
              form.serialize() +
              formString({
                component_id:component_id,
                case: "create_new_category",
                action: "home_page_settings",
              });
            r.url = ajax_url.a;
            r.before = () => disableElement(form, 2);
            r.complete = () => enableElement(form);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                resetForm(form);
                form.html(original);
                sweetAlert("success", res.message);
                success(res);
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.send();
          };
        },
      },
      Sliders: {
        init() {
          const addSlider = $("#addSlider");
          addSlider.on("click", () => {
            const r = new Ajax();
            r.data = {
              case: "create_new_slider",
              action: "home_page_settings",
            };
            r.before = () => disableBtn(addSlider);
            r.complete = () => enableBtn(addSlider);
            r.url = ajax_url.a;
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                const card = $(res.card);
                $("#sliders").append(card);
                removeTooltips();
                LXApp.initBootstrapTooltips();
    
                sweetAlert("success","New slider has been created");
                $('html, body').animate({
                  scrollTop: card.offset().top
              }, 500);
    
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.send();
          });
    
          $("body").on("click", '[data-action="delete_slider"]', (e) => {
            const t = $(e.currentTarget);
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data = {
              component_id:t.data("component_id"),
              case: "delete_slider",
              action: "home_page_settings",
            };
            r.before = () => disableBtn(t, "no-text");
            r.complete = () => enableBtn(t);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message);
                remove(t.closest(".card"));
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            const c = new Confirm();
            c.ok = () => r.send();
            c.show();
          });
    
          // Update
          const updateSliderDetailsModal = $("#updateSliderDetails");
          $("body").on("click", '[data-action="update_slider"]', (e) => {
            const t = $(e.currentTarget);
            const heading = t.data("heading");
            const card = t.closest(".card");
    
            updateSliderDetailsModal.modal("show");
    
            const form = updateSliderDetailsModal.find("form");
            form.off();
            form.find("input[name=heading]").val(heading);
    
            const F = new FormValidate(form);
            F.onValidate = () => {
              const r = new Ajax();
              r.url = ajax_url.a;
              r.data =
                form.serialize() +
                formString({
                  component_id:t.data("component_id"),
                  case: "update_slider",
                  action: "home_page_settings",
                });
              r.before = () => disableElement(form);
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  sweetAlert("success", res.message);
                  updateSliderDetailsModal.modal("hide");
                  card.find(".slider-heading").html(res.heading);
                  t.data("heading", res.heading);
                } catch (error) {
                  cl(error);
                  sweetAlert("error", res);
                }
              };
              r.complete = () => enableElement(form);
              r.send();
            };
          });
    
          const addSliderSlideModal = $("#addSliderSlideModal");
          $("body").on("click", '[data-action="add_slider_slide"]', (e) => {
            const t = $(e.currentTarget);
            const component_id = t.data("component_id");
            const card = t.closest(".card");
    
            addSliderSlideModal.modal("show");
            const form = addSliderSlideModal.find("form");
            form.off();
            this.create(form, component_id, (res) => {
              addSliderSlideModal.modal("hide");
              card.find("tbody").html(res.content);
            });
          });
    
          // Update Slider Slide
          const updateSliderSlideModal = $("#updateSliderSlideModal");
          $("body").on("click", '[data-action="updateSliderSlide"]', (e) => {
            const t = $(e.currentTarget);
            const component_id= t.data("component_id");
            const key = $(e.currentTarget).data("key");
            const tr = $(e.currentTarget).closest("tr");
            const r = new Ajax();
            const card = t.closest(".card");
    
            r.url = ajax_url.a;
            r.data = {
              component_id:component_id,
              key: key,
              case: "get_slider_slide_update_form",
              action: "home_page_settings",
            };
            r.before = () => disableElement(tr);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                updateSliderSlideModal.find(".modal-body").html(res.data);
                fillSelect();
                updateSliderSlideModal.modal("show");
                const form = updateSliderSlideModal.find("form");
                this.create(form, component_id, (res) => {
                  updateSliderSlideModal.modal("hide");
                  card.find("tbody").html(res.content);
                });
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.complete = () => enableElement(tr);
            r.send();
          });
    
          // Change Slider Slide Status
          $("body").on(
            "click",
            '[data-action="changeSliderSlideStatus"]',
            (e) => {
              const t = $(e.currentTarget);
              const component_id= t.data("component_id");
              const key = $(e.currentTarget).data("key");
              const tr = $(e.currentTarget).closest("tr");
              const r = new Ajax();
    
              r.url = ajax_url.a;
              r.data = {
                component_id:component_id,
                key: key,
                case: "change_slider_slide_status",
                action: "home_page_settings",
              };
              r.before = () => disableElement(tr);
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  sweetAlert("success", res.message);
                  tr.find(".badge").replaceWith(res.badge);
                  t.replaceWith(res.button);
                  removeTooltips();
                  LXApp.initBootstrapTooltips();
                } catch (error) {
                  cl(error);
                  r.error();
                  sweetAlert("error", res);
                }
              };
              r.complete = () => enableElement(tr);
              r.send();
            }
          );
    
          // Delelte Slider Image
          $("body").on("click", '[data-action="deleteSliderImage"]', (e) => {
            const t = $(e.currentTarget);
            const component_id= t.data("component_id");
            const key = $(e.currentTarget).data("key");
            const tr = $(e.currentTarget).closest("tr");
            const r = new Ajax();
    
            r.url = ajax_url.a;
            r.data = {
              component_id:component_id,
              key: key,
              case: "delete_slider_slide",
              action: "home_page_settings",
            };
            r.before = () => disableElement(tr);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message);
                tr.remove();
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.error = () => enableElement(tr);
            const c = new Confirm();
            c.ok = () => r.send();
            c.show();
          });
        },
        create(form, component_id, success) {
          let select = form.find("select");
          if (select.hasClass("select2-hidden-accessible")) {
            select = select.data("select2");
            select.destroy();
          }
    
          const original = form.html();
          select2();
          const imageId = form.find("[name=image_id]");
          const chooser = $(
            `<input class="sr-only" accept=".png, .jpg, .jpeg,.webp" type="file" name="images">`
          );
          const uploadCard = form.find("#uploadCard");
    
          uploadCard.on("click", () => {
            chooser.trigger("click");
          });
    
          chooser.on("change", (e) => {
            const progress = uploadCard.find(".image-upload-progress");
            const r = new ImageUpload(e.currentTarget);
            r.data = {
              type: "image",
              action: "file_upload",
            };
            r.xhr = (evt) => {
              let c = (evt.loaded / evt.total) * 100;
              c = parseInt(c);
              progress
                .show()
                .find(".progress-bar")
                .width(c + "%");
            };
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                imageId.val(res.file_id).trigger("change"),
                  uploadCard
                    .find("#innerContent")
                    .html(
                      `<img src="${res.file_url}" class="img-fluid mh-100" >`
                    );
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.complete = () => progress.hide().find(".progress-bar").width(0);
            r.upload();
          });
    
          const F = new FormValidate(form, {
            url: {
              url: {
                text: "Url is not a valid url",
              },
            },
          });
          F.onValidate = () => {
            const r = new Ajax();
            r.data =
              form.serialize() +
              formString({
                component_id:component_id,
                case: "add_sliders_slide",
                action: "home_page_settings",
              });
            r.url = ajax_url.a;
            r.before = () => disableElement(form, 2);
            r.complete = () => enableElement(form);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                resetForm(form);
                form.html(original);
                sweetAlert("success", res.message), success(res);
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.send();
          };
        },
      },
      ManualSliders: {
        init() {
          const addSlider = $("#addSlider");
          addSlider.on("click", () => {
            const r = new Ajax();
            r.data = {
              case: "create_new_manual_slider",
              action: "home_page_settings",
            };
            r.before = () => disableBtn(addSlider);
            r.complete = () => enableBtn(addSlider);
            r.url = ajax_url.a;
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                const card = $(res.card);
                $("#sliders").append(card);
                removeTooltips();
                LXApp.initBootstrapTooltips();
                
                sweetAlert("success","New slider has been created");
                $('html, body').animate({
                  scrollTop: card.offset().top
              }, 500);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.send();
          });
    
          $("body").on("click", '[data-action="delete_slider"]', (e) => {
            const t = $(e.currentTarget);
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data = {
              component_id:t.data("component_id"),
              case: "delete_manual_slider",
              action: "home_page_settings",
            };
            r.before = () => disableBtn(t, "no-text");
            r.complete = () => enableBtn(t);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message);
                remove(t.closest(".card"));
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            const c = new Confirm();
            c.ok = () => r.send();
            c.show();
          });
    
          // Update
          const updateSliderDetailsModal = $("#updateSliderDetails");
          $("body").on("click", '[data-action="update_slider"]', (e) => {
            const t = $(e.currentTarget);
            const heading = t.data("heading");
            const columns = t.data("columns");
            const tab_columns = t.data("tab_columns");
            const mobile_columns = t.data("mobile_columns");
            const card = t.closest(".card");
    
            updateSliderDetailsModal.modal("show");
    
            const form = updateSliderDetailsModal.find("form");
            form.off();
            form.find("input[name=heading]").val(heading);
            form.find("input[name=columns]").val(columns);
            form.find("input[name=tab_columns]").val(tab_columns);
            form.find("input[name=mobile_columns]").val(mobile_columns);
    
            const F = new FormValidate(form);
            F.onValidate = () => {
              const r = new Ajax();
              r.url = ajax_url.a;
              r.data =
                form.serialize() +
                formString({
                  component_id:t.data("component_id"),
                  case: "update_manual_slider",
                  action: "home_page_settings",
                });
              r.before = () => disableElement(form);
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  sweetAlert("success", res.message);
                  updateSliderDetailsModal.modal("hide");
                  card.find(".slider-heading").html(res.heading);
                  t.data("heading", res.heading);
                  t.data("columns", res.columns);
                  t.data("mobile_columns", res.mobile_columns);
                  t.data("tab_columns", res.tab_columns);
                  resetForm(form);
                } catch (error) {
                  cl(error);
                  sweetAlert("error", res);
                }
              };
              r.complete = () => enableElement(form);
              r.send();
            };
          });
    
          const addSliderSlideModal = $("#addSliderSlideModal");
          const form = addSliderSlideModal.find("form");
          const originalFormHtml = form.html();
    
          $("body").on("click", '[data-action="add_slider_slide"]', (e) => {
            const t = $(e.currentTarget);
            const component_id = t.data("component_id");
            const card = t.closest(".card");
    
            addSliderSlideModal.modal("show");
            form.off();
            this.create(
              form,
              component_id,
              (res) => {
                addSliderSlideModal.modal("hide");
                card.find("tbody").html(res.content);
              },
              originalFormHtml
            );
          });
    
          // Update Slider Slide
          const updateSliderSlideModal = $("#updateSliderSlideModal");
          $("body").on("click", '[data-action="updateSliderSlide"]', (e) => {
            const t = $(e.currentTarget);
            const component_id= t.data("component_id");
            const key = $(e.currentTarget).data("key");
            const tr = $(e.currentTarget).closest("tr");
            const r = new Ajax();
            const card = t.closest(".card");
    
            r.url = ajax_url.a;
            r.data = {
              component_id:component_id,
              key: key,
              case: "get_manual_slider_slide_update_form",
              action: "home_page_settings",
            };
            r.before = () => disableElement(tr);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                updateSliderSlideModal.find(".modal-body").html(res.data);
                fillSelect();
                updateSliderSlideModal.modal("show");
                const form = updateSliderSlideModal.find("form");
                this.create(form, component_id, (res) => {
                  updateSliderSlideModal.modal("hide");
                  card.find("tbody").html(res.content);
                });
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.complete = () => enableElement(tr);
            r.send();
          });
    
          // Change Slider Slide Status
          $("body").on(
            "click",
            '[data-action="changeSliderSlideStatus"]',
            (e) => {
              const t = $(e.currentTarget);
              const component_id= t.data("component_id");
              const key = $(e.currentTarget).data("key");
              const tr = $(e.currentTarget).closest("tr");
              const r = new Ajax();
    
              r.url = ajax_url.a;
              r.data = {
                component_id:component_id,
                key: key,
                case: "change_manual_slider_slide_status",
                action: "home_page_settings",
              };
              r.before = () => disableElement(tr);
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  sweetAlert("success", res.message);
                  tr.find(".badge").replaceWith(res.badge);
                  t.replaceWith(res.button);
                  removeTooltips();
                  LXApp.initBootstrapTooltips();
                } catch (error) {
                  cl(error);
                  r.error();
                  sweetAlert("error", res);
                }
              };
              r.complete = () => enableElement(tr);
              r.send();
            }
          );
    
          // Delete Slider Image
          $("body").on("click", '[data-action="deleteSliderImage"]', (e) => {
            const t = $(e.currentTarget);
            const component_id= t.data("component_id");
            const key = $(e.currentTarget).data("key");
            const tr = $(e.currentTarget).closest("tr");
            const r = new Ajax();
    
            r.url = ajax_url.a;
            r.data = {
              component_id:component_id,
              key: key,
              case: "delete_manual_slider_slide",
              action: "home_page_settings",
            };
            r.before = () => disableElement(tr);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message);
                tr.remove();
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.error = () => enableElement(tr);
            const c = new Confirm();
            c.ok = () => r.send();
            c.show();
          });
        },
        create(form, component_id, success, originalFormHtml) {
          let select = form.find("select");
          if (select.hasClass("select2-hidden-accessible")) {
            select = select.data("select2");
            select.destroy();
          }
    
          const original = originalFormHtml || form.html();
          select2();
          const imageId = form.find("[name=image_id]");
          const chooser = $(
            `<input class="sr-only" accept=".png, .jpg, .jpeg,.webp" type="file" name="images">`
          );
          const uploadCard = form.find("#uploadCard");
    
          uploadCard.on("click", () => {
            chooser.trigger("click");
          });
    
          chooser.on("change", (e) => {
            const progress = uploadCard.find(".image-upload-progress");
            const r = new ImageUpload(e.currentTarget);
            r.data = {
              type: "image",
              action: "file_upload",
            };
            r.xhr = (evt) => {
              let c = (evt.loaded / evt.total) * 100;
              c = parseInt(c);
              progress
                .show()
                .find(".progress-bar")
                .width(c + "%");
            };
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                imageId.val(res.file_id).trigger("change"),
                  uploadCard
                    .find("#innerContent")
                    .html(
                      `<img src="${res.file_url}" class="img-fluid mh-100" >`
                    );
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.complete = () => progress.hide().find(".progress-bar").width(0);
            r.upload();
          });
    
          const F = new FormValidate(form, {
            url: {
              url: {
                text: "Url is not a valid url",
              },
            },
          });
          F.onValidate = () => {
            const r = new Ajax();
            r.data =
              form.serialize() +
              formString({
                component_id:component_id,
                case: "add_manual_sliders_slide",
                action: "home_page_settings",
              });
            r.url = ajax_url.a;
            r.before = () => disableElement(form, 2);
            r.complete = () => enableElement(form);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                resetForm(form);
                form.html(original);
                sweetAlert("success", res.message), success(res);
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.send();
          };
        },
      },
    },
    Layouts: {
      create(layout_id) {
        const chooseComponentModal = $("#chooseComponentModal");
        const content = $("#content");
        const contentHtml = content.html();

        $("body").on("click", "[data-choose]", (e) => {
          const t = $(e.currentTarget);
          const component = t.data("choose");
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data = {
            component: component,
            case: "get_layout_components",
            action: "layout_actions",
          };
          r.before = () => disableElement(t);
          r.complete = () => enableElement(t);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              $("#content").html(res.content);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        });

        $("body").on("click", "[data-component]", (e) => {
          const t = $(e.currentTarget);
          const component_id = t.data("component_id");
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data = {
            layout_id: layout_id,
            component_id: component_id,
            case: "add_layout_component",
            action: "layout_actions",
          };
          r.before = () => disableElement(t);
          r.complete = () => enableElement(t);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              chooseComponentModal.modal("hide");
              $("#pageComponents").html(res.layouts);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        });

        $("body").on("click", "[show-content]", () => {
          content.html(contentHtml);
        });

        // Sort
        const sortable = $("#pageComponents");

        sortable.sortable({
          placeholder: "ui-state-highlight",
          update: (event, ui) => {
            const index = [];

            sortable.find(">").each((f, e) => {
              index.push($(e).data("id"));
              $(e)
                .find(".index-text")
                .html(f + 1);
            });

            const r = new Ajax();
            r.url = ajax_url.a;
            r.data = {
              layout_id: layout_id,
              case: "update_components_order",
              action: "layout_actions",
              index: index,
            };
            r.success = (res) => {
              try {
                res = JSON.parse(res);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.send();
          },
        });
        sortable.disableSelection();

        // Delete
        $("body").on("click", '[data-action="delete"]', (e) => {
          const t = $(e.currentTarget);
          const layout_id = t.data("layout_id");
          const component_id = t.data("component_id");
          const r = new Ajax();
          const tr = t.closest(".bg-white");
          r.url = ajax_url.a;
          r.data = {
            layout_id: layout_id,
            component_id: component_id,
            case: "delete_layout_component",
            action: "layout_actions",
          };
          r.before = () => disableElement(tr);
          r.complete = () => enableElement(tr);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              remove(tr);
              sweetAlert("success", res.message);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };

          const c = new Confirm();
          c.ok = () => r.send();
          c.show();
        });
      },
    },
    PaymentSetting: () => {
      const modal = $("#updatePayment");
      const modalBody = modal.find(".modal-body");
      const title = modal.find(".title");

      $("body").on("click", '[data-action="edit"]', (e) => {
        const t = $(e.currentTarget);
        const id = t.data("id");
        const tr = t.closest("tr");
        const r = new Ajax();
        r.url = ajax_url.a;
        r.data = {
          case: "get_payment_method_details",
          action: "payment_method_actions",
          id: id,
        };
        r.before = () => disableElement(tr);
        r.complete = () => enableElement(tr);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            modal.modal("show"),
              modalBody.html(res.data),
              title.html(res.name),
              update(id, tr);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      });

      $("body").on("click", '[data-action="changeStatus"]', (e) => {
        const t = $(e.currentTarget);
        const id = t.data("id");
        const tr = t.closest("tr");
        const r = new Ajax();
        r.url = ajax_url.a;
        r.data = {
          case: "change_payment_method_status",
          action: "payment_method_actions",
          id: id,
        };
        r.before = () => disableElement(tr);
        r.complete = () => enableElement(tr);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            tr.find(".badge").replaceWith(res.badge),
              tr.find(".editWrapper").replaceWith(res.editWrapper),
              sweetAlert("success", res.message);
            tr.find(".last_modified").html(res.last_modified);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      });

      const update = (id, tr) => {
        select2();
        fillSelect();
        const form = modal.find("form");
        const F = new FormValidate(form);
        F.onValidate = () => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data =
            form.serialize() +
            formString({
              case: "update_payment_method",
              action: "payment_method_actions",
              id: id,
            });

          r.before = () => disableElement(form, 2);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message),
                modal.modal("hide"),
                tr.find(".last_modified").html(res.last_modified);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
          r.complete = () => enableElement(form);
        };
      };
    },
    Support: {
      init() {
        const t = $("#loginSessionTbl").DataTable({
          processing: true,
          serverSide: true,
          order: [[4, "desc"]],
          columns: [
            {
              data: null,
              orderable: false,
              render: function (data, type, row, meta) {
                return meta.row + meta.settings._iDisplayStart + 1;
              },
            },
            {
              data: "customer",
            },
            {
              data: "subject",
            },
            {
              data: "status",
            },
            {
              data: "created_at",
            },
            {
              data: "view",
            },
          ],
          ajax: {
            url: ajax_url.a,
            type: "POST",
            data: {
              action: "loadTblData",
              case: "userSupportTickets",
            },
          },
        });

        t.on("draw", () => select2());
      },
      addTicket() {
        const maxImages = 5;
        let currentImages = 0;
        let images = [];
        const form = $("#addTicketForm");
        const btn = form.find("#uploadImg");

        const check = () => {
          maxImages == currentImages
            ? btn.addClass("d-none")
            : btn.removeClass("d-none");
        };
        const inc = () => {
          currentImages += 1;
          check();
        };
        const dec = () => {
          currentImages -= 1;
          check();
        };
        const chooser = $(
          `<input class="sr-only" multiple type="file" name="images">`
        );
        btn.before(chooser);

        btn.on("click", () => {
          chooser.trigger("click");
        });

        chooser.on("change", (e) => {
          const t = e.target;
          const files = t.files;
          const required_files = maxImages - currentImages;

          for (var i = 0; i < files.length; i++) {
            if (i < required_files) {
              const preloader =
                $(`<div class="w-80px h-80px mr-3 position-relative justify-align-center opacity-100-hover bg-light review-img-upload" >
                                              <div class="image-upload-progress">
                                                  <div class="progress-bar"></div>
                                              </div>
                                              <span class="svg-icon svg-icon-muted svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                      <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="currentColor" />
                                                      <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="currentColor" />
                                                  </svg></span>
                                          </div>`);
              btn.before(preloader);
              const create = (res) => {
                const h =
                  $(`<div class="h-100" ><button type="button" class="delete-alt" title="Delete">
                                                  <i class="fas fa-times" ></i>
                                   </button>
                                   <img class="img-fluid mh-100" src="${res.preview_url}" alt="" srcset="">
                                   </div>`);
                preloader.html(h);
                res.showExt &&
                  h
                    .find("img")
                    .after(`<div class="center-xy fs-7" >${res.ext}</div>`);
                images.push(res.file_id);
                h.find("button").on("click", () => {
                  preloader.remove();
                  images = images.filter(function (item) {
                    return item !== res.file_id;
                  });
                  dec();
                });
              };
              inc();
              const p = preloader.find(".image-upload-progress");
              const r = new ImageUpload(e.currentTarget);
              r.url = ajax_url.a;
              r.fileIndex = i;
              r.name = "file";
              r.ext = [];
              r.data = {
                type: "file",
                action: "file_upload",
              };
              r.xhr = (evt) => {
                let c = (evt.loaded / evt.total) * 100;
                c = parseInt(c);
                p.show()
                  .find(".progress-bar")
                  .width(c + "%");
              };
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  create(res);
                } catch (e) {
                  sweetalert("error", e);
                }
              };
              r.error = (e) => {
                dec();
                preloader.remove();
              };
              r.complete = () => p.hide().find(".progress-bar").width(0);
              r.upload();
            }
          }
          //
        });

        const F = new FormValidate(form);
        F.onValidate = () => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.before = () => disableElement(form, 2);
          r.data =
            form.serialize() +
            formString({
              action: "support_actions",
              files: JSON.stringify(images),
            });
          r.error = () => enableElement(form);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              const url = res.url || undefined;
              locateTo(url, 1000);
            } catch (error) {
              cl(error);
              r.error();
              sweetAlert("error", res);
            }
          };
          r.send();
        };

        //Close Ticket
        $("#closeTicket").on("click", (e) => {
          const btn = $(e.currentTarget);
          const r = new Ajax();
          r.data = {
            ticket_id: $_GET["id"],
            action: "support_actions",
            case: "close_ticket",
          };
          r.url = ajax_url.a;
          r.before = () => disableBtn(btn);
          r.complete = () => enableBtn(btn);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              locateTo(undefined, 1000);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          const c = new Confirm();
          c.ok = () => r.send();
          c.okText = "Yes, Sure";
          c.text =
            "You want to close the ticket. You will be no longer able to reply";
          c.show();
        });
      },
    },
    QC: {
      init: function (status, order) {
        const columns = [
          {
            data: null,
            orderable: false,
            render: function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            },
          },
          {
            data: "product",
          },
          {
            data: "seller",
          },
          {
            data: "req_date",
          },
          {
            data: "status",
          },
          {
            data: "action",
          },
        ];

        status !== "pending" &&
          columns.splice(4, 0, {
            data: "res_date",
          });

        const t = $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[3, order]],
          columns: columns,
          ajax: {
            url: ajax_url.a,
            type: "POST",
            data: {
              status: status,
              action: "loadTblData",
              case: "qc_tbl",
            },
          },
        });
        t.on("draw", () => {
          select2();
        });
      },
      view: function (data) {
        (() => {
          const select = $("#return_policy");
          const days = $("#return_policy_days");
          const tc = $("#return_policy_tc");
          const val = select.val();
          val !== "no"
            ? (days.show(),
              tc.show(),
              days.find("[name=return_policy_days]").attr("required", true),
              tc.find("[name=return_policy_tc]").attr("required", true))
            : (days.hide(),
              tc.hide(),
              days.find("[name=return_policy_days]").attr("required", false),
              tc.find("[name=return_policy_tc]").attr("required", false));
        })();

        data = JSON.parse(data);
        const z = {
          images: data,
        };
        const miniImgUpload = $("#miniImgUpload");
        const mainImgUpload = $("#mainImgUpload");
        const mainImgUploadHtml = mainImgUpload.html();

        let resetUploader = () => {
          mainImgUpload.html(mainImgUploadHtml);
        };

        const createImg = (cI, i, s) => {
          z.images[cI].id = i;
          z.images[cI].src = s;
          z.images[cI].create(s);

          mainImgUpload.find("img").attr("src", s);

          if (z.images[cI].type == "video") {
            resetUploader();
            mainImgUpload.find("img").remove();
            mainImgUpload.append(
              `<video controls class="mw-100 mh-100" src="${s}" ></video>`
            );
          }
        };

        // Tags
        const tagInput = $("#tags");
        const maxTagLength = 500;
        const tagIns = new Tagify(tagInput[0], {
          dropdown: {
            classname: "tagify__inline__suggestions",
            enabled: 0,
            closeOnSelect: !1,
          },
        });

        miniImgUpload.find("> div").each((f, e) => {
          const t = $(e);
          const cI = t.data("index");
          const type = t.data("type") == "video" ? "video" : "image";

          z.images[cI].type = type;
          z.images[cI].create = (s) => {
            type == "image" &&
              t.html(`<div class="bottom-inherit image-upload-progress top-0">
                                                              <div class="progress-bar h-3px"></div>
                                                          </div><img class="img-fluid mh-100" src="${s}" >`);
            type == "video" &&
              t.find(".svg-icon").addClass("border border-5 border-muted br-50")
                .html(`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                  <path d="M16.9 10.7L7 5V19L16.9 13.3C17.9 12.7 17.9 11.3 16.9 10.7Z" fill="currentColor"/>
                                                  </svg>`);
          };
          t.on("click", () => {
            const cl = "active border-bottom border-warning border-2";
            miniImgUpload.find("> div").removeClass(cl);
            t.addClass(cl);
            resetUploader();
            is_empty(z.images[cI].id) ||
              createImg(cI, z.images[cI].id, z.images[cI].src);
          });
          is_empty(z.images[cI].id) || z.images[cI].create(z.images[cI].src);
          if (cI == 1 && !is_empty(z.images[1].id))
            createImg(1, z.images[1].id, z.images[1].src);
        });

        $("#approveQC").on("click", (e) => {
          const r = new Ajax();
          r.url = ajax_url.a;
          r.data = {
            case: "approve_qc",
            action: "qc_actions",
            qc_id: $_GET["id"],
          };
          r.before = () => disableBtn(e.currentTarget);
          r.error = () => enableBtn(e.currentTarget);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message), locateTo(res.url);
            } catch (error) {
              cl(error);
              r.error();
              sweetAlert("error", res);
            }
          };
          const c = new Confirm();
          c.ok = () => r.send();
          c.okText = "Yes Approve";
          c.cancelText = "Cancel";
          c.okClass = "btn-success";
          c.iconColor = "success";
          c.text = "You want to verify this product";
          c.show();
        });

        {
          const modal = $("#rejectQcModal");
          const form = modal.find("form");

          let checkedError = 0;
          const ei = form.find("input[name=errorInput]");
          form.find(".error-item").each((f, e) => {
            const t = $(e);
            const i = t.find("input[type=checkbox]");
            const input = $(
              `<input type="hidden" value="${i.val()}" name="error_portions[]" >`
            );
            i.on("change", () => {
              const isChecked = i.prop("checked");
              !isChecked
                ? (input.remove(),
                  checkedError--,
                  checkedError == 0 && ei.val("").trigger("change"))
                : (form.append(input),
                  checkedError++,
                  ei.val(checkedError).trigger("change"));
            });
          });

          const F = new FormValidate(form);
          F.onValidate = () => {
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data =
              form.serialize() +
              formString({
                case: "reject_qc",
                action: "qc_actions",
                qc_id: $_GET["id"],
              });
            r.before = () => disableElement(form, 2);
            r.error = () => enableElement(form);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message), locateTo(res.url);
              } catch (error) {
                cl(error);
                r.error();
                sweetAlert("error", res);
              }
            };
            r.send();
          };
        }
      },
    },
    CustomPages:{
      init()
      {

        const createPage = (form, id, modal, event) =>{
          
          const F = new FormValidate(form);
          F.onValidate = () => {
            const r = new Ajax();
            r.url = ajax_url.a;
            r.data =
              form.serialize() +
              formString({
                layout_id: id,
                event: event,
                case: "create_custom_page",
                action: "layout_actions",
              });
            r.before = () => disableElement(form);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
              $("tbody").html(res.content);
              resetForm(form);
              modal.modal("hide");
              removeTooltips();
              LXApp.initBootstrapTooltips();
              sweetAlert("success",res.message);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.complete = () => enableElement(form);
            r.send();
          };
        }

        const createCustomPageModal = $("#createCustomPage");
        const form = createCustomPageModal.find("form");
        createPage(form, null, createCustomPageModal, "create");

        // Update
        const updatePageModal = $("#updatePageModal");
        $("body").on("click", '[data-action="update_page"]', (e) => {
          const t = $(e.currentTarget);
          const name = t.data("name");
          const status = t.data("status");
          updatePageModal.modal("show");

          const form = updatePageModal.find("form");
          form.off();
          form.find("input[name=name]").val(name);
          form.find("select[name=status]").attr("value",status);
          fillSelect();
          createPage(form, t.data("layout_id"), updatePageModal, "update");
        });

        // Change Status
        $("body").on("click", '[data-action="changeStatus"]', (e) => {
          const t = $(e.currentTarget);
          const layout_id = t.data("layout_id");
          const tr = $(e.currentTarget).closest("tr");
          const r = new Ajax();

          r.url = ajax_url.a;
          r.data = {
            layout_id: layout_id,
            case: "change_custom_page_status",
            action: "layout_actions",
          };
          r.before = () => disableElement(tr);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              tr.find(".badge").replaceWith(res.badge);
              t.closest("td").html(res.buttons);
              removeTooltips();
              LXApp.initBootstrapTooltips();
            } catch (error) {
              cl(error);
              r.error();
              sweetAlert("error", res);
            }
          };
          r.complete = () => enableElement(tr);
          r.send();
        });

        // Delete Page
        $("body").on("click", '[data-action="deletePage"]', (e) => {
          const t = $(e.currentTarget);
          const layout_id = t.data("layout_id");
          const tr = $(e.currentTarget).closest("tr");
          const r = new Ajax();

          r.url = ajax_url.a;
          r.data = {
            layout_id: layout_id,
            case: "delete_custom_page",
            action: "layout_actions",
          };
          r.before = () => disableElement(tr);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              tr.remove();
            } catch (error) {
              cl(error);
              r.error();
              sweetAlert("error", res);
            }
          };
          r.error = () => enableElement(tr);
          const c = new Confirm();
          c.ok = () => r.send();
          c.show();
        });
        

      }
    }
  };

  _.CreateListing = {
    init: function () {
      $(".category-list.next").each((f, e) => {
        const t = $(e);
        const id = t.data("id");
        t.on("click", () => {
          const r = new Ajax();
          r.url = ajax_url.s;
          r.data = {
            category_id: id,
            case: "fetch_categories",
            action: "create_listing",
          };
          r.before = () => disableElement(t);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              $("#catCont").html(res.data),
                $("#catHeader").html(res.header),
                this.init();
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
          r.complete = () => enableElement(t);
        });
      });

      $(".category-list.create").each((f, e) => {
        const t = $(e);
        const id = t.data("id");
        t.find(".btn").on("click", () => {
          const r = new Ajax();
          r.url = ajax_url.s;
          r.data = {
            category_id: id,
            case: "fetch_category_images",
            action: "create_listing",
          };
          r.before = () => disableElement(t);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              $("#catCont").html(res.content),
                $("#catHeader").html(res.header),
                this.init();
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
          r.complete = () => enableElement(t);
        });
      });

      $("#continue_to_listing").on("click", (e) => {
        const t = $(e.currentTarget);
        const id = t.data("id");
        const r = new Ajax();
        r.url = ajax_url.s;
        r.data = {
          category_id: id,
          case: "create_listing",
          action: "create_listing",
        };
        r.before = () => disableBtn(t);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            locateTo(res.url);
          } catch (error) {
            cl(error);
            r.error();
            sweetAlert("error", res);
          }
        };
        r.send();
        r.error = () => enableBtn(t);
      });
    },
    create: function (data) {
      const check_changes = (eve) => {
        if (eve == "saved") {
          window.onbeforeunload = "";

          $('[data-replace="true"]')
            .off()
            .on("click", (e) => {
              e.originalEvent.stopImmediatePropagation();
              e.originalEvent.preventDefault();
              locateToAnchorUrl($(e.currentTarget));
            });
        } else {
          window.onbeforeunload = function (e) {
            return "Are you sure you want to leave this page?  You will lose any unsaved data.";
          };

          $('[data-replace="true"]')
            .off()
            .on("click", (e) => {
              e.originalEvent.stopImmediatePropagation();
              e.originalEvent.preventDefault();
              const c = new Confirm();
              c.text = "You'll loss all the unsaved changes";
              c.okText = "Yes, I'm sure";
              c.ok = () => locateToAnchorUrl($(e.currentTarget));
              c.show();
            });
        }
      };

      $("body").on("change input", "input", () => {
        check_changes("unsaved");
      });
      $("body").on("change input", "textarea", () => {
        check_changes("unsaved");
      });

      data = JSON.parse(data);
      const listing_id = data.listing_id;
      const vid = data.variation_id;
      const sid = data.svariation_id;
      const modal = $("#createVariationModal");

      if (!is_empty(data.error_portions)) {
        const error_portions = data.error_portions;
        error_portions.forEach((e) => {
          $(`.card[data-portion=${e}]`).addClass("border danger-active");
        });
      }

      $('[data-trigger="createVariation"]').on("click", (e) => {
        const t = $(e.currentTarget);
        const r = new Ajax();
        r.url = ajax_url.s;
        r.data = {
          listing_id: listing_id,
          variation_id: vid,
          svariation_id: sid,
          role: t.data("role"),
          case: "get_create_variation_form",
          action: "create_listing",
        };
        r.before = () => disableElement(t);
        r.complete = () => enableElement(t);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            modal.modal("show").find(".modal-header h2").html(res.card_header),
              modal.find("form").html(res.card),
              select2(),
              CV(t.data("role"));
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      });

      const form = modal.find("form");
      const F = new FormValidate(form);
      F.onValidate = () => {
        const r = new Ajax();
        r.url = ajax_url.s;
        r.data =
          form.serialize() +
          formString({
            listing_id: listing_id,
            svariation_id: sid,
            variation_id: vid,
            case: "create_variation",
            action: "create_listing",
          });
        r.before = () => disableElement(form);
        r.error = () => enableElement(form);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            locateTo(res.url);
          } catch (error) {
            cl(error);
            r.error();
            sweetAlert("error", res);
          }
        };
        r.send();
      };

      const im = data.images;

      const CV = (role) => {
        if (data.parent_type === "image" || data.child_type === "image") {
          const createVariation = $("#createVariation");
          const variationChoose = $("#variationChoose");

          createVariation.on("click", () => variationChoose.trigger("click"));
          variationChoose.on("change", (e) => {
            const p = createVariation.find(".image-upload-progress");
            const r = new ImageUpload(e.currentTarget);
            r.url = ajax_url.s;
            r.data = {
              event_type: role,
              listing_id: listing_id,
              svariation_id: sid,
              variation_id: vid,
              variation_value: "img",
              case: "create_variation",
              action: "create_listing",
            };
            r.xhr = (evt) => {
              let c = (evt.loaded / evt.total) * 100;
              c = parseInt(c);
              p.show()
                .find(".progress-bar")
                .width(c + "%");
            };
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                locateTo(res.url);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.complete = () => p.hide().find(".progress-bar").width(0);
            r.upload();
          });
        }
      };

      const z = {
        details: {},
        images: {
          1: {
            id: null,
            src: null,
            type: "image",
          },
          2: {
            id: null,
            src: null,
            type: "image",
          },
          3: {
            id: null,
            src: null,
            type: "image",
          },
          4: {
            id: null,
            src: null,
            type: "image",
          },
          5: {
            id: null,
            src: null,
            type: "image",
          },
          6: {
            id: null,
            src: null,
            type: "image",
          },
          7: {
            id: null,
            src: null,
            type: "image",
          },
          8: {
            id: null,
            src: null,
            type: "video",
          },
        },
        variation: [],
      };

      isObject(im) && (z.images = im);
      {
        const Imgs = {
          1: {},
          2: {},
          3: {},
          4: {},
          5: {},
          6: {},
          7: {},
          8: {},
        };
        // Upload
        const miniImgUpload = $("#miniImgUpload");
        const mainImgUpload = $("#mainImgUpload");
        const mainImgUploadHtml = mainImgUpload.html();
        let currentIndex = 1;
        let uploadBtn = mainImgUpload.find("button");

        let resetUploader = () => {
          mainImgUpload.html(mainImgUploadHtml);
          uploadBtn = mainImgUpload.find("button");
          uploadBtn.on("click", () => {
            Imgs[currentIndex].upload();
          });
          if (z.images[currentIndex].type == "video") {
            uploadBtn.find("span").html("Upload Video");
          }
        };
        const createImg = (cI, i, s) => {
          const del =
            $(`<button type="button" class="btn btn-icon btn-bg-light opacity-90-hover btn-sm position-absolute end-0 top-0" >
                    <span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="currentColor"/>
                    <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="currentColor"/>
                    <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="currentColor"/>
                    </svg></span></button>`);

          z.images[cI].id = i;
          z.images[cI].src = s;
          Imgs[cI].create(s);

          uploadBtn.find("span").html("Change Image");
          mainImgUpload.find("img").attr("src", s);
          mainImgUpload.append(del);

          if (z.images[cI].type == "video") {
            resetUploader();
            mainImgUpload.append(del);
            uploadBtn.find("span").html("Change Video");
            mainImgUpload.find("img").remove();
            mainImgUpload.append(
              `<video controls class="mw-100 mh-100" src="${s}" ></video>`
            );
          }

          del.on("click", () => {
            z.images[cI].id = null;
            z.images[cI].src = null;
            Imgs[cI].reset();
            resetUploader();
          });
        };
        miniImgUpload.find("> div").each((f, e) => {
          const t = $(e);
          const cI = t.data("index");
          const oH = t.html();
          const type = t.data("type") == "video" ? "video" : "image";

          const chooser =
            type == "image"
              ? $(
                  `<input class="sr-only" accept=".png, .jpg, .jpeg,.webp" type="file" name="images">`
                )
              : $(
                  `<input class="sr-only" accept=".mp4" type="file" name="images">`
                );
          z.images[cI].type = type;
          t.before(chooser);
          chooser.on("change", (e) => {
            const imageUploadProgress = t.find(".image-upload-progress");
            const r = new ImageUpload(e.currentTarget);
            r.url = ajax_url.s;
            type == "video" && ((r.ext = ["mp4"]), (r.name = "video"));
            r.data = {
              type: type,
              action: "file_upload",
            };
            r.xhr = (evt) => {
              let c = (evt.loaded / evt.total) * 100;
              c = parseInt(c);
              imageUploadProgress
                .show()
                .find(".progress-bar")
                .width(c + "%");
            };
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                createImg(cI, res.file_id, res.file_url, type);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.complete = () =>
              imageUploadProgress.hide().find(".progress-bar").width(0);
            r.upload();
          });
          Imgs[cI].reset = () => t.html(oH);
          Imgs[cI].create = (s) => {
            type == "image" &&
              t.html(`<div class="bottom-inherit image-upload-progress top-0">
                                                            <div class="progress-bar h-3px"></div>
                                                        </div><img class="img-fluid mh-100" src="${s}" >`);
            type == "video" &&
              t.find(".svg-icon").addClass("border border-5 border-muted br-50")
                .html(`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <path d="M16.9 10.7L7 5V19L16.9 13.3C17.9 12.7 17.9 11.3 16.9 10.7Z" fill="currentColor"/>
                                                </svg>`);
          };
          t.on("click", () => {
            if (t.hasClass("active")) Imgs[cI].upload();
            const cl = "active border-bottom border-warning border-2";
            miniImgUpload.find("> div").removeClass(cl);
            currentIndex = cI;
            t.addClass(cl);
            resetUploader();
            is_empty(z.images[cI].id) ||
              createImg(cI, z.images[cI].id, z.images[cI].src);
          });

          Imgs[cI].upload = () => {
            chooser.trigger("click");
          };

          if (typeof im === "object") {
            is_empty(z.images[cI].id) || Imgs[cI].create(z.images[cI].src);
            if (cI == 1 && !is_empty(z.images[1].id))
              createImg(1, z.images[1].id, z.images[1].src);
          }
        });
        uploadBtn.on("click", () => {
          Imgs[currentIndex].upload();
        });
      }

      // Save Details
      const listingForm = $("#listingForm");
      const A = new FormValidate(listingForm);
      A.onValidate = () => {
        $("[data-detail-id]").each((f, e) => {
          const t = $(e);
          const id = t.data("detail-id");
          const v = t.val();
          z.details[id] = v;
        });

        const r = new Ajax();
        r.url = ajax_url.s;
        r.data =
          listingForm.serialize() +
          formString({
            variation_id: vid,
            listing_id: listing_id,
            svariation_id: sid,
            data: z,
            case: "save_variation",
            action: "create_listing",
          });
        r.before = () => disableElement(listingForm, 2);
        r.complete = () => enableElement(listingForm);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message), check_changes("saved");
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      };

      const card = $("#repeater");
      const btn = card.find("[data-repeater-create]");
      let currentHighlights = card.find('[data-repeater-item=""]').length - 1;
      const maxHighlights = 10;
      maxHighlights == currentHighlights && btn.addClass("d-none");
      $("#repeater").repeater({
        initEmpty: true,
        show: function () {
          currentHighlights += 1;
          maxHighlights == currentHighlights && btn.addClass("d-none");
          $(this).slideDown();
          $(this).find("input").attr("name", "highlights[]");
        },
        hide: function (e) {
          currentHighlights -= 1;
          maxHighlights == currentHighlights || btn.removeClass("d-none");
          $(this).slideUp(e);
        },
      });

      // Tags
      const tagInput = $("#tags");
      const maxTagLength = 500;
      const tagIns = new Tagify(tagInput[0], {
        dropdown: {
          classname: "tagify__inline__suggestions",
          enabled: 0,
          closeOnSelect: !1,
        },
      });

      tagIns.on("add", (e) => {
        checkTagButtons();
        getTagLength() > maxTagLength && tagIns.removeTag(e.detail.tag);
      });
      tagIns.on("remove", () => {
        checkTagButtons();
      });

      const getTagLength = () => {
        let value = tagInput.val();
        let length = 0;
        let tags = [];
        try {
          value = JSON.parse(value);
          Array.isArray(value) &&
            value.forEach((e) => {
              length += e.value.length;
            });
        } catch (error) {
          cl(error);
        }
        return length;
      };

      const copyTag = $("#copyTag");
      const removeAllTag = $("#removeAllTag");
      copyTag.on("click", (e) => {
        try {
          let value = tagInput.val();
          let tags = [];
          value = JSON.parse(value);
          Array.isArray(value) &&
            value.forEach((e) => {
              tags.push(e.value);
            });
          tags = tags.join(",");

          navigator.clipboard.writeText(tags);
          sweetAlert("success", "Tags has been copied to clipboard");
        } catch (error) {
          cl(error);
        }
      });
      removeAllTag.on("click", () => {
        tagIns.removeAllTags();
        checkTagButtons();
      });

      const checkTagButtons = () => {
        const length = getTagLength();
        if (length) {
          copyTag.removeClass("d-none");
          removeAllTag.removeClass("d-none");
        } else {
          copyTag.addClass("d-none");
          removeAllTag.addClass("d-none");
        }
      };
      checkTagButtons();

      $("#sendToQc").on("click", (e) => {
        const r = new Ajax();
        r.url = ajax_url.s;
        r.data = {
          svariation_id: "all",
          variation_id: vid,
          listing_id: listing_id,
          case: "send_to_qc",
          action: "create_listing",
        };
        r.before = () => disableBtn(e.currentTarget);
        r.complete = () => enableBtn(e.currentTarget);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            res.error == "true"
              ? locateTo(res.url)
              : (sweetAlert("success", res.message), locateTo(undefined, 2000));
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      });

      $("#send_svariation_to_qc").on("click", (e) => {
        const r = new Ajax();
        r.url = ajax_url.s;
        r.data = {
          svariation_id: sid,
          variation_id: vid,
          listing_id: listing_id,
          case: "send_to_qc",
          action: "create_listing",
        };
        r.before = () => disableBtn(e.currentTarget);
        r.complete = () => enableBtn(e.currentTarget);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            res.error == "true"
              ? locateTo(res.url)
              : (sweetAlert("success", res.message), locateTo(undefined, 2000));
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      });
      {
        const select = $("#return_policy");
        const days = $("#return_policy_days");
        const tc = $("#return_policy_tc");

        const C = () => {
          const val = select.val();
          !is_empty(val) && val !== "no"
            ? (days.show(),
              tc.show(),
              days.find("[name=return_policy_days]").attr("required", true),
              tc.find("[name=return_policy_tc]").attr("required", true))
            : (days.hide(),
              tc.hide(),
              days.find("[name=return_policy_days]").attr("required", false),
              tc.find("[name=return_policy_tc]").attr("required", false));
        };
        select.on("change", () => C());
        C();
      }

      $("#archive_variation").on("click", (e) => {
        const t = $(e.currentTarget);
        const r = new Ajax();
        r.url = ajax_url.s;
        r.data = {
          variation_id: vid,
          listing_id: listing_id,
          svariation_id: sid,
          case: "archive_variation",
          action: "create_listing",
        };
        r.before = () => disableElement(t);
        r.complete = () => enableElement(t);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message),
              t.html(res.text),
              $("#statusWrapper").html(res.statusLabel);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      });

      $("#archive_svariation").on("click", (e) => {
        const t = $(e.currentTarget);
        const r = new Ajax();
        r.url = ajax_url.s;
        r.data = {
          variation_id: vid,
          listing_id: listing_id,
          svariation_id: sid,
          case: "archive_svariation",
          action: "create_listing",
        };
        r.before = () => disableElement(t);
        r.complete = () => enableElement(t);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message),
              t.html(res.text),
              $("#statusWrapper").html(res.statusLabel);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      });

      $("#delete_variation").on("click", (e) => {
        const t = $(e.currentTarget);
        const r = new Ajax();
        r.url = ajax_url.s;
        r.data = {
          variation_id: vid,
          listing_id: listing_id,
          case: "delete_variation",
          action: "create_listing",
        };
        r.before = () => disableElement(t);
        r.complete = () => enableElement(t);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message), locateTo(res.url, 1000);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        const c = new Confirm();
        c.ok = () => r.send();
        c.text = "You want to delete this listing?";
        c.show();
      });

      $("#delete_svariation").on("click", (e) => {
        const t = $(e.currentTarget);
        const r = new Ajax();
        r.url = ajax_url.s;
        r.data = {
          variation_id: vid,
          svariation_id: sid,
          listing_id: listing_id,
          case: "delete_svariation",
          action: "create_listing",
        };
        r.before = () => disableElement(t);
        r.complete = () => enableElement(t);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message), locateTo(res.url, 1000);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        const c = new Confirm();
        c.text = "You want to delete this listing?";
        c.ok = () => r.send();
        c.show();
      });

      $("#clone_variation").on("click", (e) => {
        const t = $(e.currentTarget);
        const r = new Ajax();
        r.url = ajax_url.s;
        r.data = {
          variation_id: vid,
          svariation_id: sid,
          listing_id: listing_id,
          case: "clone_variation",
          action: "create_listing",
        };
        r.before = () => disableElement(t);
        r.complete = () => enableElement(t);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            modal.modal("show").find(".modal-header h2").html(res.card_header),
              modal.find("form").html(res.card),
              select2(),
              UI();
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      });

      $("#clone_svariation").on("click", (e) => {
        const t = $(e.currentTarget);
        const r = new Ajax();
        r.url = ajax_url.s;
        r.data = {
          variation_id: vid,
          svariation_id: sid,
          listing_id: listing_id,
          case: "clone_svariation",
          action: "create_listing",
        };
        r.before = () => disableElement(t);
        r.complete = () => enableElement(t);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            modal.modal("show").find(".modal-header h2").html(res.card_header),
              modal.find("form").html(res.card),
              select2();
            UI();
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      });

      const UI = () => {
        const c = modal.find("#createVariation");
        const v = modal.find("#variationChoose");

        c.off().on("click", () => v.trigger("click"));
        v.off().on("change", (e) => {
          const p = c.find(".image-upload-progress");
          const r = new ImageUpload(e.currentTarget);
          r.url = ajax_url.s;
          r.data = {
            type: "image",
            action: "file_upload",
          };
          r.xhr = (evt) => {
            let c = (evt.loaded / evt.total) * 100;
            c = parseInt(c);
            p.show()
              .find(".progress-bar")
              .width(c + "%");
          };
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              modal.find('input[name="variation_value"]').val(res.file_id),
                c.html(`<div class="bottom-inherit image-upload-progress top-0">
                            <div class="progress-bar h-3px"></div>
                        </div><img class="img-fluid" src="${res.file_url}" >`);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.complete = () => p.hide().find(".progress-bar").width(0);
          r.upload();
        });

        let checked = 0;
        const form = modal.find("form");
        form.find(".choose-svariation-card").each((f, e) => {
          const t = $(e);
          const i = t.find("input[type=checkbox]");
          const s = form.find("#checked_svariations");
          const svariation_input = $(
            `<input class="d-none" value="${i.val()}" name="svariations[]" >`
          );

          t.on("click", () => {
            const isChecked = i.prop("checked");
            isChecked
              ? (svariation_input.remove(),
                checked--,
                checked == 0 && s.val(""),
                i.prop("checked", false),
                t.removeClass("success-active"))
              : (checked++,
                s.val(i.val()),
                form.append(svariation_input),
                i.prop("checked", true),
                t.addClass("success-active"));
          });
        });
      };
    },
    analytics: function (xp) {
      xp = JSON.parse(xp);
      const { listing_id, variation_id, svariation_id } = xp;

      // VIEWS
      (() => {
        let hasRenderChart = false;
        let graphData;

        let e = document.querySelector(
            '[data-lx-daterangepicker="true"][data-target=views]'
          ),
          t = moment().subtract(29, "days"),
          n = moment();

        let i = e.querySelector("div"),
          r = e.hasAttribute("data-lx-daterangepicker-opens")
            ? e.getAttribute("data-lx-daterangepicker-opens")
            : "left",
          g = function (a) {
            return a.format("MM/DD/YYYY");
          },
          o = function (e, t) {
            i &&
              (i.innerHTML =
                e.format("D MMM YYYY") + " - " + t.format("D MMM YYYY"));
            const r = new Ajax();
            r.url = ajax_url.s;
            r.data = {
              from: g(e),
              to: g(t),
              listing_id: listing_id,
              variation_id: variation_id,
              svariation_id: svariation_id,
              case: "single_product_views_graph",
              action: "analytics",
            };
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                renderChart(res);
              } catch (error) {
                cl(error);
              }
            };
            r.send();
          };
        $(e).daterangepicker(
          {
            startDate: t,
            endDate: n,
            opens: r,
            ranges: {
              Today: [moment(), moment()],
              Yesterday: [
                moment().subtract(1, "days"),
                moment().subtract(1, "days"),
              ],
              "Last 7 Days": [moment().subtract(6, "days"), moment()],
              "Last 30 Days": [moment().subtract(29, "days"), moment()],
              "This Month": [
                moment().startOf("month"),
                moment().endOf("month"),
              ],
              "Last Month": [
                moment().subtract(1, "month").startOf("month"),
                moment().subtract(1, "month").endOf("month"),
              ],
            },
          },
          o
        ),
          o(t, n);

        const renderChart = (graph) => {
          if (hasRenderChart) {
            graphData.destroy();
          }

          $("#product_views_chart_count").html(graph.views);
          let chart = document.getElementById("product_views_chart");
          let height = parseInt(LXUtil.css(chart, "height")),
            color1 = LXUtil.getCssVariableValue("--bs-gray-500"),
            color2 = LXUtil.getCssVariableValue("--bs-border-dashed-color"),
            color3 = LXUtil.getCssVariableValue("--bs-primary"),
            color4 = LXUtil.getCssVariableValue("--bs-primary"),
            info = chart.getAttribute("data-lx-chart-info"),
            chartInstance = new ApexCharts(chart, {
              series: [
                {
                  name: info,
                  data: graph.y,
                },
              ],
              chart: {
                fontFamily: "inherit",
                type: "area",
                height: height,
                toolbar: {
                  show: !1,
                },
              },
              legend: {
                show: !1,
              },
              dataLabels: {
                enabled: !1,
              },
              fill: {
                type: "gradient",
                gradient: {
                  shadeIntensity: 1,
                  opacityFrom: 0.4,
                  opacityTo: 0,
                  stops: [0, 80, 100],
                },
              },
              stroke: {
                curve: "smooth",
                show: !0,
                width: 3,
                colors: [color3],
              },
              xaxis: {
                categories: graph.x,
                axisBorder: {
                  show: !1,
                },
                axisTicks: {
                  show: !1,
                },
                tickAmount: 6,
                labels: {
                  rotate: 0,
                  rotateAlways: !0,
                  style: {
                    colors: color1,
                    fontSize: "12px",
                  },
                },
                crosshairs: {
                  position: "front",
                  stroke: {
                    color: color3,
                    width: 1,
                    dashArray: 3,
                  },
                },
                tooltip: {
                  enabled: !0,
                  formatter: void 0,
                  offsetY: 0,
                  style: {
                    fontSize: "12px",
                  },
                },
              },
              yaxis: {
                tickAmount: 6,
                labels: {
                  style: {
                    colors: color1,
                    fontSize: "12px",
                  },
                },
              },
              states: {
                normal: {
                  filter: {
                    type: "none",
                    value: 0,
                  },
                },
                hover: {
                  filter: {
                    type: "none",
                    value: 0,
                  },
                },
                active: {
                  allowMultipleDataPointsSelection: !1,
                  filter: {
                    type: "none",
                    value: 0,
                  },
                },
              },
              tooltip: {
                style: {
                  fontSize: "12px",
                },
              },
              colors: [color4],
              grid: {
                borderColor: color2,
                strokeDashArray: 4,
                yaxis: {
                  lines: {
                    show: !0,
                  },
                },
              },
              markers: {
                strokeColor: color3,
                strokeWidth: 3,
              },
            });
          chartInstance.render();
          hasRenderChart = true;
          graphData = chartInstance;
        };
      })();

      // SELLS
      (() => {
        let hasRenderChart = false;
        let graphData;

        let e = document.querySelector(
            '[data-lx-daterangepicker="true"][data-target=sells]'
          ),
          t = moment().subtract(29, "days"),
          n = moment();

        let i = e.querySelector("div"),
          r = e.hasAttribute("data-lx-daterangepicker-opens")
            ? e.getAttribute("data-lx-daterangepicker-opens")
            : "left",
          g = function (a) {
            return a.format("MM/DD/YYYY");
          },
          o = function (e, t) {
            i &&
              (i.innerHTML =
                e.format("D MMM YYYY") + " - " + t.format("D MMM YYYY"));
            const r = new Ajax();
            r.url = ajax_url.s;
            r.data = {
              from: g(e),
              to: g(t),
              listing_id: listing_id,
              variation_id: variation_id,
              svariation_id: svariation_id,
              case: "single_product_sells_graph",
              action: "analytics",
            };
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                renderChart(res);
              } catch (error) {
                cl(error);
              }
            };
            r.send();
          };
        $(e).daterangepicker(
          {
            startDate: t,
            endDate: n,
            opens: r,
            ranges: {
              Today: [moment(), moment()],
              Yesterday: [
                moment().subtract(1, "days"),
                moment().subtract(1, "days"),
              ],
              "Last 7 Days": [moment().subtract(6, "days"), moment()],
              "Last 30 Days": [moment().subtract(29, "days"), moment()],
              "This Month": [
                moment().startOf("month"),
                moment().endOf("month"),
              ],
              "Last Month": [
                moment().subtract(1, "month").startOf("month"),
                moment().subtract(1, "month").endOf("month"),
              ],
            },
          },
          o
        ),
          o(t, n);

        const renderChart = (graph) => {
          if (hasRenderChart) {
            graphData.destroy();
          }

          $("#product_sells_chart_count").html(graph.sells);
          let chart = document.getElementById("product_sells_chart");
          let height = parseInt(LXUtil.css(chart, "height")),
            color1 = LXUtil.getCssVariableValue("--bs-gray-500"),
            color2 = LXUtil.getCssVariableValue("--bs-border-dashed-color"),
            color3 = LXUtil.getCssVariableValue("--bs-primary"),
            color4 = LXUtil.getCssVariableValue("--bs-danger"),
            color5 = LXUtil.getCssVariableValue("--bs-success"),
            color6 = LXUtil.getCssVariableValue("--bs-warning"),
            color7 = LXUtil.getCssVariableValue("--bs-gray-600"),
            color8 = LXUtil.getCssVariableValue("--bs-red"),
            chartInstance = new ApexCharts(chart, {
              series: [
                {
                  name: "Orders",
                  data: graph.orders,
                },
                {
                  name: "Orders Accepted",
                  data: graph.accepted_orders,
                },
                {
                  name: "Delivered",
                  data: graph.delivered,
                },
                {
                  name: "Rejected",
                  data: graph.rejected,
                },
                {
                  name: "Cancelled",
                  data: graph.cancelled,
                },
                {
                  name: "Returned",
                  data: graph.returned,
                },
                {
                  name: "Replacement",
                  data: graph.replacement,
                },
              ],
              chart: {
                fontFamily: "inherit",
                type: "area",
                height: height,
                toolbar: {
                  show: !1,
                },
              },
              dataLabels: {
                enabled: !1,
              },
              fill: {
                type: "gradient",
                gradient: {
                  shadeIntensity: 1,
                  opacityFrom: 0.4,
                  opacityTo: 0,
                  stops: [0, 80, 100],
                },
              },
              stroke: {
                curve: "smooth",
                show: !0,
                width: 3,
                colors: [color3, color5, color4, color8, color6, color7],
              },
              xaxis: {
                categories: graph.date,
                axisBorder: {
                  show: !1,
                },
                axisTicks: {
                  show: !1,
                },
                tickAmount: 6,
                labels: {
                  rotate: 0,
                  rotateAlways: !0,
                  style: {
                    colors: color1,
                    fontSize: "12px",
                  },
                },
                crosshairs: {
                  position: "front",
                  stroke: {
                    color: color3,
                    width: 1,
                    dashArray: 3,
                  },
                },
                tooltip: {
                  enabled: !0,
                  formatter: void 0,
                  offsetY: 0,
                  style: {
                    fontSize: "12px",
                  },
                },
              },
              yaxis: {
                tickAmount: 6,
                labels: {
                  style: {
                    colors: color1,
                    fontSize: "12px",
                  },
                },
              },
              states: {
                normal: {
                  filter: {
                    type: "none",
                    value: 0,
                  },
                },
                hover: {
                  filter: {
                    type: "none",
                    value: 0,
                  },
                },
                active: {
                  allowMultipleDataPointsSelection: !1,
                  filter: {
                    type: "none",
                    value: 0,
                  },
                },
              },
              tooltip: {
                style: {
                  fontSize: "12px",
                },
              },
              colors: [color3, color5, color4, color8, color6, color7],
              grid: {
                borderColor: color2,
                strokeDashArray: 4,
                yaxis: {
                  lines: {
                    show: !0,
                  },
                },
              },
              markers: {
                strokeColor: color3,
                strokeWidth: 3,
              },
            });
          chartInstance.render();
          hasRenderChart = true;
          graphData = chartInstance;
        };
      })();

      // EARNING
      (() => {
        let hasRenderChart = false;
        let graphData;

        let e = document.querySelector(
            '[data-lx-daterangepicker="true"][data-target=earnings]'
          ),
          t = moment().subtract(29, "days"),
          n = moment();

        let i = e.querySelector("div"),
          r = e.hasAttribute("data-lx-daterangepicker-opens")
            ? e.getAttribute("data-lx-daterangepicker-opens")
            : "left",
          g = function (a) {
            return a.format("MM/DD/YYYY");
          },
          o = function (e, t) {
            i &&
              (i.innerHTML =
                e.format("D MMM YYYY") + " - " + t.format("D MMM YYYY"));
            const r = new Ajax();
            r.url = ajax_url.s;
            r.data = {
              from: g(e),
              to: g(t),
              listing_id: listing_id,
              variation_id: variation_id,
              svariation_id: svariation_id,
              case: "single_product_earnings_graph",
              action: "analytics",
            };
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                renderChart(res);
              } catch (error) {
                cl(error);
              }
            };
            r.send();
          };
        $(e).daterangepicker(
          {
            startDate: t,
            endDate: n,
            opens: r,
            ranges: {
              Today: [moment(), moment()],
              Yesterday: [
                moment().subtract(1, "days"),
                moment().subtract(1, "days"),
              ],
              "Last 7 Days": [moment().subtract(6, "days"), moment()],
              "Last 30 Days": [moment().subtract(29, "days"), moment()],
              "This Month": [
                moment().startOf("month"),
                moment().endOf("month"),
              ],
              "Last Month": [
                moment().subtract(1, "month").startOf("month"),
                moment().subtract(1, "month").endOf("month"),
              ],
            },
          },
          o
        ),
          o(t, n);

        const renderChart = (graph) => {
          if (hasRenderChart) {
            graphData.destroy();
          }

          $("#product_earning_chart_count").html(graph.earning_text);
          let chart = document.getElementById("product_earning_chart");
          let height = parseInt(LXUtil.css(chart, "height")),
            color1 = LXUtil.getCssVariableValue("--bs-gray-500"),
            color2 = LXUtil.getCssVariableValue("--bs-border-dashed-color"),
            color3 = LXUtil.getCssVariableValue("--bs-warning"),
            color4 = LXUtil.getCssVariableValue("--bs-danger"),
            color5 = LXUtil.getCssVariableValue("--bs-success"),
            info = chart.getAttribute("data-lx-chart-info"),
            chartInstance = new ApexCharts(chart, {
              series: [
                {
                  name: "Earnings",
                  data: graph.earnings,
                },
                {
                  name: "Rejected",
                  data: graph.rejected,
                },
                {
                  name: "Returned",
                  data: graph.returned,
                },
              ],
              chart: {
                fontFamily: "inherit",
                type: "area",
                height: height,
                toolbar: {
                  show: !1,
                },
              },
              dataLabels: {
                enabled: !1,
              },
              fill: {
                type: "gradient",
                gradient: {
                  shadeIntensity: 1,
                  opacityFrom: 0.4,
                  opacityTo: 0,
                  stops: [0, 80, 100],
                },
              },
              stroke: {
                curve: "smooth",
                show: !0,
                width: 3,
                colors: [color5, color4, color3],
              },
              xaxis: {
                categories: graph.x,
                axisBorder: {
                  show: !1,
                },
                axisTicks: {
                  show: !1,
                },
                tickAmount: 6,
                labels: {
                  rotate: 0,
                  rotateAlways: !0,
                  style: {
                    colors: color1,
                    fontSize: "12px",
                  },
                },
                crosshairs: {
                  position: "front",
                  stroke: {
                    color: color3,
                    width: 1,
                    dashArray: 3,
                  },
                },
                tooltip: {
                  enabled: !0,
                  formatter: void 0,
                  offsetY: 0,
                  style: {
                    fontSize: "12px",
                  },
                },
              },
              yaxis: {
                tickAmount: 6,
                labels: {
                  style: {
                    colors: color1,
                    fontSize: "12px",
                  },
                },
              },
              states: {
                normal: {
                  filter: {
                    type: "none",
                    value: 0,
                  },
                },
                hover: {
                  filter: {
                    type: "none",
                    value: 0,
                  },
                },
                active: {
                  allowMultipleDataPointsSelection: !1,
                  filter: {
                    type: "none",
                    value: 0,
                  },
                },
              },
              tooltip: {
                style: {
                  fontSize: "12px",
                },
              },
              colors: [color5, color4, color3],
              grid: {
                borderColor: color2,
                strokeDashArray: 4,
                yaxis: {
                  lines: {
                    show: !0,
                  },
                },
              },
              markers: {
                strokeColor: color3,
                strokeWidth: 3,
              },
            });
          chartInstance.render();
          hasRenderChart = true;
          graphData = chartInstance;
        };
      })();
    },
  };

  _.searchProducts = (function () {
    const searchInputForm = $("#searchProducts");
    if (!searchInputForm.length) return;
    const searchInput = searchInputForm.find("input");
    const searchSuggestion = searchInputForm.find("#searchSuggestion");

    //
    let selected_li_index = 0;
    searchInput.on("keydown", (e) => {
      const total_li_length = searchSuggestion.find("li").length,
        next_li_index =
          parseInt(selected_li_index) + 1 === total_li_length
            ? 0
            : parseInt(selected_li_index) + 1,
        prev_li_index =
          parseInt(selected_li_index) - 1 < 0
            ? total_li_length - 1
            : parseInt(selected_li_index) - 1,
        next_li = searchSuggestion.find("li").eq(next_li_index),
        prev_li = searchSuggestion.find("li").eq(prev_li_index);
      switch (e.originalEvent.which) {
        case 40:
          searchSuggestion.find(".selected").removeClass("selected"),
            next_li.addClass("selected"),
            (selected_li_index = next_li_index),
            searchInput.val(next_li.data("text"));
          break;
        case 38:
          searchSuggestion.find(".selected").removeClass("selected"),
            e.originalEvent.preventDefault(),
            prev_li.addClass("selected"),
            (selected_li_index = prev_li_index),
            searchInput.val(prev_li.data("text"));
          break;
      }
    });

    const reset =
      $(`<span class="cursor-pointer svg-icon svg-icon-1 svg-icon-muted position-absolute end-0 top-50 translate-middle">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
                            </svg>
                        </span>`);

    const addSearchReset = () => {
      if (searchInput.val().length) {
        if ($(document).find(reset).length !== 0) return;
        searchInput.after(reset);

        reset.on("click", () => {
          searchInput.val("");
          reset.remove();
          searchInput.focus();
          Search();
        });
      } else {
        reset.remove();
      }
    };
    searchInput.on("input", () => addSearchReset());

    const Search = () => {
      const r = new Ajax();
      let a;
      r.data = {
        keyword: searchInput.val(),
        case: "search_suggestion",
        action: "ecommerce_search_actions",
      };
      r.success = (res) => {
        try {
          res = JSON.parse(res);
          a = $("<div></div>");
          a.html(res.data);
          if (a.find("li").length > 1) {
            searchSuggestion.show().html(res.data);
            RefreshEvent();
            selected_li_index = 0;
          } else {
            searchSuggestion.hide().html("");
          }
        } catch (error) {
          cl(error);
        }
      };
      r.send();
    };
    searchInput.on("input", () => Search());
    searchInput.on(
      "focus",
      () =>
        searchInputForm.hasClass("active") ||
        (searchInputForm.addClass("active"), Search())
    );
    searchInputForm.on("blur", () => searchSuggestion.hide());
    searchInputForm.on("submit", function (e) {
      e.preventDefault();
      searchInput.val().length &&
        locateTo(
          searchInputForm.attr("action") + "?" + searchInputForm.serialize()
        );
    });

    $("body").on("mouseup", function (e) {
      if (
        !searchInputForm.is(e.target) &&
        searchInputForm.has(e.target).length === 0
      ) {
        searchInputForm.removeClass("active"), searchSuggestion.hide();
      }
    });

    const RefreshEvent = () => {
      searchSuggestion.find("li").each((f, e) => {
        const t = $(e);
        const remove = t.find(".remove-search");
        const fill = t.find(".fill-search");
        const val = t.data("text");
        const search_id = t.data("id");

        remove.on("click", (e) => {
          e.originalEvent.preventDefault();
          e.originalEvent.stopPropagation();
          searchInput.focus();
          const r = new Ajax();
          r.data = {
            search_id: search_id,
            case: "remove_search_history",
            action: "ecommerce_search_actions",
          };
          r.before = () => disableElement(t);
          r.complete = () => enableElement(t);
          r.success = (res) => {
            try {
              t.remove(),
                $('[data-type="history"]').length == 1 &&
                  $('[data-type="history"]').remove();
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        });

        fill.on("click", (e) => {
          e.originalEvent.preventDefault();
          e.originalEvent.stopPropagation();
          searchInput.focus(), searchInput.val(val);
          Search(), addSearchReset();
        });

        t.on("click", () => {
          searchInput.val(val);
          searchInputForm.trigger("submit");
        });
      });
    };

    return {
      init: function () {
        $("#pagePreloader").html("");
        $("#filterPreloader").removeClass("d-none");
        const filterRow = $("#filterRow");

        const updateUrl = (event, key, value, fetch = true) => {
          const url = new URL(location.href);
          if (event == "set") {
            url.searchParams.set(key, value);
          } else {
            key.forEach((e) => {
              url.searchParams.delete(e);
            });
          }
          history.replaceState(null, "", url);
          fetch && fetchProducts();
        };

        $("[data-sort]").on("click", (e) => {
          $("[data-sort]").find("a").removeClass("active");
          $(e.currentTarget).find("a").addClass("active");
          updateUrl("set", "sort", $(e.currentTarget).data("sort"));
        });
        const render = ({
          currency,
          max_price,
          min_price,
          current_min_price,
          current_max_price,
          products,
          pagination,
          filters,
          search_info,
          result_count,
        }) => {

          max_price = Number(max_price);
          min_price = Number(min_price);
          current_min_price = Number(current_min_price);
          current_max_price = Number(current_max_price);

          $("#filterPreloader").addClass("d-none");
          $("#productsContainer").html(products);
          $("#pagination").html(pagination);
          $(".search-info").html(search_info);
          $("#searchResultCnt").html(result_count);
          is_empty(filters) || $("#filters").html(filters);

          if (!result_count) {
            $("#sortInfoRow").addClass("d--none");
            is_empty($("#filters").html()) && filterRow.html(products);
            return false;
          }
          $("#sortInfoRow").removeClass("d--none");

          $("#price_range").slider({
            range: true,
            min: min_price,
            max: max_price,
            values: [current_min_price, current_max_price],
            step: 1,
            slide: function (event, ui) {
              $("#price_text").html(
                String(currency) +
                  ui.values[0] +
                  " - " +
                  String(currency) +
                  ui.values[1]
              );
            },
            stop: function (event, ui) {
              updateUrl("set", "min_price", ui.values[0], false);
              updateUrl("set", "max_price", ui.values[1]);
            },
          });

          // Sliders
          $(".product-card").each((f, e) => {
            const t = $(e);
            const carousel = t.find(".product-carousel");
            const img = t.find(".img-wrapper");
            carousel.each(function () {
              const mySwiper = new Swiper(this, {
                init: false,
                loop: true,
                speed: 800,
                slidesPerView: 1,
                centeredSlides: true,
                effect: "cube", // 'cube', 'fade', 'coverflow',
                cubeEffect: {
                  slideShadows: true,
                },
                autoplayDisableOnInteraction: true,
                grabCursor: true,
                parallax: true,
                pagination: {
                  el: ".swiper-pagination",
                  clickable: true,
                },
              });
              mySwiper.init();
            });
            t.on("mouseenter", () => {
              carousel.removeClass("fade"),
                carousel[0].swiper.autoplay.start(),
                img.addClass("d-none");
            });
            t.on("mouseleave", () => {
              carousel.addClass("fade"),
                carousel[0].swiper.autoplay.stop(),
                img.removeClass("d-none");
            });
          });

          $('[data-filter="category"]').on("click", (e) => {
            updateUrl("set", "category", e.currentTarget.dataset.id);
          });

          $('[data-filter="rating"]').on("change", (e) => {
            const $_GET = getQueryParams(document.location.search);
            e = e.currentTarget;
            let rating = $_GET["rating"];
            try {
              rating = JSON.parse(rating);
            } catch (error) {
              cl(error);
              rating = [];
            }
            if (e.checked) {
              rating.push(e.value);
            } else {
              rating = rating.filter((i) => {
                return i != e.value;
              });
            }

            if (rating.length) {
              updateUrl("set", "rating", JSON.stringify(rating));
            } else {
              updateUrl("delete", ["rating"]);
            }
          });

          $(".page-link[data-page]").on("click", (e) => {
            e.originalEvent.preventDefault();
            updateUrl("set", "page", $(e.currentTarget).data("page"));
            return false;
          });

          $('[data-filter="detail"]').on("change", (e) => {
            const $_GET = getQueryParams(document.location.search);
            let filters = $_GET["filters"];

            try {
              filters = JSON.parse(filters);
            } catch (error) {
              cl(error);
              filters = {};
            }

            e = e.currentTarget;
            const id = e.dataset.id;
            const val = e.value;

            if (typeof filters[id] === "undefined") filters[id] = [];

            try {
              if (e.checked) {
                filters[id].push(val);
              } else {
                filters[id] = filters[id].filter((i) => {
                  return i != val;
                });
                filters[id].length || delete filters[id];
              }

              if (Object.keys(filters).length) {
                filters = JSON.stringify(filters);
                updateUrl("set", "filters", filters);
              } else {
                updateUrl("delete", ["filters"]);
              }
            } catch (error) {
              cl(error);
              updateUrl("delete", ["filters"]);
            }
          });
        };

        const fetchProducts = (page) => {
          const $_GET = getQueryParams(document.location.search);
          let formData = {
            ...$_GET,
            action: "ecommerce_search_products",
          };
          searchInput.val($_GET["q"]);
          addSearchReset();
          const r = new Ajax();
          r.data = formData;
          r.before = () => disableElement(filterRow, 2);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              render(res);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.complete = () => enableElement(filterRow);
          r.send();
        };

        fetchProducts(1);
      },
    };
  })();

  _.Products = {
    Preview: {
      init: function (arg) {
        const product_id = arg.product_id;
        const svariation_id = arg.svariation_id;
        const variation_id = arg.variation_id;
        const status = arg.status;

        this.q_a(product_id);
        this.review(product_id);

        status == "active" &&
          (() => {
            const change_quantity = $("#change_quantity");
            const minOrder = parseInt(change_quantity.data("min"));
            const maxOrder = parseInt(change_quantity.data("max"));

            const Stepper = new LXDialer(change_quantity[0], {
              min: minOrder,
              max: maxOrder,
              step: 1,
            });

            Stepper.on("lx.dialer.decrease", function () {
              const val = Stepper.getValue();
              val == minOrder &&
                sweetAlert("error", `Minimum order has been reached`);
            });

            Stepper.on("lx.dialer.increase", function () {
              const val = Stepper.getValue();
              val == maxOrder &&
                sweetAlert("error", `Maximum order has been reached`);
            });

            const card = $("#buyWrapper");
            const view = card.find("#viewCart");
            const cart = card.find("#addToCart");
            const buy = card.find("#buyNow");

            cart.on("click", () => {
              const quantity = Stepper.getValue();
              const r = new Ajax();
              r.data = {
                quantity: quantity,
                product_id: product_id,
                svariation_id: svariation_id,
                variation_id: variation_id,
                case: "add_to_cart",
                action: "ecommerce_product_cart_actions",
              };
              r.before = () => disableBtn(cart);
              r.complete = () => enableBtn(cart);
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  view.show(), cart.hide(), sweetAlert("success", res.message);
                } catch (error) {
                  cl(error);
                  sweetAlert("error", res);
                }
              };
              r.send();
            });

            buy.on("click", () => {
              const quantity = Stepper.getValue();
              const r = new Ajax();
              r.data = {
                quantity: quantity,
                product_id: product_id,
                svariation_id: svariation_id,
                variation_id: variation_id,
                case: "buy_product",
                action: "ecommerce_product_checkout_actions",
              };
              r.before = () => disableBtn(buy);
              r.error = () => enableBtn(buy);
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  locateTo(res.url);
                } catch (error) {
                  cl(error);
                  r.error();
                  sweetAlert("error", res);
                }
              };
              r.send();
            });
          })();

        $("#addToWishlist").on("click", (e) => {
          const t = $(e.currentTarget);
          const r = new Ajax();
          const v = t.find("i").hasClass("fal") ? "add" : "remove";
          r.data = {
            event: v,
            product_id: product_id,
            svariation_id: svariation_id,
            variation_id: variation_id,
            case: "add_to_wishlist",
            action: "ecommerce_product_cart_actions",
          };
          r.before = () => disableElement(t);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              if (res.event == "added") {
                t.find("i")
                  .removeClass("fal text-dark")
                  .addClass("fas text-danger");
              } else {
                t.find("i")
                  .removeClass("fas text-danger")
                  .addClass("fal text-dark");
              }
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.complete = () => enableElement(t);
          r.send();
        });

        !(function (u) {
          (u.fn.jstars = function (s) {
            s = s || {};

            function i(s) {
              s.css("user-select", "none")
                .css("-moz-user-select", "none")
                .css("-khtml-user-select", "none")
                .css("-webkit-user-select", "none")
                .css("-o-user-select", "none");
            }

            function l(s, e) {
              for (var t = "", n = 0; n < e; n++) t += s;
              return t;
            }
            var d = u.extend(
              {
                size: "1.5rem",
                value: 0,
                stars: 5,
                color: "#4285F4",
                emptyColor: "#dddddd",
              },
              s
            );
            return (
              this.each(function () {
                var s = u(this),
                  e = s.data("value") || d.value,
                  t = s.data("total-stars") || d.stars,
                  n = s.data("color") || d.color,
                  o = s.data("empty-color") || d.emptyColor,
                  a = s.data("size") || d.size,
                  c = u(document.createElement("div"))
                    .addClass("jstars-empty")
                    .css("position", "relative")
                    .css("display", "inline-block")
                    .css("font-size", a)
                    .css("line-height", a)
                    .css("color", o)
                    .append(l("&starf;", t));
                i(c);
                var r = u(document.createElement("div"))
                  .addClass("jstars-filled")
                  .css("top", 0)
                  .css("left", 0)
                  .css("position", "absolute")
                  .css("display", "inline-block")
                  .css("font-size", a)
                  .css("line-height", a)
                  .css("width", (e / t) * 100 + "%")
                  .css("overflow", "hidden")
                  .css("white-space", "nowrap")
                  .css("color", n)
                  .append(l("&starf;", t));
                i(r), c.append(r), s.append(c);
              }),
              this
            );
          }),
            u(function () {
              u(".jstars").jstars();
            });
        })(jQuery);

        var swiper = new Swiper(".swiper", {
          autoHeight: true,
          slidesPerGroup: 2,
          slidesPerView: 2,
          spaceBetween: 12,
          loopFillGroupWithBlank: true,
          navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          },
          breakpoints: {
            768: {
              slidesPerGroup: 4,
              slidesPerView: 4,
              spaceBetween: 12,
            },
            1024: {
              slidesPerGroup: 6,
              slidesPerView: 6,
              spaceBetween: 12,
            },
          },
        });
      },
      q_a: function (product_id) {
        const qa_cnt = $("#qa_cnt");
        const modal = $("#askQuestionModal");
        const wrapper = $("#questionsWrapper");
        const askQuestionForm = $("#ask_ques");
        const F = new FormValidate(askQuestionForm);
        F.onValidate = () => {
          const r = new Ajax();
          r.data =
            askQuestionForm.serialize() +
            formString({
              product_id: product_id,
              case: "ask_question",
              action: "ecommerce_product_actions",
            });
          r.before = () => disableElement(askQuestionForm, 2);
          r.complete = () => enableElement(askQuestionForm);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message),
                wrapper.prepend(res.data),
                $(".no-question-box").hide(),
                modal.modal("hide"),
                qa_cnt.html(res.count),
                resetForm(askQuestionForm),
                CI();
              clamp();
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        };

        const CI = () => {
          $(".question-card").each((f, e) => {
            const t = $(e);
            t.hasClass("data-init-true") || createEvent(t);
          });
          LXMenu.createInstances();
        };

        const createEvent = (t) => {
          t.addClass("data-init-true");
          const id = t.data("id");
          const edit = t.find("[data-action=edit]");
          const del = t.find("[data-action=delete]");
          const answer = t.find("[data-action=answer]");
          const like = t.find("[data-action=like]");
          const dislike = t.find("[data-action=dislike]");
          const viewAllAnswers = t.find("[data-action=viewAllAnswers]");

          del.on("click", () => {
            const r = new Ajax();
            r.data = {
              product_id: product_id,
              question_id: id,
              case: "delete_question",
              action: "ecommerce_product_actions",
            };
            r.before = (e) => disableElement(t);
            r.complete = (e) => enableElement(t);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message),
                  qa_cnt.html(res.count),
                  res.count == 0 && $(".no-question-box").show(),
                  remove(t);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            const c = new Confirm();
            c.ok = (e) => r.send();
            c.show();
          });

          answer.on("click", () => {
            const question = t.find(".questionText").html();

            const modal = $("#addAnsModal");
            modal.find(".modal-body")
              .html(`<div class="d-flex bg-light border-start border-primary border-3 py-5 px-3 mb-4">
                            <div class="fw-bolder w-20px">Q:</div>
                            <div class="flex-grow-1">${question}</div>
                        </div>
                        <form novalidate id="add_answer">
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Answer</label>
                                <textarea required maxlength="1000" rows="5" type="text" class="form-control" name="answer" value=""></textarea>
                                <div class="invalid-feedback" >Answer is required</div>
                            </div>
                            <div class="justify-right">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>`);
            modal.modal("show");
            const w = modal.find("#add_answer");
            const F = new FormValidate(w);
            F.onValidate = () => {
              const r = new Ajax();
              r.data =
                w.serialize() +
                formString({
                  question_id: id,
                  product_id: product_id,
                  case: "add_answer",
                  action: "ecommerce_product_actions",
                });
              r.before = () => disableElement(w, 2);
              r.complete = () => enableElement(w);
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  sweetAlert("success", res.message),
                    t.replaceWith($(res.data)),
                    modal.modal("hide"),
                    resetForm(t),
                    CI();
                } catch (error) {
                  cl(error);
                  sweetAlert("error", res);
                }
              };
              r.send();
            };
          });

          edit.on("click", () => {
            const question = t.find(".oriquestionText").html();
            const modal = $("#editQuestionModal");
            modal.find(".modal-body").html(`<form novalidate id="edit_ques">
                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Question</label>
                                <textarea required maxlength="500" rows="5" type="text" class="form-control" name="question">${question}</textarea>
                                <div class="invalid-feedback" >Question is required</div>
                            </div>
                            <div class="justify-right">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>`);
            const w = $("#edit_ques");
            modal.modal("show");
            const F = new FormValidate(w);
            F.onValidate = () => {
              const r = new Ajax();
              r.data =
                w.serialize() +
                formString({
                  question_id: id,
                  product_id: product_id,
                  case: "edit_question",
                  action: "ecommerce_product_actions",
                });
              r.before = () => disableElement(w, 2);
              r.complete = () => enableElement(w);
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  sweetAlert("success", res.message),
                    modal.modal("hide"),
                    t.find(".oriquestionText").html(res.data),
                    t.find(".questionText").html(res.data);
                } catch (error) {
                  cl(error);
                  sweetAlert("error", res);
                }
              };
              r.send();
            };
          });

          viewAllAnswers.on("click", (e) => {
            const modal = $("#viewAnsModal");
            const t = $(e.currentTarget);
            const r = new Ajax();
            r.data = {
              product_id: product_id,
              question_id: id,
              case: "fetch_all_answers",
              action: "ecommerce_product_actions",
            };
            r.before = (e) => disableBtn(t);
            r.complete = (e) => enableBtn(t);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                modal.modal("show"),
                  modal.find(".modal-body").html(res.data),
                  CI();
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.send();
          });

          like.on("click", (w) => {
            const t = $(w.currentTarget);
            const aid = t.data("id");
            const i = t.find("i");
            const ni = t.next().find("i");
            const b = t.find("div");
            const nb = t.next().find("div");

            const r = new Ajax();
            r.data = {
              question_id: id,
              answer_id: aid,
              product_id: product_id,
              case: "rate_answer",
              event: "like",
              action: "ecommerce_product_actions",
            };
            r.before = () => disableBtn(t, "false");
            r.complete = () => enableBtn(t);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message),
                  res.process == "like"
                    ? i.addClass("text-primary")
                    : i.removeClass("text-primary"),
                  b.html(res.likes),
                  nb.html(res.dislikes),
                  ni.removeClass("text-primary");
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.send();
          });

          dislike.on("click", (w) => {
            const t = $(w.currentTarget);
            const aid = t.data("id");
            const i = t.find("i");
            const ni = t.prev().find("i");
            const b = t.find("div");
            const nb = t.prev().find("div");

            const r = new Ajax();
            r.data = {
              question_id: id,
              answer_id: aid,
              product_id: product_id,
              case: "rate_answer",
              event: "dislike",
              action: "ecommerce_product_actions",
            };
            r.before = () => disableBtn(t, "false");
            r.complete = () => enableBtn(t);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message),
                  res.process == "dislike"
                    ? i.addClass("text-primary")
                    : i.removeClass("text-primary"),
                  ni.removeClass("text-primary"),
                  b.html(res.dislikes),
                  nb.html(res.likes);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.send();
          });
        };
        CI();
      },
      review: function (product_id) {
        $(document).on("click", ".fslightbox-source", (e) => {
          closeGallery();
          e.originalEvent.preventDefault();
          e.originalEvent.stopPropagation();
          const t = $(e.currentTarget);
          const src = t.attr("src");
          const query = "?" + src.split("?")[1];
          const params = new Proxy(new URLSearchParams(query), {
            get: (searchParams, prop) => searchParams.get(prop),
          });
          Review.ratingPreview(
            {
              index: params.index,
              disable: function () {
                disableElement($(e.currentTarget));
              },
              enable: function () {
                enableElement($(e.currentTarget));
              },
            },
            product_id,
            params.review_id
          );
        });

        const Review = {
          isLoading: false,
          ratingPreview: function (t, product_id, id) {
            if (this.isLoading) return false;

            const index = is_empty(t.index) ? 0 : t.index;
            const r = new Ajax();
            r.data = {
              product_id: product_id,
              review_id: id,
              case: "fetch_rating_content",
              action: "ecommerce_product_actions",
            };
            r.before = (e) => ((this.isLoading = true), t.disable());
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                ratingSwipe(res);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.complete = (e) => ((this.isLoading = false), t.enable());
            r.send();

            const ratingSwipe = (res) => {
              const modal = $("#previewReviewModal");
              const lightBox = $(res.lightbox);
              modal.modal("show").find(".modal-dialog").html(lightBox);
              const prev = modal.find(".modal-action-btn.previous");
              const next = modal.find(".modal-action-btn.next");
              const remove = modal.find(".modal-action-btn.remove");

              prev.on("click", (e) => {
                const id = $(e.currentTarget).data("id");
                e.originalEvent.preventDefault();
                is_empty(id) ||
                  this.ratingPreview(
                    {
                      index: 0,
                      disable: function () {
                        disableElement(lightBox, 2);
                      },
                      enable: function () {
                        enableElement(lightBox, 2);
                      },
                    },
                    product_id,
                    id
                  );
                return false;
              });

              next.on("click", (e) => {
                const id = $(e.currentTarget).data("id");
                e.originalEvent.preventDefault();
                is_empty(id) ||
                  this.ratingPreview(
                    {
                      index: 0,
                      disable: function () {
                        disableElement(lightBox, 2);
                      },
                      enable: function () {
                        enableElement(lightBox, 2);
                      },
                    },
                    product_id,
                    $(e.currentTarget).data("id")
                  );
                return false;
              });

              remove.on("click", () => {
                modal.modal("hide");
              });

              modal.find("#like_review").on("click", (e) => {
                L({
                  t: $(e.currentTarget),
                  id: id,
                });
              });

              modal.find("#dislike_review").on("click", (e) => {
                D({
                  t: $(e.currentTarget),
                  id: id,
                });
              });

              modal.find('[data-action="viewGallery"]').on("click", () => {
                modal.modal("hide");
                GALLERY(1);
              });

              setTimeout(() => {
                $("#content_wrapper").css({
                  "max-height": $("#img_wrapper").height(),
                });
                $(window).on("resize", () => {
                  $("#content_wrapper").css({
                    "max-height": $("#img_wrapper").height(),
                  });
                });

                clamp();
                const galleryThumbs = new Swiper(".gallery-thumbs", {
                  spaceBetween: 10,
                  slidesPerView: "auto",
                  freeMode: true,
                  watchSlidesVisibility: true,
                  watchSlidesProgress: true,
                });

                const ratingSwiper = new Swiper(".rating-swiper-container", {
                  init: false,
                  loop: false,
                  speed: 800,
                  slidesPerView: 1, // or 'auto'
                  centeredSlides: true,
                  effect: "coverflow", // 'cube', 'fade', 'coverflow',
                  coverflowEffect: {
                    rotate: 50, // Slide rotate in degrees
                    stretch: 50, // Stretch space between slides (in px)
                    depth: 100, // Depth offset in px (slides translate in Z axis)
                    modifier: 2, // Effect multipler
                    slideShadows: true, // Enables slides shadows
                  },
                  grabCursor: true,
                  parallax: true,
                  pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                  },
                  navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                  },
                  thumbs: {
                    swiper: galleryThumbs,
                  },
                  on: {
                    imagesReady: function () {
                      this.el.classList.remove("loading");
                    },
                  },
                });
                ratingSwiper.init();
                ratingSwiper.slideTo(index);
              }, 1000);
            };
          },
        };

        const L = (w) => {
          const t = w.t;
          const i = t.find("i");
          const ni = t.next().find("i");
          const b = t.find("div");
          const nb = t.next().find("div");

          const r = new Ajax();
          r.data = {
            review_id: w.id,
            product_id: product_id,
            case: "rate_review",
            event: "like",
            action: "ecommerce_product_actions",
          };
          r.before = () => disableBtn(t, "false");
          r.complete = () => enableBtn(t);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message),
                res.process == "like"
                  ? i.addClass("text-primary")
                  : i.removeClass("text-primary"),
                b.html(res.likes),
                nb.html(res.dislikes),
                ni.removeClass("text-primary");
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        };

        const D = (w) => {
          const t = w.t;
          const i = t.find("i");
          const ni = t.prev().find("i");
          const b = t.find("div");
          const nb = t.prev().find("div");

          const r = new Ajax();
          r.data = {
            review_id: w.id,
            product_id: product_id,
            case: "rate_review",
            event: "dislike",
            action: "ecommerce_product_actions",
          };
          r.before = () => disableBtn(t, "false");
          r.complete = () => enableBtn(t);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message),
                res.process == "dislike"
                  ? i.addClass("text-primary")
                  : i.removeClass("text-primary"),
                ni.removeClass("text-primary"),
                b.html(res.dislikes),
                nb.html(res.likes);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        };

        const creatEvent = (c) => {
          c.addClass("data-init-true");

          const id = c.data("id");
          const l = c.find("#like_review");
          const d = c.find("#dislike_review");
          const x = c.find("#delete_review");

          l.on("click", (w) =>
            L({
              t: $(w.currentTarget),
              id: id,
            })
          );

          d.on("click", (w) =>
            D({
              t: $(w.currentTarget),
              id: id,
            })
          );

          x.on("click", () => {
            const r = new Ajax();
            r.data = {
              review_id: id,
              product_id: product_id,
              case: "delete_review",
              action: "ecommerce_product_actions",
            };
            r.before = () => disableElement(c);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message),
                  $("#reviews_count").html(res.count),
                  parseInt(res.count) > 0
                    ? $(".no-review-box").hide()
                    : $(".no-review-box").show(),
                  remove(c);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.complete = () => enableElement(c);
            const a = new Confirm();
            a.ok = () => r.send();
            a.text = "You want to delete your review";
            a.show();
          });

          c.find(".gallery-item").on("click", (e) => {
            Review.ratingPreview(
              {
                index: $(e.currentTarget).data("index"),
                disable: function () {
                  disableElement($(e.currentTarget));
                },
                enable: function () {
                  enableElement($(e.currentTarget));
                },
              },
              product_id,
              id
            );
          });
        };

        const CI = () => {
          $(".review-card").each((f, q) => {
            const e = $(q);
            e.hasClass("data-init-true") || creatEvent(e);
          });
          LXMenu.createInstances();
        };
        CI();
      },
      addReview: function (x) {
        const t = $("#review_form");

        const z = {
          rating: 0,
          imgCount: 0,
          maxImgCount: 5,
          images: [],
        };

        if (x.event === "update") {
          z.images = JSON.parse(x.images);
          z.review_id = x.review_id;
          z.imgCount = JSON.parse(x.images).length;
          t.find("#imgsWrapper")
            .find(".delete-alt")
            .on("click", (e) => {
              $(e.currentTarget).parent().remove();
              z.images = z.images.filter(function (item) {
                return item !== parseInt($(e.currentTarget).data("id"));
              });
              dec();
            });
        }
        const e = t.find("#btn_submit");
        const wrapper = t.find("#imgsWrapper");
        const btn = t.find("#uploadImg");

        const check = () => {
          z.maxImgCount == z.imgCount
            ? btn.addClass("d-none")
            : btn.removeClass("d-none");
        };
        const inc = () => {
          z.imgCount += 1;
          check();
        };
        const dec = () => {
          (z.imgCount -= 1), check();
        };

        const chooser = $(
          `<input class="sr-only" accept=".png, .jpg, .jpeg,.webp" multiple type="file" name="images">`
        );
        btn.before(chooser);

        btn.on("click", () => {
          chooser.trigger("click");
        });

        chooser.on("change", (e) => {
          const t = e.target;
          const files = t.files;
          const required_files = z.maxImgCount - z.imgCount;

          for (var i = 0; i < files.length; i++) {
            if (i < required_files) {
              const preloader =
                $(`<div class="w-50px h-50px me-3 position-relative justify-align-center opacity-100-hover bg-light review-img-upload" >
                                          <div class="image-upload-progress">
                                              <div class="progress-bar"></div>
                                          </div>
                                          <span class="svg-icon svg-icon-muted svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                  <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="currentColor" />
                                                  <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="currentColor" />
                                              </svg></span>
                                      </div>`);
              btn.before(preloader);

              const create = (res) => {
                const h =
                  $(`<button type="button" class="delete-alt " title="Delete">
                                              <i class="fas fa-times"></i>
                                          </button><img class="img-fluid mh-100" src="${res.file_url}" alt="" srcset="">`);
                preloader.html(h);
                z.images.push(res.file_id);
                $(h[0]).on("click", () => {
                  preloader.remove();
                  z.images = z.images.filter(function (item) {
                    return item !== res.file_id;
                  });
                  dec();
                });
              };
              inc();

              const p = preloader.find(".image-upload-progress");
              const r = new ImageUpload(e.currentTarget);
              r.data = {
                type: "image",
                action: "file_upload",
              };
              r.fileIndex = i;
              r.xhr = (evt) => {
                let c = (evt.loaded / evt.total) * 100;
                c = parseInt(c);
                p.show()
                  .find(".progress-bar")
                  .width(c + "%");
              };
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  create(res);
                } catch (error) {
                  cl(error);
                  sweetAlert("error", res);
                }
              };
              r.error = (e) => {
                dec();
                preloader.remove();
              };
              r.complete = () => p.hide().find(".progress-bar").width(0);
              r.upload();
            }
          }
        });

        const star = (t) => {
          const r = t.find("input[name=rating]");
          let v = r.val();
          const c = t.find(".rating");
          c.find(".rating-label").on("mouseenter click", (e) => {
            const s = $(e.currentTarget);
            const p = s.index();
            for (var i = 0; i < 5; i++) {
              i <= p
                ? s.parent().children().eq(i).addClass("checked")
                : s.parent().children().eq(i).removeClass("checked");
            }
            z.rating = p;
            r.val(parseInt(p) + 1);
          });
          if (v > 0) {
            v -= 1;
            c.children().eq(v).trigger("click");
          }
        };

        const vf = (t, e, s) => {
          star(t);
          const F = new FormValidate(t);
          F.onValidate = () => {
            s();
          };
        };

        const s = () => {
          const r = new Ajax();
          r.data =
            t.serialize() +
            formString({
              images: JSON.stringify(z.images),
              product_id: x.product_id,
              svariation_id: x.svariation_id,
              variation_id: x.variation_id,
              event: x.event,
              review_id: x.review_id,
              case: "add_review",
              action: "ecommerce_product_actions",
            });
          r.before = () => disableBtn(e);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message), locateTo(res.url);
            } catch (error) {
              cl(error);
              r.error(), sweetAlert("error", res);
            }
          };
          r.error = () => enableBtn(e);
          r.send();
        };

        vf(t, e, s);
      },
    },
  };

  const FormEdit = class {
    init() {
      const x = this;
      const form = x.form;
      const submit = form.find("[type=submit]");
      const edit = x.edit;
      const cancel = form.find("[type=cancel]");
      cancel.attr("type", "button");

      x.start = () => {
        submit.hide();
        edit.show();
        cancel.hide();
        form.find("input, select, textarea").each((f, e) => {
          $(e).attr("disabled", true);
        });
        form.addClass("form-edit-disabled");
      };

      x.stop = () => {
        submit.show();
        cancel.show();
        edit.hide();
        form.find("input, select, textarea").each((f, e) => {
          $(e).attr("disabled", false);
        });
        form.removeClass("form-edit-disabled");
      };

      edit.on("click", (e) => {
        e.originalEvent.preventDefault();
        x.stop();
      });

      cancel.on("click", (e) => {
        e.originalEvent.preventDefault();
        x.start();
      });

      x.start();
    }
  };

  _.Cart = {
    init: function () {
      const U = (z) => {
        $("#cart_products").html(z.cart_card);
        $("#price_details_card").html(z.details_card);
        $("#saved_card").html(z.saved_card);
        $("#cart_count").html(z.cart_count);
        $("#saved_count").html(z.saved_count);
        R();
        z.cart_count == 0
          ? $("#emptyCartContainer").removeClass("d-none")
          : $("#emptyCartContainer").addClass("d-none");
        z.saved_count == 0
          ? $("#savedContainer").addClass("d-none")
          : $("#savedContainer").removeClass("d-none");
      };

      const C = (e) => {
        const card = $(e);
        const id = card.data("id");
        const rem = card.find("[data-action=remove]");
        const save = card.find("[data-action=save]");
        const checkout = card.find("[data-action=checkout]");
        const change_quan = card
          .find("[data-action=change_quan]")
          .find(".menu-link");
        card.addClass("init-true");

        rem.on("click", () => {
          const r = new Ajax();
          r.data = {
            cart_id: id,
            case: "remove_cart_product",
            action: "ecommerce_product_cart_actions",
          };
          r.before = () => disableElement(card);
          r.complete = () => enableElement(card);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message), remove(card), U(res);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          const c = new Confirm();
          c.ok = () => r.send();
          c.show();
        });

        save.on("click", () => {
          const r = new Ajax();
          r.data = {
            cart_id: id,
            case: "save_cart_product",
            action: "ecommerce_product_cart_actions",
          };
          r.before = () => disableBtn(save);
          r.complete = () => enableBtn(save);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message), U(res);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        });

        checkout.on("click", () => {
          const r = new Ajax();
          r.data = {
            cart_id: id,
            case: "buy_product",
            action: "ecommerce_product_cart_actions",
          };
          r.before = () => disableBtn(checkout);
          r.complete = () => enableBtn(checkout);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              locateTo(res.url);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        });

        change_quan.on("click", (e) => {
          const t = $(e.currentTarget);
          const val = t.html();
          const r = new Ajax();
          r.data = {
            quantity: val,
            cart_id: id,
            case: "change_cart_product_quantity",
            action: "ecommerce_product_cart_actions",
          };
          r.before = () => disableElement(t);
          r.complete = () => enableElement(t);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message), U(res);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        });
      };

      const S = (e) => {
        const card = $(e);
        const id = card.data("id");
        const rem = card.find("[data-action=remove]");
        const move = card.find("[data-action=move_to_cart]");
        card.addClass("init-true");

        rem.on("click", () => {
          const r = new Ajax();
          r.data = {
            cart_id: id,
            case: "remove_saved_product",
            action: "ecommerce_product_cart_actions",
          };
          r.before = () => disableBtn(rem, "no-text");
          r.complete = () => enableBtn(rem);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message), remove(card), U(res);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          const c = new Confirm();
          c.ok = () => r.send();
          c.show();
        });

        move.on("click", () => {
          const r = new Ajax();
          r.data = {
            cart_id: id,
            case: "move_saved_to_cart",
            action: "ecommerce_product_cart_actions",
          };
          r.before = () => disableBtn(move);
          r.complete = () => enableBtn(move);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message), U(res);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        });
      };

      const R = () => {
        $(".cart-item").each((f, e) => {
          $(e).hasClass("init-true") || C(e);
        });
        $(".saved-item").each((f, e) => {
          $(e).hasClass("init-true") || S(e);
        });
        LXMenu.createInstances();
        const modal = $("#modal");

        const CH = (confirm) => {
          modal.modal("hide");
          const cont = $("#lx_content_container");
          const r = new Ajax();
          r.data = {
            confirm: confirm,
            case: "cart_to_checkout",
            action: "ecommerce_product_cart_actions",
          };
          r.before = () => disableElement(cont, 2);
          r.error = () => enableElement(cont);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              if (is_empty(res.unavailable_products)) {
                locateTo(res.url);
              } else {
                r.error(),
                  modal
                    .modal("show")
                    .find(".modal-body")
                    .html(res.unavailable_products);
              }
            } catch (error) {
              cl(error);
              r.error();
              sweetAlert("error", res);
            }
          };
          r.send();
        };
        modal.find("#continue").on("click", () => CH(1));

        $("#checkout")
          .off()
          .on("click", (e) => {
            CH(0);
          });
      };
      R();
    },
    wishlist: function () {
      const U = (res) => {
        $("#fav_count").html(res.fav_count);
        if (res.fav_count == 0) {
          $("#cart_products").html("");
          $("#emptyWishlistContainer").removeClass("d-none");
        } else {
          $("#emptyWishlistContainer").addClass("d-none");
        }
      };

      const F = (e) => {
        const card = $(e);
        const id = card.data("id");
        const rem = card.find("[data-action=remove]");
        const move = card.find("[data-action=move_to_cart]");
        card.addClass("init-true");

        rem.on("click", () => {
          const r = new Ajax();
          r.data = {
            cart_id: id,
            case: "remove_wishlist_product",
            action: "ecommerce_product_cart_actions",
          };
          r.before = () => disableBtn(rem, "no-text");
          r.complete = () => enableBtn(rem);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message), remove(card), U(res);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          const c = new Confirm();
          c.ok = () => r.send();
          c.show();
        });

        move.on("click", () => {
          const r = new Ajax();
          r.data = {
            cart_id: id,
            case: "move_wishlist_to_cart",
            action: "ecommerce_product_cart_actions",
          };
          r.before = () => disableBtn(move);
          r.complete = () => enableBtn(move);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message), remove(card), U(res);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        });
      };

      const R = () => {
        $(".wishlist-item").each((f, e) => {
          $(e).hasClass("init-true") || F(e);
        });
        LXMenu.createInstances();
      };
      R();
    },
    checkout: function (address_id) {
      const z = {
        address_id: "",
        payment_method: "",
      };
      typeof address_id === "undefined" || (z.address_id = address_id);

      const paymethodErrorEle = $(
        `<div class="text-danger fs-7" >Please choose a valid Payment Method</div>`
      );
      const addressErrorEle = $(
        `<div class="text-danger fs-7" >Please choose a valid Address</div>`
      );

      (() => {
        const U = (z) => {
          z.has_products || locateTo();
          $("#checkout_products").html(z.products);
          $("#price_details_card").html(z.details_card);
          $("#products_count").html(z.products_count);
          R();
        };

        const R = () => {
          $(".checkout-item").each((f, e) => {
            const card = $(e);
            card.hasClass("init-true") || LXMenu.createInstances(),
              card.addClass("init-true"),
              Init(card);
          });
        };

        const Init = (card) => {
          const id = card.data("id");
          const rem = card.find('[data-action="remove"]');
          const change_quan = card
            .find("[data-action=change_quan]")
            .find(".menu-link");

          rem.on("click", () => {
            const r = new Ajax();
            r.data = {
              cart_id: id,
              case: "remove_checkout_product",
              action: "ecommerce_product_checkout_actions",
            };
            r.before = () => disableElement(card);
            r.complete = () => enableElement(card);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message), remove(card), U(res);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            const c = new Confirm();
            c.ok = () => r.send();
            c.show();
          });

          change_quan.on("click", (e) => {
            const t = $(e.currentTarget);
            const val = t.html();
            const r = new Ajax();
            r.data = {
              quantity: val,
              cart_id: id,
              case: "change_product_quantity",
              action: "ecommerce_product_checkout_actions",
            };
            r.before = () => disableElement(t);
            r.complete = () => enableElement(t);
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                sweetAlert("success", res.message), U(res);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.send();
          });
        };
        R();
      })();

      $(document).on("click", ".address-card", (e) => {
        const card = $(e.currentTarget);

        $(".address-card.success-active").removeClass("success-active");
        card.addClass("success-active");
        z.address_id = card.data("id");
        addressErrorEle.remove();
      });
      MyProfile.Billing("ecommerce_product_checkout_actions");

      $("[name=payment_method]").on("change", (e) => {
        z.payment_method = e.currentTarget.value;
        paymethodErrorEle.remove();
      });

      $("#checkout").on("click", (e) => {
        let error = [];
        if (is_empty(z.address_id)) error.push(addressErrorEle);
        if (is_empty(z.payment_method)) error.push(paymethodErrorEle);

        if (error.length)
          return error.forEach((e) => {
            $("#errorWrapper").append(e);
          });

        const cont = $("#lx_content_container");
        const r = new Ajax();
        r.data = {
          address_id: z.address_id,
          payment_method: z.payment_method,
          case: "final_products_checkout",
          action: "ecommerce_product_checkout_actions",
        };
        r.before = () => disableElement(cont, 2);
        r.error = () => enableElement(cont);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            res.has_products == 0 ? locateTo() : locateTo(res.url);
          } catch (error) {
            cl(error);
            r.error();
            sweetAlert("error", res);
          }
        };
        r.send();
      });
    },
  };
  _.Seller = {
    Transactions: function () {
      const t = $("#data_table").DataTable({
        processing: true,
        serverSide: true,
        order: [[6, "desc"]],
        columns: [
          {
            data: null,
            orderable: false,
            sortable: false,
            render: function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            },
          },
          {
            data: "transaction_id",
          },
          {
            data: "amount",
          },
          {
            data: "txn_charge",
          },
          {
            data: "net_amount",
          },
          {
            data: "details",
          },
          {
            data: "date",
          },
          {
            data: "last_updated",
          },
          {
            data: "status",
          },
        ],
        ajax: {
          url: ajax_url.s,
          type: "POST",
          data: {
            action: "loadTblData",
            case: "transactions_TBl",
          },
        },
      });

      t.on("draw", () => {
        select2(), LXApp.initBootstrapTooltips();
      });
    },
    Questions: function () {
      const t = $("#data_table").DataTable({
        processing: true,
        serverSide: true,
        order: [[3, "desc"]],
        columns: [
          {
            data: null,
            orderable: false,
            render: function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            },
          },
          {
            data: "product",
          },
          {
            data: "category",
          },
          {
            data: "unanswered",
          },
          {
            data: "answered_seller",
          },
          {
            data: "answered_users",
          },
          {
            data: "questions",
          },
          {
            data: "action",
          },
        ],
        ajax: {
          url: ajax_url.s,
          type: "POST",
          data: {
            status: status,
            action: "loadTblData",
            case: "questions_tbl_data",
          },
        },
      });
      t.on("draw", () => {
        select2();
      });
    },
    myListings: function () {
      const Tbl = (status) => {
        const columns = [
          {
            data: null,
            orderable: false,
            render: function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            },
          },
          {
            data: "product",
          },
          {
            data: "status",
          },
          {
            data: "stock",
          },
          {
            data: "price",
          },
          {
            data: "mrp",
          },
          {
            data: "category",
          },
          {
            data: "sell",
          },
          {
            data: "date",
          },
          {
            data: "actions",
          },
        ];
        if (status == "active" || status == "inactive")
          columns.splice(1, 0, {
            data: "check",
          });
        return $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[8, "desc"]],
          columnDefs: [
            {
              targets: [0, 1, 9],
              orderable: false,
            },
          ],
          columns: columns,
          ajax: {
            url: ajax_url.s,
            type: "POST",
            data: {
              status: status,
              action: "loadTblData",
              case: "active_listings_tbl",
            },
          },
        });
      };
      return {
        active: function () {
          const t = Tbl("active");
          t.on("draw", () => {
            select2(), LXMenu.createInstances();
            const form = $("form");
            form.each((f, e) => {
              const currentForm = $(e);
              const optionName = currentForm.find("[name=column]").val();
              const options = {
                [optionName]: {
                  number: {
                    text: `${optionName.toCapitalize()} must consist of numbers only`,
                  },
                },
              };
              const F = new FormValidate($(e), options);
              F.onValidate = () => {
                const r = new Ajax();
                r.url = ajax_url.s;
                r.data =
                  currentForm.serialize() +
                  formString({
                    case: "updating_listing_tbl_data",
                    action: "updating_tbl_data",
                  });
                r.before = () => disableElement(currentForm);
                r.complete = () => enableElement(currentForm);
                r.success = (res) => {
                  try {
                    res = JSON.parse(res);
                    LXMenu.hideDropdowns(),
                      sweetAlert("success", res.message),
                      t.draw();
                  } catch (error) {
                    cl(error);
                    sweetAlert("error", res);
                  }
                };
                r.send();
              };
            });

            const c = new Check();
            c.selector = $('[data-check-selector="true"]');
            c.target = $('[data-check-target="true"]');
            const inactive = $("#inactive");
            c.error = () => {
              inactive.attr("disabled", true);
            };
            c.success = () => {
              inactive
                .attr("disabled", false)
                .off()
                .on("click", () => {
                  const svariations = [];
                  c.checkedTarget().forEach((e) => {
                    svariations.push({
                      product_id: $(e).data("id"),
                      variation_id: $(e).data("vid"),
                      svariation_id: e.value,
                    });
                  });
                  const r = new Ajax();
                  r.url = ajax_url.s;
                  r.data = {
                    status: "inactive",
                    svariations: svariations,
                    case: "change_svariation_status",
                    action: "updating_tbl_data",
                  };
                  r.before = () => disableBtn(inactive);
                  r.complete = () => (c.init(), enableBtn(inactive));
                  r.success = (res) => {
                    try {
                      res = JSON.parse(res);
                      c.error(), sweetAlert("success", res.message), t.draw();
                    } catch (error) {
                      cl(error);
                      sweetAlert("error", res);
                    }
                  };

                  r.send();
                });
            };
            c.init();
          });
        },
        inactive: function () {
          const t = Tbl("inactive");
          t.on("draw", () => {
            select2(), LXMenu.createInstances();

            const form = $("form");
            form.each((f, e) => {
              const currentForm = $(e);
              const optionName = currentForm.find("[name=column]").val();
              const options = {
                [optionName]: {
                  number: {
                    text: `${optionName.toCapitalize()} must consist of numbers only`,
                  },
                },
              };
              const F = new FormValidate($(e), options);
              F.onValidate = () => {
                const r = new Ajax();
                r.url = ajax_url.s;
                r.data =
                  currentForm.serialize() +
                  formString({
                    case: "updating_listing_tbl_data",
                    action: "updating_tbl_data",
                  });
                r.before = () => disableElement(currentForm);
                r.complete = () => enableElement(currentForm);
                r.success = (res) => {
                  try {
                    res = JSON.parse(res);
                    LXMenu.hideDropdowns(),
                      sweetAlert("success", res.message),
                      t.draw();
                  } catch (error) {
                    cl(error);
                    sweetAlert("error", res);
                  }
                };
                r.send();
              };
            });

            const c = new Check();
            c.selector = $('[data-check-selector="true"]');
            c.target = $('[data-check-target="true"]');
            const active = $("#active");
            c.error = () => {
              active.attr("disabled", true);
            };
            c.success = () => {
              active
                .attr("disabled", false)
                .off()
                .on("click", () => {
                  const svariations = [];
                  c.checkedTarget().forEach((e) => {
                    svariations.push({
                      product_id: $(e).data("id"),
                      variation_id: $(e).data("vid"),
                      svariation_id: e.value,
                    });
                  });
                  const r = new Ajax();
                  r.url = ajax_url.s;
                  r.data = {
                    status: "active",
                    svariations: svariations,
                    case: "change_svariation_status",
                    action: "updating_tbl_data",
                  };
                  r.before = () => disableBtn(active);
                  r.complete = () => (c.init(), enableBtn(active));
                  r.success = (res) => {
                    try {
                      res = JSON.parse(res);
                      sweetAlert("success", res.message), t.draw();
                    } catch (error) {
                      cl(error);
                      sweetAlert("error", res);
                    }
                  };
                  r.send();
                });
            };
            c.init();
          });
        },
        blocked: function () {
          const t = Tbl("blocked");
          t.on("draw", () => {
            select2();
          });
        },
        rejected: function () {
          const t = Tbl("rejected");
          t.on("draw", () => {
            select2();
          });
        },
        archived: function () {
          const t = Tbl("archived");
          t.on("draw", () => {
            select2();
          });
        },
        draft: function () {
          const t = $("#data_table").DataTable({
            processing: true,
            serverSide: true,
            order: [[7, "desc"]],
            columnDefs: [
              {
                targets: [0, 1, 2, 8],
                orderable: false,
              },
            ],
            columns: [
              {
                data: null,
                orderable: false,
                render: function (data, type, row, meta) {
                  return meta.row + meta.settings._iDisplayStart + 1;
                },
              },
              {
                data: "check",
              },
              {
                data: "product",
              },
              {
                data: "stock",
              },
              {
                data: "mrp",
              },
              {
                data: "price",
              },
              {
                data: "category",
              },
              {
                data: "date",
              },
              {
                data: "actions",
              },
            ],
            ajax: {
              url: ajax_url.s,
              type: "POST",
              data: {
                status: status,
                action: "loadTblData",
                case: "draft_listings_tbl",
              },
            },
          });
          t.on("draw", () => {
            select2();

            const c = new Check();
            c.selector = $('[data-check-selector="true"]');
            c.target = $('[data-check-target="true"]');
            const removeDrafts = $("#removeDrafts");
            c.error = () => {
              removeDrafts.attr("disabled", true);
            };
            c.success = () => {
              removeDrafts
                .attr("disabled", false)
                .off()
                .on("click", () => {
                  const svariations = [];
                  c.checkedTarget().forEach((e) => {
                    svariations.push({
                      listing_id: $(e).data("id"),
                      variation_id: $(e).data("vid"),
                      svariation_id: e.value,
                    });
                  });
                  const r = new Ajax();
                  r.url = ajax_url.s;
                  r.data = {
                    svariations: svariations,
                    case: "delete_bulk_svariations",
                    action: "updating_tbl_data",
                  };
                  r.before = () => disableBtn(removeDrafts);
                  r.complete = () => (c.init(), enableBtn(removeDrafts));
                  r.success = (res) => {
                    try {
                      res = JSON.parse(res);
                      c.error(), sweetAlert("success", res.message), t.draw();
                    } catch (error) {
                      cl(error);
                      sweetAlert("error", res);
                    }
                  };

                  const con = new Confirm();
                  con.text =
                    "All the selected drafts will be removed and can't be recovered";
                  con.show();
                  con.ok = () => r.send();
                });
            };
            c.init();

            $('[data-action="delete"]').on("click", (e) => {
              const t = $(e.currentTarget);
              const tr = t.closest("tr");
              const r = new Ajax();
              r.url = ajax_url.s;
              r.data = {
                listing_id: t.data("id"),
                variation_id: t.data("vid"),
                svariation_id: t.data("sid"),
                case: "delete_svariation",
                action: "create_listing",
              };
              r.before = () => disableElement(tr);
              r.complete = () => enableElement(tr);
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  sweetAlert("success", res.message), remove(tr);
                } catch (error) {
                  cl(error);
                  sweetAlert("error", res);
                }
              };
              const c = new Confirm();
              c.ok = () => r.send();
              c.show();
            });
          });
        },
        qc: function () {
          const t = $("#data_table").DataTable({
            processing: true,
            serverSide: true,
            order: [[2, "desc"]],
            columns: [
              {
                data: null,
                orderable: false,
                render: function (data, type, row, meta) {
                  return meta.row + meta.settings._iDisplayStart + 1;
                },
              },
              {
                data: "product",
              },
              {
                data: "req_date",
              },
              {
                data: "res_date",
              },
              {
                data: "status",
              },
              {
                data: "actions",
              },
            ],
            ajax: {
              url: ajax_url.s,
              type: "POST",
              data: {
                action: "loadTblData",
                case: "qc_tbl",
              },
            },
          });
          t.on("draw", () => {
            select2();
          });
          $("#qc_status").on("change", (e) => {
            let o = e.target.value;
            "all" === o && (o = ""), t.columns(4).search(o).draw();
          });
        },
      };
    },
    Orders: {
      viewOrders: function (order_id) {
        $("#generateLabel").on("click", (e) => {
          const t = $(e.currentTarget);
          const r = new Ajax();
          r.url = ajax_url.s;
          r.data = {
            orders: [order_id],
            case: "generate_label",
            action: "orders_actions",
          };
          r.before = () => disableBtn(t);
          r.error = () => enableBtn(t);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              window.open(res.url),
                sweetAlert("success", res.message),
                locateTo(undefined, 1000);
            } catch (error) {
              cl(error);
              r.error();
              sweetAlert("error", res);
            }
          };
          r.send();
        });

        const modal = $("#cancelOrderModal");
        const form = modal.find("form");
        $("#cancelOrder").on("click", () => {
          modal.modal("show"),
            form.find("#orders_id").html(`<div class="fv-row mb-7">
                                        <label class="required form-label mb-2"> ORDER ID </label>
                                        <input required readonly type="text" class="form-control form-control-solid" name="orders[]" value="${order_id}">
                                    </div>`);
        });
        const F = new FormValidate(form);
        F.onValidate = () => {
          const r = new Ajax();
          r.url = ajax_url.s;
          r.data =
            form.serialize() +
            formString({
              case: "reject_order",
              action: "orders_actions",
            });
          r.before = () => disableElement(form, 2);
          r.error = () => enableElement(form);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message),
                resetForm(form),
                modal.modal("hide"),
                locateTo(undefined, 1000);
            } catch (error) {
              cl(error);
              r.error();
              sweetAlert("error", res);
            }
          };
          r.send();
        };

        $("#markRtd").on("click", (e) => {
          const t = $(e.currentTarget);
          const r = new Ajax();
          r.url = ajax_url.s;
          r.data = {
            orders: [order_id],
            case: "mark_rtd",
            action: "orders_actions",
          };
          r.before = () => disableBtn(t);
          r.error = () => enableBtn(t);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message), locateTo(undefined, 1000);
            } catch (error) {
              cl(error);
              r.error();
              sweetAlert("error", res);
            }
          };
          const A = new Confirm();
          A.ok = () => r.send();
          A.head = "Mark Order as RTD";
          A.text = `Are you sure you want to mark the order as RTD? This action can't be reversed. `;
          A.okText = "Mark as RTD";
          A.show();
        });
      },
      active: function () {
        const t = $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[7, "asc"]],
          columnDefs: [
            {
              targets: [0, 1, 8],
              orderable: false,
            },
          ],
          columns: [
            {
              data: null,
              orderable: false,
              render: function (data, type, row, meta) {
                return meta.row + meta.settings._iDisplayStart + 1;
              },
            },
            {
              data: "check",
            },
            {
              data: "order_id",
            },
            {
              data: "details",
            },
            {
              data: "buyer",
            },
            {
              data: "quantity",
            },
            {
              data: "amount",
            },
            {
              data: "order_date",
            },
            {
              data: "actions",
            },
          ],
          ajax: {
            url: ajax_url.s,
            type: "POST",
            data: {
              order_status: "SUCCESS",
              action: "loadTblData",
              case: "new_orders_tbl",
            },
          },
        });
        t.on("draw", () => {
          select2(), LXMenu.createInstances();
          (() => {
            const c = new Check();
            c.selector = $('[data-check-selector="true"]');
            c.target = $('[data-check-target="true"]');
            const accept = $("#accept");
            const cancel = $("#cancel");
            const modal = $("#cancelOrderModal");
            const form = modal.find("form");
            c.success = () => {
              cancel
                .attr("disabled", false)
                .off()
                .on("click", () => {
                  form.find("#orders_id").html("");
                  modal.modal("show"),
                    c.checkedTarget().forEach((e) => {
                      form.find("#orders_id").prepend(`<div class="fv-row mb-7">
                                        <label class="required form-label mb-2"> ORDER ID </label>
                                        <input required readonly type="text" class="form-control form-control-solid" name="orders[]" value="${e.value}">
                                    </div>`);
                    });
                });
              accept
                .attr("disabled", false)
                .off()
                .on("click", () => {
                  const orders = [];
                  c.checkedTarget().forEach((e) => {
                    orders.push(e.value);
                  });
                  const r = new Ajax();
                  r.url = ajax_url.s;
                  r.data = {
                    orders: orders,
                    case: "generate_label",
                    action: "orders_actions",
                  };
                  r.before = () => disableBtn(accept);
                  r.complete = () => enableBtn(accept);
                  r.success = (res) => {
                    try {
                      res = JSON.parse(res);
                      window.open(res.url),
                        sweetAlert("success", res.message),
                        t.draw();
                    } catch (error) {
                      cl(error);
                      sweetAlert("error", res);
                    }
                  };
                  r.send();
                });
            };
            c.error = () => {
              $("#accept").attr("disabled", true),
                $("#cancel").attr("disabled", true);
            };
            c.init();

            const F = new FormValidate(form);
            F.onValidate = () => {
              const r = new Ajax();
              r.url = ajax_url.s;
              r.data =
                form.serialize() +
                formString({
                  case: "reject_order",
                  action: "orders_actions",
                });
              r.before = () => disableElement(form, 2);
              r.complete = () => enableElement(form);
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  sweetAlert("success", res.message),
                    resetForm(form),
                    modal.modal("hide"),
                    t.draw();
                } catch (error) {
                  cl(error);
                  sweetAlert("error", res);
                }
              };
              r.send();
            };
          })();
        });
      },
      rtd: function () {
        const t = $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[7, "asc"]],
          columnDefs: [
            {
              targets: [0, 1, 9],
              orderable: false,
            },
          ],
          columns: [
            {
              data: null,
              orderable: false,
              render: function (data, type, row, meta) {
                return meta.row + meta.settings._iDisplayStart + 1;
              },
            },
            {
              data: "check",
            },
            {
              data: "order_id",
            },
            {
              data: "details",
            },
            {
              data: "buyer",
            },
            {
              data: "quantity",
            },
            {
              data: "amount",
            },
            {
              data: "order_date",
            },
            {
              data: "labelled_on",
            },
            {
              data: "actions",
            },
          ],
          ajax: {
            url: ajax_url.s,
            type: "POST",
            data: {
              order_status: "LABELLED",
              action: "loadTblData",
              case: "new_orders_tbl",
            },
          },
        });

        t.on("draw", () => {
          select2(), LXMenu.createInstances();
          (() => {
            const c = new Check();
            c.selector = $('[data-check-selector="true"]');
            c.target = $('[data-check-target="true"]');
            const mark_rtd = $("#mark_rtd");

            c.success = () => {
              mark_rtd
                .attr("disabled", false)
                .off()
                .on("click", () => {
                  const orders = [];
                  c.checkedTarget().forEach((e) => {
                    orders.push(e.value);
                  });
                  const r = new Ajax();
                  r.url = ajax_url.s;
                  r.data = {
                    orders: orders,
                    case: "mark_rtd",
                    action: "orders_actions",
                  };
                  r.before = () => disableBtn(mark_rtd);
                  r.complete = () => enableBtn(mark_rtd);
                  r.success = (res) => {
                    try {
                      res = JSON.parse(res);
                      sweetAlert("success", res.message), t.draw();
                    } catch (error) {
                      cl(error);
                      sweetAlert("error", res);
                    }
                  };
                  const A = new Confirm();
                  A.ok = () => r.send();
                  A.head = "Mark Orders as RTD";
                  A.text = `Are you sure you want to mark the ${orders.length} order(s) as RTD? This action can't be reversed. `;
                  A.okText = "Mark as RTD";
                  A.show();
                });
            };
            c.error = () => {
              mark_rtd.attr("disabled", true);
            };
            c.init();
          })();
        });
      },
      handover: function () {
        const t = $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[7, "asc"]],
          columnDefs: [
            {
              targets: [0, 2, 8],
              orderable: false,
            },
          ],
          columns: [
            {
              data: null,
              orderable: false,
              render: function (data, type, row, meta) {
                return meta.row + meta.settings._iDisplayStart + 1;
              },
            },
            {
              data: "order_id",
            },
            {
              data: "details",
            },
            {
              data: "buyer",
            },
            {
              data: "quantity",
            },
            {
              data: "amount",
            },
            {
              data: "order_date",
            },
            {
              data: "rtd_on",
            },
            {
              data: "actions",
            },
          ],
          ajax: {
            url: ajax_url.s,
            type: "POST",
            data: {
              order_status: "RTD",
              action: "loadTblData",
              case: "new_orders_tbl",
            },
          },
        });

        t.on("draw", () => {
          select2();
          return false;
        });
      },
      shipped() {
        const t = $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[7, "asc"]],
          columnDefs: [
            {
              targets: [0, 2, 8],
              orderable: false,
            },
          ],
          columns: [
            {
              data: null,
              orderable: false,
              render: function (data, type, row, meta) {
                return meta.row + meta.settings._iDisplayStart + 1;
              },
            },
            {
              data: "order_id",
            },
            {
              data: "details",
            },
            {
              data: "buyer",
            },
            {
              data: "quantity",
            },
            {
              data: "amount",
            },
            {
              data: "order_date",
            },
            {
              data: "shipped_on",
            },
            {
              data: "actions",
            },
          ],
          ajax: {
            url: ajax_url.s,
            type: "POST",
            data: {
              order_status: "SHIPPED",
              action: "loadTblData",
              case: "new_orders_tbl",
            },
          },
        });
        t.on("draw", () => {
          select2();
        });
      },
      scheduledPickups: function () {
        const t = $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[7, "asc"]],
          columnDefs: [
            {
              targets: [0, 2, 8],
              orderable: false,
            },
          ],
          columns: [
            {
              data: null,
              orderable: false,
              render: function (data, type, row, meta) {
                return meta.row + meta.settings._iDisplayStart + 1;
              },
            },
            {
              data: "order_id",
            },
            {
              data: "details",
            },
            {
              data: "buyer",
            },
            {
              data: "quantity",
            },
            {
              data: "amount",
            },
            {
              data: "order_date",
            },
            {
              data: "scheduled_on",
            },
            {
              data: "actions",
            },
          ],
          ajax: {
            url: ajax_url.s,
            type: "POST",
            data: {
              order_status: "PICKUP_SCHEDULED",
              action: "loadTblData",
              case: "new_orders_tbl",
            },
          },
        });
        t.on("draw", () => {
          select2();
        });
      },
      completed: function () {
        const t = $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[7, "desc"]],
          columnDefs: [
            {
              targets: [0, 1, 8],
              orderable: false,
            },
          ],
          columns: [
            {
              data: null,
              orderable: false,
              render: function (data, type, row, meta) {
                return meta.row + meta.settings._iDisplayStart + 1;
              },
            },
            {
              data: "order_id",
            },
            {
              data: "details",
            },
            {
              data: "buyer",
            },
            {
              data: "quantity",
            },
            {
              data: "amount",
            },
            {
              data: "order_date",
            },
            {
              data: "delivered_on",
            },
            {
              data: "actions",
            },
          ],
          ajax: {
            url: ajax_url.s,
            type: "POST",
            data: {
              order_status: "DELIVERED",
              action: "loadTblData",
              case: "new_orders_tbl",
            },
          },
        });
        t.on("draw", () => {
          select2(), LXMenu.createInstances();
        });
      },
      cancelled: function () {
        const t = $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[7, "desc"]],
          columnDefs: [
            {
              targets: [0, 1, 8],
              orderable: false,
            },
          ],
          columns: [
            {
              data: null,
              orderable: false,
              render: function (data, type, row, meta) {
                return meta.row + meta.settings._iDisplayStart + 1;
              },
            },
            {
              data: "order_id",
            },
            {
              data: "details",
            },
            {
              data: "buyer",
            },
            {
              data: "quantity",
            },
            {
              data: "amount",
            },
            {
              data: "order_date",
            },
            {
              data: "cancelled_on",
            },
            {
              data: "actions",
            },
          ],
          ajax: {
            url: ajax_url.s,
            type: "POST",
            data: {
              order_status: "CANCELLED",
              action: "loadTblData",
              case: "new_orders_tbl",
            },
          },
        });
        t.on("draw", () => {
          select2(), LXMenu.createInstances();
        });
      },
      rejected: function () {
        const t = $("#data_table").DataTable({
          processing: true,
          serverSide: true,
          order: [[7, "desc"]],
          columnDefs: [
            {
              targets: [0, 1, 8],
              orderable: false,
            },
          ],
          columns: [
            {
              data: null,
              orderable: false,
              render: function (data, type, row, meta) {
                return meta.row + meta.settings._iDisplayStart + 1;
              },
            },
            {
              data: "order_id",
            },
            {
              data: "details",
            },
            {
              data: "buyer",
            },
            {
              data: "quantity",
            },
            {
              data: "amount",
            },
            {
              data: "order_date",
            },
            {
              data: "rejected_on",
            },
            {
              data: "actions",
            },
          ],
          ajax: {
            url: ajax_url.s,
            type: "POST",
            data: {
              order_status: "REJECTED",
              action: "loadTblData",
              case: "new_orders_tbl",
            },
          },
        });
        t.on("draw", () => {
          select2(), LXMenu.createInstances();
        });
      },
    },
    Analytics: {
      init: function () {
        // VIEWS
        (() => {
          let hasRenderChart = false;
          let graphData;

          let e = document.querySelector(
              '[data-lx-daterangepicker="true"][data-target=views]'
            ),
            t = moment().subtract(29, "days"),
            n = moment();

          let i = e.querySelector("div"),
            r = e.hasAttribute("data-lx-daterangepicker-opens")
              ? e.getAttribute("data-lx-daterangepicker-opens")
              : "left",
            g = function (a) {
              return a.format("MM/DD/YYYY");
            },
            o = function (e, t) {
              i &&
                (i.innerHTML =
                  e.format("D MMM YYYY") + " - " + t.format("D MMM YYYY"));
              const r = new Ajax();
              r.url = ajax_url.s;
              r.data = {
                from: g(e),
                to: g(t),
                case: "product_views_graph",
                action: "analytics",
              };
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  renderChart(res);
                } catch (error) {
                  cl(error);
                }
              };
              r.send();
            };
          $(e).daterangepicker(
            {
              startDate: t,
              endDate: n,
              opens: r,
              ranges: {
                Today: [moment(), moment()],
                Yesterday: [
                  moment().subtract(1, "days"),
                  moment().subtract(1, "days"),
                ],
                "Last 7 Days": [moment().subtract(6, "days"), moment()],
                "Last 30 Days": [moment().subtract(29, "days"), moment()],
                "This Month": [
                  moment().startOf("month"),
                  moment().endOf("month"),
                ],
                "Last Month": [
                  moment().subtract(1, "month").startOf("month"),
                  moment().subtract(1, "month").endOf("month"),
                ],
              },
            },
            o
          ),
            o(t, n);

          const renderChart = (graph) => {
            if (hasRenderChart) {
              graphData.destroy();
            }

            $("#product_views_chart_count").html(graph.views);
            let chart = document.getElementById("product_views_chart");
            let height = parseInt(LXUtil.css(chart, "height")),
              color1 = LXUtil.getCssVariableValue("--bs-gray-500"),
              color2 = LXUtil.getCssVariableValue("--bs-border-dashed-color"),
              color3 = LXUtil.getCssVariableValue("--bs-primary"),
              color4 = LXUtil.getCssVariableValue("--bs-primary"),
              info = chart.getAttribute("data-lx-chart-info"),
              chartInstance = new ApexCharts(chart, {
                series: [
                  {
                    name: info,
                    data: graph.y,
                  },
                ],
                chart: {
                  fontFamily: "inherit",
                  type: "area",
                  height: height,
                  toolbar: {
                    show: !1,
                  },
                },
                legend: {
                  show: !1,
                },
                dataLabels: {
                  enabled: !1,
                },
                fill: {
                  type: "gradient",
                  gradient: {
                    shadeIntensity: 1,
                    opacityFrom: 0.4,
                    opacityTo: 0,
                    stops: [0, 80, 100],
                  },
                },
                stroke: {
                  curve: "smooth",
                  show: !0,
                  width: 3,
                  colors: [color3],
                },
                xaxis: {
                  categories: graph.x,
                  axisBorder: {
                    show: !1,
                  },
                  axisTicks: {
                    show: !1,
                  },
                  tickAmount: 6,
                  labels: {
                    rotate: 0,
                    rotateAlways: !0,
                    style: {
                      colors: color1,
                      fontSize: "12px",
                    },
                  },
                  crosshairs: {
                    position: "front",
                    stroke: {
                      color: color3,
                      width: 1,
                      dashArray: 3,
                    },
                  },
                  tooltip: {
                    enabled: !0,
                    formatter: void 0,
                    offsetY: 0,
                    style: {
                      fontSize: "12px",
                    },
                  },
                },
                yaxis: {
                  tickAmount: 6,
                  labels: {
                    style: {
                      colors: color1,
                      fontSize: "12px",
                    },
                  },
                },
                states: {
                  normal: {
                    filter: {
                      type: "none",
                      value: 0,
                    },
                  },
                  hover: {
                    filter: {
                      type: "none",
                      value: 0,
                    },
                  },
                  active: {
                    allowMultipleDataPointsSelection: !1,
                    filter: {
                      type: "none",
                      value: 0,
                    },
                  },
                },
                tooltip: {
                  style: {
                    fontSize: "12px",
                  },
                },
                colors: [color4],
                grid: {
                  borderColor: color2,
                  strokeDashArray: 4,
                  yaxis: {
                    lines: {
                      show: !0,
                    },
                  },
                },
                markers: {
                  strokeColor: color3,
                  strokeWidth: 3,
                },
              });
            chartInstance.render();
            hasRenderChart = true;
            graphData = chartInstance;
          };
        })();

        // SELLS
        (() => {
          let hasRenderChart = false;
          let graphData;

          let e = document.querySelector(
              '[data-lx-daterangepicker="true"][data-target=sells]'
            ),
            t = moment().subtract(29, "days"),
            n = moment();

          let i = e.querySelector("div"),
            r = e.hasAttribute("data-lx-daterangepicker-opens")
              ? e.getAttribute("data-lx-daterangepicker-opens")
              : "left",
            g = function (a) {
              return a.format("MM/DD/YYYY");
            },
            o = function (e, t) {
              i &&
                (i.innerHTML =
                  e.format("D MMM YYYY") + " - " + t.format("D MMM YYYY"));
              const r = new Ajax();
              r.url = ajax_url.s;
              r.data = {
                from: g(e),
                to: g(t),
                case: "product_sells_graph",
                action: "analytics",
              };
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  renderChart(res);
                } catch (error) {
                  cl(error);
                }
              };
              r.send();
            };
          $(e).daterangepicker(
            {
              startDate: t,
              endDate: n,
              opens: r,
              ranges: {
                Today: [moment(), moment()],
                Yesterday: [
                  moment().subtract(1, "days"),
                  moment().subtract(1, "days"),
                ],
                "Last 7 Days": [moment().subtract(6, "days"), moment()],
                "Last 30 Days": [moment().subtract(29, "days"), moment()],
                "This Month": [
                  moment().startOf("month"),
                  moment().endOf("month"),
                ],
                "Last Month": [
                  moment().subtract(1, "month").startOf("month"),
                  moment().subtract(1, "month").endOf("month"),
                ],
              },
            },
            o
          ),
            o(t, n);

          const renderChart = (graph) => {
            if (hasRenderChart) {
              graphData.destroy();
            }

            $("#product_sells_chart_count").html(graph.sells);
            let chart = document.getElementById("product_sells_chart");
            let height = parseInt(LXUtil.css(chart, "height")),
              color1 = LXUtil.getCssVariableValue("--bs-gray-500"),
              color2 = LXUtil.getCssVariableValue("--bs-border-dashed-color"),
              color3 = LXUtil.getCssVariableValue("--bs-primary"),
              color4 = LXUtil.getCssVariableValue("--bs-danger"),
              color5 = LXUtil.getCssVariableValue("--bs-success"),
              color6 = LXUtil.getCssVariableValue("--bs-warning"),
              color7 = LXUtil.getCssVariableValue("--bs-gray-600"),
              color8 = LXUtil.getCssVariableValue("--bs-red"),
              chartInstance = new ApexCharts(chart, {
                series: [
                  {
                    name: "Orders",
                    data: graph.orders,
                  },
                  {
                    name: "Orders Accepted",
                    data: graph.y,
                  },
                  {
                    name: "Delivered",
                    data: graph.delivered,
                  },
                  {
                    name: "Rejected",
                    data: graph.rejected,
                  },
                  {
                    name: "Cancelled",
                    data: graph.cancelled,
                  },
                  {
                    name: "Returned",
                    data: graph.returned,
                  },
                  {
                    name: "Replacement",
                    data: graph.replacement,
                  },
                ],
                chart: {
                  fontFamily: "inherit",
                  type: "area",
                  height: height,
                  toolbar: {
                    show: !1,
                  },
                },
                dataLabels: {
                  enabled: !1,
                },
                fill: {
                  type: "gradient",
                  gradient: {
                    shadeIntensity: 1,
                    opacityFrom: 0.4,
                    opacityTo: 0,
                    stops: [0, 80, 100],
                  },
                },
                stroke: {
                  curve: "smooth",
                  show: !0,
                  width: 3,
                  colors: [color3, color5, color4, color8, color6, color7],
                },
                xaxis: {
                  categories: graph.x,
                  axisBorder: {
                    show: !1,
                  },
                  axisTicks: {
                    show: !1,
                  },
                  tickAmount: 6,
                  labels: {
                    rotate: 0,
                    rotateAlways: !0,
                    style: {
                      colors: color1,
                      fontSize: "12px",
                    },
                  },
                  crosshairs: {
                    position: "front",
                    stroke: {
                      color: color3,
                      width: 1,
                      dashArray: 3,
                    },
                  },
                  tooltip: {
                    enabled: !0,
                    formatter: void 0,
                    offsetY: 0,
                    style: {
                      fontSize: "12px",
                    },
                  },
                },
                yaxis: {
                  tickAmount: 6,
                  labels: {
                    style: {
                      colors: color1,
                      fontSize: "12px",
                    },
                  },
                },
                states: {
                  normal: {
                    filter: {
                      type: "none",
                      value: 0,
                    },
                  },
                  hover: {
                    filter: {
                      type: "none",
                      value: 0,
                    },
                  },
                  active: {
                    allowMultipleDataPointsSelection: !1,
                    filter: {
                      type: "none",
                      value: 0,
                    },
                  },
                },
                tooltip: {
                  style: {
                    fontSize: "12px",
                  },
                },
                colors: [color3, color5, color4, color8, color6, color7],
                grid: {
                  borderColor: color2,
                  strokeDashArray: 4,
                  yaxis: {
                    lines: {
                      show: !0,
                    },
                  },
                },
                markers: {
                  strokeColor: color3,
                  strokeWidth: 3,
                },
              });
            chartInstance.render();
            hasRenderChart = true;
            graphData = chartInstance;
          };
        })();

        // EARNING
        (() => {
          let hasRenderChart = false;
          let graphData;

          let e = document.querySelector(
              '[data-lx-daterangepicker="true"][data-target=earnings]'
            ),
            t = moment().subtract(29, "days"),
            n = moment();

          let i = e.querySelector("div"),
            r = e.hasAttribute("data-lx-daterangepicker-opens")
              ? e.getAttribute("data-lx-daterangepicker-opens")
              : "left",
            g = function (a) {
              return a.format("MM/DD/YYYY");
            },
            o = function (e, t) {
              i &&
                (i.innerHTML =
                  e.format("D MMM YYYY") + " - " + t.format("D MMM YYYY"));
              const r = new Ajax();
              r.url = ajax_url.s;
              r.data = {
                from: g(e),
                to: g(t),
                case: "product_earnings_graph",
                action: "analytics",
              };
              r.success = (res) => {
                try {
                  res = JSON.parse(res);
                  renderChart(res);
                } catch (error) {
                  cl(error);
                }
              };
              r.send();
            };
          $(e).daterangepicker(
            {
              startDate: t,
              endDate: n,
              opens: r,
              ranges: {
                Today: [moment(), moment()],
                Yesterday: [
                  moment().subtract(1, "days"),
                  moment().subtract(1, "days"),
                ],
                "Last 7 Days": [moment().subtract(6, "days"), moment()],
                "Last 30 Days": [moment().subtract(29, "days"), moment()],
                "This Month": [
                  moment().startOf("month"),
                  moment().endOf("month"),
                ],
                "Last Month": [
                  moment().subtract(1, "month").startOf("month"),
                  moment().subtract(1, "month").endOf("month"),
                ],
              },
            },
            o
          ),
            o(t, n);

          const renderChart = (graph) => {
            if (hasRenderChart) {
              graphData.destroy();
            }

            $("#product_earning_chart_count").html(graph.earning_text);
            let e = document.getElementById("product_earning_chart");
            let height = parseInt(LXUtil.css(e, "height")),
              color1 = LXUtil.getCssVariableValue("--bs-gray-500"),
              color2 = LXUtil.getCssVariableValue("--bs-border-dashed-color"),
              color3 = LXUtil.getCssVariableValue("--bs-warning"),
              color4 = LXUtil.getCssVariableValue("--bs-danger"),
              color5 = LXUtil.getCssVariableValue("--bs-success"),
              info = e.getAttribute("data-lx-chart-info"),
              chartInstance = new ApexCharts(e, {
                series: [
                  {
                    name: "Earnings",
                    data: graph.earnings,
                  },
                  {
                    name: "Rejected",
                    data: graph.rejected,
                  },
                  {
                    name: "Returned",
                    data: graph.returned,
                  },
                ],
                chart: {
                  fontFamily: "inherit",
                  type: "area",
                  height: height,
                  toolbar: {
                    show: !1,
                  },
                },
                dataLabels: {
                  enabled: !1,
                },
                fill: {
                  type: "gradient",
                  gradient: {
                    shadeIntensity: 1,
                    opacityFrom: 0.4,
                    opacityTo: 0,
                    stops: [0, 80, 100],
                  },
                },
                stroke: {
                  curve: "smooth",
                  show: !0,
                  width: 3,
                  colors: [color5, color4, color3],
                },
                xaxis: {
                  categories: graph.x,
                  axisBorder: {
                    show: !1,
                  },
                  axisTicks: {
                    show: !1,
                  },
                  tickAmount: 6,
                  labels: {
                    rotate: 0,
                    rotateAlways: !0,
                    style: {
                      colors: color1,
                      fontSize: "12px",
                    },
                  },
                  crosshairs: {
                    position: "front",
                    stroke: {
                      color: color3,
                      width: 1,
                      dashArray: 3,
                    },
                  },
                  tooltip: {
                    enabled: !0,
                    formatter: void 0,
                    offsetY: 0,
                    style: {
                      fontSize: "12px",
                    },
                  },
                },
                yaxis: {
                  tickAmount: 6,
                  labels: {
                    style: {
                      colors: color1,
                      fontSize: "12px",
                    },
                  },
                },
                states: {
                  normal: {
                    filter: {
                      type: "none",
                      value: 0,
                    },
                  },
                  hover: {
                    filter: {
                      type: "none",
                      value: 0,
                    },
                  },
                  active: {
                    allowMultipleDataPointsSelection: !1,
                    filter: {
                      type: "none",
                      value: 0,
                    },
                  },
                },
                tooltip: {
                  style: {
                    fontSize: "12px",
                  },
                },
                colors: [color5, color4, color3],
                grid: {
                  borderColor: color2,
                  strokeDashArray: 4,
                  yaxis: {
                    lines: {
                      show: !0,
                    },
                  },
                },
                markers: {
                  strokeColor: color3,
                  strokeWidth: 3,
                },
              });
            chartInstance.render();
            hasRenderChart = true;
            graphData = chartInstance;
          };
        })();

        {
          const getTbl = (from, to) => {
            $("#top_viewed_products_table").DataTable().destroy();
            return $("#top_viewed_products_table")
              .DataTable({
                processing: true,
                serverSide: true,
                order: [[3, "desc"]],
                columns: [
                  {
                    data: null,
                    orderable: false,
                    sortable: false,
                    render: function (data, type, row, meta) {
                      return meta.row + meta.settings._iDisplayStart + 1;
                    },
                  },
                  {
                    data: "product",
                  },
                  {
                    data: "publish_date",
                  },
                  {
                    data: "views",
                  },
                ],
                ajax: {
                  url: ajax_url.s,
                  type: "POST",
                  data: {
                    from_date: from,
                    to_date: to,
                    action: "loadTblData",
                    case: "top_viewed_products_Analytics",
                  },
                },
              })
              .on("draw", () => select2());
          };

          let e = document.querySelector(
              '[data-lx-daterangepicker="true"][data-target=top_viewed_products]'
            ),
            t = moment().subtract(29, "days"),
            n = moment();

          let i = e.querySelector("div"),
            r = e.hasAttribute("data-lx-daterangepicker-opens")
              ? e.getAttribute("data-lx-daterangepicker-opens")
              : "left",
            g = function (a) {
              return a.format("MM/DD/YYYY");
            },
            o = function (e, t) {
              i &&
                (i.innerHTML =
                  e.format("D MMM YYYY") + " - " + t.format("D MMM YYYY"));
              getTbl(g(e), g(t));
            };
          $(e).daterangepicker(
            {
              startDate: t,
              endDate: n,
              opens: r,
              ranges: {
                Today: [moment(), moment()],
                Yesterday: [
                  moment().subtract(1, "days"),
                  moment().subtract(1, "days"),
                ],
                "Last 7 Days": [moment().subtract(6, "days"), moment()],
                "Last 30 Days": [moment().subtract(29, "days"), moment()],
                "This Month": [
                  moment().startOf("month"),
                  moment().endOf("month"),
                ],
                "Last Month": [
                  moment().subtract(1, "month").startOf("month"),
                  moment().subtract(1, "month").endOf("month"),
                ],
              },
            },
            o
          ),
            o(t, n);
        }
        {
          const getTbl = (from, to) => {
            $("#top_selling_products_table").DataTable().destroy();
            const t = $("#top_selling_products_table").DataTable({
              processing: true,
              serverSide: true,
              order: [[3, "desc"]],
              columns: [
                {
                  data: null,
                  orderable: false,
                  sortable: false,
                  render: function (data, type, row, meta) {
                    return meta.row + meta.settings._iDisplayStart + 1;
                  },
                },
                {
                  data: "product",
                },
                {
                  data: "views",
                },
                {
                  data: "orders",
                },
                {
                  data: "accepted_orders",
                },
                {
                  data: "delivered",
                },
                {
                  data: "returned",
                },
                {
                  data: "replacement",
                },
                {
                  data: "cancelled",
                },
                {
                  data: "rejected",
                },
                {
                  data: "earning",
                },
                {
                  data: "publish_date",
                },
              ],
              ajax: {
                url: ajax_url.s,
                type: "POST",
                data: {
                  from_date: from,
                  to_date: to,
                  action: "loadTblData",
                  case: "topSellingProductsAnalytics",
                },
              },
            });

            t.on("draw", () => select2());
          };

          let e = document.querySelector(
              '[data-lx-daterangepicker="true"][data-target=top_selling_products]'
            ),
            t = moment().subtract(29, "days"),
            n = moment();

          let i = e.querySelector("div"),
            r = e.hasAttribute("data-lx-daterangepicker-opens")
              ? e.getAttribute("data-lx-daterangepicker-opens")
              : "left",
            g = function (a) {
              return a.format("MM/DD/YYYY");
            },
            o = function (e, t) {
              i &&
                (i.innerHTML =
                  e.format("D MMM YYYY") + " - " + t.format("D MMM YYYY"));
              getTbl(g(e), g(t));
            };
          $(e).daterangepicker(
            {
              startDate: t,
              endDate: n,
              opens: r,
              ranges: {
                Today: [moment(), moment()],
                Yesterday: [
                  moment().subtract(1, "days"),
                  moment().subtract(1, "days"),
                ],
                "Last 7 Days": [moment().subtract(6, "days"), moment()],
                "Last 30 Days": [moment().subtract(29, "days"), moment()],
                "This Month": [
                  moment().startOf("month"),
                  moment().endOf("month"),
                ],
                "Last Month": [
                  moment().subtract(1, "month").startOf("month"),
                  moment().subtract(1, "month").endOf("month"),
                ],
              },
            },
            o
          ),
            o(t, n);
        }
      },
    },
    MyProfile: {
      init: function () {
        const profileContainer = $("#profileContainer");
        const imageContainer = profileContainer.find("img");
        const progress = profileContainer.find(".profile-progress");
        const avatar_image_id = profileContainer.find(
          "input[name=logo_image_id]"
        );
        const inputChooser = profileContainer.find("input[type=file]");
        const removeBtn = profileContainer.find(
          "[data-lx-image-input-action=remove]"
        );
        removeBtn.on("click", () => removeProfile());
        inputChooser.on("change", (e) => {
          const u = new ImageUpload(e.target);
          u.name = "image";
          u.data = {
            type: "image",
            action: "file_upload",
          };
          u.xhr = (evt) => {
            let percentComplete = (evt.loaded / evt.total) * 100;
            percentComplete = parseInt(percentComplete);
            profileContainer.addClass("uploading");
            progress.css({
              "--value": percentComplete,
            });
          };
          u.success = (res) => {
            try {
              res = JSON.parse(res);
              let image_id = res.file_id;
              let image_src = res.file_url;
              imageContainer.attr("src", image_src);
              avatar_image_id.val(image_id);
              profileContainer.removeClass("image-input-changed");
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          u.complete = () => profileContainer.removeClass("uploading");
          u.upload();
        });

        const removeProfile = () => {
          const r = new Ajax();
          r.url = ajax_url.s;
          r.data = {
            case: "remove_store_logo",
            action: "my_profile",
          };
          r.before = () => disableElement(profileContainer);
          r.complete = () => enableElement(profileContainer);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              imageContainer.attr("src", res.image_src);
              avatar_image_id.val(res.image_id);
              profileContainer.addClass("image-input-changed");
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        };

        const modal = $("#storeModal");
        const form = modal.find("form");
        const F = new FormValidate(form);
        F.onValidate = () => {
          const r = new Ajax();
          r.url = ajax_url.s;
          r.data =
            form.serialize() +
            formString({
              case: "update_store_details",
              action: "my_profile",
            });
          r.before = () => disableElement(form, 2);
          r.complete = () => enableElement(form);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message),
                modal.modal("hide"),
                $("#store_logo").attr("src", res.store_logo),
                $("#store_name").html(res.store_name),
                $("#store_description").html(res.store_description);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.send();
        };

        const contact_details_form = $("#contact_details_form");
        const fe = new FormEdit();
        fe.form = contact_details_form;
        fe.edit = $('[type="edit"][data-form="contact_details_form"]');
        fe.init();
        const R = new FormValidate(contact_details_form, {
          contact_name: {
            alphabet: {
              text: "Contact name must consist of alphabets and spaces only",
            },
          },
          mobile_number: {
            mobileNumber: {
              text: "Mobile Number is not valid",
            },
          },
          contact_email: {
            email: {
              text: "Contact Email is not valid",
            },
          },
        });
        R.onValidate = () => {
          const r = new Ajax();
          r.url = ajax_url.s;
          r.data =
            contact_details_form.serialize() +
            formString({
              case: "contact_details",
              action: "my_profile",
            });
          r.before = () => disableElement(contact_details_form, 2);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              fe.start(), sweetAlert("success", res.message);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.complete = () => enableElement(contact_details_form);
          r.send();
        };

        const pickup_address_form = $("#pickup_address_form");
        const fe_add = new FormEdit();
        fe_add.form = pickup_address_form;
        fe_add.edit = $('[type="edit"][data-form="pickup_address_form"]');
        fe_add.init();
        const A = new FormValidate(pickup_address_form);
        A.onValidate = () => {
          const r = new Ajax();
          r.url = ajax_url.s;
          r.data =
            pickup_address_form.serialize() +
            formString({
              case: "pickup_address",
              action: "my_profile",
            });
          r.before = () => disableElement(pickup_address_form, 2);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              fe_add.start(), sweetAlert("success", res.message);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.complete = () => enableElement(pickup_address_form, 2);
          r.send();
        };

        $("#verifyAccount").on("click", (e) => {
          const t = $(e.currentTarget);
          const r = new Ajax();
          r.url = ajax_url.s;
          r.data = {
            case: "verify_account",
            action: "my_profile",
          };
          r.before = () => disableBtn(t);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message),
                $(".status-label").html(res.status),
                t.remove();
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          r.complete = () => enableBtn(t);
          r.send();
        });
      },
    },
    ReturnOrders: (status) => {
      let date;
      switch (status) {
        case "initiated":
          date = "requested_date";
          break;
        case "completed":
          date = "completed_date";
          break;
        case "accepted":
          date = "accepted_on";
          break;
        case "pickup_scheduled":
          date = "pickup_scheduled_date";
          break;
        case "rejected":
          date = "rejected_on";
          break;
        default:
          throw new Error("Status invalid");
          break;
      }

      const columns = [
        {
          data: null,
          orderable: false,
          render: function (data, type, row, meta) {
            return meta.row + meta.settings._iDisplayStart + 1;
          },
        },
        {
          data: "order_id",
        },
        {
          data: "return_id",
        },
        {
          data: "details",
        },
        {
          data: "buyer",
        },
        {
          data: "quantity",
        },
        {
          data: "amount",
        },
        {
          data: "delivered_on",
        },
        {
          data: date,
        },
        {
          data: "actions",
        },
      ];

      let order = 8;
      let dorder = 3;

      if (status == "accepted" || status == "pickup_scheduled") {
        order = 9;
        dorder = 4;
      }

      return $("#data_table")
        .DataTable({
          processing: true,
          serverSide: true,
          order: [[order, "asc"]],
          columnDefs: [
            {
              targets: [0, dorder, 9],
              orderable: false,
            },
          ],
          columns: columns,
          ajax: {
            url: ajax_url.s,
            type: "POST",
            data: {
              status: status,
              action: "loadTblData",
              case: "return_orders_datatbl",
            },
          },
        })
        .on("draw", () => select2());
    },
    ReplacementOrders: (status) => {
      let date;
      switch (status) {
        case "initiated":
          date = "requested_date";
          break;
        case "completed":
          date = "completed_date";
          break;
        case "accepted":
          date = "accepted_on";
          break;
        case "pickup_scheduled":
          date = "pickup_scheduled_date";
          break;
        case "rejected":
          date = "rejected_on";
          break;
        default:
          throw new Error("Status invalid");
          break;
      }

      const columns = [
        {
          data: null,
          orderable: false,
          render: function (data, type, row, meta) {
            return meta.row + meta.settings._iDisplayStart + 1;
          },
        },
        {
          data: "order_id",
        },
        {
          data: "replacement_id",
        },
        {
          data: "details",
        },
        {
          data: "buyer",
        },
        {
          data: "quantity",
        },
        {
          data: "amount",
        },
        {
          data: "delivered_on",
        },
        {
          data: date,
        },
        {
          data: "actions",
        },
      ];

      let order = 8;
      let dorder = 3;

      if (status == "accepted" || status == "pickup_scheduled") {
        order = 9;
        dorder = 4;
      }

      return $("#data_table")
        .DataTable({
          processing: true,
          serverSide: true,
          order: [[order, "asc"]],
          columnDefs: [
            {
              targets: [0, dorder, 9],
              orderable: false,
            },
          ],
          columns: columns,
          ajax: {
            url: ajax_url.s,
            type: "POST",
            data: {
              status: status,
              action: "loadTblData",
              case: "replacement_orders_datatbl",
            },
          },
        })
        .on("draw", () => select2());
    },
    Support: {
      init() {
        const t = $("#dataTbl").DataTable({
          processing: true,
          serverSide: true,
          order: [[3, "desc"]],
          columns: [
            {
              data: null,
              orderable: false,
              render: function (data, type, row, meta) {
                return meta.row + meta.settings._iDisplayStart + 1;
              },
            },
            {
              data: "subject",
            },
            {
              data: "status",
            },
            {
              data: "created_at",
            },
            {
              data: "view",
            },
          ],
          ajax: {
            url: ajax_url.s,
            type: "POST",
            data: {
              action: "loadTblData",
              case: "userSupportTickets",
            },
          },
        });
        t.on("draw", () => select2());
      },
      addTicket() {
        const maxImages = 5;
        let currentImages = 0;
        let images = [];
        const form = $("#addTicketForm");
        const btn = form.find("#uploadImg");

        const check = () => {
          maxImages == currentImages
            ? btn.addClass("d-none")
            : btn.removeClass("d-none");
        };
        const inc = () => {
          currentImages += 1;
          check();
        };
        const dec = () => {
          currentImages -= 1;
          check();
        };
        const chooser = $(
          `<input class="sr-only" multiple type="file" name="images">`
        );
        btn.before(chooser);

        btn.on("click", () => {
          chooser.trigger("click");
        });

        chooser.on("change", (e) => {
          const t = e.target;
          const files = t.files;
          const required_files = maxImages - currentImages;

          for (var i = 0; i < files.length; i++) {
            if (i < required_files) {
              const preloader =
                $(`<div class="w-80px h-80px mr-3 position-relative justify-align-center opacity-100-hover bg-light review-img-upload" >
                                              <div class="image-upload-progress">
                                                  <div class="progress-bar"></div>
                                              </div>
                                              <span class="svg-icon svg-icon-muted svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                      <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="currentColor" />
                                                      <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="currentColor" />
                                                  </svg></span>
                                          </div>`);
              btn.before(preloader);
              const create = (res) => {
                const h =
                  $(`<div class="h-100" ><button type="button" class="delete-alt" title="Delete">
                                                  <i class="fas fa-times" ></i>
                                   </button>
                                   <img class="img-fluid mh-100" src="${res.preview_url}" alt="" srcset="">
                                   </div>`);
                preloader.html(h);
                res.showExt &&
                  h
                    .find("img")
                    .after(`<div class="center-xy fs-7" >${res.ext}</div>`);
                images.push(res.file_id);
                h.find("button").on("click", () => {
                  preloader.remove();
                  images = images.filter(function (item) {
                    return item !== res.file_id;
                  });
                  dec();
                });
              };
              inc();
              const imageUploadProgress = preloader.find(
                ".image-upload-progress"
              );
              const r = new ImageUpload(e.currentTarget);
              r.fileIndex = i;
              r.url = ajax_url.s;
              r.name = "file";
              r.ext = [];
              r.data = {
                type: "file",
                action: "file_upload",
              };
              r.xhr = (evt) => {
                let c = (evt.loaded / evt.total) * 100;
                c = parseInt(c);
                imageUploadProgress
                  .show()
                  .find(".progress-bar")
                  .width(c + "%");
              };
              r.success = (res) => {
                try {
                  (res = JSON.parse(res)), create(res);
                } catch (e) {
                  sweetalert("error", e);
                }
              };
              r.error = (e) => {
                dec();
                preloader.remove();
              };
              r.complete = () =>
                imageUploadProgress.hide().find(".progress-bar").width(0);
              r.upload();
            }
          }
          //
        });

        const F = new FormValidate(form);
        F.onValidate = () => {
          const r = new Ajax();
          r.before = () => disableElement(form, 2);
          r.url = ajax_url.s;
          r.data =
            form.serialize() +
            formString({
              action: "support_actions",
              files: JSON.stringify(images),
            });
          r.error = () => enableElement(form);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              const url = res.url || undefined;
              locateTo(url, 1000);
            } catch (error) {
              cl(error);
              r.error();
              sweetAlert("error", res);
            }
          };
          r.send();
        };

        //Close Ticket
        $("#closeTicket").on("click", (e) => {
          const btn = $(e.currentTarget);
          const r = new Ajax();
          r.data = {
            ticket_id: $_GET["id"],
            action: "support_actions",
            case: "close_ticket",
          };
          r.url = ajax_url.a;
          r.before = () => disableBtn(btn);
          r.complete = () => enableBtn(btn);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message);
              locateTo(undefined, 1000);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          const c = new Confirm();
          c.ok = () => r.send();
          c.okText = "Yes, Sure";
          c.text =
            "You want to close the ticket. You will be no longer able to reply";
          c.show();
        });
      },
    },
  };

  _.Withdraw = {
    createMethod: function () {
      const add_withdraw_details = $("form#add_withdraw_details");
      const F = new FormValidate(add_withdraw_details);
      F.onValidate = () => {
        const r = new Ajax();
        r.url = ajax_url.s;
        r.data =
          add_withdraw_details.serialize() +
          formString({
            gateway_id: $_GET["id"],
            case: "add_withdraw_details",
            action: "withdraw_actions",
          });
        r.before = () => disableElement(add_withdraw_details, 2);
        r.error = () => enableElement(add_withdraw_details);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message), locateTo(res.url, 2000);
          } catch (error) {
            cl(error);
            r.error();
            sweetAlert("error", res);
          }
        };
        r.send();
      };

      $(".image-upload-card").each((f, e) => {
        const c = $(e);

        const input = c.find(".img_label_choose");
        const p = c.find(".image-upload-progress");

        input.on("change", () => {
          const r = new ImageUpload(input[0]);
          r.url = ajax_url.a;
          r.data = {
            type: "image",
            action: "file_upload",
          };
          r.xhr = (evt) => {
            let c = (evt.loaded / evt.total) * 100;
            c = parseInt(c);
            p.show()
              .find(".progress-bar")
              .width(c + "%");
          };
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              c.find("img").attr("src", res.file_url),
                c.find(".image-id").val(res.file_id).trigger("change");
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };

          r.complete = () => p.hide().find(".progress-bar").width(0);
          r.upload();
        });
      });
    },
    lists: function () {
      $(".withdraw-card").each((f, e) => {
        const t = $(e);
        const del = t.find('[data-remove="withdraw"]');
        del.on("click", () => {
          const r = new Ajax();
          r.url = ajax_url.s;
          r.data = {
            gateway_id: t.data("id"),
            case: "delete_withdraw_gateway",
            action: "withdraw_actions",
          };
          r.before = () => disableElement(t);
          r.complete = () => enableElement(t);
          r.success = (res) => {
            try {
              res = JSON.parse(res);
              sweetAlert("success", res.message),
                t.find(".btns").html(res.btns);
            } catch (error) {
              cl(error);
              sweetAlert("error", res);
            }
          };
          const c = new Confirm();
          c.text = "You want to delete this payment method?";
          c.ok = () => r.send();
          c.show();
        });
      });
    },
    fillDetails: function (props) {
      const amountInput = $("input[name=amount]");
      const chargeInput = $("input[name=withdraw_charge]");
      const finalAmountInput = $("input[name=final_amount]");
      const charge = Number(props.charge);
      const chargeType = props.charge_type;

      amountInput.on("input", () => {
        const withdrawAmt = Number(amountInput.val());
        if (chargeType == "fixed") {
          finalAmountInput.val(withdrawAmt - charge);
          chargeInput.val(charge);
        } else {
          const withdrawCharge = (withdrawAmt * charge) / 100;
          const finalWithdrawAmt = withdrawAmt - withdrawCharge;
          chargeInput.val(parseFloat(withdrawCharge.toFixed(2)));
          finalAmountInput.val(parseFloat(finalWithdrawAmt.toFixed(2)));
        }
      });

      this.createMethod();
      const form = $("form#withdraw");
      const F = new FormValidate(form, {
        amount: {
          number: {
            text: "Amount must consist of numbers only",
          },
        },
      });
      F.onValidate = () => {
        const r = new Ajax();
        r.url = ajax_url.s;
        r.data =
          form.serialize() +
          formString({
            gateway_id: $_GET["id"],
            case: "withdraw",
            action: "withdraw_actions",
          });
        r.before = () => disableElement(form, 2);
        r.error = () => enableElement(form);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message), locateTo(res.url, 2000);
          } catch (error) {
            cl(error);
            r.error();
            sweetAlert("error", res);
          }
        };
        r.send();
      };
    },
    history: function () {
      const t = $("#data_table").DataTable({
        processing: true,
        serverSide: true,
        order: [[6, "desc"]],
        columns: [
          {
            data: null,
            orderable: false,
            sortable: false,
            render: function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            },
          },
          {
            data: "transaction_id",
          },
          {
            data: "gateway",
          },
          {
            data: "gross_amount",
          },
          {
            data: "charge",
          },
          {
            data: "net_amount",
          },
          {
            data: "requested_date",
          },
          {
            data: "processed_date",
          },
          {
            data: "status",
          },
          {
            data: "action",
          },
        ],
        ajax: {
          url: ajax_url.s,
          type: "POST",
          data: {
            action: "loadTblData",
            case: "withdraw_history_tbl",
          },
        },
      });

      t.on("draw", () => select2());
    },
  };

  _.Ecommerce = {
    Home: function () {
      new Swiper(".slider1", {
        loop: true,
        autoHeight: true,
        spaceBetween: 30,
        centeredSlides: true,
        autoplay: {
          delay: 2500,
          disableOnInteraction: false,
        },
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
      });

      $(".slider2").each((f, e) => {
        let columns = e.dataset.columns || 6;
        let mobileColumns = e.dataset.mobile_columns || 2;
        let tabColumns = e.dataset.tab_columns || 4;

        columns = Number(columns);
        mobileColumns = Number(mobileColumns);
        tabColumns = Number(tabColumns);

        new Swiper(e, {
          autoHeight: true,
          slidesPerGroup: mobileColumns,
          slidesPerView: mobileColumns,
          spaceBetween: 6,
          loopFillGroupWithBlank: true,
          navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          },
          breakpoints: {
            768: {
              slidesPerGroup: tabColumns,
              slidesPerView: tabColumns,
              spaceBetween: 12,
            },
            1024: {
              slidesPerGroup: columns,
              slidesPerView: columns,
              spaceBetween: 12,
            },
          },
        });
      });

      $(".swiper-wrapper").css({
        height: "inherit",
      });
      $(window).on("resize", () => {
        $(".swiper-wrapper").css({
          height: "inherit",
        });
      });
    },
  };

  _.Order = {
    timeLine: () => {
      $('[data-track-init="true"]').each((f, e) => {
        const x = $(e);
        x.find(".timeline-step.done").on("click", (e) => {
          const t = $(e.currentTarget);
          const stop = t.data("track-stop");

          x.find(".timeline-step.active").removeClass("active");
          t.addClass("active");
          x.find("[data-track]").addClass("d-none");
          x.find(`[data-track=${stop}]`)
            .removeClass("d-none")
            .addClass("active");
        });

        x.find(".timeline-step.done.active").trigger("click");
      });
    },
    view: () => {
      Order.timeLine();

      // Cancel Order
      const cancelOrderModal = $("#cancelOrder");
      const cancelOrderForm = cancelOrderModal.find("form");
      const F = new FormValidate(cancelOrderForm);
      F.onValidate = () => {
        const r = new Ajax();
        r.data =
          cancelOrderForm.serialize() +
          formString({
            order_id: $_GET["id"],
            case: "cancel_order",
            action: "ecommerce_orders_actions",
          });
        r.before = () => disableElement(cancelOrderForm, 2);
        r.complete = () => enableElement(cancelOrderForm);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message),
              resetForm(cancelOrderForm),
              cancelOrderModal.modal("hide"),
              locateTo(undefined, 1000);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      };

      // Return Order
      const returnOrderModal = $("#returnOrder");
      const returnOrderForm = returnOrderModal.find("form");

      // IMage Upload
      const minImages = 2;
      const maxImages = 8;
      let images = [];
      let currentImages = 0;
      const btn = returnOrderForm.find("#uploadImg");
      const check = () => {
        maxImages == currentImages
          ? btn.addClass("d-none")
          : btn.removeClass("d-none");
      };
      const inc = () => {
        currentImages += 1;
        check();
      };

      const dec = () => {
        currentImages -= 1;
        check();
      };

      const chooser = $(
        `<input class="sr-only" multiple="" accept=".png, .jpg, .jpeg,.webp" type="file" name="images">`
      );
      btn.before(chooser);
      btn.on("click", () => {
        chooser.trigger("click");
      });

      chooser.on("change", (e) => {
        const t = e.target;
        const files = t.files;
        const required_files = maxImages - currentImages;

        for (var i = 0; i < files.length; i++) {
          if (i < required_files) {
            const preloader =
              $(`<div class="w-50px h-50px me-3 position-relative justify-align-center opacity-100-hover bg-light review-img-upload" >
                                        <div class="image-upload-progress">
                                            <div class="progress-bar"></div>
                                        </div>
                                        <span class="svg-icon svg-icon-muted svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <path opacity="0.3" d="M22 5V19C22 19.6 21.6 20 21 20H19.5L11.9 12.4C11.5 12 10.9 12 10.5 12.4L3 20C2.5 20 2 19.5 2 19V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5ZM7.5 7C6.7 7 6 7.7 6 8.5C6 9.3 6.7 10 7.5 10C8.3 10 9 9.3 9 8.5C9 7.7 8.3 7 7.5 7Z" fill="currentColor" />
                                                <path d="M19.1 10C18.7 9.60001 18.1 9.60001 17.7 10L10.7 17H2V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V12.9L19.1 10Z" fill="currentColor" />
                                            </svg></span>
                                    </div>`);
            btn.before(preloader);

            const create = (res) => {
              const h =
                $(`<button type="button" class="delete-alt " title="Delete">
                                            <i class="fas fa-times"></i>
                                        </button><img class="img-fluid mh-100" src="${res.file_url}" alt="" srcset="">`);
              preloader.html(h);
              images.push(res.file_id);
              $(h[0]).on("click", () => {
                preloader.remove();
                images = images.filter((item) => {
                  return item !== res.file_id;
                });
                dec();
              });
            };

            inc();
            const imageUploadProgress = preloader.find(
              ".image-upload-progress"
            );
            const r = new ImageUpload(e.currentTarget);
            r.data = {
              type: "image",
              action: "file_upload",
            };
            r.fileIndex = i;
            r.xhr = (evt) => {
              let c = (evt.loaded / evt.total) * 100;
              c = parseInt(c);
              imageUploadProgress
                .show()
                .find(".progress-bar")
                .width(c + "%");
            };
            r.success = (res) => {
              try {
                res = JSON.parse(res);
                create(res);
              } catch (error) {
                cl(error);
                sweetAlert("error", res);
              }
            };
            r.error = (e) => {
              dec();
              preloader.remove();
            };
            r.complete = () =>
              imageUploadProgress.hide().find(".progress-bar").width(0);
            r.upload();
          }
        }
      });

      const R = new FormValidate(returnOrderForm);
      R.onValidate = () => {
        if (images.length < minImages)
          return sweetAlert(
            "error",
            `Minimum ${minImages} images are required`
          );
        const r = new Ajax();
        r.data =
          returnOrderForm.serialize() +
          formString({
            order_id: $_GET["id"],
            case: "return_order",
            images: images,
            action: "ecommerce_orders_actions",
          });
        r.before = () => disableElement(returnOrderForm, 2);
        r.complete = () => enableElement(returnOrderForm);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message),
              resetForm(returnOrderForm),
              returnOrderModal.modal("hide"),
              locateTo(undefined, 1000);
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      };

      $("#cancelReturn").on("click", (e) => {
        const r = new Ajax();
        r.data = {
          case: "cancel_return",
          action: "ecommerce_orders_actions",
          order_id: $_GET["id"],
        };
        r.before = () => disableBtn($(e.currentTarget));
        r.error = () => enableBtn($(e.currentTarget));
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message), locateTo(undefined, 1000);
          } catch (error) {
            cl(error);
            sweetAlert("error", res), r.error();
          }
        };
        const c = new Confirm();
        c.ok = () => r.send();
        c.okText = "Yes, Cancel Return";
        c.text = "Order return request will be cancelled and can't be undone ";
        c.show();
      });

      $("#cancelReplacement").on("click", (e) => {
        const r = new Ajax();
        r.data = {
          case: "cancel_replacement",
          action: "ecommerce_orders_actions",
          order_id: $_GET["id"],
        };
        r.before = () => disableBtn($(e.currentTarget));
        r.error = () => enableBtn($(e.currentTarget));
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message), locateTo(undefined, 1000);
          } catch (error) {
            cl(error);
            sweetAlert("error", res), r.error();
          }
        };
        const c = new Confirm();
        c.ok = () => r.send();
        c.okText = "Yes, Cancel Replacement";
        c.text =
          "Order replacement request will be cancelled and can't be undone ";
        c.show();
      });
    },
  };

  _.Install = () => {
    function scroll_to_class(element_class, removed_height) {
      var scroll_to = $(element_class).offset().top - removed_height;
      if ($(window).scrollTop() != scroll_to) {
        $("html, body").stop().animate(
          {
            scrollTop: scroll_to,
          },
          0
        );
      }
    }

    function bar_progress(progress_line_object, direction) {
      var number_of_steps = progress_line_object.data("number-of-steps");
      var now_value = progress_line_object.data("now-value");
      var new_value = 0;
      if (direction == "right") {
        new_value = now_value + 100 / number_of_steps;
      } else if (direction == "left") {
        new_value = now_value - 100 / number_of_steps;
      }
      progress_line_object
        .attr("style", "width: " + new_value + "%;")
        .data("now-value", new_value);
    }

    $(".f1 fieldset:first").fadeIn("slow");

    $(".f1 .btn-next").on("click", function () {
      var parent_fieldset = $(this).parents("fieldset");
      var next_step = true;
      var current_active_step = $(this).parents(".f1").find(".f1-step.active");
      var progress_line = $(this).parents(".f1").find(".f1-progress-line");
      parent_fieldset.find("[required]").each(function () {
        if ($(this).val() == "") {
          $(this).addClass("is-invalid");
          next_step = false;
        } else {
          $(this).removeClass("is-invalid");
        }
      });
      if (next_step) {
        parent_fieldset.fadeOut(400, function () {
          current_active_step
            .removeClass("active")
            .addClass("activated")
            .next()
            .addClass("active");
          bar_progress(progress_line, "right");
          $(this).next().fadeIn();
          scroll_to_class($(".f1"), 20);
        });
      }
    });

    let form = $("form");
    form.each((f, e) => {
      const currentForm = $(e);
      const F = new FormValidate(currentForm);
      F.onValidate = () => {
        const r = new Ajax();
        r.url = "setup";
        r.data = currentForm.serialize();
        r.before = () => disableElement(currentForm, 2);
        r.complete = () => enableElement(currentForm);
        r.success = (res) => {
          try {
            res = JSON.parse(res);
            sweetAlert("success", res.message),
              res.url
                ? locateTo(res.url, 1000)
                : currentForm
                    .siblings(".f1-buttons")
                    .find("button")
                    .trigger("click");
          } catch (error) {
            cl(error);
            sweetAlert("error", res);
          }
        };
        r.send();
      };
    });
  };

  (() => {
    const C = $("#headerCategoryWrapper");
    $("body").on("click", '[data-header-category="true"]', (e) => {
      const t = $(e.currentTarget);
      const id = t.data("id");
      const r = new Ajax();
      r.data = {
        category_id: id,
        case: "fetch_categories",
        action: "ecommerce_actions",
      };
      r.before = () => disableElement(t);
      r.success = (res) => {
        try {
          res = JSON.parse(res);
          C.html(res.data);
        } catch (error) {
          cl(error);
          sweetAlert("error", res);
        }
      };
      r.send();
      r.complete = () => enableElement(t);
    });
  })();

  LXUtil.onDOMContentLoaded(() => {
    $("#pagePreloader").fadeOut(500, () => {
      $("#pagePreloader").remove();
    });

    clamp();
    const to = ({ l, t }) => {
      l.toggleClass("close");
      t.toggleClass("open");
      t.find(".shade").toggleClass("show");
    };

    $(".header-bar-left").on("click", (e) => {
      to({
        l: $(e.currentTarget),
        t: $(".header-left-sidebar-wrapper"),
      });
    });

    $(".header-bar-right").on("click", (e) => {
      to({
        l: $(e.currentTarget),
        t: $(".header-right-sidebar-wrapper"),
      });
    });

    $("body").on("mouseup", function (e) {
      if (
        !$(".mobile-menu-wrapper-left .menu").is(e.target) &&
        $(".mobile-menu-wrapper-left .menu").has(e.target).length === 0 &&
        !$(".header-bar-left").is(e.target) &&
        $(".header-bar-left").has(e.target).length === 0 &&
        $(".mobile-menu-wrapper-left").hasClass("open")
      ) {
        to({
          l: $(".header-bar-left"),
          t: $(".header-left-sidebar-wrapper"),
        });
      }
    });

    $("body").on("mouseup", function (e) {
      if (
        !$(".mobile-menu-wrapper-right .menu").is(e.target) &&
        $(".mobile-menu-wrapper-right .menu").has(e.target).length === 0 &&
        !$(".header-bar-right").is(e.target) &&
        $(".header-bar-right").has(e.target).length === 0 &&
        $(".mobile-menu-wrapper-right").hasClass("open")
      ) {
        to({
          l: $(".header-bar-right"),
          t: $(".header-right-sidebar-wrapper"),
        });
      }
    });

    $(".go_back").on("click", () => history.back());

    $(window).on("resize", function () {
      var width = $(window).width();
      if (width > 992) {
        $("#sort_by_modal").modal("hide");
        $("#filter_modal").modal("hide");
      }
    });
    $(window).bind("popstate", function () {
      ajaxPageLocate({
        url: location.href,
        replace: true,
      });
    });

    window.paceOptions = {
      ajax: {
        restartOnRequestAfter: false,
        trackMethods: ["GET", "POST"],
      },
    };

    $("body").on("click", "a[href]:not([false-url])", (e) => {
      const t = $(e.currentTarget);
      return locateToAnchorUrl(t);
    });
    $("body").on("click", function (e) {
      $("[data-bs-toggle=popover]").each(function () {
        // hide any open popovers when the anywhere else in the body is clicked
        if (
          !$(this).is(e.target) &&
          $(this).has(e.target).length === 0 &&
          $(".popover").has(e.target).length === 0
        ) {
          $(this).popover("hide");
        }
      });
    });
    fillSelect();

    $("[data-parent-remove=true]").on("click", (e) => {
      const t = $(e.currentTarget);
      const eq = t.data("parent-eq");
      remove(t.parents().eq(eq));
    });

    $("body").on("click", ".go-back", () => history.go(-1));

    $("body").on("click", ".password-toggle", (e) => {
      const t = $(e.currentTarget);
      const state = t.hasClass("show");
      if (state) {
        t.siblings("input[type=password]").attr("type", "text");
        t.removeClass("show").addClass("hide");
      } else {
        t.siblings("input[type=text]").attr("type", "password");
        t.addClass("show").removeClass("hide");
      }
    });

    $("body").on("click", '[data-action="closeLxMenu"]', () => {
      LXMenu.hideDropdowns();
    });

    $(document).on("show.bs.modal", ".modal", function () {
      select2();
      const zIndex = 1040 + 10 * $(".modal:visible").length;
      $(this).css("z-index", zIndex);
      setTimeout(() =>
        $(".modal-backdrop")
          .not(".modal-stack")
          .css("z-index", zIndex - 1)
          .addClass("modal-stack")
      );
    });
  });

})(window);
