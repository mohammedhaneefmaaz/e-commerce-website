void function (e, t) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : (e = "undefined" != typeof globalThis ? globalThis : e || self).Tagify = t()
}(this, (function () {
    "use strict";

    function e(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var i = Object.getOwnPropertySymbols(e);
            t && (i = i.filter((function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable
            }))), n.push.apply(n, i)
        }
        return n
    }

    function t(t) {
        for (var i = 1; i < arguments.length; i++) {
            var a = null != arguments[i] ? arguments[i] : {};
            i % 2 ? e(Object(a), !0).forEach((function (e) {
                n(t, e, a[e])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : e(Object(a)).forEach((function (e) {
                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e))
            }))
        }
        return t
    }

    function n(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    const i = (e, t, n, i) => (e = "" + e, t = "" + t, i && (e = e.trim(), t = t.trim()), n ? e == t : e.toLowerCase() == t.toLowerCase());

    function a(e, t) {
        var n, i = {};
        for (n in e) t.indexOf(n) < 0 && (i[n] = e[n]);
        return i
    }

    function r(e) {
        var t = document.createElement("div");
        return e.replace(/\&#?[0-9a-z]+;/gi, (function (e) {
            return t.innerHTML = e, t.innerText
        }))
    }

    function s(e, t) {
        for (t = t || "previous"; e = e[t + "Sibling"];)
            if (3 == e.nodeType) return e
    }

    function o(e) {
        return "string" == typeof e ? e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/`|'/g, "&#039;") : e
    }

    function l(e) {
        var t = Object.prototype.toString.call(e).split(" ")[1].slice(0, -1);
        return e === Object(e) && "Array" != t && "Function" != t && "RegExp" != t && "HTMLUnknownElement" != t
    }

    function c(e, t, n) {
        function i(e, t) {
            for (var n in t)
                if (t.hasOwnProperty(n)) {
                    if (l(t[n])) {
                        l(e[n]) ? i(e[n], t[n]) : e[n] = Object.assign({}, t[n]);
                        continue
                    }
                    if (Array.isArray(t[n])) {
                        e[n] = Object.assign([], t[n]);
                        continue
                    }
                    e[n] = t[n]
                }
        }
        return e instanceof Object || (e = {}), i(e, t), n && i(e, n), e
    }

    function u(e) {
        return String.prototype.normalize ? "string" == typeof e ? e.normalize("NFD").replace(/[\u0300-\u036f]/g, "") : void 0 : e
    }
    var d = () => /(?=.*chrome)(?=.*android)/i.test(navigator.userAgent);

    function h(e) {
        return e && e.classList && e.classList.contains(this.settings.classNames.tag)
    }
    var f = {
        delimiters: ",",
        pattern: null,
        tagTextProp: "value",
        maxTags: 1 / 0,
        callbacks: {},
        addTagOnBlur: !0,
        duplicates: !1,
        whitelist: [],
        blacklist: [],
        enforceWhitelist: !1,
        userInput: !0,
        keepInvalidTags: !1,
        mixTagsAllowedAfter: /,|\.|\:|\s/,
        mixTagsInterpolator: ["[[", "]]"],
        backspace: !0,
        skipInvalid: !1,
        pasteAsTags: !0,
        editTags: {
            clicks: 2,
            keepInvalid: !0
        },
        transformTag: () => {},
        trim: !0,
        a11y: {
            focusableTags: !1
        },
        mixMode: {
            insertAfterTag: " "
        },
        autoComplete: {
            enabled: !0,
            rightKey: !1
        },
        classNames: {
            namespace: "tagify",
            mixMode: "tagify--mix",
            selectMode: "tagify--select",
            input: "tagify__input",
            focus: "tagify--focus",
            tag: "tagify__tag",
            tagNoAnimation: "tagify--noAnim",
            tagInvalid: "tagify--invalid",
            tagNotAllowed: "tagify--notAllowed",
            inputInvalid: "tagify__input--invalid",
            tagX: "tagify__tag__removeBtn",
            tagText: "tagify__tag-text",
            dropdown: "tagify__dropdown",
            dropdownWrapper: "tagify__dropdown__wrapper",
            dropdownItem: "tagify__dropdown__item",
            dropdownItemActive: "tagify__dropdown__item--active",
            dropdownInital: "tagify__dropdown--initial",
            scopeLoading: "tagify--loading",
            tagLoading: "tagify__tag--loading",
            tagEditing: "tagify__tag--editable",
            tagFlash: "tagify__tag--flash",
            tagHide: "tagify__tag--hide",
            hasMaxTags: "tagify--hasMaxTags",
            hasNoTags: "tagify--noTags",
            empty: "tagify--empty"
        },
        dropdown: {
            classname: "",
            enabled: 2,
            maxItems: 10,
            searchKeys: ["value", "searchBy"],
            fuzzySearch: !0,
            caseSensitive: !1,
            accentedSearch: !0,
            highlightFirst: !1,
            closeOnSelect: !0,
            clearOnSelect: !0,
            position: "all",
            appendTarget: null
        },
        hooks: {
            beforeRemoveTag: () => Promise.resolve(),
            beforePaste: () => Promise.resolve(),
            suggestionClick: () => Promise.resolve()
        }
    };

    function p() {
        this.dropdown = {};
        for (let e in this._dropdown) this.dropdown[e] = "function" == typeof this._dropdown[e] ? this._dropdown[e].bind(this) : this._dropdown[e];
        this.settings.dropdown.enabled >= 0 && this.dropdown.init()
    }
    var m = {
        init() {
            this.DOM.dropdown = this.parseTemplate("dropdown", [this.settings]), this.DOM.dropdown.content = this.DOM.dropdown.querySelector(this.settings.classNames.dropdownWrapperSelector)
        },
        show(e) {
            var t, n, a, r = this.settings,
                s = "mix" == r.mode && !r.enforceWhitelist,
                o = !r.whitelist || !r.whitelist.length,
                c = "manual" == r.dropdown.position;
            if (e = void 0 === e ? this.state.inputText : e, (!o || s || r.templates.dropdownItemNoMatch) && !1 !== r.dropdown.enable && !this.state.isLoading) {
                if (clearTimeout(this.dropdownHide__bindEventsTimeout), this.suggestedListItems = this.dropdown.filterListItems(e), e && !this.suggestedListItems.length && (this.trigger("dropdown:noMatch", e), r.templates.dropdownItemNoMatch && (a = r.templates.dropdownItemNoMatch.call(this, {
                        value: e
                    }))), !a) {
                    if (this.suggestedListItems.length) e && s && !this.state.editing.scope && !i(this.suggestedListItems[0].value, e) && this.suggestedListItems.unshift({
                        value: e
                    });
                    else {
                        if (!e || !s || this.state.editing.scope) return this.input.autocomplete.suggest.call(this), void this.dropdown.hide();
                        this.suggestedListItems = [{
                            value: e
                        }]
                    }
                    n = "" + (l(t = this.suggestedListItems[0]) ? t.value : t), r.autoComplete && n && 0 == n.indexOf(e) && this.input.autocomplete.suggest.call(this, t)
                }
                this.dropdown.fill(a), r.dropdown.highlightFirst && this.dropdown.highlightOption(this.DOM.dropdown.content.children[0]), this.state.dropdown.visible || setTimeout(this.dropdown.events.binding.bind(this)), this.state.dropdown.visible = e || !0, this.state.dropdown.query = e, this.setStateSelection(), c || setTimeout((() => {
                    this.dropdown.position(), this.dropdown.render()
                })), setTimeout((() => {
                    this.trigger("dropdown:show", this.DOM.dropdown)
                }))
            }
        },
        hide(e) {
            var t = this.DOM,
                n = t.scope,
                i = t.dropdown,
                a = "manual" == this.settings.dropdown.position && !e;
            if (i && document.body.contains(i) && !a) return window.removeEventListener("resize", this.dropdown.position), this.dropdown.events.binding.call(this, !1), n.setAttribute("aria-expanded", !1), i.parentNode.removeChild(i), setTimeout((() => {
                this.state.dropdown.visible = !1
            }), 100), this.state.dropdown.query = this.state.ddItemData = this.state.ddItemElm = this.state.selection = null, this.state.tag && this.state.tag.value.length && (this.state.flaggedTags[this.state.tag.baseOffset] = this.state.tag), this.trigger("dropdown:hide", i), this
        },
        toggle(e) {
            this.dropdown[this.state.dropdown.visible && !e ? "hide" : "show"]()
        },
        render() {
            var e, t, n = ((t = this.DOM.dropdown.cloneNode(!0)).style.cssText = "position:fixed; top:-9999px; opacity:0", document.body.appendChild(t), e = t.clientHeight, t.parentNode.removeChild(t), e),
                i = this.settings;
            return this.DOM.scope.setAttribute("aria-expanded", !0), document.body.contains(this.DOM.dropdown) || (this.DOM.dropdown.classList.add(i.classNames.dropdownInital), this.dropdown.position(n), i.dropdown.appendTarget.appendChild(this.DOM.dropdown), setTimeout((() => this.DOM.dropdown.classList.remove(i.classNames.dropdownInital)))), this
        },
        fill(e) {
            var t;
            e = "string" == typeof e ? e : this.dropdown.createListHTML(e || this.suggestedListItems), this.DOM.dropdown.content.innerHTML = (t = e) ? t.replace(/\>[\r\n ]+\</g, "><").replace(/(<.*?>)|\s+/g, ((e, t) => t || " ")) : ""
        },
        refilter(e) {
            e = e || this.state.dropdown.query || "", this.suggestedListItems = this.dropdown.filterListItems(e), this.dropdown.fill(), this.suggestedListItems.length || this.dropdown.hide(), this.trigger("dropdown:updated", this.DOM.dropdown)
        },
        position(e) {
            var t = this.settings.dropdown;
            if ("manual" != t.position) {
                var n, i, a, r, s, o, l = this.DOM.dropdown,
                    c = t.placeAbove,
                    u = document.documentElement.clientHeight,
                    d = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0) > 480 ? t.position : "all",
                    h = this.DOM["input" == d ? "input" : "scope"];
                e = e || l.clientHeight, this.state.dropdown.visible && ("text" == d ? (a = (n = this.getCaretGlobalPosition()).bottom, i = n.top, r = n.left, s = "auto") : (o = function (e) {
                    for (var t = 0, n = 0; e;) t += e.offsetLeft || 0, n += e.offsetTop || 0, e = e.parentNode;
                    return {
                        left: t,
                        top: n
                    }
                }(this.settings.dropdown.appendTarget), i = (n = h.getBoundingClientRect()).top - o.top, a = n.bottom - 1 - o.top, r = n.left - o.left, s = n.width + "px"), i = Math.floor(i), a = Math.ceil(a), c = void 0 === c ? u - n.bottom < e : c, l.style.cssText = "left:" + (r + window.pageXOffset) + "px; width:" + s + ";" + (c ? "top: " + (i + window.pageYOffset) + "px" : "top: " + (a + window.pageYOffset) + "px"), l.setAttribute("placement", c ? "top" : "bottom"), l.setAttribute("position", d))
            }
        },
        events: {
            binding(e = !0) {
                var t = this.dropdown.events.callbacks,
                    n = this.listeners.dropdown = this.listeners.dropdown || {
                        position: this.dropdown.position.bind(this),
                        onKeyDown: t.onKeyDown.bind(this),
                        onMouseOver: t.onMouseOver.bind(this),
                        onMouseLeave: t.onMouseLeave.bind(this),
                        onClick: t.onClick.bind(this),
                        onScroll: t.onScroll.bind(this)
                    },
                    i = e ? "addEventListener" : "removeEventListener";
                "manual" != this.settings.dropdown.position && (window[i]("resize", n.position), window[i]("keydown", n.onKeyDown)), this.DOM.dropdown[i]("mouseover", n.onMouseOver), this.DOM.dropdown[i]("mouseleave", n.onMouseLeave), this.DOM.dropdown[i]("mousedown", n.onClick), this.DOM.dropdown.content[i]("scroll", n.onScroll)
            },
            callbacks: {
                onKeyDown(e) {
                    var t = this.DOM.dropdown.querySelector(this.settings.classNames.dropdownItemActiveSelector),
                        n = this.dropdown.getSuggestionDataByNode(t);
                    switch (e.key) {
                        case "ArrowDown":
                        case "ArrowUp":
                        case "Down":
                        case "Up":
                            var i;
                            e.preventDefault(), t && (t = t[("ArrowUp" == e.key || "Up" == e.key ? "previous" : "next") + "ElementSibling"]), t || (i = this.DOM.dropdown.content.children, t = i["ArrowUp" == e.key || "Up" == e.key ? i.length - 1 : 0]), n = this.dropdown.getSuggestionDataByNode(t), this.dropdown.highlightOption(t, !0);
                            break;
                        case "Escape":
                        case "Esc":
                            this.dropdown.hide();
                            break;
                        case "ArrowRight":
                            if (this.state.actions.ArrowLeft) return;
                        case "Tab":
                            if ("mix" != this.settings.mode && t && !this.settings.autoComplete.rightKey && !this.state.editing) {
                                e.preventDefault();
                                var a = this.dropdown.getMappedValue(n);
                                return this.input.autocomplete.set.call(this, a), !1
                            }
                            return !0;
                        case "Enter":
                            e.preventDefault(), this.settings.hooks.suggestionClick(e, {
                                tagify: this,
                                tagData: n,
                                suggestionElm: t
                            }).then((() => {
                                if (t) return this.dropdown.selectOption(t);
                                this.dropdown.hide(), "mix" != this.settings.mode && this.addTags(this.state.inputText.trim(), !0)
                            })).catch((e => e));
                            break;
                        case "Backspace": {
                            if ("mix" == this.settings.mode || this.state.editing.scope) return;
                            const e = this.input.raw.call(this);
                            "" != e && 8203 != e.charCodeAt(0) || (!0 === this.settings.backspace ? this.removeTags() : "edit" == this.settings.backspace && setTimeout(this.editTag.bind(this), 0))
                        }
                    }
                },
                onMouseOver(e) {
                    var t = e.target.closest(this.settings.classNames.dropdownItemSelector);
                    t && this.dropdown.highlightOption(t)
                },
                onMouseLeave(e) {
                    this.dropdown.highlightOption()
                },
                onClick(e) {
                    if (0 == e.button && e.target != this.DOM.dropdown && e.target != this.DOM.dropdown.content) {
                        var t = e.target.closest(this.settings.classNames.dropdownItemSelector),
                            n = this.dropdown.getSuggestionDataByNode(t);
                        this.state.actions.selectOption = !0, setTimeout((() => this.state.actions.selectOption = !1), 50), this.settings.hooks.suggestionClick(e, {
                            tagify: this,
                            tagData: n,
                            suggestionElm: t
                        }).then((() => {
                            t ? this.dropdown.selectOption(t) : this.dropdown.hide()
                        })).catch((e => console.warn(e)))
                    }
                },
                onScroll(e) {
                    var t = e.target,
                        n = t.scrollTop / (t.scrollHeight - t.parentNode.clientHeight) * 100;
                    this.trigger("dropdown:scroll", {
                        percentage: Math.round(n)
                    })
                }
            }
        },
        getSuggestionDataByNode(e) {
            var t = e ? +e.getAttribute("tagifySuggestionIdx") : -1;
            return this.suggestedListItems[t] || null
        },
        highlightOption(e, t) {
            var n, i = this.settings.classNames.dropdownItemActive;
            if (this.state.ddItemElm && (this.state.ddItemElm.classList.remove(i), this.state.ddItemElm.removeAttribute("aria-selected")), !e) return this.state.ddItemData = null, this.state.ddItemElm = null, void this.input.autocomplete.suggest.call(this);
            n = this.suggestedListItems[this.getNodeIndex(e)], this.state.ddItemData = n, this.state.ddItemElm = e, e.classList.add(i), e.setAttribute("aria-selected", !0), t && (e.parentNode.scrollTop = e.clientHeight + e.offsetTop - e.parentNode.clientHeight), this.settings.autoComplete && (this.input.autocomplete.suggest.call(this, n), this.dropdown.position())
        },
        selectOption(e) {
            var t, n = this.settings.dropdown,
                i = n.clearOnSelect,
                a = n.closeOnSelect;
            if (!e) return t = this.addTags(this.state.inputText, !0), void(a && this.dropdown.hide());
            var r = e.getAttribute("tagifySuggestionIdx"),
                s = this.suggestedListItems[+r];
            this.trigger("dropdown:select", {
                data: s,
                elm: e
            }), r && s ? (this.state.editing ? this.onEditTagDone(null, c({
                __isValid: !0
            }, this.normalizeTags(s)[0])) : t = this["mix" == this.settings.mode ? "addMixTags" : "addTags"]([s], i), this.DOM.input.parentNode && (setTimeout((() => {
                this.DOM.input.focus(), this.toggleFocusClass(!0), this.placeCaretAfterNode(t)
            })), a ? setTimeout(this.dropdown.hide.bind(this)) : this.dropdown.refilter())) : this.dropdown.hide()
        },
        selectAll() {
            return this.suggestedListItems.length = 0, this.dropdown.hide(), this.addTags(this.dropdown.filterListItems(""), !0), this
        },
        filterListItems(e, t) {
            var n, i, a, r, s, o = this.settings,
                c = o.dropdown,
                d = (t = t || {}, e = "select" == o.mode && this.value.length && this.value[0][o.tagTextProp] == e ? "" : e, []),
                h = [],
                f = o.whitelist,
                p = c.maxItems || 1 / 0,
                m = c.searchKeys,
                g = 0;
            if (!e || !m.length) return (o.duplicates ? f : f.filter((e => !this.isTagDuplicate(l(e) ? e.value : e)))).slice(0, p);

            function v(e, t) {
                return t.toLowerCase().split(" ").every((t => e.includes(t.toLowerCase())))
            }
            for (s = c.caseSensitive ? "" + e : ("" + e).toLowerCase(); g < f.length; g++) {
                let e, p;
                n = f[g] instanceof Object ? f[g] : {
                    value: f[g]
                };
                let y = Object.keys(n).some((e => m.includes(e))) ? m : ["value"];
                c.fuzzySearch && !t.exact ? (a = y.reduce(((e, t) => e + " " + (n[t] || "")), "").toLowerCase().trim(), c.accentedSearch && (a = u(a), s = u(s)), e = 0 == a.indexOf(s), p = a === s, i = v(a, s)) : (e = !0, i = y.some((e => {
                    var i = "" + (n[e] || "");
                    return c.accentedSearch && (i = u(i), s = u(s)), c.caseSensitive || (i = i.toLowerCase()), p = i === s, t.exact ? i === s : 0 == i.indexOf(s)
                }))), r = !o.duplicates && this.isTagDuplicate(l(n) ? n.value : n), i && !r && (p && e ? h.push(n) : "startsWith" == c.sortby && e ? d.unshift(n) : d.push(n))
            }
            return "function" == typeof c.sortby ? c.sortby(h.concat(d), s) : h.concat(d).slice(0, p)
        },
        getMappedValue(e) {
            var t = this.settings.dropdown.mapValueTo;
            return t ? "function" == typeof t ? t(e) : e[t] || e.value : e.value
        },
        createListHTML(e) {
            return c([], e).map(((e, t) => {
                "string" != typeof e && "number" != typeof e || (e = {
                    value: e
                });
                var n = this.dropdown.getMappedValue(e);
                e.value = n && "string" == typeof n ? o(n) : n;
                var i = this.settings.templates.dropdownItem.apply(this, [e, this]);
                return i.replace(/\s*tagifySuggestionIdx=(["'])(.*?)\1/gim, "").replace(">", ` tagifySuggestionIdx="${t}">`)
            })).join("")
        }
    };
    const g = "@yaireo/tagify/";
    var v, y = {
            empty: "empty",
            exceed: "number of tags exceeded",
            pattern: "pattern mismatch",
            duplicate: "already exists",
            notAllowed: "not allowed"
        },
        b = {
            wrapper: (e, t) => `<tags class="${t.classNames.namespace} ${t.mode?`${t.classNames[t.mode+"Mode"]}`:""} ${e.className}"\n                    ${t.readonly?"readonly":""}\n                    ${t.disabled?"disabled":""}\n                    ${t.required?"required":""}\n                    tabIndex="-1">\n            <span ${!t.readonly&&t.userInput?"contenteditable":""} tabIndex="0" data-placeholder="${t.placeholder||"&#8203;"}" aria-placeholder="${t.placeholder||""}"\n                class="${t.classNames.input}"\n                role="textbox"\n                aria-autocomplete="both"\n                aria-multiline="${"mix"==t.mode}"></span>\n                &#8203;\n        </tags>`,
            tag(e, t) {
                var n = this.settings;
                return `<tag title="${e.title||e.value}"\n                    contenteditable='false'\n                    spellcheck='false'\n                    tabIndex="${n.a11y.focusableTags?0:-1}"\n                    class="${n.classNames.tag} ${e.class||""}"\n                    ${this.getAttributes(e)}>\n            <x title='' class="${n.classNames.tagX}" role='button' aria-label='remove tag'></x>\n            <div>\n                <span class="${n.classNames.tagText}">${e[n.tagTextProp]||e.value}</span>\n            </div>\n        </tag>`
            },
            dropdown(e) {
                var t = e.dropdown,
                    n = "manual" == t.position,
                    i = `${e.classNames.dropdown}`;
                return `<div class="${n?"":i} ${t.classname}" role="listbox" aria-labelledby="dropdown">\n                    <div class="${e.classNames.dropdownWrapper}"></div>\n                </div>`
            },
            dropdownItem(e, t) {
                return `<div ${this.getAttributes(e)}\n                    class='${this.settings.classNames.dropdownItem} ${e.class?e.class:""}'\n                    tabindex="0"\n                    role="option">${e.value}</div>`
            },
            dropdownItemNoMatch: null
        },
        x = {
            customBinding() {
                this.customEventsList.forEach((e => {
                    this.on(e, this.settings.callbacks[e])
                }))
            },
            binding(e = !0) {
                var t, n = this.events.callbacks,
                    i = e ? "addEventListener" : "removeEventListener";
                if (!this.state.mainEvents || !e) {
                    for (var a in this.state.mainEvents = e, e && !this.listeners.main && (this.events.bindGlobal.call(this), this.settings.isJQueryPlugin && jQuery(this.DOM.originalInput).on("tagify.removeAllTags", this.removeAllTags.bind(this))), t = this.listeners.main = this.listeners.main || {
                            focus: ["input", n.onFocusBlur.bind(this)],
                            keydown: ["input", n.onKeydown.bind(this)],
                            click: ["scope", n.onClickScope.bind(this)],
                            dblclick: ["scope", n.onDoubleClickScope.bind(this)],
                            paste: ["input", n.onPaste.bind(this)],
                            drop: ["input", n.onDrop.bind(this)]
                        }) this.DOM[t[a][0]][i](a, t[a][1]);
                    clearInterval(this.listeners.main.originalInputValueObserverInterval), this.listeners.main.originalInputValueObserverInterval = setInterval(n.observeOriginalInputValue.bind(this), 500);
                    var r = this.listeners.main.inputMutationObserver || new MutationObserver(n.onInputDOMChange.bind(this));
                    r && r.disconnect(), "mix" == this.settings.mode && r.observe(this.DOM.input, {
                        childList: !0
                    })
                }
            },
            bindGlobal(e) {
                var t, n = this.events.callbacks,
                    i = e ? "removeEventListener" : "addEventListener";
                if (e || !this.listeners.global)
                    for (t of (this.listeners.global = this.listeners && this.listeners.global || [{
                            type: this.isIE ? "keydown" : "input",
                            target: this.DOM.input,
                            cb: n[this.isIE ? "onInputIE" : "onInput"].bind(this)
                        }, {
                            type: "keydown",
                            target: window,
                            cb: n.onWindowKeyDown.bind(this)
                        }, {
                            type: "blur",
                            target: this.DOM.input,
                            cb: n.onFocusBlur.bind(this)
                        }], this.listeners.global)) t.target[i](t.type, t.cb)
            },
            unbindGlobal() {
                this.events.bindGlobal.call(this, !0)
            },
            callbacks: {
                onFocusBlur(e) {
                    var t = e.target ? this.trim(e.target.textContent) : "",
                        n = this.settings,
                        i = e.type,
                        a = n.dropdown.enabled >= 0,
                        r = {
                            relatedTarget: e.relatedTarget
                        },
                        s = this.state.actions.selectOption && (a || !n.dropdown.closeOnSelect),
                        o = this.state.actions.addNew && a,
                        l = e.relatedTarget && h.call(this, e.relatedTarget) && this.DOM.scope.contains(e.relatedTarget);
                    if ("blur" == i) {
                        if (e.relatedTarget === this.DOM.scope) return this.dropdown.hide(), void this.DOM.input.focus();
                        this.postUpdate(), this.triggerChangeEvent()
                    }
                    if (!s && !o)
                        if (this.state.hasFocus = "focus" == i && +new Date, this.toggleFocusClass(this.state.hasFocus), "mix" != n.mode) {
                            if ("focus" == i) return this.trigger("focus", r), void(0 !== n.dropdown.enabled && n.userInput || this.dropdown.show(this.value.length ? "" : void 0));
                            "blur" == i && (this.trigger("blur", r), this.loading(!1), "select" == this.settings.mode && l && (t = ""), ("select" == this.settings.mode && t ? !this.value.length || this.value[0].value != t : t && !this.state.actions.selectOption && n.addTagOnBlur) && this.addTags(t, !0), "select" != this.settings.mode || t || this.removeTags()), this.DOM.input.removeAttribute("style"), this.dropdown.hide()
                        } else "focus" == i ? this.trigger("focus", r) : "blur" == e.type && (this.trigger("blur", r), this.loading(!1), this.dropdown.hide(), this.state.dropdown.visible = void 0, this.setStateSelection())
                },
                onWindowKeyDown(e) {
                    var t, n = document.activeElement;
                    if (h.call(this, n) && this.DOM.scope.contains(document.activeElement)) switch (t = n.nextElementSibling, e.key) {
                        case "Backspace":
                            this.removeTags(n), (t || this.DOM.input).focus();
                            break;
                        case "Enter":
                            setTimeout(this.editTag.bind(this), 0, n)
                    }
                },
                onKeydown(e) {
                    var t = this.settings;
                    "select" == t.mode && t.enforceWhitelist && this.value.length && "Tab" != e.key && e.preventDefault();
                    var n = this.trim(e.target.textContent);
                    if (this.trigger("keydown", {
                            originalEvent: this.cloneEvent(e)
                        }), "mix" == t.mode) {
                        switch (e.key) {
                            case "Left":
                            case "ArrowLeft":
                                this.state.actions.ArrowLeft = !0;
                                break;
                            case "Delete":
                            case "Backspace":
                                if (this.state.editing) return;
                                var i, a, o, l = document.getSelection(),
                                    c = "Delete" == e.key && l.anchorOffset == (l.anchorNode.length || 0),
                                    u = l.anchorNode.previousSibling,
                                    f = 1 == l.anchorNode.nodeType || !l.anchorOffset && u && 1 == u.nodeType && l.anchorNode.previousSibling,
                                    p = r(this.DOM.input.innerHTML),
                                    m = this.getTagElms();
                                if ("edit" == t.backspace && f) return i = 1 == l.anchorNode.nodeType ? null : l.anchorNode.previousElementSibling, setTimeout(this.editTag.bind(this), 0, i), void e.preventDefault();
                                if (d() && f) return o = s(f), f.hasAttribute("readonly") || f.remove(), this.DOM.input.focus(), void setTimeout((() => {
                                    this.placeCaretAfterNode(o), this.DOM.input.click()
                                }));
                                if ("BR" == l.anchorNode.nodeName) return;
                                if ((c || f) && 1 == l.anchorNode.nodeType ? a = 0 == l.anchorOffset ? c ? m[0] : null : m[l.anchorOffset - 1] : c ? a = l.anchorNode.nextElementSibling : f && (a = f), 3 == l.anchorNode.nodeType && !l.anchorNode.nodeValue && l.anchorNode.previousElementSibling && e.preventDefault(), (f || c) && !t.backspace) return void e.preventDefault();
                                if ("Range" != l.type && !l.anchorOffset && l.anchorNode == this.DOM.input && "Delete" != e.key) return void e.preventDefault();
                                if ("Range" != l.type && a && a.hasAttribute("readonly")) return void this.placeCaretAfterNode(s(a));
                                clearTimeout(v), v = setTimeout((() => {
                                    var e = document.getSelection(),
                                        t = r(this.DOM.input.innerHTML),
                                        n = !c && e.anchorNode.previousSibling;
                                    if (t.length >= p.length && n)
                                        if (h.call(this, n) && !n.hasAttribute("readonly")) {
                                            if (this.removeTags(n), this.fixFirefoxLastTagNoCaret(), 2 == this.DOM.input.children.length && "BR" == this.DOM.input.children[1].tagName) return this.DOM.input.innerHTML = "", this.value.length = 0, !0
                                        } else n.remove();
                                    this.value = [].map.call(m, ((e, t) => {
                                        var n = this.tagData(e);
                                        if (e.parentNode || n.readonly) return n;
                                        this.trigger("remove", {
                                            tag: e,
                                            index: t,
                                            data: n
                                        })
                                    })).filter((e => e))
                                }), 20)
                        }
                        return !0
                    }
                    switch (e.key) {
                        case "Backspace":
                            "select" == t.mode && t.enforceWhitelist && this.value.length ? this.removeTags() : this.state.dropdown.visible && "manual" != t.dropdown.position || "" != e.target.textContent && 8203 != n.charCodeAt(0) || (!0 === t.backspace ? this.removeTags() : "edit" == t.backspace && setTimeout(this.editTag.bind(this), 0));
                            break;
                        case "Esc":
                        case "Escape":
                            if (this.state.dropdown.visible) return;
                            e.target.blur();
                            break;
                        case "Down":
                        case "ArrowDown":
                            this.state.dropdown.visible || this.dropdown.show();
                            break;
                        case "ArrowRight": {
                            let e = this.state.inputSuggestion || this.state.ddItemData;
                            if (e && t.autoComplete.rightKey) return void this.addTags([e], !0);
                            break
                        }
                        case "Tab": {
                            let i = "select" == t.mode;
                            if (!n || i) return !0;
                            e.preventDefault()
                        }
                        case "Enter":
                            if (this.state.dropdown.visible || 229 == e.keyCode) return;
                            e.preventDefault(), setTimeout((() => {
                                this.state.actions.selectOption || this.addTags(n, !0)
                            }))
                    }
                },
                onInput(e) {
                    if (this.postUpdate(), "mix" == this.settings.mode) return this.events.callbacks.onMixTagsInput.call(this, e);
                    var t = this.input.normalize.call(this),
                        n = t.length >= this.settings.dropdown.enabled,
                        i = {
                            value: t,
                            inputElm: this.DOM.input
                        };
                    i.isValid = this.validateTag({
                        value: t
                    }), this.state.inputText != t && (this.input.set.call(this, t, !1), -1 != t.search(this.settings.delimiters) ? this.addTags(t) && this.input.set.call(this) : this.settings.dropdown.enabled >= 0 && this.dropdown[n ? "show" : "hide"](t), this.trigger("input", i))
                },
                onMixTagsInput(e) {
                    var t, n, i, a, r, s, o, l, u = this.settings,
                        h = this.value.length,
                        f = this.getTagElms(),
                        p = document.createDocumentFragment(),
                        m = window.getSelection().getRangeAt(0),
                        g = [].map.call(f, (e => this.tagData(e).value));
                    if ("deleteContentBackward" == e.inputType && d() && this.events.callbacks.onKeydown.call(this, {
                            target: e.target,
                            key: "Backspace"
                        }), this.value.slice().forEach((e => {
                            e.readonly && !g.includes(e.value) && p.appendChild(this.createTagElem(e))
                        })), p.childNodes.length && (m.insertNode(p), this.setRangeAtStartEnd(!1, p.lastChild)), f.length != h) return this.value = [].map.call(this.getTagElms(), (e => this.tagData(e))), void this.update({
                        withoutChangeEvent: !0
                    });
                    if (this.hasMaxTags()) return !0;
                    if (window.getSelection && (s = window.getSelection()).rangeCount > 0 && 3 == s.anchorNode.nodeType) {
                        if ((m = s.getRangeAt(0).cloneRange()).collapse(!0), m.setStart(s.focusNode, 0), i = (t = m.toString().slice(0, m.endOffset)).split(u.pattern).length - 1, (n = t.match(u.pattern)) && (a = t.slice(t.lastIndexOf(n[n.length - 1]))), a) {
                            if (this.state.actions.ArrowLeft = !1, this.state.tag = {
                                    prefix: a.match(u.pattern)[0],
                                    value: a.replace(u.pattern, "")
                                }, this.state.tag.baseOffset = s.baseOffset - this.state.tag.value.length, l = this.state.tag.value.match(u.delimiters)) return this.state.tag.value = this.state.tag.value.replace(u.delimiters, ""), this.state.tag.delimiters = l[0], this.addTags(this.state.tag.value, u.dropdown.clearOnSelect), void this.dropdown.hide();
                            r = this.state.tag.value.length >= u.dropdown.enabled;
                            try {
                                o = (o = this.state.flaggedTags[this.state.tag.baseOffset]).prefix == this.state.tag.prefix && o.value[0] == this.state.tag.value[0], this.state.flaggedTags[this.state.tag.baseOffset] && !this.state.tag.value && delete this.state.flaggedTags[this.state.tag.baseOffset]
                            } catch (e) {}(o || i < this.state.mixMode.matchedPatternCount) && (r = !1)
                        } else this.state.flaggedTags = {};
                        this.state.mixMode.matchedPatternCount = i
                    }
                    setTimeout((() => {
                        this.update({
                            withoutChangeEvent: !0
                        }), this.trigger("input", c({}, this.state.tag, {
                            textContent: this.DOM.input.textContent
                        })), this.state.tag && this.dropdown[r ? "show" : "hide"](this.state.tag.value)
                    }), 10)
                },
                onInputIE(e) {
                    var t = this;
                    setTimeout((function () {
                        t.events.callbacks.onInput.call(t, e)
                    }))
                },
                observeOriginalInputValue() {
                    this.DOM.originalInput.value != this.DOM.originalInput.tagifyValue && this.loadOriginalValues()
                },
                onClickScope(e) {
                    var t = this.settings,
                        n = e.target.closest("." + t.classNames.tag),
                        i = +new Date - this.state.hasFocus;
                    if (e.target != this.DOM.scope) {
                        if (!e.target.classList.contains(t.classNames.tagX)) return n ? (this.trigger("click", {
                            tag: n,
                            index: this.getNodeIndex(n),
                            data: this.tagData(n),
                            originalEvent: this.cloneEvent(e)
                        }), void(1 !== t.editTags && 1 !== t.editTags.clicks || this.events.callbacks.onDoubleClickScope.call(this, e))) : void(e.target == this.DOM.input && ("mix" == t.mode && this.fixFirefoxLastTagNoCaret(), i > 500) ? this.state.dropdown.visible ? this.dropdown.hide() : 0 === t.dropdown.enabled && "mix" != t.mode && this.dropdown.show(this.value.length ? "" : void 0) : "select" == t.mode && !this.state.dropdown.visible && this.dropdown.show());
                        this.removeTags(e.target.parentNode)
                    } else this.state.hasFocus || this.DOM.input.focus()
                },
                onPaste(e) {
                    e.preventDefault();
                    var t, n, i = this.settings;
                    if ("select" == i.mode && i.enforceWhitelist || !i.userInput) return !1;
                    i.readonly || (t = e.clipboardData || window.clipboardData, n = t.getData("Text"), i.hooks.beforePaste(e, {
                        tagify: this,
                        pastedText: n,
                        clipboardData: t
                    }).then((t => {
                        void 0 === t && (t = n), t && (this.injectAtCaret(t, window.getSelection().getRangeAt(0)), "mix" == this.settings.mode ? this.events.callbacks.onMixTagsInput.call(this, e) : this.settings.pasteAsTags ? this.addTags(this.state.inputText + t, !0) : this.state.inputText = t)
                    })).catch((e => e)))
                },
                onDrop(e) {
                    e.preventDefault()
                },
                onEditTagInput(e, t) {
                    var n = e.closest("." + this.settings.classNames.tag),
                        i = this.getNodeIndex(n),
                        a = this.tagData(n),
                        r = this.input.normalize.call(this, e),
                        s = n.innerHTML != n.__tagifyTagData.__originalHTML,
                        o = this.validateTag({
                            [this.settings.tagTextProp]: r
                        });
                    s || !0 !== e.originalIsValid || (o = !0), n.classList.toggle(this.settings.classNames.tagInvalid, !0 !== o), a.__isValid = o, n.title = !0 === o ? a.title || a.value : o, r.length >= this.settings.dropdown.enabled && (this.state.editing && (this.state.editing.value = r), this.dropdown.show(r)), this.trigger("edit:input", {
                        tag: n,
                        index: i,
                        data: c({}, this.value[i], {
                            newValue: r
                        }),
                        originalEvent: this.cloneEvent(t)
                    })
                },
                onEditTagFocus(e) {
                    this.state.editing = {
                        scope: e,
                        input: e.querySelector("[contenteditable]")
                    }
                },
                onEditTagBlur(e) {
                    if (this.state.hasFocus || this.toggleFocusClass(), this.DOM.scope.contains(e)) {
                        var t, n, i = this.settings,
                            a = e.closest("." + i.classNames.tag),
                            r = this.input.normalize.call(this, e),
                            s = this.tagData(a).__originalData,
                            o = a.innerHTML != a.__tagifyTagData.__originalHTML,
                            l = this.validateTag({
                                [i.tagTextProp]: r
                            });
                        if (r)
                            if (o) {
                                if (t = this.hasMaxTags(), n = this.getWhitelistItem(r) || c({}, s, {
                                        [i.tagTextProp]: r,
                                        value: r,
                                        __isValid: l
                                    }), i.transformTag.call(this, n, s), !0 !== (l = !t && this.validateTag({
                                        [i.tagTextProp]: n[i.tagTextProp]
                                    }))) {
                                    if (this.trigger("invalid", {
                                            data: n,
                                            tag: a,
                                            message: l
                                        }), i.editTags.keepInvalid) return;
                                    i.keepInvalidTags ? n.__isValid = l : n = s
                                } else i.keepInvalidTags && (delete n.title, delete n["aria-invalid"], delete n.class);
                                this.onEditTagDone(a, n)
                            } else this.onEditTagDone(a, s);
                        else this.onEditTagDone(a)
                    }
                },
                onEditTagkeydown(e, t) {
                    switch (this.trigger("edit:keydown", {
                        originalEvent: this.cloneEvent(e)
                    }), e.key) {
                        case "Esc":
                        case "Escape":
                            t.innerHTML = t.__tagifyTagData.__originalHTML;
                        case "Enter":
                        case "Tab":
                            e.preventDefault(), e.target.blur()
                    }
                },
                onDoubleClickScope(e) {
                    var t, n, i = e.target.closest("." + this.settings.classNames.tag),
                        a = this.settings;
                    i && a.userInput && (t = i.classList.contains(this.settings.classNames.tagEditing), n = i.hasAttribute("readonly"), "select" == a.mode || a.readonly || t || n || !this.settings.editTags || this.editTag(i), this.toggleFocusClass(!0), this.trigger("dblclick", {
                        tag: i,
                        index: this.getNodeIndex(i),
                        data: this.tagData(i)
                    }))
                },
                onInputDOMChange(e) {
                    e.forEach((e => {
                        e.addedNodes.forEach((e => {
                            if (e)
                                if ("<div><br></div>" == e.outerHTML) e.replaceWith(document.createElement("br"));
                                else if (1 == e.nodeType && e.querySelector(this.settings.classNames.tagSelector)) {
                                let t = document.createTextNode("");
                                3 == e.childNodes[0].nodeType && "BR" != e.previousSibling.nodeName && (t = document.createTextNode("\n")), e.replaceWith(t, ...[...e.childNodes].slice(0, -1)), this.placeCaretAfterNode(t.previousSibling)
                            } else h.call(this, e) && e.previousSibling && "BR" == e.previousSibling.nodeName && (e.previousSibling.replaceWith("\n​"), this.placeCaretAfterNode(e.previousSibling.previousSibling))
                        })), e.removedNodes.forEach((e => {
                            e && "BR" == e.nodeName && h.call(this, t) && (this.removeTags(t), this.fixFirefoxLastTagNoCaret())
                        }))
                    }));
                    var t = this.DOM.input.lastChild;
                    t && "" == t.nodeValue && t.remove(), t && "BR" == t.nodeName || this.DOM.input.appendChild(document.createElement("br"))
                }
            }
        };

    function _(e, t) {
        return e ? e.previousElementSibling && e.previousElementSibling.classList.contains("tagify") ? (console.warn("Tagify: ", "input element is already Tagified", e), this) : (c(this, function (e) {
            var t = document.createTextNode("");

            function n(e, n, i) {
                i && n.split(/\s+/g).forEach((n => t[e + "EventListener"].call(t, n, i)))
            }
            return {
                off(e, t) {
                    return n("remove", e, t), this
                },
                on(e, t) {
                    return t && "function" == typeof t && n("add", e, t), this
                },
                trigger(n, i, a) {
                    var r;
                    if (a = a || {
                            cloneData: !0
                        }, n)
                        if (e.settings.isJQueryPlugin) "remove" == n && (n = "removeTag"), jQuery(e.DOM.originalInput).triggerHandler(n, [i]);
                        else {
                            try {
                                var s = "object" == typeof i ? i : {
                                    value: i
                                };
                                if ((s = a.cloneData ? c({}, s) : s).tagify = this, i instanceof Object)
                                    for (var o in i) i[o] instanceof HTMLElement && (s[o] = i[o]);
                                r = new CustomEvent(n, {
                                    detail: s
                                })
                            } catch (e) {
                                console.warn(e)
                            }
                            t.dispatchEvent(r)
                        }
                }
            }
        }(this)), this.isFirefox = "undefined" != typeof InstallTrigger, this.isIE = window.document.documentMode, t = t || {}, this.getPersistedData = (n = t.id, e => {
            let t, i = "/" + e;
            if (1 == localStorage.getItem(g + n + "/v", 1)) try {
                t = JSON.parse(localStorage[g + n + i])
            } catch (e) {}
            return t
        }), this.setPersistedData = (e => e ? (localStorage.setItem(g + e + "/v", 1), (t, n) => {
            let i = "/" + n,
                a = JSON.stringify(t);
            t && n && (localStorage.setItem(g + e + i, a), dispatchEvent(new Event("storage")))
        }) : () => {})(t.id), this.clearPersistedData = (e => t => {
            const n = g + "/" + e + "/";
            if (t) localStorage.removeItem(n + t);
            else
                for (let e in localStorage) e.includes(n) && localStorage.removeItem(e)
        })(t.id), this.applySettings(e, t), this.state = {
            inputText: "",
            editing: !1,
            actions: {},
            mixMode: {},
            dropdown: {},
            flaggedTags: {}
        }, this.value = [], this.listeners = {}, this.DOM = {}, this.build(e), p.call(this), this.getCSSVars(), this.loadOriginalValues(), this.events.customBinding.call(this), this.events.binding.call(this), void(e.autofocus && this.DOM.input.focus())) : (console.warn("Tagify: ", "input element not found", e), this);
        var n
    }
    return _.prototype = {
        _dropdown: m,
        customEventsList: ["change", "add", "remove", "invalid", "input", "click", "keydown", "focus", "blur", "edit:input", "edit:beforeUpdate", "edit:updated", "edit:start", "edit:keydown", "dropdown:show", "dropdown:hide", "dropdown:select", "dropdown:updated", "dropdown:noMatch", "dropdown:scroll"],
        dataProps: ["__isValid", "__removed", "__originalData", "__originalHTML", "__tagId"],
        trim(e) {
            return this.settings.trim && e && "string" == typeof e ? e.trim() : e
        },
        parseHTML: function (e) {
            return (new DOMParser).parseFromString(e.trim(), "text/html").body.firstElementChild
        },
        templates: b,
        parseTemplate(e, t) {
            return e = this.settings.templates[e] || e, this.parseHTML(e.apply(this, t))
        },
        set whitelist(e) {
            const t = e && Array.isArray(e);
            this.settings.whitelist = t ? e : [], this.setPersistedData(t ? e : [], "whitelist")
        },
        get whitelist() {
            return this.settings.whitelist
        },
        applySettings(e, n) {
            f.templates = this.templates;
            var i = this.settings = c({}, f, n);
            i.disabled = e.hasAttribute("disabled"), i.readonly = e.hasAttribute("readonly"), i.placeholder = e.getAttribute("placeholder") || i.placeholder || "", i.required = e.hasAttribute("required");
            for (let e in i.classNames) Object.defineProperty(i.classNames, e + "Selector", {
                get() {
                    return "." + this[e].split(" ")[0]
                }
            });
            if (this.isIE && (i.autoComplete = !1), ["whitelist", "blacklist"].forEach((t => {
                    var n = e.getAttribute("data-" + t);
                    n && (n = n.split(i.delimiters)) instanceof Array && (i[t] = n)
                })), "autoComplete" in n && !l(n.autoComplete) && (i.autoComplete = f.autoComplete, i.autoComplete.enabled = n.autoComplete), "mix" == i.mode && (i.autoComplete.rightKey = !0, i.delimiters = n.delimiters || null, i.tagTextProp && !i.dropdown.searchKeys.includes(i.tagTextProp) && i.dropdown.searchKeys.push(i.tagTextProp)), e.pattern) try {
                i.pattern = new RegExp(e.pattern)
            } catch (e) {}
            if (this.settings.delimiters) try {
                i.delimiters = new RegExp(this.settings.delimiters, "g")
            } catch (e) {}
            i.disabled && (i.userInput = !1), this.TEXTS = t(t({}, y), i.texts || {}), "select" != i.mode && i.userInput || (i.dropdown.enabled = 0), i.dropdown.appendTarget = n.dropdown && n.dropdown.appendTarget ? n.dropdown.appendTarget : document.body;
            let a = this.getPersistedData("whitelist");
            Array.isArray(a) && (this.whitelist = Array.isArray(i.whitelist) ? function () {
                const e = [],
                    t = {};
                for (let n of arguments)
                    for (let i of n) l(i) ? t[i.value] || (e.push(i), t[i.value] = 1) : e.includes(i) || e.push(i);
                return e
            }(i.whitelist, a) : a)
        },
        getAttributes(e) {
            var t, n = this.getCustomAttributes(e),
                i = "";
            for (t in n) i += " " + t + (void 0 !== e[t] ? `="${n[t]}"` : "");
            return i
        },
        getCustomAttributes(e) {
            if (!l(e)) return "";
            var t, n = {};
            for (t in e) "__" != t.slice(0, 2) && "class" != t && e.hasOwnProperty(t) && void 0 !== e[t] && (n[t] = o(e[t]));
            return n
        },
        setStateSelection() {
            var e = window.getSelection(),
                t = {
                    anchorOffset: e.anchorOffset,
                    anchorNode: e.anchorNode,
                    range: e.getRangeAt && e.rangeCount && e.getRangeAt(0)
                };
            return this.state.selection = t, t
        },
        getCaretGlobalPosition() {
            const e = document.getSelection();
            if (e.rangeCount) {
                const t = e.getRangeAt(0),
                    n = t.startContainer,
                    i = t.startOffset;
                let a, r;
                if (i > 0) return r = document.createRange(), r.setStart(n, i - 1), r.setEnd(n, i), a = r.getBoundingClientRect(), {
                    left: a.right,
                    top: a.top,
                    bottom: a.bottom
                };
                if (n.getBoundingClientRect) return n.getBoundingClientRect()
            }
            return {
                left: -9999,
                top: -9999
            }
        },
        getCSSVars() {
            var e = getComputedStyle(this.DOM.scope, null);
            this.CSSVars = {
                tagHideTransition: (({
                    value: e,
                    unit: t
                }) => "s" == t ? 1e3 * e : e)(function (e) {
                    if (!e) return {};
                    var t = (e = e.trim().split(" ")[0]).split(/\d+/g).filter((e => e)).pop().trim();
                    return {
                        value: +e.split(t).filter((e => e))[0].trim(),
                        unit: t
                    }
                }(("tag-hide-transition", e.getPropertyValue("--tag-hide-transition"))))
            }
        },
        build(e) {
            var t = this.DOM;
            this.settings.mixMode.integrated ? (t.originalInput = null, t.scope = e, t.input = e) : (t.originalInput = e, t.scope = this.parseTemplate("wrapper", [e, this.settings]), t.input = t.scope.querySelector(this.settings.classNames.inputSelector), e.parentNode.insertBefore(t.scope, e))
        },
        destroy() {
            this.events.unbindGlobal.call(this), this.DOM.scope.parentNode.removeChild(this.DOM.scope), this.dropdown.hide(!0), clearTimeout(this.dropdownHide__bindEventsTimeout)
        },
        loadOriginalValues(e) {
            var t, n = this.settings;
            if (void 0 === e) {
                const t = this.getPersistedData("value");
                e = t && !this.DOM.originalInput.value ? t : n.mixMode.integrated ? this.DOM.input.textContent : this.DOM.originalInput.value
            }
            if (this.removeAllTags({
                    withoutChangeEvent: !0
                }), e)
                if ("mix" == n.mode) this.parseMixTags(e.trim()), (t = this.DOM.input.lastChild) && "BR" == t.tagName || this.DOM.input.insertAdjacentHTML("beforeend", "<br>");
                else {
                    try {
                        JSON.parse(e) instanceof Array && (e = JSON.parse(e))
                    } catch (e) {}
                    this.addTags(e).forEach((e => e && e.classList.add(n.classNames.tagNoAnimation)))
                }
            else this.postUpdate();
            this.state.lastOriginalValueReported = n.mixMode.integrated ? "" : this.DOM.originalInput.value, this.state.loadedOriginalValues = !0
        },
        cloneEvent(e) {
            var t = {};
            for (var n in e) t[n] = e[n];
            return t
        },
        loading(e) {
            return this.state.isLoading = e, this.DOM.scope.classList[e ? "add" : "remove"](this.settings.classNames.scopeLoading), this
        },
        tagLoading(e, t) {
            return e && e.classList[t ? "add" : "remove"](this.settings.classNames.tagLoading), this
        },
        toggleClass(e, t) {
            "string" == typeof e && this.DOM.scope.classList.toggle(e, t)
        },
        toggleFocusClass(e) {
            this.toggleClass(this.settings.classNames.focus, !!e)
        },
        triggerChangeEvent: function () {
            if (!this.settings.mixMode.integrated) {
                var e = this.DOM.originalInput,
                    t = this.state.lastOriginalValueReported !== e.value,
                    n = new CustomEvent("change", {
                        bubbles: !0
                    });
                t && (this.state.lastOriginalValueReported = e.value, n.simulated = !0, e._valueTracker && e._valueTracker.setValue(Math.random()), e.dispatchEvent(n), this.trigger("change", this.state.lastOriginalValueReported), e.value = this.state.lastOriginalValueReported)
            }
        },
        events: x,
        fixFirefoxLastTagNoCaret() {},
        placeCaretAfterNode(e) {
            if (e && e.parentNode) {
                var t = e.nextSibling,
                    n = window.getSelection(),
                    i = n.getRangeAt(0);
                n.rangeCount && (i.setStartAfter(t || e), i.collapse(!0), n.removeAllRanges(), n.addRange(i))
            }
        },
        insertAfterTag(e, t) {
            if (t = t || this.settings.mixMode.insertAfterTag, e && e.parentNode && t) return t = "string" == typeof t ? document.createTextNode(t) : t, e.parentNode.insertBefore(t, e.nextSibling), t
        },
        editTag(e, t) {
            e = e || this.getLastTag(), t = t || {}, this.dropdown.hide();
            var n = this.settings;

            function i() {
                return e.querySelector(n.classNames.tagTextSelector)
            }
            var a = i(),
                r = this.getNodeIndex(e),
                s = this.tagData(e),
                o = this.events.callbacks,
                l = this,
                u = !0;
            if (a) {
                if (!(s instanceof Object && "editable" in s) || s.editable) return a.setAttribute("contenteditable", !0), e.classList.add(n.classNames.tagEditing), this.tagData(e, {
                    __originalData: c({}, s),
                    __originalHTML: e.innerHTML
                }), a.addEventListener("focus", o.onEditTagFocus.bind(this, e)), a.addEventListener("blur", (function () {
                    setTimeout((() => o.onEditTagBlur.call(l, i())))
                })), a.addEventListener("input", o.onEditTagInput.bind(this, a)), a.addEventListener("keydown", (t => o.onEditTagkeydown.call(this, t, e))), a.focus(), this.setRangeAtStartEnd(!1, a), t.skipValidation || (u = this.editTagToggleValidity(e)), a.originalIsValid = u, this.trigger("edit:start", {
                    tag: e,
                    index: r,
                    data: s,
                    isValid: u
                }), this
            } else console.warn("Cannot find element in Tag template: .", n.classNames.tagTextSelector)
        },
        editTagToggleValidity(e, t) {
            var n;
            if (t = t || this.tagData(e)) return (n = !("__isValid" in t) || !0 === t.__isValid) || this.removeTagsFromValue(e), this.update(), e.classList.toggle(this.settings.classNames.tagNotAllowed, !n), t.__isValid;
            console.warn("tag has no data: ", e, t)
        },
        onEditTagDone(e, t) {
            t = t || {};
            var n = {
                tag: e = e || this.state.editing.scope,
                index: this.getNodeIndex(e),
                previousData: this.tagData(e),
                data: t
            };
            this.trigger("edit:beforeUpdate", n, {
                cloneData: !1
            }), this.state.editing = !1, delete t.__originalData, delete t.__originalHTML, e && t[this.settings.tagTextProp] ? (e = this.replaceTag(e, t), this.editTagToggleValidity(e, t), this.settings.a11y.focusableTags && e.focus()) : e && this.removeTags(e), this.trigger("edit:updated", n), this.dropdown.hide(), this.settings.keepInvalidTags && this.reCheckInvalidTags()
        },
        replaceTag(e, t) {
            t && t.value || (t = e.__tagifyTagData), t.__isValid && 1 != t.__isValid && c(t, this.getInvalidTagAttrs(t, t.__isValid));
            var n = this.createTagElem(t);
            return e.parentNode.replaceChild(n, e), this.updateValueByDOMTags(), n
        },
        updateValueByDOMTags() {
            this.value.length = 0, [].forEach.call(this.getTagElms(), (e => {
                e.classList.contains(this.settings.classNames.tagNotAllowed.split(" ")[0]) || this.value.push(this.tagData(e))
            })), this.update()
        },
        setRangeAtStartEnd(e, t) {
            e = "number" == typeof e ? e : !!e, t = (t = t || this.DOM.input).lastChild || t;
            var n = document.getSelection();
            try {
                n.rangeCount >= 1 && ["Start", "End"].forEach((i => n.getRangeAt(0)["set" + i](t, e || t.length)))
            } catch (e) {}
        },
        injectAtCaret(e, t) {
            if (t = t || this.state.selection.range) return "string" == typeof e && (e = document.createTextNode(e)), t.deleteContents(), t.insertNode(e), this.setRangeAtStartEnd(!1, e), this.updateValueByDOMTags(), this.update(), this
        },
        input: {
            set(e = "", t = !0) {
                var n = this.settings.dropdown.closeOnSelect;
                this.state.inputText = e, t && (this.DOM.input.innerHTML = o("" + e)), !e && n && this.dropdown.hide.bind(this), this.input.autocomplete.suggest.call(this), this.input.validate.call(this)
            },
            raw() {
                return this.DOM.input.textContent
            },
            validate() {
                var e = !this.state.inputText || !0 === this.validateTag({
                    value: this.state.inputText
                });
                return this.DOM.input.classList.toggle(this.settings.classNames.inputInvalid, !e), e
            },
            normalize(e) {
                var t = e || this.DOM.input,
                    n = [];
                t.childNodes.forEach((e => 3 == e.nodeType && n.push(e.nodeValue))), n = n.join("\n");
                try {
                    n = n.replace(/(?:\r\n|\r|\n)/g, this.settings.delimiters.source.charAt(0))
                } catch (e) {}
                return n = n.replace(/\s/g, " "), this.settings.trim && (n = n.replace(/^\s+/, "")), n
            },
            autocomplete: {
                suggest(e) {
                    if (this.settings.autoComplete.enabled) {
                        "string" == typeof (e = e || {}) && (e = {
                            value: e
                        });
                        var t = e.value ? "" + e.value : "",
                            n = t.substr(0, this.state.inputText.length).toLowerCase(),
                            i = t.substring(this.state.inputText.length);
                        t && this.state.inputText && n == this.state.inputText.toLowerCase() ? (this.DOM.input.setAttribute("data-suggest", i), this.state.inputSuggestion = e) : (this.DOM.input.removeAttribute("data-suggest"), delete this.state.inputSuggestion)
                    }
                },
                set(e) {
                    var t = this.DOM.input.getAttribute("data-suggest"),
                        n = e || (t ? this.state.inputText + t : null);
                    return !!n && ("mix" == this.settings.mode ? this.replaceTextWithNode(document.createTextNode(this.state.tag.prefix + n)) : (this.input.set.call(this, n), this.setRangeAtStartEnd()), this.input.autocomplete.suggest.call(this), this.dropdown.hide(), !0)
                }
            }
        },
        getTagIdx(e) {
            return this.value.findIndex((t => t.__tagId == (e || {}).__tagId))
        },
        getNodeIndex(e) {
            var t = 0;
            if (e)
                for (; e = e.previousElementSibling;) t++;
            return t
        },
        getTagElms(...e) {
            var t = "." + [...this.settings.classNames.tag.split(" "), ...e].join(".");
            return [].slice.call(this.DOM.scope.querySelectorAll(t))
        },
        getLastTag() {
            var e = this.DOM.scope.querySelectorAll(`${this.settings.classNames.tagSelector}:not(.${this.settings.classNames.tagHide}):not([readonly])`);
            return e[e.length - 1]
        },
        tagData: (e, t, n) => e ? (t && (e.__tagifyTagData = n ? t : c({}, e.__tagifyTagData || {}, t)), e.__tagifyTagData) : (console.warn("tag elment doesn't exist", e, t), t),
        isTagDuplicate(e, t) {
            var n = this.settings;
            return "select" != n.mode && this.value.reduce(((a, r) => i(this.trim("" + e), r.value, t || n.dropdown.caseSensitive) ? a + 1 : a), 0)
        },
        getTagIndexByValue(e) {
            var t = [];
            return this.getTagElms().forEach(((n, a) => {
                i(this.trim(n.textContent), e, this.settings.dropdown.caseSensitive) && t.push(a)
            })), t
        },
        getTagElmByValue(e) {
            var t = this.getTagIndexByValue(e)[0];
            return this.getTagElms()[t]
        },
        flashTag(e) {
            e && (e.classList.add(this.settings.classNames.tagFlash), setTimeout((() => {
                e.classList.remove(this.settings.classNames.tagFlash)
            }), 100))
        },
        isTagBlacklisted(e) {
            return e = this.trim(e.toLowerCase()), this.settings.blacklist.filter((t => ("" + t).toLowerCase() == e)).length
        },
        isTagWhitelisted(e) {
            return !!this.getWhitelistItem(e)
        },
        getWhitelistItem(e, t, n) {
            t = t || "value";
            var a, r = this.settings;
            return (n = n || r.whitelist).some((n => {
                var s = "string" == typeof n ? n : n[t] || n.value;
                if (i(s, e, r.dropdown.caseSensitive, r.trim)) return a = "string" == typeof n ? {
                    value: n
                } : n, !0
            })), a || "value" != t || "value" == r.tagTextProp || (a = this.getWhitelistItem(e, r.tagTextProp, n)), a
        },
        validateTag(e) {
            var t = this.settings,
                n = "value" in e ? "value" : t.tagTextProp,
                i = this.trim(e[n] + "");
            return (e[n] + "").trim() ? t.pattern && t.pattern instanceof RegExp && !t.pattern.test(i) ? this.TEXTS.pattern : !t.duplicates && this.isTagDuplicate(i, this.state.editing) ? this.TEXTS.duplicate : this.isTagBlacklisted(i) || t.enforceWhitelist && !this.isTagWhitelisted(i) ? this.TEXTS.notAllowed : !t.validate || t.validate(e) : this.TEXTS.empty
        },
        getInvalidTagAttrs(e, t) {
            return {
                "aria-invalid": !0,
                class: `${e.class||""} ${this.settings.classNames.tagNotAllowed}`.trim(),
                title: t
            }
        },
        hasMaxTags() {
            return this.value.length >= this.settings.maxTags && this.TEXTS.exceed
        },
        setReadonly(e, t) {
            var n = this.settings;
            document.activeElement.blur(), n[t || "readonly"] = e, this.DOM.scope[(e ? "set" : "remove") + "Attribute"](t || "readonly", !0), "mix" == n.mode && this.setContentEditable(!e)
        },
        setContentEditable(e) {
            !this.settings.readonly && this.settings.userInput && (this.DOM.input.contentEditable = e)
        },
        setDisabled(e) {
            this.setReadonly(e, "disabled")
        },
        normalizeTags(e) {
            var t = this.settings,
                n = t.whitelist,
                i = t.delimiters,
                a = t.mode,
                r = t.tagTextProp;
            t.enforceWhitelist;
            var s = [],
                o = !!n && n[0] instanceof Object,
                l = e instanceof Array,
                c = e => (e + "").split(i).filter((e => e)).map((e => ({
                    [r]: this.trim(e),
                    value: this.trim(e)
                })));
            if ("number" == typeof e && (e = e.toString()), "string" == typeof e) {
                if (!e.trim()) return [];
                e = c(e)
            } else l && (e = [].concat(...e.map((e => e.value ? e : c(e)))));
            return o && (e.forEach((e => {
                var t = s.map((e => e.value)),
                    n = this.dropdown.filterListItems.call(this, e[r], {
                        exact: !0
                    });
                this.settings.duplicates || (n = n.filter((e => !t.includes(e.value))));
                var i = n.length > 1 ? this.getWhitelistItem(e[r], r, n) : n[0];
                i && i instanceof Object ? s.push(i) : "mix" != a && (null == e.value && (e.value = e[r]), s.push(e))
            })), s.length && (e = s)), e
        },
        parseMixTags(e) {
            var t = this.settings,
                n = t.mixTagsInterpolator,
                i = t.duplicates,
                a = t.transformTag,
                r = t.enforceWhitelist,
                s = t.maxTags,
                o = t.tagTextProp,
                l = [];
            return e = e.split(n[0]).map(((e, t) => {
                var c, u, d, h = e.split(n[1]),
                    f = h[0],
                    p = l.length == s;
                try {
                    if (f == +f) throw Error;
                    u = JSON.parse(f)
                } catch (e) {
                    u = this.normalizeTags(f)[0] || {
                        value: f
                    }
                }
                if (a.call(this, u), p || !(h.length > 1) || r && !this.isTagWhitelisted(u.value) || !i && this.isTagDuplicate(u.value)) {
                    if (e) return t ? n[0] + e : e
                } else u[c = u[o] ? o : "value"] = this.trim(u[c]), d = this.createTagElem(u), l.push(u), d.classList.add(this.settings.classNames.tagNoAnimation), h[0] = d.outerHTML, this.value.push(u);
                return h.join("")
            })).join(""), this.DOM.input.innerHTML = e, this.DOM.input.appendChild(document.createTextNode("")), this.DOM.input.normalize(), this.getTagElms().forEach(((e, t) => this.tagData(e, l[t]))), this.update({
                withoutChangeEvent: !0
            }), e
        },
        replaceTextWithNode(e, t) {
            if (this.state.tag || t) {
                t = t || this.state.tag.prefix + this.state.tag.value;
                var n, i, a = window.getSelection(),
                    r = a.anchorNode,
                    s = this.state.tag.delimiters ? this.state.tag.delimiters.length : 0;
                return r.splitText(a.anchorOffset - s), -1 == (n = r.nodeValue.lastIndexOf(t)) || (i = r.splitText(n), e && r.parentNode.replaceChild(e, i)), !0
            }
        },
        selectTag(e, t) {
            var n = this.settings;
            if (!n.enforceWhitelist || this.isTagWhitelisted(t.value)) {
                this.input.set.call(this, t[n.tagTextProp] || t.value, !0), this.state.actions.selectOption && setTimeout(this.setRangeAtStartEnd.bind(this));
                var i = this.getLastTag();
                return i ? this.replaceTag(i, t) : this.appendTag(e), n.enforceWhitelist && this.setContentEditable(!1), this.value[0] = t, this.update(), this.trigger("add", {
                    tag: e,
                    data: t
                }), [e]
            }
        },
        addEmptyTag(e) {
            var t = c({
                    value: ""
                }, e || {}),
                n = this.createTagElem(t);
            this.tagData(n, t), this.appendTag(n), this.editTag(n, {
                skipValidation: !0
            })
        },
        addTags(e, t, n) {
            var i = [],
                a = this.settings,
                r = document.createDocumentFragment();
            return n = n || a.skipInvalid, e && 0 != e.length ? (e = this.normalizeTags(e), "mix" == a.mode ? this.addMixTags(e) : ("select" == a.mode && (t = !1), this.DOM.input.removeAttribute("style"), e.forEach((e => {
                var t, s = {},
                    o = Object.assign({}, e, {
                        value: e.value + ""
                    });
                if (e = Object.assign({}, o), a.transformTag.call(this, e), e.__isValid = this.hasMaxTags() || this.validateTag(e), !0 !== e.__isValid) {
                    if (n) return;
                    c(s, this.getInvalidTagAttrs(e, e.__isValid), {
                        __preInvalidData: o
                    }), e.__isValid == this.TEXTS.duplicate && this.flashTag(this.getTagElmByValue(e.value))
                }
                if ("readonly" in e && (e.readonly ? s["aria-readonly"] = !0 : delete e.readonly), t = this.createTagElem(e, s), i.push(t), "select" == a.mode) return this.selectTag(t, e);
                r.appendChild(t), e.__isValid && !0 === e.__isValid ? (this.value.push(e), this.trigger("add", {
                    tag: t,
                    index: this.value.length - 1,
                    data: e
                })) : (this.trigger("invalid", {
                    data: e,
                    index: this.value.length,
                    tag: t,
                    message: e.__isValid
                }), a.keepInvalidTags || setTimeout((() => this.removeTags(t, !0)), 1e3)), this.dropdown.position()
            })), this.appendTag(r), this.update(), e.length && t && this.input.set.call(this), this.dropdown.refilter(), i)) : ("select" == a.mode && this.removeAllTags(), i)
        },
        addMixTags(e) {
            if ((e = this.normalizeTags(e))[0].prefix || this.state.tag) return this.prefixedTextToTag(e[0]);
            "string" == typeof e && (e = [{
                value: e
            }]);
            var t = !!this.state.selection,
                n = document.createDocumentFragment();
            return e.forEach((e => {
                var t = this.createTagElem(e);
                n.appendChild(t), this.insertAfterTag(t)
            })), t ? this.injectAtCaret(n) : (this.DOM.input.focus(), (t = this.setStateSelection()).range.setStart(this.DOM.input, t.range.endOffset), t.range.setEnd(this.DOM.input, t.range.endOffset), this.DOM.input.appendChild(n), this.updateValueByDOMTags(), this.update()), n
        },
        prefixedTextToTag(e) {
            var t, n = this.settings,
                i = this.state.tag.delimiters;
            if (n.transformTag.call(this, e), e.prefix = e.prefix || this.state.tag ? this.state.tag.prefix : (n.pattern.source || n.pattern)[0], t = this.createTagElem(e), this.replaceTextWithNode(t) || this.DOM.input.appendChild(t), setTimeout((() => t.classList.add(this.settings.classNames.tagNoAnimation)), 300), this.value.push(e), this.update(), !i) {
                var a = this.insertAfterTag(t) || t;
                this.placeCaretAfterNode(a)
            }
            return this.state.tag = null, this.trigger("add", c({}, {
                tag: t
            }, {
                data: e
            })), t
        },
        appendTag(e) {
            var t = this.DOM,
                n = t.scope.lastElementChild;
            n === t.input ? t.scope.insertBefore(e, n) : t.scope.appendChild(e)
        },
        createTagElem(e, n) {
            e.__tagId = ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (e => (e ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> e / 4).toString(16)));
            var i, a = c({}, e, t({
                value: o(e.value + "")
            }, n));
            return function (e) {
                for (var t, n = document.createNodeIterator(e, NodeFilter.SHOW_TEXT, null, !1); t = n.nextNode();) t.textContent.trim() || t.parentNode.removeChild(t)
            }(i = this.parseTemplate("tag", [a])), this.tagData(i, e), i
        },
        reCheckInvalidTags() {
            var e = this.settings;
            this.getTagElms(e.classNames.tagNotAllowed).forEach(((e, t) => {
                var n = this.tagData(e),
                    i = this.hasMaxTags(),
                    a = this.validateTag(n);
                if (!0 === a && !i) return n = n.__preInvalidData ? n.__preInvalidData : {
                    value: n.value
                }, this.replaceTag(e, n);
                e.title = i || a
            }))
        },
        removeTags(e, t, n) {
            var i;
            e = e && e instanceof HTMLElement ? [e] : e instanceof Array ? e : e ? [e] : [this.getLastTag()], i = e.reduce(((e, t) => {
                t && "string" == typeof t && (t = this.getTagElmByValue(t));
                var n = this.tagData(t);
                return t && n && !n.readonly && e.push({
                    node: t,
                    idx: this.getTagIdx(n),
                    data: this.tagData(t, {
                        __removed: !0
                    })
                }), e
            }), []), n = "number" == typeof n ? n : this.CSSVars.tagHideTransition, "select" == this.settings.mode && (n = 0, this.input.set.call(this)), 1 == i.length && i[0].node.classList.contains(this.settings.classNames.tagNotAllowed) && (t = !0), i.length && this.settings.hooks.beforeRemoveTag(i, {
                tagify: this
            }).then((() => {
                function e(e) {
                    e.node.parentNode && (e.node.parentNode.removeChild(e.node), t ? this.settings.keepInvalidTags && this.trigger("remove", {
                        tag: e.node,
                        index: e.idx
                    }) : (this.trigger("remove", {
                        tag: e.node,
                        index: e.idx,
                        data: e.data
                    }), this.dropdown.refilter(), this.dropdown.position(), this.DOM.input.normalize(), this.settings.keepInvalidTags && this.reCheckInvalidTags()))
                }
                n && n > 10 && 1 == i.length ? function (t) {
                    t.node.style.width = parseFloat(window.getComputedStyle(t.node).width) + "px", document.body.clientTop, t.node.classList.add(this.settings.classNames.tagHide), setTimeout(e.bind(this), n, t)
                }.call(this, i[0]) : i.forEach(e.bind(this)), t || (this.removeTagsFromValue(i.map((e => e.node))), this.update(), "select" == this.settings.mode && this.setContentEditable(!0))
            })).catch((e => {}))
        },
        removeTagsFromDOM() {
            [].slice.call(this.getTagElms()).forEach((e => e.parentNode.removeChild(e)))
        },
        removeTagsFromValue(e) {
            (e = Array.isArray(e) ? e : [e]).forEach((e => {
                var t = this.tagData(e),
                    n = this.getTagIdx(t);
                n > -1 && this.value.splice(n, 1)
            }))
        },
        removeAllTags(e) {
            e = e || {}, this.value = [], "mix" == this.settings.mode ? this.DOM.input.innerHTML = "" : this.removeTagsFromDOM(), this.dropdown.position(), "select" == this.settings.mode && (this.input.set.call(this), this.setContentEditable(!0)), this.update(e)
        },
        postUpdate() {
            var e = this.settings.classNames,
                t = "mix" == this.settings.mode ? this.settings.mixMode.integrated ? this.DOM.input.textContent : this.DOM.originalInput.value.trim() : this.value.length + this.input.raw.call(this).length;
            this.toggleClass(e.hasMaxTags, this.value.length >= this.settings.maxTags), this.toggleClass(e.hasNoTags, !this.value.length), this.toggleClass(e.empty, !t)
        },
        setOriginalInputValue(e) {
            var t = this.DOM.originalInput;
            this.settings.mixMode.integrated || (t.value = e, t.tagifyValue = t.value, this.setPersistedData(e, "value"))
        },
        update(e) {
            var t = this.getInputValue();
            this.setOriginalInputValue(t), this.postUpdate(), !(e || {}).withoutChangeEvent && this.state.loadedOriginalValues && this.triggerChangeEvent()
        },
        getInputValue() {
            var e = this.getCleanValue();
            return "mix" == this.settings.mode ? this.getMixedTagsAsString(e) : e.length ? this.settings.originalInputValueFormat ? this.settings.originalInputValueFormat(e) : JSON.stringify(e) : ""
        },
        getCleanValue(e) {
            return t = e || this.value, n = this.dataProps, t && Array.isArray(t) && t.map((e => a(e, n)));
            var t, n
        },
        getMixedTagsAsString() {
            var e = "",
                t = this,
                n = this.settings.mixTagsInterpolator;
            return function i(r) {
                r.childNodes.forEach((r => {
                    if (1 == r.nodeType) {
                        const s = t.tagData(r);
                        if ("BR" == r.tagName && (e += "\r\n"), "DIV" == r.tagName || "P" == r.tagName) e += "\r\n", i(r);
                        else if (h.call(t, r) && s) {
                            if (s.__removed) return;
                            e += n[0] + JSON.stringify(a(s, t.dataProps)) + n[1]
                        }
                    } else e += r.textContent
                }))
            }(this.DOM.input), e
        }
    }, _.prototype.removeTag = _.prototype.removeTags, _
}))