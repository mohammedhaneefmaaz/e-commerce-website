<link rel="shortcut icon" href="<?php echo $Web->favicon(); ?>" />

<div class="d-lg-none header-right-sidebar-wrapper mobile-menu-wrapper mobile-menu-wrapper-right ">
    <div class="cursor-pointer">
        <span class="svg-icon svg-icon-3x iconic text-dark">
            <svg xmlns="http://www.w3.org/2000/svg" class="ionicon" viewBox="0 0 512 512">
                <title>Close</title>
                <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M368 368L144 144M368 144L144 368" />
            </svg>
        </span>
    </div>
    <div class="d-lg-none shade"></div>
    <div class="menu menu-title-gray-700 menu-sub menu-sub-dropdown menu-column menu-rounded menu-state-bg menu-state-primary fw-bold py-4 fs-6 w-275px show">
        <?php echo User::ecommerce_header_profile(); ?>
    </div>
</div>

<div class="mobile-menu-wrapper mobile-menu-wrapper-left header-left-sidebar-wrapper  ">
    <div class="shade"></div>
    <div id="headerCategoryWrapper" class="menu menu-title-gray-700 menu-sub menu-sub-dropdown menu-column menu-rounded menu-state-bg menu-state-primary fw-bold py-4 fs-6 w-275px show">
        <div class="p-4 menu-item">
            <h2>Categories</h2>
        </div>
        <?php echo Ecommerce\Home::choose_categories(); ?>
    </div>
</div>


<div id="lx_header" class="header align-items-stretch">
    <div class="container-xxl d-flex align-justify-between">
        <!--  -->
        <div class="justify-align-center">
            <div class="d-flex align-items-center me-2" title="Show header menu">
                <div class="header-bar header-bar-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
            <!--  -->
            <div class="header-logo mx-5">
                <a href="<?php echo $Web->base_url(); ?>/">
                    <img alt="Logo" src="<?php echo $Web->logo(); ?>" class="logo-default h-25px">
                </a>
            </div>
        </div>
        <!--  -->
        <div class="d-flex d-lg-none">
            <a href="<?php echo $Web->base_url() . '/search'; ?>" class="d-flex align-items-center ms-1 ms-lg-3">
                <div class="btn btn-icon btn btn-icon btn-custom w-30px h-30px w-md-40px h-md-40px">
                    <span class="svg-icon svg-icon-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="black"></rect>
                            <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="black"></path>
                        </svg>
                    </span>
                </div>
            </a>
        </div>

        <div class="d-flex align-items-stretch justify-content-between flex-lg-grow-1">

            <div class="search-container d-none d-lg-flex w-100">
                <form id="searchProducts" action="<?php echo $Web->base_url() . '/product/search'; ?>" class="form flex-grow-1 mw-700px position-relative mx-auto">
                    <div class="position-relative">
                        <a class="cursor-pointer go_back">
                            <span class="svg-icon d-block d-lg-none  svg-icon-muted svg-icon-2hx position-absolute top-50 translate-middle ms-9">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="11" width="13" height="2" rx="1" fill="black" />
                                    <path d="M8.56569 11.4343L12.75 7.25C13.1642 6.83579 13.1642 6.16421 12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75L5.70711 11.2929C5.31658 11.6834 5.31658 12.3166 5.70711 12.7071L11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25C13.1642 17.8358 13.1642 17.1642 12.75 16.75L8.56569 12.5657C8.25327 12.2533 8.25327 11.7467 8.56569 11.4343Z" fill="black" />
                                </svg>
                            </span>
                        </a>
                        <span class="svg-icon d-none d-lg-block svg-icon-1 svg-icon-primary position-absolute top-50 translate-middle ms-9">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="black"></rect>
                                <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="black"></path>
                            </svg>
                        </span>
                        <input autocomplete="off" type="text" class="form-control br-0 ps-14" name="q" value="" placeholder="Search">
                    </div>
                    <div class="border d1-none border-top-0 border-primary-active" id="searchSuggestion">

                    </div>
                </form>
            </div>

            <div class="d-flex align-items-stretch flex-shrink-0">
                <div class="d-none d-lg-flex  align-items-center ms-1 ms-lg-3" id="lx_header_user_menu_toggle">
                    <div class="cursor-pointer br-50 symbol symbol-30px symbol-md-40px" data-lx-menu-trigger="click" data-lx-menu-attach="parent" data-lx-menu-placement="bottom-end">
                        <img src="<?php echo User::header_profile_img(); ?>" alt="user" />
                    </div>
                    <div class="menu menu-title-gray-700 menu-sub menu-sub-dropdown menu-column menu-rounded menu-state-bg menu-state-primary fw-bold py-4 fs-6 w-275px" data-lx-menu="true">
                        <?php echo User::ecommerce_header_profile(); ?>
                    </div>
                </div>
                <!--  -->
                <a href="<?php echo $Web->base_url() . '/cart/'; ?>" class="d-flex align-items-center ms-1 ms-lg-3">
                    <div class="btn btn-icon btn-active-light-primary btn btn-icon btn-active-light-primary btn-custom w-30px h-30px w-md-40px h-md-40px">
                        <span class="svg-icon svg-icon-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M18.041 22.041C18.5932 22.041 19.041 21.5932 19.041 21.041C19.041 20.4887 18.5932 20.041 18.041 20.041C17.4887 20.041 17.041 20.4887 17.041 21.041C17.041 21.5932 17.4887 22.041 18.041 22.041Z" fill="black" />
                                <path opacity="0.3" d="M6.04095 22.041C6.59324 22.041 7.04095 21.5932 7.04095 21.041C7.04095 20.4887 6.59324 20.041 6.04095 20.041C5.48867 20.041 5.04095 20.4887 5.04095 21.041C5.04095 21.5932 5.48867 22.041 6.04095 22.041Z" fill="black" />
                                <path opacity="0.3" d="M7.04095 16.041L19.1409 15.1409C19.7409 15.1409 20.141 14.7409 20.341 14.1409L21.7409 8.34094C21.9409 7.64094 21.4409 7.04095 20.7409 7.04095H5.44095L7.04095 16.041Z" fill="black" />
                                <path d="M19.041 20.041H5.04096C4.74096 20.041 4.34095 19.841 4.14095 19.541C3.94095 19.241 3.94095 18.841 4.14095 18.541L6.04096 14.841L4.14095 4.64095L2.54096 3.84096C2.04096 3.64096 1.84095 3.04097 2.14095 2.54097C2.34095 2.04097 2.94096 1.84095 3.44096 2.14095L5.44096 3.14095C5.74096 3.24095 5.94096 3.54096 5.94096 3.84096L7.94096 14.841C7.94096 15.041 7.94095 15.241 7.84095 15.441L6.54096 18.041H19.041C19.641 18.041 20.041 18.441 20.041 19.041C20.041 19.641 19.641 20.041 19.041 20.041Z" fill="black" />
                            </svg>
                        </span>
                    </div>
                </a>
                <!--  -->
                <!--  -->
                <a href="<?php echo $Web->base_url() . '/orders/'; ?>" class="d-none d-lg-flex align-items-center ms-1 ms-lg-3">
                    <div class="btn btn-icon btn-active-light-primary btn btn-icon btn-active-light-primary btn-custom w-30px h-30px w-md-40px h-md-40px">
                        <span class="svg-icon svg-icon-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M5 8.04999L11.8 11.95V19.85L5 15.85V8.04999Z" fill="black" />
                                <path d="M20.1 6.65L12.3 2.15C12 1.95 11.6 1.95 11.3 2.15L3.5 6.65C3.2 6.85 3 7.15 3 7.45V16.45C3 16.75 3.2 17.15 3.5 17.25L11.3 21.75C11.5 21.85 11.6 21.85 11.8 21.85C12 21.85 12.1 21.85 12.3 21.75L20.1 17.25C20.4 17.05 20.6 16.75 20.6 16.45V7.45C20.6 7.15 20.4 6.75 20.1 6.65ZM5 15.85V7.95L11.8 4.05L18.6 7.95L11.8 11.95V19.85L5 15.85Z" fill="black" />
                            </svg>
                        </span>
                    </div>
                </a>
                <!--  -->
                <div class="d-flex align-items-center d-lg-none ms-2" title="Show header menu">
                    <div class="header-bar header-bar-right">
                        <div class="cursor-pointer br-50 symbol symbol-30px symbol-md-40px" data-lx-menu-trigger="click" data-lx-menu-attach="parent" data-lx-menu-placement="bottom-end">
                            <img src="<?php echo User::header_profile_img(); ?>" alt="user" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>