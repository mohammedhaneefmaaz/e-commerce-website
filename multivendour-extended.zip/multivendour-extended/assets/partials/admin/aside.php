<div id="lx_aside" class="aside aside-light aside-hoverable" data-lx-drawer="true" data-lx-drawer-name="aside" data-lx-drawer-activate="{default: true, lg: false}" data-lx-drawer-overlay="true" data-lx-drawer-width="{default:'200px', '300px': '250px'}" data-lx-drawer-direction="start" data-lx-drawer-toggle="#lx_aside_mobile_toggle">
    <div class="aside-logo flex-column-auto" id="lx_aside_logo">
        <a href="<?php echo $Web->admin_url(); ?>">
            <img alt="Logo" src="<?php echo $Web->admin_logo(); ?>" class="h-25px logo">
        </a>
        <div id="lx_aside_toggle" class="btn btn-icon w-auto px-0 btn-active-color-primary aside-toggle" data-lx-toggle="true" data-lx-toggle-state="active" data-lx-toggle-target="body" data-lx-toggle-name="aside-minimize">
            <span class="svg-icon svg-icon-1 rotate-180">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path opacity="0.5" d="M14.2657 11.4343L18.45 7.25C18.8642 6.83579 18.8642 6.16421 18.45 5.75C18.0358 5.33579 17.3642 5.33579 16.95 5.75L11.4071 11.2929C11.0166 11.6834 11.0166 12.3166 11.4071 12.7071L16.95 18.25C17.3642 18.6642 18.0358 18.6642 18.45 18.25C18.8642 17.8358 18.8642 17.1642 18.45 16.75L14.2657 12.5657C13.9533 12.2533 13.9533 11.7467 14.2657 11.4343Z" fill="currentColor"></path>
                    <path d="M8.2657 11.4343L12.45 7.25C12.8642 6.83579 12.8642 6.16421 12.45 5.75C12.0358 5.33579 11.3642 5.33579 10.95 5.75L5.40712 11.2929C5.01659 11.6834 5.01659 12.3166 5.40712 12.7071L10.95 18.25C11.3642 18.6642 12.0358 18.6642 12.45 18.25C12.8642 17.8358 12.8642 17.1642 12.45 16.75L8.2657 12.5657C7.95328 12.2533 7.95328 11.7467 8.2657 11.4343Z" fill="currentColor"></path>
                </svg>
            </span>
        </div>
    </div>
    <div id="navigation_menu" class="aside-menu flex-column-fluid">
        <div class="hover-scroll-overlay-y my-5 my-lg-5" id="lx_aside_menu_wrapper" data-lx-scroll="true" data-lx-scroll-activate="{default: false, lg: true}" data-lx-scroll-height="auto" data-lx-scroll-dependencies="#lx_aside_logo, #lx_aside_footer" data-lx-scroll-wrappers="#lx_aside_menu" data-lx-scroll-offset="0">
            <div class="menu menu-column menu-title-gray-800 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary navigationMenu menu-arrow-gray-500" id="lx_aside_menu" data-lx-menu="true" data-lx-menu-expand="false">

                <div class="menu-item">
                    <div class="menu-content pt-8 pb-2">
                        <span class="menu-section text-muted text-uppercase fs-8 ls-1">Ecommerce</span>
                    </div>
                </div>
                <div class="menu-item">
                    <a class="menu-link" href="<?php echo $Web->admin_url() . '/dashboard/'; ?>">
                        <span class="menu-icon">
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M6 7H3C2.4 7 2 6.6 2 6V3C2 2.4 2.4 2 3 2H6C6.6 2 7 2.4 7 3V6C7 6.6 6.6 7 6 7Z" fill="black" />
                                    <path opacity="0.3" d="M13 7H10C9.4 7 9 6.6 9 6V3C9 2.4 9.4 2 10 2H13C13.6 2 14 2.4 14 3V6C14 6.6 13.6 7 13 7ZM21 6V3C21 2.4 20.6 2 20 2H17C16.4 2 16 2.4 16 3V6C16 6.6 16.4 7 17 7H20C20.6 7 21 6.6 21 6ZM7 13V10C7 9.4 6.6 9 6 9H3C2.4 9 2 9.4 2 10V13C2 13.6 2.4 14 3 14H6C6.6 14 7 13.6 7 13ZM14 13V10C14 9.4 13.6 9 13 9H10C9.4 9 9 9.4 9 10V13C9 13.6 9.4 14 10 14H13C13.6 14 14 13.6 14 13ZM21 13V10C21 9.4 20.6 9 20 9H17C16.4 9 16 9.4 16 10V13C16 13.6 16.4 14 17 14H20C20.6 14 21 13.6 21 13ZM7 20V17C7 16.4 6.6 16 6 16H3C2.4 16 2 16.4 2 17V20C2 20.6 2.4 21 3 21H6C6.6 21 7 20.6 7 20ZM14 20V17C14 16.4 13.6 16 13 16H10C9.4 16 9 16.4 9 17V20C9 20.6 9.4 21 10 21H13C13.6 21 14 20.6 14 20ZM21 20V17C21 16.4 20.6 16 20 16H17C16.4 16 16 16.4 16 17V20C16 20.6 16.4 21 17 21H20C20.6 21 21 20.6 21 20Z" fill="black" />
                                </svg>
                            </span>
                        </span>
                        <span class="menu-title">Dashboard</span>
                    </a>
                </div>
                <div data-lx-menu-trigger="click" class="menu-item menu-accordion">
                    <span class="menu-link">
                        <span class="menu-icon">
                            <span class="svg-icon svg-icon-2">
                                <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M21.25 18.525L13.05 21.825C12.35 22.125 11.65 22.125 10.95 21.825L2.75 18.525C1.75 18.125 1.75 16.725 2.75 16.325L4.04999 15.825L10.25 18.325C10.85 18.525 11.45 18.625 12.05 18.625C12.65 18.625 13.25 18.525 13.85 18.325L20.05 15.825L21.35 16.325C22.35 16.725 22.35 18.125 21.25 18.525ZM13.05 16.425L21.25 13.125C22.25 12.725 22.25 11.325 21.25 10.925L13.05 7.62502C12.35 7.32502 11.65 7.32502 10.95 7.62502L2.75 10.925C1.75 11.325 1.75 12.725 2.75 13.125L10.95 16.425C11.65 16.725 12.45 16.725 13.05 16.425Z" fill="black"></path>
                                    <path d="M11.05 11.025L2.84998 7.725C1.84998 7.325 1.84998 5.925 2.84998 5.525L11.05 2.225C11.75 1.925 12.45 1.925 13.15 2.225L21.35 5.525C22.35 5.925 22.35 7.325 21.35 7.725L13.05 11.025C12.45 11.325 11.65 11.325 11.05 11.025Z" fill="black"></path>
                                </svg>
                            </span>
                        </span>
                        <span class="menu-title">Products</span>
                        <span class="menu-arrow"></span>
                    </span>
                    <div class="menu-sub menu-sub-accordion">
                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url() . '/orders/handover'; ?>">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Orders</span>
                            </a>
                            <a class="menu-link" href="<?php echo $Web->admin_url() . '/return-orders/requests'; ?>">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Return Orders</span>
                            </a>
                            <a class="menu-link" href="<?php echo $Web->admin_url() . '/replacement-orders/requests'; ?>">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Replacement Orders</span>
                            </a>
                            <a class="menu-link" href="<?php echo $Web->admin_url() . '/refund-orders/'; ?>">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Refund Orders</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div data-lx-menu-trigger="click" class="menu-item menu-accordion">
                    <span class="menu-link">
                        <span class="menu-icon">
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M14.5 20.7259C14.6 21.2259 14.2 21.826 13.7 21.926C13.2 22.026 12.6 22.0259 12.1 22.0259C9.5 22.0259 6.9 21.0259 5 19.1259C1.4 15.5259 1.09998 9.72592 4.29998 5.82592L5.70001 7.22595C3.30001 10.3259 3.59999 14.8259 6.39999 17.7259C8.19999 19.5259 10.8 20.426 13.4 19.926C13.9 19.826 14.4 20.2259 14.5 20.7259ZM18.4 16.8259L19.8 18.2259C22.9 14.3259 22.7 8.52593 19 4.92593C16.7 2.62593 13.5 1.62594 10.3 2.12594C9.79998 2.22594 9.4 2.72595 9.5 3.22595C9.6 3.72595 10.1 4.12594 10.6 4.02594C13.1 3.62594 15.7 4.42595 17.6 6.22595C20.5 9.22595 20.7 13.7259 18.4 16.8259Z" fill="black"></path>
                                    <path opacity="0.3" d="M2 3.62592H7C7.6 3.62592 8 4.02592 8 4.62592V9.62589L2 3.62592ZM16 14.4259V19.4259C16 20.0259 16.4 20.4259 17 20.4259H22L16 14.4259Z" fill="black"></path>
                                </svg>
                            </span>
                        </span>
                        <span class="menu-title">Verification</span>
                        <span class="menu-arrow"></span>
                    </span>
                    <div class="menu-sub menu-sub-accordion">

                        <div data-lx-menu-trigger="click" class="menu-item menu-accordion">
                            <span class="menu-link">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">QC</span>
                                <span class="menu-arrow"></span>
                            </span>
                            <div class="menu-sub menu-sub-accordion">
                                <div class="d-none menu-item">
                                    <a class="menu-link" href="<?php echo $Web->admin_url() . '/qc/view'; ?>">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">View QC</span>
                                    </a>
                                </div>
                                <div class="menu-item">
                                    <a class="menu-link" href="<?php echo $Web->admin_url() . '/qc/pending'; ?>">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">Pending QC</span>
                                    </a>
                                </div>
                                <div class="menu-item">
                                    <a class="menu-link" href="<?php echo $Web->admin_url() . '/qc/approved'; ?>">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">Approved Qc</span>
                                    </a>
                                </div>
                                <div class="menu-item">
                                    <a class="menu-link" href="<?php echo $Web->admin_url() . '/qc/rejected'; ?>">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">Rejected QC</span>
                                    </a>
                                </div>
                                <div class="menu-item">
                                    <a class="menu-link" href="<?php echo $Web->admin_url() . '/qc/'; ?>">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">All QC</span>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div data-lx-menu-trigger="click" class="menu-item menu-accordion">
                            <span class="menu-link">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Seller Verification</span>
                                <span class="menu-arrow"></span>
                            </span>
                            <div class="menu-sub menu-sub-accordion">
                                <div class="d-none menu-item">
                                    <a class="menu-link" href="<?php echo $Web->admin_url(); ?>/seller-verification/view-verification">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">Pending</span>
                                    </a>
                                </div>
                                <div class="menu-item">
                                    <a class="menu-link" href="<?php echo $Web->admin_url(); ?>/seller-verification/pending">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">Pending</span>
                                    </a>
                                </div>
                                <div class="menu-item">
                                    <a class="menu-link" href="<?php echo $Web->admin_url(); ?>/seller-verification/verified">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">Verified</span>
                                    </a>
                                </div>
                                <div class="menu-item">
                                    <a class="menu-link" href="<?php echo $Web->admin_url(); ?>/seller-verification/rejected">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">Rejected</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div data-lx-menu-trigger="click" class="menu-item menu-accordion">
                    <span class="menu-link">
                        <span class="menu-icon">
                            <span class="svg-icon svg-icon-2">
                                <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M21.25 18.525L13.05 21.825C12.35 22.125 11.65 22.125 10.95 21.825L2.75 18.525C1.75 18.125 1.75 16.725 2.75 16.325L4.04999 15.825L10.25 18.325C10.85 18.525 11.45 18.625 12.05 18.625C12.65 18.625 13.25 18.525 13.85 18.325L20.05 15.825L21.35 16.325C22.35 16.725 22.35 18.125 21.25 18.525ZM13.05 16.425L21.25 13.125C22.25 12.725 22.25 11.325 21.25 10.925L13.05 7.62502C12.35 7.32502 11.65 7.32502 10.95 7.62502L2.75 10.925C1.75 11.325 1.75 12.725 2.75 13.125L10.95 16.425C11.65 16.725 12.45 16.725 13.05 16.425Z" fill="black"></path>
                                    <path d="M11.05 11.025L2.84998 7.725C1.84998 7.325 1.84998 5.925 2.84998 5.525L11.05 2.225C11.75 1.925 12.45 1.925 13.15 2.225L21.35 5.525C22.35 5.925 22.35 7.325 21.35 7.725L13.05 11.025C12.45 11.325 11.65 11.325 11.05 11.025Z" fill="black"></path>
                                </svg>
                            </span>
                        </span>
                        <span class="menu-title">Listing</span>
                        <span class="menu-arrow"></span>
                    </span>
                    <div class="menu-sub menu-sub-accordion">
                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url() . '/categories'; ?>">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Categories</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url() . '/library'; ?>">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Library</span>
                            </a>
                        </div>
                    </div>
                </div>

                <div data-lx-menu-trigger="click" class="menu-item menu-accordion">
                    <span class="menu-link">
                        <span class="menu-icon">
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M16.0173 9H15.3945C14.2833 9 13.263 9.61425 12.7431 10.5963L12.154 11.7091C12.0645 11.8781 12.1072 12.0868 12.2559 12.2071L12.6402 12.5183C13.2631 13.0225 13.7556 13.6691 14.0764 14.4035L14.2321 14.7601C14.2957 14.9058 14.4396 15 14.5987 15H18.6747C19.7297 15 20.4057 13.8774 19.912 12.945L18.6686 10.5963C18.1487 9.61425 17.1285 9 16.0173 9Z" fill="currentColor" />
                                    <rect opacity="0.3" x="14" y="4" width="4" height="4" rx="2" fill="currentColor" />
                                    <path d="M4.65486 14.8559C5.40389 13.1224 7.11161 12 9 12C10.8884 12 12.5961 13.1224 13.3451 14.8559L14.793 18.2067C15.3636 19.5271 14.3955 21 12.9571 21H5.04292C3.60453 21 2.63644 19.5271 3.20698 18.2067L4.65486 14.8559Z" fill="currentColor" />
                                    <rect opacity="0.3" x="6" y="5" width="6" height="6" rx="3" fill="currentColor" />
                                </svg>
                            </span>
                        </span>
                        <span class="menu-title">Members</span>
                        <span class="menu-arrow"></span>
                    </span>
                    <div class="menu-sub menu-sub-accordion">
                        <div data-lx-menu-trigger="click" class="menu-item menu-accordion">
                            <span class="menu-link">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Sellers</span>
                                <span class="menu-arrow"></span>
                            </span>
                            <div class="menu-sub menu-sub-accordion">
                                <div class="menu-item">
                                    <a class="d-none menu-link" href="<?php echo $Web->admin_url() . '/sellers/view'; ?>">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">View Seller</span>
                                    </a>
                                </div>
                                <div class="menu-item">
                                    <a class="menu-link" href="<?php echo $Web->admin_url() . '/sellers/verified'; ?>">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">Verified Sellers</span>
                                    </a>
                                </div>
                                <div class="menu-item">
                                    <a class="menu-link" href="<?php echo $Web->admin_url() . '/sellers/rejected'; ?>">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">Rejected Sellers</span>
                                    </a>
                                </div>
                                <div class="menu-item">
                                    <a class="menu-link" href="<?php echo $Web->admin_url() . '/sellers/list'; ?>">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">Sellers List</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div data-lx-menu-trigger="click" class="menu-item menu-accordion">
                            <span class="menu-link">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Customers</span>
                                <span class="menu-arrow"></span>
                            </span>
                            <div class="menu-sub menu-sub-accordion">
                                <div class="menu-item">
                                    <a class="menu-link" href="<?php echo $Web->admin_url() . '/customers/active'; ?>">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">Active Customers</span>
                                    </a>
                                </div>
                                <div class="menu-item">
                                    <a class="menu-link" href="<?php echo $Web->admin_url() . '/customers/blocked'; ?>">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">Blocked Customers</span>
                                    </a>
                                </div>
                                <div class="menu-item">
                                    <a class="menu-link" href="<?php echo $Web->admin_url() . '/customers/'; ?>">
                                        <span class="menu-bullet">
                                            <span class="bullet bullet-dot"></span>
                                        </span>
                                        <span class="menu-title">Customers List</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div data-lx-menu-trigger="click" class="menu-item menu-accordion">
                    <span class="menu-link">
                        <span class="menu-icon">
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M12.5 22C11.9 22 11.5 21.6 11.5 21V3C11.5 2.4 11.9 2 12.5 2C13.1 2 13.5 2.4 13.5 3V21C13.5 21.6 13.1 22 12.5 22Z" fill="black" />
                                    <path d="M17.8 14.7C17.8 15.5 17.6 16.3 17.2 16.9C16.8 17.6 16.2 18.1 15.3 18.4C14.5 18.8 13.5 19 12.4 19C11.1 19 10 18.7 9.10001 18.2C8.50001 17.8 8.00001 17.4 7.60001 16.7C7.20001 16.1 7 15.5 7 14.9C7 14.6 7.09999 14.3 7.29999 14C7.49999 13.8 7.80001 13.6 8.20001 13.6C8.50001 13.6 8.69999 13.7 8.89999 13.9C9.09999 14.1 9.29999 14.4 9.39999 14.7C9.59999 15.1 9.8 15.5 10 15.8C10.2 16.1 10.5 16.3 10.8 16.5C11.2 16.7 11.6 16.8 12.2 16.8C13 16.8 13.7 16.6 14.2 16.2C14.7 15.8 15 15.3 15 14.8C15 14.4 14.9 14 14.6 13.7C14.3 13.4 14 13.2 13.5 13.1C13.1 13 12.5 12.8 11.8 12.6C10.8 12.4 9.99999 12.1 9.39999 11.8C8.69999 11.5 8.19999 11.1 7.79999 10.6C7.39999 10.1 7.20001 9.39998 7.20001 8.59998C7.20001 7.89998 7.39999 7.19998 7.79999 6.59998C8.19999 5.99998 8.80001 5.60005 9.60001 5.30005C10.4 5.00005 11.3 4.80005 12.3 4.80005C13.1 4.80005 13.8 4.89998 14.5 5.09998C15.1 5.29998 15.6 5.60002 16 5.90002C16.4 6.20002 16.7 6.6 16.9 7C17.1 7.4 17.2 7.69998 17.2 8.09998C17.2 8.39998 17.1 8.7 16.9 9C16.7 9.3 16.4 9.40002 16 9.40002C15.7 9.40002 15.4 9.29995 15.3 9.19995C15.2 9.09995 15 8.80002 14.8 8.40002C14.6 7.90002 14.3 7.49995 13.9 7.19995C13.5 6.89995 13 6.80005 12.2 6.80005C11.5 6.80005 10.9 7.00005 10.5 7.30005C10.1 7.60005 9.79999 8.00002 9.79999 8.40002C9.79999 8.70002 9.9 8.89998 10 9.09998C10.1 9.29998 10.4 9.49998 10.6 9.59998C10.8 9.69998 11.1 9.90002 11.4 9.90002C11.7 10 12.1 10.1 12.7 10.3C13.5 10.5 14.2 10.7 14.8 10.9C15.4 11.1 15.9 11.4 16.4 11.7C16.8 12 17.2 12.4 17.4 12.9C17.6 13.4 17.8 14 17.8 14.7Z" fill="black" />
                                </svg>
                            </span>
                        </span>
                        <span class="menu-title">Payments</span>
                        <span class="menu-arrow"></span>
                    </span>
                    <div class="menu-sub menu-sub-accordion">
                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url() . '/payments/pending-withdraws'; ?>">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Pending Withdraws</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url() . '/payments/success-withdraws'; ?>">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Success Withdraws</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url() . '/payments/rejected-withdraws'; ?>">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Rejected Withdraws</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url() . '/payments/all-withdraws'; ?>">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">All Withdraws</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url() . '/payments/withdraw-methods'; ?>">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Withdraw Methods</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="menu-item">
                    <a class="menu-link" href="<?php echo $Web->admin_url() . '/couriers/'; ?>">
                        <span class="menu-icon">
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M20 8H16C15.4 8 15 8.4 15 9V16H10V17C10 17.6 10.4 18 11 18H16C16 16.9 16.9 16 18 16C19.1 16 20 16.9 20 18H21C21.6 18 22 17.6 22 17V13L20 8Z" fill="black" />
                                    <path opacity="0.3" d="M20 18C20 19.1 19.1 20 18 20C16.9 20 16 19.1 16 18C16 16.9 16.9 16 18 16C19.1 16 20 16.9 20 18ZM15 4C15 3.4 14.6 3 14 3H3C2.4 3 2 3.4 2 4V13C2 13.6 2.4 14 3 14H15V4ZM6 16C4.9 16 4 16.9 4 18C4 19.1 4.9 20 6 20C7.1 20 8 19.1 8 18C8 16.9 7.1 16 6 16Z" fill="black" />
                                </svg>
                            </span>
                        </span>
                        <span class="menu-title">Couriers</span>
                    </a>
                </div>
                <div class="menu-item">
                    <a class="menu-link" href="<?php echo $Web->admin_url() . '/service-charges/'; ?>">
                        <span class="menu-icon">
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M20 18H4C3.4 18 3 17.6 3 17V7C3 6.4 3.4 6 4 6H20C20.6 6 21 6.4 21 7V17C21 17.6 20.6 18 20 18ZM12 8C10.3 8 9 9.8 9 12C9 14.2 10.3 16 12 16C13.7 16 15 14.2 15 12C15 9.8 13.7 8 12 8Z" fill="black" />
                                    <path d="M18 6H20C20.6 6 21 6.4 21 7V9C19.3 9 18 7.7 18 6ZM6 6H4C3.4 6 3 6.4 3 7V9C4.7 9 6 7.7 6 6ZM21 17V15C19.3 15 18 16.3 18 18H20C20.6 18 21 17.6 21 17ZM3 15V17C3 17.6 3.4 18 4 18H6C6 16.3 4.7 15 3 15Z" fill="black" />
                                </svg>
                            </span>
                        </span>
                        <span class="menu-title">Service Charges</span>
                    </a>
                </div>
                <div class="menu-item">
                    <a class="menu-link" href="<?php echo $Web->admin_url() . '/support/'; ?>">
                        <span class="menu-icon">
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class="">
                                    <g>
                                        <g xmlns="http://www.w3.org/2000/svg">
                                            <g>
                                                <path d="M473.883,453.655C460.055,412.815,442.843,361,376.002,361h-36.194c10.807-8.646,20.612-18.481,28.341-30h7.853    c41.353,0,75-33.647,75-75c0-21.713,0-38.289,0-60c0-107.52-87.48-196-195-196C146.032,0,59.517,91.414,61.017,198.534    c-0.018,33.032-0.015,21.022-0.015,57.466c0,41.353,33.647,75,75,75h7.853c7.729,11.519,17.534,21.354,28.341,30h-36.194    c-66.841,0-84.053,51.815-97.881,92.641C28.343,482.498,51.006,512,81.188,512h349.629    C461.101,512,483.63,482.392,473.883,453.655z M122.518,181h-16.516c-4.814,0-9.366,0.959-13.718,2.366    C99.178,93.133,173.145,30,256.002,30c86.785,0,157.972,68.388,164.37,153.567c-4.539-1.544-9.316-2.567-14.37-2.567h-16.516    c-7.573-67.315-64.177-121-133.484-121S130.091,113.685,122.518,181z M256.002,471.995L195.996,391h120.011L256.002,471.995z     M256.002,361c-57.891,0-105-47.109-105-105v-15h45c24.62,0,46.318-12.085,60-30.463c13.682,18.378,35.38,30.463,60,30.463h45v15    c0,16.165-3.977,31.307-10.532,45h-64.468c-8.291,0-15,6.709-15,15c0,8.291,6.709,14.9,15,14.9h43.251    C310.315,349.399,284.5,361,256.002,361z" fill="#000000" data-original="#000000" class=""></path>
                                            </g>
                                        </g>
                                </svg>
                            </span>
                        </span>
                        <span class="menu-title">Support</span>
                    </a>
                </div>
                <div class="menu-item">
                    <div class="menu-content pt-8 pb-0">
                        <span class="menu-section text-muted text-uppercase fs-8 ls-1">Setting</span>
                    </div>
                </div>
                <div class="menu-item">
                    <a class="menu-link" href="<?php echo $Web->admin_url() . "/layout/home"; ?>">
                        <span class="menu-icon">
                            <span class="svg-icon svg-icon-2">
                                <svg id="Layer_2" enable-background="new 0 0 32 32" height="512" viewBox="0 0 32 32" width="512" xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path fill d="m29.5293 12.64111-2.16992-.60986c-.14844-.4292-.32227-.85303-.5293-1.26953l1.1123-1.9541c.44336-.78027.31055-1.76807-.32422-2.40283l-2.02246-2.02247c-.63281-.63379-1.62207-.76855-2.40332-.32422l-1.96387 1.1001c-.39941-.19189-.82227-.36572-1.27344-.5166l-.59667-2.17139c-.23731-.86572-1.03027-1.47021-1.92871-1.47021h-2.85938c-.89844 0-1.69141.60449-1.92871 1.46973l-.6123 2.17139c-.43555.15137-.8584.3252-1.26758.52832l-1.9541-1.11133c-.78028-.44532-1.77051-.31006-2.40332.32421l-2.02246 2.02247c-.63477.63476-.76758 1.62255-.32422 2.40332l1.10059 1.96387c-.19531.40625-.36914.83008-.51563 1.27246l-2.17285.59668c-.86524.23827-1.46973 1.03173-1.46973 1.9287v2.85986c0 .89844.60449 1.69141 1.4707 1.92871l2.16992.61133c.14941.43066.32324.85352.5293 1.26758l-1.1123 1.95508c-.44434.78027-.31055 1.76855.32422 2.40332l2.02246 2.02246c.63379.63379 1.62109.76855 2.4043.32422l1.96387-1.10059c.4043.19434.82715.36816 1.27246.51563l.5957 2.17188c.23828.86621 1.03125 1.4707 1.92968 1.4707h2.85938c.89844 0 1.69141-.60449 1.92871-1.4707l.61133-2.16992c.43066-.14941.85352-.32324 1.26758-.5293l1.95508 1.1123c.78027.44531 1.76953.30859 2.40332-.32422l2.02246-2.02246c.63477-.63477.76855-1.62305.32422-2.4043l-1.10059-1.96387c.19434-.4043.36816-.82715.51563-1.27246l2.17188-.5957c.8662-.23828 1.47069-1.03124 1.47069-1.92968v-2.85986c0-.89698-.60449-1.69044-1.4707-1.92872zm-.5293 4.78858c-1.14692.39426-3.13385.46941-3.53122 1.88575-.34774.93999-.99012 1.9452-.37689 2.91211-.00009-.00001 1.11222 1.95409 1.11222 1.95409s-2.02246 2.02246-2.02246 2.02246-1.95605-1.11328-1.95605-1.11328c-.96898-.61577-1.97186.03269-2.91015.37898-.63184.21867-1.11329.72551-1.28809 1.35832 0 0-.59766 2.17188-.59766 2.17188h-2.86035l-.59668-2.17383c-.24556-1.11704-1.43063-1.3808-2.33404-1.78607-1.25339-.7209-2.76454.64538-3.82028 1.16401.00002-.00002-2.02244-2.02248-2.02244-2.02248l1.11328-1.95605c.6146-.96763-.03216-1.97214-.37898-2.91015-.21867-.63184-.72551-1.11329-1.35832-1.28809l-2.17189-.59765v-2.85986c1.14679-.39418 3.13429-.46763 3.53122-1.88526.34728-.93688.98988-1.94604.37689-2.91211.00009 0-1.11221-1.95361-1.11221-1.95361l2.02344-2.02246 1.95313 1.11133c.97133.61538 1.96677-.0275 2.9121-.37752 1.41726-.39361 1.49423-2.39905 1.88576-3.53022-.00002.00002 2.86033.00002 2.86033.00002.39392 1.14566.4681 3.134 1.8838 3.52975.94436.35093 1.9441.99148 2.91211.37787-.00001.00009 1.95507-1.11124 1.95507-1.11124l2.02246 2.02246-1.11328 1.95508c-.61421.96743.03282 1.97425.37898 2.91161.39277 1.41676 2.39947 1.4935 3.53022 1.8843-.00002-.00001-.00002 2.85986-.00002 2.85986z" />
                                        <path fill d="m16 7.08057c-4.91895 0-8.91992 4.00146-8.91992 8.91943 0 4.91895 4.00098 8.91992 8.91992 8.91992s8.91992-4.00097 8.91992-8.91992c0-4.91797-4.00097-8.91943-8.91992-8.91943zm0 15.83935c-3.81543 0-6.91992-3.10449-6.91992-6.91992s3.10449-6.91943 6.91992-6.91943 6.91992 3.104 6.91992 6.91943-3.10449 6.91992-6.91992 6.91992z" />
                                        <path fill d="m16 12.94385c.33496 0 .60742.27246.60742.69141.04378 1.32417 1.99979 1.21879 1.99998-.08403.00002-1.08315-.6649-2.01314-1.6074-2.40645.0858-.68496-.22135-1.39879-1.00005-1.40452-.77987.0102-1.08497.71382-.9999 1.40454-.94256.39329-1.60748 1.32329-1.60748 2.40648v.84131c.00001 1.43749 1.16993 2.60741 2.60743 2.60741.33496 0 .60742.27246.60742.60742-.01929.26509.08426 1.10409-.16896 1.2607-.35796.38667-1.07668.13628-1.04586-.50292-.04339-1.32395-2.00007-1.2191-2.00001.08406-.00001 1.08315.66491 2.01314 1.60741 2.40645-.08574.68544.22157 1.39828 1.00005 1.40404.78186-.01 1.08497-.71596.9999-1.40766 1.35037-.54178 1.73038-1.91207 1.60738-3.2447.00009-1.43747-1.16983-2.60739-2.60733-2.60739-.33496 0-.60742-.27246-.60742-.60742.01586-.50276-.16669-1.44649.60742-1.44873z" />
                                    </g>
                                </svg>
                            </span>
                        </span>
                        <span class="menu-title">Home Page</span>
                    </a>
                </div>
                <div class="menu-item">
                    <a class="menu-link" href="<?php echo $Web->admin_url() . "/custom-pages/"; ?>">
                        <span class="menu-icon">
                            <span class="svg-icon svg-icon-2">
                                <svg id="Layer_2" enable-background="new 0 0 32 32" height="512" viewBox="0 0 32 32" width="512" xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path fill d="m29.5293 12.64111-2.16992-.60986c-.14844-.4292-.32227-.85303-.5293-1.26953l1.1123-1.9541c.44336-.78027.31055-1.76807-.32422-2.40283l-2.02246-2.02247c-.63281-.63379-1.62207-.76855-2.40332-.32422l-1.96387 1.1001c-.39941-.19189-.82227-.36572-1.27344-.5166l-.59667-2.17139c-.23731-.86572-1.03027-1.47021-1.92871-1.47021h-2.85938c-.89844 0-1.69141.60449-1.92871 1.46973l-.6123 2.17139c-.43555.15137-.8584.3252-1.26758.52832l-1.9541-1.11133c-.78028-.44532-1.77051-.31006-2.40332.32421l-2.02246 2.02247c-.63477.63476-.76758 1.62255-.32422 2.40332l1.10059 1.96387c-.19531.40625-.36914.83008-.51563 1.27246l-2.17285.59668c-.86524.23827-1.46973 1.03173-1.46973 1.9287v2.85986c0 .89844.60449 1.69141 1.4707 1.92871l2.16992.61133c.14941.43066.32324.85352.5293 1.26758l-1.1123 1.95508c-.44434.78027-.31055 1.76855.32422 2.40332l2.02246 2.02246c.63379.63379 1.62109.76855 2.4043.32422l1.96387-1.10059c.4043.19434.82715.36816 1.27246.51563l.5957 2.17188c.23828.86621 1.03125 1.4707 1.92968 1.4707h2.85938c.89844 0 1.69141-.60449 1.92871-1.4707l.61133-2.16992c.43066-.14941.85352-.32324 1.26758-.5293l1.95508 1.1123c.78027.44531 1.76953.30859 2.40332-.32422l2.02246-2.02246c.63477-.63477.76855-1.62305.32422-2.4043l-1.10059-1.96387c.19434-.4043.36816-.82715.51563-1.27246l2.17188-.5957c.8662-.23828 1.47069-1.03124 1.47069-1.92968v-2.85986c0-.89698-.60449-1.69044-1.4707-1.92872zm-.5293 4.78858c-1.14692.39426-3.13385.46941-3.53122 1.88575-.34774.93999-.99012 1.9452-.37689 2.91211-.00009-.00001 1.11222 1.95409 1.11222 1.95409s-2.02246 2.02246-2.02246 2.02246-1.95605-1.11328-1.95605-1.11328c-.96898-.61577-1.97186.03269-2.91015.37898-.63184.21867-1.11329.72551-1.28809 1.35832 0 0-.59766 2.17188-.59766 2.17188h-2.86035l-.59668-2.17383c-.24556-1.11704-1.43063-1.3808-2.33404-1.78607-1.25339-.7209-2.76454.64538-3.82028 1.16401.00002-.00002-2.02244-2.02248-2.02244-2.02248l1.11328-1.95605c.6146-.96763-.03216-1.97214-.37898-2.91015-.21867-.63184-.72551-1.11329-1.35832-1.28809l-2.17189-.59765v-2.85986c1.14679-.39418 3.13429-.46763 3.53122-1.88526.34728-.93688.98988-1.94604.37689-2.91211.00009 0-1.11221-1.95361-1.11221-1.95361l2.02344-2.02246 1.95313 1.11133c.97133.61538 1.96677-.0275 2.9121-.37752 1.41726-.39361 1.49423-2.39905 1.88576-3.53022-.00002.00002 2.86033.00002 2.86033.00002.39392 1.14566.4681 3.134 1.8838 3.52975.94436.35093 1.9441.99148 2.91211.37787-.00001.00009 1.95507-1.11124 1.95507-1.11124l2.02246 2.02246-1.11328 1.95508c-.61421.96743.03282 1.97425.37898 2.91161.39277 1.41676 2.39947 1.4935 3.53022 1.8843-.00002-.00001-.00002 2.85986-.00002 2.85986z" />
                                        <path fill d="m16 7.08057c-4.91895 0-8.91992 4.00146-8.91992 8.91943 0 4.91895 4.00098 8.91992 8.91992 8.91992s8.91992-4.00097 8.91992-8.91992c0-4.91797-4.00097-8.91943-8.91992-8.91943zm0 15.83935c-3.81543 0-6.91992-3.10449-6.91992-6.91992s3.10449-6.91943 6.91992-6.91943 6.91992 3.104 6.91992 6.91943-3.10449 6.91992-6.91992 6.91992z" />
                                        <path fill d="m16 12.94385c.33496 0 .60742.27246.60742.69141.04378 1.32417 1.99979 1.21879 1.99998-.08403.00002-1.08315-.6649-2.01314-1.6074-2.40645.0858-.68496-.22135-1.39879-1.00005-1.40452-.77987.0102-1.08497.71382-.9999 1.40454-.94256.39329-1.60748 1.32329-1.60748 2.40648v.84131c.00001 1.43749 1.16993 2.60741 2.60743 2.60741.33496 0 .60742.27246.60742.60742-.01929.26509.08426 1.10409-.16896 1.2607-.35796.38667-1.07668.13628-1.04586-.50292-.04339-1.32395-2.00007-1.2191-2.00001.08406-.00001 1.08315.66491 2.01314 1.60741 2.40645-.08574.68544.22157 1.39828 1.00005 1.40404.78186-.01 1.08497-.71596.9999-1.40766 1.35037-.54178 1.73038-1.91207 1.60738-3.2447.00009-1.43747-1.16983-2.60739-2.60733-2.60739-.33496 0-.60742-.27246-.60742-.60742.01586-.50276-.16669-1.44649.60742-1.44873z" />
                                    </g>
                                </svg>
                            </span>
                        </span>
                        <span class="menu-title">Custom Pages</span>
                    </a>
                </div>
                <div data-lx-menu-trigger="click" class="menu-item menu-accordion">
                    <span class="menu-link">
                        <span class="menu-icon">
                            <span class="svg-icon svg-icon-2">
                                <svg fill="" enable-background="new 0 0 64 64" height="512" viewBox="0 0 64 64" width="512" xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path fill d="m47.203 43.053-2.097-.512c-.261-1.17-.675-2.281-1.219-3.314l1.265-1.746c.426-.588.395-1.39-.075-1.943l-1.163-1.369c-.47-.553-1.257-.713-1.906-.388l-1.931.969c-1.502-1.133-3.249-1.957-5.148-2.38l-.511-2.094c-.172-.705-.804-1.201-1.529-1.201h-1.797c-.726 0-1.357.496-1.529 1.201l-.512 2.097c-1.802.403-3.468 1.169-4.916 2.216l-1.91-1.007c-.642-.339-1.432-.194-1.913.349l-1.191 1.345c-.481.543-.528 1.345-.114 1.941l1.229 1.769c-.609 1.101-1.069 2.297-1.35 3.56l-2.07.492c-.706.168-1.206.797-1.21 1.523l-.01 1.797c-.004.726.488 1.36 1.192 1.536l2.098.524c.261 1.172.676 2.285 1.221 3.32l-1.258 1.716c-.429.585-.402 1.388.065 1.944l1.156 1.375c.467.555 1.253.72 1.904.398l1.939-.96c1.503 1.134 3.252 1.96 5.153 2.383l.493 2.07c.168.706.797 1.206 1.523 1.209l1.797.01c.726.004 1.36-.489 1.536-1.193l.524-2.098c1.814-.405 3.489-1.177 4.944-2.234l1.877 1.003c.64.342 1.431.202 1.915-.339l1.198-1.339c.484-.541.535-1.342.125-1.941l-1.227-1.787c.603-1.095 1.058-2.282 1.338-3.536l2.095-.51c.705-.172 1.201-.803 1.202-1.529l.001-1.797c-.003-.726-.499-1.358-1.204-1.53zm-15.206 10.539c-4.479 0-8.111-3.631-8.111-8.11s3.631-8.111 8.111-8.111 8.11 3.631 8.11 8.111c0 4.479-3.631 8.11-8.11 8.11z" />
                                        <g>
                                            <g>
                                                <path fill d="m27.949 14.806h-15.79c-1.243 0-2.25-1.007-2.25-2.25s1.007-2.25 2.25-2.25h15.79c1.243 0 2.25 1.007 2.25 2.25s-1.008 2.25-2.25 2.25z" />
                                                <g>
                                                    <path fill d="m37.899 10.176c-1.314 0-2.379 1.065-2.379 2.379s1.065 2.379 2.379 2.379 2.379-1.065 2.379-2.379c.001-1.313-1.065-2.379-2.379-2.379z" />
                                                    <path fill d="m44.806 10.176c-1.314 0-2.379 1.065-2.379 2.379s1.065 2.379 2.379 2.379 2.379-1.065 2.379-2.379c0-1.313-1.065-2.379-2.379-2.379z" />
                                                    <path fill d="m51.712 10.176c-1.314 0-2.379 1.065-2.379 2.379s1.065 2.379 2.379 2.379 2.379-1.065 2.379-2.379c0-1.313-1.065-2.379-2.379-2.379z" />
                                                </g>
                                            </g>
                                            <path fill d="m57.008 2.118h-50.016c-3.467 0-6.278 2.811-6.278 6.278v44.907c0 3.467 2.811 6.278 6.278 6.278h5.799c1.924 0 3.075-2.077 2.117-3.745-.01-.018-.02-.035-.03-.053-.43-.754-1.249-1.202-2.118-1.202h-5.768c-.706 0-1.278-.572-1.278-1.278v-30.31h52.572v30.31c0 .706-.572 1.278-1.278 1.278h-5.768c-.884 0-1.701.473-2.14 1.241l-.008.014c-.955 1.668.249 3.745 2.171 3.745h5.744c3.467 0 6.278-2.811 6.278-6.278v-44.906c.001-3.468-2.81-6.279-6.277-6.279zm1.278 15.875h-52.572v-9.596c0-.705.573-1.278 1.278-1.278h50.016c.705 0 1.278.573 1.278 1.278z" />
                                        </g>
                                    </g>
                                </svg>
                            </span>
                        </span>
                        <span class="menu-title">Components</span>
                        <span class="menu-arrow"></span>
                    </span>
                    <div class="menu-sub menu-sub-accordion">
                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url(); ?>/components/banners">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Banners</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url(); ?>/components/sliders">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Sliders</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url(); ?>/components/manual-sliders">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Manual Sliders</span>
                            </a>
                        </div>

                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url(); ?>/components/product-sliders">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Product Sliders</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url(); ?>/components/categories">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Categories</span>
                            </a>
                        </div>

                    </div>
                </div>
                <div data-lx-menu-trigger="click" class="menu-item here menu-accordion">
                    <span class="menu-link">
                        <span class="menu-icon">
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M22.1 11.5V12.6C22.1 13.2 21.7 13.6 21.2 13.7L19.9 13.9C19.7 14.7 19.4 15.5 18.9 16.2L19.7 17.2999C20 17.6999 20 18.3999 19.6 18.7999L18.8 19.6C18.4 20 17.8 20 17.3 19.7L16.2 18.9C15.5 19.3 14.7 19.7 13.9 19.9L13.7 21.2C13.6 21.7 13.1 22.1 12.6 22.1H11.5C10.9 22.1 10.5 21.7 10.4 21.2L10.2 19.9C9.4 19.7 8.6 19.4 7.9 18.9L6.8 19.7C6.4 20 5.7 20 5.3 19.6L4.5 18.7999C4.1 18.3999 4.1 17.7999 4.4 17.2999L5.2 16.2C4.8 15.5 4.4 14.7 4.2 13.9L2.9 13.7C2.4 13.6 2 13.1 2 12.6V11.5C2 10.9 2.4 10.5 2.9 10.4L4.2 10.2C4.4 9.39995 4.7 8.60002 5.2 7.90002L4.4 6.79993C4.1 6.39993 4.1 5.69993 4.5 5.29993L5.3 4.5C5.7 4.1 6.3 4.10002 6.8 4.40002L7.9 5.19995C8.6 4.79995 9.4 4.39995 10.2 4.19995L10.4 2.90002C10.5 2.40002 11 2 11.5 2H12.6C13.2 2 13.6 2.40002 13.7 2.90002L13.9 4.19995C14.7 4.39995 15.5 4.69995 16.2 5.19995L17.3 4.40002C17.7 4.10002 18.4 4.1 18.8 4.5L19.6 5.29993C20 5.69993 20 6.29993 19.7 6.79993L18.9 7.90002C19.3 8.60002 19.7 9.39995 19.9 10.2L21.2 10.4C21.7 10.5 22.1 11 22.1 11.5ZM12.1 8.59998C10.2 8.59998 8.6 10.2 8.6 12.1C8.6 14 10.2 15.6 12.1 15.6C14 15.6 15.6 14 15.6 12.1C15.6 10.2 14 8.59998 12.1 8.59998Z" fill="black" />
                                    <path d="M17.1 12.1C17.1 14.9 14.9 17.1 12.1 17.1C9.30001 17.1 7.10001 14.9 7.10001 12.1C7.10001 9.29998 9.30001 7.09998 12.1 7.09998C14.9 7.09998 17.1 9.29998 17.1 12.1ZM12.1 10.1C11 10.1 10.1 11 10.1 12.1C10.1 13.2 11 14.1 12.1 14.1C13.2 14.1 14.1 13.2 14.1 12.1C14.1 11 13.2 10.1 12.1 10.1Z" fill="black" />
                                </svg>
                            </span>
                        </span>
                        <span class="menu-title">Site Setting</span>
                        <span class="menu-arrow"></span>
                    </span>
                    <div class="menu-sub menu-sub-accordion">
                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url() . '/site-setting/email-setting'; ?>">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Email</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url() . '/site-setting/logo-setting'; ?>">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Logo</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link" href="<?php echo $Web->admin_url() . '/site-setting/basic-setting'; ?>">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">Basic</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="menu-item">
                    <a class="menu-link" href="<?php echo $Web->admin_url() . "/payment-setting/"; ?>">
                        <span class="menu-icon">
                            <span class="svg-icon svg-icon-2">
                                <svg id="Layer_2" enable-background="new 0 0 32 32" height="512" viewBox="0 0 32 32" width="512" xmlns="http://www.w3.org/2000/svg">
                                    <g>
                                        <path fill d="m29.5293 12.64111-2.16992-.60986c-.14844-.4292-.32227-.85303-.5293-1.26953l1.1123-1.9541c.44336-.78027.31055-1.76807-.32422-2.40283l-2.02246-2.02247c-.63281-.63379-1.62207-.76855-2.40332-.32422l-1.96387 1.1001c-.39941-.19189-.82227-.36572-1.27344-.5166l-.59667-2.17139c-.23731-.86572-1.03027-1.47021-1.92871-1.47021h-2.85938c-.89844 0-1.69141.60449-1.92871 1.46973l-.6123 2.17139c-.43555.15137-.8584.3252-1.26758.52832l-1.9541-1.11133c-.78028-.44532-1.77051-.31006-2.40332.32421l-2.02246 2.02247c-.63477.63476-.76758 1.62255-.32422 2.40332l1.10059 1.96387c-.19531.40625-.36914.83008-.51563 1.27246l-2.17285.59668c-.86524.23827-1.46973 1.03173-1.46973 1.9287v2.85986c0 .89844.60449 1.69141 1.4707 1.92871l2.16992.61133c.14941.43066.32324.85352.5293 1.26758l-1.1123 1.95508c-.44434.78027-.31055 1.76855.32422 2.40332l2.02246 2.02246c.63379.63379 1.62109.76855 2.4043.32422l1.96387-1.10059c.4043.19434.82715.36816 1.27246.51563l.5957 2.17188c.23828.86621 1.03125 1.4707 1.92968 1.4707h2.85938c.89844 0 1.69141-.60449 1.92871-1.4707l.61133-2.16992c.43066-.14941.85352-.32324 1.26758-.5293l1.95508 1.1123c.78027.44531 1.76953.30859 2.40332-.32422l2.02246-2.02246c.63477-.63477.76855-1.62305.32422-2.4043l-1.10059-1.96387c.19434-.4043.36816-.82715.51563-1.27246l2.17188-.5957c.8662-.23828 1.47069-1.03124 1.47069-1.92968v-2.85986c0-.89698-.60449-1.69044-1.4707-1.92872zm-.5293 4.78858c-1.14692.39426-3.13385.46941-3.53122 1.88575-.34774.93999-.99012 1.9452-.37689 2.91211-.00009-.00001 1.11222 1.95409 1.11222 1.95409s-2.02246 2.02246-2.02246 2.02246-1.95605-1.11328-1.95605-1.11328c-.96898-.61577-1.97186.03269-2.91015.37898-.63184.21867-1.11329.72551-1.28809 1.35832 0 0-.59766 2.17188-.59766 2.17188h-2.86035l-.59668-2.17383c-.24556-1.11704-1.43063-1.3808-2.33404-1.78607-1.25339-.7209-2.76454.64538-3.82028 1.16401.00002-.00002-2.02244-2.02248-2.02244-2.02248l1.11328-1.95605c.6146-.96763-.03216-1.97214-.37898-2.91015-.21867-.63184-.72551-1.11329-1.35832-1.28809l-2.17189-.59765v-2.85986c1.14679-.39418 3.13429-.46763 3.53122-1.88526.34728-.93688.98988-1.94604.37689-2.91211.00009 0-1.11221-1.95361-1.11221-1.95361l2.02344-2.02246 1.95313 1.11133c.97133.61538 1.96677-.0275 2.9121-.37752 1.41726-.39361 1.49423-2.39905 1.88576-3.53022-.00002.00002 2.86033.00002 2.86033.00002.39392 1.14566.4681 3.134 1.8838 3.52975.94436.35093 1.9441.99148 2.91211.37787-.00001.00009 1.95507-1.11124 1.95507-1.11124l2.02246 2.02246-1.11328 1.95508c-.61421.96743.03282 1.97425.37898 2.91161.39277 1.41676 2.39947 1.4935 3.53022 1.8843-.00002-.00001-.00002 2.85986-.00002 2.85986z" />
                                        <path fill d="m16 7.08057c-4.91895 0-8.91992 4.00146-8.91992 8.91943 0 4.91895 4.00098 8.91992 8.91992 8.91992s8.91992-4.00097 8.91992-8.91992c0-4.91797-4.00097-8.91943-8.91992-8.91943zm0 15.83935c-3.81543 0-6.91992-3.10449-6.91992-6.91992s3.10449-6.91943 6.91992-6.91943 6.91992 3.104 6.91992 6.91943-3.10449 6.91992-6.91992 6.91992z" />
                                        <path fill d="m16 12.94385c.33496 0 .60742.27246.60742.69141.04378 1.32417 1.99979 1.21879 1.99998-.08403.00002-1.08315-.6649-2.01314-1.6074-2.40645.0858-.68496-.22135-1.39879-1.00005-1.40452-.77987.0102-1.08497.71382-.9999 1.40454-.94256.39329-1.60748 1.32329-1.60748 2.40648v.84131c.00001 1.43749 1.16993 2.60741 2.60743 2.60741.33496 0 .60742.27246.60742.60742-.01929.26509.08426 1.10409-.16896 1.2607-.35796.38667-1.07668.13628-1.04586-.50292-.04339-1.32395-2.00007-1.2191-2.00001.08406-.00001 1.08315.66491 2.01314 1.60741 2.40645-.08574.68544.22157 1.39828 1.00005 1.40404.78186-.01 1.08497-.71596.9999-1.40766 1.35037-.54178 1.73038-1.91207 1.60738-3.2447.00009-1.43747-1.16983-2.60739-2.60733-2.60739-.33496 0-.60742-.27246-.60742-.60742.01586-.50276-.16669-1.44649.60742-1.44873z" />
                                    </g>
                                </svg>
                            </span>
                        </span>
                        <span class="menu-title">Payment Setting</span>
                    </a>
                </div>

            </div>
        </div>
    </div>
</div>