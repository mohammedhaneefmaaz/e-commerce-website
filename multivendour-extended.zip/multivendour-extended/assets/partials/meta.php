<meta charset="utf-8" />
<meta name="description" content="<?php echo $Web->meta_description(); ?>" />
<meta name="keywords" content="<?php echo $Web->meta_keywords(); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1.0;maximum-scale=1.0;">
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="<?php echo $Web->meta_title(); ?>" />
<meta property="og:url" content="<?php echo $Web->base_url(); ?>" />
<meta property="og:site_name" content="<?php echo $Web->web_name(); ?>" />
<link rel="canonical" href="<?php echo $Web->base_url(); ?>" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700" />
<link href="<?php echo $Web->get_assets("css/global.css"."?v=".$Web->last_updated); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo $Web->get_assets("css/style.css"."?v=".$Web->last_updated); ?>" rel="stylesheet" type="text/css" />
<style>
    :root {
        --theme-default: <?php echo $Web->primary_color(); ?>
    }
</style>
<div id="pagePreloader" class="absolute-preloader"><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span></div>