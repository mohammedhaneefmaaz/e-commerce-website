<div class="footer py-4 d-flex flex-lg-column" id="lx_footer">
    <div class="container-fluid d-flex flex-column flex-md-row align-items-center justify-content-between">
        <div class="text-dark order-2 order-md-1">
            <span class="text-muted fw-bold me-1"><?php echo $Web->current_year(); ?>@</span>
            <a href="<?php echo $Web->base_url(); ?>" class="text-gray-800 text-hover-primary"><?php echo $Web->web_name(); ?></a>
        </div>
        <ul class="menu menu-gray-600 menu-hover-primary fw-bold order-1">
            <li class="menu-item">
                <a href="<?php echo $Web->base_url(); ?>" target="_blank" class="menu-link px-2">Contact Us</a>
            </li>
            <li class="menu-item">
                <a href="<?php echo $Web->base_url(); ?>" target="_blank" class="menu-link px-2">About</a>
            </li>
            <li class="menu-item">
                <a href="<?php echo $Web->base_url(); ?>" target="_blank" class="menu-link px-2">Support</a>
            </li>
            <li class="menu-item">
                <a href="<?php echo $Web->base_url(); ?>" target="_blank" class="menu-link px-2">Purchase</a>
            </li>
        </ul>
    </div>
</div>