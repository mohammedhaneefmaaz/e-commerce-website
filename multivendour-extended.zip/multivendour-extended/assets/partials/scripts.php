<script>
    window.Setting = {
        currency: "<?php echo Basics::$currency; ?> ",
        base_url: "<?php echo Basics::$base_url; ?>",
        ajax_error: "<?php echo Basics::$ajax_error; ?>"
    };
</script>
<script src="<?php echo $Web->get_assets("js/global.js") . "?v=" . $Web->last_updated; ?>"></script>
<script src="<?php echo $Web->get_assets("js/proceed.js") . "?v=" . $Web->last_updated; ?>"></script>
<script src="<?php echo $Web->get_assets("js/scripts.js") . "?v=" . $Web->last_updated; ?>"></script>