<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../db.php");
    }
    Errors::response_404();
}

if (!$Web->is_isset("case")) Errors::response_404();

$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();
if (!$Login->is_admin_loggedin()) Errors::force_admin_login();

$sql_details = array(
    'user' => $conn->userName,
    'pass' => $conn->password,
    'db'   => $conn->dbName,
    'host' => $conn->host
);
require_once $Web->include("php/library/datatable.class.php");

use Ecommerce\Basic;
use Ecommerce\Withdraw;
use Ecommerce\WithdrawGateway;
use Ecommerce\Seller;
use Ecommerce\QC;
use Ecommerce\returnOrder;
use Ecommerce\ReplacementOrder;
use Ecommerce\_Order;
use Ecommerce\Category;
use Ecommerce\Product;
use Ecommerce\SellerVerification;
use Ecommerce\Ticket;

switch ($case) {

    case "userSupportTickets":

        $columns = array(
            array(
                'db' => 'creator', 'dt' => "customer",
                'formatter' => function ($d, $row) {
                    $User = new User($d);
                    return '<div class="d-flex align-items-center">
                    <div class="symbol symbol-50px overflow-hidden me-3">
														<a>
															<div class="symbol-label">
																<img src="' . $User->seller_logo() . '" alt="' . $User->full_name() . '" class="w-100">
															</div>
														</a>
													</div>
													<div class="d-flex flex-column">
														<a class="text-gray-800 line-clamp line-clamp-1 text-hover-primary mb-1">' .  $User->full_name() . '</a>
														<span>' . $User->user_id . '</span>
													</div></div>';
                }
            ),
            array(
                'db' => 'subject', 'dt' => "subject",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->unsanitize_text($d);
                }
            ),
            array(
                'db' => 'status',
                'dt' => "status",
                'formatter' => function ($d, $row) {
                    $Ticket = new Ticket($row["ticket_id"]);
                    return $Ticket->status_label();
                }
            ),
            array(
                'db' => 'created_at',
                'dt' => "created_at",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ),
            array(
                'db' => 'ticket_id',
                'dt' => "view",
                'formatter' => function ($status, $row) {
                    $Ticket = new Ticket($row["ticket_id"]);
                    return '<a href="' . $Ticket->a_url() . '" data-action="delete" class="ms-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                    <span class="svg-icon svg-icon-2">
                                 <svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="none" d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path></svg>
                         </span>
                 </a>';
                }
            )
        );

        $sql = "SELECT * FROM $Web->support_tickets_tbl ";
        $sql2 = "SELECT COUNT(*) FROM $Web->support_tickets_tbl ";


        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;

    case "transactions_TBl":
        $columns = array(
            array(
                'db' => 'transaction_id', 'dt' => "transaction_id",
                'formatter' => function ($d, $row) {
                    return '<a > #' . $d . '</a>';;
                }
            ),
            array('db' => 'amount', 'dt' => 'amount', 'formatter' => function ($d, $row) {
                global $Web;
                $Transaction = new Transaction($row["transaction_id"]);
                $text = $Web->formatCurrency($d);
                $status = $row["status"];

                if ($Transaction->type() == "order") {
                    if ($status == "credit") $text = '<span class="text-success">+' . $text . '</span>';
                    else if ($status == "pending") $text = '<span class="text-warning">+' . $text . '</span>';
                    else if ($status == "failed") $text = '<span class="text-info">+' . $text . '</span>';
                    else if ($status == "clearing") $text = '<span class="text-dark">+' . $text . '</span>';
                    else $text = '<span class="text-danger">-' . $text . '</span>';
                } else {
                    if ($status == "debit") $text = '<span class="text-danger">-' . $text . '</span>';
                    else if ($status == "pending") $text = '<span class="text-warning">-' . $text . '</span>';
                    else $text = '<span class="text-info">-' . $text . '</span>';
                }
                return $text;
            }),
            array('db' => 'txn_charge', 'dt' => 'txn_charge',  'formatter' => function ($d, $row) {
                global $Web;
                $text = "-" . $Web->formatCurrency($d);
                $status = $row["status"];
                if ($status == "credit") $text = '<span class="text-success">' . $text . '</span>';
                else if ($status == "pending") $text = '<span class="text-warning">' . $text . '</span>';
                else if ($status == "failed") $text = '<span class="text-info">' . $text . '</span>';
                else if ($status == "clearing") $text = '<span class="text-dark">' . $text . '</span>';
                else $text = '<span class="text-danger">' . $text . '</span>';
                return $text;
            }),
            array('db' => 'net_amount', 'dt' => 'net_amount', 'formatter' => function ($d, $row) {
                global $Web;
                $text = $Web->formatCurrency($d);
                $Transaction = new Transaction($row["transaction_id"]);
                $status = $row["status"];
                if ($Transaction->type() == "order") {
                    if ($status == "credit") $text = '<span class="text-success">+' . $text . '</span>';
                    else if ($status == "pending") $text = '<span class="text-warning">+' . $text . '</span>';
                    else if ($status == "failed") $text = '<span class="text-info">+' . $text . '</span>';
                    else if ($status == "clearing") $text = '<span class="text-dark">+' . $text . '</span>';
                    else $text = '<span class="text-danger">-' . $text . '</span>';
                } else {
                    if ($status == "debit") $text = '<span class="text-danger">-' . $text . '</span>';
                    else if ($status == "pending") $text = '<span class="text-warning">-' . $text . '</span>';
                    else $text = '<span class="text-info">-' . $text . '</span>';
                }
                return $text;
            }),
            array('db' => 'details', 'dt' => 'details', 'formatter' => function ($d, $row) {
                $order_id = $row["order_id"];
                $output = $d;
                if (!empty($order_id && _Order::is_order_id($order_id))) {
                    $Order = new _Order($order_id);
                    $output = $d . '<a href="' . $Order->admin_view_url() . '" > #' . $order_id . '</a>';
                }
                return $output;
            }),
            array('db' => 'status', 'dt' => 'status', 'formatter' => function ($d, $row) {
                global $Web;
                $order_id  = $row["order_id"];
                $Order  = new _Order($order_id);
                if ($d == "credit") return  $Web->status_to_label("credit", "success");
                if ($d == "debit")  return $Web->status_to_label("debit", "danger");
                if ($d == "pending") return  $Web->status_to_label("pending", "warning");
                if ($d == "failed")  return $Web->status_to_label("failed", "info");
                if ($d == "clearing")  return '<div data-bs-toggle="tooltip" title="" data-bs-trigger="hover" data-bs-dismiss="click" data-bs-original-title="' . $Order->remaining_clearing_time() . '" >' . $Web->status_to_label("clearing", "dark") . '</div>';
            }),
            array('db' => 'date', 'dt' => 'date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'last_updated', 'dt' => 'last_updated', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            })
        );

        $sql = "SELECT * FROM $Web->transactions_tbl  ";
        $sql2 = "SELECT COUNT(*) FROM $Web->transactions_tbl  ";

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;

    case "refund_orders_tbl":

        $status = $_POST["status"] ?? "pending";
        $status = $Web->sanitize_text($status);
        if ($status !== "pending" && $status !== "completed") Errors::response("Invalid status");

        $columns = array(
            array(
                'db' => 'user_id', 'dt' => "seller",
                'formatter' => function ($d, $row) {
                    $Seller = new Seller($d);
                    return '<div class="d-flex align-items-center">
                    <div class="symbol symbol-circle symbol-50px overflow-hidden me-3">
														<a href="' . $Seller->view_url_by_admin() . '" >
															<div class="symbol-label">
																<img src="' . $Seller->store_logo() . '" alt="' . $Seller->store_name() . '" class="w-100">
															</div>
														</a>
													</div>
													<div class="d-flex flex-column">
														<a href="' . $Seller->view_url_by_admin() . '" class="text-gray-800 line-clamp line-clamp-1 text-hover-primary mb-1">' .  $Seller->store_name() . '</a>
														<span>' . $Seller->user_id. '</span>
													</div></div>';
                }
            ),
            array(
                'db' => 'order_id', 'dt' => "order_id",
                'formatter' => function ($d, $row) {
                    $Order = new _Order($d);
                    return '<a href="' . $Order->admin_view_url() . '" >#' . $d . '</a>';
                }
            ),
            array(
                'db' => 'order_id', 'dt' => 'details',
                'formatter' => function ($d, $row) {
                    $variation_id = $row["variation_id"];
                    $svariation_id = $row["svariation_id"];
                    $product_id = $row["product_id"];
                    $Product = new Product($product_id);
                    return '<div class="d-flex align-items-center">
                        <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '" class="tbl-product-img">
                            <img src="' . $Product->image($variation_id, $svariation_id) . '">
                          </a>
                         <div class="ms-5">
                             <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '" class="text-gray-800 text-hover-primary wrap-text-1 fs-5 fw-bolder">' . $Product->product_name($variation_id, $svariation_id) . '</a>
                             <span><b>SKU ID: </b>' . $Product->sku_id($variation_id, $svariation_id) . '</span>
                        </div>
                    </div>';
                }
            ),
            array('db' => 'buyer_id', 'dt' => 'buyer', 'formatter' => function ($d, $row) {
                $User = new User($d);
                return $User->full_name();
            }),
            array('db' => 'quantity', 'dt' => 'quantity'),
            array('db' => 'total_price', 'dt' => 'amount', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->formatCurrency($d);
            }),
            array('db' => 'refund_status', 'dt' => 'refund', 'formatter' => function ($d, $row) {
                global $Web;
                if ($d == "pending") return $Web->status_to_label("pending", "warning");
                if ($d == "completed") return $Web->status_to_label("completed", "success");
            }),
            array('db' => 'ordered_date', 'dt' => 'order_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'labelled_on', 'dt' => 'labelled_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'rtd_on', 'dt' => 'rtd_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'shipped_on', 'dt' => 'shipped_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'delivered_on', 'dt' => 'delivered_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'cancelled_on', 'dt' => 'cancelled_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'rejected_on', 'dt' => 'rejected_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'refund_inited_on', 'dt' => 'refund_inited_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'status', 'dt' => 'status', 'formatter' => function ($d, $row) {
                global $Web;
                if ($d == "REJECTED") return $Web->status_to_label("rejected", "danger");
                if ($d == "CANCELLED") return $Web->status_to_label("cancelled", "danger");
                if ($d == "RETURNED") return $Web->status_to_label("returned", "danger");
                if ($d == "REPLACEMENT") return $Web->status_to_label("replacement", "danger");
            }),
            array(
                'db' => 'order_id',
                'dt' => "actions",
                'formatter' => function ($d, $row) {
                    $Order = new _Order($d);
                    return '<div class="d-flex">
                        <a href="' . $Order->admin_view_url() . '" class="ms-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                           <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
                        </a>
                    </div>';
                }
            )
        );

        $sql = "SELECT *,
         ( SELECT user_id FROM $Web->ecommerce_products_tbl WHERE $Web->ecommerce_orders_tbl.product_id = $Web->ecommerce_products_tbl.product_id ) as user_id 
        FROM $Web->ecommerce_orders_tbl  WHERE $Web->ecommerce_orders_tbl.refund_status = '$status'   ";
        $sql2 = "SELECT COUNT(*) FROM $Web->ecommerce_orders_tbl  WHERE $Web->ecommerce_orders_tbl.refund_status = '$status' ";

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );


        break;

    case "seller_listings_tbl":

        if (!$Web->is_isset("id", "status")) Errors::response_404();
        $user_id = $Web->sanitize_text($_POST["id"]);

        if (!User::is_user_id($user_id)) Errors::response("Invalid User");
        $User = new User($user_id);
        if (!$User->is_seller()) Errors::response("User isn't a seller");

        $status = $Web->sanitize_text($_POST["status"]);;

        $columns = array(
            array(
                'db' => 'svariation_id', 'dt' => "product",
                'formatter' => function ($svariation_id, $row) {
                    $variation_id = $row["variation_id"];
                    $product_id = $row["product_id"];
                    $Product = new Product($product_id);
                    $vurl = $Product->url($variation_id, $svariation_id);

                    return '<div class="d-flex align-items-center">
                        <a href="' . $vurl . '" target="_blank" class="tbl-product-img">
                            <img src="' . $Product->image($variation_id, $svariation_id) . '">
                          </a>
                         <div class="ms-5">
                             <a href="' . $vurl . '" target="_blank" class="text-gray-800 text-hover-primary wrap-text-1 fs-5 fw-bolder">' . $Product->product_name($variation_id, $svariation_id) . '</a>
                             <span><b>SKU ID: </b>' . $Product->sku_id($variation_id, $svariation_id) . '</span>
                        </div>
                    </div>';
                }
            ),
            array(
                'db' => 'svariation_id',
                'dt' => "status",
                'formatter' => function ($d, $row) {
                    $svariation_id = $d;
                    $variation_id = $row["variation_id"];
                    $product_id = $row["product_id"];
                    $Product = new Product($product_id);
                    return $Product->status_label($variation_id, $svariation_id);
                }
            ),
            array(
                'db' => 'stock', 'dt' => 'stock'
            ),
            array('db' => 'mrp', 'dt' => 'mrp', 'formatter' => function ($d, $row) {
                $Web = $GLOBALS["Web"];
                return $Web->formatCurrency($d);
            }),
            array('db' => 'price', 'dt' => 'price', 'formatter' => function ($d, $row) {
                $Web = $GLOBALS["Web"];
                return $Web->formatCurrency($d);
            }),
            array('db' => 'svariation_id', 'dt' => 'category', 'formatter' => function ($d, $row) {
                $Product = new Product($row["product_id"]);
                $category_id = $Product->category_id();
                $Category = new Category($category_id);
                return $Category->category();
            }),
            array('db' => 'svariation_id', 'dt' => 'sell', 'formatter' => function ($d, $row) {
                $svariation_id = $d;
                $variation_id = $row["variation_id"];
                $product_id = $row["product_id"];
                $Product = new Product($product_id);
                return $Product->sells($variation_id, $svariation_id);
            }),
            array(
                'db' => 'date_created',
                'dt' => "date",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            )
        );

        $sql = "SELECT * FROM $Web->ecommerce_variations_tbl WHERE user_id = '$user_id' AND status = '$status' ";
        $sql2 = "SELECT COUNT(*) FROM $Web->ecommerce_variations_tbl WHERE user_id = '$user_id' AND status = '$status' ";
        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;

    case "seller_transactions_TBl":

        if (!$Web->is_isset("id")) Errors::response_404();
        $user_id = $Web->sanitize_text($_POST["id"]);

        if (!User::is_user_id($user_id)) Errors::response("Invalid User");
        $User = new User($user_id);
        if (!$User->is_seller()) Errors::response("User isn't a seller");

        $columns = array(
            array(
                'db' => 'transaction_id', 'dt' => "transaction_id",
                'formatter' => function ($d, $row) {
                    return '<a href="#!" >#' . $d . '</a>';
                }
            ),
            array('db' => 'amount', 'dt' => 'amount', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->formatCurrency($d);
            }),
            array('db' => 'txn_charge', 'dt' => 'txn_charge'),
            array('db' => 'net_amount', 'dt' => 'net_amount', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->formatCurrency($d);
            }),
            array('db' => 'details', 'dt' => 'details'),
            array('db' => 'status', 'dt' => 'status', 'formatter' => function ($d, $row) {
                global $Web;
                return $d == "credit" ? $Web->status_to_label("credit", "success") : $Web->status_to_label("debit", "danger");
            }),
            array('db' => 'date', 'dt' => 'date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            })
        );

        $sql = "SELECT * FROM $Web->transactions_tbl  WHERE user_id = '$user_id' ";
        $sql2 = "SELECT COUNT(*) FROM $Web->transactions_tbl  WHERE user_id = '$user_id' ";

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );


        break;

    case "return_orders_datatbl":
        if (!$Web->is_isset("status")) Errors::response_404();
        $status = $_POST["status"];
        $columns = array(
            array(
                'db' => 'return_id', 'dt' => "return_id",
                'formatter' => function ($d, $row) {
                    $returnOrder = new returnOrder($d);
                    return '<a href="' . $returnOrder->updateUrl() . '" >#' . $d . '</a>';
                }
            ),
            array(
                'db' => 'tbl_order_id', 'dt' => "order_id",
                'formatter' => function ($d, $row) {
                    $Order = new _Order($d);
                    return '<a href="' . $Order->admin_view_url() . '" >#' . $d . '</a>';
                }
            ),
            array(
                'db' => 'tbl_order_id', 'dt' => 'details',
                'formatter' => function ($d, $row) {
                    $variation_id = $row["variation_id"];
                    $svariation_id = $row["svariation_id"];
                    $product_id = $row["product_id"];
                    $Product = new Product($product_id);
                    return '<div class="d-flex align-items-center">
                        <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '" class="tbl-product-img">
                            <img src="' . $Product->image($variation_id, $svariation_id) . '">
                          </a>
                         <div class="ms-5">
                             <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '" class="text-gray-800 text-hover-primary wrap-text-1 fs-5 fw-bolder">' . $Product->product_name($variation_id, $svariation_id) . '</a>
                             <span><b>SKU ID: </b>' . $Product->sku_id($variation_id, $svariation_id) . '</span>
                        </div>
                    </div>';
                }
            ),
            array('db' => 'buyer_id', 'dt' => 'buyer', 'formatter' => function ($d, $row) {
                $User = new User($d);
                return $User->full_name();
            }),
            array('db' => 'quantity', 'dt' => 'quantity'),
            array('db' => 'total_price', 'dt' => 'amount', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->formatCurrency($d);
            }),
            array('db' => 'refund_status', 'dt' => 'refund', 'formatter' => function ($d, $row) {
                global $Web;
                if ($d == "pending") return $Web->status_to_label("pending", "warning");
                if ($d == "completed") return $Web->status_to_label("completed", "success");
            }),
            array('db' => 'delivered_on', 'dt' => 'delivered_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'requested_date', 'dt' => 'requested_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'accepted_on', 'dt' => 'accepted_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'tbl_rejected_on', 'dt' => 'rejected_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'completed_date', 'dt' => 'completed_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'pickup_scheduled_date', 'dt' => 'pickup_scheduled_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array(
                'db' => 'return_id',
                'dt' => "actions",
                'formatter' => function ($d, $row) {
                    $Return = new returnOrder($d);
                    return '<div class="d-flex">
                        <a href="' . $Return->updateUrl() . '" class="ms-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                           <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
                        </a>
                    </div>';
                }
            )
        );

        $sql = "SELECT *, $Web->ecommerce_orders_tbl.buyer_id ,$Web->ecommerce_orders_tbl.quantity ,$Web->ecommerce_orders_tbl.total_price,
          $Web->ecommerce_return_orders_tbl.order_id as tbl_order_id,$Web->ecommerce_return_orders_tbl.rejected_on as tbl_rejected_on  FROM 
          $Web->ecommerce_return_orders_tbl INNER JOIN $Web->ecommerce_orders_tbl ON $Web->ecommerce_orders_tbl.order_id = $Web->ecommerce_return_orders_tbl.order_id
          WHERE   $Web->ecommerce_return_orders_tbl.status = '$status' ";

        $sql2 = "SELECT COUNT(*) FROM $Web->ecommerce_return_orders_tbl WHERE status = '$status' ";

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;

    case "replacement_orders_datatbl":

        if (!$Web->is_isset("status")) Errors::response_404();
        $status = $_POST["status"];
        $columns = array(
            array(
                'db' => 'replacement_id', 'dt' => "check",
                'formatter' => function ($d, $row) {
                    return '<div class="form-check form-check-sm form-check-custom form-check-solid">
                                     <input data-check="" autocomplete="off" class="form-check-input" type="checkbox" value="' . $d . '" >
                            </div>';
                }
            ),
            array(
                'db' => 'replacement_id', 'dt' => "replacement_id",
                'formatter' => function ($d, $row) {
                    $ReplacementOrder = new ReplacementOrder($d);
                    return '<a href="' . $ReplacementOrder->updateUrl() . '" >#' . $d . '</a>';
                }
            ),
            array(
                'db' => 'tbl_order_id', 'dt' => "order_id",
                'formatter' => function ($d, $row) {
                    $Order = new _Order($d);
                    return '<a href="' . $Order->admin_view_url() . '" >#' . $d . '</a>';
                }
            ),
            array(
                'db' => 'tbl_order_id', 'dt' => 'details',
                'formatter' => function ($d, $row) {
                    $variation_id = $row["variation_id"];
                    $svariation_id = $row["svariation_id"];
                    $product_id = $row["product_id"];
                    $Product = new Product($product_id);
                    return '<div class="d-flex align-items-center">
                        <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '" class="tbl-product-img">
                            <img src="' . $Product->image($variation_id, $svariation_id) . '">
                          </a>
                         <div class="ms-5">
                             <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '" class="text-gray-800 text-hover-primary wrap-text-1 fs-5 fw-bolder">' . $Product->product_name($variation_id, $svariation_id) . '</a>
                             <span><b>SKU ID: </b>' . $Product->sku_id($variation_id, $svariation_id) . '</span>
                        </div>
                    </div>';
                }
            ),
            array('db' => 'buyer_id', 'dt' => 'buyer', 'formatter' => function ($d, $row) {
                $User = new User($d);
                return $User->full_name();
            }),
            array('db' => 'quantity', 'dt' => 'quantity'),
            array('db' => 'total_price', 'dt' => 'amount', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->formatCurrency($d);
            }),
            array('db' => 'delivered_on', 'dt' => 'delivered_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'requested_date', 'dt' => 'requested_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'accepted_on', 'dt' => 'accepted_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'tbl_rejected_on', 'dt' => 'rejected_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'completed_date', 'dt' => 'completed_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'pickup_scheduled_date', 'dt' => 'pickup_scheduled_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array(
                'db' => 'replacement_id',
                'dt' => "actions",
                'formatter' => function ($d, $row) {
                    $Replacement = new ReplacementOrder($d);
                    return '<div class="d-flex">
                        <a href="' . $Replacement->updateUrl() . '" class="ms-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                           <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
                        </a>
                    </div>';
                }
            )
        );

        $sql = "SELECT *, $Web->ecommerce_orders_tbl.buyer_id ,$Web->ecommerce_orders_tbl.quantity ,$Web->ecommerce_orders_tbl.total_price, 
          $Web->ecommerce_replacement_orders_tbl.rejected_on as tbl_rejected_on, $Web->ecommerce_replacement_orders_tbl.order_id as tbl_order_id FROM 
          $Web->ecommerce_replacement_orders_tbl INNER JOIN $Web->ecommerce_orders_tbl ON $Web->ecommerce_orders_tbl.order_id = $Web->ecommerce_replacement_orders_tbl.order_id
          WHERE  $Web->ecommerce_replacement_orders_tbl.status = '$status' ";

        $sql2 = "SELECT COUNT(*) FROM $Web->ecommerce_replacement_orders_tbl WHERE status = '$status' ";

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );


        break;

    case "all_sellers_orders_tbl":

        if (!$Web->is_isset("order_status")) Errors::response_404();
        $order_status = $_POST["order_status"];
        $columns = array(
            array(
                'db' => 'user_id', 'dt' => "seller",
                'formatter' => function ($d, $row) {
                    $Seller = new Seller($d);
                    return '<div class="d-flex align-items-center">
                    <div class="symbol symbol-circle symbol-50px overflow-hidden me-3">
														<a href="' . $Seller->view_url_by_admin() . '" >
															<div class="symbol-label">
																<img src="' . $Seller->store_logo() . '" alt="' . $Seller->store_name() . '" class="w-100">
															</div>
														</a>
													</div>
													<div class="d-flex flex-column">
														<a href="' . $Seller->view_url_by_admin() . '" class="text-gray-800 line-clamp line-clamp-1 text-hover-primary mb-1">' .  $Seller->store_name() . '</a>
														<span>' . $Seller->user_id . '</span>
													</div></div>';
                }
            ),
            array(
                'db' => 'order_id', 'dt' => "order_id",
                'formatter' => function ($d, $row) {
                    $Order = new _Order($d);
                    return '<a href="' . $Order->admin_view_url() . '" >#' . $d . '</a>';
                }
            ),
            array(
                'db' => 'order_id', 'dt' => 'details',
                'formatter' => function ($d, $row) {
                    $variation_id = $row["variation_id"];
                    $svariation_id = $row["svariation_id"];
                    $product_id = $row["product_id"];
                    $Product = new Product($product_id);
                    return '<div class="d-flex align-items-center">
                        <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '" class="tbl-product-img">
                            <img src="' . $Product->image($variation_id, $svariation_id) . '">
                          </a>
                         <div class="ms-5">
                             <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '" class="text-gray-800 text-hover-primary wrap-text-1 fs-5 fw-bolder">' . $Product->product_name($variation_id, $svariation_id) . '</a>
                             <span><b>SKU ID: </b>' . $Product->sku_id($variation_id, $svariation_id) . '</span>
                        </div>
                    </div>';
                }
            ),
            array('db' => 'buyer_id', 'dt' => 'buyer', 'formatter' => function ($d, $row) {
                $User = new User($d);
                return $User->full_name();
            }),
            array('db' => 'quantity', 'dt' => 'quantity'),
            array('db' => 'total_price', 'dt' => 'amount', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->formatCurrency($d);
            }),
            array('db' => 'refund_status', 'dt' => 'refund', 'formatter' => function ($d, $row) {
                global $Web;
                if ($d == "pending") return $Web->status_to_label("pending", "warning");
               else if ($d == "completed") return $Web->status_to_label("completed", "success");
               else return $Web->status_to_label("NA","info");
            }),
            array('db' => 'ordered_date', 'dt' => 'order_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'labelled_on', 'dt' => 'labelled_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'pickup_scheduled_on', 'dt' => 'scheduled_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'rtd_on', 'dt' => 'rtd_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'shipped_on', 'dt' => 'shipped_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'delivered_on', 'dt' => 'delivered_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'cancelled_on', 'dt' => 'cancelled_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'rejected_on', 'dt' => 'rejected_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array(
                'db' => 'order_id',
                'dt' => "actions",
                'formatter' => function ($d, $row) {
                    $Order = new _Order($d);
                    return '<div class="d-flex">
                        <a href="' . $Order->admin_view_url() . '" class="ms-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                           <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
                        </a>
                    </div>';
                }
            )
        );

        $sql = "SELECT *, ( SELECT user_id FROM $Web->ecommerce_products_tbl WHERE $Web->ecommerce_orders_tbl.product_id = $Web->ecommerce_products_tbl.product_id ) as user_id FROM $Web->ecommerce_orders_tbl  WHERE $Web->ecommerce_orders_tbl.status = '$order_status'  ";
        $sql2 = "SELECT COUNT(*) FROM $Web->ecommerce_orders_tbl  WHERE $Web->ecommerce_orders_tbl.status = '$order_status' ";

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );


        break;

    case "ecommerce_withdraw_data_tbl":
        if (!$Web->is_isset("status")) Errors::response_404();
        $status = $_POST["status"];

        $columns = array(
            array(
                "db" => "transaction_id", "dt" => "transaction_id",
                'formatter' => function ($d, $row) {
                    return "#" . $d;
                }
            ),
            array(
                'db' => 'user_id', 'dt' => "seller",
                'formatter' => function ($user_id, $row) {
                    $Seller = new Seller($user_id);
                    return '<div class="d-flex align-items-center">
                                <div class="symbol symbol-circle symbol-50px overflow-hidden me-3">
														<a>
															<div class="symbol-label">
																<img src="' . $Seller->seller_logo() . '" alt="' . $Seller->store_name() . '" class="w-100">
															</div>
														</a>
													</div>
													<div class="d-flex flex-column">
														<a class="text-gray-800 text-hover-primary mb-1">' . $Seller->store_name() . '</a>
                                                        <div class="fs-7 text-muted" >Id: ' . $Seller->user_id . '</div>
													</div>
                              </div>';
                }
            ),
            array(
                'db' => 'withdraw_id', 'dt' => "gateway",
                'formatter' => function ($withdraw_id, $row) {
                    $Withdraw = new Withdraw($withdraw_id);
                    return '<div class="d-flex align-items-center">
                                <div class="symbol symbol-circle symbol-50px overflow-hidden me-3">
														<a>
															<div class="symbol-label">
																<img src="' . $Withdraw->gateway()->logo . '" alt="' . $Withdraw->gateway()->name . '" class="w-100">
															</div>
														</a>
													</div>
													<div class="d-flex flex-column">
														<a class="text-gray-800 text-hover-primary mb-1">' . $Withdraw->gateway()->name . '</a>
													</div>
                              </div>';
                }
            ),
            array(
                'db' => 'gross_amount', 'dt' => "gross_amount",
                'formatter' => function ($gross_amount, $row) {
                    return (new Basic)->formatCurrency($gross_amount);
                }
            ),
            array(
                'db' => 'charge', 'dt' => "charge",
                'formatter' => function ($charge, $row) {
                    return (new Basic)->formatCurrency($charge);
                }
            ),
            array(
                'db' => 'net_amount', 'dt' => "net_amount",
                'formatter' => function ($net_amount, $row) {
                    return (new Basic)->formatCurrency($net_amount);
                }
            ),
            array('db' => 'date_requested', 'dt' => 'requested_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'date_processed', 'dt' => 'processed_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'status', 'dt' => 'status', 'formatter' => function ($status, $row) {
                global $Web;
                switch ($status) {
                    case "pending":
                        return $Web->status_to_label("Pending", "warning");
                        break;
                    case "success":
                        return $Web->status_to_label("Success", "success");
                        break;
                    case "rejected":
                        return $Web->status_to_label("Rejected", "danger");
                        break;
                }
            }),
            array(
                'db' => 'withdraw_id',
                'dt' => "action",
                'formatter' => function ($d, $row) {
                    $Withdraw = new Withdraw($d);
                    return '<div class="d-flex">
                        <a href="' . $Withdraw->process_url() . '" class="ms-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                           <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
                        </a>
                    </div>';
                }
            )
        );

        $sql = "SELECT * FROM $Web->ecommerce_sellers_withdraw_tbl  ";
        $sql2 = "SELECT COUNT(*) FROM $Web->ecommerce_sellers_withdraw_tbl ";

        if (!empty($status)) {
            $sql .= " WHERE status = '$status' ";
            $sql2 .= " WHERE status = '$status' ";
        }

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );


        break;

    case "all_ecommerce_withdraw_methods":

        $columns = array(
            array(
                'db' => 'gateway_id', 'dt' => "gateway",
                'formatter' => function ($gateway_id, $row) {
                    $Withdraw = new WithdrawGateway($gateway_id);
                    return '<div class="d-flex align-items-center">
                    <div class="symbol symbol-circle symbol-50px overflow-hidden me-3">
														<a>
															<div class="symbol-label">
																<img src="' . $Withdraw->logo() . '" alt="' . $Withdraw->name() . '" class="w-100">
															</div>
														</a>
													</div>
													<div class="d-flex flex-column">
														<a class="text-gray-800 text-hover-primary mb-1">' . $Withdraw->name() . '</a>
													</div>
                                            </div>';
                }
            ),
            array(
                'db' => 'processing_time',
                'dt' => 'time'
            ),
            array(
                'db' => 'date_created',
                'dt' => "date",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ),
            array(
                'db' => 'status',
                'dt' => "status",
                'formatter' => function ($status, $row) {
                    global $Web;
                    switch ($status) {
                        case "active":
                            return $Web->status_to_label("Active", "success");
                            break;
                        case "inactive":
                            return $Web->status_to_label("Inactive", "danger");
                            break;
                    }
                }
            ),
            array(
                'db' => 'gateway_id',
                'dt' => "actions",
                'formatter' => function ($gateway_id, $row) {
                    $Withdraw = new WithdrawGateway($gateway_id);
                    return '<a href="' . $Withdraw->edit_url() . '" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
						        <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
							</a>';
                }
            ),
        );


        $sql =  "SELECT * FROM $Web->ecommerce_withdraw_gateways_tbl ";
        $sql2 =  "SELECT COUNT(*) FROM $Web->ecommerce_withdraw_gateways_tbl ";

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );


        break;

    case "all_ecommerce_customers_list":
        if (!$Web->is_isset("status")) Errors::response_404();
        $status = $_POST["status"];

        $columns = array(
            array(
                'db' => 'user_id', 'dt' => "user",
                'formatter' => function ($user_id, $row) {
                    $User = new User($user_id);
                    return '<div class="d-flex align-items-center">
                    <div class="symbol symbol-circle symbol-50px overflow-hidden me-3">
														<a>
															<div class="symbol-label">
																<img src="' . $User->avatar() . '" alt="' . $User->full_name() . '" class="w-100">
															</div>
														</a>
													</div>
													<div class="d-flex flex-column">
														<a class="text-gray-800 text-hover-primary mb-1">' . $User->full_name() . '</a>
														<span>' . $User->user_id . '</span>
													</div></div>';
                }
            ),
            array(
                'db' => 'user_id',
                'dt' => 'email'
            ),
            array(
                'db' => 'user_id',
                'dt' => "purchased",
                'formatter' => function ($d, $row) {
                    $User = new User($d);
                    $email = $User->email();
                    return $User->purchased_products();
                }
            ),
            array(
                'db' => 'registration_date',
                'dt' => "member_since",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ),
            array(
                'db' => 'status',
                'dt' => "status",
                'formatter' => function ($status, $row) {
                    global $Web;
                    switch ($status) {
                        case "active":
                            return $Web->status_to_label("Active", "success");
                            break;
                        case "blocked":
                            return $Web->status_to_label("Blocked", "danger");
                            break;
                    }
                }
            ),
            array(
                'db' => 'user_id',
                'dt' => "actions",
                'formatter' => function ($user_id, $row) {
                    $User = new User($user_id);
                    return '<a class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
						        <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
							</a>';
                }
            ),
        );


        $sql =  "SELECT * FROM $Web->users_tbl ";
        $sql2 =  "SELECT COUNT(*) FROM $Web->users_tbl ";


        if (!empty($status)) {
            $sql .= " WHERE status = '$status' ";
            $sql2 .= " WHERE status = '$status' ";
        }

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;

    case "all_sellers_list":

        if (!$Web->is_isset("status")) Errors::response_404();
        $status = $_POST["status"];

        $columns = array(
            array(
                'db' => 'user_id', 'dt' => "seller",
                'formatter' => function ($user_id, $row) {
                    $Seller = new Seller($user_id);
                    return '<div class="d-flex align-items-center">
                    <div class="symbol symbol-circle symbol-50px overflow-hidden me-3">
														<a href="' . $Seller->view_url_by_admin() . '" >
															<div class="symbol-label">
																<img src="' . $Seller->store_logo() . '" alt="' . $Seller->store_name() . '" class="w-100">
															</div>
														</a>
													</div>
													<div class="d-flex flex-column">
														<a  href="' . $Seller->view_url_by_admin() . '" class="text-gray-800 text-hover-primary mb-1">' . $Seller->store_name() . '</a>
														<span> ' . $Seller->user_id. '</span>
													</div></div>';
                }
            ),
            array(
                'db' => 'user_id',
                'dt' => 'products',
                'formatter' => function ($d, $row) {
                    $Seller = new Seller($d);
                    return $Seller->products_count();
                }
            ),
            array(
                'db' => 'seller_since',
                'dt' => "seller_since",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ), array(
                'db' => 'status',
                'dt' => "status",
                'formatter' => function ($status, $row) {
                    global $Web;
                    switch ($status) {
                        case "unverified":
                            return $Web->status_to_label("Unverified", "primary");
                            break;
                        case "pending":
                            return $Web->status_to_label("Pending", "warning");
                            break;
                        case "verified":
                            return $Web->status_to_label("Verified", "success");
                            break;
                        case "rejected":
                            return $Web->status_to_label("Rejected", "danger");
                            break;
                    }
                }
            ),
            array(
                'db' => 'user_id',
                'dt' => "actions",
                'formatter' => function ($user_id, $row) {
                    $Seller = new Seller($user_id);
                    return '<a href="' . $Seller->view_url_by_admin() . '" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
						        <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
							</a>';
                }
            ),
        );


        $sql =  "SELECT * FROM $Web->ecommerce_seller_users_tbl ";
        $sql2 =  "SELECT COUNT(*) FROM $Web->ecommerce_seller_users_tbl ";

        if (!empty($status)) {
            $sql .= " WHERE status = '$status' ";
            $sql2 .= " WHERE status = '$status' ";
        }

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );


        break;

    case "sellers_verification_tbl":
        if (!$Web->is_isset("status")) Errors::response_404();
        $status = $Web->sanitize_text($_POST["status"]);
        if (!in_array($status, ["all", "pending", "verified", "unverified", "rejected"])) Errors::response_404();


        $columns = array(
            array(
                'db' => 'user_id', 'dt' => "seller",
                'formatter' => function ($user_id, $row) {
                    $Seller = new Seller($user_id);
                    return '<div class="d-flex align-items-center">
                    <div class="symbol symbol-circle symbol-50px overflow-hidden me-3">
														<a>
															<div class="symbol-label">
																<img src="' . $Seller->store_logo() . '" alt="' . $Seller->store_name() . '" class="w-100">
															</div>
														</a>
													</div>
													<div class="d-flex flex-column">
														<a class="text-gray-800 text-hover-primary mb-1">' . $Seller->store_name() . '</a>
													     <span> ' . $Seller->user_id . '</span>
													</div></div>';
                }
            ),
            array(
                'db' => 'member_since',
                'dt' => "member_since",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ),
            array(
                'db' => 'requested_on',
                'dt' => "requested_date",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ), array(
                'db' => 'status',
                'dt' => "status",
                'formatter' => function ($status, $row) {
                    global $Web;
                    switch ($status) {
                        case "pending":
                            return $Web->status_to_label("Pending", "warning");
                            break;
                        case "verified":
                            return $Web->status_to_label("Verified", "success");
                            break;
                        case "rejected":
                            return $Web->status_to_label("Rejected", "danger");
                            break;
                    }
                }
            ),
            array(
                'db' => 'verification_id',
                'dt' => "actions",
                'formatter' => function ($verification_id, $row) {
                    $Verification = new SellerVerification($verification_id);
                    return '
                    <a href="' . $Verification->url() . '" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
						        <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
							</a>';
                }
            ),
        );


        $sql = "SELECT *, (SELECT registration_date FROM $Web->users_tbl WHERE $Web->users_tbl.user_id = $Web->ecommerce_seller_verification_tbl.user_id) as member_since FROM $Web->ecommerce_seller_verification_tbl WHERE status = '$status' ";
        $sql2 = "SELECT COUNT(*) FROM $Web->ecommerce_seller_verification_tbl WHERE status = '$status' ";


        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;


    case "qc_tbl":

        if (!$Web->is_isset("status")) Errors::response_404();
        $status = $Web->sanitize_text($_POST["status"]);
        if ($status !== "pending" && $status !== "approved"  && $status !== "rejected" && $status !== "all") Errors::response_404();

        $columns = array(
            array(
                'db' => 'qc_id', 'dt' => "product",
                'formatter' => function ($d, $row) {
                    $Q = new QC($d);
                    $Listing = $Q->listing();
                    return '<div class="d-flex align-items-center">
                        <a target="_blank" class="tbl-product-img">
                            <img src="' . $Listing->image($Q->variation_id(), $Listing->st_svariation($Q->variation_id())) . '">
                          </a>
                         <div class="ms-5">
                             <a target="_blank" class="text-gray-800 text-hover-primary wrap-text-1 fs-5 fw-bolder">' . $Listing->product_name($Q->variation_id(), $Listing->st_svariation($Q->variation_id())) . '</a>
                        </div>
                    </div>';
                }
            ),
            array(
                'db' => 'user_id',
                'dt' => "seller",
                'formatter' => function ($d, $row) {
                    $Seller = new Seller($d);

                    return '
                    <div class="d-flex flex-column">
														<a class="text-gray-800 text-hover-primary mb-1">' . $Seller->store_name() . '</a>
													     <span> ' . $Seller->user_id. '</span>
													</div>';
                }
            ),
            array(
                'db' => 'date_requested',
                'dt' => "req_date",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ),
            array(
                'db' => 'date_processed',
                'dt' => "res_date",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d) ?? "NA";
                }
            ), array(
                'db' => 'status',
                'dt' => "status",
                'formatter' => function ($d, $row) {
                    global $status;
                    $q = new QC($row["qc_id"]);
                    return $status == "all" ? $q->tbl_status_label() : $q->status_label();
                }
            ),
            array(
                'db' => 'qc_id',
                'dt' => "action",
                'formatter' => function ($d, $row) {
                    $Q = new QC($d);
                    return '
                    <a href="' . $Q->url($row["qvariation_id"]) . '"  class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
						        <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
							</a>';
                }
            ),
        );


        $sql = "SELECT * FROM $Web->ecommerce_qc_tbl WHERE status = '$status' GROUP BY qvariation_id ";
        $sql2 = "SELECT COUNT(DISTINCT(qvariation_id)) FROM $Web->ecommerce_qc_tbl  WHERE status = '$status' ";

        if ($status == "all") {
            $sql = "SELECT * FROM $Web->ecommerce_qc_tbl GROUP BY qvariation_id ";
            $sql2 = "SELECT COUNT(DISTINCT(qvariation_id)) FROM $Web->ecommerce_qc_tbl ";
        }


        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );


        break;

    default:
        Errors::response_404();
        break;
}
