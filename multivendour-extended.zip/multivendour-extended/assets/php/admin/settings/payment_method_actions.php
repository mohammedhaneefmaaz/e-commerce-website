<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../../db.php");
    }
    Errors::response_404();
}


use Ecommerce\PaymentMethod;

if (!$Web->is_isset("case")) Errors::response_404();
$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();
if (!$Login->is_admin_loggedin()) Errors::force_admin_login();


switch ($case) {

    case "change_payment_method_status":

        if (!$Web->is_isset("id")) Errors::response("Invalid details requested");
        $method_id = $Web->sanitize_text($_POST["id"]);

        if (!PaymentMethod::is_method_id($method_id)) Errors::response("Payment method doesn't exist");

        $PaymentMethod = new PaymentMethod($method_id);
        $status = $PaymentMethod->status();
        $details = $PaymentMethod->details();
        $name = $PaymentMethod->name();


        try {
            if ($status === "enabled") {
                $stmt = $db->prepare("UPDATE $Web->payment_methods_tbl SET status = 'disabled' WHERE method_id = ? ");
                $stmt->execute([$method_id]);
                $message = "Payment method has been disabled";
            } else {
                switch ($name) {
                    case "Paytm":
                        $merchantKey = $details->merchantKey;
                        $merchantMid = $details->merchantMid;
                        $environment = $details->environment;

                        if ($Web->is_empty($merchantKey, $merchantMid, $environment)) Errors::response("Please fill all the details of Paytm");
                        break;
                    case "Razorpay":
                        $keyId = $details->keyId;
                        $keySecret = $details->keySecret;

                        if ($Web->is_empty($keyId, $keySecret)) Errors::response("Please fill all the details of Razorpay");
                        break;
                }

                $stmt = $db->prepare("UPDATE $Web->payment_methods_tbl SET status = 'enabled' ,last_modified = ? WHERE method_id = ? ");
                $stmt->execute([$Web->current_time(),$method_id]);
                $message = "Payment method has been enabled";
            }
        } catch (Exception $e) {
            Errors::response_500("Error in updating details:-" . $e->getMessage());
        }

        $PaymentMethod = new PaymentMethod($method_id);
        $badge = $PaymentMethod->status_label();
        $editWrapper = $PaymentMethod->actions();

        $output = new stdClass;
        $output->badge = $badge;
        $output->editWrapper = $editWrapper;
        $output->message = $message;
        $output->last_modified = $PaymentMethod->last_modified();
        echo json_encode($output);

        break;

    case "get_payment_method_details":
        if (!$Web->is_isset("id")) Errors::response("Invalid details requested");
        $method_id = $Web->sanitize_text($_POST["id"]);

        if (!PaymentMethod::is_method_id($method_id)) Errors::response("Payment method doesn't exist");

        $PaymentMethod = new PaymentMethod($method_id);
        $details = $PaymentMethod->details();

        $form = '<form class="needs-validation" novalidate default-validation="true" >
        ' . $PaymentMethod->editForm() . '
                    <div class="justify-right">
                        <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                        <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>';

        $output =  new stdClass;
        $output->data = $form;
        $output->name = $PaymentMethod->name();
        echo json_encode($output);
        break;

    case "update_payment_method":

        if (!$Web->is_isset("id")) Errors::response("Invalid details requested");
        $method_id = $Web->sanitize_text($_POST["id"]);
        if (!PaymentMethod::is_method_id($method_id)) Errors::response("Payment method doesn't exist");
        $PaymentMethod = new PaymentMethod($method_id);
        $name = $PaymentMethod->name();

        switch ($name) {
            case "Paytm":
                if (!$Web->is_isset("merchantKey", "merchantMid", "environment")) Errors::response("Invalid details requested");

                $merchantKey = $_POST["merchantKey"];
                $merchantMid = $_POST["merchantMid"];
                $environment = $Web->sanitize_text($_POST["environment"]);

                if ($environment !== "PROD" && $environment !== "TEST") Errors::response("Invalid environment");

                $details = array(
                    "merchantKey" => $merchantKey,
                    "merchantMid" => $merchantMid,
                    "environment" => $environment,
                );

                $details = json_encode($details);
                $last_modified = $Web->current_time();

                try {
                    $stmt = $db->prepare("UPDATE $Web->payment_methods_tbl SET details = ?, last_modified = ? WHERE method_id = ? AND name = ? ");
                    $stmt->execute([$details, $last_modified, $method_id, $name]);
                } catch (Exception $e) {
                    Errors::response_500("Error in updating Paytm details" . $e->getMessage());
                }

                $PaymentMethod->update();

                $output = new stdClass;
                $output->message = "Paytm details has been updated";
                $output->last_modified = $PaymentMethod->last_modified();
                echo json_encode($output);
                break;

            case "Razorpay":

                if (!$Web->is_isset("keyId", "keySecret")) Errors::response("Invalid details requested");

                $keyId = $_POST["keyId"];
                $keySecret = $_POST["keySecret"];

                $details = array(
                    "keyId" => $keyId,
                    "keySecret" => $keySecret
                );
                $details = json_encode($details);
                $last_modified = $Web->current_time();

                try {
                    $stmt = $db->prepare("UPDATE $Web->payment_methods_tbl SET details = ?, last_modified = ? WHERE method_id = ? AND name = ? ");
                    $stmt->execute([$details, $last_modified, $method_id, $name]);
                } catch (Exception $e) {
                    Errors::response_500("Error in updating Paytm details" . $e->getMessage());
                }

                $PaymentMethod->update();
                $output = new stdClass;
                $output->message = "Razorpay details has been updated";
                $output->last_modified = $PaymentMethod->last_modified();
                echo json_encode($output);

                break;
        }

        break;

    default:
        Errors::response_404();
        break;
}
