<?php

use Ecommerce\Category;
use Ecommerce\HomePageSetting;
use Ecommerce\Component;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../../db.php");
    }
    Errors::response_404();
}

if (!$Web->is_isset("case")) Errors::response_404();

$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();

if (!$Login->is_admin_loggedin()) Errors::force_admin_login();



switch ($case) {


        // Product Sliders
    case "fetch_categories":
        if (!$Web->is_isset("category_id")) Errors::response("Invalid Request");
        $category_id = $Web->sanitize_text($_POST["category_id"]);
        if (!Category::is_category_id($category_id) && $category_id != '0') Errors::response("Category do not exist");



        if ($category_id == '0') {
            $header = "";
            $content = HomePageSetting::choose_categories();
        } else {
            $Category = new Category($category_id);
            if (!$Category->has_or_child_content()) Errors::response("Category do not exist");
            $header = '
                <div data-choose-category="true" data-id="' . $Category->parent_id() . '" class="p-4 hover align-center cursor-pointer category-list border-bottom">
                    <span class="svg-icon svg-icon-muted svg-icon-2hx">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <rect opacity="0.5" x="6" y="11" width="13" height="2" rx="1" fill="black"/>
                        <path d="M8.56569 11.4343L12.75 7.25C13.1642 6.83579 13.1642 6.16421 12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75L5.70711 11.2929C5.31658 11.6834 5.31658 12.3166 5.70711 12.7071L11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25C13.1642 17.8358 13.1642 17.1642 12.75 16.75L8.56569 12.5657C8.25327 12.2533 8.25327 11.7467 8.56569 11.4343Z" fill="black"/>
                        </svg>
                    </span>
                    <div class="fs-4 ms-4 d-flex fw-bold">' . $Category->category() . '</div>
                 </div>';
        }

        $content = $category_id == '0' ?  HomePageSetting::choose_categories() :  HomePageSetting::choose_categories($category_id);
        $data = $header . $content;

        $output = new stdClass;
        $output->data = $data;
        echo json_encode($output);
        break;

    case "product_slider_add_update":

        if (!$Web->is_isset(
            "event",
            "heading",
            "category",
            "sort_by",
            "total_columns",
            "status"
        )) Errors::response_404();

        $event = $Web->sanitize_text($_POST["event"]);
        $heading = $Web->sanitize_text($_POST["heading"]);
        $category = $Web->sanitize_text($_POST["category"]);
        $sort_by = $Web->sanitize_text($_POST["sort_by"]);
        $total_columns = $Web->sanitize_text($_POST["total_columns"]);
        $status = $Web->sanitize_text($_POST["status"]);

        $Web->validate_post_length($heading, 25, "Maximum Heading length is 25");

        $Web->validate_post_input($heading, "", "Heading", true);
        $Web->validate_post_input($category, "", "Category", true);
        $Web->validate_post_input($sort_by, "", "Sort By", true);
        $Web->validate_post_input($total_columns, "number", "Total Columns", true);
        $Web->validate_post_input($status, "", "Status", true);

        if ($event !== "create" && $event !== "update") Errors::response_404();
        if ($status !== "active" && $status !== "inactive") Errors::response_404();
        if (!in_array($sort_by, [
            "sells",
            "latest",
            "price_asc",
            "price_desc",
            "discount",
            "rating",
            "view",
            "random",
        ])) Errors::response_404();
        if ($category !== "all" && !Category::is_category_id($category)) Errors::response("Category is not valid");



        $new_product_slider = [
            "heading" => $heading,
            "category" => $category,
            "sort_by" => $sort_by,
            "total_columns" => $total_columns,
            "status" => $status
        ];
        $new_product_slider = json_encode($new_product_slider);

        try {
            $output = new stdClass;
            switch ($event) {
                case "create":

                    if (Component::is_product_slider_name($heading)) Errors::response("Duplicate heading not allowed");
                    $get_new_index = Component::get_new_index();
                    $stmt = $db->prepare("INSERT INTO $Web->components_tbl (`heading`,`data`,`card_index`,`type`) VALUES (?,?,?,'product_slider') ");
                    $stmt->execute([$heading, $new_product_slider, $get_new_index]);

                    $component_id = $db->lastInsertId();
                   $Component = new Component($component_id);

                    $output->message = "Product slider has been created";
                    break;
                case "update":
                    if (!$Web->is_isset("component_id")) Errors::response("Invalid request");
                    $component_id = $Web->sanitize_text($_POST["component_id"]);
                    if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
                   $Component = new Component($component_id);
                    if ($Component->type() !== "product_slider") Errors::response("Invalid type");
                    if (Component::is_product_slider_name($heading, $component_id)) Errors::response("Duplicate heading not allowed");

                    $stmt = $db->prepare("UPDATE $Web->components_tbl SET heading = ? ,  data = ? WHERE component_id = ? AND type = 'product_slider' ");
                    $stmt->execute([$heading, $new_product_slider, $component_id]);
                    $output->message = "Product slider has been updated";
                    break;
            }


            $output->content = Component::product_sliders_tbl();
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in updating sliders" . $e->getMessage());
        }


        break;


    case "delete_product_slider":

        if (!$Web->is_isset("component_id")) Errors::response_404();
        $component_id = $Web->sanitize_text($_POST["component_id"]);

        try {
            if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
           $Component = new Component($component_id);
            if ($Component->type() !== "product_slider") Errors::response("Invalid type");

            $stmt = $db->prepare("DELETE FROM $Web->components_tbl WHERE component_id = ? AND type = 'product_slider' ");
            $stmt->execute([$component_id]);

            $output = new stdClass;
            $output->message = "Slider has been deleted";
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in deleting slider");
        }

        break;

    case "change_product_slider_status":

        if (!$Web->is_isset("component_id")) Errors::response("Invalid request");
        $component_id = $Web->sanitize_text($_POST["component_id"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        if ($Component->type() !== "product_slider") Errors::response("Invalid type");

        $row = $Component->data();
        $status = $row->status;
        $status = $status == "active" ?  "inactive" : "active";
        $row->status = $status;

        try {
            $row = json_encode($row);
            $stmt = $db->prepare("UPDATE $Web->components_tbl SET data = ? WHERE component_id = ? AND type = 'product_slider' ");
            $stmt->execute([$row, $component_id]);
            $Component->update();
        } catch (Exception $e) {
            Errors::response_500("Error in changing status" . $e->getMessage());
        }

        $row = $Component->data();
        $status = $row->status;
        $status_text = "Active";
        $statusSvg = '<i class="fs-2 fas fa-eye"></i>';
        $badge = $status == "active" ?
            $Web->status_to_label("active", "success") :
            $Web->status_to_label("inactive", "danger");

        if ($status == "active") {
            $status_text = "Inactive";
            $statusSvg = '<i class="fs-2 fas fa-eye-slash"></i>';
        }

        $button = '<button data-component_id="' . $component_id . '" data-action="changeStatus" data-bs-toggle="tooltip" data-bs-original-title="' . $status_text . '" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">' . $statusSvg . '</button>';

        $output = new stdClass;
        $output->message = "Status has been changed";
        $output->button = $button;
        $output->badge = $badge;
        echo json_encode($output);
        break;

    case "get_product_slider_update_form":

        if (!$Web->is_isset("component_id")) Errors::response("Invalid request");
        $component_id = $Web->sanitize_text($_POST["component_id"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        if ($Component->type() !== "product_slider") Errors::response("Invalid type");
        $row = $Component->data();

        $category_option = "";
        if ($row->category !== "all") {
            $Category = new Category($row->category);
            $category_option = '<option selected value="' . $row->category . '" >' . $Category->category() . '</option>';
        }


        $data = '<form id="sliderForm" novalidate class="need-validation">
        <input type="hidden" name="event" value="update">
        <input type="hidden" name="component_id" value="' . $component_id . '">

        <div class="fv-row mb-7">
            <label class="form-label required mb-2">Heading</label>
            <input value="' . $row->heading . '" required type="text" class="form-control form-control-solid" name="heading">
            <div class="invalid-feedback">Heading is required</div>
        </div>

        <div class="fv-row mb-7">
            <label class="required fs-6 fw-bold form-label mb-2"> Category</label>
            <select value="' . $row->category . '" name="category" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" type="text" class="form-select form-select-solid">
                <option></option>
                <option value="all">All</option>
                <option value="choose">Choose</option>
                ' . $category_option . '
            </select>
            <div class="invalid-feedback">Category is required</div>
        </div>


        <div class="fv-row mb-7">
            <label class="required fs-6 fw-bold form-label mb-2">Sort By</label>
            <select  value="' . $row->sort_by . '" name="sort_by" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" type="text" class="form-select form-select-solid">
                <option></option>
                <option value="sells">Sells</option>
                <option value="latest">Latest</option>
                <option value="price_asc">Price: Low To High</option>
                <option value="price_desc">Price: High To Low</option>
                <option value="discount">Discount</option>
                <option value="rating">Rating</option>
                <option value="view">View</option>
            </select>
            <div class="invalid-feedback">Sort By is required</div>
        </div>

        <div class="fv-row mb-7">
            <label class="form-label required mb-2">Total Columns<i data-bs-toggle="tooltip" data-bs-original-title="Total number of cards to load in slider" class="fas text-muted fa-exclamation-circle ms-1 fs-7"></i></label>
            <input  value="' . $row->total_columns . '"data-mask="integer" required type="text" class="form-control form-control-solid" name="total_columns">
            <div class="invalid-feedback">Total Columns is required</div>
        </div>

        <div class="fv-row mb-7">
            <label class="required fs-6 fw-bold form-label mb-2"> Status</label>
            <select  value="' . $row->status . '" name="status" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" type="text" class="form-select form-select-solid">
                <option></option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
            <div class="invalid-feedback">Status is required</div>
        </div>

        <div class="justify-right">
            <button type=submit class="btn btn-primary">Update
                <span class="svg-icon svg-icon-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black"></rect>
                        <path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black"></path>
                    </svg>
                </span>
            </button>
        </div>
    </form>';

        $output = new stdClass;
        $output->data = $data;
        echo json_encode($output);

        break;


        // Sliders
    case "create_new_slider":
        try {
            $new_slider_name = Component::new_slider_name();
            $get_new_index = Component::get_new_index();
            $stmt = $db->query("INSERT INTO $Web->components_tbl (`heading`,`data`,`card_index`,`type`) VALUES ('$new_slider_name','[]','$get_new_index','slider') ");

            $component_id = $db->lastInsertId();
           $Component = new Component($component_id);
            $card = $Component->single_slider_tbl_card();

            $output = new stdClass;
            $output->card = $card;
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in adding slider");
        }
        break;

    case "delete_slider":
        if (!$Web->is_isset("component_id")) Errors::response_404();
        $component_id = $Web->sanitize_text($_POST["component_id"]);

        try {
            if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
           $Component = new Component($component_id);
            if ($Component->type() !== "slider") Errors::response("Invalid type");

            $stmt = $db->prepare("DELETE FROM $Web->components_tbl WHERE component_id = ? AND type = 'slider' ");
            $stmt->execute([$component_id]);

            $output = new stdClass;
            $output->message = "Slider has been deleted";
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in deleting slider");
        }
        break;

    case "update_slider":
        if (!$Web->is_isset("component_id", "heading")) Errors::response_404();
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $heading = $Web->sanitize_text($_POST["heading"]);

        try {
            if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
           $Component = new Component($component_id);
            if ($Component->type() !== "slider") Errors::response("Invalid type");
            $Web->validate_post_input($heading, "", "Heading", true);
            $Web->validate_post_length($heading, 100, "Maximum 100 characters are allowed");

            if (Component::is_slider_name($heading, $component_id)) Errors::response("Duplicate heading not allowed");


            $stmt = $db->prepare("UPDATE $Web->components_tbl SET heading = ? WHERE component_id = ? AND type = 'slider' ");
            $stmt->execute([$heading, $component_id]);

            $Component->update();
            $heading = $Component->heading();

            $output = new stdClass;
            $output->heading = $heading;
            $output->message = "Heading has been update";
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in updating heading");
        }
        break;

    case "add_sliders_slide":
        if (!$Web->is_isset("component_id", "image_id", "status", "url", "event")) Errors::response("Invalid request");
        $image_id = $Web->sanitize_text($_POST["image_id"]);
        $status = $Web->sanitize_text($_POST["status"]);
        $url = $Web->sanitize_text($_POST["url"]);
        $event = $Web->sanitize_text($_POST["event"]);
        $component_id = $Web->sanitize_text($_POST["component_id"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        if ($Component->type() !== "slider") Errors::response("Invalid type");

        if (!$Web->is_file_id($image_id)) Errors::response("File doesn't exist");
        if (!empty($url)) $Web->validate_post_input($url, "url", "Url", true);
        if ($status !== "active" && $status !== "inactive") Errors::response("Status is invalid");
        if ($event !== "create" && $event !== "update") Errors::response("Event is invalid");

        $data = $Component->data();
        $output = new stdClass;

        switch ($event) {
            case "create":
                $data[] = array(
                    "image_id" => $image_id,
                    "url" => $url,
                    "status" => $status
                );
                $output->message = "Slide has been added";
                break;
            default:
                if (!$Web->is_isset("key")) Errors::response("Invalid request");
                $key = $Web->sanitize_text($_POST["key"]);
                if (!isset($data[$key])) Errors::response("Slider doesn't exist");
                $data[$key] = array(
                    "image_id" => $image_id,
                    "url" => $url,
                    "status" => $status
                );
                $output->message = "Slide has been updated";
                break;
        }
        $data = json_encode($data, true);
        try {
            $stmt = $db->prepare("UPDATE $Web->components_tbl SET data = ? WHERE component_id = ? AND type = 'slider' ");
            $stmt->execute([$data, $component_id]);
            $Component->update();
        } catch (Exception $e) {
            Errors::response_500($e->getMessage());
        }

        $output->content = $Component->slider_tbl_content();
        echo json_encode($output);
        break;


    case "get_slider_slide_update_form":
        if (!$Web->is_isset("key", "component_id")) Errors::response("Invalid request");
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $key = $Web->sanitize_text($_POST["key"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        $cards = $Component->data();
        if ($Component->type() !== "slider") Errors::response("Invalid type");

        if (!isset($cards[$key])) Errors::response("Slider doesn't exist");

        $row = $cards[$key];


        $data = '  <form novalidate class="need-validation">
        <input type="hidden" name="event" value="update">
        <input type="hidden" name="key" value="' . $key . '">
        <div class="fv-row mb-7">
            <label class="required form-label mb-2">Image</label>
            <div id="uploadCard" class="position-relative cursor-pointer justify-align-center mb-2 bg-light min-h-200px">
                <div class="bottom-inherit image-upload-progress top-0">
                    <div class="progress-bar h-3px"></div>
                </div>
                <div id="innerContent">
                    <img src="' . $Web->get_file_src($row->image_id) . '" class="mh-100 img-fluid">
                </div>
            </div>
            <input value="' . $row->image_id . '" autocomplete="off" class="sr-only" required name="image_id" value="">
            <div class="invalid-feedback">Please upload a image</div>
        </div>
        <div class="fv-row mb-7">
            <label class="form-label mb-2">Url</label>
            <input value="' . $row->url . '" autocomplete="off" type="text" class="form-control form-control-solid" name="url" value="">
        </div>
        <div class="fv-row mb-7">
            <label class="required fs-6 fw-bold form-label mb-2"> Status</label>
            <select value="' . $row->status . '" autocomplete="off" name="status" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" value="" type="text" class="form-select form-select-solid">
                <option value=""></option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
            <div class="invalid-feedback" >Status is required</div>
        </div>
        <div class="justify-right">
            <button type="submit" class="btn btn-primary">Update<span class="svg-icon svg-icon-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black"></rect>
                        <path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black"></path>
                    </svg>
                </span></button>
        </div>
    </form>';

        $output = new stdClass;
        $output->data = $data;
        echo json_encode($output);
        break;

    case "delete_slider_slide":
        if (!$Web->is_isset("key", "component_id")) Errors::response("Invalid request");
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $key = $Web->sanitize_text($_POST["key"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        $cards = $Component->data();
        if ($Component->type() !== "slider") Errors::response("Invalid type");

        if (!isset($cards[$key])) Errors::response("Slider doesn't exist");
        unset($cards[$key]);

        $cards = array_values($cards);

        try {
            $cards = json_encode($cards);
            $stmt = $db->prepare("UPDATE $Web->components_tbl SET data = ? WHERE component_id = ? AND type = 'slider' ");
            $stmt->execute([$cards, $component_id]);
        } catch (Exception $e) {
            Errors::response_500("Error in deleting image" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Slide has been deleted";
        echo json_encode($output);
        break;

    case "change_slider_slide_status":
        if (!$Web->is_isset("key", "component_id")) Errors::response("Invalid request");
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $key = $Web->sanitize_text($_POST["key"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        $cards = $Component->data();
        if ($Component->type() !== "slider") Errors::response("Invalid type");

        if (!isset($cards[$key])) Errors::response("Slider doesn't exist");

        $status = $cards[$key]->status;
        $status = $status == "active" ?  "inactive" : "active";
        $cards[$key]->status = $status;

        try {
            $cards = json_encode($cards);
            $stmt = $db->prepare("UPDATE $Web->components_tbl SET data = ? WHERE component_id = ? AND type = 'slider' ");
            $stmt->execute([$cards, $component_id]);
            $Component->update();
        } catch (Exception $e) {
            Errors::response_500("Error in changing status" . $e->getMessage());
        }

        $cards = $Component->data();
        $status = $cards[$key]->status;
        $status_text = "Active";
        $statusSvg = '<i class="fs-2 fas fa-eye"></i>';
        $badge = $status == "active" ?
            $Web->status_to_label("active", "success") :
            $Web->status_to_label("inactive", "danger");

        if ($status == "active") {
            $status_text = "Inactive";
            $statusSvg = '<i class="fs-2 fas fa-eye-slash"></i>';
        }

        $button = '<button data-component_id="' . $component_id . '" data-key="' . $key . '" data-action="changeSliderSlideStatus" data-bs-toggle="tooltip" data-bs-original-title="' . $status_text . '" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">' . $statusSvg . '</button>';

        $output = new stdClass;
        $output->message = "Status has been changed";
        $output->button = $button;
        $output->badge = $badge;
        echo json_encode($output);
        break;


        // Manual Slider Start

        // Sliders
    case "create_new_manual_slider":
        try {
            $new_slider_name = Component::new_manual_slider_name();
            $get_new_index = Component::get_new_index();

            $columns = 6;
            $tab_columns = 4;
            $mobile_columns = 2;

            $stmt = $db->query("INSERT INTO $Web->components_tbl (`heading`,`data`,`card_index`,`type`,`columns`,`tab_columns`,`mobile_columns`) VALUES ('$new_slider_name','[]','$get_new_index','manual_slider', '$columns', '$tab_columns', '$mobile_columns') ");

            $component_id = $db->lastInsertId();
           $Component = new Component($component_id);
            $card = $Component->single_manual_slider_tbl_card();

            $output = new stdClass;
            $output->card = $card;
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in adding slider");
        }
        break;

    case "delete_manual_slider":
        if (!$Web->is_isset("component_id")) Errors::response_404();
        $component_id = $Web->sanitize_text($_POST["component_id"]);

        try {
            if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
           $Component = new Component($component_id);
            if ($Component->type() !== "manual_slider") Errors::response("Invalid type");

            $stmt = $db->prepare("DELETE FROM $Web->components_tbl WHERE component_id = ? AND type = 'manual_slider' ");
            $stmt->execute([$component_id]);

            $output = new stdClass;
            $output->message = "Slider has been deleted";
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in deleting slider");
        }
        break;

    case "update_manual_slider":
        if (!$Web->is_isset("component_id", "heading", "columns", "tab_columns", "mobile_columns")) Errors::response_404();
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $heading = $Web->sanitize_text($_POST["heading"]);
        $columns = $Web->sanitize_text($_POST["columns"]);
        $tab_columns = $Web->sanitize_text($_POST["tab_columns"]);
        $mobile_columns = $Web->sanitize_text($_POST["mobile_columns"]);

        $Web->validate_post_input($columns, "number", "Columns", true);
        $Web->validate_post_input($tab_columns, "number", "Tab Columns", true);
        $Web->validate_post_input($mobile_columns, "number", "Mobile Columns", true);

        try {
            if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
           $Component = new Component($component_id);
            if ($Component->type() !== "manual_slider") Errors::response("Invalid type");
            $Web->validate_post_input($heading, "", "Heading", true);
            $Web->validate_post_length($heading, 100, "Maximum 100 characters are allowed");

            if (Component::is_slider_name($heading, $component_id)) Errors::response("Duplicate heading not allowed");


            $stmt = $db->prepare("UPDATE $Web->components_tbl SET heading = ?, columns = ?, tab_columns = ?,mobile_columns = ?  WHERE component_id = ? AND type = 'manual_slider' ");
            $stmt->execute([$heading, $columns, $tab_columns, $mobile_columns, $component_id]);

            $Component->update();
            $heading = $Component->heading();

            $output = new stdClass;
            $output->heading = $heading;
            $output->columns = $columns;
            $output->tab_columns = $tab_columns;
            $output->mobile_columns = $mobile_columns;
            $output->message = "Details has been update";
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in updating details".$e->getLine());
        }
        break;

    case "add_manual_sliders_slide":
        if (!$Web->is_isset("component_id", "image_id", "status", "url", "text1", "text2", "text3", "event")) Errors::response("Invalid request");
        $image_id = $Web->sanitize_text($_POST["image_id"]);
        $status = $Web->sanitize_text($_POST["status"]);
        $url = $Web->sanitize_text($_POST["url"]);
        $event = $Web->sanitize_text($_POST["event"]);
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $text1 = $Web->sanitize_text($_POST["text1"]);
        $text2 = $Web->sanitize_text($_POST["text2"]);
        $text3 = $Web->sanitize_text($_POST["text3"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        if ($Component->type() !== "manual_slider") Errors::response("Invalid type");

        if (!$Web->is_file_id($image_id)) Errors::response("File doesn't exist");
        if (!empty($url)) $Web->validate_post_input($url, "url", "Url", true);
        if ($status !== "active" && $status !== "inactive") Errors::response("Status is invalid");
        if ($event !== "create" && $event !== "update") Errors::response("Event is invalid");

        $data = $Component->data();
        $output = new stdClass;

        switch ($event) {
            case "create":
                $data[] = array(
                    "image_id" => $image_id,
                    "url" => $url,
                    "text1" => $text1,
                    "text2" => $text2,
                    "text3" => $text3,
                    "status" => $status
                );
                $output->message = "Slide has been added";
                break;
            default:
                if (!$Web->is_isset("key")) Errors::response("Invalid request");
                $key = $Web->sanitize_text($_POST["key"]);
                if (!isset($data[$key])) Errors::response("Slider doesn't exist");
                $data[$key] = array(
                    "image_id" => $image_id,
                    "url" => $url,
                    "text1" => $text1,
                    "text2" => $text2,
                    "text3" => $text3,
                    "status" => $status
                );
                $output->message = "Slide has been updated";
                break;
        }
        $data = json_encode($data, true);
        try {
            $stmt = $db->prepare("UPDATE $Web->components_tbl SET data = ? WHERE component_id = ? AND type = 'manual_slider' ");
            $stmt->execute([$data, $component_id]);
            $Component->update();
        } catch (Exception $e) {
            Errors::response_500($e->getMessage());
        }

        $output->content = $Component->slider_tbl_content();
        echo json_encode($output);
        break;


    case "get_manual_slider_slide_update_form":
        if (!$Web->is_isset("key", "component_id")) Errors::response("Invalid request");
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $key = $Web->sanitize_text($_POST["key"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        $cards = $Component->data();
        if ($Component->type() !== "manual_slider") Errors::response("Invalid type");

        if (!isset($cards[$key])) Errors::response("Slider doesn't exist");

        $row = $cards[$key];


        $data = '  <form novalidate class="need-validation">
        <input type="hidden" name="event" value="update">
        <input type="hidden" name="key" value="' . $key . '">
        <div class="fv-row mb-7">
            <label class="required form-label mb-2">Image</label>
            <div id="uploadCard" class="position-relative cursor-pointer justify-align-center mb-2 bg-light min-h-200px">
                <div class="bottom-inherit image-upload-progress top-0">
                    <div class="progress-bar h-3px"></div>
                </div>
                <div id="innerContent">
                    <img src="' . $Web->get_file_src($row->image_id) . '" class="mh-100 img-fluid">
                </div>
            </div>
            <input value="' . $row->image_id . '" autocomplete="off" class="sr-only" required name="image_id" value="">
            <div class="invalid-feedback">Please upload a image</div>
        </div>
        <div class="fv-row mb-7">
            <label class="form-label mb-2">Url</label>
            <input value="' . $row->url . '" autocomplete="off" type="text" class="form-control form-control-solid" name="url" value="">
        </div>
        <div class="fv-row mb-7">
        <label class="form-label mb-2">Text 1</label>
        <input value="' . $row->text1 . '" autocomplete="off" type="text" class="form-control form-control-solid" name="text1" value="">
    </div>
    <div class="fv-row mb-7">
        <label class="form-label mb-2">Text 2</label>
        <input value="' . $row->text2 . '" autocomplete="off" type="text" class="form-control form-control-solid" name="text2" value="">
    </div>
    <div class="fv-row mb-7">
        <label class="form-label mb-2">Text 3</label>
        <input value="' . $row->text3 . '" autocomplete="off" type="text" class="form-control form-control-solid" name="text3" value="">
    </div>
        <div class="fv-row mb-7">
            <label class="required fs-6 fw-bold form-label mb-2"> Status</label>
            <select value="' . $row->status . '" autocomplete="off" name="status" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" value="" type="text" class="form-select form-select-solid">
                <option value=""></option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
            <div class="invalid-feedback" >Status is required</div>
        </div>
        <div class="justify-right">
            <button type="submit" class="btn btn-primary">Update<span class="svg-icon svg-icon-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black"></rect>
                        <path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black"></path>
                    </svg>
                </span></button>
        </div>
    </form>';

        $output = new stdClass;
        $output->data = $data;
        echo json_encode($output);
        break;

    case "delete_manual_slider_slide":
        if (!$Web->is_isset("key", "component_id")) Errors::response("Invalid request");
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $key = $Web->sanitize_text($_POST["key"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        $cards = $Component->data();
        if ($Component->type() !== "manual_slider") Errors::response("Invalid type");

        if (!isset($cards[$key])) Errors::response("Slider doesn't exist");
        unset($cards[$key]);

        $cards = array_values($cards);

        try {
            $cards = json_encode($cards);
            $stmt = $db->prepare("UPDATE $Web->components_tbl SET data = ? WHERE component_id = ? AND type = 'manual_slider' ");
            $stmt->execute([$cards, $component_id]);
        } catch (Exception $e) {
            Errors::response_500("Error in deleting image" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Slide has been deleted";
        echo json_encode($output);
        break;

    case "change_manual_slider_slide_status":
        if (!$Web->is_isset("key", "component_id")) Errors::response("Invalid request");
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $key = $Web->sanitize_text($_POST["key"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        $cards = $Component->data();
        if ($Component->type() !== "manual_slider") Errors::response("Invalid type");

        if (!isset($cards[$key])) Errors::response("Slider doesn't exist");

        $status = $cards[$key]->status;
        $status = $status == "active" ?  "inactive" : "active";
        $cards[$key]->status = $status;

        try {
            $cards = json_encode($cards);
            $stmt = $db->prepare("UPDATE $Web->components_tbl SET data = ? WHERE component_id = ? AND type = 'manual_slider' ");
            $stmt->execute([$cards, $component_id]);
            $Component->update();
        } catch (Exception $e) {
            Errors::response_500("Error in changing status" . $e->getMessage());
        }

        $cards = $Component->data();
        $status = $cards[$key]->status;
        $status_text = "Active";
        $statusSvg = '<i class="fs-2 fas fa-eye"></i>';
        $badge = $status == "active" ?
            $Web->status_to_label("active", "success") :
            $Web->status_to_label("inactive", "danger");

        if ($status == "active") {
            $status_text = "Inactive";
            $statusSvg = '<i class="fs-2 fas fa-eye-slash"></i>';
        }

        $button = '<button data-component_id="' . $component_id . '" data-key="' . $key . '" data-action="changeSliderSlideStatus" data-bs-toggle="tooltip" data-bs-original-title="' . $status_text . '" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">' . $statusSvg . '</button>';

        $output = new stdClass;
        $output->message = "Status has been changed";
        $output->button = $button;
        $output->badge = $badge;
        echo json_encode($output);
        break;

        // Manual Slider End



        // Banner Start



    case "create_new_banner_collection":
        try {
            $get_new_index = Component::get_new_index();
            $new_banner_name = Component::new_banner_name();

            $columns = 4;
            $tab_columns = 2;
            $mobile_columns = 1;

            $stmt = $db->query("INSERT INTO $Web->components_tbl (`heading`,`data`,`card_index`,`type`,`columns`,`tab_columns`,`mobile_columns`) VALUES ('$new_banner_name','[]','$get_new_index','banner', '$columns', '$tab_columns', '$mobile_columns') ");

            $component_id = $db->lastInsertId();
           $Component = new Component($component_id);
            $card = $Component->single_banner_collection_tbl();

            $output = new stdClass;
            $output->card = $card;
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in adding banner");
        }
        break;

    case "delete_banner_collection":
        if (!$Web->is_isset("component_id")) Errors::response_404();
        $component_id = $Web->sanitize_text($_POST["component_id"]);

        try {
            if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
            $Component = new Component($component_id);
            if ($Component->type() !== "banner") Errors::response("Invalid type");

            $stmt = $db->prepare("DELETE FROM $Web->components_tbl WHERE component_id = ? AND type = 'banner' ");
            $stmt->execute([$component_id]);

            $output = new stdClass;
            $output->message = "Collection has been deleted";
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in deleting collection");
        }
        break;

    case "update_banner_collection":
        if (!$Web->is_isset("component_id", "heading","columns", "tab_columns", "mobile_columns")) Errors::response_404();
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $heading = $Web->sanitize_text($_POST["heading"]);
        $columns = $Web->sanitize_text($_POST["columns"]);
        $tab_columns = $Web->sanitize_text($_POST["tab_columns"]);
        $mobile_columns = $Web->sanitize_text($_POST["mobile_columns"]);

        $Web->validate_post_input($columns, "number", "Columns", true);
        $Web->validate_post_input($tab_columns, "number", "Tab Columns", true);
        $Web->validate_post_input($mobile_columns, "number", "Mobile Columns", true);

        try {
            if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
            $Component = new Component($component_id);
            if ($Component->type() !== "banner") Errors::response("Invalid type");
            $Web->validate_post_input($heading, "", "Heading", true);
            $Web->validate_post_length($heading, 100, "Maximum 100 characters are allowed");

            if (Component::is_banner_name($heading, $component_id)) Errors::response("Duplicate heading not allowed");
            $stmt = $db->prepare("UPDATE $Web->components_tbl SET heading = ?, columns = ?, tab_columns = ?,mobile_columns = ? WHERE component_id = ? AND type = 'banner' ");
            $stmt->execute([$heading,$columns, $tab_columns, $mobile_columns, $component_id]);

            $Component->update();
            $heading = $Component->heading();

            $output = new stdClass;
            $output->heading = $heading;
            $output->message = "Details has been update";
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in updating details");
        }
        break;

    case "create_new_banner":
        if (!$Web->is_isset("component_id", "image_id", "status", "url", "event")) Errors::response("Invalid request");
        $image_id = $Web->sanitize_text($_POST["image_id"]);
        $status = $Web->sanitize_text($_POST["status"]);
        $url = $Web->sanitize_text($_POST["url"]);
        $event = $Web->sanitize_text($_POST["event"]);
        $component_id = $Web->sanitize_text($_POST["component_id"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
        $Component = new Component($component_id);
        if ($Component->type() !== "banner") Errors::response("Invalid type");

        if (!$Web->is_file_id($image_id)) Errors::response("File doesn't exist");
        if (!empty($url)) $Web->validate_post_input($url, "url", "Url", true);
        if ($status !== "active" && $status !== "inactive") Errors::response("Status is invalid");
        if ($event !== "create" && $event !== "update") Errors::response("Event is invalid");

        $data = $Component->data();
        $output = new stdClass;

        switch ($event) {
            case "create":
                $data[] = array(
                    "image_id" => $image_id,
                    "url" => $url,
                    "status" => $status
                );
                $output->message = "Banner has been added";
                break;
            default:
                if (!$Web->is_isset("key")) Errors::response("Invalid request");
                $key = $Web->sanitize_text($_POST["key"]);
                if (!isset($data[$key])) Errors::response("Slider doesn't exist");
                $data[$key] = array(
                    "image_id" => $image_id,
                    "url" => $url,
                    "status" => $status
                );
                $output->message = "Banner has been updated";
                break;
        }
        $data = json_encode($data, true);
        try {

            $stmt = $db->prepare("UPDATE $Web->components_tbl SET data = ? WHERE component_id = ? AND type = 'banner' ");
            $stmt->execute([$data, $component_id]);
            $Component->update();
        } catch (Exception $e) {
            Errors::response_500($e->getMessage());
        }

        $output->content = $Component->banner_collection_tbl_content();
        echo json_encode($output);
        break;


    case "get_banner_update_form":
        if (!$Web->is_isset("key", "component_id")) Errors::response("Invalid request");
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $key = $Web->sanitize_text($_POST["key"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        if ($Component->type() !== "banner") Errors::response("Invalid type");
        $cards = $Component->data();

        if (!isset($cards[$key])) Errors::response("Banner doesn't exist");

        $row = $cards[$key];


        $data = '  <form novalidate class="need-validation">
            <input type="hidden" name="event" value="update">
            <input type="hidden" name="key" value="' . $key . '">
            <div class="fv-row mb-7">
                <label class="required form-label mb-2">Image</label>
                <div id="uploadCard" class="position-relative cursor-pointer justify-align-center mb-2 bg-light min-h-200px">
                    <div class="bottom-inherit image-upload-progress top-0">
                        <div class="progress-bar h-3px"></div>
                    </div>
                    <div id="innerContent">
                        <img src="' . $Web->get_file_src($row->image_id) . '" class="mh-100 img-fluid">
                    </div>
                </div>
                <input value="' . $row->image_id . '" autocomplete="off" class="sr-only" required name="image_id" value="">
                <div class="invalid-feedback">Please upload a image</div>
            </div>
            <div class="fv-row mb-7">
                <label class="form-label mb-2">Url</label>
                <input value="' . $row->url . '" autocomplete="off" type="text" class="form-control form-control-solid" name="url" value="">
            </div>
            <div class="fv-row mb-7">
                <label class="required fs-6 fw-bold form-label mb-2"> Status</label>
                <select value="' . $row->status . '" autocomplete="off" name="status" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" value="" type="text" class="form-select form-select-solid">
                    <option value=""></option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
                <div class="invalid-feedback" >Status is required</div>
            </div>
            <div class="justify-right">
                <button type="submit" class="btn btn-primary">Update<span class="svg-icon svg-icon-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black"></rect>
                            <path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black"></path>
                        </svg>
                    </span></button>
            </div>
        </form>';

        $output = new stdClass;
        $output->data = $data;
        echo json_encode($output);
        break;

    case "delete_banner":
        if (!$Web->is_isset("key", "component_id")) Errors::response("Invalid request");
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $key = $Web->sanitize_text($_POST["key"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        $cards = $Component->data();
        if ($Component->type() !== "banner") Errors::response("Invalid type");

        if (!isset($cards[$key])) Errors::response("Slider doesn't exist");
        unset($cards[$key]);
        $cards = array_values($cards);
        try {
            $cards = json_encode($cards);

            $stmt = $db->prepare("UPDATE $Web->components_tbl SET data = ? WHERE component_id = ? AND type = 'banner' ");
            $stmt->execute([$cards, $component_id]);
        } catch (Exception $e) {
            Errors::response_500("Error in deleting banner" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Banner has been deleted";
        echo json_encode($output);
        break;

    case "change_banner_status":
        if (!$Web->is_isset("key", "component_id")) Errors::response("Invalid request");
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $key = $Web->sanitize_text($_POST["key"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        $cards = $Component->data();
        if ($Component->type() !== "banner") Errors::response("Invalid type");

        if (!isset($cards[$key])) Errors::response("Slider doesn't exist");

        $status = $cards[$key]->status;
        $status = $status == "active" ?  "inactive" : "active";
        $cards[$key]->status = $status;

        try {
            $cards = json_encode($cards);
            $stmt = $db->prepare("UPDATE $Web->components_tbl SET data = ? WHERE component_id = ? AND type = 'banner' ");
            $stmt->execute([$cards, $component_id]);
            $Component->update();
        } catch (Exception $e) {
            Errors::response_500("Error in changing status" . $e->getMessage());
        }

        $cards = $Component->data();
        $status = $cards[$key]->status;
        $status_text = "Active";
        $statusSvg = '<i class="fs-2 fas fa-eye"></i>';
        $badge = $status == "active" ?
            $Web->status_to_label("active", "success") :
            $Web->status_to_label("inactive", "danger");

        if ($status == "active") {
            $status_text = "Inactive";
            $statusSvg = '<i class="fs-2 fas fa-eye-slash"></i>';
        }

        $button = '<button data-component_id="' . $component_id . '" data-key="' . $key . '" data-action="changeBannerStatus" data-bs-toggle="tooltip" data-bs-original-title="' . $status_text . '" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">' . $statusSvg . '</button>';

        $output = new stdClass;
        $output->message = "Status has been changed";
        $output->button = $button;
        $output->badge = $badge;
        echo json_encode($output);
        break;

        // Banner End

        // Category Start


    case "create_new_category_collection":
        try {
            $get_new_index = Component::get_new_index();
            $new_category_name = Component::new_category_name();
            
            $columns = 8;
            $tab_columns = 6;
            $mobile_columns = 4;

            $stmt = $db->query("INSERT INTO $Web->components_tbl (`heading`,`data`,`card_index`,`type`,`columns`,`tab_columns`,`mobile_columns`) VALUES ('$new_category_name','[]','$get_new_index','category', '$columns', '$tab_columns', '$mobile_columns') ");

            $component_id = $db->lastInsertId();
           $Component = new Component($component_id);
            $card = $Component->single_category_collection_tbl();

            $output = new stdClass;
            $output->card = $card;
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in adding banner");
        }
        break;

    case "delete_category_collection":
        if (!$Web->is_isset("component_id")) Errors::response_404();
        $component_id = $Web->sanitize_text($_POST["component_id"]);

        try {
            if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
           $Component = new Component($component_id);
            if ($Component->type() !== "category") Errors::response("Invalid type");

            $stmt = $db->prepare("DELETE FROM $Web->components_tbl WHERE component_id = ? AND type = 'category' ");
            $stmt->execute([$component_id]);

            $output = new stdClass;
            $output->message = "Colection has been deleted";
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in deleting collection");
        }
        break;

    case "update_category_collection":
        if (!$Web->is_isset("component_id", "heading")) Errors::response_404();
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $heading = $Web->sanitize_text($_POST["heading"]);
        $columns = $Web->sanitize_text($_POST["columns"]);
        $tab_columns = $Web->sanitize_text($_POST["tab_columns"]);
        $mobile_columns = $Web->sanitize_text($_POST["mobile_columns"]);

        $Web->validate_post_input($columns, "number", "Columns", true);
        $Web->validate_post_input($tab_columns, "number", "Tab Columns", true);
        $Web->validate_post_input($mobile_columns, "number", "Mobile Columns", true);

        try {
            if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
           $Component = new Component($component_id);
            if ($Component->type() !== "category") Errors::response("Invalid type");
            $Web->validate_post_input($heading, "", "Heading", true);
            $Web->validate_post_length($heading, 100, "Maximum 100 characters are allowed");

            if (Component::is_category_name($heading, $component_id)) Errors::response("Duplicate heading not allowed");
            $stmt = $db->prepare("UPDATE $Web->components_tbl SET heading = ?, columns = ?, tab_columns = ?,mobile_columns = ?  WHERE component_id = ? AND type = 'category' ");
            $stmt->execute([$heading,$columns, $tab_columns, $mobile_columns, $component_id]);

            $Component->update();
            $heading = $Component->heading();

            $output = new stdClass;
            $output->heading = $heading;
            $output->message = "Heading has been update";
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in updating heading");
        }
        break;

    case "create_new_category":

        if (!$Web->is_isset("component_id", "image_id", "category_name", "status", "url", "event")) Errors::response("Invalid request");
        $image_id = $Web->sanitize_text($_POST["image_id"]);
        $category_name = $Web->sanitize_text($_POST["category_name"]);
        $status = $Web->sanitize_text($_POST["status"]);
        $url = $Web->sanitize_text($_POST["url"]);
        $event = $Web->sanitize_text($_POST["event"]);
        $component_id = $Web->sanitize_text($_POST["component_id"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        if ($Component->type() !== "category") Errors::response("Invalid type");

        if (!$Web->is_file_id($image_id)) Errors::response("File doesn't exist");
        if (!empty($url)) $Web->validate_post_input($url, "url", "Url", true);
        if ($status !== "active" && $status !== "inactive") Errors::response("Status is invalid");
        if ($event !== "create" && $event !== "update") Errors::response("Event is invalid");
        $Web->validate_post_input($category_name, "", "Category Name", true);
        $Web->validate_post_length($category_name, 100, "Maximum 100 characters are allowed in Category Name");
        $data = $Component->data();

        $output = new stdClass;
        try {

            switch ($event) {
                case "create":

                    $data[] = array(
                        "image_id" => $image_id,
                        "category_name" => $category_name,
                        "url" => $url,
                        "status" => $status
                    );
                    break;
                default:
                    if (!$Web->is_isset("key")) Errors::response("Key doesn't exist");
                    $key = $Web->sanitize_text($_POST["key"]);
                    if (!isset($data[$key])) Errors::response("Category doesn't exist");

                    $data[$key] = array(
                        "image_id" => $image_id,
                        "category_name" => $category_name,
                        "url" => $url,
                        "status" => $status
                    );
                    $Component->update();


                    break;
            }

            $data = json_encode($data);
            $stmt = $db->prepare("UPDATE $Web->components_tbl SET data = ? WHERE component_id = ? AND type = 'category' ");
            $stmt->execute([$data, $component_id]);
            $output->message = "Category has been updated";
        } catch (\Exception $e) {
            Errors::response_500("Error in category" . $e->getMessage());
        }

        $output->content = $Component->category_collection_tbl_content();
        echo json_encode($output);

        break;

    case "get_category_update_form":

        if (!$Web->is_isset("component_id", "key")) Errors::response("Invalid request");
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $key = $Web->sanitize_text($_POST["key"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        if ($Component->type() !== "category") Errors::response("Invalid type");
        $rows = $Component->data();
        if (!isset($rows[$key])) Errors::response("Category doesn't exist");
        $row = $rows[$key];

        $data = '<form novalidate class="need-validation">
            <input type="hidden" name="event" value="update">
            <input type="hidden" name="key" value="' . $key . '">
            <div class="fv-row mb-7">
                <label class="required form-label mb-2">Image</label>
                <div id="uploadCard" class="position-relative cursor-pointer justify-align-center mb-2 bg-light min-h-200px">
                    <div class="bottom-inherit image-upload-progress top-0">
                        <div class="progress-bar h-3px"></div>
                    </div>
                    <div id="innerContent">
                        <img src="' . $Web->get_file_src($row->image_id) . '" class="mh-100 img-fluid">
                    </div>
                </div>
                <input value="' . $row->image_id . '" autocomplete="off" class="sr-only" required name="image_id" value="">
                <div class="invalid-feedback">Please upload a image</div>
            </div>
            <div class="fv-row mb-7">
                                <label class="form-label mb-2">Category Name</label>
                                <input value="' . $row->category_name . '" required autocomplete="off" type="text" class="form-control form-control-solid" name="category_name" value="">
                                <div class="invalid-feedback">Category Name is required</div>
            </div>
            <div class="fv-row mb-7">
                <label class="form-label mb-2">Url</label>
                <input value="' . $row->url . '" autocomplete="off" type="text" class="form-control form-control-solid" name="url" value="">
            </div>
            <div class="fv-row mb-7">
                <label class="required fs-6 fw-bold form-label mb-2"> Status</label>
                <select value="' . $row->status . '" autocomplete="off" name="status" data-placeholder="Select" data-control="select2" data-hide-search="true" required="" value="" type="text" class="form-select form-select-solid">
                    <option value=""></option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
                <div class="invalid-feedback" >Status is required</div>
            </div>
            <div class="justify-right">
                <button type="submit" class="btn btn-primary">Update<span class="svg-icon svg-icon-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black"></rect>
                            <path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black"></path>
                        </svg>
                    </span></button>
            </div>
        </form>';

        $output = new stdClass;
        $output->data = $data;
        echo json_encode($output);

        break;

    case "delete_category_component":

        if (!$Web->is_isset("component_id", "key")) Errors::response("Invalid request");
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $key = $Web->sanitize_text($_POST["key"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        if ($Component->type() !== "category") Errors::response("Invalid type");
        $rows = $Component->data();
        if (!isset($rows[$key])) Errors::response("Category doesn't exist");

        unset($rows[$key]);

        $data = array_values($rows);

        try {

            $data = json_encode($data);

            $stmt = $db->prepare("UPDATE $Web->components_tbl SET data = ? WHERE component_id = ? AND type = 'category' ");
            $stmt->execute([$data, $component_id]);

            $output = new stdClass;
            $output->message = "Category has been deleted";
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in deleting category");
        }


        break;

    case "change_category_status":


        if (!$Web->is_isset("component_id", "key")) Errors::response("Invalid request");
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $key = $Web->sanitize_text($_POST["key"]);

        if (!Component::is_component_id($component_id)) Errors::response("Invalid id");
       $Component = new Component($component_id);
        if ($Component->type() !== "category") Errors::response("Invalid type");
        $rows = $Component->data();
        if (!isset($rows[$key])) Errors::response("Category doesn't exist");
        $row = $rows[$key];

        $status = $row->status;
        $status = $status == "active" ?  "inactive" : "active";
        $row->status = $status;

        try {
            $rows = json_encode($rows);
            $stmt = $db->prepare("UPDATE $Web->components_tbl SET data = ? WHERE component_id = ? AND type = 'category' ");
            $stmt->execute([$rows, $component_id]);
            $Component->update();
        } catch (Exception $e) {
            Errors::response_500("Error in changing status" . $e->getMessage());
        }

        $rows = $Component->data();
        $row = $rows[$key];
        $status = $row->status;
        $status_text = "Active";
        $statusSvg = '<i class="fs-2 fas fa-eye"></i>';
        $badge = $status == "active" ?
            $Web->status_to_label("active", "success") :
            $Web->status_to_label("inactive", "danger");

        if ($status == "active") {
            $status_text = "Inactive";
            $statusSvg = '<i class="fs-2 fas fa-eye-slash"></i>';
        }

        $button = '<button data-key="' . $key . '" data-component_id="' . $component_id . '" data-action="changeCategoryStatus" data-bs-toggle="tooltip" data-bs-original-title="' . $status_text . '" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">' . $statusSvg . '</button>';

        $output = new stdClass;
        $output->message = "Status has been changed";
        $output->button = $button;
        $output->badge = $badge;
        echo json_encode($output);

        break;

        // Category End

    default:
        Errors::response_404();
        break;
}
