<?php

use Ecommerce\Component;
use Ecommerce\Layout;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../../../db.php");
    }
    Errors::response_404();
}


if (!$Web->is_isset("case")) Errors::response_404();
$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();
if (!$Login->is_admin_loggedin()) Errors::force_admin_login();


switch ($case) {

    case "create_custom_page":

        if (!$Web->is_isset("name", "status", "layout_id", "event")) Errors::response_404();
        $name = $Web->sanitize_text($_POST["name"]);
        $status = $Web->sanitize_text($_POST["status"]);
        $layout_id = $Web->sanitize_text($_POST["layout_id"]);
        $event = $Web->sanitize_text($_POST["event"]);

        if ($event !== "create" && $event !== "update") Errors::response("Invalid event");
        if ($status !== "active" && $status !== "inactive") Errors::response("Invalid status");

        try {
            $output = new stdClass;

            switch ($event) {
                case "create":
                    $components = '[]';
                    if (Layout::is_page_id($name)) Errors::response("$name has already created");
                    $stmt = $db->prepare("INSERT INTO $Web->layouts_tbl (`page_id`,`components`,`created_date`, `status`) VALUES ( ?, ?, ?, ?) ");
                    $stmt->execute([$name, $components, $Web->current_time(), $status]);
                    $output->message = "Page has been created";
                    break;
                default:
                    if (Layout::is_page_id($name, $layout_id)) Errors::response("$name has already created");
                    $stmt = $db->prepare("UPDATE $Web->layouts_tbl SET page_id = ?, status = ? WHERE layout_id = ? ");
                    $stmt->execute([$name, $status, $layout_id]);
                    $output->message = "Page has been updated";
                    break;
            }
            $output->content = Layout::pages_tbl_except_home();
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in custom page" . $e->getMessage());
        }

        break;


    case "delete_custom_page":
        if (!$Web->is_isset("layout_id")) Errors::response_404();
        $layout_id = $Web->sanitize_text($_POST["layout_id"]);

        if (!Layout::is_layout_id($layout_id)) Errors::response("Page doesn't exist");

        try {
            $stmt = $db->prepare("DELETE FROM $Web->layouts_tbl WHERE layout_id = ?");
            $stmt->execute([$layout_id]);

            $output = new stdClass;
            $output->message = "Page has been deleted";
            $output->content = Layout::pages_tbl_except_home();
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in deleting page");
        }
        break;

    case "change_custom_page_status":
        if (!$Web->is_isset("layout_id")) Errors::response_404();
        $layout_id = $Web->sanitize_text($_POST["layout_id"]);

        if (!Layout::is_layout_id($layout_id)) Errors::response("Page doesn't exist");
        $Layout = new Layout($layout_id);
        $status = $Layout->status();
        $status = $status == "active" ? "inactive" : "active";

        try {
            $stmt = $db->prepare("UPDATE $Web->layouts_tbl SET status = ? WHERE layout_id = ?");
            $stmt->execute([$status, $layout_id]);
            $Layout->update();

            $output = new stdClass;
            $output->message = "Status has been changed";
            $output->badge = $Layout->status_label();
            $output->buttons = $Layout->tbl_actions_btn();
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in changing status");
        }
        break;

    case "get_layout_components":
        if (!$Web->is_isset("component")) Errors::response_404();
        $component = $Web->sanitize_text($_POST["component"]);

        if (!in_array($component, ["slider", "manual_slider", "category", "product_slider", "banner"])) Errors::response_404();

        try {
            $stmt = $db->prepare("SELECT * FROM $Web->components_tbl WHERE type = ? ");
            $stmt->execute([$component]);
            $rows = $stmt->fetchAll();

            $content = '<div show-content="0" class="p-4 hover align-center cursor-pointer category-list border-bottom">
            <span class="svg-icon svg-icon-muted svg-icon-2hx">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                <rect opacity="0.5" x="6" y="11" width="13" height="2" rx="1" fill="black"></rect>
                <path d="M8.56569 11.4343L12.75 7.25C13.1642 6.83579 13.1642 6.16421 12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75L5.70711 11.2929C5.31658 11.6834 5.31658 12.3166 5.70711 12.7071L11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25C13.1642 17.8358 13.1642 17.1642 12.75 16.75L8.56569 12.5657C8.25327 12.2533 8.25327 11.7467 8.56569 11.4343Z" fill="black"></path>
                </svg>
            </span>
            <div class="fs-4 ms-4 d-flex fw-bold">Choose</div>
         </div>';

            foreach ($rows as $row) {
                $component_id = $row->component_id;
                $Component = new Component($component_id);
                $heading = $Component->heading();

                $content .= '<div data-component="" data-component_id="' . $component_id . '" class="p-4 hover cursor-pointer category-list border-bottom align-justify-between">
               <div class="fs-4 d-flex fw-bold">' . $heading . '</div>
               <span class="svg-icon svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
               <path opacity="0.5" d="M12.8956 13.4982L10.7949 11.2651C10.2697 10.7068 9.38251 10.7068 8.85731 11.2651C8.37559 11.7772 8.37559 12.5757 8.85731 13.0878L12.7499 17.2257C13.1448 17.6455 13.8118 17.6455 14.2066 17.2257L21.1427 9.85252C21.6244 9.34044 21.6244 8.54191 21.1427 8.02984C20.6175 7.47154 19.7303 7.47154 19.2051 8.02984L14.061 13.4982C13.7451 13.834 13.2115 13.834 12.8956 13.4982Z" fill="black"></path>
               <path d="M7.89557 13.4982L5.79487 11.2651C5.26967 10.7068 4.38251 10.7068 3.85731 11.2651C3.37559 11.7772 3.37559 12.5757 3.85731 13.0878L7.74989 17.2257C8.14476 17.6455 8.81176 17.6455 9.20663 17.2257L16.1427 9.85252C16.6244 9.34044 16.6244 8.54191 16.1427 8.02984C15.6175 7.47154 14.7303 7.47154 14.2051 8.02984L9.06096 13.4982C8.74506 13.834 8.21146 13.834 7.89557 13.4982Z" fill="black"></path>
               </svg>
                   </span>
           </div>';
            }


            $output = new stdClass;
            $output->content = $content;
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in layouts");
        }

        break;

    case "add_layout_component":

        if (!$Web->is_isset("component_id", "layout_id")) Errors::response_404();
        $component_id = $Web->sanitize_text($_POST["component_id"]);
        $layout_id = $Web->sanitize_text($_POST["layout_id"]);

        if (!Component::is_component_id($component_id)) Errors::response("Component doesn't exist");

        $Component = new Component($component_id);
        $Layout = new Layout($layout_id);
        $components = $Layout->components();
        $components[] = $component_id;

        try {
            $components = json_encode($components);

            $stmt = $db->prepare("UPDATE $Web->layouts_tbl SET components = ? WHERE layout_id = ? ");
            $stmt->execute([$components, $layout_id]);

            $output = new stdClass;
            $output->message = "Component has been added";
            $output->layouts = $Layout->components_layout();
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in adding component");
        }

        break;

    case "update_components_order":

        if (!$Web->is_isset("layout_id", "index")) Errors::response_404();
        $layout_id = $Web->sanitize_text($_POST["layout_id"]);
        $index = $Web->sanitize_text($_POST["index"]);

        if(!Layout::is_layout_id($layout_id)) Errors::response("Page doesn't exist");
        $Layout = new Layout($layout_id);

        if (!is_array($index)) Errors::response("Invalid index requested");
        foreach ($index as $key) {
            if (!Component::is_component_id($key)) Errors::response("Some od the components don't exist");
        }

        $components = json_encode($index);

        try {
            $stmt = $db->prepare("UPDATE $Web->layouts_tbl SET components = ? WHERE layout_id = ? ");
            $stmt->execute([$components, $layout_id]);

            $output = new stdClass;
            $output->message = "Orders has been updated";
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in updating order");
        }
        break;

    case "delete_layout_component":

        if (!$Web->is_isset("layout_id", "component_id")) Errors::response_404();
        $layout_id = $Web->sanitize_text($_POST["layout_id"]);
        $key = $Web->sanitize_text($_POST["component_id"]);

        if (!Layout::is_layout_id($layout_id)) Errors::response("Component doesn't exist");

        $Layout = new Layout($layout_id);
        $components = $Layout->components();

        if (!isset($components[$key])) Errors::response("Component doesn't exist");
        unset($components[$key]);
        $components = array_values($components);
        try {
            $components = json_encode($components);
            $stmt = $db->prepare("UPDATE $Web->layouts_tbl SET components = ? WHERE layout_id = ? ");
            $stmt->execute([$components, $layout_id]);

            $output = new stdClass;
            $output->message = "Component has been deleted";
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in delete component");
        }

        break;

    default:
        Errors::response_404();
        break;
}
