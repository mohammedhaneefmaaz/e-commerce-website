<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../../db.php");
    }
    Errors::response_404();
}

if (!$Web->is_isset("case")) Errors::response_404();

$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();

if (!$Login->is_admin_loggedin()) Errors::force_admin_login();



switch ($case) {

    case "reset_basic_setting":

        try {
            $stmt = $db->query("UPDATE $Web->setting_tbl SET web_name = NULL, currency = NULL,date = NULL,currency_position = NULL,primary_color = NULL,timezone = NULL ");
        } catch (Exception $d) {
            Errors::response("An error has been occured in updating basic settings" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Basic settings has been updated";
        echo json_encode($output);

        break;

    case "update_basic_setting":
        if (!$Web->is_isset("web_name", "currency", "currency_position", "timezone", "primary_color")) Errors::response_404();
        $web_name = $Web->sanitize_text($_POST["web_name"]);
        $currency = $Web->sanitize_text($_POST["currency"]);
        $currency_position = $Web->sanitize_text($_POST["currency_position"]);
        $timezone = $Web->sanitize_text($_POST["timezone"]);
        $primary_color = $Web->sanitize_text($_POST["primary_color"]);

        $primary_color = $Web->hex_to_rgb($primary_color);


        if ($currency_position != "prefix" && $currency_position != "suffix") Errors::response("Invalid Currency Position");

        try {
            $stmt = $db->query("SELECT * FROM $Web->setting_tbl ");
            if (!$stmt->rowCount()) {
                $stmt = $db->prepare("INSERT INTO $Web->setting_tbl (`web_name`, `currency`, `currency_position`, `primary_color`,`timezone`)
                 VALUES (?,?,?,?,?) ");
                $stmt->execute([$web_name, $currency, $currency_position, $primary_color, $timezone]);
            } else {
                $stmt = $db->prepare("UPDATE $Web->setting_tbl SET web_name = ?, currency = ?,currency_position = ?,primary_color = ?,timezone = ? ");
                $stmt->execute([$web_name, $currency, $currency_position, $primary_color, $timezone]);
            }
        } catch (Exception $e) {
            Errors::response_500("An error has been occured in updating basic settings" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Basic settings has been updated";
        echo json_encode($output);
        break;

    case "update_email_setting":
        if (!$Web->is_isset("mail_encryption", "mail_host", "mail_port", "mail_username", "mail_password"))  Errors::response_404();

        $mail_encryption = $Web->sanitize_text($_POST["mail_encryption"]);
        $mail_host = $Web->sanitize_text($_POST["mail_host"]);
        $mail_port = $Web->sanitize_text($_POST["mail_port"]);
        $mail_username = $Web->sanitize_text($_POST["mail_username"]);
        $mail_password = $Web->sanitize_text($_POST["mail_password"]);

        try {
            $stmt = $db->query("SELECT * FROM $Web->setting_tbl ");
            if (!$stmt->rowCount()) {
                $stmt = $db->prepare("INSERT INTO $Web->setting_tbl (`mail_encryption`, `mail_host`, `mail_username`, `mail_port`, `mail_password`) VALUES (?,?,?,?,?) ");
                $stmt->execute([$mail_encryption, $mail_host, $mail_username, $mail_port, $mail_password]);
            } else {
                $stmt = $db->prepare("UPDATE $Web->setting_tbl SET `mail_encryption` = ?,`mail_host` = ?,`mail_port` = ?,`mail_username` = ?,`mail_password` = ? ");
                $stmt->execute([$mail_encryption, $mail_host, $mail_port, $mail_username, $mail_password]);
            }
        } catch (Exception $e) {
            Errors::response_500("An error has been occured in updating email settings" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Email settings has been updated";
        echo json_encode($output);
        break;

    case "change_site_logo":

        if (!$Web->is_isset("panel", "type")) Errors::response_404();
        $panel = $Web->sanitize_text($_POST["panel"]);
        $type = $Web->sanitize_text($_POST["type"]);
        if ($type !== "logo" && $type !== "favicon") Errors::response("Invalid details received");

        $FileUpload = new FileUpload("image");
        $upload = $FileUpload->upload();
        if ($upload->type == "error") Errors::response($upload->message);

        $stmt = $db->query("SELECT * FROM $Web->setting_tbl ");

        $logos = $Web->logos();
        switch ($panel) {
            case "user":
                if ($type == "logo") $logos->logo_id = $upload->id;
                else $logos->favicon_id = $upload->id;
                break;
            case "seller":
                if ($type == "logo") $logos->seller_logo_id = $upload->id;
                else $logos->seller_favicon_id = $upload->id;
                break;
            case "admin":
                if ($type == "logo") $logos->admin_logo_id = $upload->id;
                else $logos->admin_favicon_id = $upload->id;
                break;
        }

        $logos = json_encode($logos);

        try {
            $stmt = $db->query("SELECT * FROM $Web->setting_tbl ");
            if (!$stmt->rowCount()) {
                $stmt = $db->prepare("INSERT INTO $Web->setting_tbl (`web_logos`) VALUES (?) ");
                $stmt->execute([$logos]);
            } else {
                $stmt = $db->prepare("UPDATE $Web->setting_tbl SET web_logos = ? ");
                $stmt->execute([$logos]);
            }
        } catch (Exception $e) {
            Errors::response("An error has been occured in updating logo" . $e->getMessage());
        }

        $output = new stdClass;
        $output->url = $upload->url;
        $output->message = "Logo has been updated";
        echo json_encode($output);
        break;

    case "send_test_email":
        if (!$Web->is_isset("test_email")) Errors::response_404();
        $test_email = $Web->sanitize_text($_POST["test_email"]);
        $Web->validate_post_input($test_email, "email", "Email", true);
        $send = $Login->send_test_email($test_email);
        if (!$send) Errors::response("Error in sending email");
        $output = new stdClass;
        $output->message = "Test email has been sent";
        echo json_encode($output);
        break;

    default:
        Errors::response_404();
        break;
}
