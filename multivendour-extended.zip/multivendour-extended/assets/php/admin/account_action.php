<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../../db.php");
    }
    Errors::response_404();
}

if (!$Web->is_isset("case")) Errors::response_404();

$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();

if ($Login->is_admin_loggedin()) Errors::response("You are already Loggedin");

switch ($case) {

    case  "login":


        if (!$Web->is_isset("email", "password", "keeplogged"))  Errors::response("Invalid request");

        $user_email = $Web->sanitize_text($_POST["email"]);
        $password = $Web->sanitize_text($_POST["password"]);
        $keeploggedin = $Web->sanitize_text($_POST["keeplogged"]);

        $Web->validate_post_input($user_email, "email", "Email", true);
        $Web->validate_post_input($password, "", "Password", true);

        if (!User::is_admin_email($user_email)) Errors::response("No account is associated with this email");
        $user_id = User::user_id($user_email);
        $user_data = new User($user_id);

        $pass_decode = password_verify($password, $user_data->password());
        if (!$pass_decode)  Errors::response("Email and Password are invalid");
        if ($user_data->status() != "active")  Errors::response("Your account has been blocked");


        $query = $Login->insert_user_login_session($user_id, $keeploggedin, "admin");
        if (!$query)  Errors::response("Error in Login");

        $output = new stdClass();
        $output->message = "Login Successfull";
        $output->url = $Web->admin_url();
        echo json_encode($output);

        break;

    default:
        Errors::response_404();
        break;
}
