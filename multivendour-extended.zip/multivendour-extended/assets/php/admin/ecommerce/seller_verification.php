<?php


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../../../db.php");
    }
    Errors::response_404();
}

use Ecommerce\SellerVerification;

if (!$Web->is_isset("case")) Errors::response_404();
$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();
if (!$Login->is_admin_loggedin()) Errors::force_admin_login();


switch ($case) {

    case "approve_verification":
        if (!$Web->is_isset("verification_id", "approve")) Errors::response_404();
        $verification_id = $Web->sanitize_text($_POST["verification_id"]);
        if (!SellerVerification::is_verification_id($verification_id)) Errors::response_404();
        $Verification = new SellerVerification($verification_id);
        if ($Verification->status() !== "pending") Errors::response("Invalid Request");

        try {

            $db->beginTransaction();

            $stmt = $db->prepare("UPDATE $Web->ecommerce_seller_verification_tbl SET status = 'verified',  action_date = ? WHERE verification_id = ? ");
            $stmt->execute([$Web->current_time(), $verification_id]);

            $stmt = $db->prepare("UPDATE $Web->ecommerce_seller_users_tbl SET status = 'verified' WHERE user_id = ? ");
            $stmt->execute([$LogSeller->user_id]);

            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in approving verification" . $e->getMessage());
        }


        $output = new stdClass;
        $output->message = "Verification has been approved";
        $output->url = $Web->admin_url() . '/seller-verification/pending';
        echo json_encode($output);
        break;

    case "reject_verification":
        if (!$Web->is_isset("verification_id", "reject_reason")) Errors::response_404();
        $verification_id = $Web->sanitize_text($_POST["verification_id"]);
        $reject_reason = $Web->sanitize_text($_POST["reject_reason"]);
        if (strlen(utf8_decode($_POST["reject_reason"])) > 500) Errors::response("Maximum reject reason length is 500 ");

        if (!SellerVerification::is_verification_id($verification_id)) Errors::response_404();
        $Verification = new SellerVerification($verification_id);
        if ($Verification->status() !== "pending") Errors::response("Invalid Request");
       
        try {

            $db->beginTransaction();

            $stmt = $db->prepare("UPDATE $Web->ecommerce_seller_verification_tbl SET status = 'rejected',rejected_reason = ?,  action_date = ? WHERE verification_id = ? ");
            $stmt->execute([$reject_reason, $Web->current_time(), $verification_id]);

            $stmt = $db->prepare("UPDATE $Web->ecommerce_seller_users_tbl SET status = 'rejected',status_reason = ? WHERE user_id = ? ");
            $stmt->execute([$reject_reason, $LogSeller->user_id]);

            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in rejecting verification" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Verification has been rejected";
        $output->url = $Web->admin_url() . '/seller-verification/pending';
        echo json_encode($output);
        break;
}
