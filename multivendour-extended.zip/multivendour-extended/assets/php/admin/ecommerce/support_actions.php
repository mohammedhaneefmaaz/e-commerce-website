<?php


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../../../db.php");
    }
    Errors::response_404();
}

if (!isset($_POST["case"]))  Errors::response_404();

$case = $_POST["case"];
if ($Web->is_empty($case)) Errors::response_404();

if (!$Login->is_admin_loggedin()) Errors::force_admin_login();

use Ecommerce\Ticket;

switch ($case) {


    case "close_ticket":
        if (!$Web->is_isset("ticket_id")) Errors::response_404();
        $ticket_id = $Web->sanitize_text($_POST["ticket_id"]);
        if (!Ticket::is_ticket_id($ticket_id)) Errors::response_404();
        $Ticket = new Ticket($ticket_id);
        if ($Ticket->status() == "closed") Errors::response("Ticket has been closed already");

        try {
            $stmt = $db->prepare(" UPDATE $Web->support_tickets_tbl SET status = 'closed', closed_on = ?, closed_by = ? WHERE ticket_id = ? ");
            $stmt->execute([$Web->current_time(), $LogAdmin->user_id, $ticket_id]);
        } catch (\Exception $e) {
            Errors::response("Error in closing ticket");
        }
        $output = new stdClass;
        $output->message = "Ticket has been closed";
        echo json_encode($output);
        break;

    case "add_reply":

        if (!$Web->is_isset("ticket_id")) Errors::response_404();
        $ticket_id = $Web->sanitize_text($_POST["ticket_id"]);
        if (!Ticket::is_ticket_id($ticket_id)) Errors::response_404();
        $Ticket = new Ticket($ticket_id);
        if ($Ticket->status() == "closed") Errors::response("You can't add reply since the ticket has been closed");

        if (!$Web->is_isset("message", "files")) Errors::response("Invalid request");
        $message = $Web->sanitize_text($_POST["message"]);
        $files = $_POST["files"];
        if (!empty($files)) $files = json_decode($files);
        $Web->validate_post_length($_POST["message"], 3000, "Maximum Message length is 3000 ");

        if (!is_array($files)) Errors::response("Invalid details requested");
        if (count($files) > 5) Errors::response("Maximum 5 files are allowed");

        $current_time = $Web->current_time();
        $files = json_encode($files);

        try {
            $db->beginTransaction();

            $stmt = $db->prepare(" INSERT INTO $Web->support_ticket_messages_tbl (`ticket_id`, `replier`, `message`, `date`, `files`) VALUES (?,?,?,?,? ) ");
            $stmt->execute([$ticket_id, $LogAdmin->user_id, $message, $current_time, $files]);

            $stmt = $db->prepare(" UPDATE $Web->support_tickets_tbl SET status = 'active', last_reply_on = ? WHERE ticket_id = ? ");
            $stmt->execute([$current_time, $ticket_id]);

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response("Error in replying");
        }

        $output = new stdClass;
        $output->message = "Reply has been added";
        echo json_encode($output);


        break;
}
