<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../../../db.php");
    }
    Errors::response_404();
}

use Ecommerce\Select;

if (!$Web->is_isset("case")) Errors::response_404();
$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();
if (!$Login->is_admin_loggedin()) Errors::force_admin_login();

switch ($case) {

    case "get_select_options":
        if (!$Web->is_isset("select_id")) Errors::response("Invalid Request");
        $select_id = $Web->sanitize_text($_POST["select_id"]);
        if (!Select::is_select_id($select_id)) Errors::response("Select doesn't exist");

        $Select = new Select($select_id);
        $data = '<div class="fv-row mb-7">
                                <label class="fs-6 fw-bold form-label mb-2">' . $Select->heading() . '</label>
                                ' . $Select->select_preview(' data-hide-search="true" ') . '
                 </div>';

        $output = new stdClass;
        $output->preview = $data;
        echo json_encode($output);

        break;

    case "fetch_select":
        if (!$Web->is_isset("select_id")) Errors::response("Invalid Request");
        $select_id = $Web->sanitize_text($_POST["select_id"]);
        if (!Select::is_select_id($select_id)) Errors::response("Select doesn't exist");

        $Select = new Select($select_id);

        $output = new stdClass;
        $output->data = $Select->select_edit_modal_form();
        echo json_encode($output);

        break;

    case "delete_select":
        if (!$Web->is_isset("select_id")) Errors::response("Invalid Request");
        $select_id = $Web->sanitize_text($_POST["select_id"]);
        if (!Select::is_select_id($select_id)) Errors::response("Select doesn't exist");
        $Select = new Select($select_id);
        if ($Select->is_in_use()) Errors::response("Sorry! Select can't be deleted because it is in use");

        try {
            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_select_tbl WHERE select_id = ? ");
            $stmt->execute([$select_id]);
        } catch (Exception $e) {
            Errors::response_500("Error in deleting select" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Select has been deleted";
        echo json_encode($output);

        break;

    case "create_select":
        if (!$Web->is_isset("select_heading", "event", "data")) Errors::response("Invalid Request");
        $select_heading = $Web->sanitize_text($_POST["select_heading"]);
        $event = $Web->sanitize_text($_POST["event"]);
        $options = $Web->sanitize_text($_POST["data"]);
        if (!is_array($options)) Errors::response("Invalid details requested");
        if (empty($options)) Errors::response("Add some select options");
        $options = json_encode($options);

        if ($event != "create" && $event != "update") Errors::response("Invalid event");

        $output =  new stdClass;

        try {
            if ($event == "create") {
                if (Select::is_heading($select_heading)) throw new CsException("Select id has been already in use");
                $stmt = $db->prepare("INSERT INTO $Web->ecommerce_select_tbl (`select_heading`, `options`,`date_created`,`last_modified`) VALUES (?,?,?,?) ");
                $stmt->execute([$select_heading, $options, $Web->current_time(), $Web->current_time()]);
                $output->message = "Select has been created";
            } else {
                if (!$Web->is_isset("select_id"))  throw new CsException("Invalid Request");
                $select_id = $Web->sanitize_text($_POST["select_id"]);
                if (!Select::is_select_id($select_id)) throw new CsException("Select doesn't exist");
                $stmt = $db->prepare("UPDATE $Web->ecommerce_select_tbl SET options = ?, last_modified = ? WHERE select_id = ? ");
                $stmt->execute([$options, $Web->current_time(), $select_id]);
                $output->message = "Select has been update";
            }
            $output->data = Select::selects_tbl();
            echo json_encode($output);
        } catch (CsException $e) {
            Errors::response("Error in creating select" . $e->getError());
        } catch (Exception $e) {
            Errors::response_500("Error in creating select" . $e->getMessage());
        }



        break;

    default:
        Errors::response_404();
        break;
}
