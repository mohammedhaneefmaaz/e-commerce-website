<?php


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../../../db.php");
    }
    Errors::response_404();
}

if (!isset($_POST["case"]))  Errors::response_404();

$case = $_POST["case"];
if ($Web->is_empty($case)) Errors::response_404();

if (!$Login->is_admin_loggedin()) Errors::force_admin_login();

use Ecommerce\Courier;

switch ($case) {

    case "delete_courier":
        if (!$Web->is_isset("courier_id")) Errors::response("Invalid Request");
        $courier_id = $Web->sanitize_text($_POST["courier_id"]);
        if (!Courier::is_courier_id($courier_id)) Errors::response("Courier doesn't exist");
        $C = new Courier($courier_id);
        if ($C->status() !== "active") Errors::response("Courier doesn't exist");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_courier_tbl SET status = 'deleted' WHERE courier_id = ? ");
            $stmt->execute([$courier_id]);
        } catch (Exception $e) {
            Errors::response_500("Error in deleting courier" . $e->getMessage());
        }

        $output = new stdClass;
        $output->data = $C->tbl();
        $output->message = "Courier has been deleted";
        echo json_encode($output);
        break;

    case "edit_courier":
        if (!$Web->is_isset("courier_id", "name", "url")) Errors::response("Invalid Request");
        $name = $Web->sanitize_text($_POST["name"]);
        $url = $Web->sanitize_text($_POST["url"]);
        $courier_id = $Web->sanitize_text($_POST["courier_id"]);

        if (!Courier::is_courier_id($courier_id)) Errors::response("Courier doesn't exist");
        $C = new Courier($courier_id);
        if ($C->status() !== "active") Errors::response("Courier doesn't exist");

        $Web->validate_post_input($name, "", "Courier Name", true);
        $Web->validate_post_input($url, "url", "Courier Url", true);

        $Web->validate_post_length($_POST["name"], 100, "Maximum Name length is 100 ");
        $Web->validate_post_length($_POST["url"], 1000, "Maximum Url length is 1000 ");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_courier_tbl SET name = ?, url = ? WHERE courier_id = ? ");
            $stmt->execute([$name, $url, $courier_id]);
        } catch (Exception $e) {
            Errors::response_500("Error in updating courier" . $e->getMessage());
        }

        $Courier = new Courier($courier_id);

        $output = new stdClass;
        $output->message = "Courier has been edited";
        $output->data = $Courier->tbl();
        echo json_encode($output);

        break;

    case "create_courier":
        if (!$Web->is_isset("name", "url")) Errors::response("Invalid Request");
        $name = $Web->sanitize_text($_POST["name"]);
        $url = $Web->sanitize_text($_POST["url"]);

        $Web->validate_post_input($name, "", "Courier Name", true);
        $Web->validate_post_input($url, "url", "Courier Url", true);

        $status = "active";
        try {
            $stmt = $db->prepare("INSERT INTO $Web->ecommerce_courier_tbl (`name`, `url`, `status`,`date`) VALUES (?,?,?,?) ");
            $stmt->execute([$name, $url, $status, $Web->current_time()]);
        } catch (Exception $e) {
            Errors::response_500("Error in creating courier" . $e->getMessage());
        }

        $courier_id = $db->lastInsertId();
        $Courier = new Courier($courier_id);

        $output = new stdClass;
        $output->message = "Courier has been created";
        $output->data = $Courier->tbl();
        echo json_encode($output);

        break;
}
