<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../../../db.php");
    }
    Errors::response_404();
}

use Ecommerce\Listing;
use Ecommerce\QC;

if (!$Web->is_isset("case")) Errors::response_404();
$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();
if (!$Login->is_admin_loggedin()) Errors::force_admin_login();


switch ($case) {

    case "reject_qc":
        if (!$Web->is_isset("reject_reason", "qc_id", "error_portions")) Errors::response("Invalid Request");
        $reject_reason = $Web->sanitize_text($_POST["reject_reason"]);
        $qc_id = $Web->sanitize_text($_POST["qc_id"]);
        $error_portions = $_POST["error_portions"];

        if (!QC::is_qc_id($qc_id)) Errors::response("Product is no more available in qc");
        $Q = new QC($qc_id);
        if ($Q->status() !== "pending") Errors::response("Product has already processed from qc");
        if (!is_array($error_portions)) Errors::response("Invalid details requested");
        if (empty($error_portions)) Errors::response("Please specify atleast a detail");

        $listing_id = $Q->listing_id();
        $variation_id = $Q->variation_id();
        $svariation_id = $Q->svariation_id();

        $error_portions = json_encode($error_portions);

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_qc_tbl SET status = 'rejected',error_portions = ?, reject_reason = ?,date_processed = ? WHERE qc_id = ? ");

            $stmt->execute([$error_portions, $reject_reason, $Web->current_time(), $qc_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in rejecting listing" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Product has been rejected";
        $output->url = $Q->get_next_url($qc_id);
        echo json_encode($output);
        break;

    case "approve_qc":
        if (!$Web->is_isset("qc_id")) Errors::response("Invalid Request");
        $qc_id = $Web->sanitize_text($_POST["qc_id"]);
        if (!QC::is_qc_id($qc_id)) Errors::response("Product is no more available in qc");
        $Q = new QC($qc_id);
        if ($Q->status() !== "pending") Errors::response("Product has already processed from qc ");

        $listing_id = $Q->listing_id();
        $Listing = new Listing($listing_id);
        $variation_id = $Q->variation_id();
        $svariation_id = $Q->svariation_id();

        $category_id = $Listing->category_id();

        try {

            $db->beginTransaction();

            if (!$Listing->is_listing_live()) {
                $stmt = $db->prepare("INSERT INTO $Web->ecommerce_products_tbl (`listing_id`, `user_id`, `category_id`) 
                VALUES (:listing_id,:user_id,:category_id) ");
                $stmt->execute([
                    ":listing_id" => $listing_id,
                    ":user_id" => $LogSeller->user_id,
                    ":category_id" => $category_id
                ]);
                $product_id = $db->lastInsertId();
            } else {
                $product_id = $Listing->live_product_id();
            }


            $row = $Listing->vrow($variation_id, $svariation_id);


            $variation_value = $row->variation_value;
            $svariation_value = $row->svariation_value;
            $variation_data = $row->variation_data;
            $svariation_data = $row->svariation_data;
            $details = $row->details;
            $images = $row->images;
            $price = $row->price;
            $sku_id = $row->sku_id;
            $mrp = $row->mrp;
            $stock = $row->stock;
            $low_stock_warning = $row->low_stock_warning;
            $product_name = $row->product_name;
            $minimum_order = $row->minimum_order;
            $maximum_order = $row->maximum_order;
            $cod_status = $row->cod_status;
            $status = $row->status;
            $return_policy = $row->return_policy;
            $return_policy_days = $row->return_policy_days;
            $return_policy_tc = $row->return_policy_tc;
            $description = $row->description;
            $tags = $row->tags;
            $highlights = $row->highlights;
            $date_created = $Web->current_time();
            $last_modified = $Web->current_time();


            $sql = "INSERT INTO `$Web->ecommerce_variations_tbl` (`user_id`, `product_id`, `variation_id`, `svariation_id`, `variation_value`, `svariation_value`, `variation_data`, `svariation_data`, `details`, `images`, `price`, `mrp`, `stock`,`low_stock_warning`, `sku_id`,`product_name`, `minimum_order`, `maximum_order`,`cod_status`,`status`,`return_policy`, `return_policy_days`, `return_policy_tc` ,`description`,`highlights`,`date_created`, `last_modified`, `tags` ) VALUES (:user_id,:product_id,:variation_id,:svariation_id,:variation_value,:svariation_value,:variation_data,:svariation_data,:details,:images,:price,:mrp,:stock,:low_stock_warning,:sku_id,:product_name,:minimum_order,:maximum_order,:cod_status,:status,:return_policy,:return_policy_days,:return_policy_tc,:description,:highlights,:date_created,:last_modified, :tags)";

            $sql = $Web->db()->prepare($sql);
            $sql->execute([
                ":user_id" => $LogSeller->user_id,
                ":product_id" => $product_id,
                ":variation_id" => $variation_id,
                ":svariation_id" => $svariation_id,
                ":variation_value" => $variation_value,
                ":svariation_value" => $svariation_value,
                ":variation_data" => $variation_data,
                ":svariation_data" => $svariation_data,
                ":details" => $details,
                ":images" => $images,
                ":price" => $price,
                ":mrp" => $mrp,
                ":stock" => $stock,
                ":low_stock_warning" => $low_stock_warning,
                ":sku_id" => $sku_id,
                ":product_name" => $product_name,
                ":minimum_order" => $minimum_order,
                ":maximum_order" => $maximum_order,
                ":cod_status" => $cod_status,
                ":status" => $status,
                ":return_policy" => $return_policy,
                ":return_policy_days" => $return_policy_days,
                ":return_policy_tc" => $return_policy_tc,
                ":description" => $description,
                ":tags" => $tags,
                ":highlights" => $highlights,
                ":date_created" => $date_created,
                ":last_modified" => $last_modified
            ]);


            $stmt = $db->prepare("UPDATE $Web->ecommerce_qc_tbl SET status = 'approved',date_processed = ? WHERE qc_id =  ? ");
            $stmt->execute([$Web->current_time(), $qc_id]);

            $stmt = $db->prepare("UPDATE $Web->ecommerce_listing_variations_tbl SET is_draft = 'no' WHERE listing_id = ? AND variation_id = ? AND svariation_id = ?  ");
            $stmt->execute([$listing_id, $variation_id, $svariation_id]);

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in approving listing" . $e->getMessage());
        }


        $output = new stdClass;
        $output->message = "Product has been approved";
        $output->url = $Q->get_next_url($qc_id);
        echo json_encode($output);
        break;

    default:
        Errors::response_404();
        break;
}
