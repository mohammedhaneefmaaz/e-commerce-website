<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../../../db.php");
    }
    Errors::response_404();
}

use Ecommerce\Category as Category;
use Ecommerce\Select;

if (!$Web->is_isset("case")) Errors::response_404();
$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();
if (!$Login->is_admin_loggedin()) Errors::force_admin_login();


switch ($case) {

    case "fetch_details":
        if (!$Web->is_isset("category_id")) Errors::response("Invalid Request");
        $category_id = $Web->sanitize_text($_POST["category_id"]);
        if (!Category::is_category_id($category_id)) Errors::response("Category doesn't exist");
        $E = new Category($category_id);
        if (!$E->is_last_category()) Errors::response("Can't add details having child");
        if ($E->is_rejected()) Errors::response("Sorry, The category has been deleted");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_category_tbl SET has_details = 'yes' WHERE category_id = ?  ");
            $stmt->execute([$category_id]);
        } catch (Exception $e) {
            Errors::response_500("Error in details" . $e->getMessage());
        }

        $output = new stdClass;
        $output->card = $E->details_card();
        $output->data = $E->data();
        echo json_encode($output);

        break;

    case "verify_category":
        if (!$Web->is_isset("category_id", "data")) Errors::response("Invalid Request");
        $category_id = $Web->sanitize_text($_POST["category_id"]);
        if (!Category::is_category_id($category_id)) Errors::response("Category doesn't exist");
        $data = $_POST["data"];
        $data = json_decode($data, true);
        $Category = new Category($category_id);
        if ($Category->is_rejected()) Errors::response("Sorry, The category has been deleted");
        if (!$Category->is_last_category()) Errors::response("Invalid Request");

        if (!isset($data["images"], $data["variations"], $data["details"], $data["deldetails"])) Errors::response("Invalid details requested");

        $images = $data["images"];
        $variations = $data["variations"];
        $details = $data["details"];
        $deldetails = $data["deldetails"];

        // Images
        if (!is_array($images)) Errors::response("Invalid image details");
        if (count($images) < 4) Errors::response("4 Images are mandatory");
        if (count($images) > 8) Errors::response("Maximum 8 images are allowed");
        $images = json_encode($images);

        // Details
        if (!is_array($details)) Errors::response("Invalid details data requested");
        if (count($details) < 3) Errors::response("Minimum 3 product details are required");

        //Deleted Details
        if (!is_array($deldetails)) Errors::response("Invalid deleted details requested");

        // variations
        if (!is_array($variations)) Errors::response("Invalid variation data");
        if (count($variations) > 2) Errors::response("Maximum 2 variation types are allowed");


        try {
            $db->beginTransaction();

            // Details
            foreach ($details as $detail_id => $detailsData) {
                if (!isset($detailsData["mandatory"], $detailsData["option_text"], $detailsData["option_type"], $detailsData["select_id"], $detailsData["filter"])) Errors::response("Invalid details requested in details section");

                $mandatory = $Web->sanitize_text($detailsData["mandatory"]);
                $option_text = $Web->sanitize_text($detailsData["option_text"]);
                $option_type = $Web->sanitize_text($detailsData["option_type"]);
                $select_id = $Web->sanitize_text($detailsData["select_id"]);
                $filter = $Web->sanitize_text($detailsData["filter"]);

                if ($mandatory != "yes" && $mandatory != "no") throw new CsException("Invalid Mandatory in details section");
                if ($filter != "yes" && $filter != "no") throw new CsException("Invalid Filter in details section");
                if ($option_type != "select" && $option_type != "input") throw new CsException("Invalid Option Type in details section");
                $Web->validate_post_input($option_text, "", "Option Text in details section", true);

                $event = $Category->is_detail_id($detail_id) ? "update" : "create";
                switch ($event) {
                    case "create";

                        if ($option_type === "select") {
                            $Web->validate_post_input($select_id, "", "Select Id", true);
                            if ($select_id == "custom") {
                                if (!isset($detailsData["selectOptions"], $detailsData["custom_select_id"])) throw new CsException("Invalid details requested in details section");
                                $selectOptions = $Web->sanitize_text($detailsData["selectOptions"]);
                                if (!is_array($selectOptions)) throw new CsException("Invalid details requested in details section");
                                if (empty($selectOptions)) throw new CsException("Add some select options in details section");
                                $select_id = Select::create_temporary_select($selectOptions);
                                $details[$detail_id]["custom_select_id"] = $select_id;
                            }
                            if (!Select::is_select_id($select_id)) throw new CsException("$select_id Select id doesn't exist");
                        }

                        $stmt = $db->prepare("INSERT INTO $Web->ecommerce_category_details_tbl (`category_id`,`mandatory`, `option_text`, `option_type`, `select_id`, `filter`) 
                                        VALUES (?,?,?,?,?,?) ");
                        $stmt->execute([$category_id, $mandatory, $option_text, $option_type, $select_id, $filter]);

                        $temp = $details[$detail_id];
                        unset($details[$detail_id]);
                        $new_detail_id = $db->lastInsertId();
                        $details[$new_detail_id] = $temp;

                        foreach ($variations as $key => $value) {
                            if ($value["detail_id"] == $detail_id) {
                                $variations[$key]["detail_id"] = $new_detail_id;
                            }
                        }

                        break;
                    default:
                        if ($option_type == "select") {
                            $Web->validate_post_input($select_id, "", "Select Id", true);
                            if ($select_id === "custom") {
                                if (!isset($detailsData["selectOptions"], $detailsData["custom_select_id"])) throw new CsException("Invalid details requested in details section");

                                $selectOptions = $Web->sanitize_text($detailsData["selectOptions"]);
                                $custom_select_id = $Web->sanitize_text($detailsData["custom_select_id"]);

                                if (!Select::is_select_id($custom_select_id)) throw new CsException("Custom Select doesn't exist");
                                if (!is_array($selectOptions))  throw new CsException("Invalid details requested in details section ");
                                if (empty($selectOptions)) throw new CsException("Add some select options in details section");

                                $Select = new Select($custom_select_id);
                                if (!$Select->is_temp()) {
                                    $select_id = Select::create_temporary_select($selectOptions);
                                } else {
                                    $select_id = $custom_select_id;
                                    $options = json_encode($selectOptions);

                                    $stmt = $db->prepare("UPDATE $Web->ecommerce_select_tbl SET options = ? WHERE select_id = ? ");
                                    $stmt->execute([$options, $select_id]);
                                }
                            }
                        }

                        $stmt = $db->prepare("UPDATE $Web->ecommerce_category_details_tbl SET mandatory = ?, option_text = ?, option_type = ?, select_id = ?, `filter` = ? WHERE detail_id =?  AND category_id = ? ");
                        $stmt->execute([$mandatory, $option_text, $option_type, $select_id, $filter, $detail_id, $category_id]);
                        break;
                }
            }

            //Deleted Details
            foreach ($deldetails as $detail_id) {
                $stmt = $db->prepare("DELETE FROM $Web->ecommerce_category_details_tbl WHERE detail_id = ? ");
                $stmt->execute([$detail_id]);
            }

            $data["details"] = $details;
            $data["deldetails"] = [];

            // variations
            if (count($variations) == 2) {
                $roles = array_column($variations, "role");
                if ($roles[0] == $roles[1]) throw new CsException("Duplicate role can't be used in Variation Types ");
            }

            foreach ($variations as $key => $variationsData) {
                if (!isset($variationsData["name"], $variationsData["type"], $variationsData["detail_id"], $variationsData["select_id"], $variationsData["role"])) throw new CsException("Invalid details in  Variation Types ");
                $name = $Web->sanitize_text($variationsData["name"]);
                $type = $Web->sanitize_text($variationsData["type"]);
                $detail_id = $Web->sanitize_text($variationsData["detail_id"]);
                $select_id = $Web->sanitize_text($variationsData["select_id"]);
                $role = $Web->sanitize_text($variationsData["role"]);

                $Web->validate_post_input($name, "", "Variation Name", true);
                if ($type != "select" && $type != "input" && $type != "image") throw new CsException("Invalid Variation Type");
                if ($role !== "parent" && $role !== "child") throw new CsException("Invalid Role");
                if (!$Category->is_detail_id($detail_id) && $type == "image") throw new CsException("Invalid Detail Id");

                if ($type == "select") {
                    $Web->validate_post_input($select_id, "", "Select Id", true);
                    if ($select_id === "custom") {
                        if (!isset($variationsData["selectOptions"], $variationsData["custom_select_id"])) throw new CsException("Invalid details requested in  Variation Types");
                        $selectOptions = $Web->sanitize_text($variationsData["selectOptions"]);
                        $custom_select_id = $Web->sanitize_text($variationsData["custom_select_id"]);
                        if (!is_array($selectOptions)) throw new CsException("Invalid details requested in  Variation Types");
                        if (empty($selectOptions)) throw new CsException("Add some select options in  Variation Types");

                        if (empty($custom_select_id)) {
                            $select_id = Select::create_temporary_select($selectOptions);
                        } else {
                            if (!Select::is_select_id($custom_select_id)) throw new CsException("Custom Select doesn't exist in  Variation Types");
                            $Select = new Select($custom_select_id);
                            if (!$Select->is_temp()) {
                                $select_id = Select::create_temporary_select($selectOptions);
                            } else {
                                $select_id = $custom_select_id;
                                $options = json_encode($selectOptions);
                                $stmt = $db->prepare("UPDATE $Web->ecommerce_select_tbl SET options = ? WHERE select_id = ? ");
                                $stmt->execute([$options, $select_id]);
                            }
                        }
                        $variations[$key]["custom_select_id"] = $select_id;
                    }
                    if (!Select::is_select_id($select_id)) throw new CsException("Select id doesn't exist");
                }

                if ($role == "child") {
                    if (count($variations) === 1) throw new CsException("Child role can't be used without parent ");
                }
            }

            $data["variations"] = $variations;
            $variations = json_encode($variations);
            $data = json_encode($data);

            $stmt = $db->prepare("UPDATE $Web->ecommerce_category_tbl SET images = ?,  variations = ?, data = ?, has_content = 'yes' WHERE category_id = ? ");
            $stmt->execute([$images, $variations, $data, $category_id]);

            $db->commit();
        } catch (CsException $e) {
            $db->rollBack();
            Errors::response($e->getError());
        } catch (Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in updating details" . $e->getLine());
        }

        $output = new stdClass;
        $output->data = $data;
        $output->message = "Congratulations, details have been updated";
        echo json_encode($output);

        break;

    case "fetch_information_select":
        if (!$Web->is_isset("category_id")) Errors::response("Invalid Request");
        $category_id = $Web->sanitize_text($_POST["category_id"]);
        if (!Category::is_category_id($category_id)) Errors::response("Category doesn't exist");

        $Category = new Category($category_id);
        if ($Category->is_rejected()) Errors::response("Sorry, The category has been deleted");


        $output = new stdClass;
        $select = '<option></option><option value="custom">Create Custom</option>';

        $stmt = $db->query("SELECT * FROM $Web->ecommerce_select_tbl WHERE is_temp = 'no' ORDER BY select_heading ASC ");
        while ($row = $stmt->fetch()) {
            $select_id = $row->select_id;
            $select_heading = $row->select_heading;
            $select .= '<option value="' . $select_id . '" >' . $select_heading . '</option>';
        }
        $output->select = $select;
        echo json_encode($output);
        break;

    case  "create_category":
        if (!$Web->is_isset("parent_id", "category")) Errors::response("Invalid Request");
        $parent_id = $Web->sanitize_text($_POST["parent_id"]);
        $category = $Web->sanitize_text($_POST["category"]);

        $Web->validate_post_input($parent_id, "number", "Request", true);
        $Web->validate_post_input($category, "", "Category", true);

        if (!Category::is_category_id($parent_id) && $parent_id !== '0') Errors::response("Category doesn't exist");
        if ($parent_id == '0') $level = 0;
        else {
            $C = new Category($parent_id);
            if (!$C->can_create_child()) Errors::response("Can't create child having details");
            $level = $C->level() + 1;
        }

        $max_level_allowed = Category::$max_level_allowed;
        if ($level > $max_level_allowed) Errors::response("Maximum $max_level_allowed level allowed");

        try {

            $stmt = $db->prepare("INSERT INTO $Web->ecommerce_category_tbl (`category`, `parent_id`,`level`,`status`) VALUES (?,?,?,'draft') ");
            $stmt->execute([$category, $parent_id, $level]);
        } catch (Exception $th) {
            Errors::response_500("Error in creating category" . $e->getMessage());
        }

        $category_id = $db->lastInsertId();
        $category = new Category($category_id);
        $category_list = $category->category_list();

        $output = new stdClass;
        $output->message = "Category created";
        $output->category_list = $category_list;
        echo json_encode($output);
        break;

    case "edit_category":
        if (!$Web->is_isset("category_id", "category")) Errors::response("Invalid Request");
        $category = $Web->sanitize_text($_POST["category"]);
        $category_id = $Web->sanitize_text($_POST["category_id"]);

        if (!Category::is_category_id($category_id)) Errors::response("Category doesn't exist");
        $Cat = new Category($category_id);
        if ($Cat->is_archived()) Errors::response("The category can't be updated because it is archived");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_category_tbl SET category = ? WHERE category_id = ? ");
            $stmt->execute([$category, $category_id]);
        } catch (Exception $e) {
            Errors::response_500("Error in updating category" . $e->getMessage());
        }

        $output = new stdClass;
        $output->category = $Web->unsanitize_text($category);
        $output->message = "Category updated successfully";
        echo json_encode($output);
        break;

    case "archive_category":
        if (!$Web->is_isset("category_id")) Errors::response("Invalid Request");
        $category_id = $Web->sanitize_text($_POST["category_id"]);

        if (!Category::is_category_id($category_id)) Errors::response("Category doesn't exist");
        $Category = new Category($category_id);
        if ($Category->is_archived()) Errors::response("The category is already archived");
        $Category->archive_category($category_id);

        $output = new stdClass;
        $output->message = "Category has been archived";
        echo json_encode($output);

        break;

    case "reject_listings":
        if (!$Web->is_isset("category_id")) Errors::response("Invalid Request");
        $category_id = $Web->sanitize_text($_POST["category_id"]);

        if (!Category::is_category_id($category_id)) Errors::response("Category doesn't exist");
        $Category = new Category($category_id);
        if ($Category->is_rejected()) Errors::response("Sorry, the category has been already deleted");

        try {
         
            $db->beginTransaction();
             $Category->reject_category();
            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in processing the request" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "All Listings has been rejected ";
        echo json_encode($output);

        break;

    case "apply_category_changes":

        try {
            $stmt = $db->query("UPDATE $Web->ecommerce_category_tbl SET status = 'active' WHERE status = 'draft' ");
        } catch (\Exception $e) {
            Errors::response_500("Error in applying changes" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Changes has been applied";
        echo json_encode($output);
        break;

    default:
        Errors::response_404();
        break;
}
