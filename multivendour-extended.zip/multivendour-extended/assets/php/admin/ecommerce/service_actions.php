<?php


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../../../db.php");
    }
    Errors::response_404();
}

if (!isset($_POST["case"]))  Errors::response_404();

$case = $_POST["case"];
if ($Web->is_empty($case)) Errors::response_404();

if (!$Login->is_admin_loggedin()) Errors::force_admin_login();

use Ecommerce\Service;

switch ($case) {

    case "delete_service":
        if (!$Web->is_isset("service_id")) Errors::response("Invalid Request");
        $service_id = $Web->sanitize_text($_POST["service_id"]);
        if (!Service::is_service_id($service_id)) Errors::response("Service doesn't exist");
        $Service = new Service($service_id);

        try {
            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_service_tbl WHERE service_id = ? ");
            $stmt->execute([$service_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in deleting service" . $e->getMessage());
        }

        $output = new stdClass;
        $output->data = $Service->tbl();
        $output->message = "Service has been deleted";
        echo json_encode($output);
        break;

    case "edit_service":
        if (!$Web->is_isset("service_id", "service_name", "service_charge", "charge_type")) Errors::response("Invalid Request");
        $service_id = $Web->sanitize_text($_POST["service_id"]);
        $service_name = $Web->sanitize_text($_POST["service_name"]);
        $service_charge = $Web->sanitize_text($_POST["service_charge"]);
        $charge_type = $Web->sanitize_text($_POST["charge_type"]);

        if (!Service::is_service_id($service_id)) Errors::response("Service doesn't exist");
        $Service = new Service($service_id);

        $Web->validate_post_input($service_name, "", "Service Name", true);
        $Web->validate_post_input($service_charge, "number", "Service Charge", true);
        if ($charge_type !== "fixed" && $charge_type !== "percentage") Errors::response("Invalid Service Type");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_service_tbl SET service_name = ?, service_charge = ?, charge_type = ? WHERE service_id = ? ");
            $stmt->execute([$service_name,$service_charge,$charge_type,$service_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in updating service" . $e->getMessage());
        }

        $Service = new Service($service_id);

        $output = new stdClass;
        $output->message = "Service has been updated";
        $output->data = $Service->tbl();
        echo json_encode($output);
        break;

    case "create_service":
        if (!$Web->is_isset("service_name", "service_charge", "charge_type")) Errors::response("Invalid Request");
        $service_name = $Web->sanitize_text($_POST["service_name"]);
        $service_charge = $Web->sanitize_text($_POST["service_charge"]);
        $charge_type = $Web->sanitize_text($_POST["charge_type"]);

        $Web->validate_post_input($service_name, "", "Service Name", true);
        $Web->validate_post_input($service_charge, "number", "Service Charge", true);
        if ($charge_type !== "fixed" && $charge_type !== "percentage") Errors::response("Invalid Service Type");

        try {
            $stmt = $db->prepare("INSERT INTO $Web->ecommerce_service_tbl (`service_name`, `service_charge`, `charge_type`,`created_date`) VALUES (?,?,?,?) ");
            $stmt->execute([$service_name,$service_charge,$charge_type,$Web->current_time()]);
        } catch (\Exception $e) {
            Errors::response_500("Error in creating service" . $e->getMessage());
        }

        $service_id = $db->lastInsertId();
        $Service = new Service($service_id);

        $output = new stdClass;
        $output->message = "Service has been created";
        $output->data = $Service->tbl();
        echo json_encode($output);

        break;

    default:
        Errors::response_404();
        break;
}
