<?php

use Ecommerce\Withdraw;
use Ecommerce\WithdrawGateway;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../../../db.php");
    }
    Errors::response_404();
}

if (!$Web->is_isset("case")) Errors::response_404();
$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();
if (!$Login->is_admin_loggedin()) Errors::force_admin_login();


switch ($case) {

    case "success_withdraw":
        if (!$Web->is_isset("withdraw_id", "success")) Errors::response_404();
        $withdraw_id = $Web->sanitize_text($_POST["withdraw_id"]);
        if (!Withdraw::is_withdraw_id($withdraw_id)) Errors::response("Withdraw doesn't exist");
        $Withdraw = new Withdraw($withdraw_id);
        if ($Withdraw->status() !== "pending") Errors::response("Withdraw has been processed already");
        $transaction_id = $Withdraw->transaction_id();

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("UPDATE $Web->ecommerce_sellers_withdraw_tbl SET status = 'success',date_processed  = ? WHERE withdraw_id = ? ");
            $stmt->execute([$Web->current_time(), $withdraw_id]);

            $stmt = $db->prepare("UPDATE $Web->transactions_tbl SET status = 'debit', last_updated = ?  WHERE transaction_id = ? ");
            $stmt->execute([$Web->current_time(), $transaction_id]);

            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in withdraw" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Withdraw has been successfull";
        echo json_encode($output);
        break;

    case "reject_withdraw":

        if (!$Web->is_isset("withdraw_id", "reject_reason")) Errors::response_404();
        $withdraw_id = $Web->sanitize_text($_POST["withdraw_id"]);
        $reject_reason = $Web->sanitize_text($_POST["reject_reason"]);
        if (!Withdraw::is_withdraw_id($withdraw_id)) Errors::response("Withdraw doesn't exist");
        $Withdraw = new Withdraw($withdraw_id);
        if ($Withdraw->status() !== "pending") Errors::response("Withdraw has been processed already");
        $Web->validate_post_input($reject_reason, "", "Description", true);
        $gross_amount = $Withdraw->gross_amount();
        $user_id = $Withdraw->seller()->user_id;
        $transaction_id = $Withdraw->transaction_id();

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("UPDATE $Web->ecommerce_sellers_withdraw_tbl SET status = 'rejected',rejected_reason = ?, date_processed  = ? WHERE withdraw_id = ? ");
            $stmt->execute([$reject_reason, $Web->current_time(), $withdraw_id]);

            $stmt = $db->prepare("UPDATE $Web->transactions_tbl SET status = 'failed', last_updated = ? WHERE transaction_id = ? ");
            $stmt->execute([$Web->current_time(), $transaction_id]);

            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in withdraw" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Withdraw has been rejected";
        echo json_encode($output);

        break;

    case "delete_withdraw_gateway":

        if (!$Web->is_isset("gateway_id")) Errors::response_404();
        $gateway_id = $Web->sanitize_text($_POST["gateway_id"]);
        if (!WithdrawGateway::is_gateway_id($gateway_id)) Errors::response("Gateway doesn't exist");


        try {
            $db->beginTransaction();

            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_withdraw_gateways_tbl WHERE gateway_id =  ? ");
            $stmt->execute([$gateway_id]);

            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_sellers_withdraw_gateways_tbl WHERE gateway_id =  ? ");
            $stmt->execute([$gateway_id]);

            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in deleting withdraw gateway " . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Gateway method has been deleted";
        $output->url = $Web->admin_url() . '/payments/withdraw-methods';
        echo json_encode($output);

        break;

    case "remove_gateway_logo":
        if (!$Web->is_isset("remove_gateway_logo", "gateway_id")) Errors::response_404();
        $gateway_id = $Web->sanitize_text($_POST["gateway_id"]);
        if (!WithdrawGateway::is_gateway_id($gateway_id)) Errors::response("Gateway doesn't exist");

        $output = new stdClass;
        $output->image_id = 0;
        $output->image_src = WithdrawGateway::default_image();
        echo json_encode($output);
        break;

    case "create_withdraw_method":

        if (!$Web->is_isset("gateway_id", "event", "logo_image_id", "gateway_name", "processing_time", "charge", "charge_type", "status", "card_heading", "labels")) Errors::response_404();

        $charge = $Web->sanitize_text($_POST["charge"]);
        $charge_type = $Web->sanitize_text($_POST["charge_type"]);
        $gateway_id = $Web->sanitize_text($_POST["gateway_id"]);
        $event = $Web->sanitize_text($_POST["event"]);
        $logo_image_id = $Web->sanitize_text($_POST["logo_image_id"]);
        $gateway_name = $Web->sanitize_text($_POST["gateway_name"]);
        $processing_time = $Web->sanitize_text($_POST["processing_time"]);
        $status = $Web->sanitize_text($_POST["status"]);
        $card_heading = $Web->sanitize_text($_POST["card_heading"]);
        $labels = $Web->sanitize_text($_POST["labels"]);
        if ($status !==  "active" && $status !== "inactive") Errors::response("Invalid status");
        if ($event !==  "create" && $event !== "update") Errors::response("Invalid event");
        if (!is_array($labels)) Errors::response("Invalid data requested");

        $Web->validate_post_input($charge, "number", "Charge", true);
        if ($charge_type !== "fixed" && $charge_type !== "percentage") Errors::response("Error Charge Type");

        $max_labels = 10;

        if (empty($labels)) Errors::response("Add at least a requirement option");
        if (count($labels) > $max_labels) Errors::response("Max $max_labels labels are allowed");


        foreach ($labels as $key => $data) {
            if (empty($data["id"])) $labels[$key]["id"] = $Web->unique_id();
        }

        $labels = json_encode($labels);
        $output = new stdClass;

        switch ($event) {
            case "create":

                try {
                    $stmt = $db->prepare("INSERT INTO $Web->ecommerce_withdraw_gateways_tbl (`gateway_name`, `logo_id`,`processing_time`,`charge`,`charge_type`, `status`, `card_heading`, `labels`, `date_created`)
                                     VALUES ( :gateway_name,:logo_id,:processing_time,:charge,:charge_type,:status,:card_heading,:labels,:date_created) ");

                    $stmt->execute([
                        ":gateway_name" => $gateway_name,
                        ":logo_id" => $logo_image_id,
                        ":processing_time" => $processing_time,
                        ":charge" => $charge,
                        ":charge_type" => $charge_type,
                        ":status" => $status,
                        ":card_heading" =>  $card_heading,
                        ":labels" => $labels,
                        ":date_created" => $Web->current_time()
                    ]);

                } catch (Exception $e) {
                    Errors::response_500("Error in creating withdraw gateway" . $e->getMessage());
                }
                $output->message = "Withdraw method has been created";
                break;
            case "update":

                if (!WithdrawGateway::is_gateway_id($gateway_id)) Errors::response("Gateway doesn't exist");
                try {
                    $stmt = $db->prepare("UPDATE $Web->ecommerce_withdraw_gateways_tbl SET  gateway_name = :gateway_name,logo_id = :logo_id,
                    processing_time = :processing_time,charge = :charge,charge_type = :charge_type, status = :status, card_heading = :card_heading,labels = :labels WHERE gateway_id = :gateway_id ");

                    $stmt->execute([
                        ":gateway_name" => $gateway_name,
                        ":logo_id" => $logo_image_id,
                        ":processing_time" => $processing_time,
                        ":charge" => $charge,
                        ":charge_type" => $charge_type,
                        ":status" => $status,
                        ":card_heading" =>  $card_heading,
                        ":labels" => $labels,
                        ":gateway_id" => $gateway_id
                    ]);
                } catch (Exception $e) {
                    Errors::response_500("Error in updating withdraw gateway" . $e->getMessage());
                }
                $output->message = "Withdraw method has been updated";
                break;
        }



        $output->url = $Web->admin_url() . '/payments/withdraw-methods';
        echo json_encode($output);
        break;
}
