<?php


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../../../db.php");
    }
    Errors::response_404();
}

use Ecommerce\Seller;
use Ecommerce\SellerVerification;

if (!$Web->is_isset("case")) Errors::response_404();
$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();
if (!$Login->is_admin_loggedin()) Errors::force_admin_login();


switch ($case) {

    case "change_seller_status":

        if (!$Web->is_isset("reason", "user_id", "status")) Errors::response_404();
        $user_id = $Web->sanitize_text($_POST["user_id"]);
        $reason = $Web->sanitize_text($_POST["reason"]);
        $status = $Web->sanitize_text($_POST["status"]);

        $Web->validate_post_length($_POST["reason"], 500, "Maximum reason length is 500");

        if ($status !== "block" && $status !== "reject") Errors::response("Invalid status requested");
        $to_status = $status == "block" ? "blocked" : "rejected";

        if (!Seller::is_user_seller($user_id)) Errors::response("Seller doesn't exist ");
        $Seller = new Seller($user_id);

        if ($Seller->status() !== "verified") Errors::response("Seller is not verified ");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_seller_users_tbl SET status = ?, status_reason = ? WHERE user_id = ? AND status = 'verified' ");
            $stmt->execute([$to_status, $reason, $user_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in updating status" . $e->getMessage());
        }

        $output = new stdClass;
        $output->status = $Seller->status_label();
        $output->message = $status == "reject" ? "Seller has been rejected" : "Seller has been blocked";
        echo json_encode($output);

        break;
}
