<?php


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../../../db.php");
    }
    Errors::response_404();
}

use Ecommerce\Order;
use Ecommerce\_Order;
use Ecommerce\Courier;
use Ecommerce\Product;

if (!$Web->is_isset("case")) Errors::response_404();
$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();
if (!$Login->is_admin_loggedin()) Errors::force_admin_login();


switch ($case) {

    case "reject_order":
        if (!$Web->is_isset("order_id", "reason")) Errors::response("Invalid Request");
        $order_id = $Web->sanitize_text($_POST["order_id"]);
        $reason = $Web->sanitize_text($_POST["reason"]);

        $Web->validate_post_input($reason, "", "Reason", true);
        $Web->validate_post_length($_POST["reason"], 3000, "Maximum Reject reason length is 3000 ");

        try {
            $db->beginTransaction();
            if (!Order::is_order_id($order_id)) Errors::response($order_id . " Order Id doesn't exist");
            $Order = new _Order($order_id);
            if (
                ($Order->status_step() < 4 || $Order->status_step() > 7) && $Order->status_step() != 11
            ) Errors::response("Sorry the order can't be rejected");
            $total_price = $Order->total_price();
            $product_id = $Order->product_id();
            $variation_id = $Order->variation_id();
            $svariation_id = $Order->svariation_id();
            $Product = new Product($product_id);
            $listing_id = $Product->listing_id();
            $quantity = $Order->quantity();
            $seller_id = $Product->seller()->user_id;

            if (in_array($Order->status_step(), [5, 6, 7, 11])) {
                $stmt = $db->prepare("UPDATE `$Web->transactions_tbl` SET status = 'failed', last_updated =? WHERE order_id = ? AND user_id =  ? ");
                $stmt->execute([$Web->current_time(), $order_id, $seller_id]);
            }

            $refund_status = $Order->can_refund() ? "pending" : "none";
            $refund_inited_on = $Order->can_refund() ? $Web->current_time() : NULL;

            $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET status = 'REJECTED', rejected_reason =?, rejected_on = ?,refund_status = ?, refund_inited_on = ? WHERE order_id = ? ");
            $stmt->execute([$reason, $Web->current_time(), $refund_status, $refund_inited_on, $order_id]);

            $stmt = $db->prepare("UPDATE $Web->ecommerce_variations_tbl SET stock = stock + ? WHERE product_id = ? AND variation_id = ? AND svariation_id = ? ");
            $stmt->execute([$quantity, $product_id, $variation_id, $svariation_id]);


            $stmt = $db->prepare("UPDATE $Web->ecommerce_listing_variations_tbl SET stock = stock + ? WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? ");
            $stmt->execute([$quantity, $listing_id, $variation_id, $svariation_id]);


            if ($Order->is_replacement_order()) {
                $total_price = $Order->original_order()->total_price();
                $service_charge = 0;
                $final_price = $total_price;

                $grand_total = 0;
                $charge_details = $Order->charge_details();

                foreach ($charge_details as $key => $value) {
                    if ($value->service_name == "Shipping Charge") {
                        $charge_details[$key]->service_charge = 0;
                    }
                }

                $replacement_charge_details = [];
                $replacement_charge_details[] = array(
                    "service_name" =>  "Replacement Rejected",
                    "service_charge" => $final_price,
                    "service_type" => "fixed"
                );

                $charge_details = json_encode($charge_details);
                $replacement_charge_details = json_encode($replacement_charge_details);
                $grand_total = $grand_total - $final_price;

                $stmt = $db->prepare("UPDATE $Web->transactions_tbl SET charge_details = ? WHERE order_id = ? ");
                $stmt->execute([$charge_details, $order_id]);

                $stmt = $db->prepare("INSERT INTO `$Web->transactions_tbl` (`user_id`,`amount`,`txn_charge`,`charge_details`,`net_amount`,`order_id`, `details`,`status`,`date`,`last_updated`,`type`) VALUES (?,?,?,?,?,?,'replacement rejected','debit',?,?,'order') ");
                $stmt->execute([$seller_id, $total_price, $service_charge, $replacement_charge_details, $final_price, $order_id, $Web->current_time(), $Web->current_time()]);

                $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET grand_total = ? WHERE order_id = ? ");
                $stmt->execute([$grand_total, $order_id]);
            }

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in processing request" . $e->getLine());
        }

        $output = new stdClass;
        $output->message = "Orders have been rejected";
        echo json_encode($output);
        break;

    case 'mark_delivered':
        if (!$Web->is_isset("order_id")) Errors::response("Invalid Request");
        $order_id = $Web->sanitize_text($_POST["order_id"]);
        if (!Order::is_order_id($order_id)) Errors::response($order_id . " Order Id doesn't exist");
        $Order = new Order($order_id);
        if ($Order->status() !== "SHIPPED") Errors::response("Only SHIPPED order can be mark as Delivered");

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET status = 'DELIVERED', delivered_on = ? WHERE order_id = ?  ");
            $stmt->execute([$Web->current_time(), $order_id]);

            $stmt = $db->prepare("UPDATE `$Web->transactions_tbl` SET status = 'clearing',last_updated = ? WHERE order_id = ? ");
            $stmt->execute([$Web->current_time(), $order_id]);

            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in updating order status " . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Orders have been marked as delivered";
        echo json_encode($output);
        break;

    case "mark_order_as_shipped":
        if (!$Web->is_isset("order_id")) Errors::response("Invalid Request");
        $order_id = $Web->sanitize_text($_POST["order_id"]);
        if (!Order::is_order_id($order_id)) Errors::response($order_id . " Order Id doesn't exist");
        $Order = new Order($order_id);
        if ($Order->status() !== "PICKUP_SCHEDULED") Errors::response("Only PICKUP_SCHEDULED order can be mark as Transit");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET status = 'SHIPPED', shipped_on = ? WHERE order_id = ? ");
            $stmt->execute([$Web->current_time(), $order_id]);
        } catch (Exception $e) {
            Errors::response_500("Error in updating order status " . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Order has been marked as Intransit ";
        echo json_encode($output);


        break;


    case "schedule_pickup_order":

        if (!$Web->is_isset("order_id", "tracking_id", "courier_service", "courier_charge", "courier_comment"))  Errors::response("Invalid Request");
        $order_id = $Web->sanitize_text($_POST["order_id"]);
        $tracking_id = $Web->sanitize_text($_POST["tracking_id"]);
        $courier_service_id = $Web->sanitize_text($_POST["courier_service"]);
        $courier_charge = $Web->sanitize_text($_POST["courier_charge"]);
        $courier_comment = $Web->sanitize_text($_POST["courier_comment"]);

        if (!_Order::is_order_id($order_id)) Errors::response($order_id . " Order Id doesn't exist");
        $Order = new _Order($order_id);
        if ($Order->status() !== "RTD") Errors::response("Order no more available for dispatch");

        $Web->validate_post_input($tracking_id, "", "Tracking Id", true);
        $Web->validate_post_input($courier_service_id, "", "Courier Service", true);
        $Web->validate_post_input($courier_charge, "number", " Courier Charge", true);
        $Web->validate_post_input($courier_comment, "", "Comment", true);
        $Web->validate_post_length($_POST["courier_comment"], 3000, "Maximum Comment length is 3000 ");

        if (!Courier::is_courier_id($courier_service_id)) Errors::response("Courier Service doesn't exist");
        $Courier = new Courier($courier_service_id);

        $shipped_details = [];
        $shipped_details["tracking_id"] = $tracking_id;
        $shipped_details["courier_service"] = $Courier->name();
        $shipped_details["courier_service_url"] = $Courier->url();
        $shipped_details["courier_charge"] = $courier_charge;
        $shipped_details["courier_comment"] = $courier_comment;
        $shipped_details = json_encode($shipped_details);

        $grand_total = $Order->grand_total();
        $charge_details = $Order->charge_details();
        $charge_details[] = array(
            "service_name" =>  "Shipping Charge",
            "service_charge" => $courier_charge,
            "service_type" => "fixed"
        );
        $charge_details = json_encode($charge_details);
        $grand_total = $grand_total - $courier_charge;


        try {
            $db->beginTransaction();
            $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET shipping_charge = shipping_charge + :courier_charge, grand_total = :grand_total, status = 'PICKUP_SCHEDULED', pickup_scheduled_on = :pickup_scheduled_on, shipped_details = :shipped_details WHERE order_id = :order_id  ");
            $stmt->execute([
                ":courier_charge" => $courier_charge,
                ":grand_total" => $grand_total,
                ":pickup_scheduled_on" => $Web->current_time(),
                ":shipped_details" => $shipped_details,
                ":order_id" => $order_id
            ]);;

            $stmt = $db->prepare("UPDATE `$Web->transactions_tbl` SET txn_charge = txn_charge + :courier_charge, net_amount = :grand_total,
            charge_details =  :charge_details, last_updated = :current_time WHERE order_id = :order_id ");
            $stmt->execute([
                ":courier_charge" => $courier_charge,
                ":grand_total" => $grand_total,
                ":charge_details" => $charge_details,
                ":current_time" => $Web->current_time(),
                ":order_id" => $order_id
            ]);

            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in updating order status " . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Pickup has been scheduled";
        echo json_encode($output);

        break;

    case "mark_refund_completed":

        if (!$Web->is_isset("comment", "order_id")) Errors::response_404();
        $order_id = $Web->sanitize_text($_POST["order_id"]);
        $comment = $Web->sanitize_text($_POST["comment"]);
        $Web->validate_post_length($_POST["comment"], 3000, "Maximum Comment length is 3000 ");
        $Web->validate_post_input($comment, "", "Comment", true);

        if (!Order::is_order_id($order_id)) Errors::response("Order doesn't exist");
        $Order = new Order($order_id);
        if ($Order->refund_status() !== "pending") Errors::response("Refund isn't applicable");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET refund_status = 'completed', refund_comment = :refund_comment ,refund_date = :refund_date WHERE order_id = :order_id ");
            $stmt->execute([
                ":refund_comment" => $comment,
                ":refund_date" => $Web->current_time(),
                ":order_id" => $order_id,
            ]);
        } catch (Exception $e) {
            Errors::response_500("Error in processing the request" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Refund has been done";
        echo json_encode($output);
        break;


    case "reject_return_request":

        if (!$Web->is_isset("reason", "order_id")) Errors::response_404();
        $order_id = $Web->sanitize_text($_POST["order_id"]);
        $reason = $Web->sanitize_text($_POST["reason"]);
        $Web->validate_post_length($_POST["reason"], 3000, "Maximum Reject reason length is 3000 ");

        if (!Order::is_order_id($order_id)) Errors::response_404();
        $Order = new _Order($order_id);
        if (!$Order->has_returned_requested()) Errors::response_404();
        $Return = $Order->return_order();
        $return_id = $Return->return_id;

        if (!in_array($Return->status_code(), [1, 3, 4]))  Errors::response("Return doesn't exist");

        $Web->validate_post_input($reason, "", "Rejection Reason", true);
        try {

            $db->beginTransaction();
            if ($Return->status_code() == 4) {

                $return_shipping_charge = $Return->return_shipping_charge();
                $grand_total = $Order->grand_total();
                $charge_details = $Order->charge_details();

                foreach ($charge_details as $key => $data) {
                    if ($data->service_name == "Return Shipping Charge") {
                        $charge_details[$key]->service_charge = 0;
                    }
                }
                $charge_details = json_encode($charge_details);
                $grand_total = $grand_total + $return_shipping_charge;

                $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET shipping_charge = shipping_charge - :return_shipping_charge, grand_total = :grand_total WHERE order_id = :order_id  ");
                $stmt->execute([
                    ":return_shipping_charge" => $return_shipping_charge,
                    ":grand_total" => $grand_total,
                    ":order_id" => $order_id
                ]);

                $stmt = $db->prepare("UPDATE `$Web->transactions_tbl` SET txn_charge = txn_charge - :return_shipping_charge, net_amount = :grand_total,charge_details = :charge_details, last_updated = :last_updated WHERE order_id = :order_id ");
                $stmt->execute([
                    ":return_shipping_charge" => $return_shipping_charge,
                    ":grand_total" => $grand_total,
                    ":charge_details" => $charge_details,
                    ":last_updated" => $Web->current_time(),
                    ":order_id" => $order_id,
                ]);
            }

            $stmt = $db->prepare("UPDATE $Web->ecommerce_return_orders_tbl SET status = 'rejected', processed_comment = :processed_comment, rejected_on = :rejected_on WHERE return_id = :return_id ");
            $stmt->execute([
                ":processed_comment" => $reason,
                ":rejected_on" => $Web->current_time(),
                ":return_id" => $return_id,
            ]);


            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in processing the request" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Return has been rejected";
        $output->url = $Web->admin_url() . '/return-orders/requests';
        echo json_encode($output);
        break;

    case "accept_return_request":

        if (!$Web->is_isset("comment", "order_id")) Errors::response_404();
        $order_id = $Web->sanitize_text($_POST["order_id"]);
        $comment = $Web->sanitize_text($_POST["comment"]);
        $Web->validate_post_length($_POST["comment"], 3000, "Maximum Comment length is 3000 ");

        if (!Order::is_order_id($order_id)) Errors::response_404();
        $Order = new _Order($order_id);
        if (!$Order->has_returned_requested()) Errors::response_404();
        $Return = $Order->return_order();
        $return_id = $Return->return_id;

        if ($Return->status_code() != "1") Errors::response("Return does not exist");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_return_orders_tbl SET status = 'accepted', processed_comment = ?, accepted_on = ? WHERE return_id = ? ");
            $stmt->execute([$comment, $Web->current_time(), $return_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in processing the request" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Return has been accepted";
        $output->url = $Web->admin_url() . '/return-orders/requests';
        echo json_encode($output);
        break;

    case "schedule_return_pickup":

        if (!$Web->is_isset("comment", "return_shipping_charge", "order_id")) Errors::response_404();
        $order_id = $Web->sanitize_text($_POST["order_id"]);
        $comment = $Web->sanitize_text($_POST["comment"]);
        $Web->validate_post_length($_POST["comment"], 3000, "Maximum Comment length is 3000 ");
        $return_shipping_charge = $Web->sanitize_text($_POST["return_shipping_charge"]);
        $Web->validate_post_input($return_shipping_charge, "number", "Return Shipping Charge", true);

        if (!Order::is_order_id($order_id)) Errors::response_404();
        $Order = new _Order($order_id);
        if (!$Order->has_returned_requested()) Errors::response_404();
        $Return = $Order->return_order();
        $return_id = $Return->return_id;

        if ($Return->status_code() != "3") Errors::response("Return doesn't exist or has been already processed from here");
        $Web->validate_post_input($comment, "", "Comment", true);

        $grand_total = $Order->grand_total();
        $charge_details = $Order->charge_details();
        $charge_details[] = array(
            "service_name" =>  "Return Shipping Charge",
            "service_charge" => $return_shipping_charge,
            "service_type" => "fixed"
        );
        $charge_details = json_encode($charge_details);
        $grand_total = $grand_total - $return_shipping_charge;

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("UPDATE $Web->ecommerce_return_orders_tbl SET status = 'pickup_scheduled', pickup_scheduled_comment = ?, pickup_scheduled_date = ?, return_shipping_charge = ? WHERE return_id = ? ");
            $stmt->execute([$comment, $Web->current_time(), $return_shipping_charge, $return_id]);

            $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET shipping_charge = shipping_charge + ?, grand_total = ? WHERE order_id = ? ");
            $stmt->execute([$return_shipping_charge, $grand_total, $order_id]);

            $stmt = $db->prepare("UPDATE `$Web->transactions_tbl` SET txn_charge = txn_charge + ?, net_amount = ?,charge_details = ?, last_updated = ? WHERE order_id = ? ");
            $stmt->execute([$return_shipping_charge, $grand_total, $charge_details, $Web->current_time(), $order_id]);

            $db->commit();
        } catch (\Throwable $e) {
            $db->rollBack();
            Errors::response("Error in processing the request" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Pickup has been scheduled";
        $output->url = $Web->admin_url() . '/return-orders/requests';
        echo json_encode($output);
        break;

    case "mark_return_order_completed":

        if (!$Web->is_isset("order_id")) Errors::response_404();
        $order_id = $Web->sanitize_text($_POST["order_id"]);

        if (!Order::is_order_id($order_id)) Errors::response_404();
        $Order = new _Order($order_id);
        if (!$Order->has_returned_requested()) Errors::response_404();
        $Return = $Order->return_order();
        $return_id = $Return->return_id;

        if ($Return->status_code() != "4") Errors::response("Return has been already processed from here");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_return_orders_tbl SET status = 'completed', completed_date = ? WHERE return_id = ? ");
            $stmt->execute([$Web->current_time(), $return_id]);

            $total_price = $Return->total_price();
            $service_charge = $Return->service_charge();
            $final_price = $Return->final_price();

            $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET status = 'RETURNED', refund_status = 'pending', refund_inited_on = ? WHERE order_id = ? ");
            $stmt->execute([$Web->current_time(), $order_id]);

            $stmt = $db->prepare("INSERT INTO `$Web->transactions_tbl` (`user_id`,`amount`,`txn_charge`,`net_amount`,`order_id`, `details`,`status`,`date`,`last_updated`,`type`)  VALUES (:user_id,:total_price,:service_charge,:final_price,:order_id,'order returned','debit',:date,:last_updated,'order') ");
            $stmt->execute([
                ":user_id" => $Order->product()->seller()->user_id,
                ":total_price" => $total_price,
                ":service_charge" =>  $service_charge,
                ":final_price" => $final_price,
                ":order_id" => $order_id,
                ":date" => $Web->current_time(),
                ":last_updated" => $Web->current_time()
            ]);
        } catch (\Exception $e) {
            Errors::response("Error in processing the request" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Return has been completed";
        $output->url = $Web->admin_url() . '/return-orders/requests';
        echo json_encode($output);
        break;

        // Replacement

    case "reject_replacement_request":

        if (!$Web->is_isset("reason", "order_id")) Errors::response_404();
        $order_id = $Web->sanitize_text($_POST["order_id"]);
        $reason = $Web->sanitize_text($_POST["reason"]);
        $Web->validate_post_length($_POST["reason"], 3000, "Maximum Reject reason length is 3000 ");

        if (!Order::is_order_id($order_id)) Errors::response_404();
        $Order = new _Order($order_id);
        if (!$Order->has_replacement_requested()) Errors::response_404();
        $Replacement = $Order->replacement_order();
        $replacement_id = $Replacement->replacement_id;

        if (!in_array($Replacement->status_code(), [1, 3, 4]))  Errors::response("Return doesn't exist");

        $Web->validate_post_input($reason, "", "Rejection Reason", true);

        try {
            if ($Replacement->status_code() == 4) {
                $return_shipping_charge = $Replacement->return_shipping_charge();
                $grand_total = $Order->grand_total();
                $charge_details = $Order->charge_details();

                foreach ($charge_details as $key => $data) {
                    if ($data->service_name == "Return Shipping Charge") {
                        $charge_details[$key]->service_charge = 0;
                    }
                }
                $charge_details = json_encode($charge_details);
                $grand_total = $grand_total + $return_shipping_charge;

                $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET shipping_charge = shipping_charge - :return_shipping_charge, grand_total = :grand_total WHERE order_id = :order_id  ");
                $stmt->execute([
                    ":return_shipping_charge" => $return_shipping_charge,
                    ":grand_total" => $grand_total,
                    ":order_id" => $order_id
                ]);

                $stmt = $db->prepare("UPDATE `$Web->transactions_tbl` SET txn_charge = txn_charge - :return_shipping_charge, net_amount = :grand_total,charge_details = :charge_details, last_updated = :last_updated WHERE order_id = :order_id ");
                $stmt->execute([
                    ":return_shipping_charge" => $return_shipping_charge,
                    ":grand_total" => $grand_total,
                    ":charge_details" => $charge_details,
                    ":last_updated" => $Web->current_time(),
                    ":order_id" => $order_id,
                ]);
            }

            $stmt = $db->prepare("UPDATE $Web->ecommerce_replacement_orders_tbl SET status = 'rejected', processed_comment = ?, rejected_on = ? WHERE replacement_id = ? ");
            $stmt->execute([$reason, $Web->current_time(), $replacement_id]);
        } catch (\Exception $e) {
            Errors::response("Error in processing the request" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Return has been rejected";
        $output->url = $Web->admin_url() . '/return-orders/requests';
        echo json_encode($output);
        break;

    case "accept_replacement_request":

        if (!$Web->is_isset("comment", "order_id")) Errors::response_404();
        $order_id = $Web->sanitize_text($_POST["order_id"]);
        $comment = $Web->sanitize_text($_POST["comment"]);
        $Web->validate_post_length($_POST["comment"], 3000, "Maximum Comment length is 3000 ");

        if (!Order::is_order_id($order_id)) Errors::response_404();
        $Order = new _Order($order_id);
        if (!$Order->has_replacement_requested()) Errors::response_404();
        $Replacement = $Order->replacement_order();
        $replacement_id = $Replacement->replacement_id;

        if ($Replacement->status_code() != "1") Errors::response("Replacement does not exist");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_replacement_orders_tbl SET status = 'accepted', processed_comment = ?, accepted_on = ? WHERE replacement_id = ? ");
            $stmt->execute([$comment, $Web->current_time(), $replacement_id]);
        } catch (\Exception $e) {
            Errors::response("Error in processing the request" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Replacement has been accepted";
        $output->url = $Web->admin_url() . '/orders/requests';
        echo json_encode($output);
        break;

    case "schedule_replacement_pickup":

        if (!$Web->is_isset("comment", "return_shipping_charge", "order_id")) Errors::response_404();
        $order_id = $Web->sanitize_text($_POST["order_id"]);
        $comment = $Web->sanitize_text($_POST["comment"]);
        $return_shipping_charge = $Web->sanitize_text($_POST["return_shipping_charge"]);
        $Web->validate_post_length($_POST["comment"], 3000, "Maximum Comment length is 3000 ");
        $Web->validate_post_input($return_shipping_charge, "number", "Return Shipping Charge", true);

        if (!Order::is_order_id($order_id)) Errors::response_404();
        $Order = new _Order($order_id);
        if (!$Order->has_replacement_requested()) Errors::response_404();
        $Replacement = $Order->replacement_order();
        $replacement_id = $Replacement->replacement_id;

        if ($Replacement->status_code() != "3") Errors::response("Return doesn't exist or has been already processed from here");
        $Web->validate_post_input($comment, "", "Comment", true);

        $grand_total = $Order->grand_total();
        $charge_details = $Order->charge_details();
        $charge_details[] = array(
            "service_name" =>  "Return Shipping Charge",
            "service_charge" => $return_shipping_charge,
            "service_type" => "fixed"
        );
        $charge_details = json_encode($charge_details);
        $grand_total = $grand_total - $return_shipping_charge;

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("UPDATE $Web->ecommerce_replacement_orders_tbl SET status = 'pickup_scheduled', pickup_scheduled_comment = ?, pickup_scheduled_date = ?, return_shipping_charge = ?  WHERE replacement_id = ? ");
            $stmt->execute([$comment, $Web->current_time(), $return_shipping_charge, $replacement_id]);


            $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET shipping_charge = shipping_charge + ?, grand_total = ? WHERE order_id = ?  ");
            $stmt->execute([$return_shipping_charge, $grand_total, $order_id]);


            $stmt = $db->prepare("UPDATE `$Web->transactions_tbl` SET txn_charge = txn_charge + ?, net_amount = ?,charge_details = ?, last_updated = ? WHERE order_id = ? ");
            $stmt->execute([$return_shipping_charge, $grand_total, $charge_details, $Web->current_time(), $order_id]);

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in processing the request" . $e->getLine());
        }

        $output = new stdClass;
        $output->message = "Pickup has been scheduled";
        $output->url = $Web->admin_url() . '/replacement-orders/requests';
        echo json_encode($output);
        break;

    case "mark_replacement_order_completed":

        if (!$Web->is_isset("order_id")) Errors::response_404();
        $order_id = $Web->sanitize_text($_POST["order_id"]);
        if (!Order::is_order_id($order_id)) Errors::response_404();
        $Order = new _Order($order_id);
        if (!$Order->has_replacement_requested()) Errors::response_404();
        $Replacement = $Order->replacement_order();
        $replacement_id = $Replacement->replacement_id;

        if ($Replacement->status_code() != "4") Errors::response("Replacement does not exist");

        $row = $Order->row();
        $buyer_id = $row->buyer_id;
        $product_id = $row->product_id;
        $variation_id = $row->variation_id;
        $svariation_id = $row->svariation_id;
        $quantity = $row->quantity;
        $price = 0;
        $total_price = 0;
        $address = $row->address;
        $payment_method = $row->payment_method;
        $status = "SUCCESS";

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("INSERT INTO $Web->ecommerce_orders_tbl (`buyer_id`, `product_id`, `variation_id`, `svariation_id`, `quantity`, `price`,`total_price`,`grand_total`, `ordered_date`, `address`, `payment_method`,`status`) VALUES (:buyer_id,:product_id,:variation_id,:svariation_id,:quantity,:price, :total_price,:grand_total, :ordered_date,:address,:payment_method,:status) ");
            $stmt->execute([
                ":buyer_id" => $buyer_id,
                ":product_id" => $product_id,
                ":variation_id" => $variation_id,
                ":svariation_id" => $svariation_id,
                ":quantity" => $quantity,
                ":price" => $price,
                ":total_price" => $total_price,
                ":grand_total" => $total_price,
                ":ordered_date" => $Web->current_time(),
                ":address" => $address,
                ":payment_method" => $payment_method,
                ":status" => $status
            ]);

            $new_order_id = $db->lastInsertId();

            $stmt = $db->prepare("UPDATE $Web->ecommerce_replacement_orders_tbl SET status = 'completed', completed_date = ?, new_order_id = ? WHERE replacement_id = ? ");
            $stmt->execute([$Web->current_time(), $new_order_id, $replacement_id]);

            $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET status = 'REPLACEMENT' WHERE order_id = ? ");
            $stmt->execute([$order_id]);

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in processing the request" . $e->getMessage());
        }


        $output = new stdClass;
        $output->message = "Replacement has been completed";
        $output->url = $Web->admin_url() . '/orders/requests';
        echo json_encode($output);
        break;


    case "refund_replacement_request":

        if (!$Web->is_isset("order_id")) Errors::response_404();
        $order_id = $Web->sanitize_text($_POST["order_id"]);
        if (!Order::is_order_id($order_id)) Errors::response_404();
        $Order = new _Order($order_id);
        if (!$Order->has_replacement_requested()) Errors::response_404();
        $Replacement = $Order->replacement_order();
        $replacement_id = $Replacement->replacement_id;

        if (!$Web->is_isset("comment")) Errors::response_404();
        $comment = $Web->sanitize_text($_POST["comment"]);
        $Web->validate_post_length($_POST["comment"], 3000, "Maximum Comment length is 3000 ");
        $Web->validate_post_input($comment, "", "Comment", true);

        if ($Replacement->status_code() != "4") Errors::response("Replacement does not exist");
        if ($Order->refund_status() == "completed") Errors::response("Refund not applicable");


        try {
            $db->beginTransaction();

            $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET status = 'REPLACEMENT', refund_status = 'pending', refund_date =  ? WHERE order_id = ? ");
            $stmt->execute([$Web->current_time(), $order_id]);

            $stmt = $db->prepare("UPDATE $Web->ecommerce_replacement_orders_tbl SET status = 'completed',refund_reason = ?, completed_date = ? WHERE replacement_id = ? ");
            $stmt->execute([$comment, $Web->current_time(), $replacement_id]);

            $seller_id = $Order->product()->seller()->user_id;
            $total_price = $Order->total_price();
            $service_charge = $Order->service_charge();
            $final_price = $total_price - $service_charge;

            $stmt = $db->prepare("INSERT INTO `$Web->transactions_tbl` (`user_id`,`amount`,`txn_charge`,`net_amount`,`order_id`, `details`,`status`,`date`,`last_updated`,`type`) VALUES (:seller_id,:total_price,:service_charge,:final_price,:order_id,'replacement refunded','debit',:date,:last_updated,'order') ");
            $stmt->execute([
                ":seller_id" => $seller_id,
                ":total_price" => $total_price,
                ":service_charge" => $service_charge,
                ":final_price" => $final_price,
                ":order_id" => $order_id,
                ":date" => $Web->current_time(),
                ":last_updated" => $Web->current_time(),
            ]);

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in processing the request" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Refund has been done";
        echo json_encode($output);
        break;


    default:
        Errors::response_404();
        break;
}
