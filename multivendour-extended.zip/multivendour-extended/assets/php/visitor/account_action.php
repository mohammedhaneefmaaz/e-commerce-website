<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        include("../../../db.php");
    }
    Errors::response_404();
}

if (!$Web->is_isset("case")) Errors::response_404();

$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();

switch ($case) {

    case  "login":

        if (!$Web->is_isset("email", "role", "password", "keeplogged")) {
            Errors::response("Invalid request");
        }

        $user_email = $Web->sanitize_text($_POST["email"]);
        $password = $Web->sanitize_text($_POST["password"]);
        $keeploggedin = $Web->sanitize_text($_POST["keeplogged"]);
        $role = $Web->sanitize_text($_POST["role"]);

        $Web->validate_post_input($user_email, "email", "Email", true);
        $Web->validate_post_input($password, "", "Password", true);

        if (!User::is_user_email($user_email)) Errors::response("No account is associated with this email");
        $user_id = User::user_id($user_email);
        $user_data = new User($user_id);

        $login_verification = $user_data->login_verification();
        $login_with_google = $user_data->google_login();
        $login_with_email = $user_data->email_login();

        if ($login_with_email == "off" && $login_with_google == "on") Errors::response("This email address uses Google LogIn");
        $pass_decode = password_verify($password, $user_data->password());
        if (!$pass_decode)  Errors::response("Email and Password are invalid");
        if ($user_data->status() != "active")  Errors::response("Your account has been blocked");

        if ($login_verification == "off" && $login_with_email == "on") {
            try {
                $prepare = $Login->insert_user_login_session($user_id, $keeploggedin, $role);
                if ($role == "seller" && !$user_data->is_seller()) $user_data->create_seller_account();

                $output = new stdClass();
                $output->message = "Login Successfull";
                $output->verification = $login_verification;
                $output->url = $role == "visitor" ?  $Web->base_url() . '/' : $Web->seller_url() . '/dashboard/';
                echo json_encode($output);
            } catch (Exception $e) {
                Errors::response_500("Error in Login" . $e->getMessage());
            }
        } else {

            $otp = $Login->get_new_otp($user_email, "login_verification");
            if (!$otp) Errors::response("Otp sending failed");


            $send_otp = $Login->send_login_verification_code($user_id, $otp);
            if (!$send_otp)  Errors::response("Otp sending failed");

            $content = $Login->get_login_verification_content($user_email, $keeploggedin, $role);
            $output = new stdClass();
            $output->verification = $login_verification;
            $output->content = $content;
            $output->email = $user_email;
            echo json_encode($output);
        }


        break;

    case "login_verification_code":
        if (!$Web->is_isset("user_email")) Errors::response("Invalid Request");
        $user_email = $Web->sanitize_text($_POST["user_email"]);

        if (!User::is_user_email($user_email)) Errors::response("Email do not exists");

        $otp = $Login->get_new_otp($user_email, "login_verification");
        if (!$otp) Errors::response("Otp sending failed");
        $user_id = User::user_id($user_email);

        $send_otp = $Login->send_login_verification_code($user_id, $otp);
        if (!$send_otp)  Errors::response("Otp sending failed");

        $output = new stdClass();
        $output->message = "Verification Code Sent Successfully";
        echo json_encode($output);

        break;

    case "login_with_verification":

        if (!$Web->is_isset("1", "2", "3", "4", "5", "6", "user_email", "keeplogged", "role")) Errors::response("Invalid Request");

        $user_email = $Web->sanitize_text($_POST["user_email"]);
        $keeplogged = $Web->sanitize_text($_POST["keeplogged"]);
        $otp = $Web->sanitize_text($_POST["1"]);
        $otp .= $Web->sanitize_text($_POST["2"]);
        $otp .= $Web->sanitize_text($_POST["3"]);
        $otp .= $Web->sanitize_text($_POST["4"]);
        $otp .= $Web->sanitize_text($_POST["5"]);
        $otp .= $Web->sanitize_text($_POST["6"]);
        $role = $Web->sanitize_text($_POST["role"]);
        $Web->validate_post_input($otp, "number", "Otp", true);

        if (!User::is_user_email($user_email)) Errors::response("Email do not exists");
        if (strlen($otp) != "6") Errors::response("Invalid Otp Length");
        $user_id = User::user_id($user_email);

        $User = new User($user_id);
        $login_verification = $User->login_verification();
        if ($login_verification == "off") Errors::response("Two Step Verification is disabled for your account");
        if (!$Login->is_valid_otp($otp, $user_email, "login_verification"))  Errors::response("Otp is invalid");

        $Login->update_otp_status($otp, $user_email, "login_verification");

        $prepare = $Login->insert_user_login_session($user_id, $keeplogged, $role);
        if ($role == "seller" && !$User->is_seller()) $User->create_seller_account();
        if ($prepare) {
            $output = new stdClass();
            $output->message = "Login Successfull";
            $output->verification = $login_verification;
            $output->url = $role == "visitor" ?  $Web->base_url() . '/' : $Web->seller_url() . '/';
            echo json_encode($output);
            exit();
        }
        Errors::response("Error in Login");
        break;

    case "register_with_google":
        if (!$Web->is_isset("google_id", "first_name", "last_name", "email", "password", "confirm_password", "toc", "role")) Errors::response("Invalid Request");

        $google_id = $Web->sanitize_text($_POST["google_id"]);
        $user_email = $Web->sanitize_text($_POST["email"]);
        $first_name = $Web->sanitize_text($_POST["first_name"]);
        $last_name =  $Web->sanitize_text($_POST["last_name"]);
        $user_password = $Web->sanitize_text($_POST["password"]);
        $confirm_password = $Web->sanitize_text($_POST["confirm_password"]);
        $toc =  $Web->sanitize_text($_POST["toc"]);
        $role = $Web->sanitize_text($_POST["role"]);

        $Web->validate_post_input($first_name, "alpha", "First Name", true);
        $Web->validate_post_input($last_name, "alpha", "Last Name", true);
        $Web->validate_post_input($user_email, "email", "Email", true);

        $Web->validate_post_length($_POST["first_name"], 20, "Maximum First Name length is 20");
        $Web->validate_post_length($_POST["last_name"], 20, "Maximum Last Name length is 20");

        try {

            $db->beginTransaction();

            $stmt = $db->prepare("SELECT * FROM $Web->check_google_signup_tbl WHERE google_id = ? AND type = 'register' AND status = '1'  ");
            $stmt->execute([$google_id]);
            if (!$stmt->rowCount()) throw new CsException("Invalid Request");
            $row = $stmt->fetch();

            $details = $row->details;
            $registerDetails = unserialize($details);
            $event = $registerDetails["event"];
            $db_email = $registerDetails["user_email"];
            if ($event != '2') throw new CsException("Invalid Request");
            if ($db_email != $user_email) throw new CsException("Invalid Request");


            if ($toc !== "1") Errors::response("Invalid Request");
            if (User::is_user_email($user_email)) Errors::response("Email is already in use");
            if ($user_password !== $confirm_password) Errors::response("Passwords are not matching");

            $user_id = $Login->get_new_user_id();
            $current_time = $Web->current_time();
            $password = "";
            $email_login = "";
            $google_login = "on";
            if (!$Web->is_empty($user_password)) {
                $email_login = "on";
                $password = password_hash($user_password, PASSWORD_BCRYPT);
            }
            $status = "active";

            $stmt = $db->prepare("INSERT INTO $Web->users_tbl (`user_id`, `user_email`, `first_name`, `last_name`,`password`, `status`,`email_login`,`google_login`, `registration_date`) VALUES (:user_id, :user_email, :first_name, :last_name,:password, :status,:email_login,:google_login, :registration_date) ");

            $stmt->execute([
                ":user_id" => $user_id,
                ":user_email" => $user_email,
                ":first_name" => $first_name,
                ":last_name" => $last_name,
                ":password" => $password,
                ":status" => $status,
                ":email_login" => $email_login,
                ":google_login" => $google_login,
                ":registration_date" => $current_time
            ]);

            $stmt = $db->prepare("UPDATE $Web->check_google_signup_tbl SET status = '2' WHERE google_id = ? ");
            $stmt->execute([$google_id]);

            $db->commit();
        } catch (\CsException $e) {
            $db->rollBack();
            Errors::response($e->getMessage());
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in registration" . $e->getMessage());
        }

        $Login->send_registration_successfull_email($user_id, $user_id);
        $output = new stdClass;
        $output->message = "Registration successfully";
        $output->url = $role == "visitor" ?  $Web->base_url() . '/login' :  $Web->seller_url() . '/login';
        echo json_encode($output);
        break;

    case "register":
        if (!$Web->is_isset("event", "first_name", "last_name", "email", "password", "confirm_password", "toc")) Errors::response("Invalid Request");

        $event = $Web->sanitize_text($_POST["event"]);
        $user_email = $Web->sanitize_text($_POST["email"]);
        $first_name = $Web->sanitize_text($_POST["first_name"]);
        $last_name =  $Web->sanitize_text($_POST["last_name"]);
        $user_password = $Web->sanitize_text($_POST["password"]);
        $confirm_password = $Web->sanitize_text($_POST["confirm_password"]);
        $toc =  $Web->sanitize_text($_POST["toc"]);
        $role =  $Web->sanitize_text($_POST["role"]);

        $Web->validate_post_input($first_name, "alpha", "First Name", true);
        $Web->validate_post_input($last_name, "alpha", "Last Name", true);
        $Web->validate_post_input($user_email, "email", "Email", true);
        $Web->validate_post_input($user_password, "", "Password", true);
        $Web->validate_post_input($confirm_password, "", "Confirm Password", true);

        if ($toc !== "1") Errors::response("You must have to agree with terms & conditions");
        if (User::is_user_email($user_email)) Errors::response("Account is already registered with $user_email ");
        if ($user_password !== $confirm_password) Errors::response("Passwords are not matching");

        switch ($event) {
            case "register":

                $otp = $Login->get_new_otp($user_email, "registration");
                if (!$otp)  Errors::response("Otp sending failed");
                $send_otp = $Login->send_registration_otp($user_email, $otp);
                if (!$send_otp)  Errors::response("Otp sending failed");
                $output = new stdClass;
                $output->message  =  "Otp has been sent";
                $output->email = $user_email;
                echo json_encode($output);
                break;

            case "verifyOtp":

                if (!$Web->is_isset("1", "2", "3", "4", "5", "6")) Errors::response("Invalid Request");
                $otp = $Web->sanitize_text($_POST["1"]);
                $otp .= $Web->sanitize_text($_POST["2"]);
                $otp .= $Web->sanitize_text($_POST["3"]);
                $otp .= $Web->sanitize_text($_POST["4"]);
                $otp .= $Web->sanitize_text($_POST["5"]);
                $otp .= $Web->sanitize_text($_POST["6"]);
                $Web->validate_post_input($otp, "number", "Otp", true);

                if (strlen($otp) !== 6) Errors::response("Invalid Otp Length");

                try {
                    $db->beginTransaction();

                    if (!$Login->is_valid_otp($otp, $user_email, "registration"))   Errors::response("Otp is invalid");


                    $user_id = $Login->get_new_user_id();
                    $password = password_hash($user_password, PASSWORD_BCRYPT);
                    $current_time = $Web->current_time();


                    $stmt = $db->prepare("INSERT INTO $Web->users_tbl (`user_id`, `user_email`, `first_name`, `last_name`, `password`, `status`,`email_login`, `registration_date`)
                         VALUES (:user_id,:user_email,:first_name,:last_name,:password,'active','on',:current_time) ");

                    $stmt->execute([
                        ":user_id" => $user_id,
                        ":user_email" => $user_email,
                        ":first_name" => $first_name,
                        ":last_name" => $last_name,
                        ":password" => $password,
                        ":current_time" => $current_time
                    ]);

                    $Login->update_otp_status($otp, $user_email, "registration");
                    $Login->send_registration_successfull_email($user_id, $user_id);

                    $db->commit();
                } catch (\Exception $e) {
                    $db->rollBack();
                    Errors::response_500("Error in registration" . $e->getMessage());
                }

                $output = new stdClass;
                $output->message = "Registration successfull";
                $output->url = $role == "visitor" ?  $Web->base_url() . '/login' : $Web->seller_url() . '/login';
                echo json_encode($output);

                break;


            default:
                Errors::response_404();
                break;
        }
        break;

    case "forgot_password":
        if (!$Web->is_isset("email")) Errors::response("Invalid request");
        $user_email = $Web->sanitize_text($_POST["email"]);
        $Web->validate_post_input($user_email, "email", "Email", true);
        if (!User::is_user_email($user_email)) Errors::response("No account is associated with this Email");

        $user_id = User::user_id($user_email);
        $user_data = new User($user_id);

        $row = $user_data->row();
        $login_with_google = $user_data->google_login();
        $login_with_email = $user_data->email_login();
        if ($login_with_email == "off" && $login_with_google == "on") Errors::response("This email address uses Google Login");

        $otp = $Login->get_new_otp($user_email, "reset_password");
        if (!$otp)  Errors::response("Otp sending failed");
        $send_otp = $Login->send_forgot_password_otp($user_id, $otp);
        if (!$send_otp)   Errors::response("Otp sending failed");
        $output = new stdClass;
        $output->message =  "Otp sending successfull";
        $output->email = $user_email;
        echo json_encode($output);
        break;


    case "verify_forgot_password_otp":
        if (!$Web->is_isset("1", "2", "3", "4", "5", "6", "email")) Errors::response("Invalid Request");
        $otp = $Web->sanitize_text($_POST["1"]);
        $otp .= $Web->sanitize_text($_POST["2"]);
        $otp .= $Web->sanitize_text($_POST["3"]);
        $otp .= $Web->sanitize_text($_POST["4"]);
        $otp .= $Web->sanitize_text($_POST["5"]);
        $otp .= $Web->sanitize_text($_POST["6"]);

        $Web->validate_post_input($otp, "number", "Otp", true);
        if (strlen($otp) != "6") Errors::response("Invalid Otp Length");
        $user_email = $Web->sanitize_text($_POST["email"]);
        if (!User::is_user_email($user_email)) Errors::response("Invalid Request");
        if (!$Login->is_valid_otp($otp, $user_email, "reset_password"))  Errors::response("Otp is invalid");
        $output = new stdClass;
        $output->message  =  "Otp approved successfull";
        $output->otp = $otp;
        echo json_encode($output);
        break;

    case "reset_password":
        if (!$Web->is_isset("password", "confirm_password", "email", "otp", "role")) Errors::response("Invalid Request");
        $password = $Web->sanitize_text($_POST["password"]);
        $confirm_password = $Web->sanitize_text($_POST["confirm_password"]);
        $role = $Web->sanitize_text($_POST["role"]);
        $user_email = $Web->sanitize_text($_POST["email"]);
        $otp = $Web->sanitize_text($_POST["otp"]);
        $Web->validate_post_input($password, "", "Password", true);
        $Web->validate_post_input($confirm_password, "", "Confirm Password", true);

        if (!User::is_user_email($user_email))  Errors::response("Invalid Email");
        if (!$Login->is_valid_otp($otp, $user_email, "reset_password")) Errors::response("Otp has been expired");

        if ($password !== $confirm_password) Errors::response("Passwords are not matching");
        $password = password_hash($password, PASSWORD_BCRYPT);
        $user_id = User::user_id($user_email);

        try {

            $db->beginTransaction();

            $stmt = $db->prepare("UPDATE $Web->users_tbl SET password = :password WHERE user_email = :user_email ");
            $stmt->execute([
                ":password" => $password,
                ":user_email" => $user_email
            ]);

            $Login->update_otp_status($otp, $user_email, "reset_password");
            $Login->logout_all_user($user_email);
            $Login->send_reset_password_successfull_email($user_id);

            $db->commit();

            $output = new stdClass;
            $output->message = "Password reset successfull";
            $output->url = $role == "visitor" ? $Web->base_url() . '/login' : $Web->seller_url() . '/login';
            echo json_encode($output);
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error In Updating Password" . $e->getMessage());
        }

        break;

    default:
        Errors::response_404();
        break;
}
