<?php

include "../../../db.php";

use Ecommerce\Product;

if(!isset($_GET["pid"])) Errors::response_404();
$product_id = $_GET["pid"];
if(!Product::is_product_id($product_id)) Errors::response_404();

$file = [];
$stmt = $db->prepare("SELECT review_id,images FROM $Web->ecommerce_reviews_tbl WHERE product_id = ? AND images != '[]' ");
$stmt->execute([$product_id]);
while ($row = $stmt->fetch()) {
    $review_id = $row->review_id;
    $images = $row->images;
    $images = json_decode($images);
    foreach ($images as $key => $image_id) {
        $file[] = $Web->get_file_src($image_id). '?review_id='. $review_id.'&index='.$key;
    }
}
$file = json_encode($file);

$output = new stdClass;
$output->data = $file;
echo json_encode($output);