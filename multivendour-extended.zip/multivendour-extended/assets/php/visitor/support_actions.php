<?php

use Ecommerce\Ticket;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists('Errors::response_404')) {
        include("../../../db.php");
    }
    Errors::response_404();
}

if (!isset($_POST["case"]))  Errors::response_404();

$case = $_POST["case"];
if ($Web->is_empty($case)) Errors::response_404();

if (!$Login->is_user_loggedin()) Errors::force_login();

switch ($case) {

    case "add_ticket":
        if (!$Web->is_isset("message", "subject", "files")) Errors::response("Invalid request");
        $subject = $Web->sanitize_text($_POST["subject"]);
        $message = $Web->sanitize_text($_POST["message"]);
        $files = $_POST["files"];
        if (!empty($files)) $files = json_decode($files);
        $Web->validate_post_length($_POST["message"], 3000, "Maximum Message length is 3000 ");
        $Web->validate_post_length($_POST["subject"], 100, "Maximum Subject length is 3000 ");

        if (!is_array($files)) Errors::response("Invalid details requested");
        if (count($files) > 5) Errors::response("Maximum 5 files are allowed");

        $current_time = $Web->current_time();

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("INSERT INTO $Web->support_tickets_tbl ( `creator`, `subject`, `created_at`, `status`) VALUES  (?,?,?,?) ");
            $stmt->execute([$LogUser->user_id, $subject, $current_time, 'pending']);

            $files = json_encode($files);

            $ticket_id = $db->lastInsertId();

            $stmt = $db->prepare("INSERT INTO $Web->support_ticket_messages_tbl  (`ticket_id`, `replier`, `message`, `date`, `files`) VALUES (?,?,?,?,?)");
            $stmt->execute([$ticket_id, $LogUser->user_id, $message, $current_time, $files]);

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in adding ticket" . $e->getMessage());
        }

        $output = new stdClass;
        $output->url = $Web->base_url() . '/support/';
        $output->message = "Ticket has been added";
        echo json_encode($output);
        break;

    case "add_reply":

        if (!$Web->is_isset("ticket_id")) Errors::response_404();
        $ticket_id = $Web->sanitize_text($_POST["ticket_id"]);
        if (!Ticket::is_ticket_id($ticket_id)) Errors::response_404();
        $Ticket = new Ticket($ticket_id);
        if ($Ticket->creator() !== $LogUser->user_id) Errors::response_404();
        if ($Ticket->status() == "closed") Errors::response("You can't add reply since the ticket has been closed");

        if (!$Web->is_isset("message", "files")) Errors::response("Invalid request");
        $message = $Web->sanitize_text($_POST["message"]);
        $files = $_POST["files"];
        if (!empty($files)) $files = json_decode($files);
        $Web->validate_post_length($_POST["message"], 3000, "Maximum Message length is 3000 ");

        if (!is_array($files)) Errors::response("Invalid details requested");
        if (count($files) > 5) Errors::response("Maximum 5 files are allowed");

        $current_time = $Web->current_time();
        $files = json_encode($files);

        try {
            $stmt = $db->prepare(" INSERT INTO $Web->support_ticket_messages_tbl (`ticket_id`, `replier`, `message`, `date`, `files`)  VALUES (?,?,?,?,?) ");
            $stmt->execute([$ticket_id, $LogUser->user_id, $message, $current_time, $files]);
        } catch (\Exception $e) {
            Errors::response_500("Error in replying");
        }

        $output = new stdClass;
        $output->message = "Reply has been added";
        echo json_encode($output);

        break;
}
