<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../db.php");
    }
    Errors::response_404();
}

use Ecommerce\Ticket;
use Jobs\Job;
use Jobs\Proposal;

if (!$Web->is_isset("case")) Errors::response_404();

$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();
if (!$Login->is_user_loggedin()) Errors::force_login();


$sql_details = array(
    'user' => $conn->userName,
    'pass' => $conn->password,
    'db'   => $conn->dbName,
    'host' => $conn->host
);
require_once $Web->include("php/library/datatable.class.php");


switch ($case) {

    case "profileReferralUsersTbl":
        $columns = array(
            array('db' => 'referred_to_user_id', 'dt' => 0),
            array(
                'db' => 'referral_income',
                'dt' => 1,
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->formatCurrency($d);
                }
            ),
            array(
                'db' => 'date',
                'dt' => 2,
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ),
            array(
                'db' => 'date',
                'dt' => 3,
                'formatter' => function ($status, $row) {
                    return '<span class="badge py-3 px-4 fs-7 badge-light-success">credit</span>';
                }
            )
        );

        $sql = "SELECT * FROM $Web->referral_tbl WHERE user_id = '{$LogUser->user_id}' ";
        $sql2 = "SELECT COUNT(*) FROM $Web->referral_tbl WHERE user_id = '{$LogUser->user_id}' ";

        
        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;
case "userLoginSessionTbl":

        $columns = array(
            array('db' => 'user_location', 'dt' => 0),
            array('db' => 'user_ip',  'dt' => 1),
            array(
                'db' => 'user_device',
                'dt' => 2,
                'formatter' => function ($d, $row) {
                    $user_os = $row["user_os"];
                    $user_device = $row["user_device"];
                    $user_browser = $row["user_browser"];
                    return $user_browser . '-' . $user_device . '-' . $user_os;
                }
            ),
            array(
                'db' => 'date',
                'dt' => 3,
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ),
            array(
                'db' => 'status',
                'dt' => 4,
                'formatter' => function ($d, $row) {
                    global $Login;
                    $session_id = $row["session_id"];
                    return $Login->is_session_id_valid($session_id) ?  '<div class="badge badge-light-success">active</div>' : '<div class="badge badge-light-danger">expired</div>';
                }
            ), array(
                'db' => 'session_id',
                'dt' => 5,
                'formatter' => function ($d, $row) {
                    global $LogUser;
                    global $Login;
                    $session_id = $row["session_id"];
                    $btn = $Login->is_session_id_valid($session_id) ? '<div data-id="' . $session_id . '" class="removeUserSession" ><i class="far text-danger fa-times-circle fs-2x"></i></div>' : 'Logged Out';
                    if ($session_id == $LogUser->session_id()) $btn = "This device";
                    return $btn;
                }
            )
        );


        $sql = "SELECT * FROM $Web->login_session_tbl WHERE user_id = '$LogUser->user_id'";
        $sql2 = "SELECT COUNT(*) FROM $Web->login_session_tbl WHERE user_id = '$LogUser->user_id' ";

        
        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;
}
