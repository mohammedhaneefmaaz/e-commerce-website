<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists('Errors::response_404')) {
        include("../../../db.php");
    }
    Errors::response_404();
}

if (!isset($_POST["case"]))  Errors::response_404();

$case = $_POST["case"];
if ($Web->is_empty($case)) Errors::response_404();

if (!$Login->is_user_loggedin()) Errors::force_login();

switch ($case) {

    case "get_address_form":
        if (!$Web->is_isset("address_id")) Errors::response("Invalid Request");
        $address_id = $Web->sanitize_text($_POST["address_id"]);
        if (!Address::is_address_id($address_id)) Errors::response("Address doesn't exist");
        $Address = new Address($address_id);
        if ($LogUser->user_id !== $Address->user()->user_id) Errors::response("Invalid Request");
        $output = new stdClass;
        $output->data = $Address->edit_form();
        echo json_encode($output);
        break;

    case "mark_address_primary":
        if (!$Web->is_isset("address_id")) Errors::response("Invalid Request");
        $address_id = $Web->sanitize_text($_POST["address_id"]);
        if (!Address::is_address_id($address_id)) Errors::response("Address doesn't exist");
        $Address = new Address($address_id);
        if ($LogUser->user_id !== $Address->user()->user_id) Errors::response("Invalid Request");

        $primary_id = Address::primary_id($LogUser->user_id);

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_address_tbl SET is_default = 'no' WHERE user_id = ? ");
            $stmt->execute([$LogUser->user_id]);

            $stmt = $db->prepare("UPDATE $Web->ecommerce_address_tbl SET is_default = 'yes' WHERE address_id = ? AND user_id = ? ");
            $stmt->execute([$address_id, $LogUser->user_id]);
        } catch (Exception $e) {
            Errors::response_500("Error in marking address" . $e->getMessage());
        }

        $Address = new Address($address_id);
        $output = new stdClass;
        $output->message = "Address has been marked primary";
        $output->pid = $primary_id;
        $output->pdata =  $Web->is_empty($primary_id) ? "" : (new Address($primary_id))->card();
        $output->data = $Address->card();
        echo json_encode($output);
        break;

    case "delete_address":
        if (!$Web->is_isset("address_id")) Errors::response("Invalid Request");
        $address_id = $Web->sanitize_text($_POST["address_id"]);
        if (!Address::is_address_id($address_id)) Errors::response("Address doesn't exist");
        $Address = new Address($address_id);
        if ($LogUser->user_id !== $Address->user()->user_id) Errors::response("Invalid Request");
        $stmt = $db->prepare("DELETE FROM $Web->ecommerce_address_tbl WHERE address_id = ? AND user_id = ? ");
        $stmt->execute([$address_id, $LogUser->user_id]);

        $output = new stdClass;
        $output->message = "Address has been deleted";
        echo json_encode($output);
        break;

    case "add_new_address":

        if (!$Web->is_isset("event", "address_id", "full_name", "mobile_number", "city", "area", "flat", "landmark", "state", "postcode", "address_type")) Errors::response("Invalid Request");

        $full_name = $Web->sanitize_text($_POST["full_name"]);
        $mobile_number = $Web->sanitize_text($_POST["mobile_number"]);
        $city = $Web->sanitize_text($_POST["city"]);
        $area = $Web->sanitize_text($_POST["area"]);
        $flat = $Web->sanitize_text($_POST["flat"]);
        $landmark = $Web->sanitize_text($_POST["landmark"]);
        $state = $Web->sanitize_text($_POST["state"]);
        $postcode = $Web->sanitize_text($_POST["postcode"]);
        $address_type = $Web->sanitize_text($_POST["address_type"]);
        $event = $Web->sanitize_text($_POST["event"]);
        $address_id = $Web->sanitize_text($_POST["address_id"]);

        $Web->validate_post_input($full_name, "alpha_numeric", "Full Name", true);
        $Web->validate_post_input($mobile_number, "mobile_number", "Mobile Number", true);
        $Web->validate_post_input($city, "", "City", true);
        $Web->validate_post_input($area, "", "Area", true);
        $Web->validate_post_input($landmark, "", "Landmark", true);
        $Web->validate_post_input($state, "", "State", true);
        $Web->validate_post_input($postcode, "number", "Post Code", true);

        $Web->validate_post_length($full_name, 40, "Maximum 40 characters are allowd in full name");
        $Web->validate_post_length($city, 100, "Maximum 100 characters are allowed in city");
        $Web->validate_post_length($area, 100, "Maximum 100 characters are allowed in area");
        $Web->validate_post_length($landmark, 100, "Maximum 100 characters are allowed in landmark");
        $Web->validate_post_length($state, 30, "Maximum 30 characters are allowd in state");

        if ($address_type !== "home" && $address_type !== "office") Errors::response("Invalid Address Type");
        if ($event !== "create" && $event !== "update") Errors::response("Invalid Event");

        $output = new stdClass;

        $clause = implode(',', array_fill(0, 10, '?'));

        if ($event == "create") {

            try {
                $stmt = $db->prepare("INSERT INTO $Web->ecommerce_address_tbl (`user_id`,`full_name`, `mobile_number`, `city`, `area`, `flat`, `landmark`, `state`, `postcode`, `address_type`) 
                VALUES ($clause) ");

                $stmt->execute([$LogUser->user_id, $full_name, $mobile_number, $city, $area, $flat, $landmark, $state, $postcode, $address_type]);
            } catch (Exception $e) {
                Errors::response_500("Error in adding address" . $e->getMessage());
            }
            $Address = new Address(($db->lastInsertId()));
            $output->message = "Address has been created";
        } else {
            if (!Address::is_address_id($address_id)) Errors::response("Address doesn't exist");
            $Address = new Address($address_id);
            if ($LogUser->user_id !== $Address->user()->user_id) Errors::response("Invalid Request");

            try {

                $stmt = $db->prepare("UPDATE $Web->ecommerce_address_tbl SET full_name = ?, mobile_number = ?, city = ?, area = ?, flat = ?,landmark = ?, state = ?,postcode = ?,address_type = ? WHERE address_id = ? AND user_id = ? ");

                $stmt->execute([$full_name, $mobile_number, $city, $area, $flat, $landmark, $state, $postcode, $address_type, $address_id, $LogUser->user_id]);
                $Address->update();
            } catch (Exception $e) {
                Errors::response_500("Error in updating address" . $e->getMessage());
            }
            $output->message = "Address has been updated";
        }

        $output->data = $Address->card();
        echo json_encode($output);
        break;

    case "remove_user_session":

        if (!$Web->is_isset("session_id")) Errors::response("Invalid Request");
        $session_id = $Web->sanitize_text($_POST["session_id"]);
        if (!$Login->is_session_id_valid($session_id)) Errors::response("Invalid Session Id");

        try {

            $stmt = $db->prepare("SELECT * FROM $Web->login_session_tbl WHERE user_id = ? AND session_id = ? ");
            $stmt->execute([$LogUser->user_id, $session_id]);

            if (!$stmt->rowCount()) Errors::response("Invalid Request");

            $stmt = $db->prepare("UPDATE $Web->login_session_tbl SET status = 'expired' WHERE user_id = ?  AND session_id = ? AND status = 'active' ");
            $stmt->execute([$LogUser->user_id, $session_id]);
        } catch (\Exception $e) {
            Errors::response_500($e->getMessage());
        }


        $output = new stdClass;
        $output->message = "Session removed successfully";
        echo json_encode($output);

        break;

    case "remove_all_session":
        if (!$Web->is_isset("event")) Errors::response("Invalid Request");

        try {
            $stmt = $db->prepare("UPDATE $Web->login_session_tbl SET status = 'expired' WHERE user_id = ?  AND session_id != ? AND status = 'active' ");
            $stmt->execute([$LogUser->user_id, $LogUser->session_id()]);
        } catch (Exception $e) {
            Errors::response_500("Error in removing all sessions" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "All login sessions has been removed";
        echo json_encode($output);

        break;

    case "update_profile_details":

        if (!$Web->is_isset("avatar_image_id", "first_name", "last_name", "contact_number", "contact_email")) {
            Errors::response("Invalid Request");
        }

        $avatar_image_id = $Web->sanitize_text($_POST["avatar_image_id"]);
        $first_name = $Web->sanitize_text($_POST["first_name"]);
        $last_name = $Web->sanitize_text($_POST["last_name"]);
        $contact_number = $Web->sanitize_text($_POST["contact_number"]);
        $contact_email = $Web->sanitize_text($_POST["contact_email"]);

        if ($Web->is_empty($avatar_image_id)) Errors::response("Please choose avatar image");
        if (!$Web->is_file_id($avatar_image_id) && $avatar_image_id != '0') Errors::response("Avatar Image is invalid");

        $Web->validate_post_input($first_name, "alpha", "First Name", true);
        $Web->validate_post_input($last_name, "alpha", "Last Name", true);
        $Web->validate_post_input($contact_number, "mobile_number", "Contact Number", true);
        $Web->validate_post_input($contact_email, "email", "Contact Email", true);

        try {
            $avatar_image_id = $avatar_image_id == 0 ? NULL : $avatar_image_id;
            $stmt = $db->prepare("UPDATE $Web->users_tbl SET first_name = ?, last_name = ?, avatar_id = ?,
                contact_number = ?,contact_email = ?  WHERE user_id = ? ");

            $stmt->execute([$first_name, $last_name, $avatar_image_id, $contact_number, $contact_email, $LogUser->user_id]);
        } catch (Exception $e) {
            Errors::response_500("Error in updating profile details" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Profile details has been updated";
        echo json_encode($output);

        break;

    case "remove_profile":
        if (!$Web->is_isset("remove_profile")) Errors::response("Invalid Request");
        $remove_profile = $Web->sanitize_text($_POST["remove_profile"]);
        if ($remove_profile != "1") Errors::response("Invalid Request");

        $output = new stdClass();
        $output->message = "Profile has been updated";
        $output->image_id = 0;
        $output->image_src = $Web->get_assets("images/web/avatar.png");
        echo json_encode($output);

        break;

    case "add_password":
        if (!$Web->is_isset("password", "confirm_password")) Errors::response("Invalid Request");

        $email_login = $LogUser->email_login();
        if ($email_login == "on") Errors::response("Password is already added");

        $password = $Web->sanitize_text($_POST["password"]);
        $confirm_password = $Web->sanitize_text($_POST["confirm_password"]);
        if ($password !== $confirm_password) Errors::response("Password and its confirm are not matching");


        $password = password_hash($password, PASSWORD_BCRYPT);
        try {
            $stmt = $db->prepare("UPDATE $Web->users_tbl SET password = ?, email_login = 'on' WHERE user_id = ? ");
            $stmt->execute([$password, $LogUser->user_id]);
        } catch (Exception $e) {
            Errors::response_500("Error In adding Password" . $e->getMessage());
        }
        $output = new stdClass;
        $output->message = "Password added successfully";
        echo json_encode($output);
        break;

    case "change_password":

        if (!$Web->is_isset("current_password", "new_password", "confirm_password")) Errors::response("Invalid Request");
        $current_password = $Web->sanitize_text($_POST["current_password"]);
        $new_password = $Web->sanitize_text($_POST["new_password"]);
        $confirm_password = $Web->sanitize_text($_POST["confirm_password"]);

        $email_login = $LogUser->email_login();
        if ($email_login == "off") Errors::response("Password can't be changed because this email is not associated with email login");

        $db_password = $LogUser->password();
        $pass_decode = password_verify($current_password, $db_password);
        if (!$pass_decode) Errors::response("Current Password is invalid");
        if ($new_password == $current_password) Errors::response("New Password must not be current password");
        if ($new_password !== $confirm_password) Errors::response("New Password and its confirm are not matching");

        $password = password_hash($new_password, PASSWORD_BCRYPT);

        try {
            $stmt = $db->prepare("UPDATE $Web->users_tbl SET password = ?, email_login = 'on' WHERE user_id = ? ");
            $stmt->execute([$password, $LogUser->user_id]);
        } catch (Exception $e) {
            Errors::response_500("Error In updating Password" . $e->getMessage());
        }

        $Login->logout_with_current($LogUser->user_id);
        $Login->send_change_password_successfull_email($LogUser->user_id);
        $output = new stdClass;
        $output->message = "Password changed successfull";
        echo json_encode($output);

        break;

    case "twoStepVerificationCodeConfirm":
        if (!$Web->is_isset("code")) Errors::response("Invalid Request");
        $code = $Web->sanitize_text($_POST["code"]);
        if ($code != '1') Errors::response("Invalid Request");

        $email_login = $LogUser->email_login();
        if ($email_login == "off") Errors::response("2 Step Verification can't be enabled");

        $otp = $Login->get_new_otp($LogUser->email(), "enable_loginverification");
        if (!$otp) Errors::response("Otp sending failed");


        $send_otp = $Login->send_enable_login_verification_code($LogUser->user_id, $otp);
        if (!$send_otp)  Errors::response("Otp sending failed");

        $login_verification = $LogUser->login_verification();
        $header = ($login_verification == "on") ? "Disable Two Step Verification" : "Enable Two Step Verification";
        $output = new stdClass;
        $output->email_sent_to = $LogUser->email();
        $output->message  =  "Otp sending successfull";
        $output->header  =  $header;
        echo json_encode($output);

        break;

    case "enable_login_verification":

        if (!$Web->is_isset("1", "2", "3", "4", "5", "6")) Errors::response("Invalid Request");

        $otp = $Web->sanitize_text($_POST["1"]);
        $otp .= $Web->sanitize_text($_POST["2"]);
        $otp .= $Web->sanitize_text($_POST["3"]);
        $otp .= $Web->sanitize_text($_POST["4"]);
        $otp .= $Web->sanitize_text($_POST["5"]);
        $otp .= $Web->sanitize_text($_POST["6"]);

        $Web->validate_post_input($otp, "number", "Otp", true);
        if (strlen($otp) != "6") Errors::response("Invalid Otp Length");
        if (!$Login->is_valid_otp($otp, $LogUser->email(), "enable_loginverification"))  Errors::response("Otp is invalid");
        $email_login = $LogUser->email_login();
        if ($email_login == "off") Errors::response("2 Step Verification can't be enabled");

        $login_verification = $LogUser->login_verification();
        $output = new stdClass;

        if ($login_verification == "on") {
            try {
                $stmt = $db->prepare("UPDATE $Web->users_tbl SET login_verification = 'off' WHERE user_id = ? ");
                $stmt->execute([$LogUser->user_id]);
            } catch (Exception $e) {
                Errors::response_500("Error in disable Two Step Verification" . $e->getMessage());
            }

            $output->message  =  "2 Step Verification Disabled";
            $output->btn_text = "Enable";
        } else {

            try {
                $stmt = $db->prepare("UPDATE $Web->users_tbl SET login_verification = 'on' WHERE user_id = ? ");
                $stmt->execute([$LogUser->user_id]);
            } catch (Exception $e) {
                Errors::response_500("Error in enable Two Step Verification" . $e->getMessage());
            }

            $output->message  =  "2 Step Verification Enabled";
            $output->btn_text = "Disable";
        }
        $Login->update_otp_status($otp, $LogUser->email(), "enable_loginverification");
        echo json_encode($output);
        break;
}
