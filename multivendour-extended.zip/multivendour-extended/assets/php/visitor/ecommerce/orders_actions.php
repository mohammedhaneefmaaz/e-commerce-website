<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        include("../../../../db.php");
    }
    Errors::response_404();
}

use Ecommerce\Order;

if (!$Web->is_isset("case")) Errors::response_404();
$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();

if (!$Login->is_user_loggedin()) Errors::force_login();

switch ($case) {

    case "cancel_order":
        if (!$Web->is_isset("order_id", "cancellation_reason")) Errors::response("Invalid Request");
        $order_id = $Web->sanitize_text($_POST["order_id"]);
        $reason = $Web->sanitize_text($_POST["cancellation_reason"]);

        $Web->validate_post_input($reason, "", "Reason", true);
        $Web->validate_post_length($_POST["cancellation_reason"], 3000, "Maximum Cancellation reason length is 3000 ");

        if (!Order::is_order_id($order_id)) Errors::response($order_id . " Order Id doesn't exist");
        $Order = new Order($order_id);
        if ($Order->buyer()->user_id !== $LogUser->user_id) Errors::response_404();
        if (!$Order->can_cancel_order()) Errors::response("Sorry the order can't be cancelled");

        $quantity = $Order->quantity();
        $variation_id = $Order->variation_id();
        $svariation_id = $Order->svariation_id();
        $product_id = $Order->product_id();
        $listing_id = $Order->product()->listing_id();

        try {
            $db->beginTransaction();


            $refund_status = $Order->can_refund() ? "pending" : "none";
            $refund_inited_on = $Order->can_refund() ? $Web->current_time() : NULL;

            $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET status = 'CANCELLED', cancelled_reason = ?, cancelled_on = ?, refund_status = ?, refund_inited_on = ? WHERE order_id = ? AND buyer_id = ?  ");
            $stmt->execute([$reason, $Web->current_time(), $refund_status,$refund_inited_on, $order_id, $LogUser->user_id]);

            $stmt = $db->prepare("UPDATE $Web->ecommerce_listing_variations_tbl SET stock = stock + ? WHERE variation_id = ? AND svariation_id = ? AND listing_id = ? ");
            $stmt->execute([$quantity, $variation_id, $svariation_id, $listing_id]);

            $stmt = $db->prepare("UPDATE $Web->ecommerce_variations_tbl SET stock = stock + ? WHERE variation_id = ? AND svariation_id = ? AND product_id = ? ");
            $stmt->execute([$quantity, $variation_id, $svariation_id, $product_id]);

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in cancelling order" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Order have been cancelled";
        echo json_encode($output);
        break;


    case "return_order":
        if (!$Web->is_isset("order_id", "return_action", "return_reason", "images")) Errors::response("Invalid Request");
        $order_id = $Web->sanitize_text($_POST["order_id"]);
        $return_action = $Web->sanitize_text($_POST["return_action"]);
        $return_reason = $Web->sanitize_text($_POST["return_reason"]);
        $images = $Web->sanitize_text($_POST["images"]);

        if (!is_array($images)) Errors::response("Images are invalid");
        if ((count($images) < 2) || count($images) > 8) Errors::response("Invalid images number");

        $Web->validate_post_input($return_reason, "", "Reason", true);
        $Web->validate_post_length($_POST["return_reason"], 3000, "Maximum Return reason length is 3000 ");
        if ($return_action !== "replacement" && $return_action !== "return") Errors::response("Invalid Return Action");

        if (!Order::is_order_id($order_id)) Errors::response($order_id . " Order Id doesn't exist");
        $Order = new Order($order_id);
        if ($Order->buyer()->user_id !== $LogUser->user_id) Errors::response_404();

        $output = new stdClass;
        $images = json_encode($images);

        try {
            switch ($return_action) {
                case "replacement";
                    if (!$Order->can_apply_replacement()) Errors::response('Replacement not applicable');

                    $stmt = $db->prepare("INSERT INTO $Web->ecommerce_replacement_orders_tbl ( `order_id`, `requested_date`, `replacement_reason`, `status`,`images`)  VALUES (?,?,?,'initiated',?) ");
                    $stmt->execute([$order_id, $Web->current_time(), $return_reason, $images]);
                    $output->message = "Order replacement request has been sent";

                    break;
                case "return";
                    if (!$Order->can_apply_return()) Errors::response('Return not applicable');

                    $stmt = $db->prepare("INSERT INTO $Web->ecommerce_return_orders_tbl ( `order_id`, `requested_date`, `return_reason`, `status`,`images`) VALUES (?,?,?,'initiated',?) ");
                    $stmt->execute([$order_id, $Web->current_time(), $return_reason, $images]);

                    $output->message = "Order return request has been sent ";
                    break;
            }
        } catch (\Exception $e) {
            Errors::response_500("Error in  return" . $e->getMessage());
        }

        echo json_encode($output);
        break;

    case "cancel_return":

        if (!$Web->is_isset("order_id")) Errors::response_404();
        $order_id = $Web->sanitize_text($_POST["order_id"]);

        if (!Order::is_order_id($order_id)) Errors::response($order_id . " Order Id doesn't exist");
        $Order = new Order($order_id);
        if ($Order->buyer()->user_id !== $LogUser->user_id) Errors::response_404();
        if (!$Order->has_returned_requested()) Errors::response("Invalid request");

        $Return  = $Order->return_order();
        if (!$Return->can_cancel_return()) Errors::response("Return can't be cancelled");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_return_orders_tbl SET status = 'cancelled', cancelled_on = ? WHERE order_id =  ? ");
            $stmt->execute([$Web->current_time(), $order_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in cancelling order return" . $e->getMessage());
        }
        $output = new stdClass;
        $output->message = "Order return has been cancelled";
        echo json_encode($output);
        break;

    case "cancel_replacement":

        if (!$Web->is_isset("order_id")) Errors::response_404();
        $order_id = $Web->sanitize_text($_POST["order_id"]);

        if (!Order::is_order_id($order_id)) Errors::response($order_id . " Order Id doesn't exist");
        $Order = new Order($order_id);
        if ($Order->buyer()->user_id !== $LogUser->user_id) Errors::response_404();
        if (!$Order->has_replacement_requested()) Errors::response("Invalid request");

        $Replacement  = $Order->replacement_order();
        if (!$Replacement->can_cancel_replacement()) Errors::response("Replacement can't be cancelled");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_replacement_orders_tbl SET status = 'cancelled', cancelled_on = ? WHERE order_id =  ? ");
            $stmt->execute([$Web->current_time(), $order_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in cancelling order replacement" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Order replacement has been cancelled";
        echo json_encode($output);
        break;
}
