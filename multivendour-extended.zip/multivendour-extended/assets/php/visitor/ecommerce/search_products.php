<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        include("../../../../db.php");
    }
    Errors::response_404();
}

use Ecommerce\Basic;
use Ecommerce\Category;
use Ecommerce\Home;
use Ecommerce\Product;


$category_filter = $_POST["category"] ?? '';
$searchKeyword = $_POST["q"] ?? '';
$filter_details = $_POST["filters"] ?? '{}';
$current_min_price = $_POST["min_price"] ?? 0;
$current_max_price = $_POST["max_price"] ?? 0;
$rating = $_POST["rating"] ?? 0;
$page = $_POST["page"] ?? 1;
$sort_by = $_POST["sort"] ?? "relavance";


$filter_details = json_decode($filter_details, true);
$rating = json_decode($rating);
$Web->addSearchHistory($searchKeyword);
if (!is_array($filter_details)) $filter_details = [];
if (!is_array($rating)) $rating = [];

$products = '';
$pagination = "";
$search_info = "";
$total_rows = 0;

$group_by_sql = " GROUP BY variation_id ";
$order_by_sql = " ORDER BY category DESC";
$filter_card_html = "";
$min_price = 0;
$max_price = 0;

$price_sql = "";
$rating_sql = "";
$details_sql = "";
$category_sql = "";
$search_sql = "";

$price_sql_param = [];
$rating_sql_param = [];
$details_sql_param = [];
$category_sql_param = [];
$search_sql_param = [];

$params = [];

$primary_sql = "SELECT product_id,variation_id,svariation_id,details,price,
        MIN(price) as MIN_PRICE,
        MAX(price) as MAX_PRICE,
        (SELECT IFNULL(SUM(quantity),0) FROM $Web->ecommerce_orders_tbl WHERE $Web->ecommerce_orders_tbl.variation_id = $Web->ecommerce_variations_tbl.variation_id ) as product_sells,
        (SELECT IFNULL(SUM(views),0) FROM $Web->ecommerce_search_relavance_tbl WHERE $Web->ecommerce_search_relavance_tbl.variation_id = $Web->ecommerce_variations_tbl.variation_id ) as relevance,
        (SELECT IFNULL(AVG(rating),0) FROM $Web->ecommerce_reviews_tbl WHERE product_id = $Web->ecommerce_variations_tbl.product_id) as avg_rating,
        (SELECT category_id FROM $Web->ecommerce_products_tbl WHERE product_id = $Web->ecommerce_variations_tbl.product_id) as category_id,
        (SELECT COUNT(category_id) FROM $Web->ecommerce_products_tbl WHERE product_id = $Web->ecommerce_variations_tbl.product_id) as category 
         FROM $Web->ecommerce_variations_tbl WHERE status = 'active' ";

if (!empty($searchKeyword)) {
    $search_sql .= " ";
    $temp_searchKeyword = explode(" ", $searchKeyword);
    foreach ($temp_searchKeyword as $count => $item) {
        if ($count == 0) $search_sql .= " AND (product_name LIKE ? OR JSON_EXTRACT(tags,'$[*].value') LIKE ?  ";
        else $search_sql .= " AND product_name LIKE ? OR JSON_EXTRACT(tags,'$[*].value') LIKE ?  ";
        $search_sql_param[] = "%$item%";
        $search_sql_param[] = "%$item%";
    }
    $search_sql .= ")";
}


if (!empty($current_max_price)) {
    $price_sql =  " AND (price BETWEEN ? AND ?) ";
    $price_sql_param[] = $current_min_price;
    $price_sql_param[] = $current_max_price;
}

if (!empty($filter_details)) {
    foreach ($filter_details as $detail_id => $detailValues) {
        if (!Category::is_a_detail_id($detail_id)) return;
        $in = str_repeat("?,", count($detailValues) - 1) . "?";
        $details_sql .= " AND JSON_UNQUOTE(JSON_EXTRACT(details,'$.$detail_id')) IN ($in) ";
        $details_sql_param = array_merge($details_sql_param, $detailValues);
    }
}


$having = false;

if (!empty($category_filter) && Category::is_category_id($category_filter)) {
    $Category = new Category($category_filter);
    if ($Category->is_last_category()) {
        $category_sql .= " HAVING category_id = ? ";
        $category_sql_param[] = $category_filter;
        $having = true;
    } else {
        $categories_array = Basic::categories_filter_ids($category_filter);
        $in = str_repeat("?,", count($categories_array) - 1) . "?";
        $category_sql .=  " HAVING category_id IN ($in) ";
        $category_sql_param = array_merge($category_sql_param, $categories_array);
        $having = true;
    }
} else {
    $category_sql .= "HAVING category_id > 0";
}


if (!empty($rating)) {
    $count = 0;
    foreach ($rating as $rating_val) {
        $max_rating = $rating_val == 4 ? 5 : $rating_val + 0.9;
        $rating_sql .= $count == 0 ?  " AND ( avg_rating BETWEEN ? AND ? > 0  " :  " OR  avg_rating BETWEEN ? AND ? > 0 ";
        $rating_sql_param[] = $rating_val;
        $rating_sql_param[] = $max_rating;
        $having = true;
        $count++;
    }
    $rating_sql .= ')';
}



$sql = $primary_sql . $search_sql . $price_sql . $details_sql . $group_by_sql . $category_sql . $rating_sql . $order_by_sql;
$params = array_merge($search_sql_param, $price_sql_param, $details_sql_param, $category_sql_param, $rating_sql_param);

$stmt = $db->prepare($sql);
$stmt->execute($params);

if ($stmt->rowCount()) {

    $used_details = [];
    $query = [];
    $searchQuery = "";
    if (!empty($searchKeyword)) $query["q"] = $searchKeyword;
    if (!empty($minimum_price)) $query["min_price"] = $minimum_price;
    if (!empty($maximum_price)) $query["max_price"] = $maximum_price;
    if (!empty($filter_details)) $query["details"] = json_encode($filter_details);
    if (!empty($rating)) $query["rating"] = json_encode($rating);
    foreach ($query as $key => $value) {
        $searchQuery .= "&$key=$value";
    }

    $url = $Web->base_url() . '/product/search?' . $searchQuery;
    $total_rows = $stmt->rowCount();
    $records_per_page = 20;
    $total_pages = ceil($total_rows / $records_per_page);
    if ($page > $total_pages) $page = $total_pages;
    if (!($page > 0)) $page = 1;
    $offset = ($page - 1) * $records_per_page;
    $pagination = !($total_pages > 1) ? "" : $Web->insert_pagination($url, $page, $total_pages, true);
    $web_url = $Web->base_url() . '/product/search?q=' . $searchKeyword . '&page=' . $page;


    $row = $stmt->fetch();
    if (empty($category_filter)) {
        $category_filter = $row->category_id;
        $category_sql = " HAVING category_id = ? ";
        $category_sql_param = [];
        $category_sql_param[] = $category_filter;
    }

    switch ($sort_by) {
        case "price_asc":
            $order_by_sql = " ORDER BY price ASC";
            break;
        case "price_desc":
            $order_by_sql = " ORDER BY price DESC";
            break;
        case "newest":
            $order_by_sql = " ORDER BY date_created DESC";
            break;
        case "popularity":
            $order_by_sql = " ORDER BY product_sells DESC";
            break;
        case "relevance":
            $order_by_sql = " ORDER BY relevance DESC";
            break;
    }

    $sql = $primary_sql . $search_sql . $price_sql . $details_sql . $group_by_sql . $category_sql . $rating_sql . $order_by_sql;

    $params = array_merge($search_sql_param, $price_sql_param, $details_sql_param, $category_sql_param, $rating_sql_param);


    $Category = new Category($category_filter);

    $sql .= " LIMIT $offset,$records_per_page";
    $final_stmt = $db->prepare($sql);
    $final_stmt->execute($params);

    while ($row = $final_stmt->fetch()) {
        $product_id = $row->product_id;
        $variation_id = $row->variation_id;
        $svariation_id = $row->svariation_id;
        $Product = new Product($product_id);
        $products .= $Product->card($variation_id, $svariation_id, $searchKeyword);
    }

    if (empty($searchKeyword)) $searchKeyword = $Category->category();
    $search_info = "Showing page $page of $total_rows results for \"$searchKeyword\" ";


    $Filter = new Home();
    $filter_data = $Filter->GET_FILTER_DATA($primary_sql, $search_sql, $price_sql, $details_sql, $category_sql, $rating_sql, $current_min_price, $current_max_price, $rating, $filter_details, $params);
    $filter_card = $filter_data->card;


    $category_card = Basic::filter_category_card($category_filter);
    if (!empty($category_card)) $filter_card["category"] = '<div class="text-primary-alt filter-card">
                                    <div class="border-bottom card card-flush ">
                                        <div data-bs-toggle="collapse" data-bs-target="#category_toggle" class="cursor-pointer rotate collapsible card-header">
                                            <div class="card-title">
                                                <h6 class="text-uppercase text-primary-alt">Categories</h6>
                                            </div>
                                            <div class="card-toolbar rotate-180">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#3e5569">
                                                    <path d="M12.5657 11.3657L16.75 15.55C17.1642 15.9643 17.8358 15.9643 18.25 15.55C18.6642 15.1358 18.6642 14.4643 18.25 14.05L12.7071 8.50716C12.3166 8.11663 11.6834 8.11663 11.2929 8.50715L5.75 14.05C5.33579 14.4643 5.33579 15.1358 5.75 15.55C6.16421 15.9643 6.83579 15.9643 7.25 15.55L11.4343 11.3657C11.7467 11.0533 12.2533 11.0533 12.5657 11.3657Z" />
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="collapse show" id="category_toggle">
                                            <div id="category_body" class="pt-0 fs-6 card-body">
                                                ' . $category_card . '
                                            </div>
                                        </div>
                                    </div>
                                </div>';

    foreach ($filter_card as $key => $value) {
        if (!empty($filter_details) && Category::is_a_detail_id($key)) {
            $temp_details_sql = "";
            $temp_details_sql_param = [];
            foreach ($filter_details as $detail_id => $detailValues) {
                if ($key != $detail_id) {
                    $in = str_repeat("?,", count($detailValues) - 1) . "?";
                    $temp_details_sql .= " AND JSON_UNQUOTE(JSON_EXTRACT(details,'$.$detail_id')) IN ($in) ";
                    $temp_details_sql_param = array_merge($temp_details_sql_param, $detailValues);
                }
            }

            $params = array_merge($search_sql_param, $price_sql_param, $temp_details_sql_param, $category_sql_param, $rating_sql_param);

            $new_filter_data = $Filter->GET_FILTER_DATA($primary_sql, $search_sql, $price_sql, $temp_details_sql, $category_sql, $rating_sql, $current_min_price, $current_max_price, $rating, $filter_details, $params);

            $new_filter_card = $new_filter_data->card;


            $value = $new_filter_card[$key];
        }
        $filter_card_html .= $value;
    }

    $min_price = $filter_data->min_price;
    $max_price = $filter_data->max_price;

    if (!empty($current_min_price) && !empty($current_max_price)) {
        $price_sql = "";

        $params = array_merge($search_sql_param, $details_sql_param, $category_sql_param, $rating_sql_param);

        $new_filter_data = $Filter->GET_FILTER_DATA($primary_sql, $search_sql, $price_sql, $details_sql, $category_sql, $rating_sql, $current_min_price, $current_max_price, $rating, $filter_details, $params);
        $min_price = $new_filter_data->min_price;
        $max_price = $new_filter_data->max_price;
    }

    if ($current_min_price < $min_price) $current_min_price = $min_price;
    if ($current_max_price > $max_price) $current_max_price = $max_price;
} else {
    $products = '<div class="justify-align-center w-100 h-100 bg-white p-4 flex-column">
                                <img class="mh-300px img-fluid" src="' . $Web->get_assets("images/web/empty-search.png") . '" alt="">
                                <h1>Sorry, no results found!</h1>
                                <p class="fs-bold fs-4">Please check the spelling or try searching for something else:)</p>
                            </div>';
}



$output = new stdClass;
$output->search_info = $search_info;
$output->products = $products;
$output->filters = $filter_card_html;
$output->pagination = $pagination;
$output->result_count = $total_rows;
$output->min_price = $min_price;
$output->max_price = $max_price;
$output->current_min_price = $current_min_price;
$output->current_max_price = $current_max_price;
$output->currency = $Web->currency();
echo json_encode($output);
