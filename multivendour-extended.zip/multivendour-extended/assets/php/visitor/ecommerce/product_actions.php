<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        include("../../../../db.php");
    }
    Errors::response_404();
}

use Ecommerce\Product;
use Ecommerce\Question;
use Ecommerce\Review;

if (!$Web->is_isset("case")) Errors::response_404();

$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();

if (!$Login->is_user_loggedin() && $case !== "fetch_rating_content") Errors::force_login();

switch ($case) {

    case "fetch_rating_content":

        if (!$Web->is_isset("review_id", "product_id")) Errors::response("Invalid Request");
        $review_id = $Web->sanitize_text($_POST["review_id"]);
        $product_id = $Web->sanitize_text($_POST["product_id"]);

        if (!Product::is_product_id($product_id))  Errors::response("Product does not exist");
        if (!Review::is_review_id($product_id, $review_id))  Errors::response("Review does not exist");

        $Review = new Review($product_id, $review_id);

        $lightbox = $Review->ratingPreviewModal();
        $output = new stdClass;
        $output->lightbox = $lightbox;
        echo json_encode($output);
        break;

    case "delete_review":
        if (!$Web->is_isset("review_id", "product_id")) Errors::response("Invalid Request");
        $review_id = $Web->sanitize_text($_POST["review_id"]);
        $product_id = $Web->sanitize_text($_POST["product_id"]);

        if (!Product::is_product_id($product_id))  Errors::response("Product does not exist");
        if (!Review::is_review_id($product_id, $review_id))  Errors::response("Review does not exist");

        $Review = new Review($product_id, $review_id);
        if ($Review->reviewer()->user_id !== $LogUser->user_id) Errors::response("Review does not belongs to you");

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_reviews_tbl WHERE review_id = ? AND product_id = ? AND reviewed_by = ? ");
            $stmt->execute([$review_id, $product_id, $LogUser->user_id]);

            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_reviews_rating_tbl WHERE review_id = ? AND product_id = ?  ");
            $stmt->execute([$review_id, $product_id]);

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in deleting review");
        }


        $Product = new Product($product_id);
        $output = new stdClass;
        $output->count = $Product->reviews_count();
        $output->message = "Review deleted successfully";
        echo json_encode($output);
        break;

    case "rate_review":
        if (!$Web->is_isset("review_id", "product_id", "event")) Errors::response("Invalid Request");

        $review_id = $Web->sanitize_text($_POST["review_id"]);
        $product_id = $Web->sanitize_text($_POST["product_id"]);
        $event = $Web->sanitize_text($_POST["event"]);

        if (!Product::is_product_id($product_id))  Errors::response("Product does not exist");
        if ($event !== "like" && $event !== "dislike") Errors::response("Invalid Request");
        if (!Review::is_review_id($product_id, $review_id))  Errors::response("Review does not exist");

        $Review = new Review($product_id, $review_id);
        if ($event == "like") {
            $rating_action = "like";
            $message = "Review liked successfully";
            if ($Review->has_user_liked($LogUser->user_id)) {
                $rating_action = "liked";
                $message = "Like removed from review successfully";
            }
        } else {
            $rating_action = "dislike";
            $message = "Review disliked successfully";
            if ($Review->has_user_disliked($LogUser->user_id)) {
                $rating_action = "disliked";
                $message = "Dislike removed from review successfully";
            }
        }

        try {
            $db->beginTransaction();

            switch ($rating_action) {
                case 'like':
                case 'dislike':

                    $stmt = $db->prepare("DELETE FROM $Web->ecommerce_reviews_rating_tbl WHERE product_id = ? AND review_id = ? AND user_id = ? ");
                    $stmt->execute([$product_id, $review_id, $LogUser->user_id]);

                    $stmt =  $db->prepare("INSERT INTO $Web->ecommerce_reviews_rating_tbl (`review_id`, `product_id`, `user_id`, `action`) VALUES (?,?,?,?) ");
                    $stmt->execute([$review_id, $product_id, $LogUser->user_id, $rating_action]);

                    break;

                case 'liked':
                case 'disliked':

                    $stmt = $db->prepare("DELETE FROM $Web->ecommerce_reviews_rating_tbl WHERE product_id = ? AND review_id = ? AND user_id = ? ");
                    $stmt->execute([$product_id, $review_id, $LogUser->user_id]);

                    break;
            }
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Something went wrong".$e->getMessage().$e->getLine());
        }


        $output = new stdClass;
        $output->likes = $Review->likes();
        $output->dislikes = $Review->dislikes();
        $output->process = $rating_action;
        $output->message = $message;
        echo json_encode($output);

        break;

    case "add_review":
        if (!$Web->is_isset("rating", "event", "review", "images", "product_id", "variation_id", "svariation_id")) Errors::response("Invalid Request");

        $rating = $Web->sanitize_text($_POST["rating"]);
        $event = $Web->sanitize_text($_POST["event"]);
        $review = $Web->sanitize_text($_POST["review"]);
        $review = trim($review);
        $images = $_POST["images"];
        $images = json_decode($images);
        if (!is_array($images)) Errors::response("Invalid Request");
        if (count($images) > 5) Errors::response("Maximum 5 images are allowed");
        $product_id = $Web->sanitize_text($_POST["product_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);
        $images = json_encode($images);

        $Web->validate_post_length($_POST["review"], 3000, "Maximum Review length is 3000");
        $Web->validate_post_input($review, "", "Review", true);

        if (!Product::is_product_id($product_id)) Errors::response("Product doesn't exist");
        $Product = new Product($product_id);
        if (!$Product->is_svariation_id($variation_id, $svariation_id)) Errors::response("Product doesn't exist");
        if (!$Product->has_user_purchased_product($LogUser->user_id)) Errors::response("Sorry! You are not allowed to review this product since you haven't purchased it");

        if (!($rating > 0 && $rating < 6)) Errors::response("Invalid rating");
        if ($event !== "create" && $event !== "update") Errors::response("Invalid Event");

        $output = new stdClass;
        $output->url = $Product->url($variation_id, $svariation_id);

        try {

            if ($event == "create") {
                if ($Product->has_user_reviewed($LogUser->user_id)) Errors::response("Sorry! You are not allowed to review this product since you have already reviewed it");

                $stmt = $db->prepare("INSERT INTO $Web->ecommerce_reviews_tbl (`product_id`,`reviewed_by`, `rating`, `review`, `images`, `date`) 
                        VALUES (?,?,?,?,?,? ) ");
                $stmt->execute([$product_id, $LogUser->user_id, $rating, $review, $images, $Web->current_time()]);

                $review_id = $db->lastInsertId();
                $output->message = "Review has been added";
            } else {
                if (!$Web->is_isset("review_id")) Errors::response("Invalid Request");
                $review_id = $Web->sanitize_text($_POST["review_id"]);
                if (!Review::is_review_id($product_id, $review_id)) Errors::response("Review doesn't exist");
                $Review = new Review($product_id, $review_id);
                if ($Review->reviewer()->user_id !== $LogUser->user_id) Errors::response_404();

                $stmt = $db->prepare("UPDATE $Web->ecommerce_reviews_tbl  SET rating = ?,review = ?,images = ? WHERE review_id = ? AND product_id = ? AND reviewed_by = ?  ");
                $stmt->execute([$rating, $review, $images, $review_id, $product_id, $LogUser->user_id]);

                $output->message = "Review has been updated";
            }
        } catch (\Exception $e) {
            Errors::response_500("Error in review");
        }


        echo json_encode($output);
        break;

    case "rate_answer":
        if (!$Web->is_isset("question_id", "answer_id", "product_id", "event")) Errors::response("Invalid Request");

        $question_id = $Web->sanitize_text($_POST["question_id"]);
        $answer_id = $Web->sanitize_text($_POST["answer_id"]);
        $product_id = $Web->sanitize_text($_POST["product_id"]);
        $event = $Web->sanitize_text($_POST["event"]);

        if (!Product::is_product_id($product_id))  Errors::response("Product does not exist");
        if ($event !== "like" && $event !== "dislike") Errors::response("Invalid Request");
        if (!Question::is_question_id($product_id, $question_id))  Errors::response("Question does not exist");
        $Question = new Question($product_id, $question_id);
        if (!$Question->is_answer_id($answer_id)) Errors::response("Answer doesn't exist");

        if ($event == "like") {
            $rating_action = "like";
            $message = "Review liked successfully";
            if ($Question->has_user_liked($LogUser->user_id, $answer_id)) {
                $rating_action = "liked";
                $message = "Like removed from review successfully";
            }
        } else {
            $rating_action = "dislike";
            $message = "Review disliked successfully";
            if ($Question->has_user_disliked($LogUser->user_id, $answer_id)) {
                $rating_action = "disliked";
                $message = "Dislike removed from review successfully";
            }
        }

        try {
            switch ($rating_action) {
                case 'like':
                case 'dislike':

                    $stmt = $db->prepare("DELETE FROM $Web->ecommerce_answer_rating_tbl WHERE product_id = ? AND question_id = ? AND answer_id = ? AND user_id = ? ");
                    $stmt->execute([$product_id, $question_id, $answer_id, $LogUser->user_id]);

                    $stmt = $db->prepare("INSERT INTO $Web->ecommerce_answer_rating_tbl (`product_id`,`question_id`,`answer_id`, `user_id`, `action`) VALUES (?,?,?,?,?) ");
                    $stmt->execute([$product_id, $question_id, $answer_id, $LogUser->user_id, $rating_action]);
                    break;

                case 'liked':
                case 'disliked':

                    $stmt = $db->prepare("DELETE FROM $Web->ecommerce_answer_rating_tbl WHERE product_id = ? AND question_id = ? AND answer_id = ? AND user_id = ? ");
                    $stmt->execute([$product_id, $question_id, $answer_id, $LogUser->user_id]);

                    break;
            }
        } catch (\Exception $e) {
            Errors::response_500("Something went wrong".$e->getMessage().$e->getLine());
        }

        $output = new stdClass;
        $output->likes = $Question->likes($answer_id);
        $output->dislikes = $Question->dislikes($answer_id);
        $output->process = $rating_action;
        $output->message = $message;
        echo json_encode($output);
        break;

    case "fetch_all_answers":
        if (!$Web->is_isset("question_id", "product_id")) Errors::response("Invalid Request");
        $question_id = $Web->sanitize_text($_POST["question_id"]);
        $product_id = $Web->sanitize_text($_POST["product_id"]);

        if (!Product::is_product_id($product_id)) Errors::response("Product doesn't exist");
        if (!Question::is_question_id($product_id, $question_id)) Errors::response("Question doesn't exist");

        $Q = new Question($product_id, $question_id);

        $output = new stdClass;
        $output->data = $Q->all_answers_card($question_id);
        echo json_encode($output);
        break;

    case "add_answer":
        if (!$Web->is_isset("question_id", "product_id", "answer")) Errors::response("Invalid Request");
        $question_id = $Web->sanitize_text($_POST["question_id"]);
        $product_id = $Web->sanitize_text($_POST["product_id"]);
        $answer = $Web->sanitize_text($_POST["answer"]);
        $answer = trim($_POST["answer"]);
        $Web->validate_post_input($answer, "", "Answer", true);

        if (!Product::is_product_id($product_id)) Errors::response("Product doesn't exist");
        $Product = new Product($product_id);
        if (!Question::is_question_id($product_id, $question_id)) Errors::response("Question doesn't exist");
        $Q = new Question($product_id, $question_id);

        $Web->validate_post_length($_POST["answer"], 1000, "Maximum Answer length is 1000");
        if (!$Product->has_user_purchased_product($LogUser->user_id) && $LogUser->user_id !== $Product->seller()->user_id) Errors::response("Sorry! You are not allowed to answer this question since you haven't purchased the product");
        if ($Q->asker()->user_id == $LogUser->user_id) Errors::response("You can't answer to your own question");
        if ($Q->has_user_answered($LogUser->user_id)) Errors::response("You have already answered the question");

        try {
            $stmt = $db->prepare("INSERT INTO $Web->ecommerce_product_answers_tbl (`product_id`,`question_id`, `date`, `answer`, `answered_by`)  VALUES (?,?,?,?,?) ");
            $stmt->execute([$product_id, $question_id, $Web->current_time(), $answer, $LogUser->user_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in adding answer");
        }

        $output = new stdClass;
        $output->message = "Answer has been added";
        $output->data = $Q->card($question_id);
        echo json_encode($output);
        break;


    case "delete_question":
        if (!$Web->is_isset("question_id", "product_id")) Errors::response("Invalid Request");
        $question_id = $Web->sanitize_text($_POST["question_id"]);
        $product_id = $Web->sanitize_text($_POST["product_id"]);
        if (!Product::is_product_id($product_id)) Errors::response("Product doesn't exist");
        $Product = new Product($product_id);
        if (!Question::is_question_id($product_id, $question_id)) Errors::response("Question doesn't exist");
        $Q = new Question($product_id, $question_id);

        if ($Q->asker()->user_id !== $LogUser->user_id) Errors::response("Invalid Request");
        if ($Q->has_answers($question_id)) Errors::response("Question having answer can't be delete");

        try {
            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_product_questions_tbl WHERE product_id = ? AND question_id = ? AND asker_id = ? ");
            $stmt->execute([$product_id, $question_id,  $LogUser->user_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in deleting question");
        }

        $output = new stdClass;
        $output->message = "Question has been deleted";
        $output->count = $Product->questions_count();
        echo json_encode($output);
        break;

    case "edit_question":
        if (!$Web->is_isset("question", "question_id", "product_id")) Errors::response("Invalid Request");
        $question = $Web->sanitize_text($_POST["question"]);
        $question_id = $Web->sanitize_text($_POST["question_id"]);
        $product_id = $Web->sanitize_text($_POST["product_id"]);
        if (!Product::is_product_id($product_id)) Errors::response("Product doesn't exist");
        $Product = new Product($product_id);
        $question = trim($question);
        $Web->validate_post_input($question, "", "Question", true);

        if (!Question::is_question_id($product_id, $question_id)) Errors::response("Question doesn't exist");
        $Q = new Question($product_id, $question_id);

        if ($Q->asker()->user_id !== $LogUser->user_id) Errors::response("Invalid Request");
        if ($Q->has_answers($question_id)) Errors::response("Question can't be edited having answers");

        $Web->validate_post_length($_POST["question"], 500, "Maximum Question length is 500");


        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_product_questions_tbl SET question = ? WHERE asker_id = ? AND product_id = ? AND question_id = ? ");
            $stmt->execute([$question, $LogUser->user_id, $product_id, $question_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in updating question");
        }

        $output = new stdClass;
        $output->message = "Question has been edited";
        $output->data = $Q->question($question_id);
        echo json_encode($output);

        break;

    case "ask_question":
        if (!$Web->is_isset("question", "product_id")) Errors::response("Invalid Request");
        $question = $Web->sanitize_text($_POST["question"]);
        $product_id = $Web->sanitize_text($_POST["product_id"]);
        if (!Product::is_product_id($product_id)) Errors::response("Product doesn't exist");
        $Product = new Product($product_id);
        $question = trim($question);
        $Web->validate_post_input($question, "", "Question", true);

        $user_questions_count = $Product->user_questions_count($LogUser->user_id);
        if ($user_questions_count >= 5) Errors::response("Sorry you are allowed to ask maximum 5 questions");
        $Web->validate_post_length($_POST["question"], 500, "Maximum Question length is 500");


        try {
            $stmt = $db->prepare("INSERT INTO $Web->ecommerce_product_questions_tbl (`product_id`, `question`, `date_asked`, `asker_id`) VALUES (?,?,?,?) ");
            $stmt->execute([$product_id, $question, $Web->current_time(), $LogUser->user_id]);

            $question_id = $db->lastInsertId();
            $Q = new Question($product_id, $question_id);

            $output = new stdClass;
            $output->data = $Q->card($question_id);
            $output->count = $Product->questions_count();
            $output->message = "Question has been added";
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in asking question");
        }



        break;
}
