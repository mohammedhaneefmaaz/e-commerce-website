<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        include("../../../../db.php");
    }
    Errors::response_404();
}

use Ecommerce\Basic;

if (!$Web->is_isset("case")) Errors::response_404();
$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();
switch ($case) {

    case "remove_search_history":
        if (!$Web->is_isset("search_id")) Errors::response_404();
        $search_id = $Web->sanitize_text($_POST["search_id"]);

        try {
            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_search_history_tbl WHERE user_id = ? AND search_id = ? ");
            $stmt->execute([$LogUser->user_id, $search_id]);
        } catch (\Exception $e) {
            Errors::response_500("Something went wrong");
        }

        $output = new stdClass;
        $output->status = 1;
        echo json_encode($output);
        break;

    case "search_suggestion":
        if (!$Web->is_isset("keyword")) Errors::response_404();
        $keyword = $_POST["keyword"];

        $search_history = "";
        if ($Login->is_user_loggedin() && !empty(Basic::searchHistory($Web, $LogUser->user_id))) $search_history = '<div data-type="history" class="search-heading">Recent Searches</div>' . Basic::searchHistory($Web, $LogUser->user_id);
        $data = '<li data-text="' . $keyword . '" class="d-none"></li>';
        if ($Web->is_empty($keyword)) {
            if (!$Web->is_empty($search_history)) $data .= $search_history;
            if (!$Web->is_empty(Basic::popularSearch($Web))) $data .= '<div class="search-heading">Popular Searches</div>' . Basic::popularSearch($Web);
        } else {
             $data .= Basic::suggestion_by_popular($keyword);
        }
        $output = new stdClass;
        $output->data = $data;
        echo json_encode($output);

        break;
}
