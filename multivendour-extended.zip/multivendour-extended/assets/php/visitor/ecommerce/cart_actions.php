<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        include("../../../../db.php");
    }
    Errors::response_404();
}

use Ecommerce\Cart;
use Ecommerce\Checkout;
use Ecommerce\Product;

if (!$Web->is_isset("case")) Errors::response_404();

$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();

if (!$Login->is_user_loggedin()) Errors::force_login();

switch ($case) {
    case "buy_product":
        if (!$Web->is_isset("cart_id")) Errors::response("Invalid Request");
        $cart_id = $Web->sanitize_text($_POST["cart_id"]);
        if (!Cart::is_user_cart_product($cart_id, $LogUser->user_id)) Errors::response("Product is not in cart");

        $Cart = new Cart($cart_id);
        $product_id = $Cart->product_id();
        $variation_id = $Cart->variation_id();
        $svariation_id = $Cart->svariation_id();
        $quantity= $Cart->quantity();
        $Product = new Product($product_id);
        if ($Product->status_text($variation_id, $svariation_id)->type !== "success") Errors::response("The product is currently unavailable");
        
        $minimum_order = $Product->minimum_order($variation_id, $svariation_id);
        $maximum_order = $Product->real_maximum_order($variation_id, $svariation_id);
        $stock = $Product->stock($variation_id, $svariation_id);
        if ($quantity < $minimum_order) Errors::response("Minimum order for $product_name is $minimum_order");
        if ($quantity > $maximum_order) Errors::response("Maximum order for $product_name is $maximum_order");
        if ($quantity > $stock) Errors::response("Only $stock stock are available for $product_name");

        Checkout::clear_checkout($LogUser->user_id);
        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_cart_tbl SET role = 'checkout', last_updated = ? WHERE user_id = ? AND role = 'cart' AND cart_id = ? ");
            $stmt->execute([$Web->current_time(), $LogUser->user_id, $cart_id]);
        } catch (\Exception $e) {
            Errors::response("Error in purchasing product");
        }

        $output = new stdClass;
        $output->url = $Web->base_url() . '/checkout/';
        echo json_encode($output);
        break;

    case "cart_to_checkout":

        if (!$Web->is_isset("confirm")) Errors::response("Invalid Request");
        $confirm = $Web->sanitize_text($_POST["confirm"]);

        if (!Cart::has_products($LogUser->user_id)) Errors::response("No product in cart");
        if (!Cart::has_available_products($LogUser->user_id)) Errors::response("No products are available to checkout");

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("SELECT * FROM $Web->ecommerce_cart_tbl WHERE user_id = ? AND role = 'cart' ");
            $stmt->execute([$LogUser->user_id]);
            $unavailable_products = '';
            if ($confirm == "1") Checkout::clear_checkout($LogUser->user_id);

            $users_all_cart_id = [];

            while ($row = $stmt->fetch()) {
                $cart_id = $row->cart_id;
                $Cart = new Cart($cart_id);
                $product_id = $Cart->product_id();
                $variation_id = $Cart->variation_id();
                $svariation_id = $Cart->svariation_id();
                $Product = new Product($product_id);
                $quantity = $Cart->quantity();

                $product_name = $Product->product_name($variation_id, $svariation_id);
                $minimum_order = $Product->minimum_order($variation_id, $svariation_id);
                $maximum_order = $Product->real_maximum_order($variation_id, $svariation_id);
                $stock = $Product->stock($variation_id, $svariation_id);
                if ($quantity < $minimum_order) Errors::response("Minimum order for $product_name is $minimum_order");
                if ($quantity > $maximum_order) Errors::response("Maximum order for $product_name is $maximum_order");
                if ($quantity > $stock) Errors::response("Only $stock stock are available for $product_name");


                if ($Product->status_text($variation_id, $svariation_id)->type == "error") {
                    if ($confirm == "0") {
                        $unavailable_products .= '<div class="border-bottom py-2 border-2 d-flex">
                            <img class="img-fluid mw-100px mh-60px" src="' . $Product->image($variation_id, $svariation_id) . '" alt="image">
                            <div class="px-2">
                                <div class="text-primary-alt fs-4 wrap-text-1">' . $Product->product_name($variation_id, $svariation_id) . '</div>
                              <div class="text-' . $Product->status_text($variation_id, $svariation_id)->code . ' mb-2 small">' . $Product->status_text($variation_id, $svariation_id)->text . '</div>
                            </div>
                        </div>';
                    }
                } else {
                    $users_all_cart_id[] = $cart_id;
                }
            }


            if ($Web->is_empty($unavailable_products) || $confirm == "1") {
                foreach ($users_all_cart_id as $cart_id) {
                    $stmt = $db->prepare("UPDATE $Web->ecommerce_cart_tbl SET role = 'checkout', last_updated = ? WHERE user_id = ? AND role = 'cart' AND cart_id = ? ");
                    $stmt->execute([$Web->current_time(), $LogUser->user_id, $cart_id]);
                }
            }
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in processing request");
        }


        $output = new stdClass;
        $output->unavailable_products = $unavailable_products;
        $output->url = $Web->base_url() . '/checkout/';
        echo json_encode($output);
        break;

    case "add_to_cart":
        if (!$Web->is_isset("variation_id", "quantity", "svariation_id", "product_id")) Errors::response("Invalid Request");
        $quantity = $Web->sanitize_text($_POST["quantity"]);
        $product_id = $Web->sanitize_text($_POST["product_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);

        if (!Product::is_product_id($product_id)) Errors::response("Product doesn't exist");
        $Product = new Product($product_id);
        if (!$Product->is_variation_id($variation_id)) Errors::response("Product does not exist");
        if (!$Product->is_svariation_id($variation_id, $svariation_id)) Errors::response("Product does not exist");
        if ($Product->status_text($variation_id, $svariation_id)->type !== "success") Errors::response("The product is currently unavailable");

        $Web->validate_post_input($quantity, "number", "Quantity", true);
        $product_name = $Product->product_name($variation_id, $svariation_id);
        $minimum_order = $Product->minimum_order($variation_id, $svariation_id);
        $maximum_order = $Product->real_maximum_order($variation_id, $svariation_id);
        $stock = $Product->stock($variation_id, $svariation_id);
        if ($quantity < $minimum_order) Errors::response("Minimum order for $product_name is $minimum_order");
        if ($quantity > $maximum_order) Errors::response("Maximum order for $product_name is $maximum_order");
        if ($quantity > $stock) Errors::response("Only $stock stock are available for $product_name");


        if (!Cart::is_product_in_cart($product_id, $variation_id, $svariation_id, $LogUser->user_id)) {
            try {
                $stmt = $db->prepare("INSERT INTO $Web->ecommerce_cart_tbl (`user_id`, `product_id`, `variation_id`, `svariation_id`,`quantity`,`role`) 
                VALUES (?,?,?,?,?,'cart') ");
                $stmt->execute([$LogUser->user_id, $product_id, $variation_id, $svariation_id, $quantity]);
            } catch (\Exception $e) {
                Errors::response_500("Error in adding product to cart");
            }
        } else {
            try {
                $stmt = $db->prepare("UPDATE $Web->ecommerce_cart_tbl SET quantity = ? WHERE user_id = ? AND product_id = ? AND variation_id =? AND svariation_id = ? AND role ='cart' ");
                $stmt->execute([$quantity, $LogUser->user_id, $product_id, $variation_id, $svariation_id]);
            } catch (\Exception $e) {
                Errors::response_500("Error in adding product to cart");
            }
        }

        $output = new stdClass;
        $output->message = "{$Product->product_name($variation_id,$svariation_id)} has been added to cart";
        echo json_encode($output);
        break;

    case "save_cart_product":
        if (!$Web->is_isset("cart_id")) Errors::response("Invalid Request");
        $cart_id = $Web->sanitize_text($_POST["cart_id"]);
        if (!Cart::is_user_cart_product($cart_id, $LogUser->user_id)) Errors::response("Product is not in cart");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_cart_tbl SET role = 'saved' WHERE cart_id = ? AND user_id = ? ");
            $stmt->execute([$cart_id, $LogUser->user_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in saving product");
        }

        $output = new stdClass;
        $output->message = "Product has been moved to saved for later";
        $output->saved_card = Cart::saved_products($LogUser->user_id);
        $output->cart_card = Cart::cart_products($LogUser->user_id);
        $output->details_card = Cart::cart_price_details_card($LogUser->user_id);
        $output->saved_count = Cart::saved_products_count($LogUser->user_id);
        $output->cart_count = Cart::cart_products_count($LogUser->user_id);
        echo json_encode($output);
        break;
    case "move_saved_to_cart":
        if (!$Web->is_isset("cart_id")) Errors::response("Invalid Request");
        $cart_id = $Web->sanitize_text($_POST["cart_id"]);
        if (!Cart::is_user_saved_product($cart_id, $LogUser->user_id)) Errors::response("Product is not in cart");

        $Cart = new Cart($cart_id);
        $product_id = $Cart->product_id();
        $variation_id = $Cart->variation_id();
        $Product = new Product($product_id);
        $svariation_id = $Cart->svariation_id();
        $quantity= $Cart->quantity();

        if ($Product->status_text($variation_id, $svariation_id)->type !== "success") Errors::response("The product is currently unavailable");

        $minimum_order = $Product->minimum_order($variation_id, $svariation_id);
        $maximum_order = $Product->real_maximum_order($variation_id, $svariation_id);
        $stock = $Product->stock($variation_id, $svariation_id);
        if ($quantity < $minimum_order) Errors::response("Minimum order for $product_name is $minimum_order");
        if ($quantity > $maximum_order) Errors::response("Maximum order for $product_name is $maximum_order");
        if ($quantity > $stock) Errors::response("Only $stock stock are available for $product_name");


        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_cart_tbl SET role = 'cart' WHERE cart_id = ? AND user_id = ? ");
            $stmt->execute([$cart_id, $LogUser->user_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in saving product");
        }

        $output = new stdClass;
        $output->message = "Product has been moved to cart";
        $output->saved_card = Cart::saved_products($LogUser->user_id);
        $output->cart_card = Cart::cart_products($LogUser->user_id);
        $output->details_card = Cart::cart_price_details_card($LogUser->user_id);
        $output->saved_count = Cart::saved_products_count($LogUser->user_id);
        $output->cart_count = Cart::cart_products_count($LogUser->user_id);
        echo json_encode($output);
        break;

    case "move_wishlist_to_cart":
        if (!$Web->is_isset("cart_id")) Errors::response("Invalid Request");
        $cart_id = $Web->sanitize_text($_POST["cart_id"]);
        if (!Cart::is_user_wishlist_product($cart_id, $LogUser->user_id)) Errors::response("Product is not in wishlist");

        $Cart = new Cart($cart_id);
        $product_id = $Cart->product_id();
        $variation_id = $Cart->variation_id();
        $svariation_id = $Cart->svariation_id();
        $quantity = $Cart->quantity();
        
        $Product = new Product($product_id);
        if ($Product->status_text($variation_id, $Cart->svariation_id())->type !== "success") Errors::response("The product is currently unavailable");

        $minimum_order = $Product->minimum_order($variation_id, $svariation_id);
        $maximum_order = $Product->real_maximum_order($variation_id, $svariation_id);
        $stock = $Product->stock($variation_id, $svariation_id);
        if ($quantity < $minimum_order) Errors::response("Minimum order for $product_name is $minimum_order");
        if ($quantity > $maximum_order) Errors::response("Maximum order for $product_name is $maximum_order");
        if ($quantity > $stock) Errors::response("Only $stock stock are available for $product_name");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_cart_tbl SET role = 'cart' WHERE cart_id = ? AND user_id = ? ");
            $stmt->execute([$cart_id, $LogUser->user_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in saving product");
        }

        $output = new stdClass;
        $output->message = "Product has been moved to cart";
        $output->fav_count = Cart::wishlist_products_count($LogUser->user_id);
        echo json_encode($output);
        break;

    case "add_to_wishlist":
        if (!$Web->is_isset("variation_id", "event", "svariation_id", "product_id")) Errors::response("Invalid Request");
        $event = $Web->sanitize_text($_POST["event"]);
        $product_id = $Web->sanitize_text($_POST["product_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);

        if (!Product::is_product_id($product_id)) Errors::response("Product doesn't exist");
        $Product = new Product($product_id);
        if (!$Product->is_variation_id($variation_id)) Errors::response("Product does not exist");
        if (!$Product->is_svariation_id($variation_id, $svariation_id)) Errors::response("Product does not exist");

        $output = new stdClass;

        try {

            switch ($event) {
                case "add":
                    if (!Cart::is_product_in_wishlist($product_id, $variation_id, $svariation_id, $LogUser->user_id)) {
                        $stmt = $db->prepare("INSERT INTO $Web->ecommerce_cart_tbl (`user_id`, `product_id`, `variation_id`, `svariation_id`,`quantity`,`role`) VALUES (?,?,?,?,'1','wishlist') ");
                        $stmt->execute([$LogUser->user_id, $product_id, $variation_id, $svariation_id]);
                    }
                    $output->event = "added";
                    $output->message = "Product has been added to wishlist";
                    break;
                case "remove":
                    if (!Cart::is_product_in_wishlist($product_id, $variation_id, $svariation_id, $LogUser->user_id)) Errors::response("Product is not in wishlist");

                    $stmt = $db->prepare("DELETE FROM $Web->ecommerce_cart_tbl WHERE product_id = ? AND variation_id = ? AND svariation_id= ? AND role = 'wishlist' AND user_id = ? ");
                    $stmt->execute([$product_id, $variation_id, $svariation_id, $LogUser->user_id]);

                    $output->event = "removed";
                    $output->message = "Product has been removed from wishlist";
                    break;
                default:
                    Errors::response_404();
                    break;
            }
        } catch (\Exception $e) {
            Errors::response_500("Error in wishlist");
        }


        echo json_encode($output);
        break;

    case "remove_cart_product":
        if (!$Web->is_isset("cart_id")) Errors::response("Invalid Request");
        $cart_id = $Web->sanitize_text($_POST["cart_id"]);
        if (!Cart::is_user_cart_product($cart_id, $LogUser->user_id)) Errors::response("Product is not in cart");

        try {
            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_cart_tbl WHERE cart_id = ? AND user_id = ? AND role = 'cart' ");
            $stmt->execute([$cart_id, $LogUser->user_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in cart");
        }

        $output = new stdClass;
        $output->message = "Product has been removed from cart";
        $output->saved_card = Cart::saved_products($LogUser->user_id);
        $output->cart_card = Cart::cart_products($LogUser->user_id);
        $output->details_card = Cart::cart_price_details_card($LogUser->user_id);
        $output->saved_count = Cart::saved_products_count($LogUser->user_id);
        $output->cart_count = Cart::cart_products_count($LogUser->user_id);
        echo json_encode($output);
        break;

    case "remove_saved_product":
        if (!$Web->is_isset("cart_id")) Errors::response("Invalid Request");
        $cart_id = $Web->sanitize_text($_POST["cart_id"]);
        if (!Cart::is_user_saved_product($cart_id, $LogUser->user_id)) Errors::response("Product is not saved for later");

        try {
            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_cart_tbl WHERE cart_id = ? AND user_id = ? AND role = 'saved' ");
            $stmt->execute([$cart_id, $LogUser->user_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in save");
        }

        $output = new stdClass;
        $output->message = "Product has been removed from saved for later";
        $output->saved_card = Cart::saved_products($LogUser->user_id);
        $output->cart_card = Cart::cart_products($LogUser->user_id);
        $output->details_card = Cart::cart_price_details_card($LogUser->user_id);
        $output->saved_count = Cart::saved_products_count($LogUser->user_id);
        $output->cart_count = Cart::cart_products_count($LogUser->user_id);
        echo json_encode($output);
        break;

    case "remove_wishlist_product":
        if (!$Web->is_isset("cart_id")) Errors::response("Invalid Request");
        $cart_id = $Web->sanitize_text($_POST["cart_id"]);
        if (!Cart::is_user_wishlist_product($cart_id, $LogUser->user_id)) Errors::response("Product is not in wishlist");

        try {
            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_cart_tbl WHERE cart_id = ? AND user_id = ? AND role = 'wishlist' ");
            $stmt->execute([$cart_id, $LogUser->user_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in wishlist");
        }

        $output = new stdClass;
        $output->message = "Product has been removed from wishlist";
        $output->fav_count = Cart::wishlist_products_count($LogUser->user_id);
        echo json_encode($output);
        break;

    case "change_cart_product_quantity":
        if (!$Web->is_isset("cart_id", "quantity")) Errors::response("Invalid Request");
        $cart_id = $Web->sanitize_text($_POST["cart_id"]);
        $quantity = $Web->sanitize_text($_POST["quantity"]);
        if (!Cart::is_user_cart_product($cart_id, $LogUser->user_id)) Errors::response("Product is not in cart");
        $Web->validate_post_input($quantity, "number", "Quantity", true);
        $Cart = new Cart($cart_id);
        $Product = new Product($Cart->product_id());
        $variation_id = $Cart->variation_id();
        $svariation_id = $Cart->svariation_id();
        if ($Product->status_text($variation_id, $Cart->svariation_id())->type !== "success") Errors::response("The product is currently unavailable");

        $minimum_order = $Product->minimum_order($variation_id, $svariation_id);
        $maximum_order = $Product->real_maximum_order($variation_id, $svariation_id);
        $stock = $Product->stock($variation_id, $svariation_id);
        if ($quantity < $minimum_order) Errors::response("Minimum order for $product_name is $minimum_order");
        if ($quantity > $maximum_order) Errors::response("Maximum order for $product_name is $maximum_order");
        if ($quantity > $stock) Errors::response("Only $stock stock are available for $product_name");

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_cart_tbl SET quantity = ? WHERE cart_id = ? AND user_id = ? AND role = 'cart' ");
            $stmt->execute([$quantity, $cart_id, $LogUser->user_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in cart");
        }

        $output = new stdClass;
        $output->message = "Product quantity has been updated";
        $output->saved_card = Cart::saved_products($LogUser->user_id);
        $output->cart_card = Cart::cart_products($LogUser->user_id);
        $output->details_card = Cart::cart_price_details_card($LogUser->user_id);
        $output->saved_count = Cart::saved_products_count($LogUser->user_id);
        $output->cart_count = Cart::cart_products_count($LogUser->user_id);
        echo json_encode($output);
        break;


    default:
        Errors::response_404();
        break;
}
