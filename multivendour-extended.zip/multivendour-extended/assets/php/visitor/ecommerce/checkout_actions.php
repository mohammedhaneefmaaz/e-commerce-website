<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        include("../../../../db.php");
    }
    Errors::response_404();
}

use Ecommerce\Cart;
use Ecommerce\Checkout;
use Ecommerce\Order;
use Ecommerce\OrderTransaction;
use Ecommerce\PaymentMethod;
use Ecommerce\Product;

if (!$Web->is_isset("case")) Errors::response_404();

$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();

if (!$Login->is_user_loggedin()) Errors::force_login();

switch ($case) {

    case "final_products_checkout":

        if (!$Web->is_isset("address_id", "payment_method")) Errors::response("Invalid Request");
        $address_id = $Web->sanitize_text($_POST["address_id"]);
        $payment_method = $Web->sanitize_text($_POST["payment_method"]);
        if (!Address::is_address_id($address_id)) Errors::response("Address doesn't exists");


        $validPaymentMethods = PaymentMethod::lists();

        if (!in_array($payment_method, $validPaymentMethods)) Errors::response("Please choose a valid Payment Method");
        if ($payment_method == "Paytm" && !PaymentMethod::isPaytmActive()) Errors::response("Paytm is not supported");
        if ($payment_method == "Razorpay" && !PaymentMethod::isRazorpayActive())  Errors::response("Razorpay is not supported");
        if ($payment_method == "CashOnDelivery" && !Checkout::is_cod_available($LogUser->user_id))  Errors::response("Cash On Delivery is not supported");

        if (!Checkout::has_products($LogUser->user_id)) {
            $output = new stdClass;
            $output->has_products = Checkout::has_products($LogUser->user_id);
            echo json_encode($output);
            exit();
        }

        $orders = [];
        $payable_amount = 0;


        try {
            $db->beginTransaction();

            $stmt = $db->prepare("SELECT * FROM $Web->ecommerce_cart_tbl WHERE user_id = ? AND role = 'checkout' ");
            $stmt->execute([$LogUser->user_id]);

            while ($row = $stmt->fetch()) {
                $cart_id = $row->cart_id;
                $Checkout = new Checkout($cart_id);

                $product_id =  $row->product_id;
                $variation_id =  $row->variation_id;
                $svariation_id =  $row->svariation_id;
                $quantity =  $row->quantity;
                $Product = new Product($product_id);
                $price =  $Product->price($variation_id, $svariation_id);
                $total_price =  $price * $quantity;
                $Address = new Address($address_id);
                $address = json_encode($Address->row());
                $payable_amount += $total_price;

                $product_name = $Product->product_name($variation_id, $svariation_id);
                $maximum_order = $Product->real_maximum_order($variation_id, $svariation_id);
                $minimum_order = $Product->minimum_order($variation_id, $svariation_id);
                $stock = $Checkout->maximum_order($variation_id, $svariation_id);

                if ($quantity < $minimum_order) Errors::response("Minimum order for $product_name is $minimum_order");
                if ($quantity > $maximum_order) Errors::response("Maximum order for $product_name is $maximum_order");
                if ($quantity > $stock) Errors::response("Only $stock stock are available for $product_name");

                $status = "PENDING";

                $return_policy = [
                    "return_policy" => $Product->return_policy($variation_id, $svariation_id),
                    "return_policy_days" => $Product->return_policy_days($variation_id, $svariation_id)
                ];
                $return_policy = json_encode($return_policy);

                $sub_stmt = $db->prepare("INSERT INTO $Web->ecommerce_orders_tbl (`buyer_id`, `product_id`, `variation_id`, `svariation_id`, `quantity`, `price`,`total_price`,`grand_total`, `ordered_date`,`return_policy`, `address`, `payment_method`,`status`) VALUES (:buyer_id,:product_id,:variation_id,:svariation_id,:quantity,:price,:total_price,:grand_total,:ordered_date,:return_policy,:address,:payment_method,:status) ");

                $sub_stmt->execute([
                    ":buyer_id" => $LogUser->user_id,
                    ":product_id" => $product_id,
                    ":variation_id" => $variation_id,
                    ":svariation_id" => $svariation_id,
                    ":quantity" => $quantity,
                    ":price" => $price,
                    ":total_price" => $total_price,
                    ":grand_total" => $total_price,
                    ":ordered_date" => $Web->current_time(),
                    ":return_policy" => $return_policy,
                    ":address" => $address,
                    ":payment_method" => $payment_method,
                    ":status" => $status
                ]);

                $orders[] = $db->lastInsertId();
            }

            $orders = json_encode($orders);
            $transaction_id = OrderTransaction::generate_transaction_id();

            $stmt = $db->prepare("INSERT INTO $Web->ecommerce_order_transactions_tbl (`transaction_id`, `buyer_id`, `orders`,`payable_amount`,`payment_method`, `status`,`transaction_date`) VALUES (?,?,?,?,?,'PENDING',?) ");
            $stmt->execute([$transaction_id, $LogUser->user_id, $orders, $payable_amount, $payment_method, $Web->current_time()]);

            $OrderTransaction = new OrderTransaction($transaction_id);

            if ($payment_method == "CashOnDelivery") {
                $orders = $OrderTransaction->orders();
                foreach ($orders as $order_id) {
                    $Order = new Order($order_id);

                    $Product = $Order->product();
                    $product_id = $Order->product_id();
                    $variation_id = $Order->variation_id();
                    $svariation_id = $Order->svariation_id();
                    $quantity = $Order->quantity();


                    $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET STATUS = 'SUCCESS', ordered_date = ? WHERE order_id = ? AND buyer_id = ? AND payment_method = ?");
                    $stmt->execute([$Web->current_time(), $order_id, $LogUser->user_id, $payment_method]);


                    $stmt = $db->prepare("UPDATE $Web->ecommerce_variations_tbl SET stock = stock - ? WHERE product_id =? AND variation_id = ? AND svariation_id = ? ");
                    $stmt->execute([$quantity, $product_id, $variation_id, $svariation_id]);

                    $listing_id = $Product->listing_id();

                    $stmt = $db->prepare("UPDATE $Web->ecommerce_listing_variations_tbl SET stock = stock - ? WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? ");
                    $stmt->execute([$quantity, $listing_id, $variation_id, $svariation_id]);
                }
            }

            $url = $OrderTransaction->proceed_url();

            Checkout::clear_checkout($LogUser->user_id);
            $db->commit();

            $output = new stdClass;
            $output->url = $url;
            echo json_encode($output);
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in checkout" . $e->getLine());
        }

        break;

    case "add_new_address":
        if (!$Web->is_isset("event", "address_id", "full_name", "mobile_number", "city", "area", "flat", "landmark", "state", "postcode", "address_type")) Errors::response("Invalid Request");

        $full_name = $Web->sanitize_text($_POST["full_name"]);
        $mobile_number = $Web->sanitize_text($_POST["mobile_number"]);
        $city = $Web->sanitize_text($_POST["city"]);
        $area = $Web->sanitize_text($_POST["area"]);
        $flat = $Web->sanitize_text($_POST["flat"]);
        $landmark = $Web->sanitize_text($_POST["landmark"]);
        $state = $Web->sanitize_text($_POST["state"]);
        $postcode = $Web->sanitize_text($_POST["postcode"]);
        $address_type = $Web->sanitize_text($_POST["address_type"]);
        $event = $Web->sanitize_text($_POST["event"]);
        $address_id = $Web->sanitize_text($_POST["address_id"]);

        if ($event !== "create" && $event !== "update") Errors::response("Invalid Event");
        $output = new stdClass;

        try {
            if ($event == "create") {
                $stmt = $db->prepare("INSERT INTO $Web->ecommerce_address_tbl (`user_id`,`full_name`, `mobile_number`, `city`, `area`, `flat`, `landmark`, `state`, `postcode`, `address_type`)  VALUES (:user_id,:full_name,:mobile_number,:city,:area,:flat,:landmark,:state,:postcode,:address_type) ");

                $stmt->execute([
                    ":user_id" => $LogUser->user_id,
                    ":full_name" => $full_name,
                    ":mobile_number" => $mobile_number,
                    ":city" => $city,
                    ":area" => $area,
                    ":flat" => $flat,
                    ":landmark" => $landmark,
                    ":state" => $state,
                    ":postcode" => $postcode,
                    ":address_type" => $address_type
                ]);

                $address_id = $db->lastInsertId();
                $Address = new Address($address_id);
                $output->message = "Address has been created";
            } else {
                if (!Address::is_address_id($address_id)) Errors::response("Address doesn't exist");
                $Address = new Address($address_id);
                if ($LogUser->user_id !== $Address->user()->user_id) Errors::response("Invalid Request");

                $stmt = $db->prepare("UPDATE $Web->ecommerce_address_tbl SET full_name = :full_name, mobile_number = :mobile_number, city = :city, area = :area, flat = :flat,landmark = :landmark, state = :state,postcode = :postcode,address_type = :address_type WHERE address_id = :address_id AND user_id = :user_id  ");

                $stmt->execute([
                    ":user_id" => $LogUser->user_id,
                    ":full_name" => $full_name,
                    ":mobile_number" => $mobile_number,
                    ":city" => $city,
                    ":area" => $area,
                    ":flat" => $flat,
                    ":landmark" => $landmark,
                    ":state" => $state,
                    ":postcode" => $postcode,
                    ":address_type" => $address_type,
                    ":address_id" => $address_id
                ]);

                $output->message = "Address has been updated";
            }
        } catch (\Exception $e) {
            Errors::response_500("Error in address" . $e->getMessage());
        }


        $output->data = Checkout::address_card($address_id, $LogUser->user_id);
        echo json_encode($output);
        break;

    case "change_product_quantity":
        if (!$Web->is_isset("cart_id", "quantity")) Errors::response("Invalid Request");
        $quantity = $Web->sanitize_text($_POST["quantity"]);
        $cart_id = $Web->sanitize_text($_POST["cart_id"]);
        if (!Checkout::is_user_checkout_product($cart_id, $LogUser->user_id)) Errors::response("Product is not in checkout");
        $Web->validate_post_input($quantity, "number", "Quantity", true);

        $Checkout = new Checkout($cart_id);
        $variation_id = $Checkout->variation_id();
        $svariation_id = $Checkout->svariation_id();

        $Product = $Checkout->product();
        $product_name = $Product->product_name($variation_id, $svariation_id);
        $minimum_order = $Product->minimum_order($variation_id, $svariation_id);
        $maximum_order = $Product->real_maximum_order($variation_id, $svariation_id);
        $stock = $Checkout->maximum_order($variation_id, $svariation_id);

        if ($quantity < $minimum_order) Errors::response("Minimum order for $product_name is $minimum_order");
        if ($quantity > $maximum_order) Errors::response("Maximum order for $product_name is $maximum_order");
        if ($quantity > $stock) Errors::response("Only $stock stock are available for $product_name");

        try {

            $stmt = $db->prepare("UPDATE $Web->ecommerce_cart_tbl SET quantity = ?, last_updated = ?  WHERE cart_id = ? AND user_id = ? AND role = 'checkout' ");
            $stmt->execute([$quantity, $Web->current_time(), $cart_id, $LogUser->user_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in updating quantity" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Product quantity has been updated";
        $output->products = Checkout::products($LogUser->user_id);
        $output->details_card = Checkout::price_details_card($LogUser->user_id);
        $output->products_count = Checkout::products_count($LogUser->user_id);
        $output->has_products = Checkout::has_products($LogUser->user_id);
        echo json_encode($output);
        break;

    case "remove_checkout_product":
        if (!$Web->is_isset("cart_id")) Errors::response("Invalid Request");
        $cart_id = $Web->sanitize_text($_POST["cart_id"]);
        if (!Checkout::is_user_checkout_product($cart_id, $LogUser->user_id)) Errors::response("Product is not in checkout");
        try {

            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_cart_tbl WHERE cart_id = ? AND user_id = ? AND role = 'checkout' ");
            $stmt->execute([$cart_id, $LogUser->user_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in removing product from checkout" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Product has been removed from checkout";
        $output->products = Checkout::products($LogUser->user_id);
        $output->details_card = Checkout::price_details_card($LogUser->user_id);
        $output->products_count = Checkout::products_count($LogUser->user_id);
        $output->has_products = Checkout::has_products($LogUser->user_id);
        echo json_encode($output);
        break;

    case "buy_product":
        if (!$Web->is_isset("variation_id", "quantity", "svariation_id", "product_id")) Errors::response("Invalid Request");
        $quantity = $Web->sanitize_text($_POST["quantity"]);
        $product_id = $Web->sanitize_text($_POST["product_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);

        if (!Product::is_product_id($product_id)) Errors::response("Product doesn't exist");
        $Product = new Product($product_id);
        if (!$Product->is_variation_id($variation_id)) Errors::response("Product does not exist");
        if (!$Product->is_svariation_id($variation_id, $svariation_id)) Errors::response("Product does not exist");
        if ($Product->status_text($variation_id, $svariation_id)->type !== "success") Errors::response("The product is currently unavailable");

        $Web->validate_post_input($quantity, "number", "Quantity", true);
        $product_name = $Product->product_name($variation_id, $svariation_id);
        $minimum_order = $Product->minimum_order($variation_id, $svariation_id);
        $maximum_order = $Product->real_maximum_order($variation_id, $svariation_id);
        $stock = $Product->stock($variation_id, $svariation_id);
        if ($quantity < $minimum_order) Errors::response("Minimum order for $product_name is $minimum_order");
        if ($quantity > $maximum_order) Errors::response("Maximum order for $product_name is $maximum_order");
        if ($quantity > $stock) Errors::response("Only $stock stock are available for $product_name");

        try {
            $db->beginTransaction();

            Checkout::clear_checkout($LogUser->user_id);

            $stmt = $db->prepare("INSERT INTO $Web->ecommerce_cart_tbl (`user_id`, `product_id`, `variation_id`, `svariation_id`,`quantity`,`role`,`last_updated`)  VALUES (?,?,?,?,?,'checkout',?) ");
            $stmt->execute([$LogUser->user_id, $product_id, $variation_id, $svariation_id, $quantity, $Web->current_time()]);

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();

            Errors::response_500("Error in purchasing product" . $e->getMessage());
        }

        $output = new stdClass;
        $output->url = $Web->base_url() . '/checkout/';
        echo json_encode($output);
        break;
}
