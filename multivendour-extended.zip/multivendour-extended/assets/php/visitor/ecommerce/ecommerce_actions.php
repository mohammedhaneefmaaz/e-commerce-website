<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        include("../../../../db.php");
    }
    Errors::response_404();
}

use Ecommerce\Cart;
use Ecommerce\Checkout;
use Ecommerce\Product;
use Ecommerce\Category;
use Ecommerce\Home;

if (!$Web->is_isset("case")) Errors::response_404();

$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();


switch ($case) {

    case "fetch_categories":
        if (!$Web->is_isset("category_id")) Errors::response("Invalid Request");
        $category_id = $Web->sanitize_text($_POST["category_id"]);
        if (!Category::is_category_id($category_id) && $category_id != '0') Errors::response("Category do not exist");

        if (Category::is_category_id($category_id)) {
            $Category = new Category($category_id);
            if (!$Category->has_or_child_content()) Errors::response("Category do not exist");

            $header = '
            <div data-header-category="true" data-id="' . $Category->parent_id() . '" class="p-4 hover align-center cursor-pointer category-list border-bottom">
                <span class="svg-icon svg-icon-muted svg-icon-2hx">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <rect opacity="0.5" x="6" y="11" width="13" height="2" rx="1" fill="black"/>
                    <path d="M8.56569 11.4343L12.75 7.25C13.1642 6.83579 13.1642 6.16421 12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75L5.70711 11.2929C5.31658 11.6834 5.31658 12.3166 5.70711 12.7071L11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25C13.1642 17.8358 13.1642 17.1642 12.75 16.75L8.56569 12.5657C8.25327 12.2533 8.25327 11.7467 8.56569 11.4343Z" fill="black"/>
                    </svg>
                </span>
                <div class="fs-4 ms-4 d-flex fw-bold">' . $Category->category() . '</div>
             </div>';
        } else {
            $header = ' <div class="p-4 menu-item">
                            <h2>Categories</h2>
                        </div>';
        }


        $content = $category_id == '0' ?  Home::choose_categories() :  Home::choose_categories($category_id);
        $data = $header . $content;

        $output = new stdClass;
        $output->data = $data;
        echo json_encode($output);

        break;
    default:
        break;
}
