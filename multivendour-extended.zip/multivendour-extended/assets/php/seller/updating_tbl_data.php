<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists('Errors::response_404')) {
        include("../../../db.php");
    }
    Errors::response_404();
}

if (!isset($_POST["case"]))  Errors::response_404();
$case = $_POST["case"];
if ($Web->is_empty($case)) Errors::response_404();
if (!$Login->is_seller_loggedin()) Errors::force_login("seller");


use Ecommerce\Listing;
use Ecommerce\Product;


switch ($case) {

    case "delete_bulk_svariations":

        if (!$Web->is_isset("svariations")) Errors::response_404();
        $svariations = $Web->sanitize_text($_POST["svariations"]);
        if (!is_array($svariations)) Errors::response("Invalid data requested");

        try {
            $db->beginTransaction();

            foreach ($svariations as $data) {
                if (!isset($data["listing_id"])) throw new CsException("Invalid data requested");
                if (!isset($data["variation_id"])) throw new CsException("Invalid data requested");
                if (!isset($data["svariation_id"])) throw new CsException("Invalid data requested");
                $listing_id = $data["listing_id"];
                $variation_id = $data["variation_id"];
                $svariation_id = $data["svariation_id"];

                if (!Listing::is_listing_id($listing_id)) throw new CsException("Some of the listings don't exists");
                $Listing = new Listing($listing_id);
                if (!$Listing->is_svariation_id($variation_id, $svariation_id)) throw new CsException("Some of the listings don't exists");
                if ($Listing->seller()->user_id !== $LogSeller->user_id) throw new Exception();
                if ($Listing->is_svariation_live($variation_id, $svariation_id)) throw new CsException("This Variation can't be deleted");

                $sql = "DELETE FROM $Web->ecommerce_listing_variations_tbl WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? AND user_id = ?";
                $sql = $db->prepare($sql);
                $sql->execute([$listing_id, $variation_id, $svariation_id, $LogSeller->user_id]);

                $sql = "DELETE FROM $Web->ecommerce_qc_tbl WHERE listing_id = ? AND variation_id = ? AND svariation_id = ?";
                $sql = $db->prepare($sql);
                $sql->execute([$listing_id, $variation_id, $svariation_id]);
            }

            $db->commit();
        } catch (CsException $e) {
            $db->rollBack();
            Errors::response($e->getMessage());
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in removing drafts" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Drafts have been removed";
        echo json_encode($output);
        break;

    case "change_svariation_status":
        if (!$Web->is_isset("svariations", "status")) Errors::response_404();
        $status = $_POST["status"];
        $svariations = $_POST["svariations"];
        if (!is_array($svariations)) Errors::response("Invalid data requested");
        if (empty($svariations)) Errors::response("Please check at least a variation");
        if ($status !== "active" && $status !== "inactive") Errors::response_404();

        try {
            $db->beginTransaction();

            foreach ($svariations as $data) {
                $variation_id = $data["variation_id"];
                $svariation_id = $data["svariation_id"];
                $product_id = $data["product_id"];
                if (!Product::is_product_id($product_id)) throw new CsException("Some of the listings you requested don't exist");

                $Product = new Product($product_id);
                $listing_id = $Product->listing_id();
                if ($status == "active" && $Product->status($variation_id, $svariation_id) !== "inactive")  throw new CsException("Some of the listings is not inactive");
                if ($status == "inactive" && $Product->status($variation_id, $svariation_id) !== "active")  throw new CsException("Some of the listings is not active");
                if ($Product->status($variation_id, $svariation_id) !== "active" && $Product->status($variation_id, $svariation_id) !== "inactive")  throw new CsException("Product status is neither active nor inactive");

                if (!Listing::is_listing_id($listing_id))  throw new CsException("Some of the listings you requested don't exist");
                $Listing = new Listing($listing_id);
                if ($Listing->seller()->user_id !== $LogSeller->user_id) throw new CsException("");
                if (!$Listing->is_variation_id($variation_id))  throw new CsException("Some of the listings you requested don't exist");
                if (!$Listing->is_svariation_id($variation_id, $svariation_id))  throw new CsException("Some of the listings you requested don't exist");
                $sql = "UPDATE $Web->ecommerce_listing_variations_tbl SET status = ? WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? AND user_id = ? ";
                $sql = $db->prepare($sql);
                $sql->execute([$status, $listing_id, $variation_id, $svariation_id, $LogSeller->user_id]);

                $sql = "UPDATE $Web->ecommerce_variations_tbl SET status = ?  WHERE product_id = ? AND variation_id = ? AND  svariation_id = ? AND user_id = ? ";
                $sql = $db->prepare($sql);
                $sql->execute([$status, $product_id, $variation_id, $svariation_id, $LogSeller->user_id]);
            }
            $db->commit();
        } catch (CsException $e) {
            $db->rollBack();
            Errors::response($e->getMessage());
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in updating status" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = $status == "active" ? "Lisings has been active" : "Lisings has been inactive";
        echo json_encode($output);

        break;

    case "updating_listing_tbl_data":

        if (!$Web->is_isset("svariation_id", "variation_id", "product_id", "column")) Errors::response("Invalid Request");
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $product_id = $Web->sanitize_text($_POST["product_id"]);
        $column = $Web->sanitize_text($_POST["column"]);

        if (!Product::is_product_id($product_id)) Errors::response("Product doesn't exist");
        $Product = new Product($product_id);
        if ($Product->seller()->user_id !== $LogSeller->user_id) Errors::response_404();
        $listing_id = $Product->listing_id();

        $output = new stdClass;

        switch ($column) {
            case "stock":
                if (!$Web->is_isset("stock")) Errors::response("Invalid Request");
                $stock = $Web->sanitize_text($_POST["stock"]);
                $Web->validate_post_input($stock, "number", "Stock", true);


                try {
                    $db->beginTransaction();

                    $stmt = $db->prepare("UPDATE $Web->ecommerce_variations_tbl SET stock = ? WHERE product_id = ? AND variation_id = ? AND svariation_id = ? AND user_id = ? ");
                    $stmt->execute([$stock, $product_id, $variation_id, $svariation_id, $LogSeller->user_id]);

                    $stmt = $db->prepare("UPDATE $Web->ecommerce_listing_variations_tbl SET stock = ? WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? AND user_id = ? ");
                    $stmt->execute([$stock, $listing_id, $variation_id, $svariation_id, $LogSeller->user_id]);
                    $db->commit();
                } catch (\Exception $e) {
                    $db->rollBack();
                    Errors::response_500("Error in updating stock" . $e->getMessage());
                }
                $output->message = "Stock has been updated";
                break;
            case "mrp":
                if (!$Web->is_isset("mrp")) Errors::response("Invalid Request");
                $mrp = $Web->sanitize_text($_POST["mrp"]);
                $Web->validate_post_input($mrp, "number", "MRP", true);
                $price = $Product->price($variation_id, $svariation_id);
                if ($price > $mrp) Errors::response("Mrp is smaller than price");


                try {
                    $db->beginTransaction();

                    $stmt = $db->prepare("UPDATE $Web->ecommerce_variations_tbl SET mrp = ? WHERE product_id = ? AND variation_id = ? AND svariation_id = ? AND user_id = ? ");
                    $stmt->execute([$mrp, $product_id, $variation_id, $svariation_id, $LogSeller->user_id]);

                    $stmt = $db->prepare("UPDATE $Web->ecommerce_listing_variations_tbl SET mrp = ? WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? AND user_id = ? ");
                    $stmt->execute([$mrp, $listing_id, $variation_id, $svariation_id, $LogSeller->user_id]);
                    $db->commit();
                } catch (\Exception $e) {
                    $db->rollBack();
                    Errors::response_500("Error in updating mrp" . $e->getMessage());
                }

                $output->message = "Mrp has been updated";
                break;

            case "price":
                if (!$Web->is_isset("price")) Errors::response("Invalid Request");
                $price = $Web->sanitize_text($_POST["price"]);
                $Web->validate_post_input($price, "number", "Price", true);
                $mrp = $Product->mrp($variation_id, $svariation_id);
                if ($price > $mrp) Errors::response("Price is greater than Mrp");

                try {
                    $db->beginTransaction();

                    $stmt = $db->prepare("UPDATE $Web->ecommerce_variations_tbl SET price = ? WHERE product_id = ? AND variation_id = ? AND svariation_id = ? AND user_id = ? ");
                    $stmt->execute([$price, $product_id, $variation_id, $svariation_id, $LogSeller->user_id]);

                    $stmt = $db->prepare("UPDATE $Web->ecommerce_listing_variations_tbl SET price = ? WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? AND user_id = ? ");
                    $stmt->execute([$price, $listing_id, $variation_id, $svariation_id, $LogSeller->user_id]);
                    $db->commit();
                } catch (\Exception $e) {
                    $db->rollBack();
                    Errors::response_500("Error in updating price" . $e->getMessage());
                }

                $output->message = "Price has been updated";

                break;
            default:
                Errors::response_404();
                break;
        }

        echo json_encode($output);

        break;

    default:
        Errors::response_404();
        break;
}
