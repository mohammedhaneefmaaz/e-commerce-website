<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists('Errors::response_404')) {
        include("../../../db.php");
    }
    Errors::response_404();
}

use Ecommerce\Listing;
use Ecommerce\Category;
use Ecommerce\Product;
use Ecommerce\QC;
use Ecommerce\Select;

if (!isset($_POST["case"]))  Errors::response_404();

$case = $_POST["case"];
if ($Web->is_empty($case)) Errors::response_404();

if (!$Login->is_seller_loggedin()) Errors::force_login("seller");

switch ($case) {

    case "fetch_categories":
        if (!$Web->is_isset("category_id")) Errors::response("Invalid Request");
        $category_id = $Web->sanitize_text($_POST["category_id"]);
        if (!Category::is_category_id($category_id) && $category_id != '0') Errors::response("Category do not exist");

        if (Category::is_category_id($category_id)) {
            $Category = new Category($category_id);
            if (!$Category->has_or_child_content()) Errors::response("Sorry the category hasn't sufficient data for listing");
        }

        $output = new stdClass;
        $output->data = $category_id == '0' ?  Listing::choose_categories() :  Listing::choose_categories($category_id);
        $output->header = $category_id == '0' ? ' <div class="card-title">
                <h4 class="text-original" >Select Category </h4>
            </div>' : Listing::choose_categories_breadcrum($category_id);
        echo json_encode($output);
        break;

    case "fetch_category_images":
        if (!$Web->is_isset("category_id")) Errors::response("Invalid Request");
        $category_id = $Web->sanitize_text($_POST["category_id"]);
        if (!Category::is_category_id($category_id)) Errors::response("Category do not exist");
        $Category = new Category($category_id);
        if (!$Category->has_content()) Errors::response("Sorry the category hasn't sufficient data for listing");
        $images = $Category->images();

        $images_list = '';
        if (is_array($images)) {
            foreach ($images as $image_id) {
                $src = $Web->get_file_src($image_id);
                $images_list .= '<div class="flex-1" ><img class="mh-100 img-fluid" src="' . $src . '" ></div>';
            }
        }

        $content = '
        <div class="card-body">
            <div class="d-flex category-img-wrapper flex-wrap" > ' . $images_list . ' </div>
            <div class="justify-right mt-4" >
                <button id="continue_to_listing" data-id="' . $category_id . '" type="button" class="btn btn-lg btn-primary" >Continue 
											<span class="svg-icon svg-icon-3 ms-1 me-0">
												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
													<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black"></rect>
													<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black"></path>
												</svg>
											</span>
			</button>
            </div>
        </div>';
        $header = $category_id == '0' ? ' <div class="card-title">
                <h4 class="text-original" >Select Category </h4>
            </div>' : Listing::choose_categories_breadcrum($category_id);

        $output = new stdClass;
        $output->content = $content;
        $output->header = $header;

        echo json_encode($output);
        break;

    case "create_listing":

        if (!$Web->is_isset("category_id")) Errors::response("Invalid Request");
        $category_id = $Web->sanitize_text($_POST["category_id"]);
        if (!Category::is_category_id($category_id)) Errors::response("Category do not exist");
        $C = new Category($category_id);
        if (!$C->has_content()) Errors::response("Sorry the category hasn't sufficient data for listing");
        if (!$C->can_add_listing()) Errors::response("Sorry, the category is not available");


        try {
            $db->beginTransaction();
            $stmt = $db->prepare("INSERT INTO $Web->ecommerce_listing_tbl (`user_id`, `category_id`)
            VALUES (?,?) ");
            $stmt->execute([$LogSeller->user_id, $category_id]);
            $listing_id = $db->lastInsertId();
            $Listing = new Listing($listing_id);
            $variation_id = $Listing->create_variation_id();
            $svariation_id = $Listing->create_svariation_id($variation_id);
            $date_created = $Web->current_time();
            $last_modified = $Web->current_time();

            $sql = "INSERT INTO `$Web->ecommerce_listing_variations_tbl` (`user_id`, `listing_id`, `variation_id`, `svariation_id`,`date_created`, `last_modified`) VALUES (:user_id,:listing_id,:variation_id,:svariation_id,:date_created,:last_modified) ";

            $stmt = $db->prepare($sql);
            $stmt->execute([
                ":user_id" => $LogSeller->user_id,
                ":listing_id" => $listing_id,
                ":variation_id" => $variation_id,
                ":svariation_id" => $svariation_id,
                ":date_created" => $date_created,
                ":last_modified" => $last_modified
            ]);
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in creating listing" . $e->getMessage());
        }

        $output = new stdClass;
        $output->url = $Listing->vurl($variation_id, $svariation_id);
        echo json_encode($output);
        break;

    case "get_create_variation_form":
        if (!$Web->is_isset("listing_id", "variation_id", "svariation_id", "role")) Errors::response_404();
        $role = $Web->sanitize_text($_POST["role"]);
        $listing_id = $Web->sanitize_text($_POST["listing_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);

        if (!Listing::is_listing_id($listing_id)) Errors::response("Listing doesn't exist");
        $Listing = new Listing($listing_id);
        if ($Listing->seller()->user_id !== $LogSeller->user_id) Errors::response_404();
        if (!$Listing->is_variation_id($variation_id)) Errors::response("Variation doesn't exist");
        if (!$Listing->is_svariation_id($variation_id, $svariation_id)) Errors::response("Variation doesn't exist");
        if (!$Listing->can_add_variation()) Errors::response("You can't create new variations to this listing");
        if ($role !== "primary" && $role !== "secondary") Errors::response("Invalid role");
        if (!$Listing->category()->has_variation()) Errors::response("Variation are not supported for this category");

        $card = $Listing->create_variation_form($variation_id, "clone_svariation");


        switch ($role) {
            case "primary":
                $card = $Listing->create_variation_form($variation_id, "primary");
                break;
            case "secondary":
                if (!$Listing->category()->has_svariation()) Errors::response("Variation are not supported for this category");
                $card = $Listing->create_variation_form($variation_id, "secondary");
                break;
        }


        $output = new stdClass;
        $output->card = $card;
        $output->card_header = "Create a variation";
        echo json_encode($output);

        break;

    case "create_variation":

        if (!$Web->is_isset("listing_id", "variation_id", "svariation_id", "event_type")) Errors::response("Invalid data requested");
        $listing_id = $Web->sanitize_text($_POST["listing_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);
        $event_type = $Web->sanitize_text($_POST["event_type"]);

        if (!Listing::is_listing_id($listing_id)) Errors::response("Listing doesn't exist");
        $Listing = new Listing($listing_id);
        if (!$Listing->can_add_variation()) Errors::response("You can't create new variations to this listing");
        if ($Listing->seller()->user_id !== $LogSeller->user_id) Errors::response_404();
        if (!$Listing->is_variation_id($variation_id)) Errors::response("Variation doesn't exist");
        if (!$Listing->is_svariation_id($variation_id, $svariation_id)) Errors::response("SVariation doesn't exist");
        if ($event_type !== "primary" && $event_type !== "secondary" && $event_type !== "clone_variation" && $event_type !== "clone_svariation") Errors::response_404();
        if (!$Listing->category()->has_variation()) Errors::response("Variation are not supported for this category");

        $date_created = $Web->current_time();
        $last_modified = $Web->current_time();

        function create_svariation($new_variation_id, $params, $clone = false)
        {
            $Web = $params["Web"];
            $Listing = $params["Listing"];
            $variation_id = $params["variation_id"];
            $svariation_id = $params["svariation_id"];
            $LogSeller = $params["LogSeller"];

            $date_created = $Web->current_time();
            $last_modified = $Web->current_time();

            $listing_id = $Listing->listing_id;

            $row = $Listing->vrow($variation_id, $svariation_id);
            $svariation_id = $Listing->create_svariation_id($new_variation_id);
            $variation_value = $row->variation_value;
            $variation_data = $row->variation_data;
            $details = $row->details;
            $images = $row->images;
            $price = $row->price;
            $mrp = $row->mrp;
            $stock = $row->stock;
            $low_stock_warning = $row->low_stock_warning;
            $product_name = $row->product_name;
            $minimum_order = $row->minimum_order;
            $maximum_order = $row->maximum_order;
            $status = $row->status;
            $return_policy = $row->return_policy;
            $return_policy_days = $row->return_policy_days;
            $return_policy_tc = $row->return_policy_tc;
            $description = $row->description;
            $highlights = $row->highlights;
            $tags = $row->tags;

            if (is_array($clone)) {
                $svariation_value = $row->svariation_value;
                $svariation_data = $row->svariation_data;
                $variation_value = $clone["variation_value"];
                $variation_data = $clone["variation_data"];
            } else {

                $svariation_type = $Listing->svariation_input($variation_id, "type");
                $svariation_header_text = $Listing->svariation_header_text();


                switch ($svariation_type) {
                    case "input":
                    case "select":
                        if (!$Web->is_isset("svariation_value"))  throw new CsException("Invalid data requested");
                        $svariation_value = $Web->sanitize_text($_POST["svariation_value"]);
                        $Web->validate_post_input($svariation_value, "", "$svariation_header_text", true);
                        if ($svariation_type == "select") {
                            $select_id = $Listing->svariation_input($variation_id, "select");
                            $Select = new Select($select_id);
                            if (!$Select->is_valid_option($svariation_value)) {
                                Errors::response("Selected $svariation_header_text is not a valid $svariation_header_text");
                            }
                        }
                        $svariation_data = array(
                            "type" => $svariation_type
                        );
                        if (in_array($svariation_value, $Listing->used_svariation_options($variation_id)))  throw new CsException("Duplicate entry not allowed");

                        break;
                    default:
                        if (!$Web->is_isset("variation_value"))  throw new CsException("Invalid data requested");
                        $svariation_value = $Web->sanitize_text($_POST["variation_value"]);
                        $Web->validate_post_input($svariation_value, "", "$svariation_header_text", true);

                        $svariation_data = array(
                            "type" => $svariation_type,
                            "id" => $svariation_value
                        );
                        break;
                }
                $svariation_data = json_encode($svariation_data);
            }

            $sql = "INSERT INTO `$Web->ecommerce_listing_variations_tbl` (`user_id`, `listing_id`, `variation_id`, `svariation_id`, `variation_value`, `svariation_value`, `variation_data`, `svariation_data`, `details`, `images`, `price`, `mrp`, `stock`,`low_stock_warning`, `product_name`, `minimum_order`, `maximum_order`,`status`,`return_policy`, `return_policy_days`, `return_policy_tc` ,`description`,`highlights`,`date_created`, `last_modified`, `tags`) VALUES (:user_id,:listing_id,:variation_id,:svariation_id,:variation_value,:svariation_value,:variation_data,:svariation_data,:details,:images,:price,:mrp,:stock,:low_stock_warning,:product_name,:minimum_order,:maximum_order,:status,:return_policy,:return_policy_days,:return_policy_tc,:description,:highlights,:date_created,:last_modified, :tags)";
            $sql = $Web->db()->prepare($sql);
            $query = $sql->execute([
                ":user_id" => $LogSeller->user_id,
                ":listing_id" => $listing_id,
                ":variation_id" => $new_variation_id,
                ":svariation_id" => $svariation_id,
                ":variation_value" => $variation_value,
                ":svariation_value" => $svariation_value,
                ":variation_data" => $variation_data,
                ":svariation_data" => $svariation_data,
                ":details" => $details,
                ":images" => $images,
                ":price" => $price,
                ":mrp" => $mrp,
                ":stock" => $stock,
                ":low_stock_warning" => $low_stock_warning,
                ":product_name" => $product_name,
                ":minimum_order" => $minimum_order,
                ":maximum_order" => $maximum_order,
                ":status" => $status,
                ":return_policy" => $return_policy,
                ":return_policy_days" => $return_policy_days,
                ":return_policy_tc" => $return_policy_tc,
                ":description" => $description,
                ":highlights" => $highlights,
                ":date_created" => $date_created,
                ":last_modified" => $last_modified,
                ":tags" => $tags
            ]);
            if (!$query) throw new Exception("Error in creating variation");

            $output = new stdClass;
            $output->query = $query;
            $output->svariation_id = $svariation_id;
            return $output;
        }


        try {

            $db->beginTransaction();
            $variation_type = $Listing->variation_input("type");
            switch ($event_type) {
                case "primary":
                    if (!$Web->is_isset("variation_value"))  throw new CsException("Invalid data requested");
                    $variation_value = $Web->sanitize_text($_POST["variation_value"]);
                    $variation_header_text = $Listing->variation_header_text();
                    $Web->validate_post_input($variation_value, "", "$variation_header_text", true);
                    if ($variation_type == "select") {
                        $select_id = $Listing->variation_input("select");
                        $Select = new Select($select_id);
                        if (!$Select->is_valid_option($variation_value)) {
                            throw new CsException("Selected $variation_header_text is not a valid $variation_header_text");
                        }
                    }

                    switch ($variation_type) {
                        case "input":
                        case "select":
                            $variation_data = array(
                                "type" => $variation_type
                            );
                            if (in_array($variation_value, $Listing->used_variation_options($variation_id)))  throw new CsException("Duplicate entry not allowed");
                            break;
                        default:
                            $FileUpload = new FileUpload("image");
                            $upload = $FileUpload->upload();
                            if ($upload->type == "error")  throw new CsException($upload->message);
                            $variation_data = array(
                                "type" => $variation_type,
                                "id" => $upload->id
                            );
                            break;
                    }

                    $variation_data = json_encode($variation_data);
                    if ($Listing->is_variation_real($variation_id, $svariation_id)) {
                        $variation_id = $Listing->create_variation_id();
                        $svariation_id = $Listing->create_svariation_id($variation_id);

                        $sql = "INSERT INTO `$Web->ecommerce_listing_variations_tbl` (`user_id`, `listing_id`, `variation_id`, `svariation_id`, `variation_value`, `variation_data`,`date_created`, `last_modified`) VALUES (:user_id,:listing_id,:variation_id,:svariation_id,:variation_value,:variation_data,:date_created,:last_modified) ";

                        $stmt = $db->prepare($sql);
                        $stmt->execute([
                            ":user_id" => $LogSeller->user_id,
                            ":listing_id" => $listing_id,
                            ":variation_id" => $variation_id,
                            ":svariation_id" => $svariation_id,
                            ":variation_value" => $variation_value,
                            ":variation_data" => $variation_data,
                            ":date_created" => $date_created,
                            ":last_modified" => $last_modified
                        ]);
                    } else {

                        $stmt = $db->prepare("UPDATE $Web->ecommerce_listing_variations_tbl SET variation_data = ?,variation_value = ? WHERE listing_id = ?  AND variation_id = ? AND user_id = ? ");
                        $stmt->execute([$variation_data, $variation_value, $listing_id, $variation_id, $LogSeller->user_id]);

                        if ($Listing->is_variation_live($variation_id)) {
                            $product_id = $Listing->live_product_id();

                            $stmt = $db->prepare("UPDATE $Web->ecommerce_variations_tbl SET variation_data = ?,variation_value = ? WHERE  variation_id = ? AND product_id = ? AND user_id = ? ");
                            $stmt->execute([$variation_data, $variation_value, $variation_id, $product_id, $LogSeller->user_id]);
                        }
                    }

                    break;

                case "secondary":
                    if (!$Listing->category()->has_svariation())  throw new CsException("Variation are not supported for this category");

                    $svariation_type = $Listing->svariation_input($variation_id, "type");
                    $svariation_header_text = $Listing->svariation_header_text();

                    $variation_value = $Listing->variation_value($variation_id, $svariation_id);
                    $variation_data = $Listing->variation_data($variation_id, $svariation_id);


                    switch ($svariation_type) {
                        case "input":
                        case "select":
                            if (!$Web->is_isset("svariation_value"))  throw new CsException("Invalid data requested");
                            $svariation_value = $Web->sanitize_text($_POST["svariation_value"]);
                            $Web->validate_post_input($svariation_value, "", "$svariation_header_text", true);

                            if ($svariation_type == "select") {
                                $select_id = $Listing->svariation_input($variation_id, "select");
                                $Select = new Select($select_id);
                                if (!$Select->is_valid_option($svariation_value)) {
                                    throw new CsException("Selected $svariation_header_text is not a valid $svariation_header_text");
                                }
                            }

                            $svariation_data = array(
                                "type" => $svariation_type
                            );
                            if (in_array($svariation_value, $Listing->used_svariation_options($variation_id)))  throw new CsException("Duplicate entry not allowed");
                            break;
                        default:
                            $svariation_value = "img";
                            $FileUpload = new FileUpload("image");
                            $upload = $FileUpload->upload();
                            if ($upload->type == "error")  throw new CsException($upload->message);
                            $svariation_data = array(
                                "type" => $svariation_type,
                                "id" => $upload->id
                            );
                            break;
                    }
                    $svariation_data = json_encode($svariation_data);

                    if ($Listing->is_svariation_real($variation_id, $svariation_id)) {
                        $svariation_id = $Listing->create_svariation_id($variation_id);

                        $sql = "INSERT INTO `$Web->ecommerce_listing_variations_tbl` (`user_id`, `listing_id`, `variation_id`, `svariation_id`, `variation_value`,`svariation_value`, `variation_data`,`svariation_data`,`date_created`, `last_modified`) VALUES (:user_id,:listing_id,:variation_id,:svariation_id,:variation_value,:svariation_value,:variation_data,:svariation_data,:date_created,:last_modified) ";

                        $stmt = $db->prepare($sql);
                        $stmt->execute([
                            ":user_id" => $LogSeller->user_id,
                            ":listing_id" => $listing_id,
                            ":variation_id" => $variation_id,
                            ":svariation_id" => $svariation_id,
                            ":variation_value" => $variation_value,
                            ":svariation_value" => $svariation_value,
                            ":variation_data" => $variation_data,
                            ":svariation_data" => $svariation_data,
                            ":date_created" => $date_created,
                            ":last_modified" => $last_modified
                        ]);
                    } else {

                        $stmt = $db->prepare("UPDATE $Web->ecommerce_listing_variations_tbl SET svariation_data = ?,svariation_value = ? WHERE listing_id = ?  AND variation_id = ? AND svariation_id = ? AND user_id = ? ");
                        $stmt->execute([$svariation_data, $svariation_value, $listing_id, $variation_id, $svariation_id, $LogSeller->user_id]);


                        $Listing->is_variation_live($variation_id) ? "true" : "false";

                        if ($Listing->is_variation_live($variation_id)) {

                            $product_id = $Listing->live_product_id();
                            $stmt = $db->prepare("UPDATE $Web->ecommerce_variations_tbl SET svariation_data = ?,svariation_value = ? WHERE  variation_id = ? AND svariation_id = ? AND product_id = ? AND user_id = ? ");
                            $stmt->execute([$svariation_data, $svariation_value, $variation_id, $svariation_id, $product_id, $LogSeller->user_id]);
                        }
                    }

                    break;

                case "clone_variation":

                    if (!$Listing->is_variation_real($variation_id, $svariation_id))  throw new CsException("This variation can't be clone");
                    if (!$Web->is_isset("svariations"))  throw new CsException("Invalid data requested");
                    $svariations = $Web->sanitize_text($_POST["svariations"]);
                    if (!is_array($svariations))  throw new CsException("Invalid data requested");
                    if (empty($svariations))  throw new CsException("Please choose at least a variation");

                    if (!$Web->is_isset("variation_value"))  throw new CsException("Invalid data requested");

                    $variation_value = $Web->sanitize_text($_POST["variation_value"]);
                    $variation_header_text = $Listing->variation_header_text();
                    $Web->validate_post_input($variation_value, "", "$variation_header_text", true);

                    foreach ($svariations as $key_svariation_id) {
                        if (!$Listing->is_svariation_id($variation_id, $key_svariation_id))  throw new CsException("Some of the variations you requested don't exist");
                    }

                    if ($variation_type === "select") {
                        $select_id = $Listing->variation_input("select");
                        $Select = new Select($select_id);
                        if (!$Select->is_valid_option($variation_value)) {
                            throw new CsException("Selected $variation_header_text is not a valid $variation_header_text");
                        }
                    }

                    switch ($variation_type) {
                        case "input":
                        case "select":
                            $variation_data = array(
                                "type" => $variation_type
                            );
                            if (in_array($variation_value, $Listing->used_variation_options($variation_id)))  throw new CsException("Duplicate entry not allowed");

                            break;
                        default:

                            $variation_data = array(
                                "type" => $variation_type,
                                "id" => $variation_value
                            );
                            break;
                    }

                    $variation_data = json_encode($variation_data);
                    $new_variation_id = $Listing->create_variation_id();

                    foreach ($svariations as $key_svariation_id) {
                        $clone =  create_svariation($new_variation_id, array(
                            "Listing" => $Listing,
                            "Web" => $Web,
                            "variation_id" => $variation_id,
                            "svariation_id" => $key_svariation_id,
                            "LogSeller" => $LogSeller,
                        ), array(
                            "variation_data" => $variation_data,
                            "variation_value" => $variation_value,
                        ));
                        $prepare = $clone->query;
                        if (!$prepare)  throw new CsException("Error in cloning variation");
                    }
                    $svariation_id = $Listing->st_svariation($new_variation_id);
                    $variation_id = $new_variation_id;

                    break;

                case "clone_svariation":
                    if (!$Listing->is_svariation_real($variation_id, $svariation_id))  throw new CsException("This variation can't be clone");
                    $clone =  create_svariation($variation_id, array(
                        "Listing" => $Listing,
                        "Web" => $Web,
                        "variation_id" => $variation_id,
                        "svariation_id" => $svariation_id,
                        "LogSeller" => $LogSeller,
                    ));
                    $svariation_id = $clone->svariation_id;
                    break;
            }

            $db->commit();
        } catch (\CsException $e) {
            $db->rollBack();
            Errors::response($e->getMessage());
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in creating variation" . $e->getMessage() . $e->getLine());
        }

        $output = new stdClass;
        $output->url = $Listing->vurl($variation_id, $svariation_id);
        echo json_encode($output);
        break;


    case "archive_variation":
        if (!$Web->is_isset("listing_id", "variation_id", "svariation_id")) Errors::response("Invalid Request");
        $listing_id = $Web->sanitize_text($_POST["listing_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $active_svariation_id = $Web->sanitize_text($_POST["svariation_id"]);

        if (!Listing::is_listing_id($listing_id)) Errors::response("Listing doesn't exist");
        $Listing = new Listing($listing_id);
        if (!$Listing->can_update_variation()) Errors::response("You can't update the listing");
        if ($Listing->seller()->user_id !== $LogSeller->user_id) Errors::response_404();
        if (!$Listing->is_variation_id($variation_id)) Errors::response("Variation doesn't exist");
        $product_id = $Listing->live_product_id();
        if (!$Listing->is_variation_live($variation_id)) Errors::response("This Listing can't be archived");
        $Product = new Product($product_id);

        if ($Product->status($variation_id, $active_svariation_id) == "archived") {
            $text = "Archive";
            $status = $Listing->status($variation_id, $active_svariation_id);
            $message = "Listing has been unarchived";
        } else {
            $text = "Unarchive";
            $status = "archived";
            $message = "Listing has been archived";
        }

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("SELECT svariation_id FROM $Web->ecommerce_listing_variations_tbl WHERE listing_id = ? AND variation_id = ? AND is_draft = 'no' ");
            $stmt->execute([$listing_id, $variation_id]);

            while ($row = $stmt->fetch()) {
                $svariation_id = $row->svariation_id;

                $stmt_a = $db->prepare("UPDATE $Web->ecommerce_variations_tbl SET status = ? WHERE product_id = ? AND variation_id = ? AND svariation_id = ? AND user_id = ?  ");
                $stmt_a->execute([$status, $product_id, $variation_id, $svariation_id, $LogSeller->user_id]);
            }
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in archiving listing" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = $message;
        $output->text = $text;
        $output->statusLabel = $Listing->live_product()->product_status($variation_id, $active_svariation_id);
        echo json_encode($output);
        break;

    case "archive_svariation":
        if (!$Web->is_isset("listing_id", "variation_id", "svariation_id")) Errors::response("Invalid Request");
        $listing_id = $Web->sanitize_text($_POST["listing_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);

        if (!Listing::is_listing_id($listing_id)) Errors::response("Listing doesn't exist");
        $Listing = new Listing($listing_id);
        if (!$Listing->can_update_variation()) Errors::response("You can't update the listing");
        if ($Listing->seller()->user_id !== $LogSeller->user_id) Errors::response_404();
        if (!$Listing->is_variation_id($variation_id)) Errors::response("Variation doesn't exist");
        $product_id = $Listing->live_product_id();
        if (!$Listing->is_variation_live($variation_id)) Errors::response("This Listing can't be archived");
        $Product = new Product($product_id);

        try {
            $db->beginTransaction();
            if ($Product->status($variation_id, $svariation_id) == "archived") {
                $text = "Archive";
                $status = $Listing->status($variation_id, $svariation_id);
                $message = "Listing has been unarchived";
            } else {
                $text = "Unarchive";
                $status = "archived";
                $message = "Listing has been archived";
            }

            $stmt_a = $db->prepare("UPDATE $Web->ecommerce_variations_tbl SET status = ? WHERE product_id = ? AND variation_id = ? AND svariation_id = ? AND user_id = ?  ");
            $stmt_a->execute([$status, $product_id, $variation_id, $svariation_id, $LogSeller->user_id]);
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in archiving listing" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = $message;
        $output->text = $text;
        $output->statusLabel = $Listing->live_product()->product_status($variation_id, $svariation_id);
        echo json_encode($output);
        break;

    case "delete_variation":
        if (!$Web->is_isset("listing_id", "variation_id")) Errors::response("Invalid Request");
        $listing_id = $Web->sanitize_text($_POST["listing_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);

        if (!Listing::is_listing_id($listing_id)) Errors::response("Listing doesn't exist");
        $Listing = new Listing($listing_id);
        if ($Listing->seller()->user_id !== $LogSeller->user_id) Errors::response_404();
        if (!$Listing->is_variation_id($variation_id)) Errors::response("Variation doesn't exist");

        if ($Listing->is_variation_live($variation_id)) Errors::response("This Variation can't be deleted");

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_listing_variations_tbl WHERE listing_id = ? AND variation_id = ? AND user_id = ?  ");
            $stmt->execute([$listing_id, $variation_id, $LogSeller->user_id]);

            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_qc_tbl WHERE listing_id = ? AND variation_id = ?  ");
            $stmt->execute([$listing_id, $variation_id]);
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in deleting listing" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Listing variation has been deleted";
        $output->url = $Listing->url();
        echo json_encode($output);
        break;

    case "delete_svariation":
        if (!$Web->is_isset("listing_id", "variation_id", "svariation_id")) Errors::response("Invalid Request");
        $listing_id = $Web->sanitize_text($_POST["listing_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);

        if (!Listing::is_listing_id($listing_id)) Errors::response("Listing doesn't exist");
        $Listing = new Listing($listing_id);
        if ($Listing->seller()->user_id !== $LogSeller->user_id) Errors::response_404();
        if (!$Listing->is_variation_id($variation_id)) Errors::response("Variation doesn't exist");
        if (!$Listing->is_svariation_id($variation_id, $svariation_id)) Errors::response("Variation doesn't exist");

        if ($Listing->is_svariation_live($variation_id, $svariation_id)) Errors::response("This Variation can't be deleted");

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_listing_variations_tbl WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? AND user_id = ?  ");
            $stmt->execute([$listing_id, $variation_id, $svariation_id, $LogSeller->user_id]);

            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_qc_tbl WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? ");
            $stmt->execute([$listing_id, $variation_id, $svariation_id]);

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in deleting listing" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Listing variation has been deleted";
        $output->url = $Listing->url($variation_id);
        echo json_encode($output);
        break;

    case "clone_variation":
        if (!$Web->is_isset("listing_id", "variation_id", "svariation_id")) Errors::response("Invalid Request");
        $listing_id = $Web->sanitize_text($_POST["listing_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);

        if (!Listing::is_listing_id($listing_id)) Errors::response("Listing doesn't exist");
        $Listing = new Listing($listing_id);
        if (!$Listing->can_add_variation()) Errors::response("You can't create new variations to this listing");
        if ($Listing->seller()->user_id !== $LogSeller->user_id) Errors::response_404();
        if (!$Listing->is_variation_id($variation_id)) Errors::response("Variation doesn't exist");
        if (!$Listing->is_svariation_id($variation_id, $svariation_id)) Errors::response("Variation doesn't exist");

        $card = $Listing->create_variation_form($variation_id, "clone_variation");

        $output = new stdClass;
        $output->card = $card;
        $output->card_header = "Clone variation";
        echo json_encode($output);
        break;

    case "clone_svariation":

        if (!$Web->is_isset("listing_id", "variation_id", "svariation_id")) Errors::response("Invalid Request");
        $listing_id = $Web->sanitize_text($_POST["listing_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);

        if (!Listing::is_listing_id($listing_id)) Errors::response("Listing doesn't exist");
        $Listing = new Listing($listing_id);
        if (!$Listing->can_add_variation()) Errors::response("You can't create new variations to this listing");
        if ($Listing->seller()->user_id !== $LogSeller->user_id) Errors::response_404();
        if (!$Listing->is_variation_id($variation_id)) Errors::response("Variation doesn't exist");
        if (!$Listing->is_svariation_id($variation_id, $svariation_id)) Errors::response("Variation doesn't exist");

        $card = $Listing->create_variation_form($variation_id, "clone_svariation");

        $output = new stdClass;
        $output->card = $card;
        $output->card_header = "Clone variation";
        echo json_encode($output);
        break;



    case "save_variation":

        if (!$LogSeller->is_verified())  Errors::response("Listing isn't available for unverified seller");

        if (!$Web->is_isset(
            "listing_id",
            "variation_id",
            "svariation_id",
            "data",
            "product_name",
            "minimum_order",
            "maximum_order",
            "product_mrp",
            "product_price",
            "cod_status",
            "stock",
            "low_stock_warning",
            "sku_id",
            "product_status",
            "return_policy",
            "return_policy_days",
            "return_policy_tc",
            "tags",
            "description"
        )) Errors::response("Invalid Request");

        $listing_id = $Web->sanitize_text($_POST["listing_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);
        $product_name = $Web->sanitize_text($_POST["product_name"]);
        $minimum_order = $Web->sanitize_text($_POST["minimum_order"]);
        $maximum_order = $Web->sanitize_text($_POST["maximum_order"]);
        $product_mrp = $Web->sanitize_text($_POST["product_mrp"]);
        $product_price = $Web->sanitize_text($_POST["product_price"]);
        $cod_status = $Web->sanitize_text($_POST["cod_status"]);
        $stock = $Web->sanitize_text($_POST["stock"]);
        $low_stock_warning = $Web->sanitize_text($_POST["low_stock_warning"]);
        $sku_id = $Web->sanitize_text($_POST["sku_id"]);
        $product_status = $Web->sanitize_text($_POST["product_status"]);
        $return_policy = $Web->sanitize_text($_POST["return_policy"]);
        $return_policy_days = $Web->sanitize_text($_POST["return_policy_days"]);
        $return_policy_tc = $Web->sanitize_text($_POST["return_policy_tc"]);
        $tags = $_POST["tags"];
        $description = $Web->sanitize_text($_POST["description"]);
        $data = $Web->sanitize_text($_POST["data"]);
        $tags = json_decode($tags,true);
        if(!is_array($tags)) $tags = [];

        if (!Listing::is_listing_id($listing_id)) Errors::response("Listing doesn't exist");
        $Listing = new Listing($listing_id);
        if ($Listing->seller()->user_id !== $LogSeller->user_id) Errors::response_404();
        if (!$Listing->is_variation_id($variation_id)) Errors::response("Variation doesn't exist");
        if (!$Listing->is_svariation_id($variation_id, $svariation_id)) Errors::response("SVariation doesn't exist");
        if (!$Listing->can_update_variation()) Errors::response("You can't update the listing");

        $Web->validate_post_length($description, 5000, "Maximum product description length is 5000");
        $Web->validate_post_length($_POST["return_policy_tc"], 5000, "Maximum Return policy length is 5000");
        $Web->validate_post_length($_POST["product_name"], 200, "Maximum Product name length is 200");

        if (!is_array($data)) Errors::response("Invalid data requested");
        if (!isset($data['details'], $data['images'])) Errors::response("Invalid data requested");

        $Web->validate_post_input($product_name, "", "Product Name", true);
        $Web->validate_post_input($minimum_order, "number", "Minimum Order", true);
        $Web->validate_post_input($maximum_order, "number", "Maximum Order", true);
        $Web->validate_post_input($product_mrp, "number", "Product Mrp", true);
        $Web->validate_post_input($product_price, "number", "Product Price", true);
        $Web->validate_post_input($stock, "number", "Product Stock", true);
        $Web->validate_post_input($low_stock_warning, "number", "Low Stock Warning", true);
        $Web->validate_post_input($sku_id, "alphanumeric", "Product Sku Id", true);
        $Web->validate_post_input($product_status, "", "Product Status", true);
        $Web->validate_post_input($return_policy, "", "Return Policy", true);

        if ($return_policy !== "no") {
            $Web->validate_post_input($return_policy_days, "number", "Return Policy Days", true);
            $Web->validate_post_input($return_policy_tc, "", "Return Policy T&C", true);
        }else{
            $return_policy_days = 0;
            $return_policy_tc = NULL;
        }

        if ($minimum_order < 1) Errors::response("Minimum order should be more than 0");
        if ($maximum_order < $minimum_order) Errors::response("Maximum order should be less than minimum order");
        if ($return_policy !== "return" && $return_policy !== "replacement" && $return_policy !== "no") Errors::response("Invalid Return Policy");
        if ($product_status !== "active" && $product_status !== "inactive") Errors::response("Invalid Product Status");
        if ($cod_status !== "no" && $cod_status !== "yes") Errors::response("Invalid Cash On Delivery");


        if ($product_mrp < $product_price) Errors::response("Mrp is smaller than Price");
        if ($Listing->is_sku_id($variation_id, $svariation_id, $sku_id)) Errors::response("Duplicate SKU Id");

        $details = $data["details"];
        $images = $data["images"];

        if (
            (!is_array($details)) || (!is_array($images))
        ) Errors::response("Invalid data requested");

        $C = new Category($Listing->category_id());


        /**
         * Validating Images
         */
        $required_images = 3;
        foreach ($images as $key => $image) {
            if ($image["type"] == "image" && $key <= $required_images) {
                if (!$Web->is_file_id($image["id"])) Errors::response("$required_images images are mandatory");
            }
            $images[$key]["src"] = $Web->get_file_src($image["id"]);
        }

        /**
         * Validating Details
         */

        $product_details_id_keys = $Listing->product_details_id_keys();
        if ($product_details_id_keys != array_keys($details)) Errors::response("Invalid data requested in Product Details");

        foreach ($details as $detail_id => $val) {
            $text = $C->detail_text($detail_id);
            $details[$detail_id] = $Web->sanitize_text($val);

            if ($C->detail_mandatory($detail_id)) {
                $Web->validate_post_input($val, "", $text . " in Product Details", true);
            }
            $Web->validate_post_length($val, 200, $text . " in Product Details  Maximum length is 200");
        }


        $highlights = [];
        if (isset($_POST["highlights"])) {
            $highlights = $_POST["highlights"];
            if (!is_array($highlights)) Errors::response("Invalid highlights data");
            if (count($highlights) > 10) Errors::response("Max highlights should be 10");
            foreach ($highlights as $key => $val) {
                if ($Web->is_empty($val)) unset($highlights[$key]);
                else {
                    $row = $key + 1;
                    $Web->validate_post_length($val, 500, "Highlights key length must be 500 or less in row $row ");
                    $highlights[$key] = $Web->sanitize_text($val);
                }
            }
        }

        // Validating tags
      
        $tags_length = 0;
        $max_tags_length = 500;
        foreach ($tags as $item) {
           $tag = $item["value"];
           $tags_length += strlen($tag);
        }
        if($tags_length > $max_tags_length) Errors::response("Tags exceeds the maximum allowed limit of $max_tags_length");

        $tags = json_encode($tags);
        $details = json_encode($details);
        $images = json_encode($images);
        $highlights = json_encode($highlights);

        try {

            $sql = "UPDATE $Web->ecommerce_listing_variations_tbl SET details = :details,images = :images,price = :price, mrp = :mrp, stock = :stock, low_stock_warning = :low_stock_warning, sku_id = :sku_id, product_name = :product_name, minimum_order= :minimum_order, maximum_order = :maximum_order, cod_status = :cod_status, status = :status,  return_policy = :return_policy,return_policy_days = :return_policy_days, return_policy_tc = :return_policy_tc, highlights = :highlights, description = :description, tags = :tags WHERE listing_id = :listing_id AND variation_id  = :variation_id AND svariation_id = :svariation_id AND user_id = :user_id ";

            $stmt = $Web->db()->prepare($sql);
            $stmt->execute([
                ":details" => $details,
                ":images" => $images,
                ":price" => $product_price,
                ":mrp" => $product_mrp,
                ":stock" => $stock,
                ":low_stock_warning" => $low_stock_warning,
                ":sku_id" => $sku_id,
                ":product_name" => $product_name,
                ":minimum_order" => $minimum_order,
                ":maximum_order" => $maximum_order,
                ":cod_status" => $cod_status,
                ":status" => $product_status,
                ":return_policy" => $return_policy,
                ":return_policy_days" => $return_policy_days,
                ":return_policy_tc" => $return_policy_tc,
                ":highlights" => $highlights,
                ":description" => $description,
                ":tags" => $tags,
                ":listing_id" => $listing_id,
                ":variation_id" => $variation_id,
                ":svariation_id" => $svariation_id,
                ":user_id" => $LogSeller->user_id
            ]);

            $details = json_decode($details, true);

            if ($Listing->variation_type($variation_id, $svariation_id) == "image" && isset($details[$Listing->variation_information_id()])) {
                $variation_value =  $details[(int) $Listing->variation_information_id()];
                $stmt = $db->prepare("UPDATE $Web->ecommerce_listing_variations_tbl SET variation_value = ? WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? AND user_id = ? ");
                $stmt->execute([$variation_value, $listing_id, $variation_id, $svariation_id, $LogSeller->user_id]);
            }

            if ($Listing->svariation_type($variation_id, $svariation_id) == "image" && isset($details[$Listing->svariation_information_id()])) {
                $svariation_value =  $details[(int) $Listing->svariation_information_id()];
                $stmt = $db->prepare("UPDATE $Web->ecommerce_listing_variations_tbl SET svariation_value = ? WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? AND user_id = ? ");
                $stmt->execute([$svariation_value, $listing_id, $variation_id, $svariation_id, $LogSeller->user_id]);
            }

            if ($Listing->is_svariation_live($variation_id, $svariation_id)) {
                $Listing->update_svariation_updates($variation_id, $svariation_id);
            }
        } catch (Exception $e) {
            Errors::response_500("Error in updating details");
        }


        $output = new stdClass;
        $output->message = "Details has been updated";
        echo json_encode($output);
        break;

    case "send_to_qc":
        if (!$Web->is_isset("listing_id", "variation_id", "svariation_id")) Errors::response("Invalid Request");
        $listing_id = $Web->sanitize_text($_POST["listing_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);

        if (!Listing::is_listing_id($listing_id)) Errors::response("Listing doesn't exist");
        $Listing = new Listing($listing_id);
        if ($Listing->seller()->user_id !== $LogSeller->user_id) Errors::response_404();
        if (!$Listing->is_variation_id($variation_id)) Errors::response("Variation doesn't exist");
        if (!$Listing->can_add_variation()) Errors::response("You can't send the listing to qc");

        if ($svariation_id == "all") {
            $svariations_key = $Listing->svariations_key($variation_id);
        } else {
            if (!$Listing->is_svariation_id($variation_id, $svariation_id)) Errors::response("Variation don't exist");
            if ($Listing->is_svariation_in_qc($variation_id, $svariation_id)) Errors::response("Variation is already in qc");
            $svariations_key = [$svariation_id];
        }

        $qvariation_id = QC::create_qvariation_id();

        try {
            $db->beginTransaction();
            foreach ($svariations_key as $svariation_id) {
                if (!$Listing->is_svariation_live($variation_id, $svariation_id) && !$Listing->is_svariation_in_qc($variation_id, $svariation_id)) {
                    if (!empty($Listing->validation_errors($variation_id, $svariation_id)->errors)) {
                        $output = new stdClass;
                        $output->error = "true";
                        $output->url = $Listing->validation_errors($variation_id, $svariation_id)->url;
                        echo json_encode($output);
                        exit();
                    } else {
                        $sql = "INSERT INTO $Web->ecommerce_qc_tbl (`qvariation_id`, `user_id`, `listing_id`, `variation_id`, `svariation_id`, `status`, `date_requested`) VALUES (?,?,?,?,?,'pending',? ) ";
                        $stmt = $db->prepare($sql);
                        $stmt->execute([$qvariation_id, $LogSeller->user_id, $listing_id, $variation_id, $svariation_id, $Web->current_time()]);
                    }
                }
            }
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in sending product to qc" . $e->getMessage() . $e->getTraceAsString() . $e->getFile());
        }

        $output = new stdClass;
        $output->error = "false";
        $output->message = "Listing has been sent to qc";
        echo json_encode($output);
        break;


    default:
        Errors::response_404();
        break;
}
