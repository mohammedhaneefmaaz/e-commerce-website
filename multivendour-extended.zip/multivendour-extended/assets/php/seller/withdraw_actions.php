<?php

use Ecommerce\WithdrawGateway;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists('Errors::response_404')) {
        include("../../../db.php");
    }
    Errors::response_404();
}

if (!isset($_POST["case"]))  Errors::response_404();
$case = $_POST["case"];
if ($Web->is_empty($case)) Errors::response_404();

if (!$Login->is_seller_loggedin()) Errors::force_login("seller");
switch ($case) {

    case "delete_withdraw_gateway":

        if (!$Web->is_isset("gateway_id")) Errors::response_404();
        $gateway_id = $Web->sanitize_text($_POST["gateway_id"]);
        if (!WithdrawGateway::is_gateway_id($gateway_id)) Errors::response("Withdraw gateway doesn't exist");;
        $WithdrawGateway = new WithdrawGateway($gateway_id);

        if (!$WithdrawGateway->has_seller_withdraw_gateway($LogSeller->user_id)) Errors::response("Invalid request");

        try {
            $stmt = $db->prepare("DELETE FROM $Web->ecommerce_sellers_withdraw_gateways_tbl WHERE gateway_id = ? AND user_id = ? ");
            $stmt->execute([$gateway_id, $LogSeller->user_id]);
        } catch (\Exception $e) {
            Errors::response_500("Error in removing withdraw gateway" . $e->getMessage());
        }

        $url = $Web->seller_url() . '/withdraw/add-details?id=' . $gateway_id;
        $btn = '<div class="d-flex flex-column gap-3" ><div class="fs-8 text-danger" > Withdraw details have not been added.</div> <a href="' . $url . '" class="btn btn-danger">Add</a></div>';

        $output = new stdClass;
        $output->message = "{$WithdrawGateway->name()} has been removed";
        $output->btns = $btn;
        echo json_encode($output);

        break;

    case "add_withdraw_details":
        if (!$Web->is_isset("labels", "gateway_id")) Errors::response_404();
        $labels = $Web->sanitize_text($_POST["labels"]);
        $gateway_id = $Web->sanitize_text($_POST["gateway_id"]);

        if (!WithdrawGateway::is_gateway_id($gateway_id)) Errors::response("Withdraw gateway doesn't exist");;
        $WithdrawGateway = new WithdrawGateway($gateway_id);
        if ($WithdrawGateway->status() !== "active") Errors::response("Withdraw gateway is currently not active");

        $db_labels = $WithdrawGateway->labels();
        if (array_keys($labels) !=  array_column($db_labels, "id")) Errors::response("Invalid details requested");
        $labels = json_encode($labels);

        $output = new stdClass;

        try {
            if ($WithdrawGateway->has_seller_withdraw_gateway($LogSeller->user_id)) {
                $stmt = $db->prepare("UPDATE $Web->ecommerce_sellers_withdraw_gateways_tbl SET labels = ? WHERE gateway_id = ? AND user_id = ? ");
                $stmt->execute([$labels, $gateway_id, $LogSeller->user_id]);
                $output->message = "Withdraw details has been updated";
            } else {
                $stmt = $db->prepare("INSERT INTO $Web->ecommerce_sellers_withdraw_gateways_tbl ( `user_id`, `gateway_id`, `labels`, `date_created`) VALUES (?,?,?,?) ");
                $stmt->execute([$LogSeller->user_id, $gateway_id, $labels, $Web->current_time()]);

                $output->message = "Withdraw details has been added";
            }
        } catch (\Exception $e) {
            Errors::response_500("Error in updating withdraw details" . $e->getMessage());
        }


        $output->url = $Web->seller_url() . '/withdraw/methods';
        echo json_encode($output);


        break;


    case "withdraw":
        if (!$Web->is_isset("gateway_id", "amount")) Errors::response_404();
        $gateway_id = $Web->sanitize_text($_POST["gateway_id"]);
        $amount = $Web->sanitize_text($_POST["amount"]);

        if (!WithdrawGateway::is_gateway_id($gateway_id)) Errors::response("Withdraw gateway doesn't exist");;
        $WithdrawGateway = new WithdrawGateway($gateway_id);
        if ($WithdrawGateway->status() !== "active") Errors::response("Withdraw gateway is currently not active");
        if (!$WithdrawGateway->has_seller_withdraw_gateway($LogSeller->user_id)) Errors::response("Please add withdraw details first");
        $Web->validate_post_input($amount, "number", "Amount", true);

        $db_labels = $WithdrawGateway->labels();
        $labels = $WithdrawGateway->user_added_labels($LogSeller->user_id);

        if (array_keys($labels) !=  array_column($db_labels, "id")) Errors::response("Invalid details requested");
        $db_labels = json_encode($db_labels);
        $gateway = array(
            "card_heading" => $WithdrawGateway->card_heading(),
            "logo" => $WithdrawGateway->logo(),
            "name" => $WithdrawGateway->name()
        );
        $gateway = json_encode($gateway);
        $labels = json_encode($labels);
        $charge = $WithdrawGateway->charge();
        $charge_type = $WithdrawGateway->charge_type();

        if ($charge_type == "fixed") $withdrawCharge = $charge;
        else {
            $withdrawCharge = ($amount * $charge) / 100;
        }

        $finalAmount = $amount - $withdrawCharge;

        if ($amount > $LogSeller->wallet()) Errors::response("Insufficient amount to withdraw");
        if (empty($amount)) Errors::response("Amount is invalid");
        if (!($finalAmount > 0)) Errors::response("Amount is invalid");


        try {
            $db->beginTransaction();

            $stmt = $db->prepare("INSERT INTO `$Web->transactions_tbl` (`user_id`,`amount`,`txn_charge`,`net_amount`, `details`,`status`,`date`,`last_updated`,`type`) VALUES (?,?,?,?,'withdraw','pending',?,?,'withdraw') ");
            $stmt->execute([$LogSeller->user_id, $amount, $withdrawCharge, $finalAmount, $Web->current_time(), $Web->current_time()]);

            $transaction_id = $db->lastInsertId();
            $stmt = $db->prepare("INSERT INTO $Web->ecommerce_sellers_withdraw_tbl (`transaction_id`,`user_id`,`gateway`, `gross_amount`, `charge`, `net_amount`, `date_requested`, `db_labels`, `user_labels`, `status`) VALUES (:transaction_id,:user_id,:gateway,:amount,:withdrawCharge,:finalAmount,:current_time,:db_labels,:labels,'pending' ) ");
            $stmt->execute([
                ":transaction_id" => $transaction_id,
                ":user_id" => $LogSeller->user_id,
                ":gateway" => $gateway,
                ":amount" => $amount,
                ":withdrawCharge" => $withdrawCharge,
                ":finalAmount" => $finalAmount,
                ":current_time" => $Web->current_time(),
                ":db_labels" => $db_labels,
                ":labels" => $labels
            ]);


            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in updating withdraw details" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Withdraw request has been sent";
        $output->url = $Web->seller_url() . '/withdraw/history';
        echo json_encode($output);
        break;
}
