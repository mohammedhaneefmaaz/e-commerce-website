<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists(Errors::response_404())) {
        require_once("../../db.php");
    }
    Errors::response_404();
}

if (!$Web->is_isset("case")) Errors::response_404();

$case = $Web->sanitize_text($_POST["case"]);
if ($Web->is_empty($case)) Errors::response_404();
if (!$Login->is_seller_loggedin()) Errors::force_login("seller");

use Ecommerce\_Order;
use Ecommerce\Listing;
use Ecommerce\Product;



$sql_details = array(
    'user' => $conn->userName,
    'pass' => $conn->password,
    'db'   => $conn->dbName,
    'host' => $conn->host
);
require_once $Web->include("php/library/datatable.class.php");

use Ecommerce\Withdraw;
use Ecommerce\returnOrder;
use Ecommerce\Basic;
use Ecommerce\Category;
use Ecommerce\Order;
use Ecommerce\QC;
use Ecommerce\ReplacementOrder;
use Ecommerce\Ticket;

switch ($case) {

    case "userSupportTickets":

        $columns = array(
            array('db' => 'subject', 'dt' => "subject",
            'formatter' => function ($d, $row) {
                global $Web;
                return $Web->unsanitize_text($d);
            }),
            array(
                'db' => 'status',
                'dt' => "status",
                'formatter' => function ($d, $row) {
                    $Ticket = new Ticket($row["ticket_id"]);
                    return $Ticket->status_label();
                }
            ),
            array(
                'db' => 'created_at',
                'dt' => "created_at",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ),
            array(
                'db' => 'ticket_id',
                'dt' => "view",
                'formatter' => function ($status, $row) {
                    $Ticket = new Ticket($row["ticket_id"]);
                    return '<a href="'.$Ticket->seller_view_url().'" data-action="delete" class="ms-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                    <span class="svg-icon svg-icon-2">
                                 <svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="none" d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path></svg>
                         </span>
                 </a>';
                }
            )
        );

        $sql = "SELECT * FROM $Web->support_tickets_tbl WHERE creator = '$LogSeller->user_id' ";
        $sql2 = "SELECT COUNT(*) FROM $Web->support_tickets_tbl WHERE creator = '$LogSeller->user_id' ";

        
        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;

    case "transactions_TBl":
        $columns = array(
            array(
                'db' => 'transaction_id', 'dt' => "transaction_id",
                'formatter' => function ($d, $row) {
                    $order_id = $row["order_id"];
                    if (!empty($order_id && Order::is_order_id($order_id))) {
                        $Order = new _Order($order_id);
                        $url = $Order->url();
                    } else {
                        $Transaction = new Transaction($d);
                        $withdraw_id = $Transaction->withdraw_id();
                        if (!Withdraw::is_withdraw_id($withdraw_id)) $url = "#";
                        else {
                            $Withdraw = new Withdraw($withdraw_id);
                            $url = $Withdraw->url();
                        }
                    }
                    return '<a href="' . $url . '" > #' . $d . '</a>';;
                }
            ),
            array('db' => 'amount', 'dt' => 'amount', 'formatter' => function ($d, $row) {
                global $Web;
                $Transaction = new Transaction($row["transaction_id"]);
                $text = $Web->formatCurrency($d);
                $status = $row["status"];

                if ($Transaction->type() == "order") {
                    if ($status == "credit") $text = '<span class="text-success">+' . $text . '</span>';
                    else if ($status == "pending") $text = '<span class="text-warning">+' . $text . '</span>';
                    else if ($status == "failed") $text = '<span class="text-info">+' . $text . '</span>';
                    else if ($status == "clearing") $text = '<span class="text-dark">+' . $text . '</span>';
                    else $text = '<span class="text-danger">-' . $text . '</span>';
                } else {
                    if ($status == "debit") $text = '<span class="text-danger">-' . $text . '</span>';
                    else if ($status == "pending") $text = '<span class="text-warning">-' . $text . '</span>';
                    else $text = '<span class="text-info">-' . $text . '</span>';
                }
                return $text;
            }),
            array('db' => 'txn_charge', 'dt' => 'txn_charge',  'formatter' => function ($d, $row) {
                global $Web;
                $text = $row["details"] == "order returned" || $row["details"] == "replacement rejected" || $row["details"] == "replacement refunded"  ? "+". $Web->formatCurrency($d) : "-" . $Web->formatCurrency($d);
                $status = $row["status"];
                if ($status == "credit") $text = '<span class="text-success">' . $text . '</span>';
                else if ($status == "pending") $text = '<span class="text-warning">' . $text . '</span>';
                else if ($status == "failed") $text = '<span class="text-info">' . $text . '</span>';
                else if ($status == "clearing") $text = '<span class="text-dark">' . $text . '</span>';
                else $text = '<span class="text-danger">' . $text . '</span>';
                return $text;
            }),
            array('db' => 'net_amount', 'dt' => 'net_amount', 'formatter' => function ($d, $row) {
                global $Web;
                $text = $Web->formatCurrency($d);
                $Transaction = new Transaction($row["transaction_id"]);
                $status = $row["status"];
                if ($Transaction->type() == "order") {
                    if ($status == "credit") $text = '<span class="text-success">+' . $text . '</span>';
                    else if ($status == "pending") $text = '<span class="text-warning">+' . $text . '</span>';
                    else if ($status == "failed") $text = '<span class="text-info">+' . $text . '</span>';
                    else if ($status == "clearing") $text = '<span class="text-dark">+' . $text . '</span>';
                    else $text = '<span class="text-danger">-' . $text . '</span>';
                } else {
                    if ($status == "debit") $text = '<span class="text-danger">-' . $text . '</span>';
                    else if ($status == "pending") $text = '<span class="text-warning">-' . $text . '</span>';
                    else $text = '<span class="text-info">-' . $text . '</span>';
                }
                return $text;
            }),
            array('db' => 'details', 'dt' => 'details', 'formatter' => function ($d, $row) {
                $order_id = $row["order_id"];
                $output = $d;
                if (!empty($order_id && Order::is_order_id($order_id))) {
                    $Order = new _Order($order_id);
                    $output = $d . '<a href="' . $Order->url() . '" > #' . $order_id . '</a>';
                }
                return $output;
            }),
            array('db' => 'status', 'dt' => 'status', 'formatter' => function ($d, $row) {
                global $Web;
                $order_id  = $row["order_id"];
                if(Order::is_order_id($order_id)) $Order  = new _Order($order_id);
                if ($d == "credit") return  $Web->status_to_label("credit", "success");
                if ($d == "debit")  return $Web->status_to_label("debit", "danger");
                if ($d == "pending") return  $Web->status_to_label("pending", "warning");
                if ($d == "failed")  return $Web->status_to_label("failed", "info");
                if ($d == "clearing")  return '<div data-bs-toggle="tooltip" title="" data-bs-trigger="hover" data-bs-dismiss="click" data-bs-original-title="' . $Order->remaining_clearing_time() . '" >' . $Web->status_to_label("clearing", "dark") . '</div>';
            }),
            array('db' => 'date', 'dt' => 'date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'last_updated', 'dt' => 'last_updated', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            })
        );

        $sql = "SELECT * FROM $Web->transactions_tbl  WHERE user_id = '$LogSeller->user_id' ";
        $sql2 = "SELECT COUNT(*) FROM $Web->transactions_tbl  WHERE user_id = '$LogSeller->user_id' ";

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;

    case 'replacement_orders_datatbl':

        if (!$Web->is_isset("status")) Errors::response_404();
        $status = $_POST["status"];


        $columns = array(
            array(
                'db' => 'replacement_id', 'dt' => "replacement_id",
                'formatter' => function ($d, $row) {
                    $ReplacementOrder = new ReplacementOrder($d);
                    return '<a href="' . $ReplacementOrder->viewUrl() . '" >#' . $d . '</a>';
                }
            ),
            array(
                'db' => 'tbl_order_id', 'dt' => "order_id",
                'formatter' => function ($d, $row) {
                    $Order = new _Order($d);
                    return '<a href="' . $Order->url() . '" >#' . $d . '</a>';
                }
            ),
            array(
                'db' => 'tbl_order_id', 'dt' => 'details',
                'formatter' => function ($d, $row) {
                    $variation_id = $row["variation_id"];
                    $svariation_id = $row["svariation_id"];
                    $product_id = $row["product_id"];
                    $Product = new Product($product_id);
                    return '<div class="d-flex align-items-center">
                        <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '" class="tbl-product-img">
                            <img src="' . $Product->image($variation_id, $svariation_id) . '">
                          </a>
                         <div class="ms-5">
                             <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '" class="text-gray-800 text-hover-primary wrap-text-1 fs-5 fw-bolder">' . $Product->product_name($variation_id, $svariation_id) . '</a>
                             <span><b>SKU ID: </b>' . $Product->sku_id($variation_id, $svariation_id) . '</span>
                        </div>
                    </div>';
                }
            ),
            array('db' => 'buyer_id', 'dt' => 'buyer', 'formatter' => function ($d, $row) {
                $User = new User($d);
                return $User->full_name();
            }),
            array('db' => 'quantity', 'dt' => 'quantity'),
            array('db' => 'total_price', 'dt' => 'amount', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->formatCurrency($d);
            }),
            array('db' => 'delivered_on', 'dt' => 'delivered_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'requested_date', 'dt' => 'requested_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'accepted_on', 'dt' => 'accepted_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'tbl_rejected_on', 'dt' => 'rejected_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'completed_date', 'dt' => 'completed_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'pickup_scheduled_date', 'dt' => 'pickup_scheduled_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array(
                'db' => 'replacement_id',
                'dt' => "actions",
                'formatter' => function ($d, $row) {
                    $Replacement = new ReplacementOrder($d);
                    return '<div class="d-flex">
                        <a href="' . $Replacement->viewUrl() . '" class="ms-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                           <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
                        </a>
                    </div>';
                }
            )
        );

        $sql = "SELECT *, $Web->ecommerce_orders_tbl.buyer_id ,$Web->ecommerce_orders_tbl.quantity ,$Web->ecommerce_orders_tbl.total_price, 
          $Web->ecommerce_replacement_orders_tbl.rejected_on as tbl_rejected_on, $Web->ecommerce_replacement_orders_tbl.order_id as tbl_order_id FROM 
          $Web->ecommerce_replacement_orders_tbl INNER JOIN $Web->ecommerce_orders_tbl ON $Web->ecommerce_orders_tbl.order_id = $Web->ecommerce_replacement_orders_tbl.order_id
          INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id = $Web->ecommerce_products_tbl.product_id 
          WHERE $Web->ecommerce_products_tbl.user_id = '$LogSeller->user_id' AND $Web->ecommerce_replacement_orders_tbl.status = '$status' ";

        $sql2 = "SELECT COUNT(*) FROM $Web->ecommerce_replacement_orders_tbl 
        INNER JOIN $Web->ecommerce_orders_tbl ON $Web->ecommerce_orders_tbl.order_id = $Web->ecommerce_replacement_orders_tbl.order_id
        INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id = $Web->ecommerce_products_tbl.product_id
         WHERE $Web->ecommerce_products_tbl.user_id = '$LogSeller->user_id' AND $Web->ecommerce_replacement_orders_tbl.status = '$status' ";

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;

    case 'return_orders_datatbl':

        if (!$Web->is_isset("status")) Errors::response_404();
        $status = $_POST["status"];


        $columns = array(
            array(
                'db' => 'return_id', 'dt' => "return_id",
                'formatter' => function ($d, $row) {
                    $returnOrder = new returnOrder($d);
                    return '<a href="' . $returnOrder->viewUrl() . '" >#' . $d . '</a>';
                }
            ),
            array(
                'db' => 'tbl_order_id', 'dt' => "order_id",
                'formatter' => function ($d, $row) {
                    $Order = new _Order($d);
                    return '<a href="' . $Order->url() . '" >#' . $d . '</a>';
                }
            ),
            array(
                'db' => 'tbl_order_id', 'dt' => 'details',
                'formatter' => function ($d, $row) {
                    $variation_id = $row["variation_id"];
                    $svariation_id = $row["svariation_id"];
                    $product_id = $row["product_id"];
                    $Product = new Product($product_id);
                    return '<div class="d-flex align-items-center">
                        <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '" class="tbl-product-img">
                            <img src="' . $Product->image($variation_id, $svariation_id) . '">
                          </a>
                         <div class="ms-5">
                             <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '" class="text-gray-800 text-hover-primary wrap-text-1 fs-5 fw-bolder">' . $Product->product_name($variation_id, $svariation_id) . '</a>
                             <span><b>SKU ID: </b>' . $Product->sku_id($variation_id, $svariation_id) . '</span>
                        </div>
                    </div>';
                }
            ),
            array('db' => 'buyer_id', 'dt' => 'buyer', 'formatter' => function ($d, $row) {
                $User = new User($d);
                return $User->full_name();
            }),
            array('db' => 'quantity', 'dt' => 'quantity'),
            array('db' => 'total_price', 'dt' => 'amount', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->formatCurrency($d);
            }),
            array('db' => 'delivered_on', 'dt' => 'delivered_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'requested_date', 'dt' => 'requested_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'accepted_on', 'dt' => 'accepted_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'tbl_rejected_on', 'dt' => 'rejected_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'completed_date', 'dt' => 'completed_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'pickup_scheduled_date', 'dt' => 'pickup_scheduled_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array(
                'db' => 'return_id',
                'dt' => "actions",
                'formatter' => function ($d, $row) {
                    $Return = new returnOrder($d);
                    return '<div class="d-flex">
                        <a href="' . $Return->viewUrl() . '" class="ms-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                           <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
                        </a>
                    </div>';
                }
            )
        );

        $sql = "SELECT *, $Web->ecommerce_orders_tbl.buyer_id ,$Web->ecommerce_orders_tbl.quantity ,$Web->ecommerce_orders_tbl.total_price,
           $Web->ecommerce_return_orders_tbl.rejected_on as tbl_rejected_on,
          $Web->ecommerce_return_orders_tbl.order_id as tbl_order_id FROM 
          $Web->ecommerce_return_orders_tbl INNER JOIN $Web->ecommerce_orders_tbl ON $Web->ecommerce_orders_tbl.order_id = $Web->ecommerce_return_orders_tbl.order_id
          INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id = $Web->ecommerce_products_tbl.product_id 
          WHERE $Web->ecommerce_products_tbl.user_id = '$LogSeller->user_id' AND  $Web->ecommerce_return_orders_tbl.status = '$status' ";

        $sql2 = "SELECT COUNT(*) FROM $Web->ecommerce_return_orders_tbl 
        INNER JOIN $Web->ecommerce_orders_tbl ON $Web->ecommerce_orders_tbl.order_id = $Web->ecommerce_return_orders_tbl.order_id
        INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id = $Web->ecommerce_products_tbl.product_id
         WHERE $Web->ecommerce_products_tbl.user_id = '$LogSeller->user_id' AND $Web->ecommerce_return_orders_tbl.status = '$status' ";

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;

    case "questions_tbl_data":


        $columns = array(
            array(
                'db' => 'product_id', 'dt' => "product",
                'formatter' => function ($d, $row) {
                    $Product = new Product($d);
                    return '<div class="d-flex align-items-center">
                        <a target="_blank" href="' . $Product->url($Product->st_variation(), $Product->st_svariation($Product->st_variation())) . '" class="tbl-product-img">
                            <img src="' . $Product->image($Product->st_variation(), $Product->st_svariation($Product->st_variation())) . '">
                          </a>
                         <div class="ms-5">
                             <a target="_blank" href="' . $Product->url($Product->st_variation(), $Product->st_svariation($Product->st_variation())) . '" class="text-gray-800 text-hover-primary wrap-text-1 fs-5 fw-bolder">' . $Product->product_name($Product->st_variation(), $Product->st_svariation($Product->st_variation())) . '</a>
                        </div>
                    </div>';
                }
            ),
            array(
                'db' => 'product_id',
                'dt' => "category",
                'formatter' => function ($d, $row) {
                    $Product = new Product($row["product_id"]);
                    $category_id = $Product->category_id();
                    $Category = new Category($category_id);
                    return $Category->category();
                }
            ),
            array(
                'db' => 'unanswered',
                'dt' => "unanswered"
            ), array(
                'db' => 'answered_seller',
                'dt' => "answered_seller"
            ),
            array(
                'db' => 'answered_users',
                'dt' => "answered_users"
            ),
            array(
                'db' => 'questions',
                'dt' => "questions"
            ),
            array(
                'db' => 'product_id',
                'dt' => "action",
                'formatter' => function ($d, $row) {
                    $Product = new Product($d);

                    return '
                    <a href="' . $Product->questions_page_url($Product->st_variation(), $Product->st_svariation($Product->st_variation())) . '"  class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
						        <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
							</a>';
                }
            ),
        );

        $sql = "SELECT *,
        (SELECT COUNT(question_id) FROM  $Web->ecommerce_product_questions_tbl WHERE $Web->ecommerce_product_questions_tbl.product_id = $Web->ecommerce_products_tbl.product_id) as questions,
         IFNULL((SELECT COUNT(answer_id) FROM  $Web->ecommerce_product_answers_tbl WHERE $Web->ecommerce_product_answers_tbl.product_id = $Web->ecommerce_products_tbl.product_id ),0) as answers,
        IFNULL((SELECT COUNT(answer_id) FROM  $Web->ecommerce_product_answers_tbl WHERE $Web->ecommerce_product_answers_tbl.product_id = $Web->ecommerce_products_tbl.product_id AND $Web->ecommerce_product_answers_tbl.answered_by = '$LogSeller->user_id'  ),0) as answered_seller,
        IFNULL((SELECT COUNT(answer_id) FROM  $Web->ecommerce_product_answers_tbl WHERE $Web->ecommerce_product_answers_tbl.product_id = $Web->ecommerce_products_tbl.product_id AND $Web->ecommerce_product_answers_tbl.answered_by != '$LogSeller->user_id'  ),0) as answered_users,
        (SELECT questions - answers) as unanswered FROM $Web->ecommerce_products_tbl WHERE user_id = '$LogSeller->user_id' ";
        
        $sql2 = "SELECT COUNT(DISTINCT(product_id)) FROM $Web->ecommerce_products_tbl WHERE user_id = '$LogSeller->user_id'  ";

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );


        break;

    case "withdraw_history_tbl":

        $columns = array(
            array(
                'db' => 'withdraw_id', 'dt' => "gateway",
                'formatter' => function ($withdraw_id, $row) {
                    $Withdraw = new Withdraw($withdraw_id);
                    return '<div class="d-flex align-items-center">
                    <div class="symbol symbol-circle symbol-50px overflow-hidden me-3">
														<a>
															<div class="symbol-label">
																<img src="' . $Withdraw->gateway()->logo . '" alt="' . $Withdraw->gateway()->name . '" class="w-100">
															</div>
														</a>
													</div>
													<div class="d-flex flex-column">
														<a class="text-gray-800 text-hover-primary mb-1">' . $Withdraw->gateway()->name . '</a>
													</div>
                                            </div>';
                }
            ),
            array(
                'db' => 'transaction_id', 'dt' => "transaction_id",
                'formatter' => function ($d, $row) {
                    return "#" . $d;
                }
            ),
            array(
                'db' => 'gross_amount', 'dt' => "gross_amount",
                'formatter' => function ($gross_amount, $row) {
                    return (new Basic)->formatCurrency($gross_amount);
                }
            ),
            array(
                'db' => 'charge', 'dt' => "charge",
                'formatter' => function ($charge, $row) {
                    return (new Basic)->formatCurrency($charge);
                }
            ),
            array(
                'db' => 'net_amount', 'dt' => "net_amount",
                'formatter' => function ($net_amount, $row) {
                    return (new Basic)->formatCurrency($net_amount);
                }
            ),
            array('db' => 'date_requested', 'dt' => 'requested_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'date_processed', 'dt' => 'processed_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d) ?? "NA";
            }),
            array('db' => 'status', 'dt' => 'status', 'formatter' => function ($status, $row) {
                global $Web;
                switch ($status) {
                    case "pending":
                        return $Web->status_to_label("Pending", "warning");
                        break;
                    case "success":
                        return $Web->status_to_label("Success", "success");
                        break;
                    case "rejected":
                        return $Web->status_to_label("Rejected", "danger");
                        break;
                }
            }),
            array(
                'db' => 'withdraw_id',
                'dt' => "action",
                'formatter' => function ($d, $row) {
                    $Withdraw = new Withdraw($d);
                    return '<div class="d-flex">
                        <a href="' . $Withdraw->url() . '" class="ms-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                           <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
                        </a>
                    </div>';
                }
            )
        );

        $sql = "SELECT * FROM $Web->ecommerce_sellers_withdraw_tbl WHERE user_id = '$LogSeller->user_id' ";
        $sql2 = "SELECT COUNT(*) FROM $Web->ecommerce_sellers_withdraw_tbl WHERE user_id = '$LogSeller->user_id'  ";


        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;

    case "topSellingProductsAnalytics":
        if (!$Web->is_isset("from_date", "to_date")) Errors::response("Invalid Request");
        $from_date = $Web->sanitize_text($_POST["from_date"]);
        $to_date = $Web->sanitize_text($_POST["to_date"]);


        $columns = array(
            array(
                'db' => 'variation_id',  'dt' => "product",
                'formatter' => function ($d, $row) {
                    $svariation_id = $row["svariation_id"];
                    $product_id = $row["product_id"];
                    $Product = new Product($product_id);
                    return '<div class="d-flex align-items-center">
                                    <a target="_blank" href="' . $Product->url($d, $svariation_id) . '" class="tbl-product-img">
                                          <img src="' . $Product->image($d, $svariation_id) . '">
                                    </a>
                                     <div class="ms-5">
                                         <a  target="_blank" href="' . $Product->url($d, $svariation_id) . '" class="text-gray-800 text-hover-primary wrap-text-1 fs-5 fw-bolder" >' . $Product->product_name($d, $svariation_id) . '</a>
                                         <a href="' . $Product->listing_url($d, $svariation_id) . '" class="fw-bolder">SKU Id: ' . $Product->sku_id($d, $svariation_id) . '</a>
                                   </div>
                              </div>';
                }
            ),
            array(
                'db' => 'views',
                'dt' => "views"
            ),
            array(
                'db' => 'orders',
                'dt' => "orders"
            ),
            array(
                'db' => 'accepted_orders',
                'dt' => "accepted_orders"
            ),
            array(
                'db' => 'delivered',
                'dt' => "delivered"
            ),
            array(
                'db' => 'cancelled',
                'dt' => "cancelled"
            ),
            array(
                'db' => 'rejected',
                'dt' => "rejected"
            ),
            array(
                'db' => 'replacement',
                'dt' => "replacement"
            ),
            array(
                'db' => 'returned',
                'dt' => "returned"
            ),
            array(
                'db' => 'earning',
                'dt' => "earning",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->formatCurrency($d);
                }
            ),
            array(
                'db' => 'date_created',
                'dt' => "publish_date",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ),
        );


        $from = strtotime($from_date);
        $to = strtotime($to_date);

        $to = $to + (24 * 3600) - 1;

        $sql = "SELECT svariation_id,variation_id,product_id,date_created, 
        (SELECT COALESCE(SUM(total_price), 0) FROM $Web->ecommerce_orders_tbl WHERE $Web->ecommerce_orders_tbl.variation_id = $Web->ecommerce_variations_tbl.variation_id  AND $Web->ecommerce_orders_tbl.svariation_id = $Web->ecommerce_variations_tbl.svariation_id AND $Web->ecommerce_orders_tbl.ordered_date BETWEEN '$from' AND '$to' AND ($Web->ecommerce_orders_tbl.status = 'DELIVERED' OR  $Web->ecommerce_orders_tbl.status = 'REPLACEMENT') ) AS earning,
        (SELECT COALESCE(COUNT(order_id), 0) FROM $Web->ecommerce_orders_tbl WHERE $Web->ecommerce_orders_tbl.variation_id = $Web->ecommerce_variations_tbl.variation_id AND $Web->ecommerce_orders_tbl.svariation_id = $Web->ecommerce_variations_tbl.svariation_id   AND $Web->ecommerce_orders_tbl.ordered_date BETWEEN '$from' AND '$to' AND $Web->ecommerce_orders_tbl.status = 'DELIVERED' ) AS delivered,
        (SELECT COALESCE(COUNT(order_id), 0) FROM $Web->ecommerce_orders_tbl WHERE $Web->ecommerce_orders_tbl.variation_id = $Web->ecommerce_variations_tbl.variation_id AND $Web->ecommerce_orders_tbl.svariation_id = $Web->ecommerce_variations_tbl.svariation_id   AND $Web->ecommerce_orders_tbl.ordered_date BETWEEN '$from' AND '$to' AND $Web->ecommerce_orders_tbl.status = 'CANCELLED' ) AS cancelled,
        (SELECT COALESCE(COUNT(order_id), 0) FROM $Web->ecommerce_orders_tbl WHERE $Web->ecommerce_orders_tbl.variation_id = $Web->ecommerce_variations_tbl.variation_id AND $Web->ecommerce_orders_tbl.svariation_id = $Web->ecommerce_variations_tbl.svariation_id   AND $Web->ecommerce_orders_tbl.ordered_date BETWEEN '$from' AND '$to' AND $Web->ecommerce_orders_tbl.status = 'RETURNED' ) AS returned,
        (SELECT COALESCE(COUNT(order_id), 0) FROM $Web->ecommerce_orders_tbl WHERE $Web->ecommerce_orders_tbl.variation_id = $Web->ecommerce_variations_tbl.variation_id AND $Web->ecommerce_orders_tbl.svariation_id = $Web->ecommerce_variations_tbl.svariation_id   AND $Web->ecommerce_orders_tbl.ordered_date BETWEEN '$from' AND '$to' AND $Web->ecommerce_orders_tbl.status = 'REPLACEMENT' ) AS replacement,
        (SELECT COALESCE(COUNT(order_id), 0) FROM $Web->ecommerce_orders_tbl WHERE $Web->ecommerce_orders_tbl.variation_id = $Web->ecommerce_variations_tbl.variation_id AND $Web->ecommerce_orders_tbl.svariation_id = $Web->ecommerce_variations_tbl.svariation_id   AND $Web->ecommerce_orders_tbl.ordered_date BETWEEN '$from' AND '$to' AND $Web->ecommerce_orders_tbl.status = 'REJECTED' ) AS rejected,
        (SELECT COALESCE(COUNT(order_id), 0)  FROM $Web->ecommerce_orders_tbl WHERE $Web->ecommerce_orders_tbl.variation_id = $Web->ecommerce_variations_tbl.variation_id  AND $Web->ecommerce_orders_tbl.svariation_id = $Web->ecommerce_variations_tbl.svariation_id AND $Web->ecommerce_orders_tbl.ordered_date BETWEEN '$from' AND '$to' AND $Web->ecommerce_orders_tbl.labelled_on IS NOT NULL  ) AS accepted_orders,
        (SELECT COALESCE(COUNT(order_id), 0)  FROM $Web->ecommerce_orders_tbl WHERE $Web->ecommerce_orders_tbl.variation_id = $Web->ecommerce_variations_tbl.variation_id  AND $Web->ecommerce_orders_tbl.svariation_id = $Web->ecommerce_variations_tbl.svariation_id AND $Web->ecommerce_orders_tbl.ordered_date BETWEEN '$from' AND '$to'   ) AS orders,
        (SELECT COALESCE(SUM(views), 0) FROM $Web->ecommerce_product_views_tbl WHERE $Web->ecommerce_product_views_tbl.variation_id = $Web->ecommerce_variations_tbl.variation_id AND  $Web->ecommerce_product_views_tbl.svariation_id = $Web->ecommerce_variations_tbl.svariation_id AND $Web->ecommerce_product_views_tbl.date BETWEEN '$from' AND '$to' ) AS views
        FROM $Web->ecommerce_variations_tbl WHERE user_id = '$LogSeller->user_id' ";

        $sql2 = "SELECT COUNT(variation_id) FROM $Web->ecommerce_variations_tbl WHERE user_id = '$LogSeller->user_id'  ";

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );
        break;

    case "top_viewed_products_Analytics":

        if (!$Web->is_isset("from_date", "to_date")) Errors::response("Invalid Request");
        $from_date = $Web->sanitize_text($_POST["from_date"]);
        $to_date = $Web->sanitize_text($_POST["to_date"]);

        $columns = array(
            array(
                'db' => 'variation_id',  'dt' => "product",
                'formatter' => function ($d, $row) {
                    $svariation_id = $row["svariation_id"];
                    $product_id = $row["product_id"];
                    $Product = new Product($product_id);
                    return '<div class="d-flex align-items-center">
                                    <a target="_blank" href="' . $Product->url($d, $svariation_id) . '" class="tbl-product-img">
                                          <img src="' . $Product->image($d, $svariation_id) . '">
                                    </a>
                                     <div class="ms-5">
                                         <a  target="_blank" href="' . $Product->url($d, $svariation_id) . '" class="text-gray-800 text-hover-primary wrap-text-1 fs-5 fw-bolder" >' . $Product->product_name($d, $svariation_id) . '</a>
                                         <a href="' . $Product->listing_url($d, $svariation_id) . '"  class="fw-bolder">SKU Id: ' . $Product->sku_id($d, $svariation_id) . '</a>
                                   </div>
                              </div>';
                }
            ),
            array(
                'db' => 'date_created',
                'dt' => "publish_date",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ),
            array(
                'db' => 'views',
                'dt' => "views"
            )
        );

        $from = strtotime($from_date);
        $to = strtotime($to_date);

        $to = $to + (24 * 3600) - 1;

        $sql = "SELECT variation_id,product_id,svariation_id,date_created, 
        (SELECT COALESCE(SUM(views), 0) FROM $Web->ecommerce_product_views_tbl WHERE $Web->ecommerce_product_views_tbl.variation_id = $Web->ecommerce_variations_tbl.variation_id AND $Web->ecommerce_product_views_tbl.svariation_id = $Web->ecommerce_variations_tbl.svariation_id AND $Web->ecommerce_product_views_tbl.date BETWEEN '$from' AND '$to') AS views
         FROM $Web->ecommerce_variations_tbl WHERE user_id = '$LogSeller->user_id' ";

        $sql2 = "SELECT COUNT(svariation_id) FROM $Web->ecommerce_variations_tbl WHERE user_id = '$LogSeller->user_id'  ";

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );
        break;
    case "new_orders_tbl":
        if (!$Web->is_isset("order_status")) Errors::response_404();
        $order_status = $_POST["order_status"];
        $columns = array(
            array(
                'db' => 'order_id', 'dt' => "check",
                'formatter' => function ($order_id, $row) {
                    return '<div class="form-check form-check-sm form-check-custom form-check-solid">
                                                        <input autocomplete="off" class="form-check-input" type="checkbox" value="' . $order_id . '" data-check-target="true">
                                                    </div>';
                }
            ),
            array(
                'db' => 'order_id', 'dt' => "order_id",
                'formatter' => function ($d, $row) {
                    $Order = new _Order($d);
                    return '<a href="' . $Order->url() . '" >#' . $d . '</a>';
                }
            ),
            array(
                'db' => 'order_id', 'dt' => 'details',
                'formatter' => function ($d, $row) {
                    $variation_id = $row["variation_id"];
                    $svariation_id = $row["svariation_id"];
                    $product_id = $row["product_id"];
                    $Product = new Product($product_id);
                    return '<div class="d-flex align-items-center">
                        <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '" class="tbl-product-img">
                            <img src="' . $Product->image($variation_id, $svariation_id) . '">
                          </a>
                         <div class="ms-5">
                             <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '" class="text-gray-800 text-hover-primary wrap-text-1 fs-5 fw-bolder">' . $Product->product_name($variation_id, $svariation_id) . '</a>
                             <span><b>SKU ID: </b>' . $Product->sku_id($variation_id, $svariation_id) . '</span>
                        </div>
                    </div>';
                }
            ),
            array('db' => 'buyer_id', 'dt' => 'buyer', 'formatter' => function ($d, $row) {
                $User = new User($d);
                return $User->full_name();
            }),
            array('db' => 'quantity', 'dt' => 'quantity'),
            array('db' => 'total_price', 'dt' => 'amount', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->formatCurrency($d);
            }),
            array('db' => 'ordered_date', 'dt' => 'order_date', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'labelled_on', 'dt' => 'labelled_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'rtd_on', 'dt' => 'rtd_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'pickup_scheduled_on', 'dt' => 'scheduled_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'shipped_on', 'dt' => 'shipped_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'delivered_on', 'dt' => 'delivered_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'cancelled_on', 'dt' => 'cancelled_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array('db' => 'rejected_on', 'dt' => 'rejected_on', 'formatter' => function ($d, $row) {
                global $Web;
                return $Web->date_time($d);
            }),
            array(
                'db' => 'order_id',
                'dt' => "actions",
                'formatter' => function ($d, $row) {
                    $Order = new _Order($d);
                    return '<div class="d-flex">
                        <a href="' . $Order->url() . '" class="ms-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                           <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
                        </a>
                    </div>';
                }
            )
        );

        $sql = "SELECT * FROM $Web->ecommerce_orders_tbl INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id = $Web->ecommerce_products_tbl.product_id WHERE $Web->ecommerce_products_tbl.user_id = '$LogSeller->user_id' AND $Web->ecommerce_orders_tbl.status = '$order_status' ";
        $sql2 = "SELECT COUNT(*) FROM $Web->ecommerce_orders_tbl INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id = $Web->ecommerce_products_tbl.product_id WHERE $Web->ecommerce_products_tbl.user_id = '$LogSeller->user_id' AND $Web->ecommerce_orders_tbl.status = '$order_status' ";

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;

    case "qc_tbl":

        $columns = array(
            array(
                'db' => 'qc_id', 'dt' => "product",
                'formatter' => function ($d, $row) {
                    $Q = new QC($d);
                    $Listing = $Q->listing();
                    return '<div class="d-flex align-items-center">
                        <a target="_blank" class="tbl-product-img">
                            <img src="' . $Listing->image($Q->variation_id(), $Listing->st_svariation($Q->variation_id())) . '">
                          </a>
                         <div class="ms-5">
                             <a target="_blank" class="text-gray-800 text-hover-primary wrap-text-1 fs-5 fw-bolder">' . $Listing->product_name($Q->variation_id(), $Listing->st_svariation($Q->variation_id())) . '</a>
                        </div>
                    </div>';
                }
            ),
            array(
                'db' => 'date_requested',
                'dt' => "req_date",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ),
            array(
                'db' => 'date_processed',
                'dt' => "res_date",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ), array(
                'db' => 'status',
                'dt' => "status",
                'formatter' => function ($d, $row) {
                    $q = new QC($row["qc_id"]);
                    return $q->status_label();
                }
            ),
            array(
                'db' => 'qc_id',
                'dt' => "actions",
                'formatter' => function ($d, $row) {
                    $Q = new QC($d);
                    $Listing = $Q->listing();
                    $variation_id = $Q->variation_id();
                    $svariation_id = $Q->svariation_id();
                    $vurl = $Listing->vurl($variation_id, $svariation_id);
                    $url = $vurl . '&qc=' . $d;

                    return '
                    <a href="' . $url . '"  class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
						        <span class="svg-icon svg-icon-2">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="currentColor"></rect>
												<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="currentColor"></path>
										</svg>
								</span>
							</a>';
                }
            ),
        );


        $sql = "SELECT * FROM $Web->ecommerce_qc_tbl WHERE user_id = '$LogSeller->user_id'  ";
        $sql2 = "SELECT COUNT(DISTINCT(qvariation_id)),user_id FROM $Web->ecommerce_qc_tbl  WHERE user_id = '$LogSeller->user_id'  ";

        if (!empty($_POST["columns"][4]["search"]["value"])) {
            $status = $_POST["columns"][4]["search"]["value"];
            $sql .= " AND status = '$status'";
            $sql2 .= " AND status = '$status'";
        }

        $sql .= ' GROUP BY qvariation_id';

        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;

    case "active_listings_tbl":

        $status = $_POST["status"];

        $columns = array(
            array(
                'db' => 'svariation_id', 'dt' => "check",
                'formatter' => function ($d, $row) {
                    $product_id = $row["product_id"];
                    $variation_id = $row["variation_id"];
                    return '<div class="form-check form-check-sm form-check-custom form-check-solid">
                                                        <input autocomplete="off" class="form-check-input" type="checkbox" data-id="' . $product_id . '" data-vid="' . $variation_id . '" value="' . $d . '" data-check-target="true">
                                                    </div>';
                }
            ),
            array(
                'db' => 'svariation_id', 'dt' => "product",
                'formatter' => function ($svariation_id, $row) {
                    $variation_id = $row["variation_id"];
                    $product_id = $row["product_id"];
                    $Product = new Product($product_id);
                    $vurl = $Product->listing_url($variation_id, $svariation_id);

                    return '<div class="d-flex align-items-center">
                        <a href="' . $vurl . '" target="_blank" class="tbl-product-img">
                            <img src="' . $Product->image($variation_id, $svariation_id) . '">
                          </a>
                         <div class="ms-5">
                             <a href="' . $vurl . '" target="_blank" class="text-gray-800 text-hover-primary wrap-text-1 fs-5 fw-bolder">' . $Product->product_name($variation_id, $svariation_id) . '</a>
                             <span><b>SKU ID: </b>' . $Product->sku_id($variation_id, $svariation_id) . '</span>
                        </div>
                    </div>';
                }
            ),
            array(
                'db' => 'svariation_id',
                'dt' => "status",
                'formatter' => function ($d, $row) {
                    $svariation_id = $d;
                    $variation_id = $row["variation_id"];
                    $product_id = $row["product_id"];
                    $Product = new Product($product_id);
                    return $Product->status_label($variation_id, $svariation_id);
                }
            ),
            array(
                'db' => 'stock', 'dt' => 'stock',
                'formatter' => function ($d, $row) {
                    $svariation_id = $row["svariation_id"];
                    $variation_id = $row["variation_id"];
                    $product_id = $row["product_id"];
                    global $status;
                    return !($status == "active" || $status == "inactive")  ? $d : $d . '<button data-lx-menu-trigger="click" data-lx-menu-placement="bottom-start" class="btn ms-2 btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                    <span class="svg-icon svg-icon-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                            <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                        </svg>
                                    </span>
                                </button>
                                <div data-lx-menu="true" class="menu mh-200px scroll-y menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg-light-primary fw-bold mw-350px">
                                    <div class="card">
                                        <div class="card-header-alt">
                                            <h4 class="card-title">Stock</h4>
                                        </div>
                                        <div class="card-body-alt">
                                            <form default-validation="true" novalidate class="needs-validation">
                                            <input type="hidden" name="column" value="stock" >
                                            <input type="hidden" name="svariation_id" value="' . $svariation_id . '" >
                                            <input type="hidden" name="variation_id" value="' . $variation_id . '" >
                                            <input type="hidden" name="product_id" value="' . $product_id . '" >
                                                <div class="col-12 fv-row mb-3">
                                                    <input  autocomplete="off" name="stock" value="' . $d . '" type="text" class="form-control" placeholder="" required="">
                                                    <div class="invalid-feedback" >Stock is required</div>
                                                </div>
                                                <div class="justify-right form-row">
                                                    <button type="button" data-action="closeLxMenu" class="btn btn-secondary" >Cancel</button>
                                                    <button type="submit" class="btn ms-3 btn-success">Update</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>';
                }
            ),
            array('db' => 'mrp', 'dt' => 'mrp', 'formatter' => function ($d, $row) {
                $Basic = new Basic();
                $svariation_id = $row["svariation_id"];
                $variation_id = $row["variation_id"];
                $product_id = $row["product_id"];
                global $status;
                return !($status == "active" || $status == "inactive") ? $Basic->formatCurrency($d) : $Basic->formatCurrency($d) . '<button data-lx-menu-trigger="click" data-lx-menu-placement="bottom-start" class="btn ms-2 btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                    <span class="svg-icon svg-icon-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                            <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                        </svg>
                                    </span>
                                </button>
                                <div data-lx-menu="true" class="menu mh-200px scroll-y menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg-light-primary fw-bold mw-350px">
                                    <div class="card">
                                         <div class="card-header-alt">
                                            <h4 class="card-title">MRP</h4>
                                        </div>
                                        <div class="card-body-alt">
                                            <form default-validation="true" novalidate class="needs-validation">
                                                <div class="fv-row col-12 mb-3">
                                                     <input type="hidden" name="column" value="mrp" >
                                                      <input type="hidden" name="svariation_id" value="' . $svariation_id . '" >
                                            <input type="hidden" name="variation_id" value="' . $variation_id . '" >
                                            <input type="hidden" name="product_id" value="' . $product_id . '" >
                                                    <input  autocomplete="off" name="mrp" value="' . $d . '" type="text" class="form-control" placeholder="" required="">
                                                    <div class="invalid-feedback" >Mrp is required</div>
                                                </div>
                                                <div class="justify-right form-row">
                                                    <button type="button" data-action="closeLxMenu" class="btn btn-secondary" >Cancel</button>
                                                    <button type="submit" class="btn ms-3 btn-success">Update</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>';
            }),
            array('db' => 'price', 'dt' => 'price', 'formatter' => function ($d, $row) {
                $Basic = new Basic();
                $svariation_id = $row["svariation_id"];
                $variation_id = $row["variation_id"];
                $product_id = $row["product_id"];
                global $status;
                return !($status == "active" || $status == "inactive") ? $Basic->formatCurrency($d) : $Basic->formatCurrency($d) . '<button data-lx-menu-trigger="click" data-lx-menu-placement="bottom-start" class="btn ms-2 btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                            <span class="svg-icon svg-icon-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                    <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                </svg>
                            </span>
                        </button>
                        <div data-lx-menu="true" class="menu mh-200px scroll-y menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg-light-primary fw-bold mw-350px">
                            <div class="card">
                                 <div class="card-header-alt">
                                    <h4 class="card-title">Price</h4>
                                </div>
                                <div class="card-body-alt">
                                    <form default-validation="true" novalidate class="needs-validation">
                                        <div class="col-12 mb-3">
                                           <input type="hidden" name="column" value="price" >
                                            <input type="hidden" name="svariation_id" value="' . $svariation_id . '" >
                                            <input type="hidden" name="variation_id" value="' . $variation_id . '" >
                                            <input type="hidden" name="product_id" value="' . $product_id . '" >
                                            <input  autocomplete="off" name="price" value="' . $d . '" type="text" class="form-control" placeholder="" required="">
                                            <div class="invalid-feedback" >Price is required</div>
                                        </div>
                                        <div class="justify-right form-row">
                                            <button type="button" data-action="closeLxMenu" class="btn btn-secondary" >Cancel</button>
                                            <button type="submit" class="btn ms-3 btn-success">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>';
            }),
            array('db' => 'svariation_id', 'dt' => 'category', 'formatter' => function ($d, $row) {
                $Product = new Product($row["product_id"]);
                $category_id = $Product->category_id();
                $Category = new Category($category_id);
                return $Category->category();
            }),
            array('db' => 'svariation_id', 'dt' => 'sell', 'formatter' => function ($d, $row) {
                $svariation_id = $d;
                $variation_id = $row["variation_id"];
                $product_id = $row["product_id"];
                $Product = new Product($product_id);
                return $Product->sells($variation_id, $svariation_id);
            }),
            array(
                'db' => 'date_created',
                'dt' => "date",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ),
            array(
                'db' => 'svariation_id',
                'dt' => "actions",
                'formatter' => function ($d, $row) {
                    $Product = new Product($row["product_id"]);
                    $variation_id = $row["variation_id"];
                    $svariation_id = $d;
                    $vurl = $Product->listing_url($variation_id, $svariation_id);
                    return '<div class="d-flex">
                        <a href="' . $vurl . '" data-action="edit" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                            <span class="svg-icon svg-icon-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                    <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                </svg>
                            </span>
                        </a>
                        <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '" data-action="delete" class="ms-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                           <span class="svg-icon svg-icon-2">
										<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="none" d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"/></svg>
								</span>
                        </a>
                    </div>';
                }
            )
        );

        $sql = "SELECT * FROM $Web->ecommerce_variations_tbl WHERE user_id = '$LogSeller->user_id' AND status = '$status' ";
        $sql2 = "SELECT COUNT(*) FROM $Web->ecommerce_variations_tbl WHERE user_id = '$LogSeller->user_id' AND status = '$status' ";
        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;


    case "draft_listings_tbl":

        $columns = array(
            array(
                'db' => 'svariation_id', 'dt' => "check",
                'formatter' => function ($d, $row) {
                    $listing_id = $row["listing_id"];
                    $variation_id = $row["variation_id"];
                    return '<div class="form-check form-check-sm form-check-custom form-check-solid">
                                                        <input autocomplete="off" class="form-check-input" type="checkbox" data-id="' . $listing_id . '" data-vid="' . $variation_id . '" value="' . $d . '" data-check-target="true">
                                                    </div>';
                }
            ),
            array(
                'db' => 'svariation_id', 'dt' => "product",
                'formatter' => function ($svariation_id, $row) {
                    $variation_id = $row["variation_id"];
                    $listing_id = $row["listing_id"];
                    $Listing = new Listing($listing_id);
                    return '<div class="d-flex align-items-center">
                        <a target="_blank" class="tbl-product-img">
                            <img src="' . $Listing->image($variation_id, $svariation_id) . '">
                          </a>
                         <div class="ms-5">
                             <a target="_blank" class="text-gray-800 text-hover-primary wrap-text-1 fs-5 fw-bolder">' . $Listing->product_name($variation_id, $svariation_id) . '</a>
                             <span><b>SKU ID: </b>' . $Listing->sku_id($variation_id, $svariation_id) . '</span>
                        </div>
                    </div>';
                }
            ),
            array(
                'db' => 'stock', 'dt' => 'stock',
                'formatter' => function ($d, $row) {
                    return  $d;
                }
            ),
            array('db' => 'mrp', 'dt' => 'mrp', 'formatter' => function ($d, $row) {
                global $Web;
                return  $Web->formatCurrency($d);
            }),
            array('db' => 'price', 'dt' => 'price', 'formatter' => function ($d, $row) {
               global $Web;
                return $Web->formatCurrency($d);
            }),
            array('db' => 'svariation_id', 'dt' => 'category', 'formatter' => function ($d, $row) {
                $Listing = new Listing($row["listing_id"]);
                $category_id = $Listing->category_id();
                $Category = new Category($category_id);
                return $Category->category();
            }),
            array('db' => 'svariation_id', 'dt' => 'sell', 'formatter' => function ($d, $row) {
                return 0;
            }),
            array(
                'db' => 'date_created',
                'dt' => "date",
                'formatter' => function ($d, $row) {
                    global $Web;
                    return $Web->date_time($d);
                }
            ),
            array(
                'db' => 'svariation_id',
                'dt' => "actions",
                'formatter' => function ($d, $row) {
                    $listing_id = $row["listing_id"];
                    $Listing = new Listing($listing_id);
                    $variation_id = $row["variation_id"];
                    $vurl = $Listing->vurl($variation_id, $d);
                    return '<div class="d-flex">
                        <a href="' . $vurl . '" data-action="edit" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                            <span class="svg-icon svg-icon-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                    <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                </svg>
                            </span>
                        </a>
                        <button data-id="' . $listing_id . '" data-vid="' . $variation_id . '" data-sid="' . $d . '" data-action="delete" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
							<span class="svg-icon svg-icon-3">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
								<path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="black"></path>
								<path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="black"></path>
								<path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="black"></path>
							</svg>
							</span>
						</button>
                    </div>';
                }
            )
        );

        $sql = "SELECT * FROM $Web->ecommerce_listing_variations_tbl WHERE user_id = '$LogSeller->user_id' AND is_draft = 'yes' ";
        $sql2 = "SELECT COUNT(*) FROM $Web->ecommerce_listing_variations_tbl WHERE user_id = '$LogSeller->user_id' AND is_draft = 'yes' ";
        echo json_encode(
            SSP::simple($_POST, $sql_details, $columns, $sql, $sql2, $sql2)
        );

        break;
}
