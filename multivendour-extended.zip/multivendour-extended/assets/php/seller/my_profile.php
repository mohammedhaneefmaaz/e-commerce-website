<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists('Errors::response_404')) {
        include("../../../db.php");
    }
    Errors::response_404();
}
if (!isset($_POST["case"]))  Errors::response_404();
$case = $_POST["case"];
if ($Web->is_empty($case)) Errors::response_404();
if (!$Login->is_seller_loggedin()) Errors::force_login("seller");

switch ($case) {

    case "remove_store_logo":
        // $avatar_id = $LogSeller->avatar_id();
        // if ($Web->is_file_id($avatar_id)) {
        //     $logo_src = $LogSeller->store_logo();

        //     echo $logo_src;

        //     if (file_exists($logo_src)) {
        //         unlink($logo_src);
        //     }
        // }

        $output = new stdClass;
        $output->image_id = 0;
        $output->image_src = $Web->get_assets("images/web/avatar.png");
        echo json_encode($output);

        break;

    case "update_store_details":
        if (!$Web->is_isset("logo_image_id", "store_name", "store_description")) Errors::response_404();
        $logo_image_id = $Web->sanitize_text($_POST["logo_image_id"]);
        $store_name = $Web->sanitize_text($_POST["store_name"]);
        $store_description = $Web->sanitize_text($_POST["store_description"]);

        $Web->validate_post_input($store_name, "", "Store Name", true);
        $Web->validate_post_input($store_description, "", "Store Description", true);
        $Web->validate_post_length($_POST["store_description"], 500, "Maximum store description length is 500");

        try {

            $db->beginTransaction();

            $stmt = $db->prepare("UPDATE $Web->ecommerce_seller_users_tbl SET store_name = ?, store_description = ?, store_logo_id = ? WHERE user_id = ? ");
            $stmt->execute([$store_name, $store_description, $logo_image_id, $LogSeller->user_id]);
            
            $stmt = $db->prepare("UPDATE $Web->users_tbl SET avatar_id = ? WHERE user_id = ? ");
            $stmt->execute([$logo_image_id, $LogSeller->user_id]);
            $LogSeller->update();

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in updating store details" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Store details has been updated";
        $output->store_name = $LogSeller->store_name();
        $output->store_description = $LogSeller->store_description();
        $output->store_logo = $LogSeller->store_logo();
        echo json_encode($output);

        break;

    case "verify_account":
        if ($LogSeller->status() == "verified") Errors::response("Your account has already verified");
        if ($LogSeller->status() == "pending") Errors::response("Your account is already in pending");

        $contact_details = $LogSeller->contact_details();
        $pickup_address = $LogSeller->pickup_address();
        $store_description = $LogSeller->store_description();
        $store_name = $LogSeller->store_name();

        if (!count((array) $contact_details)) Errors::response("Contact details are empty");
        if (!count((array) $pickup_address)) Errors::response("Pickup address is empty");
        if (empty($store_name)) Errors::response("store name is empty");
        if (empty($store_description)) Errors::response("store description is empty");

        try {
            $db->beginTransaction();
            $stmt = $db->prepare("UPDATE $Web->ecommerce_seller_users_tbl SET status = 'pending' WHERE user_id = ?");
            $stmt->execute([$LogSeller->user_id]);

            $stmt = $db->prepare("INSERT INTO $Web->ecommerce_seller_verification_tbl (`user_id`, `status`,`requested_on`) VALUES (?,'pending',?) ");
            $stmt->execute([$LogSeller->user_id, $Web->current_time()]);
            $db->commit();
            $LogSeller->update();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in verifying account" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Account has been sent for verification";
        $output->status = $LogSeller->status_label();
        echo json_encode($output);
        break;

    case "contact_details":
        if (!$Web->is_isset("contact_name", "mobile_number", "contact_email", "preferred_language")) Errors::response_404();

        $contact_name = $Web->sanitize_text($_POST["contact_name"]);
        $mobile_number = $Web->sanitize_text($_POST["mobile_number"]);
        $contact_email = $Web->sanitize_text($_POST["contact_email"]);
        $preferred_language = $Web->sanitize_text($_POST["preferred_language"]);

        $Web->validate_post_input($contact_name, '', "Contact Name", true);
        $Web->validate_post_input($mobile_number, 'mobile_number', "Mobile Number", true);
        $Web->validate_post_input($contact_email, 'email', "Contact Email", true);
        $Web->validate_post_input($preferred_language, '', "Preferred Language", true);


        $contact_details = [];
        $contact_details["contact_name"] = $contact_name;
        $contact_details["mobile_number"] = $mobile_number;
        $contact_details["contact_email"] = $contact_email;
        $contact_details["preferred_language"] = $preferred_language;
        $contact_details = json_encode($contact_details);

        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_seller_users_tbl SET contact_details = ? WHERE user_id = ?");
            $stmt->execute([$contact_details, $LogSeller->user_id]);
            $LogSeller->update();
        } catch (\Exception $e) {
            Errors::response_500("Error in updating contact details" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Contact Details have been updated";
        echo json_encode($output);
        break;

    case "pickup_address":
        if (!$Web->is_isset("pickup_country", "pickup_state", "pickup_city", "pickup_address", "pin_code")) Errors::response_404();

        $pickup_country = $Web->sanitize_text($_POST["pickup_country"]);
        $pickup_state = $Web->sanitize_text($_POST["pickup_state"]);
        $pickup_city = $Web->sanitize_text($_POST["pickup_city"]);
        $address = $Web->sanitize_text($_POST["pickup_address"]);
        $pin_code = $Web->sanitize_text($_POST["pin_code"]);

        $Web->validate_post_input($pickup_country, '', "Country", true);
        $Web->validate_post_input($pickup_state, '', "State", true);
        $Web->validate_post_input($pickup_city, '', "City", true);
        $Web->validate_post_input($address, '', "Address", true);
        $Web->validate_post_input($pin_code, '', "PIN Code", true);

        $pickup_address = [];
        $pickup_address["pickup_country"] = $pickup_country;
        $pickup_address["pickup_state"] = $pickup_state;
        $pickup_address["pickup_city"] = $pickup_city;
        $pickup_address["pickup_address"] = $address;
        $pickup_address["pin_code"] = $pin_code;
        $pickup_address = json_encode($pickup_address);


        try {
            $stmt = $db->prepare("UPDATE $Web->ecommerce_seller_users_tbl SET pickup_address =? WHERE user_id = ? ");
            $stmt->execute([$pickup_address, $LogSeller->user_id]);
            $LogSeller->update();
        } catch (\Exception $e) {
            Errors::response_500("Error in updating contact details" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Pickup address have been updated";
        echo json_encode($output);
        break;
}
