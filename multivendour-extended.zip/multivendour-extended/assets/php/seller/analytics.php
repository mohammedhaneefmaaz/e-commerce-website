<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists('Errors::response_404')) {
        include("../../../db.php");
    }
    Errors::response_404();
}
if (!isset($_POST["case"]))  Errors::response_404();
$case = $_POST["case"];
if ($Web->is_empty($case)) Errors::response_404();
if (!$Login->is_seller_loggedin()) Errors::force_login("seller");

use Ecommerce\Analytics;
use Ecommerce\Listing;
use Ecommerce\Product;

switch ($case) {

    case "single_product_earnings_graph":
        if (!$Web->is_isset("listing_id", "variation_id", "svariation_id", "from", "to")) Errors::response_404();
        $listing_id = $Web->sanitize_text($_POST["listing_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);

        if (!Listing::is_listing_id($listing_id)) Errors::response("Listing doesn't exist");
        $Listing = new Listing($listing_id);
        if ($Listing->seller()->user_id !== $LogSeller->user_id) Errors::response_404();

        if (!$Listing->is_svariation_live($variation_id, $svariation_id)) Errors::response('Analytics is unavailble for this listing');
        $product_id = $Listing->live_product_id();
        if (!Product::is_product_id($product_id)) Errors::response("Product doesn't exist");
        $from = $Web->sanitize_text($_POST["from"]);
        $to = $Web->sanitize_text($_POST["to"]);

        $graph = Analytics::single_product_earnings_graph($product_id, $variation_id, $svariation_id, $from, $to);
        echo json_encode($graph);
        break;

    case "single_product_sells_graph":
        if (!$Web->is_isset("listing_id", "variation_id", "svariation_id", "from", "to")) Errors::response_404();
        $listing_id = $Web->sanitize_text($_POST["listing_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);

        if (!Listing::is_listing_id($listing_id)) Errors::response("Listing doesn't exist");
        $Listing = new Listing($listing_id);
        if ($Listing->seller()->user_id !== $LogSeller->user_id) Errors::response_404();

        if (!$Listing->is_svariation_live($variation_id, $svariation_id)) Errors::response('Analytics is unavailble for this listing');
        $product_id = $Listing->live_product_id();
        if (!Product::is_product_id($product_id)) Errors::response("Product doesn't exist");
        $from = $Web->sanitize_text($_POST["from"]);
        $to = $Web->sanitize_text($_POST["to"]);

        $graph = Analytics::single_product_sells_graph($product_id, $variation_id, $svariation_id, $from, $to);
        echo json_encode($graph);
        break;


    case "single_product_views_graph":
        if (!$Web->is_isset("listing_id","variation_id", "svariation_id","from", "to")) Errors::response_404();

        $listing_id = $Web->sanitize_text($_POST["listing_id"]);
        $variation_id = $Web->sanitize_text($_POST["variation_id"]);
        $svariation_id = $Web->sanitize_text($_POST["svariation_id"]);

        if(!Listing::is_listing_id($listing_id)) Errors::response("Listing doesn't exist");
        $Listing = new Listing($listing_id);
        if ($Listing->seller()->user_id !== $LogSeller->user_id) Errors::response_404();

        if(!$Listing->is_svariation_live($variation_id,$svariation_id)) Errors::response('Analytics is unavailble for this listing');
        $product_id = $Listing->live_product_id();

        if(!Product::is_product_id($product_id)) Errors::response("Product doesn't exist");

        $from = $Web->sanitize_text($_POST["from"]);
        $to = $Web->sanitize_text($_POST["to"]);

        $graph = Analytics::single_product_views_graph($product_id,$variation_id,$svariation_id,$from, $to);
        echo json_encode($graph);
        break;


    case "product_earnings_graph":
        if (!$Web->is_isset("from", "to")) exit();
        $from = $Web->sanitize_text($_POST["from"]);
        $to = $Web->sanitize_text($_POST["to"]);

        $graph = Analytics::product_earnings_graph($from, $to,$LogSeller->user_id);
        echo json_encode($graph);
        break;

    case "product_sells_graph":
        if (!$Web->is_isset("from", "to")) exit();
        $from = $Web->sanitize_text($_POST["from"]);
        $to = $Web->sanitize_text($_POST["to"]);

        $graph = Analytics::product_sells_graph($from, $to,$LogSeller->user_id);
        echo json_encode($graph);
        break;

    case "product_views_graph":
        if (!$Web->is_isset("from", "to")) exit();
        $from = $Web->sanitize_text($_POST["from"]);
        $to = $Web->sanitize_text($_POST["to"]);

        $graph = Analytics::product_views_graph($from, $to,$LogSeller->user_id);
        echo json_encode($graph);
        break;


}
