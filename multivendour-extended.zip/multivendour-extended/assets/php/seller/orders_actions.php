<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (!function_exists('Errors::response_404')) {
        include("../../../db.php");
    }
    Errors::response_404();
}

if (!isset($_POST["case"]))  Errors::response_404();
$case = $_POST["case"];
if ($Web->is_empty($case)) Errors::response_404();

if (!$Login->is_seller_loggedin()) Errors::force_login("seller");


use Ecommerce\_Order;
use Ecommerce\Order;
use Ecommerce\Product;

switch ($case) {

    case "reject_order":
        if (!$Web->is_isset("orders", "reason")) Errors::response("Invalid Request");
        $orders = $Web->sanitize_text($_POST["orders"]);
        $reason = $Web->sanitize_text($_POST["reason"]);

        if (!is_array($orders)) Errors::response("Invalid data requested");
        $Web->validate_post_input($reason, "", "Reason", true);
        if (!(count($orders) > 0)) Errors::response("Select at least one order");
        $Web->validate_post_length($_POST["reason"], 3000, "Maximum Reject reason length is 3000 ");

        try {
            $db->beginTransaction();

            foreach ($orders as $order_id) {
                if (!Order::is_order_id($order_id)) Errors::response($order_id . " Order Id doesn't exist");
                $Order = new _Order($order_id);
                if ($Order->product()->seller()->user_id !== $LogSeller->user_id) Errors::response_404();
                if ($Order->status_step() < 4 || $Order->status_step() > 6) Errors::response("Sorry the order can't be rejected");
                $total_price = $Order->total_price();
                $product_id = $Order->product_id();
                $variation_id = $Order->variation_id();
                $svariation_id = $Order->svariation_id();
                $Product = new Product($product_id);
                $listing_id = $Product->listing_id();
                $quantity = $Order->quantity();

                if (in_array($Order->status_step(), [5, 6])) {
                    $stmt = $db->prepare("UPDATE `$Web->transactions_tbl` SET status = 'failed', last_updated =? WHERE order_id = ? ");
                    $stmt->execute([$Web->current_time(), $order_id]);
                }

                $refund_status = $Order->can_refund() ? "pending" : "none";
                $refund_inited_on = $Order->can_refund() ? $Web->current_time() : NULL;

                $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET status = 'REJECTED', rejected_reason =?, rejected_on = ?,refund_status = ?, refund_inited_on = ? WHERE order_id = ? ");
                $stmt->execute([$reason, $Web->current_time(), $refund_status,$refund_inited_on, $order_id]);

                $stmt = $db->prepare("UPDATE $Web->ecommerce_variations_tbl SET stock = stock + ? WHERE product_id = ? AND variation_id = ? AND svariation_id = ? ");
                $stmt->execute([$quantity, $product_id, $variation_id, $svariation_id]);


                $stmt = $db->prepare("UPDATE $Web->ecommerce_listing_variations_tbl SET stock = stock + ? WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? ");
                $stmt->execute([$quantity, $listing_id, $variation_id, $svariation_id]);


                if ($Order->is_replacement_order()) {
                    $total_price = $Order->original_order()->total_price();
                    $service_charge = 0;
                    $final_price = $total_price;

                    $grand_total = 0;
                    $charge_details = $Order->charge_details();

                    foreach ($charge_details as $key => $value) {
                        if ($value->service_name == "Shipping Charge") {
                            $charge_details[$key]->service_charge = 0;
                        }
                    }

                    $replacement_charge_details = [];
                    $replacement_charge_details[] = array(
                        "service_name" =>  "Replacement Rejected",
                        "service_charge" => $final_price,
                        "service_type" => "fixed"
                    );

                    $charge_details = json_encode($charge_details);
                    $replacement_charge_details = json_encode($replacement_charge_details);
                    $grand_total = $grand_total - $final_price;

                    $stmt = $db->prepare("UPDATE $Web->transactions_tbl SET charge_details = ? WHERE order_id = ? ");
                    $stmt->execute([$charge_details, $order_id]);

                    $stmt = $db->prepare("INSERT INTO `$Web->transactions_tbl` (`user_id`,`amount`,`txn_charge`,`charge_details`,`net_amount`,`order_id`, `details`,`status`,`date`,`last_updated`,`type`) VALUES (?,?,?,?,?,?,'replacement rejected','debit',?,?,'order') ");
                    $stmt->execute([$seller_id, $total_price, $service_charge, $replacement_charge_details, $final_price, $order_id, $Web->current_time(), $Web->current_time()]);

                    $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET grand_total = ? WHERE order_id = ? ");
                    $stmt->execute([$grand_total, $order_id]);
                }
            }

            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in processing request" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Orders have been rejected";
        echo json_encode($output);
        break;

    case "generate_label":
        if (!$Web->is_isset("orders")) Errors::response("Invalid Request");
        $orders = $Web->sanitize_text($_POST["orders"]);
        if (!is_array($orders)) Errors::response("Invalid data requested");

        if (!(count($orders) > 0)) Errors::response("Select at least one order");

        try {
            $db->beginTransaction();
            foreach ($orders as $order_id) {
                if (!_Order::is_order_id($order_id)) Errors::response($order_id . " Order Id doesn't exist");
                $Order = new _Order($order_id);
                if ($Order->product()->seller()->user_id !== $LogSeller->user_id) Errors::response_404();
                if (!$Order->can_generate_label()) Errors::response("Can't generate label for order #$order_id");
                $total_price = $Order->total_price();

                if ($Order->status() === "SUCCESS") {
                    $charge_details = $Order->service_charge_details();
                    $charge = $Order->service_charge();
                    $grand_total = $Order->service_grand_total();

                    $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET grand_total = ?,service_charge = ?, status = 'LABELLED', labelled_on = ? WHERE order_id = ? ");
                    $stmt->execute([$grand_total, $charge, $Web->current_time(), $order_id]);

                    $description = $Order->is_replacement_order() ? "replacement order" : "new order";

                    $stmt = $db->prepare("INSERT INTO `$Web->transactions_tbl` (`user_id`,`amount`,`txn_charge`,`charge_details`,`net_amount`,`order_id`, `details`,`status`,`date`,`last_updated`,`type`)  VALUES (?,?,?,?,?,?,?,'pending',?,?,'order') ");

                    $stmt->execute([$LogSeller->user_id, $total_price, $charge, $charge_details, $grand_total, $order_id, $description, $Web->current_time(), $Web->current_time()]);
                }
            }
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in processing request" . $e->getLine());
        }

        $orders = json_encode($orders);

        $output = new stdClass;
        $output->message = "Orders have been marked as labelled";
        $output->url = $Web->seller_url() . '/orders/generate-label?id=' . $orders;
        echo json_encode($output);
        break;

    case 'mark_rtd':
        if (!$Web->is_isset("orders")) Errors::response("Invalid Request");
        $orders = $Web->sanitize_text($_POST["orders"]);
        if (!is_array($orders)) Errors::response("Invalid data requested");

        if (!(count($orders) > 0)) Errors::response("Select at least one order");

        try {
            $db->beginTransaction();
            foreach ($orders as $order_id) {
                if (!Order::is_order_id($order_id)) Errors::response($order_id . " Order Id doesn't exist");
                $Order = new Order($order_id);
                if ($Order->product()->seller()->user_id !== $LogSeller->user_id) Errors::response_404();
                if ($Order->status() !== "LABELLED") Errors::response("Only labelled order can be mark as RTD");

                $stmt = $db->prepare("UPDATE $Web->ecommerce_orders_tbl SET status = 'RTD', rtd_on = ? WHERE order_id = ? ");
                $stmt->execute([$Web->current_time(), $order_id]);
            }
            $db->commit();
        } catch (\Exception $e) {
            $db->rollBack();
            Errors::response_500("Error in processing request" . $e->getMessage());
        }

        $output = new stdClass;
        $output->message = "Orders have been marked as rtd";
        echo json_encode($output);
        break;


    default:
        Errors::response_404();
        break;
}
