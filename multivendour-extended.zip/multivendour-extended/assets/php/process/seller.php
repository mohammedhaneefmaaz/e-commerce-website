<?php

include("../../../db.php");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Errors::response_404();
}

$Web->check_web_validation();

if (!isset($_POST['action'])) {
    Errors::response_404();
}

$action = $_POST['action'];
if ($Web->is_empty($action)) {
    Errors::response_404();
}

// sleep(1);

switch ($action) {
    case "support_actions":
        include $Web->include("php/seller/support_actions.php");
        break;

    case "withdraw_actions":
        include $Web->include("php/seller/withdraw_actions.php");
        break;
        
    case "my_profile":
        include $Web->include("php/seller/my_profile.php");
        break;
        
    case "analytics":
        include $Web->include("php/seller/analytics.php");
        break;

    case "orders_actions":
        include $Web->include("php/seller/orders_actions.php");
        break;

    case "updating_tbl_data":
        include $Web->include("php/seller/updating_tbl_data.php");
        break;

    case "start_selling":
        include $Web->include("php/seller/start_selling.php");
        break;

    case "file_upload":
        include $Web->include("php/file_upload.php");
        break;

    case "create_listing":
        include $Web->include("php/seller/create_listing.php");
        break;

    case "loadTblData":
        include $Web->include("php/seller/loadTblData.php");
        break;

    default:
        Errors::response_404();
        break;
}
