<?php

include("../../../db.php");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Errors::response_404();
}

$Web->check_web_validation();

if (!isset($_POST['action'])) {
    Errors::response_404();
}

$action = $_POST['action'];
if ($Web->is_empty($action)) {
    Errors::response_404();
}

// sleep(1);

switch ($action) {


    case "layout_actions":
        include $Web->include("php/admin/settings/layout_actions.php");
        break;

    case "support_actions":
        include $Web->include("php/admin/ecommerce/support_actions.php");
        break;


    case "payment_method_actions":
        include $Web->include("php/admin/settings/payment_method_actions.php");
        break;

    case "ecommerce_service_actions":
        include $Web->include("php/admin/ecommerce/service_actions.php");
        break;

    case "ecommerce_courier_actions":
        include $Web->include("php/admin/ecommerce/courier_actions.php");
        break;

    case "ecommerce_orders_actions":
        include $Web->include("php/admin/ecommerce/orders_actions.php");
        break;

    case "withdraw_actions":
        include $Web->include("php/admin/ecommerce/withdraw_actions.php");
        break;

    case "change_seller_details":
        include $Web->include("php/admin/ecommerce/change_seller_details.php");
        break;

    case "home_page_settings":
        include $Web->include("php/admin/settings/home_page_settings.php");
        break;

    case "site_settings":
        include $Web->include("php/admin/settings/site_settings.php");
        break;

    case "seller_verification":
        include $Web->include("php/admin/ecommerce/seller_verification.php");
        break;

    case "qc_actions":
        include $Web->include("php/admin/ecommerce/qc_actions.php");
        break;

    case "ecommerce_select_actions":
        include $Web->include("php/admin/ecommerce/select_actions.php");
        break;

    case "ecommerce_category_actions":
        include $Web->include("php/admin/ecommerce/category_actions.php");
        break;

    case "account_action":
        include $Web->include("php/admin/account_action.php");
        break;

    case "file_upload":
        include $Web->include("php/file_upload.php");
        break;

    case "loadTblData":
        include $Web->include("php/admin/loadTblData.php");
        break;

    default:
        Errors::response_404();
        break;
}
