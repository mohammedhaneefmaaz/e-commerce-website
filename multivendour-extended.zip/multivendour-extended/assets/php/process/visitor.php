<?php

include("../../../db.php");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Errors::response_404();
}

$Web->check_web_validation();

if (!isset($_POST['action'])) {
    Errors::response_404();
}

$action = $_POST['action'];
if ($Web->is_empty($action)) {
    Errors::response_404();
}

//   sleep(1);

switch ($action) {

    case "support_actions":
        include $Web->include("php/visitor/support_actions.php");
        break;

        
    case "ecommerce_actions":
        include $Web->include("php/visitor/ecommerce/ecommerce_actions.php");
        break;

    case "ecommerce_orders_actions":
        include $Web->include("php/visitor/ecommerce/orders_actions.php");
        break;
        
    case "ecommerce_search_products":
        include $Web->include("php/visitor/ecommerce/search_products.php");
        break;

    case "ecommerce_search_actions":
        include $Web->include("php/visitor/ecommerce/search_actions.php");
        break;

    case "youtube":
        include $Web->include("php/visitor/youtube.php");
        break;

    case "file_upload":
        include $Web->include("php/file_upload.php");
        break;

    case "ecommerce_product_cart_actions":
        include $Web->include("php/visitor/ecommerce/cart_actions.php");
        break;
    case "ecommerce_product_checkout_actions":
        include $Web->include("php/visitor/ecommerce/checkout_actions.php");
        break;

    case "ecommerce_product_actions":
        include $Web->include("php/visitor/ecommerce/product_actions.php");
        break;

    case "chat":
        include $Web->include("php/visitor/job/chat.php");
        break;

    case "loadTblData":
        include $Web->include("php/visitor/loadTblData.php");
        break;

    case "account_action":
        include $Web->include("php/visitor/account_action.php");
        break;

    case "profile_action":
        include $Web->include("php/visitor/profile_action.php");
        break;

    case "jobs_actions":
        include $Web->include("php/visitor/job/jobs_actions.php");
        break;

    case "upload_files":
        include $Web->include("php/visitor/loadTblData.php");
        break;


    default:
        Errors::response_404();
        break;
}
