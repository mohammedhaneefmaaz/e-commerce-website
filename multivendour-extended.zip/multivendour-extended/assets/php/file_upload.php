<?php


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Errors::response_404();
}

$Web->check_web_validation();

if (!isset($_POST['type'])) {
    Errors::response_404();
}

$type = $_POST['type'];
if ($Web->is_empty($action)) {
    Errors::response_404();
}

switch ($type) {

    case "image":
        try {
            $FileUpload = new FileUpload("image");
            $upload = $FileUpload->upload();

            if ($upload->type == "error") Errors::response($upload->message);

            $output = new stdClass();
            $output->file_id = $upload->id;
            $output->type = $type;
            $output->file_url = $upload->url;
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in uploading file");
        }
        break;

    case "file":
        try {
            $FileUpload = new FileUpload("file");
            $FileUpload->validExt = [];
            $upload = $FileUpload->upload();

            if ($upload->type == "error") Errors::response($upload->message);

            $output = new stdClass();
            $output->file_id = $upload->id;
            $output->type = $type;
            $output->file_url = $upload->url;
            $output->preview_url = $upload->preview_url;
            $output->ext = $upload->ext;
            $output->showExt = $upload->showExt;
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in uploading file");
        }
        break;

    case "video":
        try {
            $FileUpload = new FileUpload("video");
            $FileUpload->validExt = ["mp4"];
            $upload = $FileUpload->upload();

            if ($upload->type == "error") Errors::response($upload->message);

            $output = new stdClass();
            $output->file_id = $upload->id;
            $output->type = $type;
            $output->file_url = $upload->url;
            echo json_encode($output);
        } catch (\Exception $e) {
            Errors::response_500("Error in uploading file");
        }
        break;

    default:
        Errors::response_404();
        break;
}
