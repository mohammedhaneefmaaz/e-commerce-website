<?php

namespace Ecommerce;

use Address;
use Error;
use Errors;
use Exception;
use PDO;
use \stdClass;
use User;
use \Web;


class Basic extends Web
{
    public static $category_tbl;


    public static function suggestion_by_popular($keyword)
    {
        global $Web;

        $list = '';
        $search_text = $keyword;
        $params = [];

        $sql = "SELECT search_text, COUNT(search_text), (SELECT COUNT(product_name) FROM $Web->ecommerce_variations_tbl WHERE product_name  LIKE ?  ) as has_searched FROM $Web->ecommerce_search_history_tbl WHERE";
        $params[] = "%$search_text%";

        $keyword = explode(" ", $keyword);

        foreach ($keyword as $key => $word) {
            if ($key == 0) {
                $sql .= " search_text LIKE ? ";
                $params[] = "%$word%";
            } else {
                $sql .= " AND search_text LIKE ? ";
                $params[] = "%$word%";
            }
        }

        $sql .= " GROUP by search_text HAVING has_searched = '0'  ORDER BY COUNT(search_text) DESC LIMIT 10";
        $stmt = $Web->db()->prepare($sql);
        $stmt->execute($params);

        $words = array();
        while ($row =  $stmt->fetch()) {
            $value = $row['search_text'];
            $value = strtolower($value);
            $text =  self::highlightKeywords($value, $search_text);
            $words[] = $value;
            $svg = self::is_searched_text($value) ? ' <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M20.9 12.9C20.3 12.9 19.9 12.5 19.9 11.9C19.9 11.3 20.3 10.9 20.9 10.9H21.8C21.3 6.2 17.6 2.4 12.9 2V2.9C12.9 3.5 12.5 3.9 11.9 3.9C11.3 3.9 10.9 3.5 10.9 2.9V2C6.19999 2.5 2.4 6.2 2 10.9H2.89999C3.49999 10.9 3.89999 11.3 3.89999 11.9C3.89999 12.5 3.49999 12.9 2.89999 12.9H2C2.5 17.6 6.19999 21.4 10.9 21.8V20.9C10.9 20.3 11.3 19.9 11.9 19.9C12.5 19.9 12.9 20.3 12.9 20.9V21.8C17.6 21.3 21.4 17.6 21.8 12.9H20.9Z" fill="black" />
                                        <path d="M16.9 10.9H13.6C13.4 10.6 13.2 10.4 12.9 10.2V5.90002C12.9 5.30002 12.5 4.90002 11.9 4.90002C11.3 4.90002 10.9 5.30002 10.9 5.90002V10.2C10.6 10.4 10.4 10.6 10.2 10.9H9.89999C9.29999 10.9 8.89999 11.3 8.89999 11.9C8.89999 12.5 9.29999 12.9 9.89999 12.9H10.2C10.4 13.2 10.6 13.4 10.9 13.6V13.9C10.9 14.5 11.3 14.9 11.9 14.9C12.5 14.9 12.9 14.5 12.9 13.9V13.6C13.2 13.4 13.4 13.2 13.6 12.9H16.9C17.5 12.9 17.9 12.5 17.9 11.9C17.9 11.3 17.5 10.9 16.9 10.9Z" fill="black" />
                                    </svg>' : '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path d="M17.8 8.79999L13 13.6L9.7 10.3C9.3 9.89999 8.7 9.89999 8.3 10.3L2.3 16.3C1.9 16.7 1.9 17.3 2.3 17.7C2.5 17.9 2.7 18 3 18C3.3 18 3.5 17.9 3.7 17.7L9 12.4L12.3 15.7C12.7 16.1 13.3 16.1 13.7 15.7L19.2 10.2L17.8 8.79999Z" fill="black" />
                                        <path opacity="0.3" d="M22 13.1V7C22 6.4 21.6 6 21 6H14.9L22 13.1Z" fill="black" />
                                    </svg>';
            $list .= '
        <li data-text="' . $value . '" >
                            <div>
                                <span class="svg-icon svg-icon-muted svg-icon-2x">
                                    ' . $svg . '
                                </span>
                                <span>' . $text . '</span>
                            </div>
                            <div>
                                <span class="svg-icon fill-search svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="16.9497" y="8.46448" width="13" height="2" rx="1" transform="rotate(135 16.9497 8.46448)" fill="black" />
                                        <path d="M14.8284 9.97157L14.8284 15.8891C14.8284 16.4749 15.3033 16.9497 15.8891 16.9497C16.4749 16.9497 16.9497 16.4749 16.9497 15.8891L16.9497 8.05025C16.9497 7.49797 16.502 7.05025 15.9497 7.05025L8.11091 7.05025C7.52512 7.05025 7.05025 7.52513 7.05025 8.11091C7.05025 8.6967 7.52512 9.17157 8.11091 9.17157L14.0284 9.17157C14.4703 9.17157 14.8284 9.52975 14.8284 9.97157Z" fill="black" />
                                    </svg>
                                </span>
                            </div>
                        </li>';
        }

        $list .= self::suggestion_by_product_name($words, $search_text);
        return $list;
    }

    private static function highlightKeywords($text, $words)
    {
        preg_match_all('~[A-Za-z0-9_äöüÄÖÜ]+~', $words, $m);
        if (!$m)
            return $text;
        $re = '~(' . implode('|', $m[0]) . ')~i';
        return preg_replace($re, '<b>$0</b>', $text);
    }
    private static function is_searched_text($text)
    {
        global $Login;
        global $LogUser;
        if ($Login->is_user_loggedin()) {
            $stmt = $Login->db()->prepare("SELECT DISTINCT search_text FROM $Login->ecommerce_search_history_tbl WHERE user_id = ? AND search_text = ? ");
            $stmt->execute([$LogUser->user_id, $text]);
            return $stmt->rowCount() ? true : false;
        }
    }


    private static function suggestion_by_product_name($words_included, $search_text)
    {

        global $Web;
        $list = '';
        $params = [];
        $sql = "SELECT product_name FROM $Web->ecommerce_variations_tbl WHERE";
        $keyword = $search_text;
        $keyword = explode(" ", $keyword);
        foreach ($keyword as $key => $word) {
            if ($key == 0) {
                $sql .= " product_name LIKE ?";
                $params[] = "%$word%";
            } else {
                $sql .= " AND product_name LIKE ?";
                $params[] = "%$word%";
            }
        }

        $sql .= " GROUP BY product_name";

        $stmt = $Web->db()->prepare($sql);
        $stmt->execute($params);

        while ($row =  $stmt->fetch()) {
            $value = $row->product_name;
            $value = strtolower($value);
            $text =  self::highlightKeywords($value, $search_text);
            $words[] = $value;
            $svg = self::is_searched_text($value) ? ' <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M20.9 12.9C20.3 12.9 19.9 12.5 19.9 11.9C19.9 11.3 20.3 10.9 20.9 10.9H21.8C21.3 6.2 17.6 2.4 12.9 2V2.9C12.9 3.5 12.5 3.9 11.9 3.9C11.3 3.9 10.9 3.5 10.9 2.9V2C6.19999 2.5 2.4 6.2 2 10.9H2.89999C3.49999 10.9 3.89999 11.3 3.89999 11.9C3.89999 12.5 3.49999 12.9 2.89999 12.9H2C2.5 17.6 6.19999 21.4 10.9 21.8V20.9C10.9 20.3 11.3 19.9 11.9 19.9C12.5 19.9 12.9 20.3 12.9 20.9V21.8C17.6 21.3 21.4 17.6 21.8 12.9H20.9Z" fill="black" />
                                        <path d="M16.9 10.9H13.6C13.4 10.6 13.2 10.4 12.9 10.2V5.90002C12.9 5.30002 12.5 4.90002 11.9 4.90002C11.3 4.90002 10.9 5.30002 10.9 5.90002V10.2C10.6 10.4 10.4 10.6 10.2 10.9H9.89999C9.29999 10.9 8.89999 11.3 8.89999 11.9C8.89999 12.5 9.29999 12.9 9.89999 12.9H10.2C10.4 13.2 10.6 13.4 10.9 13.6V13.9C10.9 14.5 11.3 14.9 11.9 14.9C12.5 14.9 12.9 14.5 12.9 13.9V13.6C13.2 13.4 13.4 13.2 13.6 12.9H16.9C17.5 12.9 17.9 12.5 17.9 11.9C17.9 11.3 17.5 10.9 16.9 10.9Z" fill="black" />
                                    </svg>' : '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path d="M17.8 8.79999L13 13.6L9.7 10.3C9.3 9.89999 8.7 9.89999 8.3 10.3L2.3 16.3C1.9 16.7 1.9 17.3 2.3 17.7C2.5 17.9 2.7 18 3 18C3.3 18 3.5 17.9 3.7 17.7L9 12.4L12.3 15.7C12.7 16.1 13.3 16.1 13.7 15.7L19.2 10.2L17.8 8.79999Z" fill="black" />
                                        <path opacity="0.3" d="M22 13.1V7C22 6.4 21.6 6 21 6H14.9L22 13.1Z" fill="black" />
                                    </svg>';
            $list .= '
        <li data-text="' . $value . '" >
                            <div>
                                <span class="svg-icon svg-icon-muted svg-icon-2x">
                                    ' . $svg . '
                                </span>
                                <span>' . $text . '</span>
                            </div>
                            <div>
                                <span class="svg-icon fill-search svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="16.9497" y="8.46448" width="13" height="2" rx="1" transform="rotate(135 16.9497 8.46448)" fill="black" />
                                        <path d="M14.8284 9.97157L14.8284 15.8891C14.8284 16.4749 15.3033 16.9497 15.8891 16.9497C16.4749 16.9497 16.9497 16.4749 16.9497 15.8891L16.9497 8.05025C16.9497 7.49797 16.502 7.05025 15.9497 7.05025L8.11091 7.05025C7.52512 7.05025 7.05025 7.52513 7.05025 8.11091C7.05025 8.6967 7.52512 9.17157 8.11091 9.17157L14.0284 9.17157C14.4703 9.17157 14.8284 9.52975 14.8284 9.97157Z" fill="black" />
                                    </svg>
                                </span>
                            </div>
                        </li>';
        }
        return $list;
    }

    public function web_low_stock_warning()
    {
        return 10;
    }


    public static function searchHistory($Web, $user_id)
    {
        $output = '';
        $stmt = $Web->db()->prepare("SELECT * FROM $Web->ecommerce_search_history_tbl WHERE user_id = ? ORDER by search_id DESC ");
        $stmt->execute([$user_id]);
        while ($row =  $stmt->fetch()) {
            $search_id = $row->search_id;
            $search_text = $row->search_text;
            $output .= '
             <li data-type="history" data-id="' . $search_id . '" data-text="' . $search_text . '" >
                            <div>
                                <span class="svg-icon svg-icon-muted svg-icon-2x">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M20.9 12.9C20.3 12.9 19.9 12.5 19.9 11.9C19.9 11.3 20.3 10.9 20.9 10.9H21.8C21.3 6.2 17.6 2.4 12.9 2V2.9C12.9 3.5 12.5 3.9 11.9 3.9C11.3 3.9 10.9 3.5 10.9 2.9V2C6.19999 2.5 2.4 6.2 2 10.9H2.89999C3.49999 10.9 3.89999 11.3 3.89999 11.9C3.89999 12.5 3.49999 12.9 2.89999 12.9H2C2.5 17.6 6.19999 21.4 10.9 21.8V20.9C10.9 20.3 11.3 19.9 11.9 19.9C12.5 19.9 12.9 20.3 12.9 20.9V21.8C17.6 21.3 21.4 17.6 21.8 12.9H20.9Z" fill="black"></path>
                                        <path d="M16.9 10.9H13.6C13.4 10.6 13.2 10.4 12.9 10.2V5.90002C12.9 5.30002 12.5 4.90002 11.9 4.90002C11.3 4.90002 10.9 5.30002 10.9 5.90002V10.2C10.6 10.4 10.4 10.6 10.2 10.9H9.89999C9.29999 10.9 8.89999 11.3 8.89999 11.9C8.89999 12.5 9.29999 12.9 9.89999 12.9H10.2C10.4 13.2 10.6 13.4 10.9 13.6V13.9C10.9 14.5 11.3 14.9 11.9 14.9C12.5 14.9 12.9 14.5 12.9 13.9V13.6C13.2 13.4 13.4 13.2 13.6 12.9H16.9C17.5 12.9 17.9 12.5 17.9 11.9C17.9 11.3 17.5 10.9 16.9 10.9Z" fill="black"></path>
                                    </svg>
                                </span>
                                <span>' . $search_text . '</span>
                            </div>
                            <div>
                                <span class="remove-search svg-icon svg-icon-muted svg-icon-2x">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="black" />
                                        <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="black" />
                                        <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="black" />
                                    </svg>
                                </span>
                                <span class="svg-icon fill-search svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="16.9497" y="8.46448" width="13" height="2" rx="1" transform="rotate(135 16.9497 8.46448)" fill="black" />
                                        <path d="M14.8284 9.97157L14.8284 15.8891C14.8284 16.4749 15.3033 16.9497 15.8891 16.9497C16.4749 16.9497 16.9497 16.4749 16.9497 15.8891L16.9497 8.05025C16.9497 7.49797 16.502 7.05025 15.9497 7.05025L8.11091 7.05025C7.52512 7.05025 7.05025 7.52513 7.05025 8.11091C7.05025 8.6967 7.52512 9.17157 8.11091 9.17157L14.0284 9.17157C14.4703 9.17157 14.8284 9.52975 14.8284 9.97157Z" fill="black" />
                                    </svg>
                                </span>
                            </div>
                        </li>';
        }
        return $output;
    }


    public static function popularSearch($Web)
    {
        $output = '';
        $stmt = $Web->db()->query("SELECT search_text,COUNT(search_text) FROM $Web->ecommerce_search_history_tbl GROUP BY search_text ORDER BY COUNT(search_text) DESC LIMIT 5");
        while ($row =  $stmt->fetch()) {
            $search_text = $row->search_text;
            $output .= '<li data-text="' . $search_text . '" >
                            <div>
                                <span class="svg-icon svg-icon-muted svg-icon-2x">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path d="M17.8 8.79999L13 13.6L9.7 10.3C9.3 9.89999 8.7 9.89999 8.3 10.3L2.3 16.3C1.9 16.7 1.9 17.3 2.3 17.7C2.5 17.9 2.7 18 3 18C3.3 18 3.5 17.9 3.7 17.7L9 12.4L12.3 15.7C12.7 16.1 13.3 16.1 13.7 15.7L19.2 10.2L17.8 8.79999Z" fill="black" />
                                        <path opacity="0.3" d="M22 13.1V7C22 6.4 21.6 6 21 6H14.9L22 13.1Z" fill="black" />
                                    </svg>
                                </span>
                                <span>' . $search_text . '</span>
                            </div>
                            <div>
                                <span class="svg-icon fill-search svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="16.9497" y="8.46448" width="13" height="2" rx="1" transform="rotate(135 16.9497 8.46448)" fill="black" />
                                        <path d="M14.8284 9.97157L14.8284 15.8891C14.8284 16.4749 15.3033 16.9497 15.8891 16.9497C16.4749 16.9497 16.9497 16.4749 16.9497 15.8891L16.9497 8.05025C16.9497 7.49797 16.502 7.05025 15.9497 7.05025L8.11091 7.05025C7.52512 7.05025 7.05025 7.52513 7.05025 8.11091C7.05025 8.6967 7.52512 9.17157 8.11091 9.17157L14.0284 9.17157C14.4703 9.17157 14.8284 9.52975 14.8284 9.97157Z" fill="black" />
                                    </svg>
                                </span>
                            </div>
                        </li>';
        }
        return $output;
    }



    public static function filter_category_card($id)
    {
        global $Web;

        $Cat = new Category($id);
        $parent_id = $Cat->parent_id();
        $output = '';

        $bread_crumbs = [];
        while ($parent_id != 0) {
            $bread_crumbs[] = $parent_id;
            $parent_id =  (new Category($parent_id))->parent_id();
        }

        $bread_crumbs = array_reverse($bread_crumbs);

        foreach ($bread_crumbs as $category_id) {
            $C = new Category($category_id);
            $category = $C->category();
            $output .= '
                            <div data-filter="category" data-id="' . $category_id . '" class="text-gray-700 cursor-pointer">
                                                <span class="svg-icon svg-icon-muted svg-icon-2">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path d="M11.2657 11.4343L15.45 7.25C15.8642 6.83579 15.8642 6.16421 15.45 5.75C15.0358 5.33579 14.3642 5.33579 13.95 5.75L8.40712 11.2929C8.01659 11.6834 8.01659 12.3166 8.40712 12.7071L13.95 18.25C14.3642 18.6642 15.0358 18.6642 15.45 18.25C15.8642 17.8358 15.8642 17.1642 15.45 16.75L11.2657 12.5657C10.9533 12.2533 10.9533 11.7467 11.2657 11.4343Z" fill="black" />
                                                    </svg>
                                                </span> ' . $category . '
                             </div>';
        }

        $category = $Cat->category();

        if ($Cat->is_last_category()) {
            $output .= '<div>
                              <div class="ms-12 text-muted"> ' . $category . '</div>
                     </div>';
        } else {
            $output .= '<div data-filter="category" data-id="' . $id . '" class="text-gray-700 cursor-pointer">
                                                <span class="svg-icon svg-icon-muted svg-icon-2">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path d="M11.2657 11.4343L15.45 7.25C15.8642 6.83579 15.8642 6.16421 15.45 5.75C15.0358 5.33579 14.3642 5.33579 13.95 5.75L8.40712 11.2929C8.01659 11.6834 8.01659 12.3166 8.40712 12.7071L13.95 18.25C14.3642 18.6642 15.0358 18.6642 15.45 18.25C15.8642 17.8358 15.8642 17.1642 15.45 16.75L11.2657 12.5657C10.9533 12.2533 10.9533 11.7467 11.2657 11.4343Z" fill="black" />
                                                    </svg>
                                                </span> ' . $category . '
                          </div>';

            $stmt = $Web->db()->prepare("SELECT category_id FROM $Web->ecommerce_category_tbl WHERE parent_id = ? ");
            $stmt->execute([$id]);
            while ($row =  $stmt->fetch()) {
                $category_id = $row->category_id;
                $C = new Category($category_id);
                if (!$C->has_products()) continue;
                $category = $C->category();
                $output .= '<div data-filter="category" data-id="' . $category_id . '" class="text-gray-700 cursor-pointer">
                              <div class="ms-12 fw-bolder"> ' . $category . '</div>
                     </div>';
            }
        }
        return $output;
    }

    public static $zeroLevelId = array();
    public static function categories_filter_ids($categoryId)
    {
        self::zero_level_category_id($categoryId);
        return self::$zeroLevelId;
    }

    public static function zero_level_category_id($cat_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT * FROM $Web->ecommerce_category_tbl WHERE parent_id = ? ");
        $stmt->execute([$cat_id]);
        while ($row =  $stmt->fetch()) {
            $category_id = $row->category_id;
            $Category = new Category($category_id);
            $is_last_category = $Category->is_last_child();

            if ($is_last_category) {
                self::$zeroLevelId[] = $category_id;
            } else {
                self::zero_level_category_id($category_id);
            }
        }
    }


    public function GET_FILTER_DATA($primary_sql, $search_sql, $price_sql, $details_sql, $category_sql, $rating_sql, &$current_min_price, &$current_max_price, $rating, $filter_details, $params)
    {

        $min_price = null;
        $max_price = null;
        $filters = [];
        $filter_card = [];
        $filter_card["category"] = "";
        $group_by_sql = " GROUP BY svariation_id ";
        $order_by_sql = " ORDER BY category DESC";
        $category_filter = null;

        $sql = $primary_sql . $search_sql . $price_sql . $details_sql . $group_by_sql . $category_sql . $rating_sql . $order_by_sql;

        $stmt = $this->db()->prepare($sql);
        $stmt->execute($params);


        if ($stmt->rowCount()) {
            $used_details = [];
            while ($row = $stmt->fetch()) {
                if (empty($category_filter)) {
                    $category_filter = $row->category_id;
                    $category_id = $row->category_id;
                    $Category = new Category($category_id);
                }

                $details = $row->details;
                $details = json_decode($details, true);

                if (!is_array($details)) $details = [];
                foreach ($details as $detail_id => $val) {

                    if (!isset($filters[$detail_id]))  $filters[$detail_id] = '';
                    if ($Category->detail_filter($detail_id) == "yes" && !isset($used_details[$val])) {
                        $used_details[$val] = $val;
                        $check = "";
                        if (isset($filter_details[$detail_id]) && in_array($val, $filter_details[$detail_id])) {
                            $check = 'checked = "checked" ';
                        }
                        $filters[$detail_id] .=
                            '<label class="mb-5 cursor-pointer form-check form-check-custom form-check-solid mb-5">
                                    <input data-filter="detail" ' . $check . ' class="form-check-input" type="checkbox" data-id="' . $detail_id . '" value="' . $val . '" >
                                    <div class="form-check-label flex-grow-1 fw-bold text-gray-700 fs-6" >' . $val . '</div>
                         </label>';
                    }
                }

                if (empty($min_price) || $min_price > $row->MIN_PRICE) $min_price = $row->MIN_PRICE;
                if ($max_price < $row->MAX_PRICE) $max_price = $row->MAX_PRICE;
            }

            if (empty($current_min_price)) $current_min_price = $min_price;
            if (empty($current_max_price)) $current_max_price = $max_price;


            $filter_card["price"] = '
                    <div class="filter-card">
                    <div class="border-bottom card card-flush ">
                        <div data-bs-toggle="collapse" data-bs-target="#price_toggle" class="cursor-pointer card-header  rotate collapsible">
                            <div class="card-title">
                                <h6 class="text-uppercase text-primary-alt">Price</h6>
                            </div>
                            <div class="card-toolbar rotate-180">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#3e5569">
                                    <path d="M12.5657 11.3657L16.75 15.55C17.1642 15.9643 17.8358 15.9643 18.25 15.55C18.6642 15.1358 18.6642 14.4643 18.25 14.05L12.7071 8.50716C12.3166 8.11663 11.6834 8.11663 11.2929 8.50715L5.75 14.05C5.33579 14.4643 5.33579 15.1358 5.75 15.55C6.16421 15.9643 6.83579 15.9643 7.25 15.55L11.4343 11.3657C11.7467 11.0533 12.2533 11.0533 12.5657 11.3657Z" />
                                </svg>
                            </div>
                        </div>
                        <div class="collapse show" id="price_toggle">
                            <div class="pt-0 card-body">
                                <div class="price-slider">
                                    <p id="price_text">' . $this->formatCurrency($current_min_price) . ' - ' . $this->formatCurrency($current_max_price) . '</p>
                                    <div id="price_range" class="ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content">
                                        <div class="ui-slider-range ui-corner-all ui-widget-header" style="left: 0%; width: 100%;"></div>
                                        <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default" style="left: 0%;"></span>
                                        <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default" style="left: 100%;"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>';



            foreach ($filters as $detail_id => $val) {
                if (!$Category->is_detail_id($detail_id)) continue;
                $option_text = $Category->detail_text($detail_id);
                if (!empty($val)) {
                    $filter_card[$detail_id] = '<div class="text-primary-alt">
                        <div class="border-bottom card card-flush ">
                            <div data-bs-toggle="collapse" data-bs-target="#filter_' . $detail_id . '" class="collapsible cursor-pointer rotate collapsed card-header">
                                <div class="card-title">
                                    <h6 class="text-uppercase text-primary-alt">' . $option_text . '</h6>
                                </div>
                                <div class="card-toolbar rotate-180">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#3e5569">
                                    <path d="M12.5657 11.3657L16.75 15.55C17.1642 15.9643 17.8358 15.9643 18.25 15.55C18.6642 15.1358 18.6642 14.4643 18.25 14.05L12.7071 8.50716C12.3166 8.11663 11.6834 8.11663 11.2929 8.50715L5.75 14.05C5.33579 14.4643 5.33579 15.1358 5.75 15.55C6.16421 15.9643 6.83579 15.9643 7.25 15.55L11.4343 11.3657C11.7467 11.0533 12.2533 11.0533 12.5657 11.3657Z"/>
                                    </svg>
                                </div>
                            </div>
                            <div class="collapse show" id="filter_' . $detail_id . '" >
                            <div class="py-0 card-body">
                            ' . $val . '
                            </div>
                            </div>
                        </div>
                        </div>';
                }
            }


            $filter_rating_card = "";
            for ($i = 4; $i >= 1; $i--) {
                $check = is_array($rating) && in_array($i, $rating) ? 'checked = "checked" ' : "";
                $filter_rating_card .= '<div class="form-check form-check-custom form-check-solid mb-5">
                    <input data-filter="rating" ' . $check . ' id="rating_' . $i . '" class="form-check-input" type="checkbox" value="' . $i . '">
                    <label class="form-check-label flex-grow-1 fw-bold text-gray-700 fs-6" for="rating_' . $i . '">' . $i . ' <span><i class="text-primary-alt bi bi-star"></i></span> & above </label>
                        </div>';
            }

            $filter_card["rating"] = '
                        <div class="text-primary-alt filter-card">
                        <div class="border-bottom card card-flush ">
                            <div data-bs-toggle="collapse" data-bs-target="#rating_toggle" class="cursor-pointer card-header  rotate collapsible">
                                <div class="card-title">
                                    <h6 class="text-uppercase text-primary-alt">Customer Ratings</h6>
                                </div>
                                <div class="card-toolbar rotate-180">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#3e5569">
                                        <path d="M12.5657 11.3657L16.75 15.55C17.1642 15.9643 17.8358 15.9643 18.25 15.55C18.6642 15.1358 18.6642 14.4643 18.25 14.05L12.7071 8.50716C12.3166 8.11663 11.6834 8.11663 11.2929 8.50715L5.75 14.05C5.33579 14.4643 5.33579 15.1358 5.75 15.55C6.16421 15.9643 6.83579 15.9643 7.25 15.55L11.4343 11.3657C11.7467 11.0533 12.2533 11.0533 12.5657 11.3657Z" />
                                    </svg>
                                </div>
                            </div>
                            <div class="collapse show" id="rating_toggle">
                                <div class="py-0 card-body">
                                    ' . $filter_rating_card . '
                                </div>
                            </div>
                        </div>
                    </div>';
        }

        $output = new stdClass;
        $output->card = $filter_card;
        $output->min_price = $min_price;
        $output->max_price = $max_price;

        return $output;
    }
}

class Home extends Basic
{
    public function components($layout_id)
    {
        $output = "";
        if (!Layout::is_layout_id($layout_id)) return;
        $Layout = new Layout($layout_id);
        $components = $Layout->components();
        foreach ($components as $key) {
            if (!Component::is_component_id($key)) continue;
            $Component = new Component($key);
            $row = $Component->data();

            switch ($Component->type()) {
                case "slider":
                    $output .= $this->get_swiper_slider($row);
                    break;
                case "manual_slider":
                    $output .= $this->get_manual_slider($row, $Component->heading(), $Component->columns(), $Component->tab_columns(), $Component->mobile_columns());
                    break;
                case "category":
                    $output .= $this->get_category_slider($row, $Component->heading(), $Component->columns(), $Component->tab_columns(), $Component->mobile_columns());
                    break;
                case "banner":
                    $output .= $this->get_banner($row, $Component->columns(), $Component->tab_columns(), $Component->mobile_columns());
                    break;
                case "product_slider":
                    $output .= $this->create_product_slider_card($row);
                    break;
            }
        }

        return $output;
    }


    public function get_swiper_slider($rows)
    {
        $output = '';
        foreach ($rows as $row) {
            if ($row->status == "active") {
                $src = $this->get_file_src($row->image_id);
                $url = $row->url;
                if (!empty($url)) {
                    $output .= '<a href="' . $url . '" target="_blank" class="swiper-slide">
                    <img src="' . $src . '">
                </a>';
                } else {
                    $output .= '<a class="swiper-slide">
                    <img src="' . $src . '">
                </a>';
                }
            }
        }
        $card = '<div class="swiper slider1">
            <div class="swiper-wrapper">
            ' . $output . '
            </div>
            <div class="swiper-pagination"></div>
        </div>';
        return $card;
    }

    public function get_banner($rows, $columns, $tab_columns, $mobile_columns)
    {
        $output = "";
        $output = '';

        $columns = 12 / $columns;
        $tab_columns = 12 / $tab_columns;
        $mobile_columns = 12 / $mobile_columns;

        foreach ($rows as $row) {
            $image_id = $row->image_id;
            $url = $row->url;
            $status = $row->status;
            if ($status !== "active") continue;
            $src = $this->get_file_src($image_id);
            if (empty($url)) {
                $output .= '<div class="col-lg-' . $columns . ' col-md-' . $tab_columns . ' col-' . $mobile_columns . '  " >
                <img class="img-fluid" src="' . $src . '" >
            </div>';
            } else {
                $output .= '<a href="' . $url . '" class="col-lg-' . $columns . ' col-md-' . $tab_columns . ' col-' . $mobile_columns . ' " >
                <img class="img-fluid" src="' . $src . '" >
            </a>';
            }
        }
        $card = '<div class="row g-2 g-lg-4" >' . $output . '</div>';
        return $card;
    }

    public function get_manual_slider($rows, $heading, $columns, $tab_columns, $mobile_columns)
    {
        $products = '';

        foreach ($rows as $row) {
            $image_id = $row->image_id;
            $url = $row->url;
            $status = $row->status;
            if ($status !== "active") continue;

            $url = $row->url;
            $image_id = $row->image_id;
            $url = $row->url;
            $image = $this->get_file_src($image_id);
            $href = empty($url) ? "" : ' href="' . $url . '" ';

            $products .= '
             <a ' . $href . ' class="text-primary-alt h-100 d-flex flex-column justify-content-between swiper-slide">
                <img src="' . $image . '" class="mh-100 img-fluid">
                    <div class="text-center fs-7 p-3">
                                <div class="font-normal line-clamp line-clamp-1">' . $row->text1 . '</div>
                                <div class="font-normal text-success line-clamp line-clamp-1">' . $row->text2 . '</div>
                                <div class="font-normal text-muted line-clamp line-clamp-1">' . $row->text3 . '</div>
                        </div>
             </a>';
        }
        return '<div class="card card-flush">
                <div class="card-header">
                    <div class="card-title">
                        <h2>' . $heading . '</h2>
                    </div>
                </div>
                <div class="card-body px-0 px-lg-8 pt-0">
                    <div data-columns="' . $columns . '" data-tab_columns="' . $tab_columns . '" data-mobile_columns="' . $mobile_columns . '" class="swiper swiper-container manual-slider slider2">
                        <div class="swiper-wrapper">
                            ' . $products . '
                        </div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
            </div>';
    }

    public function get_category_slider($rows, $heading, $columns, $tab_columns, $mobile_columns)
    {
        $products = '';

        foreach ($rows as $row) {
            $image_id = $row->image_id;
            $url = $row->url;
            $status = $row->status;
            if ($status !== "active") continue;

            $url = $row->url;
            $image_id = $row->image_id;
            $url = $row->url;
            $image = $this->get_file_src($image_id);
            $href = empty($url) ? "" : ' href="' . $url . '" ';
            $products .= '
             <a ' . $href . '  class="text-primary-alt d-flex h-100 flex-column justify-content-between swiper-slide">
                <img src="' . $image . '" class="mh-100 img-fluid">
                    <div class="text-center fs-7 p-3">
                                <div class="fw-bolder line-clamp line-clamp-1">' . $row->category_name . '</div>
                   </div>
             </a>';
        }
        return '<div class="card card-flush">
                <div class="card-header">
                    <div class="card-title">
                        <h2>' . $heading . '</h2>
                    </div>
                </div>
                <div class="card-body px-0 px-lg-8 pt-0">
                    <div data-columns="' . $columns . '" data-tab_columns="' . $tab_columns . '" data-mobile_columns="' . $mobile_columns . '" class="swiper category-slider swiper-container manual-slider slider2">
                        <div class="swiper-wrapper">
                            ' . $products . '
                        </div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
            </div>';
    }

    public function create_product_slider_card($row)
    {
        $status = $row->status;
        $limit = $row->total_columns;
        $category = $row->category;
        $sort_by = $row->sort_by;

        if ($status !== "active") return;


        return '<div class="card card-flush">
        <div class="card-header">
            <div class="card-title">
                <h2>' . $row->heading . '</h2>
            </div>
        </div>
        <div class="card-body px-0 px-lg-8 pt-0">
            <div data-mobile_columns="2" class="swiper product-slider swiper-container slider2">
                <div class="swiper-wrapper">
                    ' . $this->get_product_sliders_products($category, $sort_by, $limit) . '
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </div>';
    }


    public function get_product_sliders_products($category_id, $sort_by, $limit)
    {
        // return;

        $sql = "";
        $cards = "";
        $category = "";
        $having = " WHERE status = 'active' GROUP BY variation_id ";

        if ($category_id !== "all") {
            $category = " , (SELECT category_id FROM $this->ecommerce_products_tbl WHERE product_id = $this->ecommerce_variations_tbl.product_id) as category_id ";

            $Category = new Category($category_id);
            if ($Category->is_last_category()) {
                $having .= " HAVING category_id = '$category_id' ";
            } else {
                $categories_array = Basic::categories_filter_ids($category_id);
                $categories_array = implode("','", $categories_array);

                $having .=  " HAVING category_id IN ('" . $categories_array . "') ";
            }
        }

        switch ($sort_by) {
            case "sells":

                $stmt = $this->db()->query("SELECT product_id,variation_id,svariation_id, 
        (SELECT SUM(quantity) FROM $this->ecommerce_orders_tbl WHERE $this->ecommerce_orders_tbl.product_id = $this->ecommerce_variations_tbl.product_id AND  $this->ecommerce_orders_tbl.variation_id = $this->ecommerce_variations_tbl.variation_id AND  $this->ecommerce_orders_tbl.svariation_id = $this->ecommerce_variations_tbl.svariation_id AND ( $this->ecommerce_orders_tbl.STATUS = 'DELIVERED' OR  $this->ecommerce_orders_tbl.STATUS = 'REPLACEMENT')  ) as sells $category  FROM $this->ecommerce_variations_tbl $having  ORDER BY sells DESC ");

                break;
            case "latest":
                $stmt = $this->db()->query("SELECT product_id,variation_id,svariation_id $category FROM $this->ecommerce_variations_tbl $having ORDER BY date_created DESC LIMIT $limit ");
                break;

            case "price_asc":

                $stmt = $this->db()->query("SELECT product_id,variation_id,svariation_id $category FROM $this->ecommerce_variations_tbl $having ORDER BY price ASC LIMIT $limit ");
                break;

            case "price_desc":
                $stmt = $this->db()->query("SELECT product_id,variation_id,svariation_id $category FROM $this->ecommerce_variations_tbl $having ORDER BY price DESC LIMIT $limit ");
                break;

            case "discount":
                $stmt = $this->db()->query("SELECT product_id,variation_id,svariation_id, (mrp - price) * 100/mrp as discount
                $category FROM $this->ecommerce_variations_tbl $having ORDER BY discount DESC LIMIT $limit ");
                break;

            case "rating":
                $stmt = $this->db()->query("SELECT product_id,variation_id,svariation_id,(SELECT AVG(rating) FROM $this->ecommerce_reviews_tbl WHERE product_id = $this->ecommerce_variations_tbl.product_id) as avg_rating $category FROM $this->ecommerce_variations_tbl $having ORDER BY avg_rating DESC LIMIT $limit ");
                break;

            case "view":
                $stmt = $this->db()->query("SELECT product_id,variation_id,svariation_id,
                  (
                    SELECT SUM(views) FROM $this->ecommerce_product_views_tbl WHERE $this->ecommerce_product_views_tbl.product_id = $this->ecommerce_variations_tbl.product_id AND $this->ecommerce_product_views_tbl.variation_id = $this->ecommerce_variations_tbl.variation_id AND $this->ecommerce_product_views_tbl.svariation_id = $this->ecommerce_variations_tbl.svariation_id
                  ) as views $category FROM $this->ecommerce_variations_tbl $having ORDER BY views DESC LIMIT $limit ");
                break;

            case "random":
                $stmt = $this->db()->query("SELECT product_id,variation_id,svariation_id $category FROM $this->ecommerce_variations_tbl $having ORDER BY rand() LIMIT $limit ");
                break;
        }

        while ($row =  $stmt->fetch()) {
            $cards .= $this->create_card($row);
        }
        return $cards;
    }


    public function create_card($param)
    {

        $product_id = $param->product_id;
        $variation_id = $param->variation_id;
        $svariation_id = $param->svariation_id;

        $Product = new Product($product_id);
        return ' <a href="' . $Product->url($variation_id, $svariation_id) . '"  class="text-primary-alt h-100 align-items-start d-flex flex-column swiper-slide">
                                            <div class="text-center w-100">
                                                <img src="' . $Product->image($variation_id, $svariation_id) . '" class="img-fluid">
                                            </div>
                                            <div class="text-start fs-7 p-3">
                                                <div class="font-normal line-clamp line-clamp-1">' . $Product->product_name($variation_id, $svariation_id) . '</div>
                                                <span class="mb-2"><span class="font-16">' . $Product->price_text($variation_id, $svariation_id) . '</span> <span class="text-muted mx-1"><del>' . $Product->mrp_text($variation_id, $svariation_id) . '</del></span> <span class="text-success">' . $Product->discount($Product->mrp($variation_id, $svariation_id), $Product->price($variation_id, $svariation_id)) . '% off</span></span>
                  </div> 
                  </a>';
    }


    public static function choose_categories($parent_id = false)
    {
        $output = '';
        $parent_id = $parent_id == false ? 0 : $parent_id;
        global $Web;
        $stmt = $Web->db()->prepare("SELECT category_id,category FROM $Web->ecommerce_category_tbl WHERE parent_id = ? AND status = 'active'  ");
        $stmt->execute([$parent_id]);
        while ($row =  $stmt->fetch()) {
            $category_id = $row->category_id;
            $C = new Category($category_id);

            if (!$C->has_or_child_content()) continue;
            if (!$C->has_products()) {
                continue;
            };
            if ($C->is_last_category()) {
                $url = $Web->base_url() . '/product/search?category=' . $category_id;
                $output .= ' <a href="' . $url . '" data-id="' . $row->category_id . '"  class="p-4 hover cursor-pointer category-list border-bottom align-justify-between">
                <div class="fs-4 d-flex fw-bold">  ' . $C->category() . '</div>
                <span class="svg-icon svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z" fill="black" />
                        </svg>
                    </span>
            </a>';
            } else {
                $output .= ' <div data-header-category="true" data-id="' . $row->category_id . '"  class="p-4 hover cursor-pointer category-list border-bottom align-justify-between">
                <div class="fs-4 d-flex fw-bold">  ' . $C->category() . '</div>
                    <span class="svg-icon svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z" fill="black" />
                        </svg>
                    </span>
            </div>';
            }
        }
        return $output;
    }
}


class Category extends Basic
{
    public $category_id;
    private $row;

    public static $max_level_allowed = 3;

    function __construct($id)
    {
        if (!self::is_category_id($id)) throw new Error($id . " is not a category");
        $this->category_id = $id;
        $this->row = $this->row();
    }

    public static function is_category_id($category_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT category_id FROM $Web->ecommerce_category_tbl WHERE category_id = ? ");
        $stmt->execute([$category_id]);
        return $stmt->rowCount() ? true : false;
    }
    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_category_tbl WHERE category_id = ? ");
        $stmt->execute([$this->category_id]);
        return $stmt->fetch();
    }

    public function category()
    {
        $row = $this->row();
        $text = $this->unsanitize_text($row->category);
        return $text;
    }

    public function parent_id()
    {
        $row = $this->row();
        $parent_id = $row->parent_id;
        return $parent_id;
    }

    public function level()
    {
        return $this->row()->level;
    }

    public function status()
    {
        $row = $this->row();
        return $row->status;
    }
    public function status_label()
    {
        switch ($this->status()) {
            case "draft":
                return $this->status_to_label($this->status(), "secondary");
                break;
            case "active":
                return $this->status_to_label($this->status(), "success");
                break;
            case "archived":
                return $this->status_to_label($this->status(), "warning");
                break;
            case "rejected":
                return $this->status_to_label($this->status(), "danger");
                break;
        }
    }
    public function is_archived()
    {
        $status = $this->status();
        return $status == "archived" ? true : false;
    }

    public function is_draft()
    {
        return $this->status() == "draft" ? true : false;
    }

    public function is_rejected()
    {
        return $this->status() == "rejected" ? true : false;
    }

    public function can_add_listing()
    {
        return $this->status() == "active" ? true : false;
    }

    public function archive_category($category_id)
    {
        try {
            $stmt = $this->db()->prepare("UPDATE $this->ecommerce_category_tbl SET status = 'archived' WHERE category_id = ?");
            $stmt->execute([$category_id]);

            $stmt = $this->db()->prepare("SELECT category_id FROM $this->ecommerce_category_tbl WHERE parent_id = ? ");
            $stmt->execute([$category_id]);

            while ($row =  $stmt->fetch()) {
                $category_id = $row->category_id;
                $this->archive_category($category_id);
            }
        } catch (Exception $e) {
            Errors::response_500("Error in archive category" . $e->getMessage());
        }
    }

    public function reject_category()
    {

        try {
            $stmt = $this->db()->prepare("UPDATE $this->ecommerce_category_tbl SET status = 'rejected' WHERE category_id = ?  ");
            $stmt->execute([$this->category_id]);

            $stmt = $this->db()->prepare("SELECT product_id FROM $this->ecommerce_products_tbl WHERE category_id = ? ");
            $stmt->execute([$this->category_id]);

            while ($row =  $stmt->fetch()) {
                $product_id = $row->product_id;
                $sub_query = $this->db()->prepare("UPDATE $this->ecommerce_variations_tbl SET status = 'rejected' WHERE product_id = ? ");
                $sub_query->execute([$product_id]);
            }

            $stmt = $this->db()->prepare("SELECT category_id FROM $this->ecommerce_category_tbl WHERE parent_id = ? ");
            $stmt->execute([$this->category_id]);

            while ($row =  $stmt->fetch()) {
                $category_id = $row->category_id;
                $Category = new Category($category_id);
                $Category->reject_category();
            }
        } catch (Exception $e) {
            Errors::response_500("Error in processing the request" . $e->getMessage());
        }
    }

    public function is_in_use()
    {
        $stmt = $this->db()->prepare("SELECT listing_id FROM $this->ecommerce_listing_tbl WHERE category_id = ? ");
        $stmt->execute([$this->category_id]);
        if ($stmt->rowCount()) return true;

        $stmt = $this->db()->prepare("SELECT category_id FROM $this->ecommerce_category_tbl WHERE parent_id = ? ");
        $stmt->execute([$this->category_id]);
        if (!$stmt->rowCount()) return false;

        while ($row =  $stmt->fetch()) {
            $category_id = $row->category_id;
            $Category = new Category($category_id);
            return $Category->is_in_use();
        }
    }

    private static function create_1st_category()
    {
        global $Web;
        try {
            $stmt = $Web->db()->query("INSERT INTO $Web->ecommerce_category_tbl (`category`, `parent_id`,`level`)
            VALUES ('Add Text','0','0') ");
            return self::all_lists();
        } catch (Exception $e) {
            Errors::response_500("Error in creating category" . $e->getMessage());
        }
    }

    public static function all_lists($param = false)
    {
        global $Web;
        $output = '';

        if ($param == "read_archived") {
            $stmt = $Web->db()->query("SELECT DISTINCT(level) FROM $Web->ecommerce_category_tbl ");
        } else {
            $stmt = $Web->db()->query("SELECT DISTINCT(level) FROM $Web->ecommerce_category_tbl WHERE status = 'active' OR status = 'draft' OR status = 'archived' ");
            if (!$stmt->rowCount()) return self::create_1st_category();
        }


        while ($row =  $stmt->fetch()) {
            $level = $row->level;
            $output .= self::createLevelAllLists($level, $param);
        }

        return $output;
    }

    private static function createLevelAllLists($level, $param)
    {
        global $Web;
        $output = '';
        $stmt = $param == "read_archived" ? $Web->db()->query("SELECT category_id FROM $Web->ecommerce_category_tbl WHERE level = '$level' ") : $Web->db()->query("SELECT category_id  FROM $Web->ecommerce_category_tbl WHERE level = '$level' AND (status = 'active' || status = 'draft' || status = 'archived' ) ");
        while ($row =  $stmt->fetch()) {
            $id = $row->category_id;
            $C = new Category($id);
            $output .= $C->category_list($param);
        }
        $class = $level == 0 ? "" : "d1-none";
        $output = '<div class="' . $class . '" data-level="' . $level . '" > <ul>' . $output . '</ul> </div>';
        return $output;
    }

    public function is_last_child()
    {
        $stmt = $this->db()->query("SELECT category_id FROM $this->ecommerce_category_tbl WHERE parent_id = '$this->category_id' ");
        if (!$stmt->rowCount()) return true;
        return false;
    }


    public function has_details()
    {
        $row = $this->row();
        $has_details = $row->has_details;
        return $has_details == "yes" ? true : false;
    }

    public function has_content()
    {
        $row = $this->row();
        $has_content = $row->has_content;
        return $has_content == "yes" ? true : false;
    }

    public function has_or_child_content()
    {
        if ($this->has_content()) return true;
        $stmt = $this->db()->query("SELECT category_id FROM $this->ecommerce_category_tbl WHERE parent_id = '$this->category_id' ");
        while ($row =  $stmt->fetch()) {
            $category_id = $row->category_id;
            $Category = new Category($category_id);
            if (!$Category->is_last_child()) {
                if ($Category->has_or_child_content()) return true;
            }
            if ($Category->has_content()) return true;
        }

        return false;
    }


    public function has_products()
    {

        if ($this->is_last_category()) {
            $stmt = $this->db()->prepare("SELECT product_id FROM $this->ecommerce_products_tbl WHERE category_id = ? ");
            $stmt->execute([$this->category_id]);
            if ($stmt->rowCount()) return true;
        } else {
            $categories_array = Basic::categories_filter_ids($this->category_id);
            $in = str_repeat("?,", count($categories_array) - 1) . "?";

            $stmt = $this->db()->prepare("SELECT product_id FROM $this->ecommerce_products_tbl WHERE category_id IN ($in) ");
            $stmt->execute($categories_array);
            if ($stmt->rowCount()) return true;
        }
        return false;
    }

    public function data()
    {
        $row = $this->row();
        $data = $row->data;
        return $data;
    }


    public function is_last_category()
    {
        $stmt = $this->db()->query("SELECT category_id FROM $this->ecommerce_category_tbl WHERE parent_id = '$this->category_id' ");
        if (!$stmt->rowCount()) return true;

        return $this->has_details();
    }

    public function can_create_child()
    {
        $level = $this->level();
        return $level < self::$max_level_allowed && $this->row()->has_details == "no" ? true : false;
    }

    public function category_list($param = false)
    {
        $class =  $this->parent_id() == 0 ? "" : "d-none";
        if ($this->is_draft()) $class .= " success";
        if ($this->has_details()) $class .= " has-details";

        $drop_child = '';

        if ($this->is_last_category()) {
            if ($this->has_details()) {
                $drop_child .= '
        <div class="menu-item px-3">
            <a id="add_details" class="menu-link px-3">Show details </a>
        </div>';
            } else {
                $drop_child .= '
        <div class="menu-item px-3">
            <a id="add_details" class="menu-link px-3">Add details </a>
        </div>';
            }
        }


        $drop_child .= $this->can_create_child() ? '
        <div class="menu-item px-3">
            <a id="create_child" class="menu-link px-3">Create child</a>
        </div>' : '';


        $drop = '';
        if ($param != "read_archived") $drop = '<div class="drop-container">
                <button type="button" class="btn btn-sm btn-icon btn-color-white btn-active-white border-0 me-n3" data-lx-menu-trigger="click" data-lx-menu-placement="bottom-end">
                    <i class="fas fa-ellipsis-v"></i>
                </button>
                <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg-light-primary fw-bold w-200px py-3" data-lx-menu="true" style="">
                    ' . $drop_child . '
                    <div class="menu-item px-3">
                        <a id="edit" class="menu-link px-3">Rename</a>
                    </div>
                    <div class="menu-item px-3">
                        <a id="create_sibling" class="menu-link px-3">Create Sibling</a>
                    </div>
                    <div class="menu-item px-3 my-1">
                        <a id="archive" class="menu-link px-3">Close Category</a>
                    </div>
                     <div class="menu-item px-3">
                        <a id="delete_listings" class="menu-link px-3">Delete Listings</a>
                    </div>
                </div>
            </div>';

        return '<li data-pid="' . $this->parent_id() . '" data-id="' . $this->category_id . '" class="' . $class . ' category-list align-justify-between">
                    <div class="w-100 text-container">
                        <span class="line-clamp line-clamp-1" >' . $this->category() . '</span>
                        <form novalidate="novalidate" class="w-100 d-none">
                            <div class="fv-row">
                                <div class="input-group">
                                    <input value="' . $this->category() . '" name="category" type="text" class="form-control form-control-solid">
                                    <button id="submit" class="btn btn-secondary input-group-text">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                ' . $drop . '
                </li>';
    }

    public function product_details_row()
    {
        $output = '';
        $stmt = $this->db()->query("SELECT * FROM $this->ecommerce_category_details_tbl WHERE category_id = '$this->category_id'  ");
        while ($row =  $stmt->fetch()) {
            $detail_id = $row->detail_id;
            $select_id = $row->select_id;

            if ($this->is_empty($select_id)) $select_heading = "";
            else {
                $Select = new Select($select_id);
                $select_heading =  ' - ' . $Select->heading();
            }

            $details = '<div class="d-flex">
        <button data-id="' . $detail_id . '" data-action="editCatDetail"  class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
            <span class="svg-icon svg-icon-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path opacity="0.3"
                        d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z"
                        fill="currentColor"></path>
                    <path
                        d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z"
                        fill="currentColor"></path>
                </svg>
            </span>
                </button>
            <button data-id="' . $detail_id . '"  data-action="deleteCatDetail" class="btn ms-2 btn-icon btn-bg-light btn-active-color-primary btn-sm">
                <span class="svg-icon svg-icon-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path
                            d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z"
                            fill="currentColor"></path>
                        <path opacity="0.5"
                            d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z"
                            fill="currentColor"></path>
                        <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z"
                            fill="currentColor"></path>
                    </svg>
                </span>
            </button>
            </div>';
            $output .= '<tr data-id="detail_' . $detail_id . '"  >
                <td class="text-capitalize" >' . $row->mandatory . '</td>
                <td>' . $row->option_text . '</td>
                <td class="text-capitalize" >' . $row->option_type . $select_heading . '</td>
                <td class="text-capitalize" >' . $row->filter . '</td>
                <td>' . $details . '</td>
            </tr>';
        }
        return $output;
    }

    private function images_card()
    {
        $images  = $this->images();
        $output = '';
        for ($i = 0; $i < 8; $i++) {
            if (isset($images[$i])) $output .= '<div  data-index="' . $i . '"  class="me-4 position-relative cursor-pointer min-w-80px justify-align-center mb-2 bg-light hover h-100px">
                                                    <div class="bottom-inherit image-upload-progress top-0">
                                                        <div class="progress-bar h-3px"></div>
                                                    </div><div data-category-image-delete="true" data-id="' . $images[$i] . '" class="delete-alt"><i class="fas fa-times"></i></div>
                                                    <img class="img-fluid mh-100" src="' . $this->get_file_src($images[$i]) . '" >
                                                </div> ';
        }
        $output .=  '<div data-index="' . $i . '" data-category-image="true" class="me-4 position-relative cursor-pointer min-w-80px justify-align-center mb-2 bg-light hover h-100px">
                                                    <span class="svg-icon svg-icon-muted svg-icon-4x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <rect opacity="0.5" x="11" y="18" width="12" height="2" rx="1" transform="rotate(-90 11 18)" fill="currentColor"></rect>
                                                            <rect x="6" y="11" width="12" height="2" rx="1" fill="currentColor"></rect>
                                                        </svg></span>
                                                </div> ';
        return $output;
    }

    public function details_card()
    {
        $library_url = $this->admin_url() . '/library';

        $output = '<div class="card card-flush mt-4">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2 class="me-3" >Images</h2>
                                            ' . $this->status_label() . '
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                      <p class="text-muted required fs-7" >Add images to describe the category (min. 4 images are required) </p>
                                        <div id="catImages" class="d-flex">
                                              ' . $this->images_card() . '
                                        </div>
                                    </div>
                                </div>

                                  <div class="card mt-4 card-flush">
                                <div class="card-header">
                                    <div class="card-title">
                                        <h2>Variation Types
                                        <i data-bs-toggle="popover" data-bs-html="true"  data-bs-content=\'Create variation type by selecting custom for single usage for multiple usage create select value in  <a target="_blank" href="' . $library_url . '" >library</a>\' class="fas fa-exclamation-circle ms-2 fs-7"></i>
                                        </h2>
                                    </div>
                                    <div class="card-toolbar">
                                        <button data-bs-toggle="modal" data-bs-target="#variationModal" id="addVariation" type="button" class="btn btn-sm btn-flex btn-light-primary">
                                            <span class="svg-icon svg-icon-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5" fill="currentColor"></rect>
                                                    <rect x="10.8891" y="17.8033" width="12" height="2" rx="1" transform="rotate(-90 10.8891 17.8033)" fill="currentColor"></rect>
                                                    <rect x="6.01041" y="10.9247" width="12" height="2" rx="1" fill="currentColor"></rect>
                                                </svg>
                                            </span>
                                            Create Variation
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body pt-0">
                                        <p class="text-muted fs-7" >Add Max. 2 types of variation i.e., Color, Size</p>
                                    <table class="table align-middle table-row-dashed fs-6 gy-5" id="var_table">
                                        <thead>
                                            <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                                <th class="min-w-100px">Name</th>
                                                <th class="min-w-100px">Type</th>
                                                <th class="min-w-100px">Role</th>
                                                <th class="min-w-100px">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody class="fw-bold text-gray-600">' . $this->variations_tbl() . '</tbody>
                                    </table>
                                </div>
                            </div>

                                <div class="card card-flush mt-4">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2>Product Details</h2>
                                        </div>
                                        <div class="card-toolbar">
                                            <button data-bs-target="#addDetailsModal" data-bs-toggle="modal" id="addDetails" type="button" class="btn btn-sm btn-flex btn-light-primary">
                                                <span class="svg-icon svg-icon-3">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5" fill="currentColor"></rect>
                                                        <rect x="10.8891" y="17.8033" width="12" height="2" rx="1" transform="rotate(-90 10.8891 17.8033)" fill="currentColor"></rect>
                                                        <rect x="6.01041" y="10.9247" width="12" height="2" rx="1" fill="currentColor"></rect>
                                                    </svg>
                                                </span>
                                                Add Details
                                            </button>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                     <p class="text-muted fs-7" >Add products details i.e., Color,Size,Type...</p>
                                        <table class="table align-middle table-row-dashed fs-6 gy-5" id="pro_details_tbl">
                                            <thead>
                                                <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                                    <th class="min-w-50px">Mandatory</th>
                                                    <th class="min-w-200px">Option Text</th>
                                                    <th class="min-w-150px">Option Type</th>
                                                    <th class="min-w-150px">Filter</th>
                                                    <th class="min-w-150px">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody class="fw-bold text-gray-600">
                                                ' . $this->product_details_row() . '
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="mt-4 justify-right" >
                                    <button id="verifyCategory" class="btn btn-primary" >Apply For Listing</button>
                                </div>
                                ';
        return $output;
    }

    public static function is_a_detail_id($detail_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT detail_id FROM $Web->ecommerce_category_details_tbl WHERE detail_id = ? ");
        $stmt->execute([$detail_id]);
        return $stmt->rowCount() ? true : false;
    }
    public function is_detail_id($detail_id)
    {
        $stmt = $this->db()->prepare("SELECT detail_id FROM $this->ecommerce_category_details_tbl WHERE category_id = ? AND detail_id = ? ");
        $stmt->execute([$this->category_id, $detail_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function detail_row($detail_id)
    {
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_category_details_tbl WHERE category_id = ? AND detail_id = ? ");
        $stmt->execute([$this->category_id, $detail_id]);
        return  $stmt->fetch();
    }


    public function detail_mandatory($detail_id)
    {
        $row = $this->detail_row($detail_id);
        return $row->mandatory == "yes" ? true : false;
    }

    public function detail_text($detail_id)
    {
        $row = $this->detail_row($detail_id);
        return $this->unsanitize_text($row->option_text);
    }

    public function detail_filter($detail_id)
    {
        $row = $this->detail_row($detail_id);
        if (!isset($row->filter)) {
            // echo $detail_id;
            // exit();
        }
        return $row->filter ?? '';
    }

    public function images()
    {
        $row = $this->row();
        $images = $row->images ?? '{}';
        $images = json_decode($images, true);
        return $images;
    }

    public function variations()
    {
        $row = $this->row();
        $variations = $row->variations ?? '{}';
        $variations = json_decode($variations, true);
        $variations =  empty($variations) ? [] : $variations;
        foreach ($variations as $key => $value) {
            if ($value["select_id"] == "custom") {
                $variations[$key]["select_id"] = $value["custom_select_id"];
            }
        }
        return $variations;
    }

    public function variations_tbl()
    {
        $variations = $this->variations();
        $output = '';
        foreach ($variations as $Key => $variation) {
            $details = '<div class="d-flex">
                        <button data-id="' . $Key . '" data-action="editCategoryVariation" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                            <span class="svg-icon svg-icon-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3"
                                        d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z"
                                        fill="currentColor"></path>
                                    <path
                                        d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z"
                                        fill="currentColor"></path>
                                </svg>
                            </span>
                        </button>
                        <button data-id="' . $Key . '" data-action="deleteCategoryVariation" class="ms-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                            <span class="svg-icon svg-icon-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path
                                        d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z"
                                        fill="currentColor"></path>
                                    <path opacity="0.5"
                                        d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z"
                                        fill="currentColor"></path>
                                    <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z"
                                        fill="currentColor"></path>
                                </svg>
                            </span>
                        </button>
                    </div>';

            if ($variation["type"] == "select") {
                $select_id = $variation["select_id"];
                $select_id = $select_id == "custom" ? $variation["custom_select_id"] : $select_id;
                $Select = new Select($select_id);
                $select_heading = " - " . $Select->heading();
            } else {
                $select_heading  = "";
            }

            if ($variation["role"] == "primary") $variation["role"] = "Parent";
            if ($variation["role"] == "secondary") $variation["role"] = "Child";

            $output .= '<tr data-id="' . $Key . '" >
                <td class="text-capitalize" >' . $variation["name"] . '</td>
                <td class="text-capitalize" >' . $variation["type"] . $select_heading . '</td>
                <td class="text-capitalize" >' . $variation["role"] . '</td>
                <td>' . $details . '</td>
            </tr>';;
        }
        return $output;
    }

    public function has_variation()
    {
        return  $this->header_variation_data("has_parent");
    }
    public function has_svariation()
    {
        return  $this->header_variation_data("has_child");
    }

    public function header_variation_data($param)
    {
        $variations = $this->variations();

        if (empty($variations)) return false;

        $role_columns = array_column($variations, "role");
        $keys = array_keys($variations);

        $parent_array_index = $keys[0];
        $child_array_index = $keys[0];
        if (count($variations) === 2) {
            $parent_array_index = $role_columns[0] == "parent" ? $keys[0] : $keys[1];
            $child_array_index = $role_columns[1] == "child" ? $keys[1] : $keys[0];
        }

        switch ($param) {
            case "has_parent":
                if (in_array("parent", $role_columns)) return true;
                break;

            case "has_child":
                if (in_array("child", $role_columns)) return true;
                break;

            case "parent_header_text":
                return $variations[$parent_array_index]["name"];
                break;

            case "child_header_text":
                return $variations[$child_array_index]["name"];
                break;

            case "parent_type":
                return $variations[$parent_array_index]["type"];
                break;

            case "child_type":
                return  $variations[$child_array_index]["type"];
                break;

            case "parent_select_id":

                return  $variations[$parent_array_index]["select_id"];
                break;

            case "child_select_id":
                return  $variations[$child_array_index]["select_id"];
                break;

            case "parent_detail_id":

                return $variations[$parent_array_index]["detail_id"];
                break;

            case "child_detail_id":
                return  $variations[$child_array_index]["detail_id"];
                break;
        }
    }

    public function breadcrumb($text, $url = true)
    {
        $str = '';

        $parent_id = $this->parent_id();
        $output = '';

        $bread_crumbs = [$this->category_id];
        while ($parent_id != 0) {
            $bread_crumbs[] = $parent_id;
            $parent_id =  (new Category($parent_id))->parent_id();
        }

        $bread_crumbs = array_reverse($bread_crumbs);

        foreach ($bread_crumbs as $category_id) {
            $C = new Category($category_id);
            $category = $C->category();
            $href = $url ? 'href="' . $this->base_url() . '/product/search?category=' . $category_id . '"' : "";
            $str .= ' <li class="breadcrumb-item"><a ' . $href . ' class="text-primary-alt">' . $category . '</a></li>';
        }

        $output = '<ol class="breadcrumb breadcrumb-arrow py-2 text-muted fs-8 fw-bold">
                                ' . $str . '
                       <li class="breadcrumb-item text-muted">' . $text . '</li>
                    </ol>';
        return $output;
    }
}

class Select extends Basic
{

    public $select_id;
    private $row;

    function __construct($select_id)
    {
        if (!self::is_select_id($select_id)) Errors::response("$select_id is not a valid select id");
        $this->select_id = $select_id;
        $this->row = $this->row();
    }

    public static function is_select_id($select_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT select_id FROM $Web->ecommerce_select_tbl WHERE select_id = ? ");
        $stmt->execute([$select_id]);
        return $stmt->rowCount() ? true : false;
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_select_tbl WHERE select_id = ? ");
        $stmt->execute([$this->select_id]);
        return  $stmt->fetch();
    }

    public static function is_heading($select_heading)
    {
        $Web = $GLOBALS["Web"];
        $stmt = $Web->db()->prepare("SELECT select_heading FROM $Web->ecommerce_select_tbl WHERE select_heading = ? ");
        $stmt->execute([$select_heading]);
        return $stmt->rowCount() ? true : false;
    }

    public function heading()
    {
        $row = $this->row();
        $select_heading = $row->select_heading;
        if ($this->is_temp()) return "Custom";
        return $this->unsanitize_text($select_heading);
    }

    public function date_created()
    {
        $row = $this->row();
        $date_created = $row->date_created;
        return $this->date_time($date_created);
    }

    public function last_modified()
    {
        $row = $this->row();
        $last_modified = $row->last_modified;
        return $this->date_time($last_modified);
    }

    public function select_edit_detail()
    {
        $output = '';
        $options = $this->options();
        foreach ($options as $option) {
            $output .= ' <div data-repeater-item="" class="form-group d-flex flex-wrap gap-5">
                                                <input required value="' . $option . '" type="text" class="data-heading form-control mw-100 w-300px" placeholder="Value" />
                                                <button type="button" data-repeater-delete="" class="btn btn-sm btn-icon btn-light-danger">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </div>';
        }
        return $output;
    }

    public function select_edit_modal_form()
    {
        return '<form novalidate>

                            <div class="fv-row mb-7">
                                <label class="required fs-6 fw-bold form-label mb-2">Select Id</label>
                                <input required  type="text" class="form-control form-control-solid" name="select_heading" value="' . $this->heading() . '">
                            </div>

                            <div>
                                <label class="form-label">Add Select Options</label>
                                <div id="repeater">
                                    <div class="form-group">
                                        <div data-repeater-list="repeater" class="d-flex flex-column gap-3">
                                            <div data-repeater-item="" class="form-group d-flex flex-wrap gap-5">
                                                <input required type="text" class="data-heading form-control mw-100 w-300px" placeholder="Value" />
                                                <button type="button" data-repeater-delete="" class="btn btn-sm btn-icon btn-light-danger">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </div>
                                            ' . $this->select_edit_detail() . '
                                        </div>
                                    </div>
                                    <div class="form-group mt-5">
                                        <button type="button" data-repeater-create="" class="btn btn-sm btn-light-primary">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>';
    }

    public function is_valid_option($val)
    {
        $options = $this->options();
        if (!is_array($options)) return false;
        return in_array($val, $options) ? true : false;
    }

    public function options()
    {
        $row = $this->row();
        $options = $row->options;
        $options = json_decode($options);
        return $options;
    }

    public function select_preview($attr = false)
    {
        $options = $this->options();
        if (!is_array($options)) return;
        $output = '';
        foreach ($options as $option) {
            $output .= '<option value="' . $option . '">' . $option . '</option>';
        }
        $attr = $attr == false ? '' : $attr;
        return '
        <select ' . $attr . '  data-placeholder="Select" class="form-select form-select-solid" data-name="' . $this->select_id . '" data-control="select2"  >
        <option></option>
        ' . $output . '
        </select>';
    }

    public static function selects_tbl()
    {
        global $Web;
        $output = '';
        $stmt = $Web->db()->query("SELECT * FROM $Web->ecommerce_select_tbl WHERE is_temp = 'no' ORDER BY select_heading ASC ");
        $count = 1;
        if (!$stmt->rowCount()) return '<tr><td class="text-center" colspan="6" >No data available in the table</td></tr>';
        while ($row =  $stmt->fetch()) {
            $select_id = $row->select_id;
            $Select = new Select($select_id);
            $preview = $Select->select_preview();
            $details = '<div class="d-flex">
                    <button data-id="' . $select_id . '" data-action="edit" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                        <span class="svg-icon svg-icon-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3"
                                    d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z"
                                    fill="currentColor"></path>
                                <path
                                    d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z"
                                    fill="currentColor"></path>
                            </svg>
                        </span>
                    </button>
                    <button data-id="' . $select_id . '" data-action="delete" class="ms-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                        <span class="svg-icon svg-icon-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path
                                    d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z"
                                    fill="currentColor"></path>
                                <path opacity="0.5"
                                    d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z"
                                    fill="currentColor"></path>
                                <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z"
                                    fill="currentColor"></path>
                            </svg>
                        </span>
                    </button>
                </div>';
            $output .= '<tr>
                                <td class="text-capitalize" >' . $count++ . '</td>
                                <td class="text-capitalize" >' . $Select->heading() . '</td>
                                <td class="text-capitalize" >' . $preview . '</td>
                                <td class="text-capitalize" >' . $Select->date_created() . '</td>
                                <td class="text-capitalize" >' . $Select->last_modified() . '</td>
                                <td>' . $details . '</td>
                            </tr>';
        }
        return $output;
    }

    public static function create_temporary_select($options)
    {
        global $Web;
        $options = json_encode($options);
        try {
            $stmt = $Web->db()->prepare("INSERT INTO $Web->ecommerce_select_tbl (`select_heading`, `options`,`is_temp`) VALUES (NULL,?,'yes') ");
            $stmt->execute([$options]);
            return $Web->db()->lastInsertId();
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    public function is_in_use()
    {
        $stmt = $this->db()->prepare("SELECT select_id FROM $this->ecommerce_category_details_tbl WHERE select_id = ? ");
        $stmt->execute([$this->select_id]);
        if ($stmt->rowCount()) return true;

        $stmt = $this->db()->prepare("SELECT variations FROM $this->ecommerce_category_tbl WHERE JSON_EXTRACT (variations,'$[1].select_id') = ? OR JSON_EXTRACT (variations,'$[2].select_id') = ? ");
        $stmt->execute([$this->select_id, $this->select_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function is_temp()
    {
        $row = $this->row();
        $temp = $row->is_temp;
        return $temp == "yes" ? true : false;
    }
}

class Listing extends Basic
{
    public $listing_id;
    private $row;

    function __construct($id)
    {
        if (!self::is_listing_id($id)) throw new Error("$id is not a valid Listing Id");
        $this->listing_id = $id;
        $this->row = $this->row();
    }


    public function is_variation_id($variation_id)
    {
        $stmt = $this->db()->prepare("SELECT variation_id FROM $this->ecommerce_listing_variations_tbl WHERE variation_id = ? AND listing_id = ? ");
        $stmt->execute([$variation_id, $this->listing_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function is_svariation_id($variation_id, $svariation_id)
    {
        $stmt = $this->db()->prepare("SELECT variation_id FROM $this->ecommerce_listing_variations_tbl WHERE variation_id = ? AND svariation_id = ? AND listing_id = ? ");
        $stmt->execute([$variation_id, $svariation_id, $this->listing_id]);
        return $stmt->rowCount() ? true : false;
    }


    public function create_variation_id()
    {
        $variation_id = rand(10000000000, 99999999999);
        $variation_id = \uniqid($variation_id);
        return $this->is_variation_id($variation_id) ? $this->create_variation_id() : $variation_id;
    }

    public function create_svariation_id($variation_id)
    {
        $svariation_id = rand(10000000000, 99999999999);
        $svariation_id = \uniqid($svariation_id);
        return $this->is_svariation_id($variation_id, $svariation_id) ? $this->create_svariation_id($variation_id) : $svariation_id;
    }

    public static function choose_categories($parent_id = false)
    {
        $output = '';
        $parent_id = $parent_id == false ? 0 : $parent_id;
        global $Web;
        $stmt = $Web->db()->prepare("SELECT category_id,category FROM $Web->ecommerce_category_tbl WHERE parent_id = ? AND status = 'active'  ");
        $stmt->execute([$parent_id]);
        while ($row =  $stmt->fetch()) {
            $category_id = $row->category_id;
            $C = new Category($category_id);

            if (!$C->has_or_child_content()) continue;

            $next = $C->is_last_category() ? '<button class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                <span class="svg-icon svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M9.89557 13.4982L7.79487 11.2651C7.26967 10.7068 6.38251 10.7068 5.85731 11.2651C5.37559 11.7772 5.37559 12.5757 5.85731 13.0878L9.74989 17.2257C10.1448 17.6455 10.8118 17.6455 11.2066 17.2257L18.1427 9.85252C18.6244 9.34044 18.6244 8.54191 18.1427 8.02984C17.6175 7.47154 16.7303 7.47154 16.2051 8.02984L11.061 13.4982C10.7451 13.834 10.2115 13.834 9.89557 13.4982Z" fill="black"/>
                                </svg></span>
                            </button>' : '  <div class="next"><span class="svg-icon svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z" fill="black" />
                        </svg>
                        </span>
                        </div>';
            $action = $C->is_last_category() ? "create" : "next";
            $hover = $C->is_last_category() ? "" : "hover cursor-pointer ";
            $fav = '<div class="rating">
            <div class="rating-label me-4 checked">
                <i class="bi bi-star fs-1"></i>
            </div></div>';

            $output .= ' <div data-id="' . $row->category_id . '"  class="p-4 ' . $action . '  category-list ' . $hover . ' border-bottom align-justify-between">
                            <div class="fs-4 d-flex fw-bold"> ' . $fav . ' ' . $C->category() . '</div>
                         ' . $next . '
                        </div>';
        }
        return $output;
    }

    public static function choose_categories_breadcrum($id)
    {
        $Cat = new Category($id);
        $parent_id = $Cat->parent_id();
        $output = '';

        $bread_crumbs = [];
        while ($parent_id != 0) {
            $bread_crumbs[] = $parent_id;
            $parent_id =  (new Category($parent_id))->parent_id();
        }

        $bread_crumbs = array_reverse($bread_crumbs);

        foreach ($bread_crumbs as $category_id) {
            $C = new Category($category_id);
            $category = $C->category();
            $output .= '<li data-id="' . $category_id . '" class="breadcrumb-item category-list next pe-3"><a class="cursor-pointer pe-3">' . $category . '</a></li>            ';
        }

        $category = $Cat->category();
        $output .= '<li class="breadcrumb-item pe-3"><a class="text-original pe-3">' . $category . '</a></li>';
        $output = '<ol class="breadcrumb fw-bold">' . $output . '</ol>';
        $output .= '<div class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm " ><span data-id="0" class="category-list next svg-icon svg-icon-muted svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
        <rect opacity="0.5" x="7.05025" y="15.5356" width="12" height="2" rx="1" transform="rotate(-45 7.05025 15.5356)" fill="black"/>
        <rect x="8.46447" y="7.05029" width="12" height="2" rx="1" transform="rotate(45 8.46447 7.05029)" fill="black"/>
        </svg></span></div>';

        return $output;
    }

    public static function is_listing_id($id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT listing_id FROM $Web->ecommerce_listing_tbl WHERE listing_id = ? ");
        $stmt->execute([$id]);
        return $stmt->rowCount() ? true : false;
    }

    public function url($variation_id = false)
    {
        if ($variation_id == false) {
            $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_listing_variations_tbl WHERE listing_id = ? ");
            $stmt->execute([$this->listing_id]);
        } else {
            $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_listing_variations_tbl WHERE listing_id = ? AND variation_id = ? ");
            $stmt->execute([$this->listing_id, $variation_id]);
            if (!$stmt->rowCount()) return $this->url();
        }

        if (!$stmt->rowCount()) return $this->seller_url() . '/listings/';
        $row =  $stmt->fetch();
        $variation_id = $row->variation_id;
        $svariation_id = $row->svariation_id;

        return $this->vurl($variation_id, $svariation_id);
    }

    public function can_add_variation()
    {
        $Category = new Category($this->category_id());
        if ($Category->is_archived() || $Category->is_rejected()) return false;
        return true;
    }

    public function can_update_variation()
    {
        $Category = new Category($this->category_id());
        if ($Category->is_rejected()) return false;
        return true;
    }

    public function vurl($variation_id, $svariation_id)
    {
        return  $this->seller_url() . '/create-listing/listing&lid=' . $this->listing_id . '&vid=' . $variation_id . '&sid=' . $svariation_id;
    }

    public function analytics_url($variation_id, $svariation_id)
    {
        return  $this->seller_url() . '/create-listing/listing&lid=' . $this->listing_id . '&vid=' . $variation_id . '&sid=' . $svariation_id . '&src=analytics';
    }

    public function earnings_url($variation_id, $svariation_id)
    {
        return  $this->seller_url() . '/create-listing/listing&lid=' . $this->listing_id . '&vid=' . $variation_id . '&sid=' . $svariation_id . '&src=earnings';
    }

    public function product_url($variation_id, $svariation_id)
    {
        $Listing = new Listing($this->listing_id);
        if (!$Listing->is_listing_live()) return;
        $product_id = $Listing->live_product_id();
        return (new Product($product_id))->url($variation_id, $svariation_id);
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_listing_tbl WHERE listing_id = ? ");
        $stmt->execute([$this->listing_id]);
        return  $stmt->fetch();
    }

    public function vrow($variation_id, $svariation_id)
    {
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_listing_variations_tbl WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? ");
        $stmt->execute([$this->listing_id, $variation_id, $svariation_id]);
        return $stmt->fetch();
    }

    public function variation_value($variation_id, $svariation_id)
    {
        $vrow = $this->vrow($variation_id, $svariation_id);
        return $vrow->variation_value;
    }
    public function variation_data($variation_id, $svariation_id)
    {
        $vrow = $this->vrow($variation_id, $svariation_id);
        return $vrow->variation_data;
    }

    public function svariation_value($variation_id, $svariation_id)
    {
        $vrow = $this->vrow($variation_id, $svariation_id);
        return $vrow->svariation_value;
    }

    public function date_created($variation_id, $svariation_id)
    {
        $vrow = $this->vrow($variation_id, $svariation_id);
        $date = $vrow->date_created;
        return $this->to_date($date);
    }

    public function tags($variation_id, $svariation_id)
    {
        $tags = $this->vrow($variation_id, $svariation_id)->tags;
        return $tags;
    }

    public function category()
    {
        $category_id = $this->category_id();
        return new Category($category_id);
    }

    public function is_variation_real($variation_id, $svariation_id)
    {
        $variation_data = $this->variation_data($variation_id, $svariation_id);
        return $this->is_empty($variation_data) ? false : true;
    }

    public function is_svariation_real($variation_id, $svariation_id)
    {
        $variation_value = $this->svariation_value($variation_id, $svariation_id);
        return $this->is_empty($variation_value) ? false : true;
    }

    public function mrp($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->mrp;
    }

    public function stock($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->stock;
    }

    public function low_stock_warning($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->low_stock_warning;
    }

    public function price($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->price;
    }

    public function minimum_order($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->minimum_order;
    }

    public function product_name($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $this->unsanitize_text($row->product_name);
    }

    public function maximum_order($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->maximum_order;
    }

    public function cod_status($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->cod_status;
    }

    public function return_policy($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->return_policy;
    }
    public function return_policy_days($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->return_policy_days;
    }
    public function return_policy_tc($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $this->unsanitize_text($row->return_policy_tc);
    }
    public function status($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->status;
    }

    public function sku_id($variation_id, $svariation_id)
    {
        $srow = $this->vrow($variation_id, $svariation_id);
        return $srow->sku_id;
    }

    public function description($variation_id, $svariation_id)
    {
        $srow = $this->vrow($variation_id, $svariation_id);
        $description = $srow->description;
        return $this->unsanitize_text($description);
    }

    public function highlights($variation_id, $svariation_id)
    {
        $srow = $this->vrow($variation_id, $svariation_id);
        $highlights = $srow->highlights ?? '{}';
        return json_decode($highlights);
    }

    public function create_highlights($variation_id, $svariation_id)
    {
        $output = '';
        $highlights = $this->highlights($variation_id, $svariation_id);
        if (!is_array($highlights)) return;
        foreach ($highlights as $text) {
            $text = $this->unsanitize_text($text);
            $output .= ' <div data-repeater-item="" class="form-group align-center gap-5">
                                                            <input  maxlength="500" value="' . $text . '" name="highlights[]" type="text" class="form-control form-control-solid flex-grow-1 ">
                                                            <button type="button" data-repeater-delete="" class="btn btn-sm btn-icon btn-light-danger">
                                                                <i class="fas fa-times"></i>
                                                            </button>
                                                        </div>';
        }
        return $output;
    }

    public function is_draft($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->is_draft == "yes" ? true : false;
    }

    public function category_id()
    {
        $row = $this->row();
        return $row->category_id;
    }
    public function seller()
    {
        $row = $this->row();
        $user_id = $row->user_id;
        return new Seller($user_id);
    }

    public function variation_image($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        $variation_data = $row->variation_data ?? '{}';
        $variation_data = json_decode($variation_data);
        $img_id = $variation_data->id;
        return $this->get_file_src($img_id);
    }

    public function svariation_image($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        $variation_data = $row->svariation_data;
        if (empty($variation_data)) return false;
        $variation_data = json_decode($variation_data);
        $img_id = $variation_data->id;
        return $this->get_file_src($img_id);
    }

    public function variation_type($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        $variation_data = $row->variation_data ?? '{}';
        $variation_data = json_decode($variation_data);
        return $variation_data->type ?? '';
    }

    public function svariation_type($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        $svariation_data = $row->svariation_data ?? '{}';
        $svariation_data = json_decode($svariation_data);
        return $svariation_data->type ?? '';
    }

    public function st_svariation($variation_id)
    {
        $stmt = $this->db()->prepare("SELECT svariation_id FROM $this->ecommerce_listing_variations_tbl WHERE listing_id = ? AND variation_id = ? ORDER BY date_created ASC LIMIT 1 ");
        $stmt->execute([$this->listing_id, $variation_id]);
        return  $stmt->fetch()->svariation_id;
    }

    public function variations_card($active_variation_id)
    {
        $output = '';
        $stmt = $this->db()->prepare("SELECT DISTINCT(variation_id) FROM $this->ecommerce_listing_variations_tbl WHERE listing_id = ? ORDER BY date_created ASC ");
        $stmt->execute([$this->listing_id]);

        while ($row =  $stmt->fetch()) {
            $variation_id = $row->variation_id;
            $svariation_id = $this->st_svariation($variation_id);

            $class = $variation_id === $active_variation_id ? " border primary-active " : "";
            $variation_type = $this->variation_type($variation_id, $svariation_id);
            switch ($variation_type) {
                case "input":
                case "select":
                    $output .= '<a data-replace="true" href="' . $this->vurl($variation_id, $svariation_id) . '" class="' . $class . ' text-primary-alt  py-3 px-6 border active position-relative cursor-pointer justify-align-center mb-2 bg-light hover">
                                        <div>' . $this->variation_value($variation_id, $svariation_id) . '</div>          
                                </a>';
                    break;

                case "image":
                    $output .= '<a data-replace="true" href="' . $this->vurl($variation_id, $svariation_id) . '" class="' . $class . ' active position-relative cursor-pointer w-80px rounded-1 justify-align-center mb-2 bg-light hover h-100px">
                                                <img class="img-fluid mh-100" src="' . $this->variation_image($variation_id, $svariation_id) . '" >
                                            </a>';
                    break;
            }
        }
        return $output;
    }

    public function svariations_card($active_variation_id, $active_svariation_id)
    {
        $output = '';
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_listing_variations_tbl WHERE listing_id = ? AND variation_id = ? ");
        $stmt->execute([$this->listing_id, $active_variation_id]);

        while ($row =  $stmt->fetch()) {
            $variation_id = $row->variation_id;
            $svariation_id = $row->svariation_id;
            if (!$this->is_empty($this->svariation_value($variation_id, $svariation_id))) {
                $class = $svariation_id === $active_svariation_id ? " border primary-active " : "";

                $svariation_type = $this->svariation_type($variation_id, $svariation_id);
                switch ($svariation_type) {
                    case "input":
                    case "select":
                        $output .= '<a data-replace="true" href="' . $this->vurl($variation_id, $svariation_id) . '" class="' . $class . ' text-primary-alt  py-3 px-6 border active position-relative cursor-pointer justify-align-center mb-2 bg-light hover">
                                        <div>' . $this->svariation_value($variation_id, $svariation_id) . '</div>          
                                </a>';
                        break;

                    case "image":
                        $output .= '<a data-replace="true" href="' . $this->vurl($variation_id, $svariation_id) . '" class="' . $class . ' active position-relative cursor-pointer w-80px rounded-1 justify-align-center mb-2 bg-light hover h-100px">
                                                <img class="img-fluid mh-100" src="' . $this->svariation_image($variation_id, $svariation_id) . '" >
                                            </a>';
                        break;
                }
            }
        }
        return $output;
    }

    public function is_sku_id($variation_id, $svariation_id, $sku_id)
    {
        $stmt = $this->db()->prepare("SELECT sku_id FROM $this->ecommerce_listing_variations_tbl WHERE  sku_id = ? AND listing_id = ? AND svariation_id != ? ");
        $stmt->execute([$sku_id, $this->listing_id, $svariation_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function images($variation_id, $svariation_id)
    {
        $vrow = $this->vrow($variation_id, $svariation_id);
        $images = $vrow->images ?? '{}';
        $images = json_decode($images, true);
        return $images;
    }

    public function details($variation_id, $svariation_id)
    {
        $row = $this->Vrow($variation_id, $svariation_id);
        $details = $row->details ?? '{}';
        $details = json_decode($details, true);
        return $details;
    }

    private function create_input_preview($detail_id, $attr)
    {
        $E = new Category($this->category_id());
        $row = $E->detail_row($detail_id);
        $option_type = $row->option_type;
        if ($option_type == "input")  return '<input maxlength="200" ' . $attr . ' type="text" class="form-control form-control-solid" >';
        $select_id = $row->select_id;
        $Select = new Select($select_id);
        return $Select->select_preview($attr);
    }

    private function get_product_detail_value($detail_id, $variation_id, $svariation_id)
    {
        $details = $this->details($variation_id, $svariation_id);
        $val = $details[$detail_id] ?? "";
        return $val;
    }

    public function product_details_id_keys()
    {
        $category_id = $this->category_id();
        $output = [];
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_category_details_tbl WHERE category_id = ? ");
        $stmt->execute([$category_id]);

        while ($row =  $stmt->fetch()) {
            $output[] = $row->detail_id;
        }
        return $output;
    }

    public function product_details_form($variation_id, $svariation_id)
    {
        $category_id = $this->category_id();
        $output = '';
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_category_details_tbl WHERE category_id = ? ");
        $stmt->execute([$category_id]);

        while ($row =  $stmt->fetch()) {
            $detail_id = $row->detail_id;
            $mandatory = $row->mandatory == "yes" ? "required" : "";
            $value = $this->get_product_detail_value($detail_id, $variation_id, $svariation_id);
            $attr = $mandatory . ' value="' . $value . '"  data-detail-id="' . $row->detail_id . '" ';

            $input = $this->create_input_preview($detail_id, $attr);
            $output .= '<div class="fv-row mb-7">
                   <label class="' . $mandatory . ' fs-6 fw-bold form-label mb-2">' . $row->option_text . '</label>
                   ' . $input . '
                   </div>';
        }
        return $output;
    }

    public function select_preview($select_id, $attr, $used_options)
    {
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_select_tbl WHERE select_id = ? ");
        $stmt->execute([$select_id]);

        $row =  $stmt->fetch();
        $options = $row->options;
        $options = json_decode($options);
        if (!is_array($options)) return;
        $output = '';
        foreach ($options as $option) {
            $dis = in_array($option, $used_options) ? "disabled" : "";
            $output .= '<option ' . $dis . ' value="' . $option . '">' . $option . '</option>';
        }
        return '
        <select ' . $attr . '  data-placeholder="Select" class="form-select form-select-solid" data-name="' . $select_id . '" data-control="select2"  >
        <option></option>
        ' . $output . '
        </select>';
    }

    public function used_variation_options()
    {
        $output = [];
        $stmt = $this->db()->prepare("SELECT variation_value FROM $this->ecommerce_listing_variations_tbl WHERE listing_id = ? ");
        $stmt->execute([$this->listing_id]);

        while ($row =  $stmt->fetch()) {
            $output[] = $row->variation_value;
        }
        return $output;
    }

    public function used_svariation_options($variation_id)
    {
        $output = [];
        $stmt = $this->db()->prepare("SELECT svariation_value FROM $this->ecommerce_listing_variations_tbl WHERE variation_id = ? AND listing_id = ? ");
        $stmt->execute([$variation_id, $this->listing_id]);
        while ($row =  $stmt->fetch()) {
            $output[] = $row->svariation_value;
        }
        return $output;
    }

    public function get_category_variation_data($param, $variation_id = false)
    {
        $category_id = $this->category_id();
        $C = new Category($category_id);
        $variations = $C->variations();

        if (empty($variations)) return false;
        $keys = array_keys($variations);

        $role_columns = array_column($variations, "role");
        $parent_array_index = $keys[0];
        $child_array_index = $keys[0];
        if (count($variations) === 2) {
            $parent_array_index = $role_columns[0] == "parent" ? $keys[0] : $keys[1];
            $child_array_index = $role_columns[1] == "child" ? $keys[1] : $keys[0];
        }

        switch ($param) {
            case "parent_input_preview":

                $select_id = $variations[$parent_array_index]["select_id"];
                $type = $variations[$parent_array_index]["type"];
                if ($select_id == "custom") $select_id = $variations[$parent_array_index]["custom_select_id"];

                $attr = ' name="variation_value" required';
                if ($type == "input") return '<input ' . $attr . ' type="text" class="form-control form-control-solid" >';
                else if ($type == "select") return $this->select_preview($select_id, $attr, $this->used_variation_options());
                else return '<div>
                        <input id="variationChoose" class="sr-only" accept=".png, .jpg, .jpeg"  type="file" name="images">
                        <div id="createVariation" class="active position-relative cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">
                            <div class="bottom-inherit image-upload-progress top-0">
                                <div class="progress-bar h-3px"></div>
                            </div>
                            <span class="svg-icon svg-icon-muted svg-icon-4x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="11" y="18" width="12" height="2" rx="1" transform="rotate(-90 11 18)" fill="currentColor" />
                                    <rect x="6" y="11" width="12" height="2" rx="1" fill="currentColor" />
                                </svg>
                            </span>
                        </div>
                    </div>';

                break;

            case "child_input_preview":
                $select_id = $variations[$child_array_index]["select_id"];
                $type = $variations[$child_array_index]["type"];
                $attr = ' name="svariation_value" required';
                if ($type == "input") return '<input ' . $attr . ' type="text" class="form-control form-control-solid" >';
                else if ($type == "select")  return $this->select_preview($select_id, $attr, $this->used_svariation_options($variation_id));
                else return '<div>
                <input id="variationChoose" class="sr-only" accept=".png, .jpg, .jpeg"  type="file" name="images">
                <div id="createVariation" class="active position-relative cursor-pointer w-80px justify-align-center mb-2 bg-light hover h-100px">
                    <div class="bottom-inherit image-upload-progress top-0">
                        <div class="progress-bar h-3px"></div>
                    </div>
                    <span class="svg-icon svg-icon-muted svg-icon-4x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="11" y="18" width="12" height="2" rx="1" transform="rotate(-90 11 18)" fill="currentColor" />
                            <rect x="6" y="11" width="12" height="2" rx="1" fill="currentColor" />
                        </svg>
                    </span>
                </div>
            </div>';
                break;

            default:
                return $C->header_variation_data($param);
                break;
        }
    }

    public function variation_header_text()
    {
        $parent_header_text = $this->get_category_variation_data("parent_header_text");
        return $parent_header_text;
    }

    public function variation_information_id()
    {
        $parent_information_id = $this->get_category_variation_data("parent_detail_id");
        return $parent_information_id;
    }

    public function svariation_information_id()
    {
        $parent_information_id = $this->get_category_variation_data("child_detail_id");
        return $parent_information_id;
    }

    public function variation_input($param = false)
    {
        if ($param == "type") return $this->get_category_variation_data("parent_type");
        if ($param == "select") return $this->get_category_variation_data("parent_select_id");
        return $this->get_category_variation_data("parent_input_preview");
    }


    public function svariation_input($variation_id, $param = false)
    {
        if ($param == "type") return $this->get_category_variation_data("child_type");
        if ($param == "select") return $this->get_category_variation_data("child_select_id");
        return $this->get_category_variation_data("child_input_preview", $variation_id);
    }

    public function svariation_header_text()
    {
        $child_header_text = $this->get_category_variation_data("child_header_text");
        return $child_header_text;
    }

    public function can_send_variation_to_qc($variation_id)
    {
        if (!$this->can_add_variation()) return false;
        $svariations = $this->svariations_key($variation_id);
        foreach ($svariations as $svariation_id) {
            if (!$this->is_svariation_live($variation_id, $svariation_id) && !$this->is_svariation_in_qc($variation_id, $svariation_id)) return true;
        }
        return false;
    }


    public function toolbar($variation_id, $svariation_id)
    {
        $toolbar = '';

        if ($this->is_variation_real($variation_id, $svariation_id) && $this->category()->has_variation() && $this->can_add_variation()) {
            $toolbar .= '<div class="menu-item px-3">
                                <a id="clone_variation" class="menu-link px-3">Clone</a>
                         </div>';
        }

        if ($this->is_variation_live($variation_id) && $this->can_add_variation()) {
            $product_id = $this->live_product_id();
            $Product = new Product($product_id);
            $arch_text = $Product->status($variation_id, $this->is_variation_live($variation_id)) == "archived" ? "Unarchive" : "Archieve";
            $toolbar .= '<div class="menu-item px-3">
                                                <a id="archive_variation" class="menu-link px-3">' . $arch_text . '</a>
                                            </div>';
        }

        if (!$this->is_variation_live($variation_id)) {
            $toolbar .= '<div class="menu-item px-3">
                                 <a id="delete_variation" class="menu-link px-3">Delete</a>
                        </div>';
        }

        if ($this->can_send_variation_to_qc($variation_id)) {
            $toolbar .= ' <div class="menu-item px-3">
                                     <a id="sendToQc" class="menu-link flex-stack px-3">Send to Qc</a>
                              </div>';
        }

        if ($this->is_svariation_live($variation_id, $svariation_id)) {
            $product_id = $this->live_product_id();
            $Product = new Product($product_id);
            $toolbar .= '<div class="menu-item px-3">
                                   <a target="_blank" href="' . $Product->url($variation_id, $svariation_id) . '"  class="menu-link flex-stack px-3">View on ' . $this->web_name() . '</a>
                         </div>';
        }

        return ' <button type="button" class="btn btn-sm btn-icon btn-color-primary btn-active-light-primary" data-lx-menu-trigger="click" data-lx-menu-placement="bottom-end"><i class="fas fa-ellipsis-v"></i></button>
                   <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg-light-primary fw-bold w-200px py-3" data-lx-menu="true" style="">
                  ' . $toolbar . '
                  </div>';
    }

    public function svariations_key($variation_id)
    {
        $output = [];
        $stmt = $this->db()->prepare("SELECT svariation_id FROM $this->ecommerce_listing_variations_tbl WHERE listing_id = ? AND variation_id = ? ");
        $stmt->execute([$this->listing_id, $variation_id]);

        while ($row =  $stmt->fetch()) {
            $output[] = $row->svariation_id;
        }
        return $output;
    }

    public function clone_variation_childs_form($variation_id)
    {
        $output = "";
        foreach ($this->svariations_key($variation_id) as $svariation_id) {
            $svariation_type = $this->svariation_type($variation_id, $svariation_id);
            switch ($svariation_type) {
                case "input":
                case "select":
                    $output .= '<div class="cursor-pointer choose-svariation-card border px-6 py-4 fw-bold">
                                    ' . $this->svariation_value($variation_id, $svariation_id) . '
                                    <input type="checkbox" class="d-none" value="' . $svariation_id . '" >
                                </div>';
                    break;

                case "image":
                    $output .= '<div class="no-bg pe-0 choose-svariation-card border position-relative cursor-pointer w-80px justify-align-center bg-light h-100px">
                                        <img class="img-fluid mh-100" src="' . $this->svariation_image($variation_id, $svariation_id) . '" >
                                        <input type="checkbox" class="d-none" value="' . $svariation_id . '" >
                                        </div>';
                    break;
            }
        }
        return $output;
    }



    public function create_variation_form($variation_id, $role)
    {
        $card = '';
        switch ($role) {
            case "primary":
                $card = '<div class="fv-row mb-7">
                            <label class="required form-label mb-2"> ' . $this->variation_header_text() . '</label>
                            ' . $this->variation_input() . '
                        </div>
                        <input type="hidden" value="primary" name="event_type" >';
                if ($this->variation_input("type") !== "image") {
                    $card .= '<div class="justify-right my-4 ">
                            <button type="submit" class="btn btn-rounded btn-primary">Create Variation</button>
                        </div>';
                }

                break;
            case "secondary":
                $card = '<div class="fv-row mb-7">
                            <label class="required form-label mb-2"> ' . $this->svariation_header_text() . '</label>
                            ' . $this->svariation_input($variation_id) . '
                        </div>
                        <input type="hidden" value="secondary" name="event_type" >';

                if ($this->svariation_input($variation_id, "type") !== "image") {
                    $card .= '<div class="justify-right my-4 ">
                        <button type="submit" class="btn btn-rounded btn-primary">Create Variation</button>
                    </div>';
                }
                break;
            case "clone_variation":
                $content = $this->clone_variation_childs_form($variation_id);
                $svariation_id = $this->st_svariation($variation_id);
                if (!$this->is_svariation_real($variation_id, $svariation_id)) {
                    $card = '
                    <input class="d-none" value="' . $svariation_id . '" name="svariations[]" >
                    <input class="d-none" type="text" value="' . $svariation_id . '" id="checked_svariations" required="" >';
                } else {
                    $card = '
                        <div class="fv-row mb-7">
                         <label class="required form-label mb-2"> Choose variations</label>
                            <div class="flex-wrap gap-4 align-center">' . $content . '</div>
                             <input class="d-none" type="text" id="checked_svariations" required="" >
                             <div class="invalid-feedback" >You must choose at least a variation</div>
                        </div>';
                }
                if ($this->variation_input("type") == "image") {
                    $card .= '<div class="fv-row mb-7">
                            <label class="required form-label mb-2"> Choose - ' . $this->variation_header_text() . '</label>
                            ' . $this->variation_input() . '
                        </div><input class="d-none" required="" type="text" value="" name="variation_value" >
                         <div class="invalid-feedback" >You must choose an image</div>';
                } else {
                    $card .= '<div class="fv-row mb-7">
                            <label class="required form-label mb-2"> ' . $this->variation_header_text() . '</label>
                            ' . $this->variation_input() . '
                        </div>';
                }
                $card .= '<input type="hidden" value="clone_variation" name="event_type" ><div class="justify-right my-4 ">
                            <button type="submit" class="btn btn-rounded btn-primary">Clone Variation</button>
                        </div>';
                break;
            case "clone_svariation":
                if ($this->svariation_input($variation_id, "type") == "image") {
                    $card = '<div class="fv-row mb-7">
                <label class="required form-label mb-2"> ' . $this->svariation_header_text() . '</label>
                ' . $this->svariation_input($variation_id) . '
                <input class="d-none" required="" type="text" value="" name="variation_value" >
                         <div class="invalid-feedback" >You must choose an image</div>
            </div>';
                } else {
                    $card = '<div class="fv-row mb-7">
                    <label class="required form-label mb-2"> ' . $this->svariation_header_text() . '</label>
                    ' . $this->svariation_input($variation_id) . '
                </div>';
                }
                $card .= '<input type="hidden" value="clone_svariation" name="event_type" >
                        <div class="justify-right my-4 ">
                            <button type="submit" class="btn btn-rounded btn-primary">Clone Variation</button>
                        </div>';
                break;
        }
        return $card;
    }

    public function svariation_count($variation_id)
    {
        $stmt = $this->db()->prepare("SELECT COUNT(svariation_id) as count FROM $this->ecommerce_listing_variations_tbl WHERE listing_id = ? AND variation_id = ? ");
        $stmt->execute([$this->listing_id, $variation_id]);
        return  $stmt->fetch()->count;
    }


    public function child_toolbar($variation_id, $svariation_id)
    {
        $toolbar = '';

        if ($this->is_svariation_real($variation_id, $svariation_id) && $this->can_add_variation()) {
            $toolbar =  '<div class="menu-item px-3">
                                 <a id="clone_svariation" class="menu-link px-3">Clone</a>
                        </div>';
        }

        if (!$this->is_svariation_live($variation_id, $svariation_id)) {
            $toolbar .=  '<div class="menu-item px-3">
         <a id="delete_svariation" class="menu-link px-3">Delete</a>
</div>';
            if (!$this->is_svariation_in_qc($variation_id, $svariation_id) && $this->can_add_variation()) {
                $toolbar .=  '<div class="menu-item px-3">
                             <a id="send_svariation_to_qc" class="menu-link px-3">Send to QC</a>
                      </div>';
            }
        } else {
            $product_id = $this->live_product_id();
            $Product = new Product($product_id);
            $arch_text = $Product->status($variation_id, $svariation_id) == "archived" ? "Unarchive" : "Archieve";
            $toolbar .= '<div class="menu-item px-3">
                <a id="archive_svariation" class="menu-link px-3">' . $arch_text . '</a>
         </div>';
        }
        if (!empty($toolbar)) return ' <button type="button" class="btn btn-sm btn-icon btn-color-primary btn-active-light-primary" data-lx-menu-trigger="click" data-lx-menu-placement="bottom-end"><i class="fas fa-ellipsis-v"></i></button>
                   <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg-light-primary fw-bold w-200px py-3" data-lx-menu="true" style="">
                  ' . $toolbar . '
                  </div>';
    }

    public function image($variation_id, $svariation_id)
    {

        $img_id = $this->images($variation_id, $svariation_id)[1]["id"] ?? '';
        return $this->get_file_src($img_id);
    }

    public function update_svariation_updates($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        $product_id = $this->live_product_id();
        $details = $row->details;
        $images = $row->images;
        $variation_value = $row->variation_value;
        $svariation_value = $row->svariation_value;
        $price = $row->price;
        $mrp = $row->mrp;
        $stock = $row->stock;
        $low_stock_warning = $row->low_stock_warning;
        $product_name = $row->product_name;
        $minimum_order = $row->minimum_order;
        $maximum_order = $row->maximum_order;
        $cod_status = $row->cod_status;
        $status = $row->status;
        $return_policy = $row->return_policy;
        $return_policy_days = $row->return_policy_days;
        $return_policy_tc = $row->return_policy_tc;
        $description = $row->description;
        $highlights = $row->highlights;
        $sku_id = $row->sku_id;
        $tags = $row->tags;

        $product_status = $this->live_product()->status($variation_id, $svariation_id);
        $status = $product_status == "active" || $product_status == "inactive" ? $status : $product_status;

        $sql = "UPDATE $this->ecommerce_variations_tbl SET variation_value = :variation_value, svariation_value = :svariation_value, details = :details,images = :images,price = :price, mrp = :mrp, stock = :stock, low_stock_warning = :low_stock_warning, sku_id = :sku_id, product_name = :product_name, minimum_order= :minimum_order, maximum_order = :maximum_order, cod_status = :cod_status, status = :status,  return_policy = :return_policy,return_policy_days = :return_policy_days, return_policy_tc = :return_policy_tc, highlights = :highlights, description = :description, tags = :tags WHERE product_id = :product_id AND variation_id  = :variation_id AND svariation_id = :svariation_id ";

        try {
            $stmt = $this->db()->prepare($sql);
            $stmt->execute([
                ":variation_value" => $variation_value,
                ":svariation_value" => $svariation_value,
                ":details" => $details,
                ":images" => $images,
                ":price" => $price,
                ":mrp" => $mrp,
                ":stock" => $stock,
                ":low_stock_warning" => $low_stock_warning,
                ":sku_id" => $sku_id,
                ":product_name" => $product_name,
                ":minimum_order" => $minimum_order,
                ":maximum_order" => $maximum_order,
                ":cod_status" => $cod_status,
                ":status" => $status,
                ":return_policy" => $return_policy,
                ":return_policy_days" => $return_policy_days,
                ":return_policy_tc" => $return_policy_tc,
                ":highlights" => $highlights,
                ":description" => $description,
                ":tags" => $tags,
                ":product_id" => $product_id,
                ":variation_id" => $variation_id,
                ":svariation_id" => $svariation_id
            ]);
        } catch (Exception $e) {
            throw new Error("Error in updating product changes" . $e->getMessage());
        }
    }

    public function validation_errors($variation_id, $svariation_id)
    {
        $image_error = '';
        $details_error = '';
        $information_error = '';
        $C = new Category($this->category_id());

        $row = $this->vrow($variation_id, $svariation_id);
        $images = $this->images($variation_id, $svariation_id);
        $price = $row->price;
        $mrp = $row->mrp;
        $stock = $row->stock;
        $low_stock_warning = $row->low_stock_warning;
        $sku_id = $row->sku_id;
        $cod_status = $row->cod_status;
        $product_name = $row->product_name;
        $minimum_order = $row->minimum_order;
        $maximum_order = $row->maximum_order;
        $status = $row->status;
        $return_policy = $row->return_policy;

        /**
         * Validating Images
         */
        $required_images = 3;
        if (empty($images)) $image_error = "$required_images images are mandatory";
        foreach ($images as $key => $image) {
            if ($image["type"] == "image" && $key <= $required_images) {
                if (!$this->is_file_id($image["id"])) $image_error = "$required_images images are mandatory";
            }
        }

        /**
         * Validating Information
         */

        if (empty($product_name)) $information_error .= '<p>*Product name is required.</p>';
        if (empty($minimum_order)) $information_error .= '<p>*Minimum order is required.</p>';
        if (empty($maximum_order)) $information_error .= '<p>*Maximum order is required.</p>';
        if (empty($status)) $information_error .= '<p>*Status is required.</p>';
        if (empty($return_policy)) $information_error .= '<p>*Return Policy is required.</p>';
        if (empty($price)) $information_error .= '<p>*Selling Price is required.</p>';
        if (empty($mrp)) $information_error .= '<p>*Mrp is required.</p>';
        if (empty($stock)) $information_error .= '<p>*Stock is required.</p>';
        if (empty($sku_id)) $information_error .= '<p>*Sku Id is required.</p>';
        if (empty($cod_status)) $information_error .= '<p>*Cash On Delivery is required.</p>';
        if (empty($low_stock_warning)) $information_error .= '<p>*Low Stock Warning is required.</p>';


        /**
         * Validating Details
         */
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_category_details_tbl WHERE category_id = '{$this->category_id()}' ");
        while ($row =  $stmt->fetch()) {
            $detail_id = $row->detail_id;
            $text = $C->detail_text($detail_id);
            $value = $this->get_product_detail_value($detail_id, $variation_id, $svariation_id);
            if (empty($value)) $details_error .= "<p>*$text is required.</p>";
        }


        $errors_card = '';
        if (!empty($image_error)) {
            $errors_card .= ' <div class="card mb-4 col-lg-4">
                                        <div class="card-header-alt">
                                            <div class="align-center">Images</div>
                                        </div>
                                        <div class="card-body text-danger fw-bold  border">' . $image_error . '</div>
                                    </div>';
        }
        if (!empty($information_error)) {
            $errors_card .= ' <div class="card mb-4 col-lg-4">
                                        <div class="card-header-alt">
                                            <div class="align-center">
                                                Product Information
                                            </div>
                                        </div>
                                        <div class="card-body text-danger fw-bold  border">' . $information_error . '</div>
                                    </div>';
        }
        if (!empty($details_error)) {
            $errors_card .= ' <div class="card mb-4 col-lg-4">
                                        <div class="card-header-alt">
                                            <div class="align-center">
                                                Product Details
                                            </div>
                                        </div>
                                        <div class="card-body text-danger fw-bold  border">' . $details_error . '</div>
                                    </div>';
        }
        $output = new stdClass;
        $output->errors = $errors_card;
        $output->url = $this->vurl($variation_id, $svariation_id) . '&validate=true';
        return $output;
    }


    public function is_listing_live()
    {
        $stmt = $this->db()->prepare("SELECT product_id FROM $this->ecommerce_products_tbl WHERE listing_id = ? ");
        $stmt->execute([$this->listing_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function is_variation_live($variation_id)
    {
        $svariations = $this->svariations_key($variation_id);
        foreach ($svariations as $svariation_id) {
            if ($this->is_svariation_live($variation_id, $svariation_id)) return $svariation_id;
        }
        return false;
    }

    public function is_svariation_live($variation_id, $svariation_id)
    {
        $stmt = $this->db()->prepare("SELECT product_id FROM $this->ecommerce_variations_tbl WHERE  variation_id = ? AND svariation_id = ? ");
        $stmt->execute([$variation_id, $svariation_id]);

        return $stmt->rowCount() ? true : false;
    }

    public function live_product_id()
    {
        $bt = debug_backtrace();
        $caller = array_shift($bt);

        //   echo $caller['file'];
        //   echo $caller['line'];

        $stmt = $this->db()->prepare("SELECT product_id FROM $this->ecommerce_products_tbl WHERE listing_id = ? ");
        $stmt->execute([$this->listing_id]);
        $row =   $stmt->fetch();
        return $row->product_id;
    }

    public function live_product()
    {
        return new Product($this->live_product_id());
    }

    public function is_variation_in_qc($variation_id)
    {
        $stmt = $this->db()->prepare("SELECT listing_id FROM $this->ecommerce_qc_tbl WHERE variation_id = ? AND listing_id = ? AND status = 'pending' ");
        $stmt->execute([$variation_id, $this->listing_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function is_svariation_in_qc($variation_id, $svariation_id)
    {
        $stmt = $this->db()->prepare("SELECT listing_id FROM $this->ecommerce_qc_tbl WHERE variation_id = ? AND listing_id = ? AND svariation_id = ? AND status = 'pending' ");
        $stmt->execute([$variation_id, $this->listing_id, $svariation_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function svariation_status_labels($variation_id, $svariation_id)
    {
        $status = '';
        if ($this->is_svariation_in_qc($variation_id, $svariation_id)) $status .= $this->status_to_label("In qc", "primary", 'me-4 py-3 px-4');
        else if ($this->has_qc_rejected($variation_id, $svariation_id, '')->status) $status .= $this->status_to_label("Qc rejected", "danger", 'me-4 py-3 px-4');

        if ($this->is_draft($variation_id, $svariation_id)) $status .= $this->status_to_label("Draft", "info", 'me-4 py-3 px-4');
        else $status = $this->live_product()->product_status($variation_id, $svariation_id) . ' ' . $this->live_product()->status_label($variation_id, $svariation_id);
        return $status;
    }

    public function has_qc_rejected($variation_id, $svariation_id, $qc_id)
    {
        $output = new stdClass;
        $output->status = false;
        $output->reject_reason = '';

        if (QC::is_qc_id($qc_id)) {
            $q = new QC($qc_id);
            if ($q->listing_id() == $this->listing_id && $q->status() == "rejected" && $q->variation_id() == $variation_id && $q->svariation_id() == $svariation_id) {
                $output->status = true;
                $output->reject_reason = $q->reject_reason();
                $output->error_portions = $q->error_portions();
            }
            return $output;
        }

        $stmt = $this->db()->prepare("SELECT qc_id FROM $this->ecommerce_qc_tbl WHERE listing_id = ? AND variation_id = ? AND svariation_id = ? AND status = 'rejected' ORDER BY qc_id DESC ");
        $stmt->execute([$this->listing_id, $variation_id, $svariation_id]);

        $row =  $stmt->fetch();
        if ($stmt->rowCount() && !$this->is_svariation_live($variation_id, $svariation_id) && !$this->is_svariation_in_qc($variation_id, $svariation_id)) {
            $qc_id = $row->qc_id;
            $q = new QC($qc_id);
            $output->status = true;
            $output->reject_reason = $q->reject_reason();
            $output->error_portions = $q->error_portions();
        }
        return $output;
    }
}

class Product extends Basic
{
    public $product_id;
    private $row;

    function __construct($id)
    {
        if (!self::is_product_id($id)) throw new Error("$id is not a valid Product Id");
        $this->product_id = $id;
        $this->row = $this->row();
    }

    public static function is_product_id($product_id)
    {
        global $Web;
        $stmt =  $Web->db()->prepare("SELECT product_id FROM $Web->ecommerce_products_tbl WHERE product_id = ? ");
        $stmt->execute([$product_id]);
        return $stmt->rowCount() ? true : false;
    }


    // Question

    public function questions_count()
    {
        $stmt = $this->db()->prepare("SELECT COUNT(*) as questions FROM $this->ecommerce_product_questions_tbl WHERE product_id = ? ");
        $stmt->execute([$this->product_id]);
        return  $stmt->fetch()->questions;
    }

    public function all_questions($variation_id, $svariation_id, $p_page = false)
    {
        $total_rows = $this->questions_count();
        if ($p_page == false) {
            $records_per_page = 5;
            $page = 1;
        } else {
            $page = $p_page;
            $records_per_page = 5;
        }

        $total_pages = ceil($total_rows / $records_per_page);
        if ($page > $total_pages) $page = 1;
        if (!($page > 0)) $page = 1;
        $offset = ($page - 1) * $records_per_page;

        $questions_data = '';
        $sql = "SELECT question_id FROM $this->ecommerce_product_questions_tbl WHERE product_id = ? ORDER BY date_asked DESC LIMIT $offset,$records_per_page";
        $stmt = $this->db()->prepare($sql);
        $stmt->execute([$this->product_id]);

        while ($row =  $stmt->fetch()) {
            $question_id  = $row->question_id;
            $questions_data .= (new Question($this->product_id, $question_id))->card($question_id);
        }

        if ($total_rows > 5 && $p_page == false)  $questions_data .= '<div class="py-4 px-6 fs-5">
                                                <a class="text-uppercase align-center fs-7 fw-bolder" href="' . $this->questions_page_url($variation_id, $svariation_id, true) . '">View all ' . $total_rows . ' Q&A
                                                    <span class="svg-icon svg-icon-2x mt-n1 svg-icon-primary">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <path d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z" fill="currentColor" />
                                                        </svg>
                                                    </span>
                                                </a>
                                            </div>';

        $output = new stdClass;
        $output->content = $questions_data;
        $output->pagination = $this->insert_pagination($this->questions_page_url($variation_id, $svariation_id), $page, $total_pages, true);

        return $output;
    }


    function reviews($variation_id, $svariation_id, $p_page = false)
    {
        $total_rows = $this->reviews_count();
        if ($p_page == false) {
            $records_per_page = 5;
            $page = 1;
        } else {
            $page = $p_page;
            $records_per_page = 5;
        }

        $total_pages = ceil($total_rows / $records_per_page);
        if ($page > $total_pages) $page = 1;
        if (!($page > 0)) $page = 1;
        $offset = ($page - 1) * $records_per_page;

        $sql = "SELECT * FROM $this->ecommerce_reviews_tbl WHERE product_id = ? ORDER BY review_id DESC LIMIT $offset,$records_per_page";
        $stmt = $this->db()->prepare($sql);
        $stmt->execute([$this->product_id]);

        $reviews_data = '';
        while ($row =  $stmt->fetch()) {
            $review_id = $row->review_id;
            $Review = new Review($this->product_id, $review_id);
            $reviews_data .= $Review->create_card($variation_id, $svariation_id);
        }
        if ($total_rows > 5 && $p_page == false) {
            $reviews_data .= '<div class="py-4 px-6 fs-5">
                                            <a class="text-uppercase align-center fs-7 fw-bolder" href="' . $this->review_page_url($variation_id, $svariation_id, true) . '" >View all ' . $total_rows . ' reviews
                                                <span class="svg-icon svg-icon-2x mt-n1 svg-icon-primary">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z" fill="currentColor" />
                                                    </svg>
                                                </span>
                                            </a>
                                        </div>';
        }

        $output = new stdClass;
        $output->content = $reviews_data;
        $output->pagination = $this->insert_pagination($this->review_page_url($variation_id, $svariation_id), $page, $total_pages, true);

        return $output;
    }

    public function reviews_images_cnt()
    {
        //images
        $count = 0;
        $stmt = $this->db()->prepare("SELECT review_id FROM $this->ecommerce_reviews_tbl WHERE product_id = ?  ");
        $stmt->execute([$this->product_id]);

        while ($row =  $stmt->fetch()) {
            $images = (new Review($this->product_id, $row->review_id))->images();
            $count += count($images) ?? 0;
        }
        return $count;
    }

    public function reviews_images()
    {
        //images
        $output = '';
        $count = 0;
        $max_images = 10;
        $stmt = $this->db()->prepare("SELECT review_id,images FROM $this->ecommerce_reviews_tbl WHERE product_id = ? AND images != '[]' ");
        $stmt->execute([$this->product_id]);

        $left = $this->reviews_images_cnt() - $max_images;
        while ($row =  $stmt->fetch()) {
            $review_id = $row->review_id;
            $images = $row->images;
            $images = json_decode($images);
            foreach ($images as $image_id) {
                $count++;
                if ($count == $max_images) {
                    $output .= '<div data-index="' . $count . '"  style="background-image:url(' . $this->get_file_src($image_id) . ')" data-id="' . $review_id . '" class="gallery-item">
                                                            <div class="extra-images-cover">+' . $left . '</div>
                                                        </div>';
                    return $output;
                } else {
                    $output .= '<a data-index="' . $count . '" style="background-image:url(' . $this->get_file_src($image_id) . ')" data-id="' . $review_id . '" class="gallery-item"></a>';
                }
            }
        }
        return $output;
    }

    public function reviews_count()
    {
        $stmt = $this->db()->prepare("SELECT COUNT(*) as reviews FROM $this->ecommerce_reviews_tbl WHERE product_id = ?  ");
        $stmt->execute([$this->product_id]);
        return  $stmt->fetch()->reviews;
    }

    public function avg_rating()
    {
        $stmt = $this->db()->prepare("SELECT AVG(rating) as avg FROM $this->ecommerce_reviews_tbl WHERE product_id = ?  ");
        $stmt->execute([$this->product_id]);
        $output = (float)  $stmt->fetch()->avg ?? 0;
        return $this->to_decimal($output, 1);
    }

    public function avg_rating_per($i)
    {
        $total = $this->reviews_count();
        $stmt = $this->db()->prepare("SELECT COUNT(*) as avg FROM $this->ecommerce_reviews_tbl WHERE product_id = ? AND rating = '$i'  ");
        $stmt->execute([$this->product_id]);
        $output = $total > 0 ? (($stmt->fetch()->avg) / $total) * 100 : 0;
        return $this->to_decimal($output, 1);
    }

    public function rating_count()
    {
        $stmt = $this->db()->prepare("SELECT SUM(rating) as rating FROM $this->ecommerce_reviews_tbl WHERE product_id = ?  ");
        $stmt->execute([$this->product_id]);
        return  $stmt->fetch()->rating ?? 0;
    }

    public function has_user_reviewed($user_id)
    {
        $stmt = $this->db()->prepare("SELECT review_id FROM $this->ecommerce_reviews_tbl WHERE product_id = ? AND reviewed_by = ? ");
        $stmt->execute([$this->product_id, $user_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function user_reviewed_id($user_id)
    {
        $stmt = $this->db()->prepare("SELECT review_id FROM $this->ecommerce_reviews_tbl WHERE product_id = ? AND reviewed_by = ? ");
        $stmt->execute([$this->product_id, $user_id]);
        return  $stmt->fetch()->review_id;
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_products_tbl WHERE product_id = ? ");
        $stmt->execute([$this->product_id]);
        $row =  $stmt->fetch();
        return $row;
    }

    public function update()
    {
        $this->row = $this->row();
    }

    public function vrow($variation_id, $svariation_id)
    {
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_variations_tbl WHERE product_id = ? AND variation_id = ? AND svariation_id = ? ");
        $stmt->execute([$this->product_id, $variation_id, $svariation_id]);
        $row =  $stmt->fetch();
        return $row;
    }

    public function date_created($variation_id, $svariation_id)
    {
        $vrow = $this->vrow($variation_id, $svariation_id);
        $date = $vrow->date_created;
        return $this->to_date($date);
    }

    public function sku_id($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->sku_id;
    }

    public function real_stock($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->stock;
    }

    public function stock($variation_id, $svariation_id)
    {
        $stock = $this->real_stock($variation_id, $svariation_id);

        $rangeTime = strtotime('-10 minutes');
        $product_id = $this->product_id;
        // 
        $stmt = $this->db()->prepare("SELECT SUM(quantity) as reserved_stock FROM $this->ecommerce_cart_tbl WHERE last_updated >= ? AND product_id = ? AND variation_id = ? AND svariation_id = ? ");
        $stmt->execute([$rangeTime, $product_id, $variation_id, $svariation_id]);

        $reserved_stock = $stmt->fetch()->reserved_stock;
        return $stock - $reserved_stock;
    }

    public function is_product_available($variation_id, $svariation_id)
    {
        $status = $this->status_text($variation_id, $svariation_id);
        return $status->type == "success" ? true : false;
    }

    public function can_view()
    {
        $Category = new Category($this->category_id());
        if ($Category->is_rejected()) return false;
        return true;
    }

    public function is_cod_available($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->cod_status === "yes" ? true : false;;
    }

    public function sells($variation_id, $svariation_id)
    {
        $stmt = $this->db()->prepare("SELECT SUM(quantity) as sells FROM $this->ecommerce_orders_tbl WHERE (status = 'DELIVERED' OR status = 'REPLACEMENT') AND variation_id = ? AND svariation_id = ? AND product_id = ? ");
        $stmt->execute([$this->product_id, $variation_id, $svariation_id]);
        $sells =  $stmt->fetch()->sells;
        return $sells;
    }


    public function status_text($variation_id, $svariation_id, $stock = null)
    {
        $status = $this->status($variation_id, $svariation_id);
        $stock = $stock ? $stock : $this->stock($variation_id, $svariation_id);


        $output = new stdClass;
        switch ($status) {
            case "archived":
                $type = "error";
                $text = "Currently unavailable";
                break;
            case "inactive":
                $type = "error";
                $text = "Currently unavailable";
                break;
            case "blocked":
                $type = "error";
                $text = "Currently unavailable";
                break;
            case "active":
                $type = "success";
                $text = "";
                break;
            case "rejected":
                $type = "error";
                $text = "This product is no more available";
                break;
        }

        if ($type == "error") {
            $output->type = $type;
            $output->text = $text;
            $output->code = "danger";
            return $output;
        }

        $minimum_order = $this->minimum_order($variation_id, $svariation_id);
        if ($stock < $minimum_order) {
            $output->type = "error";
            $output->text = "Currently unavailable";
            $output->code = "danger";
            return $output;
        } else if ($stock < $this->web_low_stock_warning()) {
            $output->type = "success";
            $output->text = "Only $stock in stock";
            $output->code = "warning";
            return $output;
        }

        $output->type = "success";
        $output->text = "In Stock";
        $output->code = "success";
        return $output;
    }

    public function listing_url($variation_id, $svariation_id)
    {
        $listing_id = $this->row($this->product_id)->listing_id;
        return (new Listing($listing_id))->vurl($variation_id, $svariation_id);
    }

    public function is_variation_id($variation_id)
    {
        $stmt = $this->db()->prepare("SELECT variation_id FROM $this->ecommerce_variations_tbl WHERE product_id = ? AND variation_id = ? ");
        $stmt->execute([$this->product_id, $variation_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function is_svariation_id($variation_id, $svariation_id)
    {
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_variations_tbl WHERE product_id = ? AND variation_id = ? AND svariation_id = ? ");
        $stmt->execute([$this->product_id, $variation_id, $svariation_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function variation_value($variation_id, $svariation_id)
    {
        $vrow = $this->vrow($variation_id, $svariation_id);
        return $vrow->variation_value;
    }

    public function svariation_value($variation_id, $svariation_id)
    {
        $vrow = $this->vrow($variation_id, $svariation_id);
        return $vrow->svariation_value;
    }

    public function low_stock_warning($variation_id, $svariation_id)
    {
        $vrow = $this->vrow($variation_id, $svariation_id);
        return $vrow->low_stock_warning;
    }

    public function description($variation_id, $svariation_id)
    {
        $srow = $this->vrow($variation_id, $svariation_id);
        $description = $srow->description;
        return $this->unsanitize_text($description);
    }

    public function highlights($variation_id, $svariation_id)
    {
        $srow = $this->vrow($variation_id, $svariation_id);
        $highlights = $srow->highlights;
        return json_decode($highlights);
    }
    public function variation_image($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        $variation_data = $row->variation_data;
        if (empty($variation_data)) return false;
        $variation_data = json_decode($variation_data);
        $img_id = $variation_data->id;
        return $this->get_file_src($img_id);
    }

    public function svariation_image($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        $variation_data = $row->svariation_data;
        if (empty($variation_data)) return false;
        $variation_data = json_decode($variation_data);
        $img_id = $variation_data->id;
        return $this->get_file_src($img_id);
    }

    public function variation_type($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        $variation_data = $row->variation_data;
        if (empty($variation_data)) return false;
        $variation_data = json_decode($variation_data);
        return $variation_data->type ?? '';
    }

    public function svariation_type($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        $svariation_data = $row->svariation_data ?? '{}';
        $svariation_data = json_decode($svariation_data);
        return $svariation_data->type ?? '';
    }

    public function status($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->status;
    }

    public function status_label($variation_id, $svariation_id)
    {
        $srow = $this->vrow($variation_id, $svariation_id);
        $stock = $srow->stock;
        if ($stock == 0) return $this->status_to_label("Sold Out", "danger");
        else if ($stock <= $this->low_stock_warning($variation_id, $svariation_id)) return $this->status_to_label("Low Stock", "warning");
        else return $this->status_to_label("In Stock", "success");
    }

    public function details($variation_id, $svariation_id)
    {
        $vrow = $this->vrow($variation_id, $svariation_id);
        $details = $vrow->details;
        $details = json_decode($details, true);
        return $details;
    }

    public function images($variation_id, $svariation_id)
    {
        $vrow = $this->vrow($variation_id, $svariation_id);
        $images = $vrow->images;
        $images = json_decode($images, true);
        return $images;
    }

    public function st_variation()
    {
        $stmt = $this->db()->prepare("SELECT variation_id FROM $this->ecommerce_variations_tbl WHERE product_id = ? ORDER BY variation_id ASC LIMIT 1");
        $stmt->execute([$this->product_id]);
        $row =  $stmt->fetch();
        return $row->variation_id;
    }

    public function st_svariation($variation_id)
    {
        $stmt = $this->db()->prepare("SELECT svariation_id FROM $this->ecommerce_variations_tbl WHERE product_id = ? AND variation_id = ? ORDER BY date_created ASC LIMIT 1");
        $stmt->execute([$this->product_id, $variation_id]);
        $row =  $stmt->fetch();
        return $row->svariation_id;
    }

    public function product_name($variation_id, $svariation_id)
    {

        $vrow = $this->vrow($variation_id, $svariation_id);
        $product_name = $vrow->product_name;
        return $this->unsanitize_text($product_name);
    }

    public function image($variation_id, $svariation_id)
    {
        $images = $this->images($variation_id, $svariation_id);
        $image_id = $images[1]["id"];
        return $this->get_file_src($image_id);
    }

    public function price($variation_id, $svariation_id)
    {
        $srow = $this->vrow($variation_id, $svariation_id);
        $price = $srow->price;
        return $price;
    }

    public function price_text($variation_id, $svariation_id)
    {
        return $this->formatCurrency($this->price($variation_id, $svariation_id));
    }

    public function mrp($variation_id, $svariation_id)
    {
        $srow = $this->vrow($variation_id, $svariation_id);
        $price = $srow->mrp;
        return $price;
    }

    public function mrp_text($variation_id, $svariation_id)
    {
        return $this->formatCurrency($this->mrp($variation_id, $svariation_id));
    }

    public function discount($mrp, $price)
    {
        if ($mrp < 1) return 0;
        $discount = 100 - ($price / $mrp * 100);
        $discount = $this->to_decimal($discount);
        return $discount;
    }
    public function url($variation_id, $svariation_id)
    {

        $product_name = $this->product_name($variation_id, $svariation_id);
        $product_name = $this->sluggify($product_name);
        return $this->base_url() . '/product/' . $product_name . '&pid=' . $this->product_id . '&vid=' . $variation_id . '&sid=' . $svariation_id . '&preview';
    }

    public function review_page_url($variation_id, $svariation_id)
    {
        $product_name = $this->product_name($variation_id, $svariation_id);
        $product_name = $this->sluggify($product_name);
        $url = $this->base_url() . '/product/' . $product_name . '&pid=' . $this->product_id . '&vid=' . $variation_id . '&sid=' . $svariation_id . '&reviews';
        return $url;
    }

    public function add_review_page_url($variation_id, $svariation_id, $page = false)
    {
        $product_name = $this->product_name($variation_id, $svariation_id);
        $product_name = $this->sluggify($product_name);
        $url = $this->base_url() . '/product/' . $product_name . '&pid=' . $this->product_id . '&vid=' . $variation_id . '&sid=' . $svariation_id . '&add-review';
        if ($page == true) $url .= "&page=1";
        return $url;
    }

    public function questions_page_url($variation_id, $svariation_id, $page = false)
    {
        $product_name = $this->product_name($variation_id, $svariation_id);
        $product_name = $this->sluggify($product_name);
        $url =  $this->base_url() . '/product/' . $product_name . '&pid=' . $this->product_id . '&vid=' . $variation_id . '&sid=' . $svariation_id . '&questions';
        if ($page == true) $url .= "&page=1";
        return $url;
    }


    public function highlights_card($variation_id, $svariation_id)
    {
        $output = '';
        $highlights = $this->highlights($variation_id, $svariation_id);
        if (!is_array($highlights)) return false;
        foreach ($highlights as $point) {
            $output .= '<li class="mb-3" >' . $point . '</li>';
        }
        if (!empty($output))  $output = "<ul>$output</ul>";
        return $output;
    }


    public function product_carousel($variation_id, $svariation_id)
    {

        $carousel = '';
        $images = $this->images($variation_id, $svariation_id);
        foreach ($images as $data) {
            if ($data["type"] == "image" && $this->is_file_id($data["id"])) {
                $src = $this->get_file_src($data["id"]);
                $carousel .= '<div class="swiper-slide" data-swiper-autoplay="400" style="background-image:url(' . $src . ');" >
                       </div>';
            }
        }
        $carousel = '<section class="swiper-container h-100 w-100 top-0 position-absolute product-carousel fade">
                                <div class="swiper-wrapper">
                                    ' . $carousel . '
                                </div>
                                <div class="swiper-pagination"></div>
                            </section>';
        return $carousel;
    }


    public function card($variation_id, $svariation_id, $searchQuery)
    {
        return '<a href="' . $this->url($variation_id, $svariation_id) . '&src=' . $searchQuery . '" class="product-card col-xl-3 col-lg-4 col-md-3 col-6">
                                            <div class="bg-white h-100">
                                                <div class="overflow-hidden position-relative h-250px h-lg-350px">
                                                    <div class="img-wrapper justify-align-center h-100"><img class="mh-100 img-fluid" src="' . $this->image($variation_id, $svariation_id) . '" alt="image"></div>
                                                            ' . $this->product_carousel($variation_id, $svariation_id) . '
                                                </div>
                                                <div class="card-body p-4">
                                                    <div class="text-primary" >' . $this->seller()->store_name() . '</div>
                                                    <div class="fs-5 text-primary-alt wrap-text-1 fw-bold"> ' . $this->product_name($variation_id, $svariation_id) . ' </div>
                                                    <div class="d-flex fs-6 fs-md-5 align-items-baseline mb-1 fw-bolder">
                                                            <span>' . $this->price_text($variation_id, $svariation_id) . '</span>
                                                            <span class="text-gray-600 text-decoration-line-through ms-2">' . $this->mrp_text($variation_id, $svariation_id) . '</span>
                                                            <span class="text-success ms-2">' . $this->discount($this->mrp($variation_id, $svariation_id), $this->price($variation_id, $svariation_id)) . '% off</span>
                                                    </div>
                                                </div>
                                            </div>
                 </a>';
    }

    public function sm_zoom_images($variation_id, $svariation_id)
    {
        $output = '';
        $images = $this->images($variation_id, $svariation_id);
        foreach ($images as $data) {
            if ($data["type"] == "image" && $this->is_file_id($data["id"])) {
                $src = $this->get_file_src($data["id"]);
                $output .= '<a data-zoom-id="product_slider" false-url href="' . $src . '" >
                                                        <img src="' . $src . '" />
                              </a>';
            }
        }
        return $output;
    }

    public function variation_header_text()
    {
        $category_id = $this->category_id();
        $C = new Category($category_id);
        return $C->header_variation_data("parent_header_text");
    }

    public function variation_information_id()
    {
        $category_id = $this->category_id();
        $C = new Category($category_id);
        return $C->header_variation_data("parent_detail_id");
    }

    public function category()
    {
        $category_id = $this->category_id();
        return new Category($category_id);
    }

    public function variations_card($active_variation_id, $svariation_id)
    {
        $output = '';
        $name =  $this->category()->has_variation() ?
            '<div class="d-flex mb-1">
                       <span class="fw-bolder" >' . $this->variation_header_text() . ': </span>
                        <span class="ms-2 fw-bold text-gray-400">' . $this->variation_value($active_variation_id, $svariation_id) . '</span>
                  </div>' : "";
        $stmt = $this->db()->prepare("SELECT DISTINCT(variation_id) FROM $this->ecommerce_variations_tbl WHERE product_id = ? ORDER BY date_created ASC ");
        $stmt->execute([$this->product_id]);
        while ($row =  $stmt->fetch()) {
            $variation_id = $row->variation_id;
            $svariation_id = $this->st_svariation($variation_id);

            $class = $variation_id === $active_variation_id ? "  primary-active " : "";
            $variation_type = $this->variation_type($variation_id, $svariation_id);

            switch ($variation_type) {
                case "input":
                case "select":
                    $output .= '<a data-replace="true" href="' . $this->url($variation_id, $svariation_id) . '" class="' . $class . '  border text-primary-alt border-hover-primary py-3 px-6 min-w-mcontent min-w-40px border min-h-40px active position-relative cursor-pointer justify-align-center">
                                        <div>' . $this->variation_value($variation_id, $svariation_id) . '</div>          
                                </a>';
                    break;

                case "image":
                    $output .= '<a data-replace="true" href="' . $this->url($variation_id, $svariation_id) . '" class="' . $class . ' border min-w-80px w-80px rounded-1 overflow-hidden active position-relative cursor-pointer justify-align-center  bg-hover-light h-100px">
                                                <img class="img-fluid mh-100" src="' . $this->variation_image($variation_id, $svariation_id) . '" >
                                            </a>';
                    break;
            }
        }

        if (!empty($output))   $output =  $name . '<div class="d-flex align-center scroll-x flex-lg-wrap p-2 gap-4">' . $output . '</div>';
        return $output;
    }

    public function svariations_card($active_variation_id, $active_svariation_id)
    {
        $output = '';
        $name =  $this->category()->has_svariation() ? '<div class="d-flex mb-1">
                       <span class="fw-bolder" >' . $this->svariation_header_text() . ': </span>
                        <span class="ms-2 fw-bold text-gray-400">' . $this->svariation_value($active_variation_id, $active_svariation_id) . '</span>
                  </div>' : '';
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_variations_tbl WHERE product_id = ? AND variation_id = ? ORDER BY date_created ASC ");
        $stmt->execute([$this->product_id, $active_variation_id]);
        while ($row =  $stmt->fetch()) {
            $variation_id = $row->variation_id;
            $svariation_id = $row->svariation_id;
            if (!$this->is_empty($this->svariation_value($variation_id, $svariation_id))) {
                $class = $svariation_id === $active_svariation_id ? " border primary-active " : "";
                $svariation_type = $this->svariation_type($variation_id, $svariation_id);
                switch ($svariation_type) {
                    case "input":
                    case "select":
                        $output .= '<a  data-replace="true" href="' . $this->url($variation_id, $svariation_id) . '" class="' . $class . '  border text-primary-alt border-hover-primary min-w-mcontent py-3 px-6 border active position-relative cursor-pointer justify-align-center">
                                        <div>' . $this->svariation_value($variation_id, $svariation_id) . '</div>          
                                    </a>';
                        break;

                    case "image":
                        $output .= '<a data-replace="true" href="' . $this->url($variation_id, $svariation_id) . '" class="' . $class . ' active position-relative cursor-pointer w-80px rounded-1 justify-align-center bg-light hover h-100px">
                                         <img class="img-fluid mh-100" src="' . $this->svariation_image($variation_id, $svariation_id) . '" >
                                     </a>';
                        break;
                }
            }
        }

        if (!empty($output)) $output =  $name . '<div class="d-flex align-center scroll-x flex-lg-wrap p-2 gap-4">' . $output . '</div>';
        return $output;
    }

    public function category_id()
    {
        $row = $this->row();
        return $row->category_id;
    }

    public function seller()
    {
        $row = $this->row();
        $user_id =  $row->user_id;
        return new Seller($user_id);
    }

    public function svariation_header_text()
    {
        $category_id = $this->category_id();
        $C = new Category($category_id);
        return $C->header_variation_data("child_header_text");
    }

    public function svariation_val($variation_id, $svariation_id)
    {
        $srow = $this->vrow($variation_id, $svariation_id);
        return $srow->svariation_value;
    }

    public function svariations($variation_id, $svariation_id)
    {
        $text = '<div class="d-flex mb-1">
                                <span class="text-gray-400">' . $this->svariation_header_text() . ': </span>
                  </div>';
        $output = '';
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_variations_tbl WHERE product_id = ? AND variation_id = ? ORDER BY svariation_id ASC ");
        $stmt->execute([$this->product_id, $variation_id]);

        while ($row =  $stmt->fetch()) {
            $svar_id = $row->svariation_id;
            $class = $svar_id == $svariation_id ? "primary-active " : "";
            $output .= '<a href="' . $this->url($variation_id, $svar_id) . '" data-replace="true" class="' . $class . 'text-primary-alt min-w-40px min-h-40px p-2 me-2 border border-gray-500 justify-align-center cursor-pointer ">' . $row->val . '</a>';
        }
        $m_output = '<div class="d-flex fw-bold mb-1">' . $output . '</div>';
        $output = $text . $m_output;
        return $output;
    }

    public function details_card($variation_id, $svariation_id)
    {
        $output = '<div class="align-justify-between mb-3">
                                            <div>Product Id</div>
                                            <div class="text-gray-600 text-muted">' . $this->product_id . '</div>
                                        </div>
                                        <div class="align-justify-between mb-3">
                                            <div>Activation Date</div>
                                            <div class="text-gray-600 text-muted">' . $this->date_created($variation_id, $svariation_id) . '</div>
                                        </div>';
        $details = $this->details($variation_id, $svariation_id);
        if (!is_array($details)) $details = [];
        foreach ($details as $detail_id => $val) {
            $C = new Category($this->category_id());
            $text = $C->detail_text($detail_id);
            $output .= '<div class="justify-between mb-3">
                                            <div class="min-w-100px"  >' . $text . '</div>
                                            <div class="text-end text-gray-600 text-muted">' . $val . '</div>
                                        </div>';
        }
        return $output;
    }

    public function minimum_order($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->minimum_order;
    }

    public function real_maximum_order($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        $maximum_order =  $row->maximum_order;
        return $maximum_order;
    }

    public function maximum_order($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        $stock = $this->stock($variation_id, $svariation_id);
        $maximum_order =  $row->maximum_order;
        if ($maximum_order > $stock) $maximum_order = $stock;
        return $maximum_order;
    }


    public function product_status($variation_id, $svariation_id)
    {
        $status = $this->status($variation_id, $svariation_id);
        switch ($status) {
            case "active":
                return $this->status_to_label("Active", "success");
                break;
            case "inactive":
                return $this->status_to_label("Inactive", "primary");
                break;
            case "archived":
                return $this->status_to_label("Archived", "info");
                break;
            case "blocked":
                return $this->status_to_label("Blocked", "danger");
                break;
            case "rejected":
                return $this->status_to_label("Rejected", "danger");
                break;
        }
    }

    public function return_policy($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        return $row->return_policy;
    }

    public function return_policy_days($variation_id, $svariation_id)
    {
        if ($this->return_policy($variation_id, $svariation_id) == "no") return 0;
        $row = $this->vrow($variation_id, $svariation_id);
        return (int) $row->return_policy_days;
    }

    public function return_policy_tc($variation_id, $svariation_id)
    {
        $row = $this->vrow($variation_id, $svariation_id);
        $return_policy_tc = $row->return_policy_tc;
        return $this->unsanitize_text($return_policy_tc);
    }

    public function listing_id()
    {
        $row = $this->row();
        return $row->listing_id;
    }

    public function updateViews($variation_id, $svariation_id)
    {
        global $Login;
        $ip_address = $Login->get_ip();
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_product_views_tbl WHERE ip_address = ? AND date = ? AND product_id = ? AND variation_id = ? AND svariation_id = ? ");
        $stmt->execute([$ip_address, $this->current_date(), $this->product_id, $variation_id, $svariation_id]);

        if (!$stmt->rowCount()) {
            $stmt = $this->db()->prepare("INSERT INTO $this->ecommerce_product_views_tbl (`product_id`,`variation_id`,`svariation_id`,`ip_address`,`views`,`date`, `last_viewed`)
             VALUES (?,?,?,?,'1',?,?) ");
            $stmt->execute([$this->product_id, $variation_id, $svariation_id, $ip_address, $this->current_date(), $this->current_time()]);
        } else {
            $row =  $stmt->fetch();
            $last_viewed = $row->last_viewed;
            $diff = $this->current_time() - $last_viewed;
            if ($diff >= 3600 * 4) {
                $stmt = $this->db()->prepare("UPDATE $this->ecommerce_product_views_tbl SET views = views + 1, last_viewed = ? WHERE ip_address = ? AND date = ? AND product_id = ? AND variation_id = ? AND svariation_id= ? ");
                $stmt->execute([$this->current_time(), $ip_address, $this->current_date(), $this->product_id, $variation_id, $svariation_id]);
            }
        }
    }

    public function has_user_purchased_product($user_id)
    {
        $stmt = $this->db()->prepare("SELECT buyer_id FROM $this->ecommerce_orders_tbl WHERE buyer_id = ? AND product_id = ? AND ( status = 'DELIVERED' || status = 'REPLACEMENT' || status = 'RETURNED' )   ");
        $stmt->execute([$user_id, $this->product_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function update_search_relevance($variation_id, $src)
    {
        $stmt = $this->db()->prepare("SELECT relevance_id FROM $this->ecommerce_search_relavance_tbl WHERE product_id = ? AND variation_id = ? AND search_keyword = ? ");
        $stmt->execute([$this->product_id, $variation_id, $src]);

        if ($stmt->rowCount()) {
            $this->db()->prepare("UPDATE $this->ecommerce_search_relavance_tbl SET views = views+1  WHERE product_id = ? AND variation_id = ? AND search_keyword =? ");
            $stmt->execute([$this->product_id, $variation_id, $src]);
        } else {
            $this->db()->prepare("INSERT INTO $this->ecommerce_search_relavance_tbl (`product_id`, `variation_id`, `search_keyword`, `views`) VALUES (?,?,?,'1') ");
            $stmt->execute([$this->product_id, $variation_id, $src]);
        }
    }


    public function user_questions_count($user_id)
    {
        $stmt = $this->db()->prepare("SELECT COUNT(question_id) as count FROM $this->ecommerce_product_questions_tbl WHERE  product_id = ? AND asker_id = ? ");
        $stmt->execute([$this->product_id, $user_id]);
        return  $stmt->fetch()->count;
    }

    private function create_similar_product_card($param)
    {
        $product_id = $param["product_id"];
        $variation_id = $param["variation_id"];
        $svariation_id = $param["svariation_id"];

        $Product = new Product($product_id);
        return ' <a href="' . $Product->url($variation_id, $svariation_id) . '"  class="d-flex flex-column text-primary-alt swiper-slide"><div class="h-100">
                                              <img src="' . $Product->image($variation_id, $svariation_id) . '" class="img-fluid">
                                          <div  class="text-start fs-7 p-3">
                                                <div class="font-normal line-clamp line-clamp-1">' . $Product->product_name($variation_id, $svariation_id) . '</div>
                                                <span class="mb-2"><span class="font-16">' . $Product->price_text($variation_id, $svariation_id) . '</span> <span class="text-muted mx-1"><del>' . $Product->mrp_text($variation_id, $svariation_id) . '</del></span> <span class="text-success">' . $Product->discount($Product->mrp($variation_id, $svariation_id), $Product->price($variation_id, $svariation_id)) . '% off</span></span>
                                            </div>
                  </div> </a>';
    }

    public function similarProducts()
    {
        $category_id = $this->category_id();
        $output = '';

        $stmt = $this->db()->prepare("SELECT $this->ecommerce_variations_tbl.product_id,$this->ecommerce_variations_tbl.variation_id,$this->ecommerce_variations_tbl.svariation_id, (
            SELECT COUNT(quantity) FROM $this->ecommerce_orders_tbl WHERE $this->ecommerce_orders_tbl.status = 'DELIVERED' AND $this->ecommerce_orders_tbl.product_id = $this->ecommerce_variations_tbl.product_id AND 
            $this->ecommerce_orders_tbl.variation_id = $this->ecommerce_variations_tbl.variation_id AND $this->ecommerce_orders_tbl.svariation_id = $this->ecommerce_variations_tbl.svariation_id 
        ) as sells FROM $this->ecommerce_variations_tbl INNER JOIN $this->ecommerce_products_tbl ON $this->ecommerce_variations_tbl.product_id = $this->ecommerce_products_tbl.product_id
         WHERE $this->ecommerce_products_tbl.category_id = ? AND $this->ecommerce_products_tbl.product_id != ? GROUP BY variation_id ORDER BY sells DESC LIMIT 12 ");

        $stmt->execute([$category_id, $this->product_id]);

        while ($row =  $stmt->fetch()) {
            $output .= $this->create_similar_product_card(array(
                "product_id" => $row->product_id,
                "variation_id" => $row->variation_id,
                "svariation_id" => $row->svariation_id
            ));
        }
        return $output;
    }
}

class Question extends Basic
{

    public $question_id;
    public $product_id;
    private $row;

    function __construct($product_id, $question_id)
    {
        if (!self::is_question_id($product_id, $question_id)) throw new Error("$question_id is not a vaild question id");
        $this->product_id = $product_id;
        $this->question_id = $question_id;
        $this->row = $this->row();
    }

    public static function is_question_id($product_id, $question_id)
    {
        global $Web;
        $stmt =  $Web->db()->prepare("SELECT product_id FROM $Web->ecommerce_product_questions_tbl WHERE product_id = ? AND question_id = ? ");
        $stmt->execute([$product_id, $question_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function product()
    {
        return new Product($this->product_id);
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_product_questions_tbl WHERE product_id = ? AND question_id = ? ");
        $stmt->execute([$this->product_id, $this->question_id]);
        return  $stmt->fetch();
    }

    public function asker()
    {
        $row = $this->row($this->question_id);
        return new User($row->asker_id);
    }

    public function has_answers()
    {
        $stmt = $this->db()->prepare("SELECT question_id FROM $this->ecommerce_product_answers_tbl WHERE question_id = ? ");
        $stmt->execute([$this->question_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function has_user_answered($user_id)
    {
        $stmt = $this->db()->prepare("SELECT question_id FROM $this->ecommerce_product_answers_tbl WHERE question_id = ? AND answered_by = ? ");
        $stmt->execute([$this->question_id, $user_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function can_add_answer($user_id)
    {
        if ($user_id == $this->asker()->user_id) return false;
        if ($this->has_user_answered($user_id)) return false;
        if ($user_id == $this->product()->seller()->user_id) return true;
        if (!$this->product()->has_user_purchased_product($user_id)) return false;
    }

    private function card_drop()
    {
        global $Login;
        if (!$Login->is_user_loggedin()) return;
        global $LogUser;

        $drop = '';
        if (
            ($LogUser->user_id == $this->asker()->user_id) &&
            (!$this->has_answers())
        ) {
            $drop .= '<div class="menu-item px-3">
                        <a data-action="edit" class="menu-link px-3">Edit</a>
                    </div>
                    <div class="menu-item px-3">
                        <a data-action="delete" class="menu-link px-3">Delete</a>
                    </div>';
        }

        if ($this->can_add_answer($LogUser->user_id)) {
            $drop .= '<div class="menu-item px-3">
                        <a data-action="answer" class="menu-link px-3">Add an answer</a>
                    </div>';
        }

        if (!$this->is_empty($drop))  return '<div class="drop-container">
                <button type="button" class="btn btn-sm btn-icon btn-active-white btn-active-color- border-0 me-n3" data-lx-menu-trigger="click" data-lx-menu-placement="bottom-end">
                    <i class="fas fa-ellipsis-v"></i>
                </button>
                <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg-light-primary fw-bold w-200px py-3" data-lx-menu="true" style="">
                    ' . $drop . '
                </div>
            </div>';
    }

    public function question()
    {
        $row = $this->row();
        $question = $row->question;
        $question = $this->unsanitize_text($question);
        return $question;
    }

    public function card($question_id)
    {
        $row = $this->row($question_id);
        if (!$this->has_answers($question_id)) {
            $answer = '<div class="my-2 align-items-baseline text-muted d-flex">Not Answered Yet</div>';
        } else {
            $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_product_answers_tbl WHERE question_id = ? ORDER BY date ASC LIMIT 1");
            $stmt->execute([$question_id]);
            $answer_row =  $stmt->fetch();
            $answer = $this->answer_card($answer_row->answer_id);
        }



        return '<div data-id="' . $question_id . '" class="question-card fs-6 px-6 border-top border-bottom py-2 ">
                        <div class="d-flex">
                            <div class="d-flex align-items-start flex-grow-1">
                                <div class="fw-bolder w-20px">Q:</div>
                                <div class="d-none oriquestionText">' . $this->question() . '</div>
                                <div data-clamp="3" class="ms-1 line-clamp line-clamp-3 questionText fw-bold flex-grow-1 pre-wrap">' . $this->question() . '</div>
                            </div>
                            <div class="w-50px">' . $this->card_drop() . '</div>
                        </div>
                        ' . $answer . '
                    </div>';
    }

    private function answers_count()
    {
        $stmt = $this->db()->prepare("SELECT COUNT(*) as answers FROM $this->ecommerce_product_answers_tbl WHERE question_id = ?  ");
        $stmt->execute([$this->question_id]);
        return  $stmt->fetch()->answers;
    }

    public function all_answers_card()
    {
        $output = ' <div class="d-flex bg-light border-start border-primary border-3 py-5 px-3 mb-4">
                                <div class="fw-bolder w-20px">Q:</div>
                                <div class="ms-1 questionText fw-bold flex-grow-1">' . $this->question() . '</div>
                      </div>';
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_product_answers_tbl WHERE question_id = ? ORDER BY date DESC");
        $stmt->execute([$this->question_id]);
        while ($row =  $stmt->fetch()) {
            $output .= $this->answer_card($row->answer_id, true);
        }
        return $output;
    }

    public function likes($answer_id)
    {
        $stmt = $this->db()->prepare("SELECT COUNT(*) as likes FROM $this->ecommerce_answer_rating_tbl WHERE product_id = ? AND question_id = ? AND answer_id = ? AND action = 'like' ");
        $stmt->execute([$this->product_id, $this->question_id, $answer_id]);
        return  $stmt->fetch()->likes;
    }

    public function like_class($answer_id)
    {
        global $Login;
        if ($Login->is_user_loggedin()) {
            global $LogUser;
            if ($this->has_user_liked($LogUser->user_id, $answer_id)) return " text-primary";
        }
    }

    public function dislikes($answer_id)
    {
        $stmt = $this->db()->prepare("SELECT COUNT(*) as dislikes FROM $this->ecommerce_answer_rating_tbl WHERE product_id = ? AND question_id = ? AND answer_id = ? AND action = 'dislike' ");
        $stmt->execute([$this->product_id, $this->question_id, $answer_id]);
        return  $stmt->fetch()->dislikes;
    }

    public function dislike_class($answer_id)
    {
        global $Login;
        if ($Login->is_user_loggedin()) {
            global $LogUser;
            if ($this->has_user_disliked($LogUser->user_id, $answer_id)) return " text-primary";
        }
    }


    public function has_user_liked($user_id, $answer_id)
    {
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_answer_rating_tbl WHERE product_id = ? AND  question_id = ? AND answer_id = ? AND user_id = ? AND action = 'like' ");
        $stmt->execute([$this->product_id, $this->question_id, $answer_id, $user_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function has_user_disliked($user_id, $answer_id)
    {
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_answer_rating_tbl WHERE product_id = ? AND question_id = ? AND answer_id = ? AND user_id = ? AND action = 'dislike' ");
        $stmt->execute([$this->product_id, $this->question_id, $answer_id, $user_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function is_answer_id($answer_id)
    {
        $stmt = $this->db()->prepare("SELECT question_id FROM $this->ecommerce_product_answers_tbl WHERE question_id = ? AND answer_id = ? ");
        $stmt->execute([$this->question_id, $answer_id]);
        return $stmt->rowCount();
    }


    public function answer_card($answer_id, $border = false)
    {
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_product_answers_tbl WHERE question_id = ? AND answer_id = ? ORDER BY date ASC LIMIT 1");
        $stmt->execute([$this->question_id, $answer_id]);

        $row =  $stmt->fetch();
        $answer = $this->unsanitize_text($row->answer);
        $U = new User($row->answered_by);
        $output = '
                      <div class="align-items-start fs-6 d-flex text-gray-700" >
                                    <div class="fw-bolder w-20px">A:</div>
                                    <div  data-clamp="3" class="ms-1 line-clamp line-clamp-3 pre-wrap fw-bold flex-grow-1"> ' . $answer . ' </div>
                                </div>
                                <div class="align-items-baseline flex-wrap justify-between">
                                    <div class="d-none d-md-flex my-2 align-items-baseline d-flex">
                                        <span class="fs-7 text-muted">Answered by</span>
                                        <span class="ms-2 fs-6 fw-bolder">' . $U->full_name() . '</span>
                                        <div class="ms-2">
                                            <span class="svg-icon svg-icon-primary"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="currentColor"></rect>
                                                    <path d="M10.4343 12.4343L8.75 10.75C8.33579 10.3358 7.66421 10.3358 7.25 10.75C6.83579 11.1642 6.83579 11.8358 7.25 12.25L10.2929 15.2929C10.6834 15.6834 11.3166 15.6834 11.7071 15.2929L17.25 9.75C17.6642 9.33579 17.6642 8.66421 17.25 8.25C16.8358 7.83579 16.1642 7.83579 15.75 8.25L11.5657 12.4343C11.2533 12.7467 10.7467 12.7467 10.4343 12.4343Z" fill="currentColor"></path>
                                                </svg></span>
                                            <span class="text-primary fw-bold">Buyer</span>
                                        </div>
                                        <div class="ms-2 fs-7 text-muted">' . $this->time_to_Ago($row->date) . '</div>
                                    </div>
                                    <div class="d-flex d-md-none my-2 align-items-baseline d-flex">
                                        <span class="fs-8 text-muted">By</span>
                                        <span class="ms-2 fs-6 fw-bolder">' . $U->first_name() . '</span>
                                        <div class="ms-2">
                                            <span class="svg-icon svg-icon-primary"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="currentColor"></rect>
                                                    <path d="M10.4343 12.4343L8.75 10.75C8.33579 10.3358 7.66421 10.3358 7.25 10.75C6.83579 11.1642 6.83579 11.8358 7.25 12.25L10.2929 15.2929C10.6834 15.6834 11.3166 15.6834 11.7071 15.2929L17.25 9.75C17.6642 9.33579 17.6642 8.66421 17.25 8.25C16.8358 7.83579 16.1642 7.83579 15.75 8.25L11.5657 12.4343C11.2533 12.7467 10.7467 12.7467 10.4343 12.4343Z" fill="currentColor"></path>
                                                </svg></span>
                                            <span class="text-primary fw-bold">Buyer</span>
                                        </div>
                                        <div class="ms-2 fs-7 text-muted">' . $this->time_to_Ago($row->date) . '</div>
                                    </div>
                                    <div class="d-flex">
                                        <button data-id="' . $answer_id . '" data-action="like" id="like_review" class="border-0 p-2 btn btn-outline align-center btn-outline-secondary">
                                            <i class="' . $this->like_class($answer_id) . ' fa fs-1 fa-thumbs-up"></i>
                                            <div class="fs-4 mt-1 ms-1 text-gray-700">' . $this->likes($answer_id) . '</div>
                                        </button>
                                        <button data-id="' . $answer_id . '" data-action="dislike" id="dislike_review" class="border-0 p-2 ms-3 btn btn-outline align-center btn-outline-secondary">
                                            <i class="' . $this->dislike_class($answer_id) . ' fa fs-1 fa-thumbs-down"></i>
                                            <div class="fs-4 mt-1 ms-1 text-gray-700">' . $this->dislikes($answer_id) . '</div>
                                        </button>
                                    </div>
                                </div>';
        if ($border) $output = '<div data-id="' . $this->question_id . '" class="question-card" >' . $output . '<div class="my-6 separator"></div></div>';
        if ($this->answers_count() > 1 && !$border) {

            $output .= '<button data-action="viewAllAnswers" class="text-uppercase fs-7 btn-link btn fw-bolder ">View All ' . $this->answers_count() . ' Answers</button>';
        }
        return $output;
    }
}

class Review extends Basic
{

    public $product_id;
    public $review_id;
    private $row;

    function __construct($product_id, $i)
    {
        if (!self::is_review_id($product_id, $i)) throw new Error("$i is not a valid review id");
        $this->product_id = $product_id;
        $this->review_id = $i;
        $this->row = $this->row();
    }

    public static function is_review_id($product_id, $review_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT * FROM $Web->ecommerce_reviews_tbl WHERE product_id = ? AND review_id = ? ");
        $stmt->execute([$product_id, $review_id]);
        return $stmt->rowCount() ? true : false;
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_reviews_tbl WHERE product_id = ? AND review_id = ? ");
        $stmt->execute([$this->product_id, $this->review_id]);
        return  $stmt->fetch();
    }

    public function rating()
    {
        $row = $this->row();
        $rating = $row->rating;
        return $rating;
    }

    public function product()
    {
        return new Product($this->product_id);
    }

    public static function rating_star($rating_int, $size)
    {
        $stars = '';
        for ($i = 1; $i <= 5; $i++) {
            $fill = ($i <= $rating_int) ? 'checked' : '';
            $stars .= '<div class="rating-label ' . $fill . '">
                      <i class="bi bi-star me-1 ' . $size . '"></i>
            </div>';
        }
        return $stars;
    }

    public function review_star($size)
    {
        $row = $this->row();
        $rating = $row->rating;
        $stars = $this->rating_star($rating, $size);
        return $stars;
    }

    public function review()
    {
        $row = $this->row();
        $review = $row->review;
        $review = $this->unsanitize_text($review);
        return $review;
    }

    public function reviewer()
    {
        $row = $this->row();
        $reviewed_by = $row->reviewed_by;
        return new User($reviewed_by);
    }

    public function date()
    {
        $row = $this->row();
        $date = $row->date;
        $date = $this->date_time($date);
        return $date;
    }

    public function likes()
    {
        $stmt = $this->db()->prepare("SELECT COUNT(*) as likes FROM $this->ecommerce_reviews_rating_tbl WHERE product_id = ? AND review_id = ? AND action = 'like' ");
        $stmt->execute([$this->product_id, $this->review_id]);

        return  $stmt->fetch()->likes;
    }

    public function like_class()
    {
        global $Login;
        if ($Login->is_user_loggedin()) {
            global $LogUser;
            if ($this->has_user_liked($LogUser->user_id)) return " text-primary";
        }
    }

    public function dislikes()
    {
        $stmt = $this->db()->prepare("SELECT COUNT(*) as dislikes FROM $this->ecommerce_reviews_rating_tbl WHERE product_id = ? AND review_id = ? AND action = 'dislike' ");
        $stmt->execute([$this->product_id, $this->review_id]);
        return  $stmt->fetch()->dislikes;
    }

    public function dislike_class()
    {
        global $Login;
        if ($Login->is_user_loggedin()) {
            global $LogUser;
            if ($this->has_user_disliked($LogUser->user_id)) return " text-primary";
        }
    }

    private function dropdown($variation_id, $svariation_id)
    {
        global $Login;
        if (!$Login->is_user_loggedin()) return false;
        global $LogUser;
        if ($LogUser->user_id !== $this->reviewer()->user_id) return false;
        return '<button type="button" class="btn btn-sm btn-icon btn-color-primary btn-active-light-primary" data-lx-menu-trigger="click" data-lx-menu-placement="bottom-end"><i class="fas fa-ellipsis-v"></i></button>
                                                    <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg-light-primary fw-bold w-200px py-3" data-lx-menu="true" style="">
                                                        <div class="menu-item px-3">
                                                            <a href="' . $this->product()->add_review_page_url($variation_id, $svariation_id) . '" class="menu-link px-3">Edit</a>
                                                        </div>
                                                        <div class="menu-item px-3">
                                                            <a id="delete_review" class="menu-link flex-stack px-3">Delete</a>
                                                        </div>
                                                    </div>';
    }

    public function images()
    {
        $row = $this->row();
        $images = $row->images;
        $images = json_decode($images);
        return $images;
    }

    private function images_card()
    {
        $images = $this->images();
        $output = '';
        foreach ($images as $key => $image_id) {
            $output .= '<div data-index="' . $key . '" style="background-image:url(' . $this->get_file_src($image_id) . ')"  class="gallery-item"></div>';
        }
        return $output;
    }

    public function create_card($variation_id, $svariation_id)
    {
        return '<div data-id="' . $this->review_id . '" class="review-card py-3 border-bottom border-top px-6">
                                                <div class="align-justify-between">
                                                    <div class="rating">' . $this->review_star("fs-2") . '</div>
                                                    ' . $this->dropdown($variation_id, $svariation_id) . '
                                                </div>
                                                <div data-clamp="3" class="my-2 fs-6 line-clamp line-clamp-3 fw-bold pre-wrap">' . $this->review() . '</div>

                                                <div class="gallery-container">
                                                ' . $this->images_card() . '
                                                </div>

                                                <div class="align-items-baseline flex-wrap justify-between">
                                                    <div class="d-none d-md-flex fmy-2 align-items-baseline d-flex">
                                                        <span class="fs-7 text-muted">Reviewed by</span>
                                                        <span class="ms-2 fw-bolder">' . $this->reviewer()->full_name() . '</span>
                                                        <div class="ms-2">
                                                            <span class="svg-icon svg-icon-primary"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="currentColor" />
                                                                    <path d="M10.4343 12.4343L8.75 10.75C8.33579 10.3358 7.66421 10.3358 7.25 10.75C6.83579 11.1642 6.83579 11.8358 7.25 12.25L10.2929 15.2929C10.6834 15.6834 11.3166 15.6834 11.7071 15.2929L17.25 9.75C17.6642 9.33579 17.6642 8.66421 17.25 8.25C16.8358 7.83579 16.1642 7.83579 15.75 8.25L11.5657 12.4343C11.2533 12.7467 10.7467 12.7467 10.4343 12.4343Z" fill="currentColor" />
                                                                </svg></span>
                                                            <span class="text-primary fw-bold">Buyer</span>
                                                        </div>
                                                        <div class="ms-2 fs-7 text-muted">' . $this->date() . '</div>
                                                    </div>
                                                    <div class="d-md-none d-flex my-2 align-items-baseline d-flex">
                                                        <span class="d-md-none d-block fs-7 text-muted">By</span>
                                                        <span class="ms-2 fw-bolder">' . $this->reviewer()->first_name() . '</span>
                                                        <div class="ms-2">
                                                            <span class="svg-icon svg-icon-primary"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="currentColor" />
                                                                    <path d="M10.4343 12.4343L8.75 10.75C8.33579 10.3358 7.66421 10.3358 7.25 10.75C6.83579 11.1642 6.83579 11.8358 7.25 12.25L10.2929 15.2929C10.6834 15.6834 11.3166 15.6834 11.7071 15.2929L17.25 9.75C17.6642 9.33579 17.6642 8.66421 17.25 8.25C16.8358 7.83579 16.1642 7.83579 15.75 8.25L11.5657 12.4343C11.2533 12.7467 10.7467 12.7467 10.4343 12.4343Z" fill="currentColor" />
                                                                </svg></span>
                                                            <span class="text-primary fw-bold">Buyer</span>
                                                        </div>
                                                        <div class="ms-2 fs-7 text-muted">' . $this->to_date(strtotime($this->date())) . '</div>
                                                    </div>
                                                    <div class="d-flex">
                                                        <button  id="like_review" class="border-0 p-2 btn btn-outline align-center btn-outline-secondary">
                                                    <i class="' . $this->like_class() . ' fa fs-1 fa-thumbs-up"></i>
                                                    <div class="fs-4 mt-1 ms-1 text-gray-700">' . $this->likes() . '</div>
                                                </button>
                                                <button id="dislike_review" class="border-0 btn p-2 ms-3 btn-outline align-center btn-outline-secondary">
                                                    <i class="' . $this->dislike_class() . ' fa fs-1 fa-thumbs-down"></i>
                                                    <div class="fs-4 mt-1 ms-1 text-gray-700">' . $this->dislikes() . '</div>
                                                </button>
                                                    </div>
                                                </div>
                                            </div>';
    }

    public function has_user_liked($user_id)
    {
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_reviews_rating_tbl WHERE product_id = ? AND  review_id = ? AND user_id = ? AND action = 'like' ");
        $stmt->execute([$this->product_id, $this->review_id, $user_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function has_user_disliked($user_id)
    {
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_reviews_rating_tbl WHERE product_id = ? AND review_id = ? AND user_id = ? AND action = 'dislike' ");
        $stmt->execute([$this->product_id, $this->review_id, $user_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function edit_images_form()
    {
        $images = $this->images();
        $output = '';
        foreach ($images as $image_id) {
            $output .= '<div class="w-50px h-50px me-3 position-relative justify-align-center opacity-100-hover bg-light review-img-upload" >
                          <button data-id="' . $image_id . '" type="button" class="delete-alt " title="Delete">
                                            <i class="fas fa-times"></i>
                                        </button><img class="img-fluid mh-100" src="' . $this->get_file_src($image_id) . '" alt="" srcset="">
                        </div>';
        }
        $class = count($images) == 5 ? "d-none" : "";
        $output .= ' <div class="' . $class . ' w-50px h-50px me-3 opacity-100-hover review-img-upload" id="uploadImg">
                                        <span>+</span>
                                    </div>';
        return $output;
    }

    private function prev_review_id()
    {
        $stmt = $this->db()->prepare("SELECT review_id FROM $this->ecommerce_reviews_tbl WHERE product_id = ? AND  review_id = (SELECT min(review_id) from $this->ecommerce_reviews_tbl where review_id >  ? AND product_id = ? AND images != '[]' ) ");
        $stmt->execute([$this->product_id, $this->review_id, $this->product_id]);
        $row =  $stmt->fetch();
        $review_id = $row->review_id ?? '';
        return $review_id;
    }

    private function next_review_id()
    {
        $stmt = $this->db()->prepare("SELECT review_id FROM $this->ecommerce_reviews_tbl WHERE product_id = ? AND  review_id = (SELECT max(review_id) from $this->ecommerce_reviews_tbl where review_id <  ? AND product_id = ? AND images != '[]' ) ");
        $stmt->execute([$this->product_id, $this->review_id, $this->product_id]);
        $row =  $stmt->fetch();
        $review_id = $row->review_id ?? '';
        return $review_id;
    }

    private function ratingPreviewModalSwiper()
    {
        $images  = $this->images();
        $output = '';
        foreach ($images as $img_id) {
            $output .= '<div class="justify-align-center align-self-center swiper-slide">
                             <img src="' . $this->get_file_src($img_id) . '" class="img-fluid mh-100">
                        </div>';
        }
        return $output;
    }

    private function ratingPreviewModalSwiperPagination()
    {
        $images  = $this->images();
        $output = '';
        foreach ($images as $img_id) {
            $output .= '<div class="align-self-center swiper-slide me-1 swiper-slide-visible swiper-slide-active swiper-slide-thumb-active" style="background-image: url(' . $this->get_file_src($img_id) . ');"></div>';
        }
        return $output;
    }

    public function ratingPreviewModal()
    {
        $prev = $this->is_empty($this->prev_review_id()) ? "element-disabled" : "";
        $next = $this->is_empty($this->next_review_id()) ? "element-disabled" : "";

        return '<div style="pointer-events: auto;" class="my-12 position-relative cursor-default br-0 d-block justify-align-center w-100 mw-700px mw-xl-800px mw-xxl-1000px min-h-400px">
     
       <div data-id="' . $this->prev_review_id() . '" class="' . $prev . ' modal-action-btn previous "><span class="svg-icon svg-icon-muted svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                   <rect opacity="0.5" x="6" y="11" width="13" height="2" rx="1" fill="black" />
                   <path d="M8.56569 11.4343L12.75 7.25C13.1642 6.83579 13.1642 6.16421 12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75L5.70711 11.2929C5.31658 11.6834 5.31658 12.3166 5.70711 12.7071L11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25C13.1642 17.8358 13.1642 17.1642 12.75 16.75L8.56569 12.5657C8.25327 12.2533 8.25327 11.7467 8.56569 11.4343Z" fill="black" />
               </svg></span></div>
       <div data-id="' . $this->next_review_id() . '" class="' . $next . ' modal-action-btn next"><span class="svg-icon svg-icon-muted svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                   <rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black" />
                   <path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black" />
               </svg></span></div>
       <div class="modal-action-btn remove" ><span class="svg-icon svg-icon-muted svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                   <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                   <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
               </svg></span></div>                
                                           <div class="d-flex flex-column flex-md-row justify-center">
                                                <div id="img_wrapper" class="w-100 mw-md-50 h-100">

                                                    <section style="background-color: #4f4f4f;" class="rating-swiper-container overflow-hidden swiper-container">
                                                        <div class="swiper-wrapper">' . $this->ratingPreviewModalSwiper() . '</div>
                                                        <div class="swiper-pagination"></div>
                                                        <div class="swiper-button-prev swiper-button-white"></div>
                                                        <div class="swiper-button-next swiper-button-white"></div>
                                                    </section>

                                                </div>
                                                <div id="content_wrapper" class="px-4 d-flex flex-column w-100 mw-md-50 scroll-y bg-white position-relative">

                                                    <div class="my-2 align-items-baseline d-flex">
                                                        <span class="fw-bolder">' . $this->reviewer()->full_name() . '</span>
                                                        <div class="ms-2">
                                                            <span class="svg-icon svg-icon-primary"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="currentColor"></rect>
                                                                    <path d="M10.4343 12.4343L8.75 10.75C8.33579 10.3358 7.66421 10.3358 7.25 10.75C6.83579 11.1642 6.83579 11.8358 7.25 12.25L10.2929 15.2929C10.6834 15.6834 11.3166 15.6834 11.7071 15.2929L17.25 9.75C17.6642 9.33579 17.6642 8.66421 17.25 8.25C16.8358 7.83579 16.1642 7.83579 15.75 8.25L11.5657 12.4343C11.2533 12.7467 10.7467 12.7467 10.4343 12.4343Z" fill="currentColor"></path>
                                                                </svg></span>
                                                            <span class="text-primary fw-bold">Seller</span>
                                                        </div>
                                                        <div class="ms-2 text-muted">' . $this->date() . '</div>
                                                    </div>
                                                    <div class="align-justify-between">
                                                        <div class="rating">
                                                           ' . $this->review_star("fs-2") . '
                                                        </div>
                                                    </div>
                                                    <div data-clamp="3"  class="my-2 scroll-y mh-50 line-clamp line-clamp-3 fw-bold pre-wrap">' . $this->review() . '</div>
                                                    <div class="d-flex">
                                                        <button  id="like_review" class="border-0 btn btn-outline align-center btn-outline-secondary">
                                                    <i class="' . $this->like_class() . ' fa fs-1 fa-thumbs-up"></i>
                                                    <div class="fs-4 mt-1 ms-1 text-gray-700">' . $this->likes() . '</div>
                                                </button>
                                                <button id="dislike_review" class="border-0 btn btn-outline align-center btn-outline-secondary">
                                                    <i class="' . $this->dislike_class() . ' fa fs-1 fa-thumbs-down"></i>
                                                    <div class="fs-4 mt-1 ms-1 text-gray-700">' . $this->dislikes() . '</div>
                                                </button>
                                                    </div>

                                                    <div class="separator d-md-none d-block d-lg-block my-4"></div>
                                                    <div class="swiper-container d-md-none d-block d-lg-block h-auto gallery-thumbs swiper-container-horizontal swiper-container-free-mode swiper-container-thumbs">
                                                        <div class="swiper-wrapper" style="flex-wrap: wrap;">
                                                            ' . $this->ratingPreviewModalSwiperPagination() . '
                                                        </div>
                                                        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                                                    </div>
                                                   <div class="mt-auto" >
                                                    <div class="separator mt-4"></div>
                                                    <button data-action="viewGallery" class="text-uppercase  position-relative bottom-0 fs-7 btn-link btn fw-bolder ">
                                                        <span class="svg-icon svg-icon-primary svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                <path d="M4.5 7C5.88071 7 7 5.88071 7 4.5C7 3.11929 5.88071 2 4.5 2C3.11929 2 2 3.11929 2 4.5C2 5.88071 3.11929 7 4.5 7Z" fill="currentColor" />
                                                                <path opacity="0.3" d="M14 4.5C14 5.9 12.9 7 11.5 7C10.1 7 9 5.9 9 4.5C9 3.1 10.1 2 11.5 2C12.9 2 14 3.1 14 4.5ZM18.5 2C17.1 2 16 3.1 16 4.5C16 5.9 17.1 7 18.5 7C19.9 7 21 5.9 21 4.5C21 3.1 19.9 2 18.5 2ZM4.5 9C3.1 9 2 10.1 2 11.5C2 12.9 3.1 14 4.5 14C5.9 14 7 12.9 7 11.5C7 10.1 5.9 9 4.5 9ZM11.5 9C10.1 9 9 10.1 9 11.5C9 12.9 10.1 14 11.5 14C12.9 14 14 12.9 14 11.5C14 10.1 12.9 9 11.5 9ZM18.5 9C17.1 9 16 10.1 16 11.5C16 12.9 17.1 14 18.5 14C19.9 14 21 12.9 21 11.5C21 10.1 19.9 9 18.5 9ZM4.5 16C3.1 16 2 17.1 2 18.5C2 19.9 3.1 21 4.5 21C5.9 21 7 19.9 7 18.5C7 17.1 5.9 16 4.5 16ZM11.5 16C10.1 16 9 17.1 9 18.5C9 19.9 10.1 21 11.5 21C12.9 21 14 19.9 14 18.5C14 17.1 12.9 16 11.5 16ZM18.5 16C17.1 16 16 17.1 16 18.5C16 19.9 17.1 21 18.5 21C19.9 21 21 19.9 21 18.5C21 17.1 19.9 16 18.5 16Z" fill="currentColor" />
                                                            </svg></span>View Image gallery
                                                    </button>
                                                    </div>


                                                </div>
                                            </div>
                                        </div>';
    }
}

class Courier extends Basic
{
    public $courier_id;
    private $row;

    /**
     * @param $id = $courier_id
     * 
     */
    function __construct($id)
    {
        if (!self::is_courier_id($id)) Errors::response("$id is not a valid Courier Id");
        $this->courier_id = $id;
        $this->row = $this->row();
    }

    /**
     * @param $id = $courier_id
     * 
     */
    public static function is_courier_id($id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT courier_id FROM $Web->ecommerce_courier_tbl WHERE courier_id = ? ");
        $stmt->execute([$id]);
        return $stmt->rowCount() ? true : false;
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_courier_tbl WHERE courier_id = ? ");
        $stmt->execute([$this->courier_id]);
        return  $stmt->fetch();
    }

    public function name()
    {
        $row = $this->row();
        $name =  $row->name;
        return $this->unsanitize_text($name);
    }

    public function url()
    {
        $row = $this->row();
        $url = $row->url;
        return $this->unsanitize_text($url);
    }

    public function status()
    {
        $row = $this->row();
        $status = $row->status;
        return $status;
    }
    public function created_date()
    {
        $row = $this->row();
        $created_date = $row->date;
        return $this->date_time($created_date);
    }

    public static function list()
    {
        global $Web;
        $stmt = $Web->db()->query("SELECT * FROM $Web->ecommerce_courier_tbl WHERE status = 'active' ");
        $output = '';
        while ($row =  $stmt->fetch()) {
            $courier_id = $row->courier_id;
            $name = (new Courier($courier_id))->name();
            $output .= '<option value="' . $courier_id . '" >' . $name . '</option>';
        }
        return $output;
    }

    public static function tbl()
    {
        global $Web;
        $count =  0;
        $stmt = $Web->db()->query("SELECT * FROM $Web->ecommerce_courier_tbl WHERE status = 'active' ORDER BY name ASC ");
        if (!$stmt->rowCount()) return '<tr><td colspan="5" class="text-center" >No data available in table</td></tr>';
        $output = '';
        while ($row =  $stmt->fetch()) {
            $C = new Courier($row->courier_id);
            $count++;
            $output  .= '<tr>
            <td>' . $count . '</td>
            <td>' . $C->name() . '</td>
            <td><a target="_blank" href="' . $C->url() . '" >' . $C->url() . '</a></td>
                    <td>' . $C->created_date() . '</td>
            <td><div>
                                  <a data-url="' . $C->url() . '" data-name="' . $C->name() . '" data-id="' . $C->courier_id . '" data-action="edit" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                    <span class="svg-icon svg-icon-3">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                      </svg>
                                    </span>
                                  </a>
                                  <a data-id="' . $C->courier_id . '" data-action="delete" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                                    <span class="svg-icon svg-icon-3">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="currentColor"></path>
                                        <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="currentColor"></path>
                                        <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="currentColor"></path>
                                      </svg>
                                    </span>
                                  </a>
                                </div></td>
            </tr>';
        }
        return $output;
    }
}

class QC extends Basic
{
    private $qc_id;
    private $row;

    function __construct($id)
    {
        if (!self::is_qc_id($id)) throw new Error("$id is not a valid Qc Id");
        $this->qc_id = $id;
        $this->row = $this->row();
    }

    public static function is_qc_id($qc_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT qc_id FROM $Web->ecommerce_qc_tbl WHERE qc_id = ? ");
        $stmt->execute([$qc_id]);
        return $stmt->rowCount() ? true : false;
    }

    public static function is_qvariation_id($qvariation_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT qc_id FROM $Web->ecommerce_qc_tbl WHERE qvariation_id = ? ");
        $stmt->execute([$qvariation_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function is_qc_qvariation_id($qvariation_id)
    {
        $stmt = $this->db()->prepare("SELECT qc_id FROM $this->ecommerce_qc_tbl WHERE  qc_id = ? AND qvariation_id = ? ");
        $stmt->execute([$this->qc_id, $qvariation_id]);
        return $stmt->rowCount() ? true : false;
    }

    public static function create_qvariation_id()
    {
        $qvariation_id = rand(10000000000, 99999999999);
        return self::is_qvariation_id($qvariation_id) ? self::create_qvariation_id() : $qvariation_id;
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_qc_tbl WHERE qc_id = ? ");
        $stmt->execute([$this->qc_id]);
        return $stmt->fetch();
    }

    public function url($qvariation_id)
    {
        return $this->admin_url() . '/qc/view?id=' . $this->qc_id . '&qid=' . $qvariation_id;
    }

    public function get_next_url()
    {
        $qvariation_id = $this->qvariation_id();
        $stmt = $this->db()->prepare("SELECT qc_id FROM $this->ecommerce_qc_tbl WHERE qvariation_id = ? AND status = 'pending' ");
        $stmt->execute([$qvariation_id]);

        if ($stmt->rowCount()) {
            $row =  $stmt->fetch();
            $qc_id = $row->qc_id;
            $q = new QC($qc_id);
            return $q->url($qvariation_id);
        }
        return $this->admin_url() . '/qc/pending';
    }

    public function variations_card($qvariation_id, $active_variation_id)
    {
        $Listing = $this->listing();
        $output = '';
        $stmt = $this->db()->prepare("SELECT variation_id,svariation_id FROM $this->ecommerce_qc_tbl WHERE qvariation_id = ? ORDER BY date_requested ASC ");
        $stmt->execute([$qvariation_id]);

        $row =  $stmt->fetch();
        $variation_id = $row->variation_id;
        $svariation_id = $row->svariation_id;

        $variation_type = $Listing->variation_type($variation_id, $svariation_id);
        switch ($variation_type) {
            case "input":
            case "select":
                $output .= '<a data-replace="true" href="' . $this->url($qvariation_id) . '" class=" border primary-active text-primary-alt py-3 px-6 border h-40px active position-relative cursor-pointer justify-align-center bg-light hover">
                                        <div>' . $Listing->variation_value($variation_id, $svariation_id) . '</div>          
                                </a>';
                break;

            case "image":
                $output .= '<a data-replace="true" href="' . $this->url($qvariation_id) . '" class="border rounded overflow-hidden primary-active active position-relative cursor-pointer mw-80px justify-align-center bg-hover-light h-100px">
                                                <img class="img-fluid mh-100" src="' . $Listing->variation_image($variation_id, $svariation_id) . '" >
                            </a>';
                break;
        }
        return $output;
    }

    public function svariations_card($qvariation_id, $qc_id)
    {
        $Listing = $this->listing();
        $output = '';
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_qc_tbl WHERE qvariation_id = ?  ");
        $stmt->execute([$qvariation_id]);
        while ($row =  $stmt->fetch()) {
            $db_qc_id = $row->qc_id;
            $variation_id = $row->variation_id;
            $svariation_id = $row->svariation_id;
            $q = new QC($db_qc_id);
            if (!$this->is_empty($Listing->svariation_value($variation_id, $svariation_id))) {
                $class = $qc_id == $db_qc_id ? " border primary-active " : "";

                $svariation_type = $Listing->svariation_type($variation_id, $svariation_id);

                switch ($svariation_type) {
                    case "input":
                    case "select":
                        $output .= '<a  data-replace="true" href="' . $q->url($qvariation_id) . '" class="' . $class . ' text-primary-alt   py-3 px-6 border h-40px me-4 active position-relative cursor-pointer justify-align-center mb-2 bg-light hover">
                                        <div>' . $Listing->svariation_value($variation_id, $svariation_id) . '</div>          
                                </a>';
                        break;

                    case "image":
                        $output .= '<a data-replace="true" href="' . $q->url($qvariation_id, $svariation_id) . '" class="' . $class . ' border min-w-80px w-80px rounded-1 overflow-hidden active position-relative cursor-pointer justify-align-center  bg-hover-light h-100px">
                                                    <img class="img-fluid mh-100" src="' . $Listing->svariation_image($variation_id, $svariation_id) . '" >
                                                </a>';
                        break;
                }
            }
        }
        return $output;
    }

    public function listing()
    {
        $listing_id = $this->row()->listing_id;
        return new Listing($listing_id);
    }

    public function error_portions()
    {
        $error_portions = $this->row()->error_portions;
        $error_portions = json_decode($error_portions);
        return $error_portions;
    }

    public function qvariation_id()
    {
        $qvariation_id = $this->row()->qvariation_id;
        return $qvariation_id;
    }

    public function listing_id()
    {
        $listing_id = $this->row()->listing_id;
        return $listing_id;
    }

    public function status()
    {
        $status = $this->row()->status;
        return $status;
    }

    public function reject_reason()
    {
        $reject_reason = $this->row()->reject_reason;
        $reject_reason = $this->unsanitize_text($reject_reason);
        return $reject_reason;
    }

    public function tbl_status_label()
    {
        $qvariation_id = $this->qvariation_id();
        $stmt = $this->db()->prepare("SELECT qc_id FROM $this->ecommerce_qc_tbl WHERE qvariation_id = '$qvariation_id' AND status = 'rejected' ");
        if ($stmt->rowCount()) return $this->status_to_label("Rejected", "danger");

        else return $this->status_label();
    }

    public function status_label()
    {
        $status = $this->status();
        switch ($status) {
            case "pending":
                return $this->status_to_label("Pending", "warning");
                break;
            case "approved":
                return $this->status_to_label("Approved", "success");
                break;
            case "rejected":
                return $this->status_to_label("Rejected", "danger");
                break;
        }
    }

    public function variation_id()
    {
        $variation_id = $this->row()->variation_id;
        return $variation_id;
    }

    public function svariation_id()
    {
        $svariation_id = $this->row()->svariation_id;
        return $svariation_id;
    }

    public function create_highlights($variation_id, $svariation_id)
    {
        $output = '';
        $highlights = $this->listing()->highlights($variation_id, $svariation_id);
        if (!is_array($highlights)) return;
        foreach ($highlights as $text) {
            $text = $this->unsanitize_text($text);
            $output .= ' <input required value="' . $text . '"  type="text" class="mb-4 form-control form-control-solid ">';
        }
        return $output;
    }
}

class Cart extends Basic
{
    public $cart_id;
    private $row;

    function __construct($id)
    {
        if (!self::is_cart_id($id)) throw new Error("$id is not a card id");
        $this->cart_id = $id;
        $this->row = $this->row();
    }

    public static function is_cart_id($cart_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT cart_id FROM $Web->ecommerce_cart_tbl WHERE cart_id = ? ");
        $stmt->execute([$cart_id]);
        return  $stmt->rowCount() ? true : false;
    }

    public static function is_product_in_cart($product_id, $variation_id, $svariation_id, $user_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT * FROM $Web->ecommerce_cart_tbl WHERE product_id = ? AND variation_id = ? AND svariation_id = ? AND user_id = ? AND role = 'cart' ");
        $stmt->execute([$product_id, $variation_id, $svariation_id, $user_id]);
        return $stmt->rowCount() ? true : false;
    }

    public static function is_product_in_wishlist($product_id, $variation_id, $svariation_id, $user_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT * FROM $Web->ecommerce_cart_tbl WHERE product_id = ? AND variation_id = ? AND svariation_id = ? AND user_id = ? AND role = 'wishlist' ");
        $stmt->execute([$product_id, $variation_id, $svariation_id, $user_id]);
        return $stmt->rowCount() ? true : false;
    }

    public static function is_user_cart_product($cart_id, $user_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT * FROM $Web->ecommerce_cart_tbl WHERE cart_id = ? AND user_id = ? AND role = 'cart' ");
        $stmt->execute([$cart_id, $user_id]);
        return $stmt->rowCount() ? true : false;
    }
    public static function is_user_saved_product($cart_id, $user_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT * FROM $Web->ecommerce_cart_tbl WHERE cart_id = ? AND user_id = ? AND role = 'saved' ");
        $stmt->execute([$cart_id, $user_id]);
        return $stmt->rowCount() ? true : false;
    }

    public static function is_user_wishlist_product($cart_id, $user_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT * FROM $Web->ecommerce_cart_tbl WHERE cart_id = ? AND user_id = ? AND role = 'wishlist' ");
        $stmt->execute([$cart_id, $user_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_cart_tbl WHERE cart_id = ? ");
        $stmt->execute([$this->cart_id]);
        return  $stmt->fetch();
    }

    public function product_id()
    {
        $row = $this->row();
        return $row->product_id;
    }

    public function variation_id()
    {
        $row = $this->row();
        return $row->variation_id;
    }
    public function svariation_id()
    {
        $row = $this->row();
        return $row->svariation_id;
    }

    public function quantity()
    {
        $row = $this->row();
        return $row->quantity;
    }

    public function product()
    {
        $product_id = $this->product_id();
        return new Product($product_id);
    }

    public static function cart_products_count($user_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT COUNT(*) as count FROM $Web->ecommerce_cart_tbl WHERE user_id = ? AND role = 'cart' ");
        $stmt->execute([$user_id]);
        return  $stmt->fetch()->count;
    }

    public static function saved_products_count($user_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT COUNT(*) as count FROM $Web->ecommerce_cart_tbl WHERE user_id = ? AND role = 'saved' ");
        $stmt->execute([$user_id]);
        return  $stmt->fetch()->count;
    }

    public static function wishlist_products_count($user_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT COUNT(*) as count FROM $Web->ecommerce_cart_tbl WHERE user_id = ? AND role = 'wishlist' ");
        $stmt->execute([$user_id]);
        return  $stmt->fetch()->count;
    }


    public function quantity_drop($min, $max, $stock = null)
    {
        $Product = new Product($this->product_id());
        if ($Product->status_text($this->variation_id(), $this->svariation_id(), $stock)->type == "success") {
            $output = ' <div data-action="change_quan" >
                                                                        <button type="button" class="btn btn-sm btn-icon btn-color-primary btn-active-light-primary" data-lx-menu-trigger="click" data-lx-menu-placement="bottom-end">
                                                                            <span class="svg-icon svg-icon-2">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                                    <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="currentColor" />
                                                                                </svg>
                                                                            </span>
                                                                        </button>
                                                                        <div class="menu mh-200px scroll-y menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg-light-primary fw-bold w-100px py-3" data-lx-menu="true">
                                                                        ';
            for ($i = $min; $i <= $max; $i++) {
                $output .= '<div class="menu-item px-3">
                               <a class="menu-link flex-stack px-3">' . $i . '</a>
                         </div>';
            }
            return $output . '  </div></div>';
        }
    }

    private function create_card($cart_id)
    {
        $row = $this->row($cart_id);
        $product_id = $row->product_id;
        $variation_id = $row->variation_id;
        $svariation_id = $row->svariation_id;
        $quantity = $row->quantity;
        $Product = new Product($product_id);

        $price = $Product->price($variation_id, $svariation_id) * $quantity;
        $mrp = $Product->mrp($variation_id, $svariation_id) * $quantity;
        $discount = $Product->discount($mrp, $price);
        $price = $Product->formatCurrency($price);
        $mrp = $Product->formatCurrency($mrp);
        $btn = $Product->is_product_available($variation_id, $svariation_id) ? '<button data-action="checkout" class="w-50 w-lg-25 p-0 ms-4 btn text-uppercase btn-lg btn-flex text-primary-alt"><b>Checkout</b></button>' : "";


        $variation_data = "";
        if ($Product->category()->has_variation() && !empty($Product->variation_value($variation_id, $svariation_id))) $variation_data = '<div class="d-flex mb-1">
                       <span class="text-dark">' . $Product->variation_header_text() . ': </span>
                       <span class="ms-2 text-gray-600">' . $Product->variation_value($variation_id, $svariation_id) . '</span>
                   </div>';
        if ($Product->category()->has_svariation() && !empty($Product->svariation_val($variation_id, $svariation_id))) $variation_data .= '<div class="d-flex mb-1">
                       <span class="text-dark">' . $Product->svariation_header_text() . ': </span>
                       <span class="ms-2 text-gray-600">' . $Product->svariation_val($variation_id, $svariation_id) . '</span>
                   </div>';

        return '<div data-id="' . $cart_id . '" class="cart-item border-top border-1 p-2 position-relative border-bottom">
                                                <button style="transform: translateY(-50%);" data-action="remove" class="top-50 btn end-20px btn-icon position-absolute btn-bg-light btn-active-color-primary btn-sm">
                                                    <span class="svg-icon svg-icon-3">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="currentColor"></path>
                                                            <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="currentColor"></path>
                                                            <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="currentColor"></path>
                                                        </svg>
                                                    </span>
                                                </button>
                                                <div class="d-flex">
                                                    <a href="' . $Product->url($variation_id, $svariation_id) . '" class="mw-110px mh-150px">
                                                        <img class="img-fluid mh-100 " src="' . $Product->image($variation_id, $svariation_id) . '" alt="product-image" srcset="">
                                                    </a>
                                                    <div class="ms-4 flex-grow-1">
                                                        <div class="row">
                                                            <div class="col-lg-8">
                                                                <a href="' . $Product->url($variation_id, $svariation_id) . '" class="text-primary-alt fs-4 wrap-text-1">' . $Product->product_name($variation_id, $svariation_id) . 't</a>
                                                                <div class="text-' . $Product->status_text($variation_id, $svariation_id)->code . ' mb-1 small">' . $Product->status_text($variation_id, $svariation_id)->text . '</div>
                                                                <div class="d-flex d-lg-none align-items-baseline mb-1 fw-bolder">
                                                                    <span class="fs-2">' . $price . '</span>
                                                                    <span class="text-gray-600 text-decoration-line-through ms-2 fs-4">' . $mrp . '</span>
                                                                    <span class="text-success ms-2">' . $discount . '% off</span>
                                                                </div>
                                                                ' . $variation_data . '
                                                                <div class="align-center h-20px mb-1">
                                                                    <span class="text-dark">Quantity: </span>
                                                                    <span class="ms-2 text-gray-600">' . $row->quantity . '</span>
                                                                   ' . $this->quantity_drop($Product->minimum_order($variation_id, $svariation_id), $Product->maximum_order($variation_id, $svariation_id)) . '
                                                                </div>
                                                                <div class="d-flex mb-2">
                                                                        <span class="text-dark">Seller: </span>
                                                                        <a href="" class="ms-2">' . $Product->seller()->store_name() . '</a>
                                                                </div>
                                                            </div>

                                                            <div class="col-lg-4">
                                                                <div class="text-muted mb-1 small">Delivery by Wed Sep 08</div>
                                                                <div class="d-none d-lg-flex align-items-baseline fw-bolder">
                                                                    <span class="fs-2">' . $price . '</span>
                                                                    <span class="text-gray-600 text-decoration-line-through ms-2 fs-4">' . $mrp . '</span>
                                                                    <span class="text-success ms-2">' . $discount . '% off</span>
                                                                </div>
                                                            </div>

                                                        </div>
                                                        <div class="align-center">
                                                        <button data-action="save" class="w-50 w-lg-25 p-0 btn text-uppercase btn-lg btn-flex text-primary-alt"><b>Save For Later</b></button>
                                                    ' . $btn . '
                                                    </div>
                                                    </div>
                                                </div>
                                </div>';
    }

    public static function cart_products($user_id)
    {
        global $Web;
        $output = '';
        $stmt = $Web->db()->prepare("SELECT * FROM $Web->ecommerce_cart_tbl WHERE user_id = ? AND role = 'cart' ORDER BY cart_id DESC");
        $stmt->execute([$user_id]);
        while ($row =  $stmt->fetch()) {
            $cart_id = $row->cart_id;
            $Cart = new Cart($cart_id);
            $output .= $Cart->create_card($cart_id);
        }
        return $output;
    }

    private function create_saved_card($cart_id)
    {
        $row = $this->row($cart_id);
        $product_id = $row->product_id;
        $variation_id = $row->variation_id;
        $svariation_id = $row->svariation_id;
        $quantity = 1;
        $Product = new Product($product_id);

        $price = $Product->price($variation_id, $svariation_id) * $quantity;
        $mrp = $Product->mrp($variation_id, $svariation_id) * $quantity;
        $discount = $Product->discount($mrp, $price);
        $price = $Product->formatCurrency($price);
        $mrp = $Product->formatCurrency($mrp);
        $btn = $Product->is_product_available($variation_id, $svariation_id) ? '<div class="align-center">
                                                            <button data-action="move_to_cart" class="w-50 w-lg-25 p-0 btn text-uppercase btn-flex text-primary-alt"><b>Move To Cart</b></button>
                                                        </div>' : "";

        $variation_data = "";
        if ($Product->category()->has_variation() && !empty($Product->variation_value($variation_id, $svariation_id))) $variation_data = '<div class="d-flex mb-1">
                       <span class="text-dark">' . $Product->variation_header_text() . ': </span>
                       <span class="ms-2 text-gray-600">' . $Product->variation_value($variation_id, $svariation_id) . '</span>
                   </div>';
        if ($Product->category()->has_svariation() && !empty($Product->svariation_val($variation_id, $svariation_id))) $variation_data .= '<div class="d-flex mb-1">
                       <span class="text-dark">' . $Product->svariation_header_text() . ': </span>
                       <span class="ms-2 text-gray-600">' . $Product->svariation_val($variation_id, $svariation_id) . '</span>
                   </div>';

        return '<div data-id="' . $cart_id . '" class="saved-item border-top border-1 p-2 position-relative border-bottom">
                                                <button style="transform: translateY(-50%);" data-action="remove" class="top-50 btn end-20px btn-icon position-absolute btn-bg-light btn-active-color-primary btn-sm">
                                                    <span class="svg-icon svg-icon-3">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="currentColor"></path>
                                                            <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="currentColor"></path>
                                                            <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="currentColor"></path>
                                                        </svg>
                                                    </span>
                                                </button>
                                                <div class="d-flex">
                                                    <a href="' . $Product->url($variation_id, $svariation_id) . '" class="mw-110px mh-150px">
                                                        <img class="img-fluid mh-100 " src="' . $Product->image($variation_id, $svariation_id) . '" alt="product-image" srcset="">
                                                    </a>
                                                    <div class="ms-4 flex-grow-1">
                                                        <div class="row">
                                                            <div class="col-lg-8">
                                                                <a href="' . $Product->url($variation_id, $svariation_id) . '" class="text-primary-alt fs-4 wrap-text-1">' . $Product->product_name($variation_id, $svariation_id) . 't</a>
                                                                  <div class="text-' . $Product->status_text($variation_id, $svariation_id)->code . ' mb-2 small">' . $Product->status_text($variation_id, $svariation_id)->text . '</div>
                                                                <div class="d-flex d-lg-none align-items-baseline mb-1 fw-bolder">
                                                                    <span class="fs-2">' . $price . '</span>
                                                                    <span class="text-gray-600 text-decoration-line-through ms-2 fs-4">' . $mrp . '</span>
                                                                    <span class="text-success ms-2">' . $discount . '% off</span>
                                                                </div>
                                                                 ' . $variation_data . '
                                                                <div class="mb-4">
                                                                    <div class="d-flex mb-1">
                                                                        <span class="text-dark">Seller: </span>
                                                                        <a href="" class="ms-2">' . $Product->seller()->store_name() . '</a>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="col-lg-4">
                                                                <div class="d-none d-lg-flex align-items-baseline mb-1 fw-bolder">
                                                                    <span class="fs-2">' . $price . '</span>
                                                                    <span class="text-gray-600 text-decoration-line-through ms-2 fs-4">' . $mrp . '</span>
                                                                    <span class="text-success ms-2">' . $discount . '% off</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        ' . $btn . '
                                                    </div>
                                                </div>
                   </div>';
    }

    public static function saved_products($user_id)
    {
        global $Web;
        $output = '';
        $stmt = $Web->db()->prepare("SELECT * FROM $Web->ecommerce_cart_tbl WHERE user_id = ? AND role = 'saved' ORDER BY cart_id DESC");
        $stmt->execute([$user_id]);

        while ($row =  $stmt->fetch()) {
            $cart_id = $row->cart_id;
            $Cart = new Cart($cart_id);
            $output .= $Cart->create_saved_card($cart_id);
        }
        return $output;
    }


    private function create_wishlist_card($cart_id)
    {
        $row = $this->row($cart_id);
        $product_id = $row->product_id;
        $variation_id = $row->variation_id;
        $svariation_id = $row->svariation_id;
        $quantity = 1;
        $Product = new Product($product_id);

        $price = $Product->price($variation_id, $svariation_id) * $quantity;
        $mrp = $Product->mrp($variation_id, $svariation_id) * $quantity;
        $discount = $Product->discount($mrp, $price);
        $price = $Product->formatCurrency($price);
        $mrp = $Product->formatCurrency($mrp);
        $btn = $Product->is_product_available($variation_id, $svariation_id) ? '<div class="align-center">
                                <button data-action="move_to_cart" class="w-50 w-lg-25 p-0 btn text-uppercase btn-lg btn-flex text-primary-alt"><b>Move To Cart</b></button>
                                                        </div>' : "";
        $variation_data = "";
        if ($Product->category()->has_variation() && !empty($Product->variation_value($variation_id, $svariation_id))) $variation_data = '<div class="d-flex mb-1">
                       <span class="text-dark">' . $Product->variation_header_text() . ': </span>
                       <span class="ms-2 text-gray-600">' . $Product->variation_value($variation_id, $svariation_id) . '</span>
                   </div>';
        if ($Product->category()->has_svariation() && !empty($Product->svariation_val($variation_id, $svariation_id))) $variation_data .= '<div class="d-flex mb-1">
                       <span class="text-dark">' . $Product->svariation_header_text() . ': </span>
                       <span class="ms-2 text-gray-600">' . $Product->svariation_val($variation_id, $svariation_id) . '</span>
                   </div>';

        return '<div data-id="' . $cart_id . '" class="wishlist-item border-top border-1 p-2 position-relative border-bottom">
                                                <button style="transform: translateY(-50%);" data-action="remove" class="top-50 btn end-20px btn-icon position-absolute btn-bg-light btn-active-color-primary btn-sm">
                                                    <span class="svg-icon svg-icon-3">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="currentColor"></path>
                                                            <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="currentColor"></path>
                                                            <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="currentColor"></path>
                                                        </svg>
                                                    </span>
                                                </button>
                                                <div class="d-flex">
                                                    <a href="' . $Product->url($variation_id, $svariation_id) . '" class="mw-110px mh-150px">
                                                        <img class="img-fluid mh-100 " src="' . $Product->image($variation_id, $svariation_id) . '" alt="product-image" srcset="">
                                                    </a>
                                                    <div class="ms-4 flex-grow-1">
                                                        <div class="row">
                                                            <div class="col-lg-8">
                                                                <a href="' . $Product->url($variation_id, $svariation_id) . '" class="text-primary-alt fs-4 wrap-text-1">' . $Product->product_name($variation_id, $svariation_id) . 't</a>
                                                         <div class="text-' . $Product->status_text($variation_id, $svariation_id)->code . ' mb-2 small">' . $Product->status_text($variation_id, $svariation_id)->text . '</div>
                                                                  <div class="d-flex d-lg-none align-items-baseline mb-1 fw-bolder">
                                                                    <span class="fs-2">' . $price . '</span>
                                                                    <span class="text-gray-600 text-decoration-line-through ms-2 fs-4">' . $mrp . '</span>
                                                                    <span class="text-success ms-2">' . $discount . '% off</span>
                                                                            </div>
                                                                    ' . $variation_data . '
                                                              <div class="d-flex mb-1">
                                                                        <span class="text-dark">Seller: </span>
                                                                        <a href="" class="ms-2">' . $Product->seller()->store_name() . '</a>
                                                                    </div>
                                                            </div>
                                                            <div class="col-lg-4">
                                                                 <div class="d-none d-lg-flex align-items-baseline fw-bolder">
                                                                    <span class="fs-2">' . $price . '</span>
                                                                    <span class="text-gray-600 text-decoration-line-through ms-2 fs-4">' . $mrp . '</span>
                                                                    <span class="text-success ms-2">' . $discount . '% off</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                      ' . $btn . '
                                                    </div>
                                                </div>
                   </div>';
    }

    public static function wishlist_products($user_id, $page)
    {
        global $Web;
        $output = new stdClass;
        $output->content = '';

        $total_rows = self::wishlist_products_count($user_id);
        $records_per_page = 10;
        $total_pages = ceil($total_rows / $records_per_page);
        if ($page > $total_pages) $page = 1;
        if (!($page > 0)) $page = 1;
        $offset = ($page - 1) * $records_per_page;

        $stmt = $Web->db()->prepare("SELECT * FROM $Web->ecommerce_cart_tbl WHERE user_id = ? AND role = 'wishlist' ORDER BY cart_id DESC LIMIT $offset,$records_per_page ");
        $stmt->execute([$user_id]);

        while ($row =  $stmt->fetch()) {
            $cart_id = $row->cart_id;
            $Cart = new Cart($cart_id);
            $output->content .= $Cart->create_wishlist_card($cart_id);
        }
        $output->pagination = !$stmt->rowCount() ? "" : $Web->insert_pagination($Web->base_url() . '/wishlist/', $page, $total_pages, true, '?');

        return $output;
    }

    public static function cart_price_details($user_id)
    {
        $output = new stdClass;
        $t_mrp = 0;
        $t_price = 0;
        $available_products = 0;

        global $Web;
        $stmt = $Web->db()->prepare("SELECT * FROM $Web->ecommerce_cart_tbl WHERE user_id = ? AND role = 'cart' ");
        $stmt->execute([$user_id]);

        while ($row =  $stmt->fetch()) {
            $product_id = $row->product_id;
            $variation_id = $row->variation_id;
            $svariation_id = $row->svariation_id;
            $quantity = $row->quantity;
            $Product = new Product($product_id);

            $price = $Product->status_text($variation_id, $svariation_id)->type == "success" ? $Product->price($variation_id, $svariation_id) : 0;
            $mrp = $Product->status_text($variation_id, $svariation_id)->type == "success" ? $Product->mrp($variation_id, $svariation_id) : 0;
            $available_products += $Product->status_text($variation_id, $svariation_id)->type == "success" ? 1 : 0;

            $t_mrp += $mrp * $quantity;
            $t_price += $price * $quantity;
        }
        $output->mrp = $t_mrp;
        $output->price = $t_price;
        $output->available_products = $available_products;
        $output->discount = $t_mrp - $t_price;
        return $output;
    }

    public static function has_products($user_id)
    {
        $count = self::cart_products_count($user_id);
        return $count == 0 ? false : true;
    }

    public static function has_available_products($user_id)
    {
        $count = self::cart_price_details($user_id)->available_products;
        return $count == 0 ? false : true;
    }

    public static function cart_price_details_card($user_id)
    {
        $basic = new Basic();
        $attr = self::has_available_products($user_id) ? "" : " disabled ";
        return '

        <div class="table-responsive">
    <table class="table align-middle table-row-bordered border-light table-row-light last-child-no-border mb-0 fs-6 gy-5">
        <tbody class="fw-bold text-gray-600">
            <tr>
                <td class="text-muted">
                    <div class="d-flex align-items-center">
                        <span class="svg-icon svg-icon-muted svg-icon-2 me-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M3.20001 5.91897L16.9 3.01895C17.4 2.91895 18 3.219 18.1 3.819L19.2 9.01895L3.20001 5.91897Z" fill="black" />
                                <path opacity="0.3" d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21C21.6 10.9189 22 11.3189 22 11.9189V15.9189C22 16.5189 21.6 16.9189 21 16.9189H16C14.3 16.9189 13 15.6189 13 13.9189ZM16 12.4189C15.2 12.4189 14.5 13.1189 14.5 13.9189C14.5 14.7189 15.2 15.4189 16 15.4189C16.8 15.4189 17.5 14.7189 17.5 13.9189C17.5 13.1189 16.8 12.4189 16 12.4189Z" fill="black" />
                                <path d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21V7.91895C21 6.81895 20.1 5.91895 19 5.91895H3C2.4 5.91895 2 6.31895 2 6.91895V20.9189C2 21.5189 2.4 21.9189 3 21.9189H19C20.1 21.9189 21 21.0189 21 19.9189V16.9189H16C14.3 16.9189 13 15.6189 13 13.9189Z" fill="black" />
                            </svg></span>
                        Price (' . self::cart_price_details($user_id)->available_products . ' items)
                    </div>
                </td>
                <td class="fw-bolder text-end">' . $basic->formatCurrency(self::cart_price_details($user_id)->mrp) . '</td>
            </tr>
            <tr>
                <td class="text-muted">
                    <div class="d-flex align-items-center">
                        <span class="svg-icon svg-icon-2 me-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M18 22H6C5.4 22 5 21.6 5 21V8C6.6 6.4 7.4 5.6 9 4H15C16.6 5.6 17.4 6.4 19 8V21C19 21.6 18.6 22 18 22ZM12 5.5C11.2 5.5 10.5 6.2 10.5 7C10.5 7.8 11.2 8.5 12 8.5C12.8 8.5 13.5 7.8 13.5 7C13.5 6.2 12.8 5.5 12 5.5Z" fill="black" />
                                <path d="M12 7C11.4 7 11 6.6 11 6V3C11 2.4 11.4 2 12 2C12.6 2 13 2.4 13 3V6C13 6.6 12.6 7 12 7ZM15.1 10.6C15.1 10.5 15.1 10.4 15 10.3C14.9 10.2 14.8 10.2 14.7 10.2C14.6 10.2 14.5 10.2 14.4 10.3C14.3 10.4 14.3 10.5 14.2 10.6L9 19.1C8.9 19.2 8.89999 19.3 8.89999 19.4C8.89999 19.5 8.9 19.6 9 19.7C9.1 19.8 9.2 19.8 9.3 19.8C9.5 19.8 9.6 19.7 9.8 19.5L15 11.1C15 10.8 15.1 10.7 15.1 10.6ZM11 11.6C10.9 11.3 10.8 11.1 10.6 10.8C10.4 10.6 10.2 10.4 10 10.3C9.8 10.2 9.50001 10.1 9.10001 10.1C8.60001 10.1 8.3 10.2 8 10.4C7.7 10.6 7.49999 10.9 7.39999 11.2C7.29999 11.6 7.2 12 7.2 12.6C7.2 13.1 7.3 13.5 7.5 13.9C7.7 14.3 7.9 14.5 8.2 14.7C8.5 14.9 8.8 14.9 9.2 14.9C9.8 14.9 10.3 14.7 10.6 14.3C11 13.9 11.1 13.3 11.1 12.5C11.1 12.3 11.1 11.9 11 11.6ZM9.8 13.8C9.7 14.1 9.5 14.2 9.2 14.2C9 14.2 8.8 14.1 8.7 14C8.6 13.9 8.5 13.7 8.5 13.5C8.5 13.3 8.39999 13 8.39999 12.6C8.39999 12.2 8.4 11.9 8.5 11.7C8.5 11.5 8.6 11.3 8.7 11.2C8.8 11.1 9 11 9.2 11C9.5 11 9.7 11.1 9.8 11.4C9.9 11.7 10 12 10 12.6C10 13.2 9.9 13.6 9.8 13.8ZM16.5 16.1C16.4 15.8 16.3 15.6 16.1 15.4C15.9 15.2 15.7 15 15.5 14.9C15.3 14.8 15 14.7 14.6 14.7C13.9 14.7 13.4 14.9 13.1 15.3C12.8 15.7 12.6 16.3 12.6 17.1C12.6 17.6 12.7 18 12.9 18.4C13.1 18.7 13.3 19 13.6 19.2C13.9 19.4 14.2 19.5 14.6 19.5C15.2 19.5 15.7 19.3 16 18.9C16.4 18.5 16.5 17.9 16.5 17.1C16.7 16.8 16.6 16.4 16.5 16.1ZM15.3 18.4C15.2 18.7 15 18.8 14.7 18.8C14.4 18.8 14.2 18.7 14.1 18.4C14 18.1 13.9 17.7 13.9 17.2C13.9 16.8 13.9 16.5 14 16.3C14.1 16.1 14.1 15.9 14.2 15.8C14.3 15.7 14.5 15.6 14.7 15.6C15 15.6 15.2 15.7 15.3 16C15.4 16.2 15.5 16.6 15.5 17.2C15.5 17.7 15.4 18.1 15.3 18.4Z" fill="black" />
                            </svg>
                        </span>Discount
                    </div>
                </td>
                <td class="fw-bolder text-end">-' . $basic->formatCurrency(self::cart_price_details($user_id)->discount) . '
                </td>
            </tr>
            <tr id="totalAmtRow">
                <td class="text-muted">
                    <div class="d-flex align-items-center">
                        <span class="svg-icon svg-icon-muted svg-icon-2  me-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M3.20001 5.91897L16.9 3.01895C17.4 2.91895 18 3.219 18.1 3.819L19.2 9.01895L3.20001 5.91897Z" fill="black" />
                                <path opacity="0.3" d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21C21.6 10.9189 22 11.3189 22 11.9189V15.9189C22 16.5189 21.6 16.9189 21 16.9189H16C14.3 16.9189 13 15.6189 13 13.9189ZM16 12.4189C15.2 12.4189 14.5 13.1189 14.5 13.9189C14.5 14.7189 15.2 15.4189 16 15.4189C16.8 15.4189 17.5 14.7189 17.5 13.9189C17.5 13.1189 16.8 12.4189 16 12.4189Z" fill="black" />
                                <path d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21V7.91895C21 6.81895 20.1 5.91895 19 5.91895H3C2.4 5.91895 2 6.31895 2 6.91895V20.9189C2 21.5189 2.4 21.9189 3 21.9189H19C20.1 21.9189 21 21.0189 21 19.9189V16.9189H16C14.3 16.9189 13 15.6189 13 13.9189Z" fill="black" />
                            </svg></span>Total Amount
                    </div>
                </td>
                <td class="fw-bolder text-end">' . $basic->formatCurrency(self::cart_price_details($user_id)->price) . '</td>
            </tr>
        </tbody>
    </table>
</div>

            <button ' . $attr . ' id="checkout" class="btn w-100 btn-light-primary">Checkout</button>';
    }
}

class Checkout extends Cart
{
    public $cart_id;

    function __construct($id)
    {
        $this->cart_id = $id;
    }

    public static function is_user_checkout_product($cart_id, $user_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT * FROM $Web->ecommerce_cart_tbl WHERE cart_id = ? AND user_id = ? AND role = 'checkout' ");
        $stmt->execute([$cart_id, $user_id]);
        return $stmt->rowCount() ? true : false;
    }

    public static function products_count($user_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT COUNT(*) as count FROM $Web->ecommerce_cart_tbl WHERE user_id = ? AND role = 'checkout' ");
        $stmt->execute([$user_id]);
        return  $stmt->fetch()->count;
    }

    public static function has_products($user_id)
    {
        $products_count = self::products_count($user_id);
        return $products_count == 0 ? false : true;
    }

    public static function clear_checkout($user_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("DELETE FROM $Web->ecommerce_cart_tbl WHERE user_id = ? AND role = 'checkout' ");
        $query = $stmt->execute([$user_id]);
        if (!$query) Errors::response("Something went wrong");
    }

    public function checkout_stock($variation_id, $svariation_id)
    {
        global $LogUser;
        $stock = $this->product()->real_stock($variation_id, $svariation_id);

        $rangeTime = strtotime('-10 minutes');
        $product_id = $this->product_id();
        // 
        $stmt = $this->db()->prepare("SELECT SUM(quantity) as reserved_stock FROM $this->ecommerce_cart_tbl WHERE last_updated >= ? AND product_id = ? AND variation_id = ? AND svariation_id = ? AND user_id != ? ");
        $stmt->execute([$rangeTime, $product_id, $variation_id, $svariation_id, $LogUser->user_id]);

        $reserved_stock = $stmt->fetch()->reserved_stock;
        return $stock - $reserved_stock;
    }

    public function maximum_order($variation_id, $svariation_id)
    {
        global $LogUser;
        $real_maximum_order = $this->product()->real_maximum_order($variation_id, $svariation_id);
        $checkout_stock = $this->checkout_stock($variation_id, $svariation_id);
        if ($real_maximum_order > $checkout_stock) $real_maximum_order = $checkout_stock;

        //     echo $real_maximum_order;

        //     $rangeTime = strtotime('-10 minutes');
        //     $product_id = $this->product_id();
        //     // 
        //     $stmt = $this->db()->prepare("SELECT SUM(quantity) as reserved_stock FROM $this->ecommerce_cart_tbl WHERE last_updated >= ? AND product_id = ? AND variation_id = ? AND svariation_id = ? AND user_id != ? ");
        //     $stmt->execute([$rangeTime, $product_id, $variation_id, $svariation_id, $LogUser->user_id]);

        //    echo $reserved_stock = $stmt->fetch()->reserved_stock;
        //     $maximum_order = $real_maximum_order - $reserved_stock;
        // echo $maximum_order;
        return $real_maximum_order;
    }

    private function create_card($cart_id)
    {
        $cart = new Cart($cart_id);
        $row = $cart->row($cart_id);
        $product_id = $row->product_id;
        $variation_id = $row->variation_id;
        $svariation_id = $row->svariation_id;
        $quantity = $row->quantity;
        $Product = new Product($product_id);

        $price = $Product->price($variation_id, $svariation_id) * $quantity;
        $mrp = $Product->mrp($variation_id, $svariation_id) * $quantity;
        $discount = $Product->discount($mrp, $price);
        $price = $Product->formatCurrency($price);
        $mrp = $Product->formatCurrency($mrp);

        $variation_data = "";
        if ($Product->category()->has_variation() && !empty($Product->variation_value($variation_id, $svariation_id))) $variation_data = '<div class="d-flex mb-1">
                       <span class="text-dark">' . $Product->variation_header_text() . ': </span>
                       <span class="ms-2 text-gray-600">' . $Product->variation_value($variation_id, $svariation_id) . '</span>
                   </div>';
        if ($Product->category()->has_svariation() && !empty($Product->svariation_val($variation_id, $svariation_id))) $variation_data .= '<div class="d-flex mb-1">
                       <span class="text-dark">' . $Product->svariation_header_text() . ': </span>
                       <span class="ms-2 text-gray-600">' . $Product->svariation_val($variation_id, $svariation_id) . '</span>
                   </div>';

        return '<div data-id="' . $cart_id . '" class="checkout-item border-top border-1 p-2 position-relative border-bottom">
       <button style="transform: translateY(-50%);" data-action="remove" class="top-50 btn end-20px btn-icon position-absolute btn-bg-light btn-active-color-primary btn-sm">
           <span class="svg-icon svg-icon-3">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                   <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="currentColor"></path>
                   <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="currentColor"></path>
                   <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="currentColor"></path>
               </svg>
           </span>
       </button>
       <div class="d-flex">
           <a href="' . $Product->url($variation_id, $svariation_id) . '" class="mw-110px mh-150px">
               <img class="img-fluid mh-100 " src="' . $Product->image($variation_id, $svariation_id) . '" alt="product-image" srcset="">
           </a>
           <div class="ms-4 flex-grow-1">
               <div class="row">
                   <div class="col-lg-8">
                       <a href="' . $Product->url($variation_id, $svariation_id) . '" class="text-primary-alt fs-4 wrap-text-1">' . $Product->product_name($variation_id, $svariation_id) . 't</a>
                          <div class="text-' . $Product->status_text($variation_id, $svariation_id, $this->checkout_stock($variation_id, $svariation_id))->code . ' mb-2 small">' . $Product->status_text($variation_id, $svariation_id, $this->checkout_stock($variation_id, $svariation_id))->text . '</div>
                        <div class="d-flex d-lg-none align-items-baseline mb-1 fw-bolder">
                                                                    <span class="fs-2">' . $price . '</span>
                                                                    <span class="text-gray-600 text-decoration-line-through ms-2 fs-4">' . $mrp . '</span>
                                                                    <span class="text-success ms-2">' . $discount . '% off</span>
                             </div>
                             ' . $variation_data . '
                      <div class="align-center h-20px mb-1">
                           <span class="text-dark">Quantity: </span>
                           <span class="ms-2 text-gray-600">' . $row->quantity . '</span>
                          ' . $cart->quantity_drop($Product->minimum_order($variation_id, $svariation_id), $this->maximum_order($variation_id, $svariation_id), $this->checkout_stock($variation_id, $svariation_id)) . '
                       </div>
                       <div class="d-flex mb-1">
                               <span class="text-dark">Seller: </span>
                               <a href="" class="ms-2">' . $Product->seller()->store_name() . '</a>
                           </div>
                   </div>

                   <div class="col-lg-4">
                       <div class="text-muted small">Delivery by Wed Sep 08</div>
                      <div class="d-none d-lg-flex align-items-baseline fw-bolder">
                           <span class="fs-2">' . $price . '</span>
                           <span class="text-gray-600 text-decoration-line-through ms-2 fs-4">' . $mrp . '</span>
                           <span class="text-success ms-2">' . $discount . '% off</span>
                       </div>
                   </div>
               </div>
           </div>
       </div>
   </div>';
    }

    public static function products($user_id)
    {
        global $Web;
        $output = '';
        $stmt = $Web->db()->prepare("SELECT cart_id FROM $Web->ecommerce_cart_tbl WHERE user_id = ? AND role = 'checkout' ORDER BY cart_id DESC");
        $stmt->execute([$user_id]);

        while ($row =  $stmt->fetch()) {
            $cart_id = $row->cart_id;
            $checkout = new self($cart_id);
            $output .= $checkout->create_card($cart_id);
        }
        return $output;
    }

    public static function is_cod_available($user_id)
    {
        if (!PaymentMethod::is_COD_Active()) return false;
        global $Web;
        $stmt = $Web->db()->prepare("SELECT product_id,variation_id,svariation_id FROM $Web->ecommerce_cart_tbl WHERE user_id = ? AND role = 'checkout' ");
        $stmt->execute([$user_id]);

        while ($row =  $stmt->fetch()) {
            $product_id = $row->product_id;
            $variation_id = $row->variation_id;
            $svariation_id = $row->svariation_id;
            $Product = new Product($product_id);
            if (!$Product->is_cod_available($variation_id, $svariation_id)) return false;
        }
        return true;
    }

    public static function price_details($user_id)
    {
        $output = new stdClass;
        $t_mrp = 0;
        $t_price = 0;

        global $Web;
        $stmt = $Web->db()->prepare("SELECT * FROM $Web->ecommerce_cart_tbl WHERE user_id = ? AND role = 'checkout' ");
        $stmt->execute([$user_id]);

        while ($row =  $stmt->fetch()) {
            $product_id = $row->product_id;
            $variation_id = $row->variation_id;
            $svariation_id = $row->svariation_id;
            $quantity = $row->quantity;
            $Product = new Product($product_id);

            $mrp = $Product->mrp($variation_id, $svariation_id);
            $price = $Product->price($variation_id, $svariation_id);

            $t_mrp += $mrp * $quantity;
            $t_price += $price * $quantity;
        }
        $output->mrp = $t_mrp;
        $output->price = $t_price;
        $output->discount = $t_mrp - $t_price;
        return $output;
    }

    public static function price_details_card($user_id)
    {
        $data = self::price_details($user_id);
        global $Web;
        return '
        <div class="table-responsive">
                                                    <table class="table align-middle table-row-bordered border-light table-row-light last-child-no-border mb-0 fs-6 gy-5">
                                                        <tbody class="fw-bold text-gray-600">
                                                            <tr>
                                                                <td class="text-muted">
                                                                    <div class="d-flex align-items-center">
                                                                        <span class="svg-icon svg-icon-muted svg-icon-2 me-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                                <path opacity="0.3" d="M3.20001 5.91897L16.9 3.01895C17.4 2.91895 18 3.219 18.1 3.819L19.2 9.01895L3.20001 5.91897Z" fill="black" />
                                                                                <path opacity="0.3" d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21C21.6 10.9189 22 11.3189 22 11.9189V15.9189C22 16.5189 21.6 16.9189 21 16.9189H16C14.3 16.9189 13 15.6189 13 13.9189ZM16 12.4189C15.2 12.4189 14.5 13.1189 14.5 13.9189C14.5 14.7189 15.2 15.4189 16 15.4189C16.8 15.4189 17.5 14.7189 17.5 13.9189C17.5 13.1189 16.8 12.4189 16 12.4189Z" fill="black" />
                                                                                <path d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21V7.91895C21 6.81895 20.1 5.91895 19 5.91895H3C2.4 5.91895 2 6.31895 2 6.91895V20.9189C2 21.5189 2.4 21.9189 3 21.9189H19C20.1 21.9189 21 21.0189 21 19.9189V16.9189H16C14.3 16.9189 13 15.6189 13 13.9189Z" fill="black" />
                                                                            </svg></span>
                                                                        Price (' . self::products_count($user_id) . ' items)
                                                                    </div>
                                                                </td>
                                                                <td class="fw-bolder text-end">' . $Web->formatCurrency($data->mrp) . '</td>
                                                            </tr>
                                                            <tr>
                                                                <td class="text-muted">
                                                                    <div class="d-flex align-items-center">
                                                                        <span class="svg-icon svg-icon-2 me-2">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                                <path opacity="0.3" d="M18 22H6C5.4 22 5 21.6 5 21V8C6.6 6.4 7.4 5.6 9 4H15C16.6 5.6 17.4 6.4 19 8V21C19 21.6 18.6 22 18 22ZM12 5.5C11.2 5.5 10.5 6.2 10.5 7C10.5 7.8 11.2 8.5 12 8.5C12.8 8.5 13.5 7.8 13.5 7C13.5 6.2 12.8 5.5 12 5.5Z" fill="black" />
                                                                                <path d="M12 7C11.4 7 11 6.6 11 6V3C11 2.4 11.4 2 12 2C12.6 2 13 2.4 13 3V6C13 6.6 12.6 7 12 7ZM15.1 10.6C15.1 10.5 15.1 10.4 15 10.3C14.9 10.2 14.8 10.2 14.7 10.2C14.6 10.2 14.5 10.2 14.4 10.3C14.3 10.4 14.3 10.5 14.2 10.6L9 19.1C8.9 19.2 8.89999 19.3 8.89999 19.4C8.89999 19.5 8.9 19.6 9 19.7C9.1 19.8 9.2 19.8 9.3 19.8C9.5 19.8 9.6 19.7 9.8 19.5L15 11.1C15 10.8 15.1 10.7 15.1 10.6ZM11 11.6C10.9 11.3 10.8 11.1 10.6 10.8C10.4 10.6 10.2 10.4 10 10.3C9.8 10.2 9.50001 10.1 9.10001 10.1C8.60001 10.1 8.3 10.2 8 10.4C7.7 10.6 7.49999 10.9 7.39999 11.2C7.29999 11.6 7.2 12 7.2 12.6C7.2 13.1 7.3 13.5 7.5 13.9C7.7 14.3 7.9 14.5 8.2 14.7C8.5 14.9 8.8 14.9 9.2 14.9C9.8 14.9 10.3 14.7 10.6 14.3C11 13.9 11.1 13.3 11.1 12.5C11.1 12.3 11.1 11.9 11 11.6ZM9.8 13.8C9.7 14.1 9.5 14.2 9.2 14.2C9 14.2 8.8 14.1 8.7 14C8.6 13.9 8.5 13.7 8.5 13.5C8.5 13.3 8.39999 13 8.39999 12.6C8.39999 12.2 8.4 11.9 8.5 11.7C8.5 11.5 8.6 11.3 8.7 11.2C8.8 11.1 9 11 9.2 11C9.5 11 9.7 11.1 9.8 11.4C9.9 11.7 10 12 10 12.6C10 13.2 9.9 13.6 9.8 13.8ZM16.5 16.1C16.4 15.8 16.3 15.6 16.1 15.4C15.9 15.2 15.7 15 15.5 14.9C15.3 14.8 15 14.7 14.6 14.7C13.9 14.7 13.4 14.9 13.1 15.3C12.8 15.7 12.6 16.3 12.6 17.1C12.6 17.6 12.7 18 12.9 18.4C13.1 18.7 13.3 19 13.6 19.2C13.9 19.4 14.2 19.5 14.6 19.5C15.2 19.5 15.7 19.3 16 18.9C16.4 18.5 16.5 17.9 16.5 17.1C16.7 16.8 16.6 16.4 16.5 16.1ZM15.3 18.4C15.2 18.7 15 18.8 14.7 18.8C14.4 18.8 14.2 18.7 14.1 18.4C14 18.1 13.9 17.7 13.9 17.2C13.9 16.8 13.9 16.5 14 16.3C14.1 16.1 14.1 15.9 14.2 15.8C14.3 15.7 14.5 15.6 14.7 15.6C15 15.6 15.2 15.7 15.3 16C15.4 16.2 15.5 16.6 15.5 17.2C15.5 17.7 15.4 18.1 15.3 18.4Z" fill="black" />
                                                                            </svg>
                                                                        </span>Discount
                                                                    </div>
                                                                </td>
                                                                <td class="fw-bolder text-end">-' . $Web->formatCurrency($data->discount) . '
                                                                </td>
                                                            </tr>
                                                            <tr id="totalAmtRow">
                                                                <td class="text-muted">
                                                                    <div class="d-flex align-items-center">
                                                                        <span class="svg-icon svg-icon-muted svg-icon-2  me-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                                <path opacity="0.3" d="M3.20001 5.91897L16.9 3.01895C17.4 2.91895 18 3.219 18.1 3.819L19.2 9.01895L3.20001 5.91897Z" fill="black" />
                                                                                <path opacity="0.3" d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21C21.6 10.9189 22 11.3189 22 11.9189V15.9189C22 16.5189 21.6 16.9189 21 16.9189H16C14.3 16.9189 13 15.6189 13 13.9189ZM16 12.4189C15.2 12.4189 14.5 13.1189 14.5 13.9189C14.5 14.7189 15.2 15.4189 16 15.4189C16.8 15.4189 17.5 14.7189 17.5 13.9189C17.5 13.1189 16.8 12.4189 16 12.4189Z" fill="black" />
                                                                                <path d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21V7.91895C21 6.81895 20.1 5.91895 19 5.91895H3C2.4 5.91895 2 6.31895 2 6.91895V20.9189C2 21.5189 2.4 21.9189 3 21.9189H19C20.1 21.9189 21 21.0189 21 19.9189V16.9189H16C14.3 16.9189 13 15.6189 13 13.9189Z" fill="black" />
                                                                            </svg></span>Total Amount
                                                                    </div>
                                                                </td>
                                                                <td class="fw-bolder text-end">' . $Web->formatCurrency($data->price) . '</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>';
    }

    public static function addresses($user_id)
    {
        global $Web;
        $output = '';
        $stmt = $Web->db()->prepare("SELECT address_id FROM $Web->ecommerce_address_tbl WHERE user_id = ? ");
        $stmt->execute([$user_id]);

        while ($row =  $stmt->fetch()) {
            $output .= self::address_card($row->address_id, $user_id);
        }
        return $output;
    }

    public static function address_card($address_id, $user_id)
    {
        $Address = new Address($address_id);
        $class = $Address->is_default()  == "yes" ? " success-active" : "";

        return '<div data-id="' . $Address->address_id . '" class="address-card cursor-pointer mb-4 border ' . $class . ' align-justify-between p-6 ">
                    <div class="d-flex flex-column py-2">
                        <div class="d-flex align-items-center fs-5 fw-bolder mb-5">' . $Address->full_name() . ' ' . $Address->mobile_number() . '
                            <span class="badge badge-light-success text-uppercase fs-7 ms-2">' . $Address->address_type() . '</span>
                        </div>
                        <div class="fs-6 fw-bold text-gray-600 word-break">' . $Address->full_address() . ' </div>
                    </div>
                    <div class="d-flex align-items-center py-2">
                        <button data-action="edit" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                            <span class="svg-icon svg-icon-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                    <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                </svg>
                            </span>
                        </button>
                    </div>
            </div>';
    }
}

class Analytics extends Basic
{

    public static function product_views_graph($from, $to, $user_id)
    {
        global $Web;
        $output = [];
        $output["views"] = 0;
        $from = strtotime($from);
        $to = strtotime($to);
        if ($from > $to) return;
        for ($i = $from; $i <= $to; $i += 24 * 60 * 60) {
            $sql = "SELECT SUM(views) as views FROM $Web->ecommerce_product_views_tbl INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_product_views_tbl.product_id= $Web->ecommerce_products_tbl.product_id WHERE $Web->ecommerce_products_tbl.user_id = ? AND $Web->ecommerce_product_views_tbl.date = '$i' ";
            $stmt = $Web->db()->prepare($sql);
            $stmt->execute([$user_id]);
            $views = $stmt->fetch()->views ?? 0;
            $date = date("d M", $i);
            $output["x"][] = $date;
            $output["y"][] = $views;
            $output["views"] += $views;
        }
        return $output;
    }
    public static function product_sells_graph($from, $to, $user_id)
    {
        global $Web;
        $output = new stdClass;
        $output->sells = 0;
        $from = strtotime($from);
        $to = strtotime($to);
        if ($from > $to) return;
        for ($i = $from; $i <= $to; $i += 24 * 60 * 60) {
            $i_to = $i + (24 * 3600) - 1;

            $sql_o = "SELECT COUNT(order_id) FROM $Web->ecommerce_orders_tbl INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id= $Web->ecommerce_products_tbl.product_id WHERE $Web->ecommerce_products_tbl.user_id = ? AND $Web->ecommerce_orders_tbl.ordered_date BETWEEN '$i' AND '$i_to' ";

            $sql = "SELECT COUNT(order_id) FROM $Web->ecommerce_orders_tbl INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id= $Web->ecommerce_products_tbl.product_id WHERE $Web->ecommerce_products_tbl.user_id = ? AND $Web->ecommerce_orders_tbl.ordered_date BETWEEN '$i' AND '$i_to' AND labelled_on IS NOT NULL  ";

            $sql_d = "SELECT COUNT(order_id) FROM $Web->ecommerce_orders_tbl INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id= $Web->ecommerce_products_tbl.product_id WHERE $Web->ecommerce_products_tbl.user_id = ? AND $Web->ecommerce_orders_tbl.delivered_on BETWEEN '$i' AND '$i_to' AND status = 'DELIVERED' ";

            $sql_r = "SELECT COUNT(order_id) FROM $Web->ecommerce_orders_tbl INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id= $Web->ecommerce_products_tbl.product_id WHERE $Web->ecommerce_products_tbl.user_id = ? AND $Web->ecommerce_orders_tbl.rejected_on BETWEEN '$i' AND '$i_to' AND status = 'REJECTED' ";

            $sql_c = "SELECT COUNT(order_id) FROM $Web->ecommerce_orders_tbl INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id= $Web->ecommerce_products_tbl.product_id WHERE $Web->ecommerce_products_tbl.user_id = ? AND $Web->ecommerce_orders_tbl.cancelled_on BETWEEN '$i' AND '$i_to' AND status = 'CANCELLED' ";

            $sql_ret = "SELECT COUNT($Web->ecommerce_orders_tbl.order_id) FROM $Web->ecommerce_orders_tbl 
            INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id= $Web->ecommerce_products_tbl.product_id  INNER JOIN $Web->ecommerce_return_orders_tbl ON $Web->ecommerce_orders_tbl.order_id = $Web->ecommerce_return_orders_tbl.order_id  WHERE $Web->ecommerce_products_tbl.user_id = ? AND $Web->ecommerce_return_orders_tbl.requested_date BETWEEN '$i' AND '$i_to' AND $Web->ecommerce_orders_tbl.status = 'RETURNED' ";

            $sql_rep = "SELECT COUNT($Web->ecommerce_orders_tbl.order_id) FROM $Web->ecommerce_orders_tbl 
            INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id= $Web->ecommerce_products_tbl.product_id INNER JOIN $Web->ecommerce_replacement_orders_tbl ON $Web->ecommerce_orders_tbl.order_id= $Web->ecommerce_replacement_orders_tbl.order_id  WHERE $Web->ecommerce_products_tbl.user_id = ? AND $Web->ecommerce_replacement_orders_tbl.requested_date BETWEEN '$i' AND '$i_to' AND $Web->ecommerce_orders_tbl.status = 'REPLACEMENT' ";


            $orders = $Web->db()->prepare($sql_o);
            $orders->execute([$user_id]);
            $orders = $orders->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $sells = $Web->db()->prepare($sql);
            $sells->execute([$user_id]);
            $sells = $sells->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $delivered = $Web->db()->prepare($sql_d);
            $delivered->execute([$user_id]);
            $delivered = $delivered->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $rejected = $Web->db()->prepare($sql_r);
            $rejected->execute([$user_id]);
            $rejected = $rejected->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $cancelled = $Web->db()->prepare($sql_c);
            $cancelled->execute([$user_id]);
            $cancelled = $cancelled->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $returned = $Web->db()->prepare($sql_ret);
            $returned->execute([$user_id]);
            $returned = $returned->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $replacement = $Web->db()->prepare($sql_rep);
            $replacement->execute([$user_id]);
            $replacement = $replacement->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $date = date("d M", $i);
            $output->x[] = $date;
            $output->y[] = $sells;
            $output->orders[] = $orders;
            $output->delivered[] = $delivered;
            $output->rejected[] = $rejected;
            $output->cancelled[] = $cancelled;
            $output->returned[] = $returned;
            $output->replacement[] = $replacement;
            $output->sells += $sells;
        }
        return $output;
    }

    public static function product_earnings_graph($from, $to, $user_id)
    {
        global $Web;
        $output = new stdClass;
        $output->earning_text = 0;
        $from = strtotime($from);
        $to = strtotime($to);
        if ($from > $to) return;
        for ($i = $from; $i <= $to; $i += 24 * 60 * 60) {
            $i_to = $i + (24 * 3600) - 1;

            $sql = "SELECT SUM(total_price) FROM $Web->ecommerce_orders_tbl INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id= $Web->ecommerce_products_tbl.product_id WHERE $Web->ecommerce_products_tbl.user_id = ? AND ( $Web->ecommerce_orders_tbl.ordered_date BETWEEN '$i' AND '$i_to') AND labelled_on IS NOT NULL  ";

            $sql_c = "SELECT SUM(total_price) FROM $Web->ecommerce_orders_tbl INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id= $Web->ecommerce_products_tbl.product_id WHERE $Web->ecommerce_products_tbl.user_id = ? AND $Web->ecommerce_orders_tbl.ordered_date BETWEEN '$i' AND '$i_to' AND status = 'REJECTED' ";

            $sql_ret = "SELECT SUM(total_price) FROM $Web->ecommerce_orders_tbl 
            INNER JOIN $Web->ecommerce_products_tbl ON $Web->ecommerce_orders_tbl.product_id= $Web->ecommerce_products_tbl.product_id INNER JOIN $Web->ecommerce_return_orders_tbl ON $Web->ecommerce_orders_tbl.order_id = $Web->ecommerce_return_orders_tbl.order_id   WHERE $Web->ecommerce_products_tbl.user_id = ? AND $Web->ecommerce_return_orders_tbl.requested_date BETWEEN '$i' AND '$i_to' AND $Web->ecommerce_orders_tbl.status = 'RETURNED' ";

            $stmt = $Web->db()->prepare($sql);
            $stmt->execute([$user_id]);
            $earnings = $stmt->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $stmt = $Web->db()->prepare($sql_c);
            $stmt->execute([$user_id]);
            $rejected_earnings = $stmt->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $stmt = $Web->db()->prepare($sql_ret);
            $stmt->execute([$user_id]);
            $return_earnings = $stmt->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $date = date("d M", $i);
            $output->x[] = $date;
            $output->earnings[] = $earnings;
            $output->rejected[] = $rejected_earnings;
            $output->returned[] = $return_earnings;
            $output->earning_text += $earnings;
        }
        $output->earning_text = $Web->formatCurrency($output->earning_text);
        return $output;
    }


    public static function single_product_views_graph($product_id, $variation_id, $svariation_id, $from, $to)
    {
        global $Web;
        $output = new stdClass;
        $output->views = 0;
        $from = strtotime($from);
        $to = strtotime($to);
        if ($from > $to) return;
        for ($i = $from; $i <= $to; $i += 24 * 60 * 60) {
            $i_to = $i + (24 * 3600) - 1;
            $sql = "SELECT SUM(views) as views FROM $Web->ecommerce_product_views_tbl WHERE date = '$i' AND product_id = ? AND variation_id = ? AND svariation_id = ? ";
            $sql = $Web->db()->prepare($sql);
            $sql->execute([$product_id, $variation_id, $svariation_id]);

            $views = $sql->fetch()->views ?? 0;
            $date = date("d M", $i);
            $output->x[] = $date;
            $output->y[] = $views;
            $output->views += $views;
        }
        return $output;
    }

    public static function single_product_sells_graph($product_id, $variation_id, $svariation_id, $from, $to)
    {
        global $Web;
        $output = new stdClass;
        $output->sells = 0;
        $from = strtotime($from);
        $to = strtotime($to);
        if ($from > $to) return;
        for ($i = $from; $i <= $to; $i += 24 * 60 * 60) {
            $i_to = $i + (24 * 3600) - 1;

            $sql = "SELECT COUNT(order_id) FROM $Web->ecommerce_orders_tbl WHERE product_id = ? AND variation_id = ? AND svariation_id = ? AND ordered_date BETWEEN '$i' AND '$i_to' ";
            $sql = $Web->db()->prepare($sql);
            $sql->execute([$product_id, $variation_id, $svariation_id]);
            $orders = $sql->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $sql = "SELECT COUNT(order_id) FROM $Web->ecommerce_orders_tbl WHERE product_id = ? AND variation_id = ? AND svariation_id = ? AND labelled_on IS NOT NULL AND ordered_date BETWEEN '$i' AND '$i_to'  ";
            $sql = $Web->db()->prepare($sql);
            $sql->execute([$product_id, $variation_id, $svariation_id]);
            $accepted_orders =  $sql->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $sql = "SELECT COUNT(order_id) FROM $Web->ecommerce_orders_tbl WHERE product_id = ? AND variation_id = ? AND svariation_id = ? AND delivered_on BETWEEN '$i' AND '$i_to' AND status = 'DELIVERED'";
            $sql = $Web->db()->prepare($sql);
            $sql->execute([$product_id, $variation_id, $svariation_id]);
            $delivered =  $sql->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $sql = "SELECT COUNT(order_id) FROM $Web->ecommerce_orders_tbl WHERE product_id = ? AND variation_id = ? AND svariation_id = ? AND rejected_on BETWEEN '$i' AND '$i_to' AND status = 'REJECTED'";
            $sql = $Web->db()->prepare($sql);
            $sql->execute([$product_id, $variation_id, $svariation_id]);
            $rejected =  $sql->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $sql = "SELECT COUNT(order_id) FROM $Web->ecommerce_orders_tbl WHERE product_id = ? AND variation_id = ? AND svariation_id = ? AND cancelled_on BETWEEN '$i' AND '$i_to' AND status = 'CANCELLED'";
            $sql = $Web->db()->prepare($sql);
            $sql->execute([$product_id, $variation_id, $svariation_id]);
            $cancelled =  $sql->fetch(PDO::FETCH_NUM)[0] ?? 0;


            $sql = "SELECT COUNT($Web->ecommerce_orders_tbl.order_id) FROM $Web->ecommerce_orders_tbl 
            INNER JOIN $Web->ecommerce_return_orders_tbl ON $Web->ecommerce_orders_tbl.order_id = $Web->ecommerce_return_orders_tbl.order_id WHERE  $Web->ecommerce_return_orders_tbl.requested_date BETWEEN '$i' AND '$i_to' AND $Web->ecommerce_orders_tbl.status = 'RETURNED'  AND $Web->ecommerce_orders_tbl.product_id = ? AND $Web->ecommerce_orders_tbl.variation_id = ? AND $Web->ecommerce_orders_tbl.svariation_id = ? ";
            $sql = $Web->db()->prepare($sql);
            $sql->execute([$product_id, $variation_id, $svariation_id]);
            $returned = $sql->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $sql = "SELECT COUNT($Web->ecommerce_orders_tbl.order_id) FROM $Web->ecommerce_orders_tbl 
            INNER JOIN $Web->ecommerce_replacement_orders_tbl ON $Web->ecommerce_orders_tbl.order_id= $Web->ecommerce_replacement_orders_tbl.order_id WHERE  $Web->ecommerce_replacement_orders_tbl.requested_date BETWEEN '$i' AND '$i_to' AND $Web->ecommerce_orders_tbl.status = 'REPLACEMENT' AND $Web->ecommerce_orders_tbl.product_id = ? AND $Web->ecommerce_orders_tbl.variation_id = ? AND $Web->ecommerce_orders_tbl.svariation_id = ? ";
            $sql = $Web->db()->prepare($sql);
            $sql->execute([$product_id, $variation_id, $svariation_id]);
            $replacement = $sql->fetch(PDO::FETCH_NUM)[0] ?? 0;


            $date = date("d M", $i);
            $output->date[] = $date;
            $output->accepted_orders[] = $accepted_orders;
            $output->orders[] = $orders;
            $output->delivered[] = $delivered;
            $output->rejected[] = $rejected;
            $output->cancelled[] = $cancelled;
            $output->returned[] = $returned;
            $output->replacement[] = $replacement;
            $output->sells += $orders;
        }
        return $output;
    }

    public static function single_product_earnings_graph($product_id, $variation_id, $svariation_id, $from, $to)
    {
        global $Web;
        $output = new stdClass;
        $output->earning_text = 0;
        $from = strtotime($from);
        $to = strtotime($to);
        if ($from > $to) return;
        for ($i = $from; $i <= $to; $i += 24 * 60 * 60) {
            $i_to = $i + (24 * 3600) - 1;

            $sql = "SELECT SUM(total_price) FROM $Web->ecommerce_orders_tbl WHERE product_id = ? AND variation_id = ? AND svariation_id = ? AND  ordered_date BETWEEN '$i' AND '$i_to' AND labelled_on IS NOT NULL  ";

            $sql = $Web->db()->prepare($sql);
            $sql->execute([$product_id, $variation_id, $svariation_id]);
            $earnings = $sql->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $sql = "SELECT SUM(total_price) FROM $Web->ecommerce_orders_tbl WHERE product_id = ? AND variation_id = ? AND svariation_id = ? AND  ordered_date BETWEEN '$i' AND '$i_to' AND status = 'REJECTED'  ";
            $sql = $Web->db()->prepare($sql);
            $sql->execute([$product_id, $variation_id, $svariation_id]);
            $rejected_earnings = $sql->fetch(PDO::FETCH_NUM)[0] ?? 0;

            $sql = "SELECT SUM(total_price) FROM $Web->ecommerce_orders_tbl 
            INNER JOIN $Web->ecommerce_return_orders_tbl ON $Web->ecommerce_orders_tbl.order_id = $Web->ecommerce_return_orders_tbl.order_id  WHERE $Web->ecommerce_orders_tbl.product_id = ? AND $Web->ecommerce_orders_tbl.variation_id = ? AND $Web->ecommerce_orders_tbl.svariation_id = ? AND $Web->ecommerce_return_orders_tbl.requested_date BETWEEN '$i' AND '$i_to' AND $Web->ecommerce_orders_tbl.status = 'RETURNED' ";
            $sql = $Web->db()->prepare($sql);
            $sql->execute([$product_id, $variation_id, $svariation_id]);
            $return_earnings = $sql->fetch(PDO::FETCH_NUM)[0] ?? 0;


            $date = date("d M", $i);
            $output->x[] = $date;
            $output->earnings[] = $earnings;
            $output->rejected[] = $rejected_earnings;
            $output->returned[] = $return_earnings;
            $output->earning_text += $earnings;
        }
        $output->earning_text = $Web->formatCurrency($output->earning_text);
        return $output;
    }
}

class Seller extends User
{
    private $row;
    public $user_id;

    function __construct($user_id)
    {
        global $Login;
        if (!self::is_user_seller($user_id)) throw new Error("$user_id is not valid seller");
        $this->user_id = $user_id;
        $this->row = $this->row();
    }

    public function view_url_by_admin()
    {
        return $this->admin_url() . '/view-seller/?id=' . $this->user_id;
    }

    public static function is_user_seller($user_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT user_id FROM $Web->ecommerce_seller_users_tbl WHERE user_id = ? ");
        $stmt->execute([$user_id]);
        return $stmt->rowCount() ? true : false;
    }

    public static function is_user_id($user_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT user_id FROM $Web->ecommerce_seller_users_tbl WHERE user_id = ? ");
        $stmt->execute([$user_id]);
        return $stmt->rowCount() ? true : false;
    }

    public static function email_by_user_id($user_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT user_id FROM $Web->ecommerce_seller_users_tbl WHERE user_id = ? ");
        $stmt->execute([$user_id]);
        return  $stmt->fetch()->user_id;
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_seller_users_tbl WHERE user_id = ? ");
        $stmt->execute([$this->user_id]);
        return $stmt->fetch();
    }

    public function update()
    {
        $this->row = $this->row();
    }

    public function pickup_address()
    {
        $pickup_address = $this->row()->pickup_address ?? '{}';
        $pickup_address = json_decode($pickup_address, true);
        return (object) $pickup_address;
    }

    public function has_withdraw_details()
    {
        $stmt = $this->db()->prepare("SELECT gateway_id FROM $this->ecommerce_sellers_withdraw_gateways_tbl WHERE user_id = ? ORDER BY date_created DESC");
        $stmt->execute([$this->user_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function contact_details()
    {
        $contact_details = $this->row()->contact_details ?? '{}';
        $contact_details = json_decode($contact_details, true);
        return (object) $contact_details;
    }

    public function seller_since()
    {
        $row = $this->row();
        $seller_since = $row->seller_since;
        return $this->to_date($seller_since);
    }

    public function status()
    {
        $row = $this->row();
        return $row->status;
    }

    public function is_verified()
    {
        return $this->status() == "verified";
    }

    public function status_label()
    {
        $status = $this->status();
        switch ($status) {
            case "unverified":
                return $this->status_to_label("Unverified", "primary");
                break;
            case "pending":
                return $this->status_to_label("Pending", "warning");
                break;
            case "verified":
                return $this->status_to_label("Verified", "success");
                break;
            case "rejected":
                return $this->status_to_label("Rejected", "danger");
                break;
            case "blocked":
                return $this->status_to_label("Blocked", "danger");
                break;
        }
    }

    public function store_name()
    {
        $store_name = $this->row()->store_name;
        return $this->unsanitize_text($store_name);
    }

    public function store_description()
    {
        $store_description = $this->row()->store_description;
        return $this->unsanitize_text($store_description);
    }

    public function store_logo_id()
    {
        // $store_logo_id = $this->row()->store_logo_id;
        // return $store_logo_id;

        return $this->avatar_id();
    }

    public function store_logo()
    {
        // $store_logo_id = $this->store_logo_id();
        // $src = $this->get_file_src($store_logo_id);
        // return $this->is_empty($src) ? $this->get_assets("images/web/avatar.png") : $src;

        return $this->avatar();
    }

    public function rejected_reason()
    {
        $row = $this->row();
        $status_reason = $row->status_reason;
        return $this->unsanitize_text($status_reason);
    }

    private function get_orders_status_count($order_status)
    {
        $sql = "SELECT COUNT(*) as orders FROM $this->ecommerce_orders_tbl INNER JOIN $this->ecommerce_products_tbl ON $this->ecommerce_orders_tbl.product_id = $this->ecommerce_products_tbl.product_id 
         WHERE $this->ecommerce_products_tbl.user_id =? AND $this->ecommerce_orders_tbl.status = ? ";
        $stmt = $this->db()->prepare($sql);
        $stmt->execute([$this->user_id, $order_status]);
        return  $stmt->fetch()->orders;
    }

    private function get_listings_status_count($status)
    {
        switch ($status) {
            case "low_stock":
                $stmt = $this->db()->prepare("SELECT COUNT(*) FROM $this->ecommerce_variations_tbl WHERE  user_id = ? AND low_stock_warning >= stock  ");
                $stmt->execute([$this->user_id]);
                break;
            case "out_of_stock":
                $stmt = $this->db()->prepare("SELECT COUNT(*) FROM $this->ecommerce_variations_tbl WHERE user_id = ? AND stock = '0'  ");
                $stmt->execute([$this->user_id]);
                break;
            case "qc":
                $stmt = $this->db()->prepare("SELECT COUNT(*) FROM $this->ecommerce_qc_tbl WHERE user_id = ? AND status = 'pending' ");
                $stmt->execute([$this->user_id]);
                break;
            case "draft":
                $stmt = $this->db()->prepare("SELECT COUNT(*) FROM $this->ecommerce_listing_variations_tbl WHERE user_id = ? AND is_draft = 'yes' ");
                $stmt->execute([$this->user_id]);
                break;
            default:
                $stmt = $this->db()->prepare("SELECT COUNT(*) FROM $this->ecommerce_variations_tbl WHERE user_id = ? AND status = '$status' ");
                $stmt->execute([$this->user_id]);
                break;
        }

        return  $stmt->fetch(PDO::FETCH_NUM)[0];
    }

    private function get_questions_count($status)
    {

        switch ($status) {
            case "unanswered":

                return $this->get_questions_count("questions") - $this->get_questions_count("answered_by_seller") - $this->get_questions_count("answered_by_customers");

                break;

            case "questions":
                $sql = "SELECT COUNT(question_id) as count FROM $this->ecommerce_product_questions_tbl
                INNER JOIN $this->ecommerce_products_tbl ON $this->ecommerce_product_questions_tbl.product_id = $this->ecommerce_products_tbl.product_id 
                    WHERE $this->ecommerce_products_tbl.user_id = ? ";

                $stmt = $this->db()->prepare($sql);
                $stmt->execute([$this->user_id]);
                break;

            case "answered_by_seller":
                $sql = "SELECT COUNT(answer_id) as count FROM $this->ecommerce_product_answers_tbl 
                INNER JOIN $this->ecommerce_products_tbl ON $this->ecommerce_product_answers_tbl.product_id = $this->ecommerce_products_tbl.product_id 
                    WHERE $this->ecommerce_products_tbl.user_id = ? AND $this->ecommerce_product_answers_tbl.answered_by = ? ";

                $stmt = $this->db()->prepare($sql);
                $stmt->execute([$this->user_id, $this->user_id]);
                break;

            case "answered_by_customers":
                $sql = "SELECT COUNT(answer_id) as count FROM $this->ecommerce_product_answers_tbl 
                INNER JOIN $this->ecommerce_products_tbl ON $this->ecommerce_product_answers_tbl.product_id = $this->ecommerce_products_tbl.product_id 
                    WHERE $this->ecommerce_products_tbl.user_id = ? AND $this->ecommerce_product_answers_tbl.answered_by != ? ";

                $stmt = $this->db()->prepare($sql);
                $stmt->execute([$this->user_id, $this->user_id]);
                break;
        }
        return  $stmt->fetch()->count;
    }

    private function get_return_status_count($status)
    {

        $LogSeller = $GLOBALS["LogSeller"];

        $sql = "SELECT COUNT(*) as returns FROM $this->ecommerce_return_orders_tbl 
        INNER JOIN $this->ecommerce_orders_tbl ON $this->ecommerce_orders_tbl.order_id = $this->ecommerce_return_orders_tbl.order_id
        INNER JOIN $this->ecommerce_products_tbl ON $this->ecommerce_orders_tbl.product_id = $this->ecommerce_products_tbl.product_id
         WHERE $this->ecommerce_products_tbl.user_id = ? AND $this->ecommerce_return_orders_tbl.status = ? ";

        $stmt = $this->db()->prepare($sql);
        $stmt->execute([$LogSeller->user_id, $status]);
        return $stmt->fetch()->returns;
    }

    private function get_replacement_status_count($status)
    {

        $LogSeller = $GLOBALS["LogSeller"];

        $sql = "SELECT COUNT(*) as replacements FROM $this->ecommerce_replacement_orders_tbl 
        INNER JOIN $this->ecommerce_orders_tbl ON $this->ecommerce_orders_tbl.order_id = $this->ecommerce_replacement_orders_tbl.order_id
        INNER JOIN $this->ecommerce_products_tbl ON $this->ecommerce_orders_tbl.product_id = $this->ecommerce_products_tbl.product_id
         WHERE $this->ecommerce_products_tbl.user_id = ? AND $this->ecommerce_replacement_orders_tbl.status = ? ";

        $stmt = $this->db()->prepare($sql);
        $stmt->execute([$LogSeller->user_id, $status]);
        return $stmt->fetch()->replacements;
    }



    public function orders_data()
    {
        $output = new stdClass;
        $output->new_orders = $this->get_orders_status_count("SUCCESS");
        $output->pending_rtd = $this->get_orders_status_count("LABELLED");
        $output->pending_handover = $this->get_orders_status_count("RTD");
        $output->shipped_orders = $this->get_orders_status_count("SHIPPED");
        $output->completed_orders = $this->get_orders_status_count("DELIVERED");
        $output->cancelled_orders = $this->get_orders_status_count("CANCELLED");
        $output->returned_orders = $this->get_orders_status_count("SUCCESS");
        $output->rejected_orders = $this->get_orders_status_count("REJECTED");
        return $output;
    }

    public function returns_data()
    {
        $output = new stdClass;
        $output->requests = $this->get_return_status_count("initiated");
        $output->accepted = $this->get_return_status_count("accepted");
        $output->scheduled_pickup = $this->get_return_status_count("pickup_scheduled");
        $output->completed = $this->get_return_status_count("completed");
        $output->rejected = $this->get_return_status_count("rejected");
        return $output;
    }

    public function replacements_data()
    {
        $output = new stdClass;
        $output->requests = $this->get_replacement_status_count("initiated");
        $output->accepted = $this->get_replacement_status_count("accepted");
        $output->scheduled_pickup = $this->get_replacement_status_count("pickup_scheduled");
        $output->completed = $this->get_replacement_status_count("completed");
        $output->rejected = $this->get_replacement_status_count("rejected");
        return $output;
    }

    public function listings_data()
    {
        $output = new stdClass;
        $output->active_listings = $this->get_listings_status_count("active");
        $output->low_stock_listings = $this->get_listings_status_count("low_stock");
        $output->out_of_stock_listings = $this->get_listings_status_count("out_of_stock");
        $output->inactive_listings = $this->get_listings_status_count("inactive");
        $output->qc_listings = $this->get_listings_status_count("qc");
        $output->archived_listings = $this->get_listings_status_count("archived");
        $output->blocked_listings = $this->get_listings_status_count("blocked");
        $output->draft_listings = $this->get_listings_status_count("draft");
        return $output;
    }

    public function questions_data()
    {
        $output = new stdClass;
        $output->unanswered = $this->get_questions_count("unanswered");
        $output->answered_by_seller = $this->get_questions_count("answered_by_seller");
        $output->answered_by_customers = $this->get_questions_count("answered_by_customers");
        $output->questions = $this->get_questions_count("questions");
        return $output;
    }

    public function products_count()
    {
        $stmt = $this->db()->prepare("SELECT COUNT(svariation_id) as products FROM $this->ecommerce_variations_tbl WHERE user_id = ? ");
        $stmt->execute([$this->user_id]);
        return  $stmt->fetch()->products;
    }

    private function withdraw_gateway_card($gateway_id)
    {
        $WithdrawGateway = new WithdrawGateway($gateway_id);


        $db_labels = $WithdrawGateway->labels();
        $labels = $WithdrawGateway->user_added_labels($this->user_id);

        if (array_keys($labels) !=  array_column($db_labels, "id")) {
            $url = $this->seller_url() . '/withdraw/add-details?id=' . $gateway_id;

            $btn =  '<div class="fs-7 text-danger" >New updates available</div><a href="' . $url . '" class="btn btn-warning" >Update</a> ';
        } else {
            $url = $this->seller_url() . '/withdraw/withdraw-details?id=' . $gateway_id;
            $btn = '<a href="' . $url . '" class="btn btn-success" >Withdraw</a>';
        }

        return '<div class="col-xl-3 col-lg-4 col-md-4 col-sm-6">
                            <div data-id="' . $gateway_id . '" class="card withdraw-card mb-4 text-center">
                                <img style="max-height:540px" src="' . $WithdrawGateway->logo() . '" class="card-img-top" alt="' . $WithdrawGateway->name() . '">
                                <div class="card-body p-4">
                                    <h4 class="card-title">Withdraw Via ' . $WithdrawGateway->name() . '</h4>
                                    <ul class="list-group br-0 text-center py-2">
                                        <li class="list-group-item">Charge - ' . $WithdrawGateway->chargeText() . '</li>
                                        <li class="list-group-item">Processing Time - ' . $WithdrawGateway->processing_time() . '</li>
                                    </ul>
                                    <hr>
                                    ' . $btn . '
                                </div>
                            </div></div>';
    }

    private function empty_withdraw_gateway_card()
    {
        return '
            <a href="' . $this->seller_url() . '/withdraw/methods' . '" class="bg-white border border-dashed border-2 border-success justify-align-center p-6" >
                <div class="text-success justify-align-center fw-bolder" ><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                <rect opacity="0.5" x="11" y="18" width="12" height="2" rx="1" transform="rotate(-90 11 18)" fill="black"/>
                <rect x="6" y="11" width="12" height="2" rx="1" fill="black"/>
                </svg></span>Add A Withdraw Method</div>
            </a>
        ';
    }

    public function withdraw_gateway_lists()
    {
        $output = '';
        $stmt = $this->db()->prepare("SELECT gateway_id FROM $this->ecommerce_sellers_withdraw_gateways_tbl WHERE user_id = ? ORDER BY date_created DESC");
        $stmt->execute([$this->user_id]);
        if (!$stmt->rowCount()) return $this->empty_withdraw_gateway_card();
        while ($row =  $stmt->fetch()) $output .= $this->withdraw_gateway_card($row->gateway_id);
        return '<div class="row">' . $output . '</div>';
    }

    public function pending_withdrawal()
    {
        $stmt = $this->db()->prepare("SELECT IFNULL(SUM(gross_amount),0)  as withdrawal FROM $this->ecommerce_sellers_withdraw_tbl
        WHERE user_id = ? AND status = 'pending' ");
        $stmt->execute([$this->user_id]);
        return $stmt->fetch()->withdrawal;
    }

    public function total_withdrawal()
    {

        $stmt = $this->db()->prepare("SELECT IFNULL(SUM(gross_amount),0) as withdrawal FROM $this->ecommerce_sellers_withdraw_tbl
        WHERE user_id = ? AND status = 'success' ");
        $stmt->execute([$this->user_id]);
        return $stmt->fetch()->withdrawal;
    }

    public function pending_credits()
    {
        $stmt = $this->db()->prepare("SELECT IFNULL(SUM(net_amount),0) as credits FROM $this->transactions_tbl
        WHERE user_id = ? AND status = 'pending' AND type = 'order' ");
        $stmt->execute([$this->user_id]);
        return  $stmt->fetch()->credits;
    }

    public function pending_clearance()
    {

        $stmt = $this->db()->prepare("SELECT IFNULL(SUM(net_amount),0) as clearance FROM $this->transactions_tbl
        WHERE user_id = ? AND status = 'clearing' ");
        $stmt->execute([$this->user_id]);
        return  $stmt->fetch()->clearance;
    }

    public function net_income()
    {
        $stmt = $this->db()->prepare("SELECT *, 
        ( SELECT IFNULL(SUM(net_amount),0) FROM $this->transactions_tbl WHERE user_id = ? AND status = 'credit') as credit,
        ( SELECT IFNULL(SUM(net_amount),0) FROM $this->transactions_tbl WHERE user_id = ? AND type = 'order' AND status = 'debit') as debit FROM $this->transactions_tbl
         ");
        $stmt->execute([$this->user_id, $this->user_id]);
        if (!$stmt->rowCount()) return 0;
        $row = $stmt->fetch();
        return $row->credit - $row->debit;
    }

    public function wallet()
    {
        $stmt = $this->db()->prepare("SELECT *, 
        ( SELECT IFNULL(SUM(net_amount),0) FROM $this->transactions_tbl WHERE user_id = ? AND status = 'credit') as credit,
        ( SELECT IFNULL(SUM(net_amount),0) FROM $this->transactions_tbl WHERE user_id = ? AND type = 'order' AND status = 'debit') as debit,
        ( SELECT IFNULL(SUM(amount),0) FROM $this->transactions_tbl WHERE user_id = ? AND type = 'withdraw' AND status = 'debit') as debit_w
         FROM $this->transactions_tbl
         ");
        $stmt->execute([$this->user_id, $this->user_id, $this->user_id]);
        if (!$stmt->rowCount()) {
            $wallet = 0;
        } else {
            $row = $stmt->fetch();
            $wallet = $row->credit - $row->debit - $row->debit_w;
        }
        $pending_withdrawal = $this->pending_withdrawal();
        return $wallet - $pending_withdrawal;
    }


    public function check_clearing_payments()
    {
        $sql = "SELECT order_id FROM $this->transactions_tbl WHERE user_id = ? AND status = 'clearing'  ";
        $stmt = $this->db()->prepare($sql);
        $stmt->execute([$this->user_id]);

        try {
            while ($row =  $stmt->fetch()) {
                $order_id = $row->order_id;
                $Order = new _Order($order_id);
                if ($Order->can_clear_payment()) {

                    $sub_query = $this->db()->prepare("UPDATE `$this->transactions_tbl` SET status = 'credit', last_updated = ?  WHERE order_id = ? AND status = 'clearing' ");
                    $sub_query->execute([$this->current_time(), $order_id]);
                }
            }
        } catch (Exception $e) {
            Errors::response_500("Error in updating transaction" . $e->getMessage());
        }
    }
}

class SellerVerification extends Basic
{

    public $verification_id;
    private $row;

    function __construct($id)
    {
        if (!self::is_verification_id($id)) throw new Error("$id is not a valid Seller Verification Id");
        $this->verification_id = $id;
        $this->row = $this->row();
    }

    public static function is_verification_id($verification_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT verification_id FROM $Web->ecommerce_seller_verification_tbl WHERE verification_id = ? ");
        $stmt->execute([$verification_id]);
        return $stmt->rowCount() ? true : false;
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_seller_verification_tbl WHERE verification_id = ? ");
        $stmt->execute([$this->verification_id]);
        return  $stmt->fetch();
    }

    public function seller()
    {
        $user_id = $this->user_id();
        return new Seller($user_id);
    }

    public function user_id()
    {
        $row = $this->row();
        return $row->user_id;
    }

    public function status()
    {
        $row = $this->row();
        return $row->status;
    }

    public function rejected_reason()
    {
        $row = $this->row();
        $rejected_reason = $row->rejected_reason;
        return $this->unsanitize_text($rejected_reason);
    }

    public function requested_date()
    {
        $row = $this->row();
        $date =  $row->requested_on;
        return $this->date_time($date);
    }

    public function action_date()
    {
        $row = $this->row();
        $date =  $row->action_date;
        return $this->date_time($date);
    }

    public function status_label()
    {
        $status = $this->status();
        switch ($status) {
            case "pending":
                return $this->status_to_label("Pending", "warning");
                break;
            case "verified":
                return $this->status_to_label("Verified", "success");
                break;
            case "rejected":
                return $this->status_to_label("Rejected", "danger");
                break;
        }
    }

    public function url()
    {
        return $this->admin_url() . '/seller-verification/view-verification&id=' . $this->verification_id;
    }
}

class WithdrawGateway extends Basic
{
    public $gateway_id;
    private $row;

    function __construct($gateway_id)
    {
        if (!self::is_gateway_id($gateway_id)) Errors::response("$gateway_id is not a valid Withdraw Gateway Id");
        $this->gateway_id = $gateway_id;
        $this->row = $this->row();
    }

    public static function default_image()
    {
        global $Web;
        return $Web->get_assets("images/web/withdraw_gateway.png");
    }

    public static function is_gateway_id($gateway_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT gateway_id FROM $Web->ecommerce_withdraw_gateways_tbl WHERE gateway_id = ? ");
        $stmt->execute([$gateway_id]);
        return $stmt->rowCount() ? true : false;
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_withdraw_gateways_tbl WHERE gateway_id = ? ");
        $stmt->execute([$this->gateway_id]);
        return $stmt->fetch();
    }

    public function logo_id()
    {
        return $this->row()->logo_id;
    }

    public function status()
    {
        return $this->row()->status;
    }

    public function processing_time()
    {
        $processing_time = $this->row()->processing_time;
        return $this->unsanitize_text($processing_time);
    }

    public function card_heading()
    {
        $card_heading = $this->row()->card_heading;
        return $this->unsanitize_text($card_heading);
    }

    public function name()
    {
        $name = $this->row()->gateway_name;
        return $this->unsanitize_text($name);
    }
    public function charge()
    {
        $charge = $this->row()->charge;
        return $charge;
    }
    public function charge_type()
    {
        $charge_type = $this->row()->charge_type;
        return $charge_type;
    }
    public function chargeText()
    {
        $charge = $this->charge();
        $charge_type = $this->charge_type();
        if ($charge_type == "fixed") return $this->formatCurrency($charge);
        return $charge . '%';
    }
    public function logo()
    {
        $logo_id = $this->logo_id();
        return empty($logo_id) ? WithdrawGateway::default_image() : $this->get_file_src($logo_id);
    }

    public function edit_url()
    {
        return $this->admin_url() . '/payments/edit-withdraw-method?id=' . $this->gateway_id;
    }

    public function labels()
    {
        $row = $this->row();
        $labels = $row->labels;
        return json_decode($labels);
    }

    public function labels_count()
    {
        $labels = $this->labels();
        $labels = count($labels);
        $output = new stdClass;
        $output->currentLabels = $labels;

        return json_encode($output);
    }

    public function labels_preview()
    {
        $output = '';
        $labels = $this->labels();
        foreach ($labels as $key => $data) {
            if ($data->type == "image") {
                $output .= ' <div data-repeater-item="" class="form-group">
                                                <div class="d-flex align-items-end mb-5">
                                                    <div class="flex-grow-1 fv-row">
                                                        <label class="fs-6 fw-bold mb-2 required"> Add Label <small>(image)</small> </label>
                                                        <input data-type="image" data-id="' . $data->id . '" type="text" class="form-control form-control-solid flex-grow-1 " placeholder="Add Label" name="labels" value="' . $data->value . '">
                                                    </div>
                                                    <button type="button" data-repeater-delete="" class="ms-4 btn btn-sm btn-icon btn-light-danger">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                </div>
                                            </div>';
            } else {
                $output .= ' <div data-repeater-item="" class="form-group d-flex align-items-end mb-5">
                                                            <div class="flex-grow-1 fv-row">
                                                                <label class="fs-6 fw-bold mb-2 required"> Add Label </label>
                                                                <input data-type="input" data-id="' . $data->id . '" type="text" class="form-control form-control-solid flex-grow-1 " placeholder="Add Label" name="labels" value="' . $data->value . '">
                                                            </div>
                                                            <button type="button" data-repeater-delete="" class="ms-4 btn btn-sm btn-icon btn-light-danger">
                                                                <i class="fas fa-times"></i>
                                                            </button>
                                                        </div>';
            }
        }
        return $output;
    }

    public static function all_lists($user_id)
    {
        $output = '';
        global $Web;
        $stmt = $Web->db()->query("SELECT * FROM $Web->ecommerce_withdraw_gateways_tbl WHERE status = 'active' ");
        if (!$stmt->rowCount()) return '<div class="vh-100 justify-align-center" ><h1>Currently No Withdraw Methods Are Available</h1></div>';
        while ($row =  $stmt->fetch()) {
            $WithdrawGateway = new WithdrawGateway($row->gateway_id);
            $output .= $WithdrawGateway->create_card($user_id);
        }
        return $output;
    }

    public function create_card($user_id)
    {
        $url = $this->seller_url() . '/withdraw/add-details?id=' . $this->gateway_id;

        if ($this->has_seller_withdraw_gateway($user_id)) {

            $btn = '<a href="' . $url . '" class="btn btn-icon btn-bg-primary btn-sm me-1">
                            <span class="svg-icon svg-icon-white svg-icon-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                    <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                </svg>
                            </span>
                    </a> <button data-remove="withdraw" class="btn btn-icon btn-bg-danger btn-sm me-1" >
                            <span class="svg-icon svg-icon-white svg-icon-3"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="black"/>
                            <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="black"/>
                            <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="black"/>
                            </svg></span>
                    </button>';
        } else {

            $btn = '<div class="d-flex flex-column gap-3" ><div class="fs-8 text-danger" > Withdraw details have not been added.</div> <a href="' . $url . '" class="btn btn-danger">Add</a></div>';
        }
        return '<div class="col-xl-3 col-lg-4 col-md-4 col-sm-6">
                            <div data-id="' . $this->gateway_id . '" class="card withdraw-card mb-4 text-center">
                                <img style="max-height:540px" src="' . $this->logo() . '" class="card-img-top" alt="' . $this->name() . '">
                                <div class="card-body p-4">
                                    <h4 class="card-title">Withdraw Via ' . $this->name() . '</h4>
                                    <ul class="list-group br-0 text-center py-2">
                                        <li class="list-group-item">Charge - ' . $this->chargeText() . '</li>
                                        <li class="list-group-item">Processing Time - ' . $this->processing_time() . '</li>
                                    </ul>
                                    <hr>
                                    <div class=" btns" >' . $btn . '</div>
                                </div>
                            </div>
                </div>';
    }

    public function form($user_id)
    {
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_sellers_withdraw_gateways_tbl WHERE user_id = ? AND gateway_id = ? ");
        $stmt->execute([$user_id, $this->gateway_id]);

        $row =  $stmt->fetch();
        $user_withdraw_data = $row->labels ?? '{}';
        $uw_data = json_decode($user_withdraw_data, true);

        $output = '';
        $labels = $this->labels();
        foreach ($labels as $key => $data) {
            $val = $uw_data[$data->id] ?? '';

            if ($data->type == "image") {
                $src = $this->get_file_src($val);
                $output .= '<div class="mb-5 fv-row">
                                     <label class="fs-6 fw-bold mb-2 required"> ' . $data->value . ' </label>
                                      <div class="cursor-pointer mh-400px image-input image-upload-card mb-4">
                                                    <input autocomplete="off" required type="text" class="d-none image-id form-control form-control-solid flex-grow-1 "  name="labels[' . $data->id . ']" value="' .  $val . '">
                                            <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-lx-image-input-action="change" data-bs-toggle="tooltip" data-bs-original-title="Change Image">
                                                <i class="bi bi-pencil-fill fs-7"></i>
                                                <input class="img_label_choose"  type="file" name="avatar" accept=".png, .jpg, .jpeg">
                                            </label>
                                            <div class="image-upload-progress">
                                                <div class="progress-bar"></div>
                                            </div>
                                            <img class="img-fluid mh-400px " src="' . $src . '" alt="add image" srcset="">
                                            <div class="invalid-feedback" >Please choose a image</div>
                                      </div>
                            </div>';
            } else {
                $output .= '<div class="mb-5 fv-row">
                                       <label class="fs-6 fw-bold mb-2 required"> ' . $data->value . ' </label>
                                       <input autocomplete="off" required type="text" class="form-control flex-grow-1 " name="labels[' . $data->id . ']" value="' . $val . '">
                                       <div class="invalid-feedback" >' . $data->value . ' is required</div>
                            </div>';
            }
        }
        return $output;
    }

    public function false_form($user_id)
    {
        $output = '';

        $db_labels = $this->labels();
        $user_labels = $this->user_added_labels($user_id);

        foreach ($db_labels as $key => $data) {
            if ($data->type == "image") {
                $value = $this->get_file_src($user_labels[$data->id]);
                $output .= '<div class="mb-5 fv-row">
                                     <label class="fs-6 fw-bold mb-2 required"> ' . $data->value . ' </label>
                                      <div class="mh-400px image-input image-upload-card mb-4">
                                            <img class="img-fluid mh-400px " src="' . $value . '" alt="image" srcset="">
                                      </div>
                            </div>';
            } else {
                $value = $user_labels[$data->id];
                $output .= '<div class="mb-5 fv-row">
                                       <label class="fs-6 fw-bold mb-2 required"> ' . $data->value . ' </label>
                                       <input autocomplete="off" required type="text" class="form-control form-control-solid flex-grow-1 "  value="' . $value . '">
                            </div>';
            }
        }
        return $output;
    }

    public function has_seller_withdraw_gateway($user_id)
    {
        $stmt = $this->db()->prepare("SELECT gateway_id FROM $this->ecommerce_sellers_withdraw_gateways_tbl WHERE gateway_id = ? AND user_id = ? ");
        $stmt->execute([$this->gateway_id, $user_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function user_added_labels($user_id)
    {
        $stmt = $this->db()->prepare("SELECT labels FROM $this->ecommerce_sellers_withdraw_gateways_tbl WHERE gateway_id = ? AND user_id = ?  ");
        $stmt->execute([$this->gateway_id, $user_id]);
        $labels =   $stmt->fetch()->labels;
        return json_decode($labels, true);
    }
}

class Withdraw extends Basic
{
    public $withdraw_id;
    private $row;

    function __construct($withdraw_id)
    {
        if (!self::is_withdraw_id($withdraw_id)) throw new Error("$withdraw_id is not a valid withdraw id");
        $this->withdraw_id = $withdraw_id;
        $this->row = $this->row();
    }

    public static function is_withdraw_id($withdraw_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT withdraw_id FROM $Web->ecommerce_sellers_withdraw_tbl WHERE withdraw_id = ?");
        $stmt->execute([$withdraw_id]);
        return $stmt->rowCount() ? true : false;
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_sellers_withdraw_tbl WHERE withdraw_id = ? ");
        $stmt->execute([$this->withdraw_id]);
        return  $stmt->fetch();
    }

    public function seller()
    {
        $row = $this->row();
        $user_id = $row->user_id;
        return new Seller($user_id);
    }
    public function gateway_id()
    {
        $row = $this->row();
        return $row->gateway_id;
    }
    public function transaction_id()
    {
        $row = $this->row();
        return $row->transaction_id;
    }

    public function gross_amount()
    {
        $row = $this->row();
        return (float) $row->gross_amount;
    }

    public function charge()
    {
        $row = $this->row();
        return (float) $row->charge;
    }
    public function net_amount()
    {
        $row = $this->row();
        return (float) $row->net_amount;
    }
    public function date_requested()
    {
        $row = $this->row();
        $date_requested = $row->date_requested;
        return $this->date_time($date_requested);
    }
    public function date_processed()
    {
        $row = $this->row();
        $date_processed = $row->date_processed;
        return $this->date_time($date_processed);
    }
    public function gateway()
    {
        $row = $this->row();
        $gateway = $row->gateway;
        return (object) json_decode($gateway, true);
    }
    public function db_labels()
    {
        $row = $this->row();
        $db_labels = $row->db_labels;
        return json_decode($db_labels, true);
    }
    public function user_labels()
    {
        $row = $this->row();
        $user_labels =  $row->user_labels;
        return json_decode($user_labels, true);
    }
    public function status()
    {
        $row = $this->row();
        return $row->status;
    }

    public function rejected_reason()
    {
        $row = $this->row();
        $rejected_reason = $row->rejected_reason;
        return $this->unsanitize_text($rejected_reason);
    }

    public function url()
    {
        return $this->seller_url() . '/withdraw/view?id=' . $this->withdraw_id;
    }

    public function process_url()
    {
        return $this->admin_url() . '/payments/process-withdraw?id=' . $this->withdraw_id;
    }

    public function labels()
    {
        $output = '';

        $db_labels = $this->db_labels();
        $user_labels = $this->user_labels();

        foreach ($db_labels as $key => $data) {
            $data = (object) $data;
            if ($data->type == "image") {
                $value = $this->get_file_src($user_labels[$data->id]);
                $output .= '<div class="mb-5 fv-row">
                                     <label class="fs-6 fw-bold mb-2 required"> ' . $data->value . ' </label>
                                      <div class="mh-400px image-input image-upload-card mb-4">
                                            <img class="img-fluid mh-400px " src="' . $value . '" alt="image" srcset="">
                                      </div>
                            </div>';
            } else {
                $value = $user_labels[$data->id];
                $output .= '<div class="mb-5 fv-row">
                                       <label class="fs-6 fw-bold mb-2 required"> ' . $data->value . ' </label>
                                       <input autocomplete="off" required type="text" class="form-control form-control-solid flex-grow-1 "  value="' . $value . '">
                            </div>';
            }
        }
        return $output;
    }
}

class Order extends Basic
{
    public $order_id;
    private $row;

    function __construct($id)
    {
        if (!self::is_order_id($id)) throw new Error($id . " is not a valid Order Id");
        $this->order_id = $id;
        $this->row = $this->row();
    }

    public static function is_order_id($order_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT order_id FROM $Web->ecommerce_orders_tbl WHERE order_id = ? ");
        $stmt->execute([$order_id]);
        return $stmt->rowCount() ? true : false;
    }

    public static function user_orders_count($user_id)
    {
        global $Web;
        $output = '';
        $stmt = $Web->db()->prepare("SELECT COUNT(*) FROM $Web->ecommerce_orders_tbl WHERE STATUS != 'PENDING' AND buyer_id = ? ");
        $stmt->execute([$user_id]);
        return  $stmt->fetch(PDO::FETCH_NUM)[0];
    }
    public static function user_orders($user_id, $page)
    {
        global $Web;
        $output = new stdClass;
        $output->content = '';

        $total_rows = self::user_orders_count($user_id);
        $records_per_page = 10;
        $total_pages = ceil($total_rows / $records_per_page);
        if ($page > $total_pages) $page = 1;
        if (!($page > 0)) $page = 1;
        $offset = ($page - 1) * $records_per_page;
        $stmt = $Web->db()->prepare("SELECT order_id FROM $Web->ecommerce_orders_tbl WHERE buyer_id = ? AND STATUS != 'PENDING' ORDER BY order_id DESC LIMIT ?,? ");
        $stmt->execute([$user_id, $offset, $records_per_page]);
        while ($row =  $stmt->fetch()) {
            $output->content .= (new self($row->order_id))->create_card();
        }

        $output->pagination = $Web->insert_pagination($Web->base_url() . '/orders/?', $page, $total_pages, true, '');

        return $output;
    }

    public function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_orders_tbl WHERE order_id = ? ");
        $stmt->execute([$this->order_id]);
        return  $stmt->fetch();
    }

    public function product_id()
    {
        $row = $this->row();
        return $row->product_id;
    }

    public function product()
    {
        $product_id = $this->product_id();
        return new Product($product_id);
    }

    public function variation_id()
    {
        $row = $this->row();
        return $row->variation_id;
    }

    public function svariation_id()
    {
        $row = $this->row();
        return $row->svariation_id;
    }
    public function quantity()
    {
        $row = $this->row();
        return $row->quantity;
    }
    public function status()
    {
        $row = $this->row();
        $status = $row->status;
        return $status;
    }
    public function payment_method()
    {
        $row = $this->row();
        $payment_method = $row->payment_method;
        return $payment_method;
    }
    public function buyer()
    {
        $row = $this->row();
        $buyer_id = $row->buyer_id;
        return new User($buyer_id);
    }
    public function address()
    {
        $row = $this->row();
        $address = $row->address;
        $address = json_decode($address);

        $output = new stdClass;
        $output->full_name = $this->unsanitize_text($address->full_name);
        $output->mobile_number = $this->unsanitize_text($address->mobile_number);
        $output->city = $this->unsanitize_text($address->city);
        $output->area = $this->unsanitize_text($address->area);
        $output->flat = $this->unsanitize_text($address->flat);
        $output->landmark = $this->unsanitize_text($address->landmark);
        $output->state = $this->unsanitize_text($address->state);
        $output->postcode = $this->unsanitize_text($address->postcode);
        $output->address_type = $this->unsanitize_text($address->address_type);
        return $output;
    }

    public function seller_address_card()
    {
        $address = $this->product()->seller()->pickup_address();
        $main_address = '
                <b>' . $address->pickup_address . '</b>
                <div class="px-2" >' . $address->pickup_city . ',' . $address->pickup_state . ',' . $address->pickup_country . ' - ' . $address->pin_code . '</div>
                ';
        return $main_address;
    }

    public function pickup_address()
    {
        $address = $this->product()->seller()->pickup_address();

        $main_address = "<b>$address->pickup_address</b>
        <br>$address->pickup_city
        <br>$address->pickup_state
        <br>$address->pickup_country
        <br>$address->pin_code
        
        ";
        $full_address = '
                <div class="px-2" >' . $main_address . '</div>
                ';
        return $full_address;
    }

    public function address_card()
    {
        $full_address = '';
        if (!$this->is_empty($this->address()->flat)) $full_address .= ", " . $this->address()->flat;
        $full_address .=  "," . $this->address()->area;
        $full_address .= ", " . $this->address()->landmark;
        $full_address .= ", " . $this->address()->city;
        $full_address .= ", " . $this->address()->state;
        $full_address .= " - " . $this->address()->postcode;

        $main_address = '';
        $full_address = explode(",", $full_address);
        foreach ($full_address as $address) {
            if (!$this->is_empty($address)) {
                $main_address .= $address . "</br>";
            }
        }
        $main_address = rtrim($main_address, ", ");
        $main_address = '
                <div class="p-2" ><b>' . $this->address()->full_name . '</b></div>
                <div class="px-2" >' . $main_address . '</div>
                <div class="p-2">Phone Number:- ' . $this->address()->mobile_number . '</div>
                ';
        return $main_address;
    }

    public function shipping()
    {
        $shipped_details = $this->row()->shipped_details;
        if (!empty($shipped_details))  $shipped_details = json_decode($shipped_details);

        if (empty($shipped_details)) return;

        $tracking_id = $shipped_details->tracking_id;
        $courier_comment = $shipped_details->courier_comment;
        $courier_service = $shipped_details->courier_service;
        $courier_service_url = $shipped_details->courier_service_url;
        $courier_comment = $this->unsanitize_text($courier_comment);

        $output = new stdClass;
        $output->tracking_id = $tracking_id;
        $output->courier_service = $courier_service;
        $output->comment = $courier_comment;
        $output->courier_service_url = $courier_service_url;
        return $output;
    }

    public function price()
    {
        $row = $this->row();
        return $row->price;
    }

    public function price_text()
    {
        return $this->formatCurrency($this->price());
    }

    public function discount()
    {
        $row = $this->row();
        return $row->discount ?? 0;
    }

    public function discount_text()
    {
        return $this->formatCurrency($this->discount());
    }

    public function shipping_rate()
    {
        $row = $this->row();
        $shipping_rate = $row->shipping_rate ?? 0;
        return $shipping_rate;
    }

    public function shipping_rate_text()
    {
        return $this->formatCurrency($this->shipping_rate());
    }

    public function total_price()
    {
        $row = $this->row();
        $price = $row->total_price;
        return $price;
    }

    public function total_price_text()
    {
        $row = $this->row();
        $price = $row->total_price;
        return $this->formatCurrency($price);
    }

    public function grand_total()
    {
        $row = $this->row();
        $grand_total = $row->grand_total;
        return $grand_total;
    }

    public function grand_total_text()
    {
        $grand_total = $this->grand_total();
        return $this->formatCurrency($grand_total);
    }

    public function shipping_charge()
    {
        $row = $this->row();
        $shipping_charge = $row->shipping_charge;
        return $shipping_charge;
    }

    public function shipping_charge_text()
    {
        return $this->formatCurrency($this->shipping_charge());
    }

    public function service_charge()
    {
        $row = $this->row();
        $service_charge = $row->service_charge;
        return $service_charge;
    }

    public function service_charge_text()
    {
        $service_charge = $this->service_charge();
        return $this->formatCurrency($service_charge);
    }

    public function order_date()
    {
        $row = $this->row();
        $order_date =  $row->ordered_date;
        return $this->date_time($order_date);
    }

    public function labelled_on()
    {
        $row = $this->row();
        $labelled_on =  $row->labelled_on;
        return $this->date_time($labelled_on);
    }

    public function rtd_on()
    {
        $row = $this->row();
        $rtd_on =  $row->rtd_on;
        return $this->date_time($rtd_on);
    }
    public function pickup_scheduled_on()
    {
        $row = $this->row();
        $pickup_scheduled_on =  $row->pickup_scheduled_on;
        return $this->date_time($pickup_scheduled_on);
    }

    public function shipped_on()
    {
        $row = $this->row();
        $shipped_on =  $row->shipped_on;
        return $this->date_time($shipped_on);
    }

    public function delivered_on()
    {
        $row = $this->row();
        $delivered_on =  $row->delivered_on;
        return $this->date_time($delivered_on);
    }

    public function cancelled_on()
    {
        $row = $this->row();
        $cancelled_on =  $row->cancelled_on;
        return $this->date_time($cancelled_on);
    }
    public function rejected_on()
    {
        $row = $this->row();
        $rejected_on =  $row->rejected_on;
        return $this->date_time($rejected_on);
    }
    public function returned_on()
    {
        $row = $this->row();
        $returned_on =  $row->returned_on;
        return $this->date_time($returned_on);
    }
    public function cancelled_reason()
    {
        $row = $this->row();
        $cancelled_reason =  $row->cancelled_reason;
        return $this->unsanitize_text($cancelled_reason);
    }
    public function returned_reason()
    {
        $row = $this->row();
        $returned_reason =  $row->returned_reason;
        return $this->unsanitize_text($returned_reason);
    }
    public function rejected_reason()
    {
        $row = $this->row();
        $rejected_reason =  $row->rejected_reason;
        return $this->unsanitize_text($rejected_reason);
    }

    public function status_step()
    {
        $status = $this->status();
        switch ($status) {
            case "PENDING":
                return 0;
                break;
            case "FAILED":
                return 1;
                break;
            case "CANCELLED":
                return 2;
            case "REJECTED":
                return 3;
                break;
            case "SUCCESS":
                return 4;
                break;
            case "LABELLED":
                return 5;
                break;
            case "RTD":
                return 6;
                break;
            case "SHIPPED":
                return 7;
            case "DELIVERED":
                return 8;
                break;
            case "REPLACEMENT":
                return 9;
                break;
            case "RETURNED":
                return 10;
                break;
            case "PICKUP_SCHEDULED":
                return 11;
                break;
        }
    }

    public function can_review()
    {
        return $this->status_step() > 7 && $this->status_step() !== 11;
    }

    public function ship_to()
    {
        $row = $this->row();
        $order_date =  $row->date;
        return $this->date_time($order_date);
    }

    public function url()
    {
        return $this->base_url() . '/orders/preview?id=' . $this->order_id;
    }

    public function status_label()
    {
        $status = $this->status();
        $status = strtolower($status);
        switch ($status) {
            case "pending":
                return $this->status_to_label("Pending", "warning");
                break;
            case "success":
            case "labelled":
                return $this->status_to_label("Not yet dispatched", "primary");
                break;
            case "failed":
                return $this->status_to_label("Failed", "danger");
                break;
            case "pickup_scheduled":
            case "rtd":
                return $this->status_to_label("Rtd", "info");
                break;
            case "shipped":
                return $this->status_to_label($status, "primary");
                break;
            case "delivered":
                return $this->status_to_label("Delivered", "success");
                break;
            case "cancelled":
                return $this->status_to_label("Cancelled", "danger");
                break;
            case "rejected":
                return $this->status_to_label("Rejected", "danger");
                break;
            case "replacement":
                return $this->status_to_label("Replacement", "info");
                break;
            case "returned":
                return $this->status_to_label("Returned", "danger");
                break;
        }
    }

    public function status_text()
    {
        $status = $this->status();
        $status = strtolower($status);
        switch ($status) {
            case "pending":
                return "Order Pending";
                break;
            case "rejected":
                return "Order Rejected on " . $this->rejected_on();
                break;
            case "success":
            case "labelled":
                return "Ordered on " . $this->order_date();
                break;
            case "failed":
                return "Order Failed";
                break;
            case "rtd":
            case "pickup_scheduled":
                return "Rtd on " . $this->rtd_on();
                break;
            case "shipped":
                return "Shipped on " . $this->shipped_on();
                break;
            case "delivered":
                return "Delivered on " . $this->delivered_on();
                break;
            case "cancelled":
                return "Cancelled on " . $this->cancelled_on();
                break;
            case "returned":
                return "Return completed on " . $this->return_order()->completed_date();
                break;
            case "replacement":
                return "Replacement on " . $this->replacement_order()->completed_date();
                break;
        }
    }

    private function create_card()
    {
        $Product = new Product($this->product_id());
        $variation_data = $Product->category()->has_variation() && !empty($Product->variation_value($this->variation_id(), $this->svariation_id())) ? '
        <div class="d-flex my-1">
                                    <span class="text-dark">' . $Product->variation_header_text() . ': </span>
                                    <span class="ms-2 text-gray-600">' . $Product->variation_value($this->variation_id(), $this->svariation_id()) . '</span>
                                </div>' : '';
        $svariation_data = $Product->category()->has_svariation() && !empty($Product->svariation_val($this->variation_id(), $this->svariation_id())) ? '<div class="d-flex my-1">
                                    <span class="text-dark">' . $Product->svariation_header_text() . ': </span>
                                    <span class="ms-2 text-gray-600">' . $Product->svariation_val($this->variation_id(), $this->svariation_id()) . '</span>
                                </div>' : '';

        return '<div class="border-top border-1 p-2 position-relative border-bottom">
                <div class="d-flex">
                    <a href="' . $this->url() . '" class="mw-lg-110px mw-80px mh-150px">
                        <img class="img-fluid mh-100 " src="' . $Product->image($this->variation_id(), $this->svariation_id()) . '" alt="product-image" srcset="">
                    </a>
                    <div class="ms-4 flex-grow-1">
                        <div class="row">
                            <div class="col-lg-8">
                                <a href="' . $this->url() . '" class="mb-2 text-primary-alt fs-4 wrap-text-1">' . $Product->product_name($this->variation_id(), $this->svariation_id()) . '</a>
                            <div class="d-none d-md-block">
                                ' . $variation_data . '
                                ' . $svariation_data . '
                                <div class="align-center mb-1">
                                    <span class="text-dark">Quantity: </span>
                                    <span class="ms-2 text-gray-600">' . $this->quantity() . '</span>
                                </div>
                                <div class="mb-4">
                                    <div class="d-flex mb-1">
                                        <span class="text-dark">Seller: </span>
                                        <a href="" class="ms-2">' . $Product->seller()->store_name() . '</a>
                                    </div>
                                </div>
                            </div></div>

                            <div class="col-lg-4">
                                <div class="d-none mb-1 d-md-flex align-center">
                                    <span class="fs-6 text-dark">Order placed: </span>
                                    <span class="ms-2 text-gray-600">' . $this->order_date() . '</span>
                                </div>
                                <div class="d-flex d-md-none text-gray-700 fs-5 mb-2 align-center">' . $this->status_text() . '</div>
                                <div class="d-none d-md-flex align-center">
                                    <span class="fs-6 text-dark">Total Price: </span>
                                    <span class="ms-2 text-gray-600">' . $this->total_price() . '</span>
                                </div>
                                <div class="d-none d-md-flex align-center">
                                    <span class="fs-6 text-dark">Ship To: </span>
                                    <span class="ms-2 text-gray-600">' . $this->address()->full_name . '</span>
                                    <div>
                                                                                    <button type="button" class="btn btn-sm btn-icon btn-color-primary btn-active-light-primary" data-lx-menu-trigger="click" data-lx-menu-placement="bottom-end">
                                                                                        <span class="svg-icon svg-icon-2">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                                                <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="currentColor"></path>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </button>
                                                                                    <div data-lx-menu="true" style="" class="menu mh-200px scroll-y menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg-light-primary fw-bold mw-350px p-3">
                                                                                    ' . $this->address_card() . '
                                                                                    </div>
                                                                                </div>
                                </div>
                                <div class="align-center mb-2">
                                    <span class="fs-6 text-dark">Order: </span>
                                    <a class="ms-2" href="' . $this->url() . '" >#' . $this->order_id . '</a>
                                </div>
                                <div class="d-none d-md-flex align-center">
                                    <span class="fs-6 text-dark">Status: </span>
                                    <a class="ms-2 text-gray-600">' . $this->status_label() . '</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
    }
    public function has_returned_requested()
    {
        $stmt = $this->db()->prepare("SELECT return_id FROM $this->ecommerce_return_orders_tbl WHERE order_id = ? ");
        $stmt->execute([$this->order_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function return_order_id()
    {
        $stmt = $this->db()->prepare("SELECT return_id FROM $this->ecommerce_return_orders_tbl WHERE order_id = ? ");
        $stmt->execute([$this->order_id]);
        return  $stmt->fetch()->return_id;
    }

    public function has_replacement_requested()
    {
        $stmt = $this->db()->prepare("SELECT replacement_id FROM $this->ecommerce_replacement_orders_tbl WHERE order_id = ? ");
        $stmt->execute([$this->order_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function replacement_order_id()
    {
        $stmt = $this->db()->prepare("SELECT replacement_id FROM $this->ecommerce_replacement_orders_tbl WHERE order_id = ? ");
        $stmt->execute([$this->order_id]);
        return  $stmt->fetch()->replacement_id;
    }

    public function return()
    {
        $row = $this->row;
        $return_policy = $row->return_policy;
        return \json_decode($return_policy);
    }

    public function return_policy()
    {
        $return = $this->return();
        $return_policy = $return->return_policy;
        return \json_decode($return_policy);
    }

    public function return_policy_days()
    {

        $return = $this->return();
        $return_policy_days = $return->return_policy_days;
        return \json_decode($return_policy_days);
    }

    public function raw_return_applicable_till()
    {
        $return_policy_days = $this->return_policy_days();
        $date = $return_policy_days * 3600 * 24 + $this->row()->delivered_on;
        return $date;
    }

    public function return_applicable_till()
    {
        $return_policy_days = $this->return_policy_days();
        $date = $return_policy_days * 3600 * 24 + $this->row()->delivered_on;
        return $this->date_time($date);
    }

    public function can_apply_return()
    {
        $return_policy = $this->return_policy();
        $return_policy_days = $this->return_policy_days();
        if ($this->status() !== 'DELIVERED') return false;
        if ($this->has_returned_requested()) return false;
        if ($return_policy === 'no') return false;
        if ($this->has_replacement_requested()) return false;
        if (($this->current_time() - $this->row()->delivered_on) <=  $return_policy_days * 3600 * 24) return true;
        return false;
    }

    public function can_apply_replacement()
    {
        $return_policy = $this->return_policy();
        $return_policy_days = $this->return_policy_days();
        if ($this->status() !== 'DELIVERED') return false;
        if ($this->has_returned_requested()) return false;
        if ($return_policy !== 'replacement') return false;
        if ($this->is_replacement_order()) return false;
        if ($this->has_replacement_requested()) return false;
        if (($this->current_time() - $this->row()->delivered_on) <=  $return_policy_days * 3600 * 24) return true;
        return false;
    }

    public function return_order()
    {
        return new ReturnOrder($this->return_order_id());
    }

    public function replacement_order()
    {
        return new ReplacementOrder($this->replacement_order_id());
    }

    public function can_cancel_order()
    {
        if ($this->is_replacement_order()) return false;
        if ($this->status_step() !== 4) return false;
        return true;
    }

    public function is_replacement_order()
    {
        $stmt = $this->db()->prepare("SELECT replacement_id FROM $this->ecommerce_replacement_orders_tbl WHERE new_order_id = ? ");
        $stmt->execute([$this->order_id]);
        return $stmt->rowCount() ? true : false;
    }

    public function original_order_id()
    {
        $stmt = $this->db()->prepare("SELECT order_id as order_id FROM $this->ecommerce_replacement_orders_tbl WHERE new_order_id = ? ");
        $stmt->execute([$this->order_id]);
        return  $stmt->fetch()->order_id;
    }

    public function original_order()
    {
        $original_order_id = $this->original_order_id();
        return new _Order($original_order_id);
    }

    public function refund_status()
    {
        $status = $this->row()->refund_status;
        return $status;
    }

    public function refund_comment()
    {
        $refund_comment = $this->row()->refund_comment;
        return $this->unsanitize_text($refund_comment);
    }

    public function refund_date()
    {
        $refund_date = $this->row()->refund_date;
        return $this->date_time($refund_date);
    }

    public function payment_status_label()
    {
        if ($this->status() == "FAILED") return $this->status_to_label("Failed", "danger");
        if ($this->payment_method() === "CashOnDelivery") return $this->status_to_label("cash on delivery", "info");
        return $this->refund_status() == "completed" ? $this->status_to_label("refunded", "success") : $this->status_to_label("completed", "success");
    }

    public function has_refunded()
    {
        return $this->refund_status() == "completed" ? true : false;
    }
    public function can_refund()
    {
        if ($this->is_replacement_order()) return true;
        return $this->payment_method() === "CashOnDelivery" ? false : true;
    }
}

class _Order extends Order
{
    function __construct($id)
    {
        $this->order_id = $id;
        parent::__construct($id);
    }

    public function url()
    {
        return $this->seller_url() . '/view-order/' . $this->order_id;
    }

    public function admin_view_url()
    {
        return $this->admin_url() . '/view-order/' . $this->order_id;
    }

    public function can_generate_label()
    {
        return in_array($this->status_step(), [4, 5, 6, 7]);
    }

    public function service_charge()
    {
        $totalCharge = 0;
        if ($this->is_replacement_order()) return $totalCharge;
        $stmt = $this->db()->query("SELECT service_id FROM $this->ecommerce_service_tbl ");
        while ($row =  $stmt->fetch()) {
            $Service = new Service($row->service_id);
            $charge = $Service->charge();
            $type = $Service->type();
            if ($type == "fixed") $totalCharge += $charge;
            else $totalCharge += ($this->total_price() * $charge) / 100;
        }
        return $totalCharge;
    }

    public function service_charge_text()
    {
        return $this->formatCurrency($this->service_charge());
    }

    public function service_charge_details()
    {
        $charges = [];
        if ($this->is_replacement_order()) return json_encode($charges);
        $stmt = $this->db()->query("SELECT service_id FROM $this->ecommerce_service_tbl ");
        while ($row =  $stmt->fetch()) {
            $Service = new Service($row->service_id);
            $charges[] = array(
                "service_name" => $Service->name(),
                "service_charge" => $Service->charge(),
                "service_type" => $Service->type()
            );
        }
        $charges = json_encode($charges);
        return $charges;
    }

    public function service_grand_total()
    {
        return $this->total_price() - $this->service_charge();
    }

    public function charge_details()
    {
        $stmt = $this->db()->prepare("SELECT charge_details FROM $this->transactions_tbl WHERE order_id = ? ");
        $stmt->execute([$this->order_id]);
        $rows = $stmt->fetch()->charge_details ?? '[]';
        $rows = \json_decode($rows);
        return $rows;
    }

    public function charge_details_preview()
    {
        $stmt = $this->db()->prepare("SELECT charge_details FROM $this->transactions_tbl WHERE order_id = ? ");
        $stmt->execute([$this->order_id]);
        $rows = $stmt->fetchAll();
        if (!is_array($rows)) return [];
        return $rows;
    }

    public function tbl_charges_details()
    {
        $output = '';

        if ($this->is_replacement_order()) {
            $original_price = $this->original_order()->total_price_text();
            $output .= '
            <tr>
                <td colspan="4" class="text-end">Original Price</td>
                <td class="text-end">' . $original_price . '</td>
            </tr';
        }

        $rows = $this->charge_details_preview();

        if (!is_array($rows)) return;


        foreach ($rows as $data) {
            $charge_details  = $data->charge_details ?? '[]';
            $charge_details = \json_decode($charge_details);
            foreach ($charge_details as $data) {
                $service_charge = $data->service_charge;
                $service_name = $data->service_name;
                if ($data->service_type == "percentage") {
                    $service_name = $service_name . "($service_charge%)";
                    $service_charge = ($this->total_price() * $service_charge) / 100;
                }
                $service_charge = $this->formatCurrency($service_charge);
                $output .= '
                 <tr>
                          <td colspan="4" class="text-end">' . $service_name . '</td>
                          <td class="text-end"> - ' . $service_charge . '</td>
                  </tr>';
            }
        }
        return $output;
    }

    private function secondsToTime($seconds)
    {
        $dtF = new \DateTime('@0');
        $dtT = new \DateTime("@$seconds");
        $days =  $dtF->diff($dtT)->format('%a');
        $hours =  $dtF->diff($dtT)->format('%h');
        $minutes =  $dtF->diff($dtT)->format('%i');
        $seconds =  $dtF->diff($dtT)->format('%s');
        if ($days > 0) return $days . ' days';
        if ($hours == 1) return $hours . ' hour';
        else if ($hours > 0) return $hours . ' hours';
        if ($minutes > 0) return $minutes . ' minutes';
        if ($seconds > 0) return $seconds . ' seconds';
    }


    public function remaining_clearing_time()
    {
        $remaining_time =  $this->raw_return_applicable_till() - $this->current_time();
        return "clearing in " . $this->secondsToTime($remaining_time);
    }

    public function can_clear_payment()
    {
        if ($this->raw_return_applicable_till() < $this->current_time()) return true;
        if ($this->is_replacement_order()) return true;
        if ($this->can_apply_replacement()) return false;
        if ($this->can_apply_return()) return false;
        if ($this->has_replacement_requested()) {
            $Replacement = $this->replacement_order();
            if ($Replacement->status() !== "completed") return false;
        }
        if ($this->has_returned_requested()) {
            $Return = $this->return_order();
            if ($Return->status() !== "completed") return false;
        }
        return true;
    }
}

class ReturnOrder extends Basic
{

    private $row;

    function __construct($return_id)
    {
        if (!self::is_return_id($return_id)) throw new Error("$return_id is not a valid Return Order Id");
        $this->return_id = $return_id;
        $this->tbl = $this->ecommerce_return_orders_tbl;
    }

    public static function is_return_id($return_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT return_id FROM $Web->ecommerce_return_orders_tbl WHERE return_id = ? ");
        $stmt->execute([$return_id]);
        return $stmt->rowCount() ? true : false;
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->tbl WHERE return_id = ? ");
        $stmt->execute([$this->return_id]);
        return  $stmt->fetch();
    }

    public function order_id()
    {
        $row = $this->row();
        return $row->order_id;
    }

    public function order()
    {
        return new _Order($this->order_id());
    }

    public function status()
    {
        $row = $this->row();
        return $row->status;
    }

    public function return_shipping_charge()
    {
        $row = $this->row();
        return $row->return_shipping_charge;
    }

    public function status_code()
    {
        $status = $this->status();
        switch ($status) {
            case "cancelled":
                return 0;
                break;
            case "initiated":
                return 1;
                break;
            case "rejected":
                return 2;
                break;
            case "accepted":
                return 3;
                break;
            case "pickup_scheduled":
                return 4;
                break;
            case "completed":
                return 5;
                break;
        }
    }

    public function has_return_completed()
    {
        return $this->status() === "completed";
    }

    public function has_return_succeed()
    {
        return $this->status() === "completed";
    }

    public function status_label()
    {
        $status = $this->status();
        $status = strtolower($status);
        switch ($status) {
            case "cancelled":
                return $this->status_to_label("Cancelled", "danger");
                break;
            case "initiated":
                return $this->status_to_label("Initiated", "warning");
                break;
            case "accepted":
                return $this->status_to_label("Accepted", "success");
                break;
            case "rejected":
                return $this->status_to_label("Rejected", "danger");
                break;
            case "pickup_scheduled":
                return $this->status_to_label("Pickup Scheduled", "primary");
                break;
            case "completed":
                return $this->status_to_label("Completed", "success");
                break;
        }
    }


    public function track_class($code)
    {
        $class = '';

        switch ($code) {
            case 1:
                $class .= "done ";
                if ($this->status_code() == "1") $class .= ' active';
                break;
            case 2:
                if ($this->status_code() == "2") $class .= 'done active';
                break;
            case 3:
                if ($this->status_code() == "3") $class .= ' active';
                if ($this->has_accepted()) $class .= ' done';
                break;
            case 4:
                if ($this->status_code() == "4") $class .= ' active ';
                if ($this->status_code() >= "4") $class .= ' done';
                break;
            case 5:
                if ($this->status_code() == "5") $class .= 'done active';
                break;
        }
        return $class;
    }


    public function can_cancel_return()
    {
        if ($this->status_code() != "1" && $this->status_code() != "3") return false;
        return true;
    }


    public function total_price()
    {
        if ($this->order()->is_replacement_order()) {
            $order_id = $this->order()->original_order_id();
            $Order = new _Order($order_id);
            return $Order->total_price();
        }
        return  $this->order()->total_price();
    }

    public function service_charge()
    {
        if ($this->order()->is_replacement_order()) {
            $order_id = $this->order()->original_order_id();
            $Order = new _Order($order_id);
            return $Order->service_charge();
        }
        if (!$this->has_return_succeed()) return 0;
        return  $this->order()->service_charge();
    }

    public function total_price_text()
    {
        return $this->formatCurrency($this->total_price());
    }

    public function service_charge_text()
    {
        return $this->formatCurrency($this->service_charge());
    }

    public function final_price()
    {
        $total_price = $this->total_price();
        $service_charge = $this->service_charge();
        $final_price = $total_price - $service_charge;
        return $final_price;
    }

    public function final_price_text()
    {
        return $this->formatCurrency($this->final_price());
    }

    public function tbl_charges_details()
    {
        $output = '';

        $output .= '
        <tr>
            <td colspan="4" class="text-end">Return Product Price</td>
            <td class="text-end"> - ' . $this->total_price_text() . '</td>
        </tr';
        if ($this->has_return_succeed()) $output .= '
        <tr>
            <td colspan="4" class="text-end">Service Charge</td>
            <td class="text-end"> + ' . $this->service_charge_text() . '</td>
        </tr';
        return $output;
    }

    public function requested_date()
    {
        $row = $this->row();
        $requested_date = $row->requested_date;
        return $this->date_time($requested_date);
    }

    public function pickup_scheduled_date()
    {
        $row = $this->row();
        $pickup_scheduled_date = $row->pickup_scheduled_date;
        return $this->date_time($pickup_scheduled_date);
    }
    public function pickup_scheduled_comment()
    {
        $row = $this->row();
        $pickup_scheduled_comment = $row->pickup_scheduled_comment;
        return $this->unsanitize_text($pickup_scheduled_comment);
    }

    public function accepted_on()
    {
        $row = $this->row();
        $accepted_on = $row->accepted_on;
        return $this->date_time($accepted_on);
    }

    public function rejected_on()
    {
        $row = $this->row();
        $rejected_on = $row->rejected_on;
        return $this->date_time($rejected_on);
    }

    public function completed_date()
    {
        $row = $this->row();
        $completed_date = $row->completed_date;
        return $this->date_time($completed_date);
    }

    public function has_accepted()
    {
        return $this->is_empty($this->accepted_on()) ? false : true;
    }

    public function cancelled_date()
    {
        $row = $this->row();
        $cancelled_on = $row->cancelled_on;
        return $this->date_time($cancelled_on);
    }

    public function return_reason()
    {
        $row = $this->row();
        $return_reason = $row->return_reason;
        return $this->unsanitize_text($return_reason);
    }

    public function processed_comment()
    {
        $row = $this->row();
        $processed_comment = $row->processed_comment;
        return $this->unsanitize_text($processed_comment);
    }


    public function images()
    {
        $row = $this->row();
        $images = $row->images;
        return json_decode($images);
    }

    public function attachments()
    {
        $images = $this->images();
        $output = "";
        if (!is_array($images)) return;
        foreach ($images as $key => $image_id) {
            $index = $key + 1;
            $file_src = $this->get_file_src($image_id);
            $output .= '<a target="_blank" href="' . $file_src . '" >Attachment ' . $index . ' </a>';
        }
        return $output;
    }

    public function viewUrl()
    {
        return $this->order()->url();
    }

    public function updateUrl()
    {
        return $this->order()->admin_view_url();
    }
}

class ReplacementOrder extends Basic
{
    private $row;

    function __construct($replacement_id)
    {
        if (!self::is_replacement_id($replacement_id)) throw new Error("$replacement_id is not a valid Replacement Order Id");
        $this->replacement_id = $replacement_id;
        $this->tbl = $this->ecommerce_replacement_orders_tbl;
        $this->row = $this->row();
    }

    public static function is_replacement_id($replacement_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT replacement_id FROM $Web->ecommerce_replacement_orders_tbl WHERE replacement_id = ? ");
        $stmt->execute([$replacement_id]);
        return $stmt->rowCount() ? true : false;
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->tbl WHERE replacement_id = ?  ");
        $stmt->execute([$this->replacement_id]);
        return  $stmt->fetch();
    }

    public function order_id()
    {
        $row = $this->row();
        return $row->order_id;
    }

    public function order()
    {
        return new _Order($this->order_id());
    }

    public function original_price()
    {
        return $this->order()->total_price();
    }

    public function status()
    {
        $row = $this->row();
        return $row->status;
    }

    public function return_shipping_charge()
    {
        $row = $this->row();
        return $row->return_shipping_charge;
    }

    public function new_order_id()
    {
        $row = $this->row();
        return $row->new_order_id;
    }

    public function newOrder()
    {
        return new _Order($this->new_order_id());
    }

    public function newUserOrder()
    {
        return new Order($this->new_order_id());
    }

    public function status_code()
    {
        $status = $this->status();
        switch ($status) {
            case "cancelled":
                return 0;
                break;
            case "initiated":
                return 1;
                break;
            case "rejected":
                return 2;
                break;
            case "accepted":
                return 3;
                break;
            case "pickup_scheduled":
                return 4;
                break;
            case "completed":
                return 5;
                break;
        }
    }

    public function status_label()
    {
        $status = $this->status();
        $status = strtolower($status);
        switch ($status) {
            case "cancelled":
                return $this->status_to_label("Cancelled", "danger");
                break;
            case "initiated":
                return $this->status_to_label("Initiated", "warning");
                break;
            case "accepted":
                return $this->status_to_label("Accepted", "success");
                break;
            case "rejected":
                return $this->status_to_label("Rejected", "danger");
                break;
            case "pickup_scheduled":
                return $this->status_to_label("Pickup Scheduled", "primary");
                break;
            case "completed":
                return $this->status_to_label("Completed", "success");
                break;
        }
    }


    public function track_class($code)
    {
        $class = '';

        switch ($code) {
            case 1:
                $class .= "done ";
                if ($this->status_code() == "1") $class .= ' active';
                break;
            case 2:
                if ($this->status_code() == "2") $class .= 'done active';
                break;
            case 3:
                if ($this->status_code() == "3") $class .= ' active';
                if (!empty($this->accepted_on())) $class .= ' done';
                break;
            case 4:
                if ($this->status_code() == "4") $class .= ' active ';
                if (!empty($this->pickup_scheduled_date())) $class .= ' done';
                break;
            case 5:
                if ($this->status_code() == "5") $class .= 'done active';
                break;
        }
        return $class;
    }
    public function can_cancel_replacement()
    {
        if ($this->status_code() != "1" && $this->status_code() != "3") return false;
        return true;
    }


    public function requested_date()
    {
        $row = $this->row();
        $requested_date = $row->requested_date;
        return $this->date_time($requested_date);
    }

    public function accepted_on()
    {
        $row = $this->row();
        $accepted_on = $row->accepted_on;
        return $this->date_time($accepted_on);
    }

    public function rejected_on()
    {
        $row = $this->row();
        $rejected_on = $row->rejected_on;
        return $this->date_time($rejected_on);
    }

    public function pickup_scheduled_date()
    {
        $row = $this->row();
        $pickup_scheduled_date = $row->pickup_scheduled_date;
        return $this->date_time($pickup_scheduled_date);
    }
    public function pickup_scheduled_comment()
    {
        $row = $this->row();
        $pickup_scheduled_comment = $row->pickup_scheduled_comment;
        return $this->unsanitize_text($pickup_scheduled_comment);
    }

    public function completed_date()
    {
        $row = $this->row();
        $completed_date = $row->completed_date;
        return $this->date_time($completed_date);
    }

    public function cancelled_date()
    {
        $row = $this->row();
        $cancelled_on = $row->cancelled_on;
        return $this->date_time($cancelled_on);
    }

    public function replacement_reason()
    {
        $row = $this->row();
        $replacement_reason = $row->replacement_reason;
        return $this->unsanitize_text($replacement_reason);
    }

    public function processed_comment()
    {
        $row = $this->row();
        $processed_comment = $row->processed_comment;
        return $this->unsanitize_text($processed_comment);
    }

    public function refund_reason()
    {
        $row = $this->row();
        $refund_reason = $row->refund_reason;
        return $this->unsanitize_text($refund_reason);
    }

    public function images()
    {
        $row = $this->row();
        $images = $row->images;
        return json_decode($images);
    }

    public function attachments()
    {
        $images = $this->images();
        $output = "";
        foreach ($images as $key => $image_id) {
            $index = $key + 1;
            $file_src = $this->get_file_src($image_id);
            $output .= '<a target="_blank" href="' . $file_src . '" >Attachment ' . $index . ' </a>';
        }
        return $output;
    }

    public function viewUrl()
    {
        return $this->order()->url();
    }

    public function updateUrl()
    {
        return $this->order()->admin_view_url();
    }

    public function tbl_charges_details()
    {
        $output = '';

        $output .= '
        <tr>
            <td colspan="4" class="text-end">Return Product Price</td>
            <td class="text-end"> - ' . $this->order()->total_price_text() . '</td>
        </tr';
        $output .= '
        <tr>
            <td colspan="4" class="text-end">Service Charge</td>
            <td class="text-end"> + ' . $this->order()->service_charge_text() . '</td>
        </tr';
        return $output;
    }

    public function final_price_text()
    {
        $total_price =  $this->order()->total_price();
        $service_charge =  $this->order()->service_charge();
        $final_price = $total_price - $service_charge;
        return $this->formatCurrency($final_price);
    }
}

class Dashboard extends Basic
{
    private function get_orders_data_count($status)
    {
        $sql = $this->db()->prepare("SELECT COUNT(order_id) as orders FROM $this->ecommerce_orders_tbl WHERE status = ?");
        $sql->execute([$status]);
        return $sql->fetch()->orders;
    }


    private function get_return_status_count($status)
    {
        $sql = $this->db()->prepare("SELECT COUNT(*) as orders FROM $this->ecommerce_return_orders_tbl WHERE $this->ecommerce_return_orders_tbl.status = ? ");
        $sql->execute([$status]);
        return $sql->fetch()->orders;
    }

    private function get_replacement_status_count($status)
    {
        $sql = $this->db()->prepare("SELECT COUNT(*) as orders FROM $this->ecommerce_replacement_orders_tbl WHERE $this->ecommerce_replacement_orders_tbl.status = ? ");
        $sql->execute([$status]);
        return $sql->fetch()->orders;
    }


    private function get_refund_data_count($status)
    {
        $sql = $this->db()->prepare("SELECT COUNT(*) as orders FROM $this->ecommerce_orders_tbl WHERE refund_status = ? ");
        $sql->execute([$status]);
        return $sql->fetch()->orders;
    }


    public function refund_data()
    {
        $output = new stdClass;
        $output->pending = $this->get_refund_data_count("pending");
        $output->completed = $this->get_refund_data_count("completed");
        return $output;
    }


    public function orders_data()
    {
        $output = new stdClass;
        $output->rtd = $this->get_orders_data_count("RTD");
        $output->scheduled_pickups = $this->get_orders_data_count("PICKUP_SCHEDULED");
        $output->shipped = $this->get_orders_data_count("SHIPPED");
        $output->completed = $this->get_orders_data_count("DELIVERED");
        return $output;
    }
    public function returns_data()
    {
        $output = new stdClass;
        $output->requests = $this->get_return_status_count("initiated");
        $output->accepted = $this->get_return_status_count("accepted");
        $output->scheduled_pickup = $this->get_return_status_count("pickup_scheduled");
        $output->completed = $this->get_return_status_count("completed");
        $output->rejected = $this->get_return_status_count("rejected");
        return $output;
    }

    public function replacements_data()
    {
        $output = new stdClass;
        $output->requests = $this->get_replacement_status_count("initiated");
        $output->accepted = $this->get_replacement_status_count("accepted");
        $output->scheduled_pickup = $this->get_replacement_status_count("pickup_scheduled");
        $output->completed = $this->get_replacement_status_count("completed");
        $output->rejected = $this->get_replacement_status_count("rejected");
        return $output;
    }

    public function service_charge()
    {
        $stmt = $this->db()->query("SELECT IFNULL(SUM(service_charge),0) as charge FROM $this->ecommerce_orders_tbl ");
        return  $stmt->fetch()->charge;
    }

    public function shipping_charge()
    {
        $stmt = $this->db()->query("SELECT IFNULL(SUM(shipping_charge),0) as charge FROM $this->ecommerce_orders_tbl ");
        return  $stmt->fetch()->charge;
    }

    public function total_sale()
    {
        $stmt = $this->db()->query("SELECT COUNT(order_id) as sale FROM $this->ecommerce_orders_tbl WHERE STATUS IN ('SUCCESS', 'LABELLED', 'RTD','SHIPPED','DELIVERED','PICKUP_SCHEDULED') ");
        return  $stmt->fetch()->sale;
    }

    public function withdraw_request_count()
    {
        $stmt = $this->db()->query("SELECT COUNT(withdraw_id) as requests FROM $this->ecommerce_sellers_withdraw_tbl WHERE status = 'pending' ");
        return  $stmt->fetch()->requests;
    }
    public function qc_requests_count()
    {
        $stmt = $this->db()->query("SELECT COUNT(DISTINCT(qvariation_id)) as requests FROM $this->ecommerce_qc_tbl WHERE status= 'pending' ");
        return  $stmt->fetch()->requests;
    }
    public function seller_verification_requests()
    {
        $stmt = $this->db()->query("SELECT COUNT(verification_id) as requests FROM $this->ecommerce_seller_verification_tbl WHERE status= 'pending' ");
        return  $stmt->fetch()->requests;
    }
}

class Service extends Basic
{
    public $service_id;
    private $row;

    /**
     * @param $id = $service_id
     * 
     */
    function __construct($id)
    {
        if (!self::is_service_id($id)) Errors::response("$id is not a valid service id");
        $this->service_id = $id;
        $this->row = $this->row();
    }

    /**
     * @param $id = $service_id
     * 
     */
    public static function is_service_id($id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT service_id FROM $Web->ecommerce_service_tbl WHERE service_id = ? ");
        $stmt->execute([$id]);
        return $stmt->rowCount() ? true : false;
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_service_tbl WHERE service_id = ? ");
        $stmt->execute([$this->service_id]);
        return $stmt->fetch();
    }

    public function name()
    {
        $row = $this->row();
        $name =  $row->service_name;
        return $this->unsanitize_text($name);
    }

    public function charge()
    {
        $row = $this->row();
        $service_charge = $row->service_charge;
        return $service_charge;
    }

    public function chargeText()
    {
        $charge = $this->charge();
        $type = $this->type();
        return $type == "fixed" ? $this->formatCurrency($charge) : $charge . "%";
    }

    public function type()
    {
        $row = $this->row();
        $charge_type = $row->charge_type;
        return $charge_type;
    }
    public function created_date()
    {
        $row = $this->row();
        $created_date = $row->created_date;
        return $this->date_time($created_date);
    }

    public static function tbl()
    {
        global $Web;
        $count =  0;
        $stmt = $Web->db()->query("SELECT service_id FROM $Web->ecommerce_service_tbl ORDER BY service_name ASC ");
        $output = '';
        if (!$stmt->rowCount()) return '<tr><td colspan="5" class="text-center" >No data available in table</td></tr>';
        while ($row =  $stmt->fetch()) {
            $Service = new Service($row->service_id);
            $count++;
            $output  .= '<tr>
            <td>' . $count . '</td>
            <td>' . $Service->name() . '</td>
            <td>' . $Service->chargeText() . '</td>
            <td>' . $Service->created_date() . '</td>
            <td><div>
                                  <a data-action="edit" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                    <span class="svg-icon svg-icon-3">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                      </svg>
                                    </span>
                                  </a>
                                  <a data-id="' . $Service->service_id . '" data-action="delete" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                                    <span class="svg-icon svg-icon-3">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="currentColor"></path>
                                        <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="currentColor"></path>
                                        <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="currentColor"></path>
                                      </svg>
                                    </span>
                                  </a>
                                                                    <form class="needs-validation d-none" novalidate default-validation="true" >
                            <input type="hidden" name="service_id" value="' . $Service->service_id . '" >
                            <div class="fv-row mb-7">
                                <label class="required form-label mb-2">Service Name</label>
                                <input required maxlength="100" rows="5" type="text" class="form-control form-control-solid" name="service_name" value="' . $Service->name() . '">
                            </div>

                            <div class="fv-row mb-7">
                                <label class="required form-label mb-2">Service Charge</label>
                                <input data-mask="integer" required type="text" class="form-control form-control-solid" name="service_charge" value="' . $Service->charge() . '">
                            </div>

                            <div class="fv-row mb-7">
                                <label class="required form-label mb-2">Charge Type</label>
                                <select id="serviceChargeSelect" value="' . $Service->type() . '" required name="charge_type" autocomplete="off" class="form-select form-select-solid" data-placeholder="Select" data-control="select2" data-hide-search="true">
                                    <option value=""></option>
                                    <option value="fixed">Fixed</option>
                                    <option value="percentage">Percentage</option>
                                </select>
                            </div>

                            <div class="justify-right">
                                <a data-bs-dismiss="modal" id=" cancel" class="btn btn-light me-3">Cancel</a>
                                <button type="submit" id="submit" class="btn btn-primary">Submit</button>
                            </div>

                        </form>
                                </div>
            </td>
            </tr>';
        }
        return $output;
    }
}


class PaymentMethod extends Basic
{

    private $row;

    public static function lists()
    {
        return ["Paytm", "Razorpay", "CashOnDelivery"];
    }

    public static function getMethodDetails($paymentMethod)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT * FROM $Web->payment_methods_tbl WHERE uid = ? ");
        $stmt->execute([$paymentMethod]);
        $data =  $stmt->fetch();
        $data->details = json_decode($data->details);
        $data = (object) $data;
        return $data;
    }

    public static function insertPaymentMethod()
    {
        global $Web;

        $paymentMethods = [];

        // Razorpay
        $paymentMethods[] = array(
            "uid" => "Razorpay",
            "name" => "Razorpay",
            "details" => array(
                "keyId" => "",
                "keySecret" => ""
            )
        );

        // Paytm
        $paymentMethods[] = array(
            "uid" => "Paytm",
            "name" => "Paytm",
            "details" => array(
                "merchantKey" => "",
                "merchantMid" => "",
                "environment" => "",
            )
        );

        $paymentMethods[] = array(
            "uid" => "CashOnDelivery",
            "name" => "Cash On Delivery",
            "details" => array()
        );


        try {
            foreach ($paymentMethods as $data) {
                $uid = $data["uid"];
                $name = $data["name"];
                $details = $data["details"];
                $details = json_encode($details);

                $last_modified = "";
                $status = "disabled";

                if (self::is_uid($uid)) {
                    $stmt = $Web->db()->query("UPDATE $Web->payment_methods_tbl SET name = '$name' WHERE uid = '$uid' ");
                } else {
                    $stmt = $Web->db()->query("INSERT INTO $Web->payment_methods_tbl (`uid`,`name`,`last_modified`,`status`,`details`) VALUES ('$uid','$name','$last_modified','$status','$details') ");
                }
            }
        } catch (Exception $e) {
            Errors::response("Error in creating payment methods" . $e->getMessage());
        }
    }

    public static function is_uid($uid)
    {
        global $Web;
        $stmt = $Web->db()->query("SELECT uid FROM $Web->payment_methods_tbl WHERE uid = '$uid' ");
        return $stmt->rowCount() ? true : false;
    }

    public static function tblList()
    {
        self::insertPaymentMethod();

        global $Web;
        $output = '';
        $count = 0;
        $stmt = $Web->db()->query("SELECT * FROM $Web->payment_methods_tbl ");
        if (!$stmt->rowCount()) return '<tr><td class="text-center" colspan="5">No data in table</td></tr>';
        $lists = $stmt->fetchAll();
        if (!count($lists)) return '<tr><td class="text-center" colspan="5">No data in table</td></tr>';
        foreach ($lists as $row) {
            $method_id = $row->method_id;
            $Payment = new PaymentMethod($method_id);
            $key = $count + 1;
            $count++;
            $output .= '
            <tr>
                <td>' . $key . '</td>
                <td>' . $Payment->name() . '</td>
                <td class="last_modified" >' . $Payment->last_modified() . '</td>
                <td>' . $Payment->status_label() . '</td>
                <td>' . $Payment->actions() . '</td>
            </tr>';
        }
        return $output;
    }

    public static function isPaytmActive()
    {
        $data = self::getMethodDetails("Paytm");
        return $data->status === "enabled" ? true : false;
    }

    public static function isRazorpayActive()
    {
        $data = self::getMethodDetails("Razorpay");
        return $data->status === "enabled" ? true : false;
    }

    public static function is_COD_Active()
    {
        $data = self::getMethodDetails("CashOnDelivery");
        return $data->status === "enabled" ? true : false;
    }

    function __construct($id)
    {
        if (!$this->is_method_id($id)) Errors::response("$id is not a valid payment method id");
        $this->method_id = $id;
        $this->row = $this->row();
    }

    public static function is_method_id($id)
    {
        global $Web;
        $stmt = $Web->db()->query("SELECT method_id FROM $Web->payment_methods_tbl WHERE method_id = '$id' ");
        return $stmt->rowCount() ? true : false;
    }

    public function actions()
    {

        $statusSvg = $this->status() == "enabled" ? '<i class="fs-2 fas fa-eye-slash"></i>' : '<i class="fs-2 fas fa-eye"></i>';

        $statusBtn = empty($this->details()) ? "" : '<button data-id="' . $this->method_id . '" data-action="edit" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
        <span class="svg-icon svg-icon-3">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
            </svg>
        </span>
    </button>';

        return '<div class="editWrapper" >
        ' . $statusBtn . '
        <button data-id="' . $this->method_id . '" data-action="changeStatus" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
            ' . $statusSvg . '
        </button>
    </div>';
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->payment_methods_tbl WHERE method_id = ? ");
        $stmt->execute([$this->method_id]);
        return $stmt->fetch();
    }

    public function name()
    {
        $row = $this->row();
        $name = $row->name;
        return $this->unsanitize_text($name);
    }

    public function uid()
    {
        $row = $this->row();
        $uid = $row->uid;
        return $uid;
    }

    public function status()
    {
        $row = $this->row();
        $status = $row->status;
        return $status;
    }

    public function status_label()
    {
        $status = $this->status();
        if ($status === "enabled") return $this->status_to_label($status, "success");
        return $this->status_to_label($status, "danger");
    }

    public function update()
    {
        $this->row = $this->row();
    }

    public function last_modified()
    {
        $row = $this->row();
        $last_modified = $row->last_modified;
        return $this->date_time($last_modified) ?? "NA";
    }

    public function details()
    {
        $row = $this->row();
        $details = $row->details;
        if (empty($details)) $details = '{}';
        $details = json_decode($details);
        return $details;
    }

    public function editForm()
    {
        $details = $this->details();

        $name = $this->name();
        switch ($name) {
            case "Paytm":

                $merchantKey = $details->merchantKey;
                $merchantMid = $details->merchantMid;
                $environment = $details->environment;

                return '
                <div class="fv-row mb-7">
                    <label class="required form-label mb-2"> Merchant Key</label>
                    <input required name="merchantKey" type="text" class="form-control form-control-solid" value="' . $merchantKey . '">
                    <div class="invalid-feedback" >Merchant Key is required</div>
                </div>

                    <div class="fv-row mb-7">
                        <label class="required form-label mb-2">Merchant Mid</label>
                        <input  required type="text" class="form-control form-control-solid" name="merchantMid" value="' . $merchantMid . '">
                        <div class="invalid-feedback" >Merchant Mid is required</div>
                        </div>

                <div class="fv-row mb-7">
                    <label class="required form-label mb-2">Environment</label>
                    <select value="' . $environment . '" required name="environment" autocomplete="off" class="form-select form-select-solid" data-placeholder="Select" data-control="select2" data-hide-search="true" >
                        <option value=""></option>
                        <option value="TEST">Test</option>
                        <option value="PROD">Production</option>
                    </select>
                    <div class="invalid-feedback" >Environment is required</div>
                </div> ';
                break;

            case "Razorpay":

                $keyId = $details->keyId;
                $keySecret = $details->keySecret;

                return '
                    <div class="fv-row mb-7">
                        <label class="required form-label mb-2">Key Id</label>
                        <input required name="keyId" type="text" class="form-control form-control-solid" value="' . $keyId . '">
                        <div class="invalid-feedback" >Key Id is required</div>
                        </div>

                    <div class="fv-row mb-7">
                        <label class="required form-label mb-2">Key Secret</label>
                        <input  required type="text" class="form-control form-control-solid" name="keySecret" value="' . $keySecret . '">
                        <div class="invalid-feedback" >Key Secret is required</div>
                        </div>';

                break;
        }
    }
}

class OrderTransaction extends Basic
{

    private $row;

    function __construct($id)
    {
        if (!self::is_transaction_id($id)) Errors::response("Invalid transaction id");
        $this->transaction_id = $id;
        $this->row = $this->row();
    }

    public static function generate_transaction_id()
    {
        global $Web;
        $transaction_id = rand(10000000, 99999999);
        return self::is_transaction_id($transaction_id) ? self::generate_transaction_id() : $transaction_id;
    }

    public static function is_transaction_id($transaction_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT transaction_id FROM $Web->ecommerce_order_transactions_tbl WHERE transaction_id = ? ");
        $stmt->execute([$transaction_id]);
        return $stmt->rowCount() ? true : false;
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->ecommerce_order_transactions_tbl WHERE transaction_id = ?  ");
        $stmt->execute([$this->transaction_id]);
        return $stmt->fetch();
    }

    public function status()
    {
        $row = $this->row();
        $status = $row->status;
        return $status;
    }

    public function phone()
    {
        $order_id = $this->orders()[0];
        $Order = new Order($order_id);
        return $Order->address()->mobile_number;;
    }

    public function full_name()
    {
        $order_id = $this->orders()[0];
        $Order = new Order($order_id);
        return $Order->address()->full_name;
    }

    public function orders()
    {
        $row = $this->row();
        $orders = $row->orders;
        return json_decode($orders);
    }

    public function buyer()
    {
        $row = $this->row();
        return $row->buyer_id;
    }

    public function payment_method()
    {
        $row = $this->row();
        return $row->payment_method;
    }

    public function payable_amount()
    {
        $row = $this->row();
        return $row->payable_amount;
    }

    public function transaction_date()
    {
        $row = $this->row();
        $transaction_date =  $row->transaction_date;
        return $this->date_time($transaction_date);
    }

    public function payable_amount_text()
    {
        $payable_amount = $this->payable_amount();
        return $this->formatCurrency($payable_amount);
    }

    public function proceed_url()
    {
        $payment_method = $this->payment_method();
        switch ($payment_method) {
            case "Paytm":
                return $this->base_url() . '/pay/paytm/pay?i=' . $this->transaction_id;
                break;
            case "Razorpay":
                return $this->base_url() . '/pay/razorpay/pay?i=' . $this->transaction_id;
                break;
            case "CashOnDelivery":
                return $this->base_url() . '/orders/';
                break;
        }
    }

    public static function is_razorpay_order_id($razorpay_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT razorpay_id FROM $Web->ecommerce_order_transactions_tbl WHERE razorpay_id = ? ");
        $stmt->execute([$razorpay_id]);
        return $stmt->rowCount() ? true : false;
    }

    public static function transaction_id_by_razorpay($razorpay_id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT transaction_id FROM $Web->ecommerce_order_transactions_tbl WHERE razorpay_id = ? ");
        $stmt->execute([$razorpay_id]);
        $transaction_id =  $stmt->fetch()->transaction_id;
        return $transaction_id;
    }


    // Cards


    public static function checksumMismatchCard()
    {
        global $Web;
        return '<div class="mw-400px m-auto card">
                                <div class="card-body">
                                    <div class="py-4 text-center">
                                        <span class="svg-icon svg-icon-danger svg-icon-5hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black" />
                                                <rect x="7" y="15.3137" width="12" height="2" rx="1" transform="rotate(-45 7 15.3137)" fill="black" />
                                                <rect x="8.41422" y="7" width="12" height="2" rx="1" transform="rotate(45 8.41422 7)" fill="black" />
                                            </svg></span>
                                    </div>
                                    <div class="text-center">
                                        <h2 class="text-uppercase text-muted">Payment Mismatched</h2>
                                    </div>
                                    <div class="mb-2 text-muted fs-4">The transaction is not a valid transaction.</div>
                                   
                                    <a class="w-100 btn btn-primary" href="' . $Web->base_url() . '/orders/">My Orders</a>
                                </div>

                            </div>';
    }

    public function PaymentFailedCard($msg = false)
    {
        $err = $msg === false ? 'Your transation has been failed.' : $msg;
        return '<div class="mw-400px m-auto card">
                                <div class="card-body">
                                    <div class="py-4 text-center">
                                        <span class="svg-icon svg-icon-danger svg-icon-5hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black" />
                                                <rect x="7" y="15.3137" width="12" height="2" rx="1" transform="rotate(-45 7 15.3137)" fill="black" />
                                                <rect x="8.41422" y="7" width="12" height="2" rx="1" transform="rotate(45 8.41422 7)" fill="black" />
                                            </svg></span>
                                    </div>
                                    <div class="text-center">
                                        <h2 class="text-uppercase text-muted">Payment Failed</h2>
                                    </div>
                                    <div class="mb-2 text-muted fs-4">' . $err . '</div>
                                   
                                    <div class="border-bottom py-4 fw-bold text-gray-600 align-justify-between">
                                        <div>
                                            <span class="svg-icon svg-icon-2 me-2">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                                                    <path opacity="0.3" d="M19 3.40002C18.4 3.40002 18 3.80002 18 4.40002V8.40002H14V4.40002C14 3.80002 13.6 3.40002 13 3.40002C12.4 3.40002 12 3.80002 12 4.40002V8.40002H8V4.40002C8 3.80002 7.6 3.40002 7 3.40002C6.4 3.40002 6 3.80002 6 4.40002V8.40002H2V4.40002C2 3.80002 1.6 3.40002 1 3.40002C0.4 3.40002 0 3.80002 0 4.40002V19.4C0 20 0.4 20.4 1 20.4H19C19.6 20.4 20 20 20 19.4V4.40002C20 3.80002 19.6 3.40002 19 3.40002ZM18 10.4V13.4H14V10.4H18ZM12 10.4V13.4H8V10.4H12ZM12 15.4V18.4H8V15.4H12ZM6 10.4V13.4H2V10.4H6ZM2 15.4H6V18.4H2V15.4ZM14 18.4V15.4H18V18.4H14Z" fill="black"></path>
                                                    <path d="M19 0.400024H1C0.4 0.400024 0 0.800024 0 1.40002V4.40002C0 5.00002 0.4 5.40002 1 5.40002H19C19.6 5.40002 20 5.00002 20 4.40002V1.40002C20 0.800024 19.6 0.400024 19 0.400024Z" fill="black"></path>
                                                </svg>
                                            </span>Transaction Date
                                        </div>
                                        <div class="fw-bolder text-end">' . $this->transaction_date() . '</div>
                                    </div>


                                    <div class="border-bottom py-4 fw-bold text-gray-600 align-justify-between">
                                        <div>
                                            <span class="svg-icon svg-icon-2 me-2">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path opacity="0.3" d="M3.20001 5.91897L16.9 3.01895C17.4 2.91895 18 3.219 18.1 3.819L19.2 9.01895L3.20001 5.91897Z" fill="black"></path>
                                                    <path opacity="0.3" d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21C21.6 10.9189 22 11.3189 22 11.9189V15.9189C22 16.5189 21.6 16.9189 21 16.9189H16C14.3 16.9189 13 15.6189 13 13.9189ZM16 12.4189C15.2 12.4189 14.5 13.1189 14.5 13.9189C14.5 14.7189 15.2 15.4189 16 15.4189C16.8 15.4189 17.5 14.7189 17.5 13.9189C17.5 13.1189 16.8 12.4189 16 12.4189Z" fill="black"></path>
                                                    <path d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21V7.91895C21 6.81895 20.1 5.91895 19 5.91895H3C2.4 5.91895 2 6.31895 2 6.91895V20.9189C2 21.5189 2.4 21.9189 3 21.9189H19C20.1 21.9189 21 21.0189 21 19.9189V16.9189H16C14.3 16.9189 13 15.6189 13 13.9189Z" fill="black"></path>
                                                </svg>
                                            </span>Payment Method
                                        </div>
                                        <div class="fw-bolder text-end">' . $this->payment_method() . '</div>
                                    </div>


                                    <div class="border-bottom py-4 fw-bold text-gray-600 align-justify-between">
                                        <div>
                                            <span class="svg-icon svg-icon-2 me-2">
                                               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <path opacity="0.3" d="M12.5 22C11.9 22 11.5 21.6 11.5 21V3C11.5 2.4 11.9 2 12.5 2C13.1 2 13.5 2.4 13.5 3V21C13.5 21.6 13.1 22 12.5 22Z" fill="black"/>
                                                <path d="M17.8 14.7C17.8 15.5 17.6 16.3 17.2 16.9C16.8 17.6 16.2 18.1 15.3 18.4C14.5 18.8 13.5 19 12.4 19C11.1 19 10 18.7 9.10001 18.2C8.50001 17.8 8.00001 17.4 7.60001 16.7C7.20001 16.1 7 15.5 7 14.9C7 14.6 7.09999 14.3 7.29999 14C7.49999 13.8 7.80001 13.6 8.20001 13.6C8.50001 13.6 8.69999 13.7 8.89999 13.9C9.09999 14.1 9.29999 14.4 9.39999 14.7C9.59999 15.1 9.8 15.5 10 15.8C10.2 16.1 10.5 16.3 10.8 16.5C11.2 16.7 11.6 16.8 12.2 16.8C13 16.8 13.7 16.6 14.2 16.2C14.7 15.8 15 15.3 15 14.8C15 14.4 14.9 14 14.6 13.7C14.3 13.4 14 13.2 13.5 13.1C13.1 13 12.5 12.8 11.8 12.6C10.8 12.4 9.99999 12.1 9.39999 11.8C8.69999 11.5 8.19999 11.1 7.79999 10.6C7.39999 10.1 7.20001 9.39998 7.20001 8.59998C7.20001 7.89998 7.39999 7.19998 7.79999 6.59998C8.19999 5.99998 8.80001 5.60005 9.60001 5.30005C10.4 5.00005 11.3 4.80005 12.3 4.80005C13.1 4.80005 13.8 4.89998 14.5 5.09998C15.1 5.29998 15.6 5.60002 16 5.90002C16.4 6.20002 16.7 6.6 16.9 7C17.1 7.4 17.2 7.69998 17.2 8.09998C17.2 8.39998 17.1 8.7 16.9 9C16.7 9.3 16.4 9.40002 16 9.40002C15.7 9.40002 15.4 9.29995 15.3 9.19995C15.2 9.09995 15 8.80002 14.8 8.40002C14.6 7.90002 14.3 7.49995 13.9 7.19995C13.5 6.89995 13 6.80005 12.2 6.80005C11.5 6.80005 10.9 7.00005 10.5 7.30005C10.1 7.60005 9.79999 8.00002 9.79999 8.40002C9.79999 8.70002 9.9 8.89998 10 9.09998C10.1 9.29998 10.4 9.49998 10.6 9.59998C10.8 9.69998 11.1 9.90002 11.4 9.90002C11.7 10 12.1 10.1 12.7 10.3C13.5 10.5 14.2 10.7 14.8 10.9C15.4 11.1 15.9 11.4 16.4 11.7C16.8 12 17.2 12.4 17.4 12.9C17.6 13.4 17.8 14 17.8 14.7Z" fill="black"/>
                                                </svg>
                                            </span>Transaction Amount
                                        </div>
                                        <div class="fw-bolder text-end">' . $this->payable_amount_text() . '</div>
                                    </div>

                                    <div class="border-bottom py-4 fw-bold text-gray-600 align-justify-between">
                                        <div>
                                            <span class="svg-icon svg-icon-2 me-2">
                                               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <path d="M22 7H2V11H22V7Z" fill="black"/>
                                                <path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
                                                </svg>
                                            </span>Order Id
                                        </div>
                                        <div class="fw-bolder text-end">#' . $this->transaction_id . '</div>
                                    </div>

                                    <a class="w-100 btn btn-primary" href="' . $this->base_url() . '/orders/">My Orders</a>
                                </div>

                            </div>';
    }

    public function PaymentSuccessCard()
    {
        return '<div class="mw-400px mb-4 m-auto card">
                                <div class="card-body">
                                    <div class="py-4 text-center">
                                        <span class="svg-icon svg-icon-success svg-icon-5hx"><svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24">
                                                <path d="M10.0813 3.7242C10.8849 2.16438 13.1151 2.16438 13.9187 3.7242V3.7242C14.4016 4.66147 15.4909 5.1127 16.4951 4.79139V4.79139C18.1663 4.25668 19.7433 5.83365 19.2086 7.50485V7.50485C18.8873 8.50905 19.3385 9.59842 20.2758 10.0813V10.0813C21.8356 10.8849 21.8356 13.1151 20.2758 13.9187V13.9187C19.3385 14.4016 18.8873 15.491 19.2086 16.4951V16.4951C19.7433 18.1663 18.1663 19.7433 16.4951 19.2086V19.2086C15.491 18.8873 14.4016 19.3385 13.9187 20.2758V20.2758C13.1151 21.8356 10.8849 21.8356 10.0813 20.2758V20.2758C9.59842 19.3385 8.50905 18.8873 7.50485 19.2086V19.2086C5.83365 19.7433 4.25668 18.1663 4.79139 16.4951V16.4951C5.1127 15.491 4.66147 14.4016 3.7242 13.9187V13.9187C2.16438 13.1151 2.16438 10.8849 3.7242 10.0813V10.0813C4.66147 9.59842 5.1127 8.50905 4.79139 7.50485V7.50485C4.25668 5.83365 5.83365 4.25668 7.50485 4.79139V4.79139C8.50905 5.1127 9.59842 4.66147 10.0813 3.7242V3.7242Z" fill="#00A3FF" />
                                                <path class="permanent" d="M14.8563 9.1903C15.0606 8.94984 15.3771 8.9385 15.6175 9.14289C15.858 9.34728 15.8229 9.66433 15.6185 9.9048L11.863 14.6558C11.6554 14.9001 11.2876 14.9258 11.048 14.7128L8.47656 12.4271C8.24068 12.2174 8.21944 11.8563 8.42911 11.6204C8.63877 11.3845 8.99996 11.3633 9.23583 11.5729L11.3706 13.4705L14.8563 9.1903Z" fill="white" />
                                            </svg></span>
                                    </div>
                                    <div class="text-center">
                                        <h2 class="text-uppercase text-muted">Payment Successfull</h2>
                                    </div>

                                    <div class="mb-2 text-muted fs-4">Your transation has been successfull.</div>

                                    <div class="border-bottom py-4 fw-bold text-gray-600 align-justify-between">
                                        <div>
                                            <span class="svg-icon svg-icon-2 me-2">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                                                    <path opacity="0.3" d="M19 3.40002C18.4 3.40002 18 3.80002 18 4.40002V8.40002H14V4.40002C14 3.80002 13.6 3.40002 13 3.40002C12.4 3.40002 12 3.80002 12 4.40002V8.40002H8V4.40002C8 3.80002 7.6 3.40002 7 3.40002C6.4 3.40002 6 3.80002 6 4.40002V8.40002H2V4.40002C2 3.80002 1.6 3.40002 1 3.40002C0.4 3.40002 0 3.80002 0 4.40002V19.4C0 20 0.4 20.4 1 20.4H19C19.6 20.4 20 20 20 19.4V4.40002C20 3.80002 19.6 3.40002 19 3.40002ZM18 10.4V13.4H14V10.4H18ZM12 10.4V13.4H8V10.4H12ZM12 15.4V18.4H8V15.4H12ZM6 10.4V13.4H2V10.4H6ZM2 15.4H6V18.4H2V15.4ZM14 18.4V15.4H18V18.4H14Z" fill="black"></path>
                                                    <path d="M19 0.400024H1C0.4 0.400024 0 0.800024 0 1.40002V4.40002C0 5.00002 0.4 5.40002 1 5.40002H19C19.6 5.40002 20 5.00002 20 4.40002V1.40002C20 0.800024 19.6 0.400024 19 0.400024Z" fill="black"></path>
                                                </svg>
                                            </span>Transaction Date
                                        </div>
                                        <div class="fw-bolder text-end">' . $this->transaction_date() . '</div>
                                    </div>


                                    <div class="border-bottom py-4 fw-bold text-gray-600 align-justify-between">
                                        <div>
                                            <span class="svg-icon svg-icon-2 me-2">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path opacity="0.3" d="M3.20001 5.91897L16.9 3.01895C17.4 2.91895 18 3.219 18.1 3.819L19.2 9.01895L3.20001 5.91897Z" fill="black"></path>
                                                    <path opacity="0.3" d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21C21.6 10.9189 22 11.3189 22 11.9189V15.9189C22 16.5189 21.6 16.9189 21 16.9189H16C14.3 16.9189 13 15.6189 13 13.9189ZM16 12.4189C15.2 12.4189 14.5 13.1189 14.5 13.9189C14.5 14.7189 15.2 15.4189 16 15.4189C16.8 15.4189 17.5 14.7189 17.5 13.9189C17.5 13.1189 16.8 12.4189 16 12.4189Z" fill="black"></path>
                                                    <path d="M13 13.9189C13 12.2189 14.3 10.9189 16 10.9189H21V7.91895C21 6.81895 20.1 5.91895 19 5.91895H3C2.4 5.91895 2 6.31895 2 6.91895V20.9189C2 21.5189 2.4 21.9189 3 21.9189H19C20.1 21.9189 21 21.0189 21 19.9189V16.9189H16C14.3 16.9189 13 15.6189 13 13.9189Z" fill="black"></path>
                                                </svg>
                                            </span>Payment Method
                                        </div>
                                        <div class="fw-bolder text-end">' . $this->payment_method() . '</div>
                                    </div>


                                    <div class="border-bottom py-4 fw-bold text-gray-600 align-justify-between">
                                        <div>
                                            <span class="svg-icon svg-icon-2 me-2">
                                               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <path opacity="0.3" d="M12.5 22C11.9 22 11.5 21.6 11.5 21V3C11.5 2.4 11.9 2 12.5 2C13.1 2 13.5 2.4 13.5 3V21C13.5 21.6 13.1 22 12.5 22Z" fill="black"/>
                                                <path d="M17.8 14.7C17.8 15.5 17.6 16.3 17.2 16.9C16.8 17.6 16.2 18.1 15.3 18.4C14.5 18.8 13.5 19 12.4 19C11.1 19 10 18.7 9.10001 18.2C8.50001 17.8 8.00001 17.4 7.60001 16.7C7.20001 16.1 7 15.5 7 14.9C7 14.6 7.09999 14.3 7.29999 14C7.49999 13.8 7.80001 13.6 8.20001 13.6C8.50001 13.6 8.69999 13.7 8.89999 13.9C9.09999 14.1 9.29999 14.4 9.39999 14.7C9.59999 15.1 9.8 15.5 10 15.8C10.2 16.1 10.5 16.3 10.8 16.5C11.2 16.7 11.6 16.8 12.2 16.8C13 16.8 13.7 16.6 14.2 16.2C14.7 15.8 15 15.3 15 14.8C15 14.4 14.9 14 14.6 13.7C14.3 13.4 14 13.2 13.5 13.1C13.1 13 12.5 12.8 11.8 12.6C10.8 12.4 9.99999 12.1 9.39999 11.8C8.69999 11.5 8.19999 11.1 7.79999 10.6C7.39999 10.1 7.20001 9.39998 7.20001 8.59998C7.20001 7.89998 7.39999 7.19998 7.79999 6.59998C8.19999 5.99998 8.80001 5.60005 9.60001 5.30005C10.4 5.00005 11.3 4.80005 12.3 4.80005C13.1 4.80005 13.8 4.89998 14.5 5.09998C15.1 5.29998 15.6 5.60002 16 5.90002C16.4 6.20002 16.7 6.6 16.9 7C17.1 7.4 17.2 7.69998 17.2 8.09998C17.2 8.39998 17.1 8.7 16.9 9C16.7 9.3 16.4 9.40002 16 9.40002C15.7 9.40002 15.4 9.29995 15.3 9.19995C15.2 9.09995 15 8.80002 14.8 8.40002C14.6 7.90002 14.3 7.49995 13.9 7.19995C13.5 6.89995 13 6.80005 12.2 6.80005C11.5 6.80005 10.9 7.00005 10.5 7.30005C10.1 7.60005 9.79999 8.00002 9.79999 8.40002C9.79999 8.70002 9.9 8.89998 10 9.09998C10.1 9.29998 10.4 9.49998 10.6 9.59998C10.8 9.69998 11.1 9.90002 11.4 9.90002C11.7 10 12.1 10.1 12.7 10.3C13.5 10.5 14.2 10.7 14.8 10.9C15.4 11.1 15.9 11.4 16.4 11.7C16.8 12 17.2 12.4 17.4 12.9C17.6 13.4 17.8 14 17.8 14.7Z" fill="black"/>
                                                </svg>
                                            </span>Transaction Amount
                                        </div>
                                        <div class="fw-bolder text-end">' . $this->payable_amount_text() . '</div>
                                    </div>

                                    <div class="border-bottom py-4 fw-bold text-gray-600 align-justify-between">
                                        <div>
                                            <span class="svg-icon svg-icon-2 me-2">
                                               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <path d="M22 7H2V11H22V7Z" fill="black"/>
                                                <path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
                                                </svg>
                                            </span>Transaction Id
                                        </div>
                                        <div class="fw-bolder text-end">#' . $this->transaction_id . '</div>
                                    </div>

                                    <a class="w-100 btn btn-primary" href="' . $this->base_url() . '/orders/">My Orders</a>
                                </div>

                            </div>';
    }
}

class Ticket extends Basic
{
    public $ticket_id;
    private $row;

    function __construct($id)
    {
        if (!self::is_ticket_id($id)) Errors::response("Invalid ticket id");
        $this->ticket_id = $id;
        $this->row = $this->row();
    }

    public static function is_ticket_id($id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT ticket_id FROM $Web->support_tickets_tbl WHERE ticket_id = ? ");
        $stmt->execute([$id]);
        return $stmt->rowCount() ? true : false;
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->support_tickets_tbl WHERE ticket_id=  ? ");
        $stmt->execute([$this->ticket_id]);
        return $stmt->fetch();
    }

    public function creator()
    {
        $row = $this->row();
        return $row->creator;
    }

    public function subject()
    {
        $row = $this->row();
        $subject =  $row->subject;
        return $this->unsanitize_text($subject);
    }

    public function created_at()
    {
        $row = $this->row();
        $created_at =  $row->created_at;
        return  $this->date_time($$created_at);
    }

    public function last_reply_on()
    {
        $row = $this->row();
        $last_reply_on =  $row->last_reply_on;
        return $this->date_time($last_reply_on);
    }

    public function activated_on()
    {
        $row = $this->row();
        $activated_on =  $row->activated_on;
        return $this->date_time($activated_on);
    }

    public function closed_on()
    {
        $row = $this->row();
        $closed_on =  $row->closed_on;
        return $this->date_time($closed_on);
    }

    public function closed_by()
    {
        $row = $this->row();
        $closed_by =  $row->closed_by;
        return $closed_by == $this->creator() ? "You" : "Admin";
    }

    public function status()
    {
        $row = $this->row();
        $status = $row->status;
        return $status;
    }
    public function status_label()
    {
        $status = $this->status();
        switch ($status) {
            case "pending":
                return $this->status_to_label($status, "warning");
            case "active":
                return $this->status_to_label($status, "success");
            case "closed":
                return $this->status_to_label($status, "danger");
        }
    }

    public function url()
    {
        return $this->base_url() . '/support/ticket?id=' . $this->ticket_id;
    }
    public function seller_view_url()
    {
        return $this->seller_url() . '/support/ticket?id=' . $this->ticket_id;
    }

    public function a_url()
    {
        return $this->admin_url() . '/support/ticket?id=' . $this->ticket_id;
    }

    public  function is_message_id($id)
    {
        $stmt = $this->db()->prepare("SELECT message FROM $this->support_ticket_messages_tbl WHERE ticket_id = ? AND message_id = ? ");
        $stmt->execute([$this->ticket_id, $id]);
        return $stmt->rowCount() ? true : false;
    }

    public function m_row($id)
    {
        $stmt = $this->db()->prepare("SELECT * FROM $this->support_ticket_messages_tbl WHERE ticket_id= ? AND message_id = ? ");
        $stmt->execute([$this->ticket_id, $id]);
        return  $stmt->fetch();
    }

    public function m_replier($id)
    {
        $row = $this->m_row($id);
        return $row->replier;
    }

    public function message($id)
    {
        $row = $this->m_row($id);
        $message =  $row->message;
        return $this->unsanitize_text($message);
    }

    public function m_date($id)
    {
        $row = $this->m_row($id);
        $date =  $row->date;
        return $this->time_to_Ago($date);
    }

    public function files($id)
    {
        $row = $this->m_row($id);
        $files =  $row->files;
        $files = $files ?? '[]';
        return json_decode($files);
    }

    public function chats()
    {
        $stmt = $this->db()->prepare("SELECT message_id FROM $this->support_ticket_messages_tbl WHERE ticket_id = ? ORDER BY date DESC ");
        $stmt->execute([$this->ticket_id]);

        $output = '';
        while ($row = $stmt->fetch()) {
            $output .= $this->create_card($row->message_id);
        }
        return $output;
    }

    public function create_card($id)
    {
        $replier = $this->m_replier($id);
        $User = new User($replier);
        $date = $this->m_date($id);
        $message = $this->message($id);

        $flex = "start";
        if ($this->creator() !== $replier) {
            $flex = "end";
        }

        return '<div class="d-flex w-100 card justify-content-' . $flex . ' mb-2 mb-lg-6">
        <div class="d-flex bg-white p-4 rounded flex-column align-items-start">
            <div class="d-flex align-items-center mb-2">
                <div class="symbol symbol-35px symbol-circle">
                    <img alt="Pic" src="' . $User->avatar() . '">
                </div>
                <div class="ms-3">
                    <a class="fs-5 fw-bold text-gray-900 text-hover-primary me-1">' . $User->full_name() . '</a>
                    <div class="text-muted fs-7 mb-1">' . $date . '</div>
                </div>
            </div>
            <div class="p-5 rounded text-dark text-start" >
            ' . $message . '
            ' . $this->files_view($id) . '
            </div>
        </div>
    </div>';
    }

    public function files_view($id)
    {
        $output = "";
        $files = $this->files($id);
        if (!is_array($files)) return;
        foreach ($files as $file_id) {
            $src = $this->file_preview_url($file_id);

            $data = $this->get_file_data($file_id);
            $name = $data->name;
            $preview_url = $data->preview_url;
            $url = $data->url;
            $ext = $data->ext;
            $showExt = $data->showExt;
            $text = "";
            if ($showExt) {
                $text = '<div class="text-muted center-xy fs-7">' . $ext . '</div>';
            }

            $output .= '
            <a href="' . $url . '" target="_blank" class="w-80px h-80px justify-align-center mr-3 position-relative opacity-100-hover bg-light-info">
                <div class=" justify-align-center  h-100">
                <img class="img-fluid mh-100" src="' . $preview_url . '" alt="" srcset="">
                ' . $text . '
                </div>
            </a>';
        }

        if (!empty($output)) $output = '<div class="mt-4 d-flex flex-wrap gap-4" >' . $output . '</div>';

        return $output;
    }
}

class HomePageSetting extends Basic
{
    public static function choose_categories($parent_id = false)
    {
        $output = '';
        $parent_id = $parent_id == false ? 0 : $parent_id;
        global $Web;
        $stmt = $Web->db()->prepare("SELECT category_id,category FROM $Web->ecommerce_category_tbl WHERE parent_id = ? AND status = 'active'  ");
        $stmt->execute([$parent_id]);
        while ($row =  $stmt->fetch()) {
            $category_id = $row->category_id;
            $C = new Category($category_id);

            if (!$C->has_or_child_content()) continue;
            if ($C->is_last_category()) {
                $url = $Web->base_url() . '/product/search?category=' . $category_id;
                $output .= ' <div data-choose-category="done" data-text="' . $C->category() . '" data-id="' . $row->category_id . '"  class="p-4 hover cursor-pointer category-list border-bottom align-justify-between">
                <div class="fs-4 d-flex fw-bold">  ' . $C->category() . '</div>
                <span class="svg-icon svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path opacity="0.5" d="M12.8956 13.4982L10.7949 11.2651C10.2697 10.7068 9.38251 10.7068 8.85731 11.2651C8.37559 11.7772 8.37559 12.5757 8.85731 13.0878L12.7499 17.2257C13.1448 17.6455 13.8118 17.6455 14.2066 17.2257L21.1427 9.85252C21.6244 9.34044 21.6244 8.54191 21.1427 8.02984C20.6175 7.47154 19.7303 7.47154 19.2051 8.02984L14.061 13.4982C13.7451 13.834 13.2115 13.834 12.8956 13.4982Z" fill="black"/>
                <path d="M7.89557 13.4982L5.79487 11.2651C5.26967 10.7068 4.38251 10.7068 3.85731 11.2651C3.37559 11.7772 3.37559 12.5757 3.85731 13.0878L7.74989 17.2257C8.14476 17.6455 8.81176 17.6455 9.20663 17.2257L16.1427 9.85252C16.6244 9.34044 16.6244 8.54191 16.1427 8.02984C15.6175 7.47154 14.7303 7.47154 14.2051 8.02984L9.06096 13.4982C8.74506 13.834 8.21146 13.834 7.89557 13.4982Z" fill="black"/>
                </svg>
                    </span>
            </div>';
            } else {
                $output .= ' <div data-choose-category="true" data-id="' . $row->category_id . '"  class="p-4 hover cursor-pointer category-list border-bottom align-justify-between">
                <div class="fs-4 d-flex fw-bold">  ' . $C->category() . '</div>
                    <span class="svg-icon svg-icon-muted svg-icon-2x"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z" fill="black" />
                        </svg>
                    </span>
            </div>';
            }
        }
        return $output;
    }
}



class Component extends Basic
{
    private $component_id;
    private $row;

    function __construct($id)
    {
        if (!self::is_component_id($id)) throw new Error($id . " is not a valid component id");
        $this->component_id = $id;
    }

    public static function is_component_id($id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT component_id FROM $Web->components_tbl WHERE component_id = ?");
        $stmt->execute([$id]);
        return $stmt->rowCount() ? true : false;
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->components_tbl WHERE component_id = ? ");
        $stmt->execute([$this->component_id]);
        return $stmt->fetch();
    }

    public function update()
    {
        return $this->row = $this->row();
    }

    public function heading()
    {
        $row = $this->row();
        return $row->heading;
    }

    public function columns()
    {
        $row = $this->row();
        return $row->columns ?? 6;
    }

    public function mobile_columns()
    {
        $row = $this->row();
        return $row->mobile_columns ?? 2;
    }

    public function tab_columns()
    {
        $row = $this->row();
        return $row->tab_columns ?? 4;
    }

    public function data()
    {
        $row = $this->row();
        $data = $row->data;
        return \json_decode($data);
    }

    public function type()
    {
        $row = $this->row();
        return $row->type;
    }


    public static function get_new_index()
    {
        global $Web;
        $stmt = $Web->db()->query("SELECT MAX(card_index) as card_index FROM $Web->components_tbl ");
        if (!$stmt->rowCount()) return 0;
        return $stmt->fetch()->card_index + 1;
    }


    public static function new_slider_name()
    {
        global $Web;
        $stmt = $Web->db()->query("SELECT COUNT(*) as count FROM $Web->components_tbl WHERE type = 'slider' ");
        $count = $stmt->fetch()->count;
        $count += 1;
        $name = "Slider$count";

        while (self::is_slider_name($name)) {
            $count += 1;
            $name = "Slider$count";
        }
        return $name;
    }

    public static function new_manual_slider_name()
    {
        global $Web;
        $stmt = $Web->db()->query("SELECT COUNT(*) as count FROM $Web->components_tbl WHERE type = 'manual_slider' ");
        $count = $stmt->fetch()->count;
        $count += 1;
        $name = "Manual Slider$count";

        while (self::is_slider_name($name)) {
            $count += 1;
            $name = "Manual Slider$count";
        }
        return $name;
    }

    public static function new_banner_name()
    {
        global $Web;
        $stmt = $Web->db()->query("SELECT COUNT(*) as count FROM $Web->components_tbl WHERE type = 'banner' ");
        $count = $stmt->fetch()->count;
        $count += 1;
        $name = "Slider$count";


        while (self::is_slider_name($name)) {
            $count += 1;
            $name = "Slider$count";
        }
        return "Banner$count";
    }

    public static function new_category_name()
    {
        global $Web;
        $stmt = $Web->db()->query("SELECT COUNT(*) as count FROM $Web->components_tbl WHERE type = 'category' ");
        $count = $stmt->fetch()->count;
        $count += 1;
        $name = "Category$count";


        while (self::is_slider_name($name)) {
            $count += 1;
            $name = "Slider$count";
        }
        return "Category$count";
    }

    public static function is_slider_name($heading, $id = false)
    {
        global $Web;
        if ($id) {
            $stmt = $Web->db()->prepare("SELECT heading FROM $Web->components_tbl WHERE heading = ? AND component_id != ? AND type = 'slider' ");
            $stmt->execute([$heading, $id]);
            return $stmt->rowCount() ? true : false;
        } else {
            $stmt = $Web->db()->prepare("SELECT heading FROM $Web->components_tbl WHERE heading = ? AND type = 'slider' ");
            $stmt->execute([$heading]);
            return $stmt->rowCount() ? true : false;
        }
    }

    public static function is_manual_slider_name($heading, $id = false)
    {
        global $Web;
        if ($id) {
            $stmt = $Web->db()->prepare("SELECT heading FROM $Web->components_tbl WHERE heading = ? AND component_id != ? AND type = 'manual_slider' ");
            $stmt->execute([$heading, $id]);
            return $stmt->rowCount() ? true : false;
        } else {
            $stmt = $Web->db()->prepare("SELECT heading FROM $Web->components_tbl WHERE heading = ? AND type = 'manual_slider' ");
            $stmt->execute([$heading]);
            return $stmt->rowCount() ? true : false;
        }
    }

    public static function is_banner_name($heading, $id = false)
    {
        global $Web;
        if ($id) {
            $stmt = $Web->db()->prepare("SELECT heading FROM $Web->components_tbl WHERE heading = ? AND component_id != ? AND type = 'banner' ");
            $stmt->execute([$heading, $id]);
            return $stmt->rowCount() ? true : false;
        } else {
            $stmt = $Web->db()->prepare("SELECT heading FROM $Web->components_tbl WHERE heading = ? AND type = 'banner' ");
            $stmt->execute([$heading]);
            return $stmt->rowCount() ? true : false;
        }
    }

    public static function is_category_name($heading, $id = false)
    {
        global $Web;
        if ($id) {
            $stmt = $Web->db()->prepare("SELECT heading FROM $Web->components_tbl WHERE heading = ? AND component_id != ? AND type = 'category' ");
            $stmt->execute([$heading, $id]);
            return $stmt->rowCount() ? true : false;
        } else {
            $stmt = $Web->db()->prepare("SELECT heading FROM $Web->components_tbl WHERE heading = ? AND type = 'category' ");
            $stmt->execute([$heading]);
            return $stmt->rowCount() ? true : false;
        }
    }

    public static function is_product_slider_name($heading, $id = false)
    {
        global $Web;
        if ($id) {

            $stmt = $Web->db()->prepare("SELECT heading FROM $Web->components_tbl WHERE heading = ? AND component_id != ? AND type = 'product_slider' ");
            $stmt->execute([$heading, $id]);
            return $stmt->rowCount() ? true : false;
        } else {
            $stmt = $Web->db()->prepare("SELECT heading FROM $Web->components_tbl WHERE heading = ? AND type = 'product_slider' ");
            $stmt->execute([$heading]);

            return $stmt->rowCount() ? true : false;
        }
    }

    // Sliders Tbl Start

    public static function sliders_tbl()
    {
        global $Web;
        $stmt = $Web->db()->query("SELECT component_id FROM $Web->components_tbl WHERE type = 'slider' ");
        $rows = $stmt->fetchAll();

        $output = "";
        foreach ($rows as $row) {
            $Slider = new self($row->component_id);
            $output .= $Slider->single_slider_tbl_card();
        }
        return $output;
    }

    public function slider_tbl_content()
    {
        $output = '';
        $data = $this->data();

        if (empty($data)) return '<tr>
            <td colspan="5" class="text-center" >No data available in table</td>
        </tr>';

        foreach ($data as $key => $data) {
            $index = $key + 1;
            $status = $data->status;

            $status_text = "Active";
            $statusSvg = '<i class="fs-2 fas fa-eye"></i>';
            if ($status == "active") {
                $status_text = "Inactive";
                $statusSvg = '<i class="fs-2 fas fa-eye-slash"></i>';
            }

            $status_label = $status == "active" ? $this->status_to_label($status, "success") : $this->status_to_label($status, "danger");
            $a = $data->url ? '<a href="' . $data->url . '" target="_blank" >Url</a>' : "NA";

            $output .= '
                <tr>
                    <td>' . $index . '</td>
                    <td><img class="img-fluid mh-100px" src="' . $this->get_file_src($data->image_id) . '" ></td>
                    <td>' . $a . '</td>
                    <td>' . $status_label . '</td>
                    <td>
                    <div class="d-flex">
                    <button data-action="updateSliderSlide" data-component_id="' . $this->component_id . '" data-key="' . $key . '" data-bs-toggle="tooltip" data-bs-original-title="Update" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                        <span class="svg-icon svg-icon-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                            </svg>
                        </span>
                    </button>
                    <button data-component_id="' . $this->component_id . '" data-key="' . $key . '" data-bs-toggle="tooltip" data-bs-original-title="Delete" data-action="deleteSliderImage" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                        <span class="svg-icon svg-icon-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="black"></path>
                            <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="black"></path>
                            <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="black"></path>
                        </svg>
                        </span>
                    </button>
                    <button  data-component_id="' . $this->component_id . '" data-key="' . $key . '" data-action="changeSliderSlideStatus" data-bs-toggle="tooltip" data-bs-original-title="' . $status_text . '" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">' . $statusSvg . ' </button>
                </div>
                </td>
                </tr>
            ';
        }
        return $output;
    }


    public function single_slider_tbl_card()
    {
        return '<div class="card card-flush">
        <div class="card-header align-items-center py-5 gap-2 gap-md-5" >
            <div data-bs-toggle="collapse" data-bs-target="#collapsible_' . $this->component_id . '"  class="flex-1 card-title cursor-pointer collapsible rotate">
            <span class="rotate-180 svg-icon svg-icon-1">
															<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																<rect opacity="0.5" x="11" y="18" width="13" height="2" rx="1" transform="rotate(-90 11 18)" fill="currentColor"></rect>
																<path d="M11.4343 15.4343L7.25 11.25C6.83579 10.8358 6.16421 10.8358 5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75L11.2929 18.2929C11.6834 18.6834 12.3166 18.6834 12.7071 18.2929L18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25C17.8358 10.8358 17.1642 10.8358 16.75 11.25L12.5657 15.4343C12.2533 15.7467 11.7467 15.7467 11.4343 15.4343Z" fill="currentColor"></path>
															</svg>
														</span>
                <h2 class="slider-heading ms-2" >' . $this->heading() . '</h2>
            </div>
            <div class="card-toolbar">

            <button data-heading="' . $this->heading() . '" data-component_id="' . $this->component_id . '" data-bs-toggle="tooltip" data-bs-original-title="Update heading" data-action="update_slider" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-2">
                <span class="svg-icon svg-icon-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                    </svg>
                </span>
            </button>

            <button data-component_id="' . $this->component_id . '" data-bs-toggle="tooltip" data-bs-original-title="Delete slider" data-action="delete_slider" class="me-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                <span class="svg-icon svg-icon-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="black"></path>
                    <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="black"></path>
                    <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="black"></path>
                </svg>
                </span>
            </button>

            <button data-component_id="' . $this->component_id . '" data-bs-toggle="tooltip" data-bs-original-title="Add new slide" data-action="add_slider_slide" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                <span class="svg-icon svg-icon-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5" fill="black"></rect>
                <rect x="10.8891" y="17.8033" width="12" height="2" rx="1" transform="rotate(-90 10.8891 17.8033)" fill="black"></rect>
                <rect x="6.01041" y="10.9247" width="12" height="2" rx="1" fill="black"></rect>
            </svg>
                </span>
            </button>

            </div>
        </div>
        <div id="collapsible_' . $this->component_id . '" class="collapse show">
                <div class="card-body pt-0">
            <div class="table-responsive">
                <table class="table align-middle table-row-dashed fs-6 gy-5">
                    <thead>
                        <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                            <th class="min-w-50px">#</th>
                            <th class="min-w-200px">Image</th>
                            <th class="min-w-150px">Url</th>
                            <th class="min-w-150px">Status</th>
                            <th class="min-w-150px">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="data" class="fw-bold text-gray-600">
                    ' . $this->slider_tbl_content() . '
                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </div>';
    }

    // Sliders Tbl End

    // Manual Sliders Start
    // Sliders Tbl

    public static function manual_sliders_tbl()
    {
        global $Web;
        $stmt = $Web->db()->query("SELECT component_id FROM $Web->components_tbl WHERE type = 'manual_slider' ");
        $rows = $stmt->fetchAll();

        $output = "";
        foreach ($rows as $row) {
            $Slider = new self($row->component_id);
            $output .= $Slider->single_manual_slider_tbl_card();
        }
        return $output;
    }

    public function manual_slider_tbl_content()
    {
        $output = '';
        $data = $this->data();

        if (empty($data)) return '<tr>
              <td colspan="5" class="text-center" >No data available in table</td>
          </tr>';

        foreach ($data as $key => $data) {
            $index = $key + 1;
            $status = $data->status;

            $status_text = "Active";
            $statusSvg = '<i class="fs-2 fas fa-eye"></i>';
            if ($status == "active") {
                $status_text = "Inactive";
                $statusSvg = '<i class="fs-2 fas fa-eye-slash"></i>';
            }

            $status_label = $status == "active" ? $this->status_to_label($status, "success") : $this->status_to_label($status, "danger");
            $a = $data->url ? '<a href="' . $data->url . '" target="_blank" >Url</a>' : "NA";

            $output .= '
                  <tr>
                      <td>' . $index . '</td>
                      <td><img class="img-fluid mh-100px" src="' . $this->get_file_src($data->image_id) . '" ></td>
                      <td>' . $a . '</td>
                      <td>' . $status_label . '</td>
                      <td>
                      <div class="d-flex">
                      <button data-action="updateSliderSlide" data-component_id="' . $this->component_id . '" data-key="' . $key . '" data-bs-toggle="tooltip" data-bs-original-title="Update" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                          <span class="svg-icon svg-icon-3">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                  <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                  <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                              </svg>
                          </span>
                      </button>
                      <button  data-component_id="' . $this->component_id . '" data-key="' . $key . '" data-bs-toggle="tooltip" data-bs-original-title="Delete" data-action="deleteSliderImage" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                          <span class="svg-icon svg-icon-3">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                              <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="black"></path>
                              <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="black"></path>
                              <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="black"></path>
                          </svg>
                          </span>
                      </button>
                      <button  data-component_id="' . $this->component_id . '" data-key="' . $key . '" data-action="changeSliderSlideStatus" data-bs-toggle="tooltip" data-bs-original-title="' . $status_text . '" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">' . $statusSvg . ' </button>
                  </div>
                  </td>
                  </tr>
              ';
        }
        return $output;
    }


    public function single_manual_slider_tbl_card()
    {
        return '<div class="card card-flush">
          <div class="card-header align-items-center py-5 gap-2 gap-md-5" >
              <div data-bs-toggle="collapse" data-bs-target="#collapsible_' . $this->component_id . '"  class="flex-1 card-title cursor-pointer collapsible rotate">
              <span class="rotate-180 svg-icon svg-icon-1">
                                                              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                  <rect opacity="0.5" x="11" y="18" width="13" height="2" rx="1" transform="rotate(-90 11 18)" fill="currentColor"></rect>
                                                                  <path d="M11.4343 15.4343L7.25 11.25C6.83579 10.8358 6.16421 10.8358 5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75L11.2929 18.2929C11.6834 18.6834 12.3166 18.6834 12.7071 18.2929L18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25C17.8358 10.8358 17.1642 10.8358 16.75 11.25L12.5657 15.4343C12.2533 15.7467 11.7467 15.7467 11.4343 15.4343Z" fill="currentColor"></path>
                                                              </svg>
                                                          </span>
                  <h2 class="slider-heading ms-2" >' . $this->heading() . '</h2>
              </div>
              <div class="card-toolbar">
  
              <button data-heading="' . $this->heading() . '" data-columns="' . $this->columns() . '" data-tab_columns="' . $this->tab_columns() . '" data-mobile_columns="' . $this->mobile_columns() . '" data-component_id="' . $this->component_id . '" data-bs-toggle="tooltip" data-bs-original-title="Update heading" data-action="update_slider" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-2">
                  <span class="svg-icon svg-icon-3">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                          <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                          <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                      </svg>
                  </span>
              </button>
  
              <button data-component_id="' . $this->component_id . '" data-bs-toggle="tooltip" data-bs-original-title="Delete slider" data-action="delete_slider" class="me-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                  <span class="svg-icon svg-icon-3">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                      <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="black"></path>
                      <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="black"></path>
                      <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="black"></path>
                  </svg>
                  </span>
              </button>
  
              <button data-component_id="' . $this->component_id . '" data-bs-toggle="tooltip" data-bs-original-title="Add new slide" data-action="add_slider_slide" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                  <span class="svg-icon svg-icon-3">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5" fill="black"></rect>
                  <rect x="10.8891" y="17.8033" width="12" height="2" rx="1" transform="rotate(-90 10.8891 17.8033)" fill="black"></rect>
                  <rect x="6.01041" y="10.9247" width="12" height="2" rx="1" fill="black"></rect>
              </svg>
                  </span>
              </button>
  
              </div>
          </div>
          <div id="collapsible_' . $this->component_id . '" class="collapse show">
                  <div class="card-body pt-0">
              <div class="table-responsive">
                  <table class="table align-middle table-row-dashed fs-6 gy-5">
                      <thead>
                          <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                              <th class="min-w-50px">#</th>
                              <th class="min-w-200px">Image</th>
                              <th class="min-w-150px">Url</th>
                              <th class="min-w-150px">Status</th>
                              <th class="min-w-150px">Actions</th>
                          </tr>
                      </thead>
                      <tbody id="data" class="fw-bold text-gray-600">
                      ' . $this->manual_slider_tbl_content() . '
                      </tbody>
                  </table>
              </div>
          </div>
          </div>
      </div>';
    }

    // Manual Sliders End

    // Banner


    public static function banners_collections_tbl()
    {
        global $Web;
        $stmt = $Web->db()->query("SELECT component_id FROM $Web->components_tbl WHERE type = 'banner' ");
        $rows = $stmt->fetchAll();

        $output = "";
        foreach ($rows as $row) {
            $Slider = new self($row->component_id);
            $output .= $Slider->single_banner_collection_tbl();
        }
        return $output;
    }

    public function banner_collection_tbl_content()
    {
        $output = '';
        $data = $this->data();

        if (empty($data)) return '<tr>
            <td colspan="5" class="text-center" >No data available in table</td>
        </tr>';

        foreach ($data as $key => $data) {


            $index = $key + 1;
            $status = $data->status;

            $status_text = "Active";
            $statusSvg = '<i class="fs-2 fas fa-eye"></i>';
            if ($status == "active") {
                $status_text = "Inactive";
                $statusSvg = '<i class="fs-2 fas fa-eye-slash"></i>';
            }

            $status_label = $status == "active" ? $this->status_to_label($status, "success") : $this->status_to_label($status, "danger");
            $a = $data->url ? '<a href="' . $data->url . '" target="_blank" >Url</a>' : "NA";

            $output .= '
                <tr>
                    <td>' . $index . '</td>
                    <td><img class="img-fluid mh-100px" src="' . $this->get_file_src($data->image_id) . '" ></td>
                    <td>' . $a . '</td>
                    <td>' . $status_label . '</td>
                    <td>
                    <div class="d-flex">
                    <button data-action="updateBanner" data-component_id="' . $this->component_id . '" data-key="' . $key . '" data-bs-toggle="tooltip" data-bs-original-title="Update" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                        <span class="svg-icon svg-icon-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                            </svg>
                        </span>
                    </button>
                    <button  data-component_id="' . $this->component_id . '" data-key="' . $key . '" data-bs-toggle="tooltip" data-bs-original-title="Delete" data-action="deleteBanner" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                        <span class="svg-icon svg-icon-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="black"></path>
                            <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="black"></path>
                            <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="black"></path>
                        </svg>
                        </span>
                    </button>
                    <button  data-component_id="' . $this->component_id . '" data-key="' . $key . '" data-action="changeBannerStatus" data-bs-toggle="tooltip" data-bs-original-title="' . $status_text . '" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">' . $statusSvg . ' </button>
                </div>
                </td>
                </tr>
            ';
        }
        return $output;
    }

    public function single_banner_collection_tbl()
    {
        return '<div class="card card-flush">
        <div class="card-header align-items-center py-5 gap-2 gap-md-5" >
            <div data-bs-toggle="collapse" data-bs-target="#collapsible_' . $this->component_id . '"  class="flex-1 card-title cursor-pointer collapsible rotate">
            <span class="rotate-180 svg-icon svg-icon-1">
															<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																<rect opacity="0.5" x="11" y="18" width="13" height="2" rx="1" transform="rotate(-90 11 18)" fill="currentColor"></rect>
																<path d="M11.4343 15.4343L7.25 11.25C6.83579 10.8358 6.16421 10.8358 5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75L11.2929 18.2929C11.6834 18.6834 12.3166 18.6834 12.7071 18.2929L18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25C17.8358 10.8358 17.1642 10.8358 16.75 11.25L12.5657 15.4343C12.2533 15.7467 11.7467 15.7467 11.4343 15.4343Z" fill="currentColor"></path>
															</svg>
														</span>
                <h2 class="collection-heading ms-2" >' . $this->heading() . '</h2>
            </div>
            <div class="card-toolbar">

            <button data-heading="' . $this->heading() . '" data-columns="' . $this->columns() . '" data-tab_columns="' . $this->tab_columns() . '" data-mobile_columns="' . $this->mobile_columns() . '" data-component_id="' . $this->component_id . '" data-bs-toggle="tooltip" data-bs-original-title="Update heading" data-action="update_collection" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-2">
                <span class="svg-icon svg-icon-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                    </svg>
                </span>
            </button>

            <button data-component_id="' . $this->component_id . '" data-bs-toggle="tooltip" data-bs-original-title="Delete collection" data-action="delete_collection" class="me-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                <span class="svg-icon svg-icon-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="black"></path>
                    <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="black"></path>
                    <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="black"></path>
                </svg>
                </span>
            </button>

            <button data-component_id="' . $this->component_id . '" data-bs-toggle="tooltip" data-bs-original-title="Add a banner" data-action="add_banner" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                <span class="svg-icon svg-icon-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5" fill="black"></rect>
                <rect x="10.8891" y="17.8033" width="12" height="2" rx="1" transform="rotate(-90 10.8891 17.8033)" fill="black"></rect>
                <rect x="6.01041" y="10.9247" width="12" height="2" rx="1" fill="black"></rect>
            </svg>
                </span>
            </button>

            </div>
        </div>
        <div id="collapsible_' . $this->component_id . '" class="collapse show">
                <div class="card-body pt-0">
            <div class="table-responsive">
                <table class="table align-middle table-row-dashed fs-6 gy-5">
                    <thead>
                        <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                            <th class="min-w-50px">#</th>
                            <th class="min-w-200px">Image</th>
                            <th class="min-w-150px">Url</th>
                            <th class="min-w-150px">Status</th>
                            <th class="min-w-150px">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="data" class="fw-bold text-gray-600">
                    ' . $this->banner_collection_tbl_content() . '
                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </div>';
    }

    // Product Sliders

    public static function product_sliders_tbl()
    {
        global $Web;
        $stmt = $Web->db()->query("SELECT component_id FROM $Web->components_tbl WHERE type = 'product_slider' ");
        if (!$stmt->rowCount()) {
            return '<tr>
            <td class="text-center" colspan="5" >No data available in the table</td></tr>';
        }
        $rows = $stmt->fetchAll();

        $output = "";
        foreach ($rows as $key => $row) {
            $count = $key + 1;
            $Slider = new self($row->component_id);
            $row_c = $Slider->data();

            $tr = '';

            $status = $row_c->status;
            if ($status === "active") $label = $Web->status_to_label($status, "success");
            if ($status === "inactive") $label = $Web->status_to_label($status, "danger");

            $status_text = "Active";
            $statusSvg = '<i class="fs-2 fas fa-eye"></i>';
            if ($status == "active") {
                $status_text = "Inactive";
                $statusSvg = '<i class="fs-2 fas fa-eye-slash"></i>';
            }

            $actions = ' <div class="d-flex">
            <button data-component_id="' . $row->component_id . '"  data-action="update"  data-bs-toggle="tooltip" data-bs-original-title="Update" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                <span class="svg-icon svg-icon-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                    </svg>
                </span>
            </button>
            <button data-component_id="' . $row->component_id . '" data-action="delete" data-bs-toggle="tooltip" data-bs-original-title="Delete" class="btn me-1 btn-icon btn-bg-light btn-active-color-primary btn-sm">
                <span class="svg-icon svg-icon-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="black"></path>
                    <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="black"></path>
                    <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="black"></path>
                </svg>
                </span>
            </button>
            <button  data-component_id="' . $row->component_id . '" data-action="changeStatus" data-bs-toggle="tooltip" data-bs-original-title="' . $status_text . '" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">' . $statusSvg . ' </button>
        </div>';

            $tr = '<tr>
                <td>' . $count . '</td>
                <td>' . $row_c->heading . '</td>
                <td>' . \strtoupper($row_c->sort_by) . '</td>
                <td>' . $label . '</td>
                <td>' . $actions . '</td>
            </tr>';

            $output .= $tr;
        }
        return $output;
    }



    // Categories

    public static function categories_collections_tbl()
    {
        global $Web;
        $stmt = $Web->db()->query("SELECT component_id FROM $Web->components_tbl WHERE type = 'category' ");
        $rows = $stmt->fetchAll();

        $output = "";
        foreach ($rows as $row) {
            $Slider = new self($row->component_id);
            $output .= $Slider->single_category_collection_tbl();
        }
        return $output;
    }

    public function single_category_collection_tbl()
    {

        return '<div class="card card-flush">
        <div class="card-header align-items-center py-5 gap-2 gap-md-5" >
            <div data-bs-toggle="collapse" data-bs-target="#collapsible_' . $this->component_id . '"  class="flex-1 card-title cursor-pointer collapsible rotate">
            <span class="rotate-180 svg-icon svg-icon-1">
															<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																<rect opacity="0.5" x="11" y="18" width="13" height="2" rx="1" transform="rotate(-90 11 18)" fill="currentColor"></rect>
																<path d="M11.4343 15.4343L7.25 11.25C6.83579 10.8358 6.16421 10.8358 5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75L11.2929 18.2929C11.6834 18.6834 12.3166 18.6834 12.7071 18.2929L18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25C17.8358 10.8358 17.1642 10.8358 16.75 11.25L12.5657 15.4343C12.2533 15.7467 11.7467 15.7467 11.4343 15.4343Z" fill="currentColor"></path>
															</svg>
														</span>
                <h2 class="collection-heading ms-2" >' . $this->heading() . '</h2>
            </div>
            <div class="card-toolbar">

            <button data-heading="' . $this->heading() . '" data-columns="' . $this->columns() . '" data-tab_columns="' . $this->tab_columns() . '" data-mobile_columns="' . $this->mobile_columns() . '" data-component_id="' . $this->component_id . '" data-bs-toggle="tooltip" data-bs-original-title="Update heading" data-action="update_collection" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-2">
                <span class="svg-icon svg-icon-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                    </svg>
                </span>
            </button>

            <button data-component_id="' . $this->component_id . '" data-bs-toggle="tooltip" data-bs-original-title="Delete collection" data-action="delete_collection" class="me-2 btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                <span class="svg-icon svg-icon-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="black"></path>
                    <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="black"></path>
                    <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="black"></path>
                </svg>
                </span>
            </button>

            <button data-component_id="' . $this->component_id . '" data-bs-toggle="tooltip" data-bs-original-title="Add a category" data-action="add_category" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                <span class="svg-icon svg-icon-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5" fill="black"></rect>
                <rect x="10.8891" y="17.8033" width="12" height="2" rx="1" transform="rotate(-90 10.8891 17.8033)" fill="black"></rect>
                <rect x="6.01041" y="10.9247" width="12" height="2" rx="1" fill="black"></rect>
            </svg>
                </span>
            </button>

            </div>
        </div>
        <div id="collapsible_' . $this->component_id . '" class="collapse show">
                <div class="card-body pt-0">
            <div class="table-responsive">
                <table class="table align-middle table-row-dashed fs-6 gy-5">
                    <thead>
                        <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                            <th class="min-w-50px">#</th>
                            <th class="min-w-200px">Name</th>
                            <th class="min-w-200px">Image</th>
                            <th class="min-w-150px">Url</th>
                            <th class="min-w-150px">Status</th>
                            <th class="min-w-150px">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="data" class="fw-bold text-gray-600">
                    ' . $this->category_collection_tbl_content() . '
                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </div>';
    }

    public function category_collection_tbl_content()
    {
        $output = '';
        $rows = $this->data();

        foreach ($rows as $key => $data) {
            $index = $key + 1;
            $status = $data->status;

            $status_text = "Active";
            $statusSvg = '<i class="fs-2 fas fa-eye"></i>';
            if ($status == "active") {
                $status_text = "Inactive";
                $statusSvg = '<i class="fs-2 fas fa-eye-slash"></i>';
            }

            $status_label = $status == "active" ? $this->status_to_label($status, "success") : $this->status_to_label($status, "danger");
            $a = $data->url ? '<a href="' . $data->url . '" target="_blank" >Url</a>' : "NA";

            $output .= '
                <tr>
                    <td>' . $index . '</td>
                    <td>' . $data->category_name . '</td>
                    <td><img class="img-fluid mh-100px" src="' . $this->get_file_src($data->image_id) . '" ></td>
                    <td>' . $a . '</td>
                    <td>' . $status_label . '</td>
                    <td>
                    <div class="d-flex">
                    <button data-action="updateCategory" data-component_id="' . $this->component_id . '" data-key="' . $key . '" data-bs-toggle="tooltip" data-bs-original-title="Update" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                        <span class="svg-icon svg-icon-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                            </svg>
                        </span>
                    </button>
                    <button data-component_id="' . $this->component_id . '" data-key="' . $key . '" data-bs-toggle="tooltip" data-bs-original-title="Delete" data-action="deleteCategory" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                        <span class="svg-icon svg-icon-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="black"></path>
                            <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="black"></path>
                            <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="black"></path>
                        </svg>
                        </span>
                    </button>
                    <button data-component_id="' . $this->component_id . '" data-key="' . $key . '" data-action="changeCategoryStatus" data-bs-toggle="tooltip" data-bs-original-title="' . $status_text . '" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">' . $statusSvg . ' </button>
                </div>
                </td>
                </tr>
            ';
        }
        return $output;
    }
}


class Layout extends Basic
{
    private $layout_id;
    private $row;

    function __construct($id)
    {
        if (!self::is_layout_id($id)) throw new Error("$id is not a valid layout Id");
        $this->layout_id = $id;
    }

    public static function is_layout_id($id)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT layout_id FROM $Web->layouts_tbl WHERE layout_id = ?");
        $stmt->execute([$id]);
        return $stmt->rowCount() ? true : false;
    }

    public static function is_page_id($page, $id = false)
    {
        global $Web;
        if ($id) {
            $stmt = $Web->db()->prepare("SELECT page_id FROM $Web->layouts_tbl WHERE page_id = ? AND layout_id != ?");
            $stmt->execute([$page, $id]);
        } else {
            $stmt = $Web->db()->prepare("SELECT page_id FROM $Web->layouts_tbl WHERE page_id = ?");
            $stmt->execute([$page]);
        }
        return $stmt->rowCount() ? true : false;
    }

    public static function get_id_by_page($page)
    {
        global $Web;
        $stmt = $Web->db()->prepare("SELECT layout_id FROM $Web->layouts_tbl WHERE page_id = ?");
        $stmt->execute([$page]);
        return $stmt->fetch()->layout_id;
    }


    public static function create_new_layout($page)
    {
        if (self::is_page_id($page)) return;
        global $Web;
        $components = '[]';
        $stmt = $Web->db()->prepare("INSERT INTO $Web->layouts_tbl (`page_id`,`components`) VALUES (?,?) ");
        $query = $stmt->execute([$page, $components]);
        if (!$query) throw new Error("Error in creating layout");
    }

    private function row()
    {
        if (!empty($this->row)) return $this->row;
        $stmt = $this->db()->prepare("SELECT * FROM $this->layouts_tbl WHERE layout_id = ?");
        $stmt->execute([$this->layout_id]);
        return $stmt->fetch();
    }

    public function update()
    {
        return $this->row = $this->row();
    }

    public function components()
    {
        $row = $this->row();
        $components = $row->components;
        return \json_decode($components);
    }

    public function page_id()
    {
        $row = $this->row();
        return $row->page_id;
    }

    public function status()
    {
        $row = $this->row();
        return $row->status;
    }

    public function status_label()
    {
        $status = $this->status();
        $status_label = $status == "active" ? $this->status_to_label($status, "success") : $this->status_to_label($status, "danger");
        return $status_label;
    }

    public function tbl_actions_btn()
    {
        $status = $this->status();
        $status_text = "Active";
        $statusSvg = '<i class="fs-2 fas fa-eye"></i>';
        if ($status == "active") {
            $status_text = "Inactive";
            $statusSvg = '<i class="fs-2 fas fa-eye-slash"></i>';
        }

        return '
        <div class="d-flex">
        <button data-action="update_page" data-name="' . $this->page_id() . '" data-layout_id="' . $this->layout_id . '" data-status="' . $this->status() . '" data-bs-toggle="tooltip" data-bs-original-title="Update" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
            <span class="svg-icon svg-icon-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                    <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                </svg>
            </span>
        </button>
        <button data-layout_id="' . $this->layout_id . '" data-bs-toggle="tooltip" data-bs-original-title="Delete" data-action="deletePage" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
            <span class="svg-icon svg-icon-3">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="black"></path>
                <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="black"></path>
                <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="black"></path>
            </svg>
            </span>
        </button>
        <button data-layout_id="' . $this->layout_id . '" data-action="changeStatus" data-bs-toggle="tooltip" data-bs-original-title="' . $status_text . '" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">' . $statusSvg . ' </button>
    </div>';
    }

    public function created_date()
    {
        $row = $this->row();
        $created_date = $row->created_date;
        return $this->date_time($created_date);
    }

    public function components_layout()
    {
        $components = $this->components();
        $output = "";
        foreach ($components as $key =>  $id) {
            if (!Component::is_component_id($id)) continue;
            $Component = new Component($id);
            $output .= '<div data-id="' . $id . '" class="bg-white cursor-move p-6 align-center" > 
                <span class="svg-icon me-4 svg-icon-muted" >
                <svg xmlns="http://www.w3.org/2000/svg" id="Outline" viewBox="0 0 24 24" width="512" height="512"><rect y="4" width="24" height="2" rx="1"/><rect y="18" width="24" height="2" rx="1"/></svg>
                </span>
                <div class="flex-1" >' . $Component->heading() . '</div>
                <button data-layout_id="' . $this->layout_id . '" data-component_id="' . $key . '" data-bs-toggle="tooltip" data-bs-original-title="Delete" data-action="delete" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                        <span class="svg-icon svg-icon-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="black"></path>
                            <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="black"></path>
                            <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="black"></path>
                        </svg>
                        </span>
                    </button>
            </div>';
        }
        return $output;
    }

    public static function pages_tbl_except_home()
    {
        global $Web;
        $output = "";
        $stmt = $Web->db()->query("SELECT layout_id FROM $Web->layouts_tbl WHERE page_id != 'HOME' ");
        if (!$stmt->rowCount()) {
            return '<tr>
            <td class="text-center" colspan="6" >No data available in the table</td></tr>';
        }

        $rows = $stmt->fetchAll();

        foreach ($rows as $key => $row) {

            $layout_id = $row->layout_id;
            $Layout = new Layout($layout_id);

            $index_key = $key + 1;
            $status_label = $Layout->status_label();
            $a = '<a target="_blank" href="' . $Web->base_url() . '/pages/' . $Layout->page_id() . '&id=' . $layout_id . '" target="_blank" >Url</a>';

            $created_date = $Layout->created_date();
            $tbl_btns = $Layout->tbl_actions_btn();

            $layout_url = '<a href="' . $Web->admin_url() . '/layout/create?id=' . $layout_id . '" >' . $Layout->page_id() . '</a>';

            $output .= '
                <tr>
                    <td>' . $index_key . '</td>
                    <td>' . $layout_url . '</td>
                    <td>' . $a . '</td>
                    <td>' . $status_label . '</td>
                    <td>' . $created_date . '</td>
                    <td>' . $tbl_btns . '</td>
                </tr>
            ';
        }
        return $output;
    }
}
